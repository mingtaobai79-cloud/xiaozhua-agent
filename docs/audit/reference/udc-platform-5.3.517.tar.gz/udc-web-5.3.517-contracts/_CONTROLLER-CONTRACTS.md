# udc-web-5.3.517 Controller 契约（javap -v 机器提取）

> 来源: Artifactory udc-web-5.3.517.jar | javap -v 常量池 Utf8 顺序解析

> Controller: 54 个 | 类级 @HasRole: 49 个

| Controller | 类级路径 | @HasRole 角色 |
|---|---|---|
| AppCollaborationController | `udc/collaboration` | udcAppDesigner, udcSystemAdmin |
| ApplicationController | `udc/application` | udcAppDesigner, udcRootOrgAdmin, udcSystemAdmin |
| AttachmentTemplateController | `udc/attachment-template` | udcAppDesigner, udcSystemAdmin |
| AttributeGroupController | `udc/attribute-group` | udcAppDesigner, udcSystemAdmin |
| AttributeSetController | `udc/attributeSet` | udcAppDesigner, udcSystemAdmin |
| BackendComponentController | `udc/backend-component` | OpsAdmin, udcAppDesigner, udcSystemAdmin |
| COLISplitController | `udc/app-split` | udcAppDesigner, udcRootOrgAdmin, udcSystemAdmin |
| DataFlowDesignController | `udc/data-flow` | udcAppDesigner, udcSystemAdmin |
| DataTransferObjectController | `udc/data-transfer-object` | udcAppDesigner, udcSystemAdmin |
| DataTypeController | `udc/data-type` | udcAppDesigner, udcSystemAdmin |
| DeductionRuleController | `udc/deduction` | udcAppDesigner, udcSystemAdmin |
| DependencyAnalysisController | `udc/dependency/analysis` | （无） |
| DeployController | `udc/runtime` | （无） |
| DeploymentController | `udc/deployment` | BpmSystemManager, OpsAdmin, udcAppDesigner, udcSystemAdmin |
| EntityController | `udc/entity` | udcAppDesigner, udcSystemAdmin |
| EntityGroupController | `udc/entity-group` | udcAppDesigner, udcSystemAdmin |
| EntityOpenApiController | `udc/entity-open-api` | udcAppDesigner, udcSystemAdmin |
| EventController | `udc/event` | udcAppDesigner, udcSystemAdmin |
| FeatureController | `udc/feature` | udcAppDesigner, udcSystemAdmin |
| FunctionNodeController | `udc/function` | udcAppDesigner, udcSystemAdmin |
| IndexController | `udc/index` | udcAppDesigner, udcSystemAdmin |
| MetaDataController | `udc/meta-data` | （无） |
| MicroFlowController | `udc/microflow` | udcAppDesigner, udcSystemAdmin |
| MicroFlowFunctionalCheckController | `udc/micro-flow-functional-check` | udcAppDesigner, udcSystemAdmin |
| MicroFlowGroupController | `udc/micro-flow-group` | udcAppDesigner, udcSystemAdmin |
| MicroFlowMacroController | `udc/micro-flow-macro` | udcAppDesigner, udcSystemAdmin |
| MicroFlowRefactorController | `udc/microflow-refactor` | udcAppDesigner, udcSystemAdmin |
| MicroFlowUpgradeController | `udc/micro-flow-upgrade` | udcAppDesigner, udcSystemAdmin |
| MultiEditController | `udc/multi-edit` | OrgAdmin, udcAppDesigner, udcSystemAdmin |
| OperationLogController | `udc/operation-log` | （无） |
| PageInfoController | `udc/page-info` | udcAppDesigner, udcSystemAdmin |
| PageLayoutController | `udc/page-layout` | udcAppDesigner, udcSystemAdmin |
| PageRouteController | `udc/page-route` | udcAppDesigner, udcSystemAdmin |
| PageTemplateClassController | `udc/page-template-class` | udcAppDesigner, udcRootOrgAdmin, udcSystemAdmin |
| PageTemplateController | `udc/page-template` | BpmDesigner, BpmManager, udcAppDesigner, udcSystemAdmin |
| PageTemplatePublishedController | `udc/page-template/published` | udcAppDesigner, udcRootOrgAdmin, udcSystemAdmin |
| ParameterController | `—` | （无） |
| PortletController | `udc/portlet` | OrgAdmin, udcAppDesigner, udcSystemAdmin |
| PortletGroupController | `udc/portlet-group` | OrgAdmin, udcAppDesigner, udcSystemAdmin |
| PublishStateController | `udc/publish-state` | OrgAdmin, udcAppDesigner, udcSystemAdmin |
| ReferConfigController | `udc/refer-config` | OrgAdmin, udcAppDesigner, udcSystemAdmin |
| SandboxController | `udc/sandbox` | OpsAdmin, OrgAdmin, udcAppDesigner, udcSystemAdmin |
| ScalabilityController | `udc/scalability` | udcAppDesigner, udcSystemAdmin |
| ScalabilityOptionController | `udc/scalability-option` | udcAppDesigner, udcSystemAdmin |
| StereotypeController | `udc/stereotype` | udcAppDesigner, udcSystemAdmin |
| TempPresetMicroFlowController | `udc/preset/microflow` | OrgAdmin, udcAppDesigner |
| UdcCtpEnumController | `udc/udc-enum-item` | udcAppDesigner, udcSystemAdmin |
| UdcDesignMetadataController | `udc/design-metadata` | （无） |
| UdcEnumCategoryController | `udc/udc-enum-category` | udcAppDesigner, udcSystemAdmin |
| UdcEnumController | `udc/udc-enum` | udcAppDesigner, udcSystemAdmin |
| UdcEnumItemController | `udc/udc-enum-item` | udcAppDesigner, udcSystemAdmin |
| UdcFileController | `udc/runtime/file` | （无） |
| UdcManagerController | `udc/manager` | （无） |
| UdcSandBoxLogController | `udc/sandbox/logs` | udcAppDesigner, udcSystemAdmin |
