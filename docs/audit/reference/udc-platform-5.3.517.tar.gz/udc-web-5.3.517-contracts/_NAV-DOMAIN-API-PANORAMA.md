# 设计器 8 导航域 API 全景（udc-web 5.3.517，方法级完整路径）

> 数据源: Artifactory udc-web-5.3.517.jar | javap -v 类级+方法级路径

| 导航域 | controller | API | POST | 独立服务 |
|---|---|---|---|---|
| 应用 | 8 | 111 | 78 | — |
| 实体 | 12 | 131 | 87 | — |
| 菜单 | 2 | 20 | 17 | — |
| 规则 | 8 | 108 | 83 | — |
| 流程 | 0 | 0 | 0 | bpm |
| BI | 0 | 0 | 0 | cdp-data |
| 栏目 | 7 | 82 | 62 | — |
| 设置 | 17 | 205 | 148 | — |

## 应用 域（111 API）

| Controller | 类级路径 | API | POST | 角色 |
|---|---|---|---|---|
| ApplicationController | `udc/application` | 70 | 51 | udcAppDesigner, udcRootOrgAdmin, udcSystemAdmin |
| PublishStateController | `udc/publish-state` | 1 | 1 | OrgAdmin, udcAppDesigner, udcSystemAdmin |
| SandboxController | `udc/sandbox` | 5 | 1 | OpsAdmin, OrgAdmin, udcAppDesigner, udcSystemAdmin |
| DeployController | `udc/runtime` | 12 | 11 | — |
| DeploymentController | `udc/deployment` | 6 | 6 | BpmSystemManager, OpsAdmin, udcAppDesigner, udcSystemAdmin |
| BackendComponentController | `udc/backend-component` | 9 | 4 | OpsAdmin, udcAppDesigner, udcSystemAdmin |
| AppCollaborationController | `udc/collaboration` | 6 | 4 | udcAppDesigner, udcSystemAdmin |
| DependencyAnalysisController | `udc/dependency/analysis` | 2 | 0 | — |

## 实体 域（131 API）

| Controller | 类级路径 | API | POST | 角色 |
|---|---|---|---|---|
| EntityController | `udc/entity` | 54 | 32 | udcAppDesigner, udcSystemAdmin |
| EntityGroupController | `udc/entity-group` | 7 | 5 | udcAppDesigner, udcSystemAdmin |
| AttributeSetController | `udc/attributeSet` | 10 | 9 | udcAppDesigner, udcSystemAdmin |
| AttributeGroupController | `udc/attribute-group` | 7 | 6 | udcAppDesigner, udcSystemAdmin |
| ReferConfigController | `udc/refer-config` | 12 | 11 | OrgAdmin, udcAppDesigner, udcSystemAdmin |
| EventController | `udc/event` | 12 | 10 | udcAppDesigner, udcSystemAdmin |
| IndexController | `udc/index` | 7 | 5 | udcAppDesigner, udcSystemAdmin |
| ScalabilityController | `udc/scalability` | 6 | 4 | udcAppDesigner, udcSystemAdmin |
| ScalabilityOptionController | `udc/scalability-option` | 8 | 4 | udcAppDesigner, udcSystemAdmin |
| DataTypeController | `udc/data-type` | 6 | 1 | udcAppDesigner, udcSystemAdmin |
| StereotypeController | `udc/stereotype` | 1 | 0 | udcAppDesigner, udcSystemAdmin |
| EntityOpenApiController | `udc/entity-open-api` | 1 | 0 | udcAppDesigner, udcSystemAdmin |

## 菜单 域（20 API）

| Controller | 类级路径 | API | POST | 角色 |
|---|---|---|---|---|
| FunctionNodeController | `udc/function` | 19 | 17 | udcAppDesigner, udcSystemAdmin |
| PageRouteController | `udc/page-route` | 1 | 0 | udcAppDesigner, udcSystemAdmin |

## 规则 域（108 API）

| Controller | 类级路径 | API | POST | 角色 |
|---|---|---|---|---|
| MicroFlowController | `udc/microflow` | 66 | 55 | udcAppDesigner, udcSystemAdmin |
| MicroFlowGroupController | `udc/micro-flow-group` | 7 | 6 | udcAppDesigner, udcSystemAdmin |
| MicroFlowMacroController | `udc/micro-flow-macro` | 2 | 1 | udcAppDesigner, udcSystemAdmin |
| MicroFlowRefactorController | `udc/microflow-refactor` | 3 | 2 | udcAppDesigner, udcSystemAdmin |
| MicroFlowUpgradeController | `udc/micro-flow-upgrade` | 4 | 0 | udcAppDesigner, udcSystemAdmin |
| MicroFlowFunctionalCheckController | `udc/micro-flow-functional-check` | 9 | 6 | udcAppDesigner, udcSystemAdmin |
| DeductionRuleController | `udc/deduction` | 16 | 13 | udcAppDesigner, udcSystemAdmin |
| TempPresetMicroFlowController | `udc/preset/microflow` | 1 | 0 | OrgAdmin, udcAppDesigner |

## 栏目 域（82 API）

| Controller | 类级路径 | API | POST | 角色 |
|---|---|---|---|---|
| PortletController | `udc/portlet` | 7 | 6 | OrgAdmin, udcAppDesigner, udcSystemAdmin |
| PortletGroupController | `udc/portlet-group` | 4 | 3 | OrgAdmin, udcAppDesigner, udcSystemAdmin |
| PageLayoutController | `udc/page-layout` | 18 | 13 | udcAppDesigner, udcSystemAdmin |
| PageInfoController | `udc/page-info` | 25 | 18 | udcAppDesigner, udcSystemAdmin |
| PageTemplateController | `udc/page-template` | 13 | 11 | BpmDesigner, BpmManager, udcAppDesigner, udcSystemAdmin |
| PageTemplateClassController | `udc/page-template-class` | 7 | 4 | udcAppDesigner, udcRootOrgAdmin, udcSystemAdmin |
| PageTemplatePublishedController | `udc/page-template/published` | 8 | 7 | udcAppDesigner, udcRootOrgAdmin, udcSystemAdmin |

## 设置 域（205 API）

| Controller | 类级路径 | API | POST | 角色 |
|---|---|---|---|---|
| UdcEnumController | `udc/udc-enum` | 8 | 7 | udcAppDesigner, udcSystemAdmin |
| UdcEnumItemController | `udc/udc-enum-item` | 12 | 10 | udcAppDesigner, udcSystemAdmin |
| UdcEnumCategoryController | `udc/udc-enum-category` | 8 | 7 | udcAppDesigner, udcSystemAdmin |
| UdcCtpEnumController | `udc/udc-enum-item` | 5 | 5 | udcAppDesigner, udcSystemAdmin |
| DataTransferObjectController | `udc/data-transfer-object` | 20 | 14 | udcAppDesigner, udcSystemAdmin |
| DataFlowDesignController | `udc/data-flow` | 24 | 20 | udcAppDesigner, udcSystemAdmin |
| FeatureController | `udc/feature` | 2 | 0 | udcAppDesigner, udcSystemAdmin |
| ParameterController | `None` | 6 | 5 | — |
| MetaDataController | `udc/meta-data` | 28 | 22 | — |
| UdcDesignMetadataController | `udc/design-metadata` | 47 | 27 | — |
| MultiEditController | `udc/multi-edit` | 5 | 5 | OrgAdmin, udcAppDesigner, udcSystemAdmin |
| OperationLogController | `udc/operation-log` | 6 | 4 | — |
| AttachmentTemplateController | `udc/attachment-template` | 6 | 4 | udcAppDesigner, udcSystemAdmin |
| COLISplitController | `udc/app-split` | 8 | 7 | udcAppDesigner, udcRootOrgAdmin, udcSystemAdmin |
| UdcFileController | `udc/runtime/file` | 2 | 0 | — |
| UdcSandBoxLogController | `udc/sandbox/logs` | 5 | 5 | udcAppDesigner, udcSystemAdmin |
| UdcManagerController | `udc/manager` | 13 | 6 | — |
