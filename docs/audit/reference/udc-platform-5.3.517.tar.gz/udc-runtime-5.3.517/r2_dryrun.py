"""R2 registry-entries 只读 dry-run: 从 md 抽取 python 构造块, 用真实 models.py 实例化, 校验 13 条 + 0 冲突。
绝不写 registry.py / models.py。"""
import re, json, pathlib, sys
sys.path.insert(0, r"D:\work\chit\seeyon-agent")
from components.platform_operations.models import UdcOperationContract, OperationStatus
from components.platform_operations.registry import UdcOperationRegistry

MD = pathlib.Path(r"D:\work\chit\seeyon-agent\docs\operation-contracts\udc\runtime\registry-entries.md")
OUT = pathlib.Path(r"D:\work\chit\seeyon-agent\docs\audit\artifacts\udc-runtime-5.3.517\r2_registry_entries_dryrun.txt")
text = MD.read_text(encoding="utf-8")
blocks = re.findall(r"```python\n(.*?)```", text, re.S)
code = "\n".join(blocks)

contracts = {}
ns = {"UdcOperationContract": UdcOperationContract, "OperationStatus": OperationStatus, "contracts": contracts}
exec(compile(code, "registry-entries.md", "exec"), ns)

lines = []
lines.append("DRY-RUN registry-entries.md (runtime 域)  -- 只读, 未写任何仓库文件")
lines.append("构造成功条数 = %d" % len(contracts))
existing = UdcOperationRegistry.default()._contracts
conflicts = [k for k in contracts if k in existing]
lines.append("与既有运行态键(76)冲突 = %d  %s" % (len(conflicts), conflicts))
from dataclasses import fields
fk = [f.name for f in fields(UdcOperationContract)]
lines.append("字段序 = %s" % fk)
for k, v in contracts.items():
    lines.append("  %-42s method=%-4s write=%s status=%s effective=%s" %
                 (k, v.method, v.write, v.status, v.effective))
# 断言
assert len(contracts) == 13, "expected 13, got %d" % len(contracts)
assert not conflicts, conflicts
eff = [k for k, v in contracts.items() if v.effective]
lines.append("effective()=True 条数 = %d  %s" % (len(eff), eff))
lines.append("VERDICT: PASS (13/13 construct OK, 0 key conflict)")
OUT.write_text("\n".join(lines) + "\n", encoding="utf-8")
print("\n".join(lines))
