"""R2 步骤4: 106 个 registry 0 命中候选分类: 写形态 / R7R8 排除 / human 域排除 / 只读候选。"""
import json, re, pathlib

BASE = pathlib.Path(__file__).parent
d = json.loads((BASE / "r2_diff.json").read_text(encoding="utf-8"))
new = d["new"]

WRITE_VERB = re.compile(r"(^|/)(create|update|delete|add|save|import|export|copy|upgrade|deploy|init|clear|unload|evict|refresh|enable|upload|modify|operate|runtime-copy|fill|batch|publish|apply|bind|reset|sync|submit|execute|invoke|remove|set)", re.I)
READ_VERB = re.compile(r"(search|select|query|get|list|detail|check|calculat|find|page|tree|exist|count|graphql|forward|cascade|default|info|status|version|permission|length|content)", re.I)
# GET 语义写侧（GET 但方法名是写动作）
GET_WRITE = re.compile(r"(clear|delete|unload|evict|refresh|enable|set|update|create|remove)", re.I)
R7R8 = re.compile(r"(create-bpm|update-bpm|dataflow/|microflow/)", re.I)
HUMAN = re.compile(r"(page-refer/)", re.I)

buckets = {"read": [], "write": [], "r7r8": [], "human": []}
for e in new:
    path = e["norm_path"]
    m = "/".join(e["methods"])
    mem = e["member"]
    if R7R8.search(path):
        buckets["r7r8"].append(e); continue
    if HUMAN.search(path):
        buckets["human"].append(e); continue
    if m == "GET":
        if GET_WRITE.search(mem) and not re.search(r"(get|check|search|select|list|info|status|version|permission|length|content)", mem, re.I):
            buckets["write"].append(e)
        elif GET_WRITE.search(mem):
            buckets["write"].append(e)
        else:
            buckets["read"].append(e)
    else:  # POST etc.
        if READ_VERB.search(mem) and not WRITE_VERB.search(mem):
            buckets["read"].append(e)
        else:
            buckets["write"].append(e)

for k, v in buckets.items():
    print("== %s (%d) ==" % (k, len(v)))
    for e in sorted(v, key=lambda x: x["norm_path"]):
        print("   %-6s %-88s %s#%s" % ("/".join(e["methods"]), e["norm_path"], e["class"].split(".")[-1], e["member"]))
    print()

json.dump({k: v for k, v in buckets.items()},
          (BASE / "r2_classified.json").open("w", encoding="utf-8"), ensure_ascii=False, indent=1)
print("counts", {k: len(v) for k, v in buckets.items()}, "sum", sum(len(v) for v in buckets.values()))
