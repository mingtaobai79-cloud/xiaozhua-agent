"""R2 步骤2: 把 runtime jar 的 mapping-bearing 类的类级基路径 × 方法级路径展开为端点表。"""
import json, pathlib, sys, re

SRC = pathlib.Path(sys.argv[1] if len(sys.argv) > 1 else "r2_endpoints_raw.json")
OUT = pathlib.Path(sys.argv[2] if len(sys.argv) > 2 else "r2_endpoints_flat.json")
data = json.loads(SRC.read_text(encoding="utf-8"))


def join(base, path):
    if base and path:
        return base.rstrip("/") + "/" + path.lstrip("/")
    return base or path


endpoints = []
for b in data["mapping_bearing"]:
    bases = []
    for a in b["class_level"]:
        for p in a["paths"]:
            bases.append(p)
    if not bases:
        bases = [""]
    for m in b["members"]:
        for mp in m["mappings"]:
            paths = mp["paths"] or [""]
            for base in bases:
                for p in paths:
                    full = join(base, p)
                    norm = "/" + full.lstrip("/")
                    endpoints.append({
                        "class": b["class"],
                        "class_sha256": b["class_sha256"],
                        "member": m["member"],
                        "descriptor": m["descriptor"],
                        "annotation": mp["annotation"],
                        "raw_paths": mp["paths"],
                        "base_paths": [x for x in bases if x],
                        "full_path": full,
                        "norm_path": norm,
                        "methods": mp["effective_methods"],
                    })

# 模板归一（{var} -> {}），用于差分匹配
def templ(p):
    return re.sub(r"\{[^}]*\}", "{}", p)

for e in endpoints:
    e["template"] = templ(e["norm_path"])

out = {"jar": data["jar"], "jar_sha256": data["jar_sha256"],
       "mapping_bearing_count": data["mapping_bearing_count"],
       "endpoint_rows": len(endpoints), "endpoints": endpoints}
OUT.write_text(json.dumps(out, ensure_ascii=False, indent=1), encoding="utf-8")

print("endpoint_rows", len(endpoints))
by_method = {}
for e in endpoints:
    for mth in e["methods"]:
        by_method[mth] = by_method.get(mth, 0) + 1
print("by method", by_method)
print()
for e in sorted(endpoints, key=lambda x: (x["class"], x["member"])):
    print("%-6s %-95s %s#%s" % ("/".join(e["methods"]), e["full_path"], e["class"].split(".")[-1], e["member"]))
