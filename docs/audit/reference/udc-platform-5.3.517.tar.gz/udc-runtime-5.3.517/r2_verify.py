"""R2 步骤7: 三层完备性核对 + 计数摘要 + 把 _scratch 中间产物 stage 到证据目录。"""
import json, pathlib, shutil, hashlib, subprocess, re

SCRATCH = pathlib.Path(__file__).parent
ART = pathlib.Path(r"D:\work\chit\seeyon-agent\docs\audit\artifacts\udc-runtime-5.3.517")

raw = json.loads((SCRATCH / "r2_endpoints_raw.json").read_text(encoding="utf-8"))
flat = json.loads((SCRATCH / "r2_endpoints_flat.json").read_text(encoding="utf-8"))
diff = json.loads((SCRATCH / "r2_diff.json").read_text(encoding="utf-8"))
cls = json.loads((SCRATCH / "r2_classified.json").read_text(encoding="utf-8"))
lA = json.loads((ART / "r2_layerA_classname_scan.json").read_text(encoding="utf-8"))
lC = json.loads((ART / "r2_layerC_constantpool_scan.json").read_text(encoding="utf-8"))

# 计数
class_level_decls = sum(1 for b in raw["mapping_bearing"] if b["class_level"])
member_mapped = sum(len(b["members"]) for b in raw["mapping_bearing"])
endpoint_rows = len(flat["endpoints"])
# L-B 端点表用到的全部原始路径字面量
lb_literals = set()
for b in raw["mapping_bearing"]:
    for a in b["class_level"]:
        lb_literals.update(a["paths"])
    for m in b["members"]:
        for mp in m["mappings"]:
            lb_literals.update(mp["paths"])

# L-C 覆盖核对: L-C 中所有 udc-runtime* 或 '/' 开头字面量, 是否都能在 L-B 找到载体
lc_lit = lC["slash_literals"]
lc_only = {}
for k, owners in lc_lit.items():
    if k in lb_literals:
        continue
    # 允许前缀/后缀包含关系(路径段拼接)
    if any(k in lit or lit in k for lit in lb_literals if lit):
        continue
    lc_only[k] = len(owners)

summary = {
    "jar": raw["jar"], "jar_sha256": raw["jar_sha256"], "version": "5.3.517",
    "layer_A": {"class_entries": lA["class_entries"], "top_level_classes": lA["top_level_classes"],
                "udcrt_controller_classes": len(lA["udcrt_classes"]),
                "proxy_controller_classes": len(lA["proxy_classes"])},
    "layer_B": {"mapping_bearing_classes": raw["mapping_bearing_count"],
                "class_level_mapping_decls": class_level_decls,
                "members_with_mapping": member_mapped,
                "expanded_endpoint_rows": endpoint_rows},
    "layer_C": {"classes_scanned": lC["classes_scanned"], "utf8_total": lC["utf8_total"],
                "distinct_slash_literals": lC["distinct_slash_literals"],
                "lC_only_literals_not_in_lB": lc_only},
    "differential": {"total_rows": diff["total"],
                     "covered_dedup": len(diff["covered"]),
                     "zero_hit": len(diff["new"]),
                     "read": len(cls["read"]), "write": len(cls["write"]),
                     "r7r8_excluded": len(cls["r7r8"]), "human_excluded": len(cls["human"])},
}
(ART / "r2_summary.json").write_text(json.dumps(summary, ensure_ascii=False, indent=1), encoding="utf-8")
print(json.dumps(summary, ensure_ascii=False, indent=1))

# stage scratch 中间产物 + 脚本
stage = ["r2_endpoints_raw.json", "r2_endpoints_flat.json", "r2_diff.json", "r2_classified.json"]
scans = ["r2_scan_runtime.py", "r2_flatten.py", "r2_diff.py", "r2_classify.py",
         "r2_layerAC.py", "r2_javap_dump.py", "r2_sig.py", "r2_verify.py"]
staged = []
for f in stage + scans:
    src = SCRATCH / f
    if src.exists():
        dst = ART / f
        shutil.copy2(src, dst)
        staged.append({"file": f, "bytes": dst.stat().st_size,
                       "sha256": hashlib.sha256(dst.read_bytes()).hexdigest()})
(ART / "r2_staged_manifest.json").write_text(json.dumps(staged, ensure_ascii=False, indent=1), encoding="utf-8")
print("staged", len(staged), "files")
