"""R2 步骤3: 差分 —— 端点表 vs registry 全键（按规范化模板路径匹配）。"""
import json, re, pathlib, sys

BASE = pathlib.Path(__file__).parent
endp = json.loads((BASE / "r2_endpoints_flat.json").read_text(encoding="utf-8"))
reg = json.loads((BASE / "registry_dump.json").read_text(encoding="utf-8"))


def norm(p):
    if not p:
        return ""
    p = p.strip()
    p = re.sub(r"//+", "/", p)
    p = p.lstrip("/")
    p = re.sub(r"\{[^}]*\}", "{}", p)
    return p


reg_by_tpl = {}
for r in reg:
    reg_by_tpl.setdefault(norm(r["path"]), []).append(r)

rows = []
for e in endp["endpoints"]:
    tpl = norm(e["norm_path"])
    hit = reg_by_tpl.get(tpl, [])
    rows.append({**e, "tpl": tpl, "registry_hits": [h["key"] for h in hit]})

covered = [r for r in rows if r["registry_hits"]]
new = [r for r in rows if not r["registry_hits"]]

WRITE_HINT = re.compile(r"(create|update|delete|save|add|remove|import|export|copy|upgrade|deploy|init|clear|unload|evict|refresh|enable|upload|modify|set|put|post|operate|fill|batch|publish|apply|bind|reset|sync|submit|execute|invoke|call|run)", re.I)
# 本函数仅给候选做初筛，最终判定由人工/语义层确认

print("== 总端点", len(rows), " 已覆盖", len(covered), " 新候选", len(new))
print()
print("== 已覆盖（命中 registry 键）==")
for r in sorted(covered, key=lambda x: x["tpl"]):
    print("  %-8s %-72s -> %s" % ("/".join(r["methods"]), r["norm_path"], ",".join(r["registry_hits"])))
print()
print("== 新候选（registry 0 命中）==")
for r in sorted(new, key=lambda x: (x["methods"], x["tpl"])):
    print("  %-8s %-8s %-85s %s#%s" % ("/".join(r["methods"]), r["annotation"], r["norm_path"], r["class"].split(".")[-1], r["member"]))

json.dump({"covered": covered, "new": new, "total": len(rows),
           "reg_templates": sorted(reg_by_tpl.keys())},
          (BASE / "r2_diff.json").open("w", encoding="utf-8"), ensure_ascii=False, indent=1)
