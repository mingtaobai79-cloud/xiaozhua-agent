"""R2 步骤6: 从 javap -v 文本提取每个方法的 注解/描述符/Signature/参数注解/局部变量名。"""
import re, sys, pathlib

def extract(path):
    txt = pathlib.Path(path).read_text(encoding="utf-8")
    # 只取 class 体（跳过常量池）
    lines = txt.splitlines()
    out = []
    i = 0
    # 找每个方法: 行以 "  " 开头且含 "(" 且以 "); " 或 ");" 结尾, 或 "abstract"/"native"
    meth_re = re.compile(r"^\s{2}(public|protected|private|static|final|abstract|\s)*.*\(.*\);?\s*$")
    blocks = []
    n = len(lines)
    idx = [k for k, ln in enumerate(lines) if re.match(r"^  [a-zA-Z@]", ln) and "(" in ln and ln.rstrip().endswith(";")]
    for k in idx:
        blk = [lines[k]]
        j = k + 1
        while j < n and not (re.match(r"^  [a-zA-Z@]", lines[j]) and "(" in lines[j] and lines[j].rstrip().endswith(";")):
            blk.append(lines[j]); j += 1
            if len(blk) > 400: break
        blocks.append(blk)
    for blk in blocks:
        head = blk[0]
        sig = next((l.strip() for l in blk if l.strip().startswith("Signature:")), "")
        # 方法级映射注解
        mapann = []
        for l in blk:
            m = re.match(r'\s*(com\.seeyon\.[\w.]*|org\.springframework\.web\.bind\.annotation\.[\w.]+)\s*\(', l)
            if m and ("Mapping" in m.group(1) or "PathVariable" in m.group(1) or "RequestBody" in m.group(1) or "RequestParam" in m.group(1)):
                # 抓取注解参数
                cand = l.strip()
                mapann.append(cand[:200])
        # RuntimeVisibleParameterAnnotations 区
        pann = []
        inpa = False
        for l in blk:
            if "RuntimeVisibleParameterAnnotations" in l:
                inpa = True; continue
            if inpa:
                if re.match(r"^\s{2}[A-Za-z]", l) and ":" not in l: break
                s = l.strip()
                if s.startswith("com.seeyon") or s.startswith("org.springframework") or s.startswith("javax"):
                    pann.append(s[:160])
        # LocalVariableTable 首参名
        lv = [l.strip() for l in blk if re.search(r"LocalVariableTable", l)]
        out.append({"head": head.strip(), "signature": sig,
                    "ann": mapann, "param_ann": pann, "has_lvt": bool(lv)})
    return out


for p in sys.argv[1:]:
    print("=" * 100)
    print(pathlib.Path(p).name)
    for m in extract(p):
        print("  M:", m["head"])
        if m["signature"]:
            print("     SIG:", m["signature"])
        for a in m["ann"]:
            print("     ANN:", a)
        for a in m["param_ann"]:
            print("     PANN:", a)
