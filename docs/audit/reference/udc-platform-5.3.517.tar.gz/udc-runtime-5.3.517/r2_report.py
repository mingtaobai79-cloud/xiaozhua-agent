"""R2 步骤8: 产出最终只读候选表 + registry 全键 0 命中 grep 证明。"""
import json, re, pathlib, subprocess

SCRATCH = pathlib.Path(__file__).parent
ART = pathlib.Path(r"D:\work\chit\seeyon-agent\docs\audit\artifacts\udc-runtime-5.3.517")
REG = r"D:\work\chit\seeyon-agent\components\platform_operations\registry.py"

# 13 只读候选: (operation_id, method, path, request_type, response_type, FQCN, member, javap_file)
CANDIDATES = [
    # A. runtime 域原生 (7)
    ("udc.runtime.env_check_build_info", "GET", "udc-runtime/evn-check/build-info/{appName}",
     "String appName (@PathVariable)", "SingleResponse<Map<String, Object>>",
     "com.seeyon.boot.starter.udcrt.controller.RuntimeEnvCheckController", "getBuildInfo", "r2-RuntimeEnvCheckController.javap.txt"),
    ("udc.runtime.env_check_app_version", "GET", "udc-runtime/evn-check/app-version/{appName}",
     "String appName (@PathVariable)", "SingleResponse<String>",
     "com.seeyon.boot.starter.udcrt.controller.RuntimeEnvCheckController", "checkAppVersion", "r2-RuntimeEnvCheckController.javap.txt"),
    ("udc.runtime.env_check_data_permission", "GET", "udc-runtime/evn-check/data-permission/{entityFullName}",
     "String entityFullName (@PathVariable)", "SingleResponse<Object>",
     "com.seeyon.boot.starter.udcrt.controller.RuntimeEnvCheckController", "checkDataPermission", "r2-RuntimeEnvCheckController.javap.txt"),
    ("udc.runtime.env_check_response_length", "GET", "udc-runtime/evn-check/response-length/{length}",
     "Integer length (@PathVariable)", "SingleResponse<String>",
     "com.seeyon.boot.starter.udcrt.controller.RuntimeEnvCheckController", "checkResponseLength", "r2-RuntimeEnvCheckController.javap.txt"),
    ("udc.runtime.env_check_request_content", "POST", "udc-runtime/evn-check/request-content",
     "String content (@MultiRequestBody)", "SingleResponse<String>",
     "com.seeyon.boot.starter.udcrt.controller.RuntimeEnvCheckController", "checkRequestContent", "r2-RuntimeEnvCheckController.javap.txt"),
    ("udc.runtime.function_support_calculate", "POST", "udc-runtime/function-support/calculate",
     "FrontFunctionSupportDto (@RequestBody)", "SingleResponse<Object>",
     "com.seeyon.boot.starter.udcrt.controller.FrontFunctionSupportController", "selectListByEntityName", "r2-FrontFunctionSupportController.javap.txt"),
    ("udc.runtime.graphql_proxy_graphql", "POST", "udc-runtime/graphql-proxy/graphql",
     "GraphqlProxyRequestDto (@RequestBody)", "SingleResponse<String>",
     "com.seeyon.boot.starter.udcrt.controller.GraphqlProxyController", "doGraphql", "r2-GraphqlProxyController.javap.txt"),
    # B. 跨域词干重叠 (6)
    ("udc.applog.search_dataflow", "POST", "udc-runtime/app-log/search/dataflow",
     "PageDtoRequest<DataFlowLogSearchDto> (@RequestBody)", "PageResponse<UdcDataFlowLogDto>",
     "com.seeyon.boot.starter.udcrt.controller.UdcAppLogController", "searchDataFlow", "r2-UdcAppLogController.javap.txt"),
    ("udc.applog.search_dataflow_details", "POST", "udc-runtime/app-log/search-details/dataflow",
     "PageDtoRequest<DataFlowLogSearchDto> (@RequestBody)", "PageResponse<UdcDataFlowLogDto>",
     "com.seeyon.boot.starter.udcrt.controller.UdcAppLogController", "searchDataFlowDetails", "r2-UdcAppLogController.javap.txt"),
    ("udc.applog.search_deduction", "POST", "udc-runtime/app-log/search/deduction",
     "PageDtoRequest<DeductionLogSearchDto> (@RequestBody)", "PageResponse<UdcDeductionLogDto>",
     "com.seeyon.boot.starter.udcrt.controller.UdcAppLogController", "searchDeduction", "r2-UdcAppLogController.javap.txt"),
    ("udc.applog.search_deduction_details", "POST", "udc-runtime/app-log/search-details/deduction",
     "PageDtoRequest<DeductionLogSearchDto> (@RequestBody)", "PageResponse<UdcDeductionLogDto>",
     "com.seeyon.boot.starter.udcrt.controller.UdcAppLogController", "searchDeductionDetails", "r2-UdcAppLogController.javap.txt"),
    ("udc.serial.config_list", "POST", "udc-runtime/serial-config/list",
     "Map params + Sort sort (@RequestBody)", "ListResponse",
     "com.seeyon.boot.starter.udcrt.controller.UdcSerialConfigController", "selectListByConditions", "r2-UdcSerialConfigController.javap.txt"),
    ("udc.runtime.jar_import_status", "GET", "udc-runtime/dynamic/jar/import/status/{requestId}",
     "String requestId (@PathVariable)", "SingleResponse<RequestStatusDto>",
     "com.seeyon.boot.starter.udcrt.controller.DynamicJarController", "getRequestStatus", "r2-DynamicJarController.javap.txt"),
]

man = {f["simple"]: f for f in json.loads((ART / "r2_javap_manifest.json").read_text(encoding="utf-8"))["files"]}
reg_text = pathlib.Path(REG).read_text(encoding="utf-8", errors="replace")

out = []
proof = ["# R2 registry 全键 0 命中证明（13 只读候选）", "# registry.py: %s" % REG, ""]
for (oid, method, path, req, resp, fq, mem, jf) in CANDIDATES:
    simple = fq.split(".")[-1]
    sha = man[simple]["class_sha256"]
    # 0 命中证明: operation_id 与 path 模板 grep registry.py
    id_hits = reg_text.count('"%s"' % oid)
    # 路径模板匹配（{var}-> 通配，仅比字面路径段）
    raw_pat = re.sub(r"\{[^}]*\}", r"[^\\\"]*", path)
    path_hits = len(re.findall(r'"%s"' % raw_pat.replace("/", "/"), reg_text))
    out.append({"operation_id": oid, "method": method, "path": path,
                "request_type": req, "response_type": resp, "class": fq, "member": mem,
                "class_sha256": sha, "javap": "docs/audit/artifacts/udc-runtime-5.3.517/" + jf,
                "registry_id_hits": id_hits, "registry_path_hits": path_hits,
                "tier": "A-runtime-native" if oid.startswith("udc.runtime.") and "jar_import" not in oid else "B-overlap"})
    proof.append("op=%s  id_hits=%d  path_hits=%d  path=%s" % (oid, id_hits, path_hits, path))

(ART / "r2_candidates.json").write_text(json.dumps(out, ensure_ascii=False, indent=1), encoding="utf-8")
(ART / "r2_registry_key_check.txt").write_text("\n".join(proof) + "\n", encoding="utf-8")
print("\n".join(proof))
print()
print("total candidates", len(out), " all id_hits==0:", all(c["registry_id_hits"] == 0 for c in out))
