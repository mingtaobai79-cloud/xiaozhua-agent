"""R2 运行时域: 解析 udc-starter-runtime-5.3.517.jar 全部 mapping-bearing 类的映射端点。
口径照抄 udc-bi-5.3.517/r1_extract_endpoints.py（自实现 JVMS 常量池 + RuntimeVisibleAnnotations）。
只读 jar，只写 _scratch/。"""
import zipfile, hashlib, struct, json, pathlib, sys

JAR = pathlib.Path(r"D:\repo\CHIT\com\seeyon\udc-starter-runtime\5.3.517\udc-starter-runtime-5.3.517.jar")
OUT = pathlib.Path(sys.argv[1]) if len(sys.argv) > 1 else pathlib.Path("r2_endpoints_raw.json")

MAPPING_TYPES = {
    "Lorg/springframework/web/bind/annotation/RequestMapping;": "RequestMapping",
    "Lorg/springframework/web/bind/annotation/GetMapping;": "GetMapping",
    "Lorg/springframework/web/bind/annotation/PostMapping;": "PostMapping",
    "Lorg/springframework/web/bind/annotation/PutMapping;": "PutMapping",
    "Lorg/springframework/web/bind/annotation/DeleteMapping;": "DeleteMapping",
    "Lorg/springframework/web/bind/annotation/PatchMapping;": "PatchMapping",
}
MAPPING_DEFAULT_METHOD = {
    "GetMapping": ["GET"], "PostMapping": ["POST"], "PutMapping": ["PUT"],
    "DeleteMapping": ["DELETE"], "PatchMapping": ["PATCH"], "RequestMapping": ["ANY"],
}


class CP:
    def __init__(self, buf, pos):
        n = struct.unpack_from(">H", buf, pos)[0]; pos += 2
        self.slots = {}
        i = 1
        while i < n:
            tag = buf[pos]; pos += 1
            if tag == 1:
                ln = struct.unpack_from(">H", buf, pos)[0]; pos += 2
                self.slots[i] = ("Utf8", buf[pos:pos + ln].decode("utf-8", "replace")); pos += ln
            elif tag in (3, 4):
                self.slots[i] = ("Num", struct.unpack_from(">i", buf, pos)[0]); pos += 4
            elif tag in (9, 10, 11, 12, 17, 18):
                a, b = struct.unpack_from(">HH", buf, pos); pos += 4
                self.slots[i] = ("Ref%d" % tag, (a, b))
            elif tag in (15,):
                pos += 3; self.slots[i] = ("MethodHandle", None)
            elif tag in (7, 8, 16, 19, 20):
                pos += 2; self.slots[i] = ("T%d" % tag, None)
            elif tag in (5, 6):
                self.slots[i] = ("Long/Double", None); pos += 8; i += 1
            else:
                raise ValueError("bad cp tag %d" % tag)
            i += 1
        self.end = pos

    def utf8(self, idx):
        v = self.slots.get(idx)
        return v[1] if v and v[0] == "Utf8" else None


def read_value(buf, pos, cp):
    tag = buf[pos]; pos += 1
    if tag == ord("s"):
        return ("s", cp.utf8(struct.unpack_from(">H", buf, pos)[0])), pos + 2
    if tag == ord("e"):
        tn, cn = struct.unpack_from(">HH", buf, pos); pos += 4
        return ("e", (cp.utf8(tn), cp.utf8(cn))), pos
    if tag == ord("["):
        cnt = struct.unpack_from(">H", buf, pos); pos += 2
        items = []
        for _ in range(cnt[0]):
            v, pos = read_value(buf, pos, cp)
            items.append(v)
        return ("[", items), pos
    if tag == ord("@"):
        a, pos = read_annotation(buf, pos, cp)
        return ("@", a), pos
    if tag in (ord("B"), ord("C"), ord("S"), ord("I"), ord("F"), ord("D"), ord("J"), ord("Z")):
        return ("const", struct.unpack_from(">H", buf, pos)[0]), pos + 2
    if tag == ord("c"):
        return ("class", cp.utf8(struct.unpack_from(">H", buf, pos)[0])), pos + 2
    raise ValueError("bad value tag %r" % tag)


def read_annotation(buf, pos, cp):
    ti = struct.unpack_from(">H", buf, pos)[0]; pos += 2
    npairs = struct.unpack_from(">H", buf, pos)[0]; pos += 2
    pairs = {}
    for _ in range(npairs):
        ni = struct.unpack_from(">H", buf, pos)[0]; pos += 2
        v, pos = read_value(buf, pos, cp)
        pairs[cp.utf8(ni)] = v
    return {"type": cp.utf8(ti), "pairs": pairs}, pos


def parse_class(data):
    cp = CP(data, 8)
    pos = cp.end
    pos += 6  # access, this, super
    ifc = struct.unpack_from(">H", data, pos)[0]; pos += 2 + 2 * ifc
    res = {}

    def skip_attrs(count):
        nonlocal pos
        for _ in range(count):
            nidx = struct.unpack_from(">H", data, pos)[0]
            ln = struct.unpack_from(">I", data, pos + 2)[0]
            name = cp.utf8(nidx)
            body = data[pos + 6: pos + 6 + ln]
            pos += 6 + ln
            yield name, body

    fields = struct.unpack_from(">H", data, pos)[0]; pos += 2
    for _ in range(fields):
        pos += 6
        ac = struct.unpack_from(">H", data, pos)[0]; pos += 2
        for _ in skip_attrs(ac):
            pass
    methods = struct.unpack_from(">H", data, pos)[0]; pos += 2
    members = []
    for _ in range(methods):
        access, ni, di = struct.unpack_from(">HHH", data, pos); pos += 6
        ac = struct.unpack_from(">H", data, pos)[0]; pos += 2
        anns = []
        for name, body in skip_attrs(ac):
            if name == "RuntimeVisibleAnnotations":
                anns.append(body)
        members.append({"member": cp.utf8(ni), "descriptor": cp.utf8(di),
                        "access": access, "ann_bodies": anns})
    class_ann_bodies = []
    cac = struct.unpack_from(">H", data, pos)[0]; pos += 2
    for name, body in skip_attrs(cac):
        if name == "RuntimeVisibleAnnotations":
            class_ann_bodies.append(body)

    def decode(body):
        out = []
        cnt = struct.unpack_from(">H", body, 0)[0]
        p = 2
        for _ in range(cnt):
            a, p = read_annotation(body, p, cp)
            out.append(a)
        return out

    def collect(target, bodies):
        for b in bodies:
            for a in decode(b):
                t = MAPPING_TYPES.get(a["type"])
                if not t:
                    continue
                paths = a["pairs"].get("path") or a["pairs"].get("value")
                pl = []
                if paths:
                    kind, val = paths
                    if kind == "[":
                        pl = [v[1] for v in val if v[0] == "s"]
                    elif kind == "s":
                        pl = [val]
                methods_ = a["pairs"].get("method")
                ml = []
                if methods_:
                    kind, val = methods_
                    if kind == "[":
                        ml = [v[1][1] for v in val if v[0] == "e"]
                    elif kind == "e":
                        ml = [val[1]]
                target.append({"annotation": t, "paths": pl,
                               "declared_methods": ml,
                               "effective_methods": ml or MAPPING_DEFAULT_METHOD[t],
                               "other_elements": sorted(k for k in a["pairs"] if k not in ("path", "value", "method"))})

    res["class_level"] = []
    res["members"] = []
    collect(res["class_level"], class_ann_bodies)
    for m in members:
        got = []
        collect(got, m["ann_bodies"])
        if got:
            res["members"].append({"member": m["member"], "descriptor": m["descriptor"],
                                   "access": m["access"], "mappings": got})
    res["pool_slash_strings"] = sorted({v[1] for v in cp.slots.values()
                                        if v and v[0] == "Utf8" and isinstance(v[1], str)
                                        and v[1] and v[1][0] == "/"})
    return res


jar_sha = hashlib.sha256(JAR.read_bytes()).hexdigest()
result = {"jar": JAR.name, "jar_path": str(JAR), "jar_sha256": jar_sha,
          "version": "5.3.517"}
z = zipfile.ZipFile(JAR)
names = z.namelist()
allcls = [n for n in names if n.endswith(".class")]
bearing = []
for n in allcls:
    data = z.read(n)
    if not any(d.encode() in data for d in MAPPING_TYPES):
        continue
    fq = n[:-6].replace("/", ".")
    p = parse_class(data)
    bearing.append({"class": fq, "entry": n,
                    "class_sha256": hashlib.sha256(data).hexdigest(),
                    "class_bytes": len(data),
                    "class_level": p["class_level"],
                    "members": p["members"],
                    "pool_slash_strings": p["pool_slash_strings"]})
result["class_entries"] = len(allcls)
result["top_level_classes"] = len([c for c in allcls if "$" not in c])
result["mapping_bearing"] = bearing
result["mapping_bearing_count"] = len(bearing)
OUT.write_text(json.dumps(result, ensure_ascii=False, indent=1), encoding="utf-8")
print("jar_sha256", jar_sha)
print("class_entries", result["class_entries"], "top_level", result["top_level_classes"])
print("mapping_bearing", len(bearing))
for b in bearing:
    cl = " | ".join("%s:%s" % (a["annotation"], ",".join(a["paths"])) for a in b["class_level"]) or "(no class-level)"
    print("  %-70s cls=[%s] members=%d" % (b["class"][:70], cl, len(b["members"])))
