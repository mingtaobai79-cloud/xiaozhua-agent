"""R2 步骤5: 对 runtime jar 全部 27 个 mapping-bearing 类做 javap -p -v 落盘 + provenance 五元组头。"""
import json, hashlib, pathlib, subprocess, sys, datetime, zipfile

JAR = pathlib.Path(r"D:\repo\CHIT\com\seeyon\udc-starter-runtime\5.3.517\udc-starter-runtime-5.3.517.jar")
JAVAP = r"C:\Program Files\Java\latest\jdk-21\bin\javap.exe"
OUTDIR = pathlib.Path(sys.argv[1])
SCRATCH = pathlib.Path(__file__).parent

raw = json.loads((SCRATCH / "r2_endpoints_raw.json").read_text(encoding="utf-8"))
jar_sha = raw["jar_sha256"]

z = zipfile.ZipFile(JAR)
entries = {}
for n in z.namelist():
    if n.endswith(".class"):
        entries[n[:-6].replace("/", ".")] = n

run_at = datetime.datetime.now(datetime.timezone.utc).isoformat()
manifest = []
ok = 0
for b in raw["mapping_bearing"]:
    fq = b["class"]
    entry = entries[fq]
    data = z.read(entry)
    cls_sha = hashlib.sha256(data).hexdigest()
    cmd = [JAVAP, "-J-Dstdout.encoding=UTF-8", "-p", "-v", "-cp", str(JAR).replace("\\", "/"), fq]
    p = subprocess.run(cmd, capture_output=True, text=True, encoding="utf-8")
    simple = fq.split(".")[-1]
    out = OUTDIR / ("r2-%s.javap.txt" % simple)
    header = (
        "# source_jar: %s\n# source_jar_path: %s\n# jar_sha256: %s\n"
        "# class_fqcn: %s\n# class_entry: %s\n# class_sha256: %s\n# class_bytes: %d\n"
        "# command: %s\n# exit_code: %d\n# run_at_utc: %s\n# evidence_level: VERIFIED_STATIC_BYTECODE\n%s\n"
    ) % (JAR.name, str(JAR), jar_sha, fq, entry, cls_sha, len(data),
         " ".join('"%s"' % c if " " in c else c for c in cmd), p.returncode, run_at, "#" + "-" * 60)
    out.write_text(header + p.stdout, encoding="utf-8")
    manifest.append({"class": fq, "simple": simple, "entry": entry, "class_sha256": cls_sha,
                     "class_bytes": len(data), "file": out.name, "exit_code": p.returncode,
                     "stdout_bytes": len(p.stdout)})
    if p.returncode == 0:
        ok += 1
    print("%-2d %-72s rc=%d sha=%s" % (ok, simple, p.returncode, cls_sha[:12]))

(OUTDIR / "r2_javap_manifest.json").write_text(
    json.dumps({"jar": JAR.name, "jar_sha256": jar_sha, "javap": JAVAP,
                "run_at_utc": run_at, "count": len(manifest), "ok": ok, "files": manifest},
               ensure_ascii=False, indent=1), encoding="utf-8")
print("dumped", ok, "/", len(manifest))
