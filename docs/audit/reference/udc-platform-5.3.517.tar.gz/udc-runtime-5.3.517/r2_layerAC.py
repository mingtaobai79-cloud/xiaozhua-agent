"""R2 三层扫描 L-A(类名层) + L-C(常量池全量层): udc-starter-runtime-5.3.517.jar。只读。"""
import zipfile, hashlib, struct, json, pathlib, sys

JAR = pathlib.Path(r"D:\repo\CHIT\com\seeyon\udc-starter-runtime\5.3.517\udc-starter-runtime-5.3.517.jar")
OUTDIR = pathlib.Path(sys.argv[1])

jar_sha = hashlib.sha256(JAR.read_bytes()).hexdigest()
z = zipfile.ZipFile(JAR)
names = z.namelist()
classes = [n for n in names if n.endswith(".class")]
tops = [c for c in classes if "$" not in c]


class CP:
    def __init__(self, buf):
        pos = 8
        n = struct.unpack_from(">H", buf, pos)[0]; pos += 2
        self.slots = {}
        i = 1
        while i < n:
            tag = buf[pos]; pos += 1
            if tag == 1:
                ln = struct.unpack_from(">H", buf, pos)[0]; pos += 2
                self.slots[i] = buf[pos:pos + ln].decode("utf-8", "replace"); pos += ln
            elif tag in (3, 4):
                pos += 4
            elif tag in (9, 10, 11, 12, 17, 18):
                pos += 4
            elif tag == 15:
                pos += 3
            elif tag in (7, 8, 16, 19, 20):
                pos += 2
            elif tag in (5, 6):
                pos += 8; i += 1
            else:
                raise ValueError("cp tag %d" % tag)
            i += 1


# L-A: 类名层
la = {"jar": JAR.name, "jar_sha256": jar_sha, "version": "5.3.517",
      "class_entries": len(classes), "top_level_classes": len(tops),
      "packages": {}, "udcrt_classes": [], "proxy_classes": []}
for c in tops:
    fq = c[:-6].replace("/", ".")
    pkg = ".".join(fq.split(".")[:-1])
    la["packages"][pkg] = la["packages"].get(pkg, 0) + 1
    if ".udcrt.controller." in fq:
        la["udcrt_classes"].append(fq)
    if ".udcrt.proxy.controller." in fq:
        la["proxy_classes"].append(fq)
(OUTDIR / "r2_layerA_classname_scan.json").write_text(
    json.dumps(la, ensure_ascii=False, indent=1), encoding="utf-8")

# L-C: 常量池全量层 —— 所有 class 的全部 Utf8，收集以 / 开头的字面量
lc = {"jar": JAR.name, "jar_sha256": jar_sha, "classes_scanned": 0,
      "utf8_total": 0, "slash_literals": {}}
for n in classes:
    data = z.read(n)
    cp = CP(data)
    lc["classes_scanned"] += 1
    for v in cp.slots.values():
        if not isinstance(v, str):
            continue
        lc["utf8_total"] += 1
        if v.startswith("/") or v.startswith("udc-runtime"):
            lc["slash_literals"].setdefault(v, []).append(n)
lc["distinct_slash_literals"] = len(lc["slash_literals"])
(OUTDIR / "r2_layerC_constantpool_scan.json").write_text(
    json.dumps(lc, ensure_ascii=False, indent=1), encoding="utf-8")

print("L-A class_entries", la["class_entries"], "top", la["top_level_classes"])
print("L-A udcrt.controller classes", len(la["udcrt_classes"]), "proxy.controller", len(la["proxy_classes"]))
print("L-A packages:", json.dumps(la["packages"], ensure_ascii=False))
print("L-C classes_scanned", lc["classes_scanned"], "utf8_total", lc["utf8_total"],
      "distinct_slash_literals", lc["distinct_slash_literals"])
hr = [k for k in lc["slash_literals"] if k.startswith("udc-runtime")]
print("L-C udc-runtime stems:", len(hr))
for k in sorted(lc["slash_literals"])[:200]:
    if k.startswith("/"):
        print("    ", k, "<-", len(lc["slash_literals"][k]), "cls")
