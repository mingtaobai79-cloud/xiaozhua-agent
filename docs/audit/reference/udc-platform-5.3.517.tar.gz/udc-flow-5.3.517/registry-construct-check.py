#!/usr/bin/env python3
"""R5 可构造性核验：registry-entries.md 每个 UdcOperationContract(...) 代码块
实例化 + 跑 .effective。只 import + 读文件，绝不写 registry.py/layer.py/tests/冻结件。"""
import sys, re

sys.path.insert(0, "D:/work/chit/seeyon-agent")
from components.platform_operations.models import UdcOperationContract, OperationStatus

MD = "D:/work/chit/seeyon-agent/docs/operation-contracts/udc/flow/registry-entries.md"

def main():
    text = open(MD, encoding="utf-8").read()
    blocks = re.findall(r"```python\n(.*?)```", text, re.DOTALL)
    # 正文/示意处 "UdcOperationContract(" 计数（非代码块内）
    total_mentions = text.count("UdcOperationContract(")
    in_code_mentions = sum(len(re.findall(r"UdcOperationContract\(", b)) for b in blocks)
    prose_mentions = total_mentions - in_code_mentions

    out = []
    p = out.append
    p("=== R5 registry-entries.md 可构造性核验 ===")
    p(f"models.py sys.path=D:/work/chit/seeyon-agent; import UdcOperationContract, OperationStatus: OK")
    p(f"总 'UdcOperationContract(' 提及 = {total_mentions}")
    p(f"  代码块内提及(可构造实例) = {in_code_mentions}  (只读 9 + 写 3)")
    p(f"  正文/示意提及(非代码块) = {prose_mentions}  (preamble 第4行签名示意, 非可构造, 显式区分)")
    p(f"```python 围栏数 = {len(blocks)}  (只读 9 各占1围栏 + 写侧 3 共用1围栏)")
    p("")

    instances = []
    for i, b in enumerate(blocks, 1):
        ns = {"UdcOperationContract": UdcOperationContract, "OperationStatus": OperationStatus,
              "contracts": {}}  # 代码块用 contracts[...]=... 赋值, 提供容器命名空间
        # 逐块 exec
        try:
            exec(compile(b, f"<block-{i}>", "exec"), ns)
        except Exception as e:
            p(f"[BLOCK {i}] CONSTRUCT=FAIL  {type(e).__name__}: {e}")
            continue
        new = [v for v in ns["contracts"].values() if isinstance(v, UdcOperationContract)]
        for op in new:
            instances.append(op)
            p(f"[BLOCK {i}] {op.operation_id}  construct=OK  method={op.method} write={op.write} "
              f"status={op.status.name} effective={op.effective}")

    p("")
    p("=== .effective 判定表 (门控: status in {PASS,VERIFIED_STATIC_BYTECODE,OBSERVED} 且 write=False 且 method==GET) ===")
    get_true = [o for o in instances if o.effective]
    post_read_false = [o for o in instances if not o.effective and o.method == "POST" and not o.write]
    write_false = [o for o in instances if o.write]
    p(f"GET 只读 -> effective=True   : {len(get_true)} 条  " + ", ".join(o.operation_id for o in get_true))
    p(f"POST 读型(write=False) -> effective=False : {len(post_read_false)} 条  " + ", ".join(o.operation_id for o in post_read_false))
    p(f"写型(write=True) -> effective=False        : {len(write_false)} 条  " + ", ".join(o.operation_id for o in write_false))
    p("")
    ok = (len(instances) == 12 and len(get_true) == 3 and len(post_read_false) == 6 and len(write_false) == 3
          and all(o.effective for o in get_true) and not any(o.effective for o in post_read_false + write_false))
    p(f"总判定: {12 if len(instances)==12 else len(instances)}/12 可构造块; "
      f"{'PASS' if ok else 'FAIL'}")
    print("\n".join(out))

if __name__ == "__main__":
    main()
