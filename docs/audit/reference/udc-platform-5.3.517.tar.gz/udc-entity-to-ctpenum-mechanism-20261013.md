# UDC 关联字段(ENTITY) → 枚举(CTPENUM) 切换机制 —— 字节码实证

取证时间: 2026-10-13
证据等级: VERIFIED_STATIC_BYTECODE (CFR 0.152 反编译本机 Artifactory 5.3.517 产物)

## 一、拉取的 artifact（Artifactory libs-release, 匿名, sha1 已核对）

| artifact | 版本 | bytes | local sha1 | remote sha1 match |
|---|---|---|---|---|
| udc-biz        | 5.3.517 | 6972862 | f9664736e5a88e9a6fe2893edfd917fbfd84dec3 | YES |
| udc-web        | 5.3.517 | 136930  | 944a22a97385e6f6ca4f3d5c80a32911b4738d9d | YES |
| udc-extend     | 5.3.517 | 271481  | 2cad3af2fe32c3f90d6403a36d83676974d27286 | YES |
| udc-plugin-api | 5.3.517 | 549912  | (未核对) | - |

来源: http://172.28.24.205/artifactory/libs-release/com/seeyon/<a>/5.3.517/<a>-5.3.517.jar
落盘: D:/repo/CHIT/com/seeyon/<a>/5.3.517/
备注: udc-starters 5.3.517 只有 pom（聚合模块，无 jar）；udc-assemble / udc-entity 在 libs-release 无 5.3.517 路径。

关键类承载位置（此前未知）:
- AutoCodeProperties → **udc-plugin-api** 的 com/seeyon/udc/common/autocode/config/
- DataTypeChangeUtil / TypeChangeSqlResolver / EntityTransportHandler → udc-biz

## 二、结论：ENTITY→CTPENUM 是「删列 + 加列」，存量数据丢失

### 1. 设计态闸门
`AttributeGroupService:556` → `AttributeDesignUtil.dataTypeChanged(old,new)`
```java
return !oldDto.getDataType().equals(attributeDto.getDataType())
    || !Objects.equals(oldDto.getMultiSelect(), attributeDto.getMultiSelect());
```
→ 类型或多选任一变化即触发 `DataTypeChangeUtil.changeDataType(now, old)`

### 2. 属性收敛（DataTypeChangeUtil）
ENTITY→CTPENUM 落在这支，`case "ENUM"/"ENTITY"/"CTPENUM"/"ATTACHMENT": break;` → **保留**
relationApp / relationEntity / relationCode / relationStarter / relationEntityName 全部保留，不置空（供前端传新 relationCode 覆盖）。
无条件清空 4 个表达式字段；defaultValue 除 INTEGER/DECIMAL/CURRENCY 外一律置 ""。
`!now.getMultiSelect().equals(old.getMultiSelect())` → **直接 return，属性完全不收敛**（源码注释：多选变化先不处理）。

### 3. 物理类型：BIGINT → BIGINT，类型码不变
| DataType | dbType | JDBC | JavaType | len | multi |
|---|---|---|---|---|---|
| EntityDataType  | -5 | BIGINT | Long | 50 | true |
| CtpEnumDataType | -5 | BIGINT | Long | 50 | true |
| EnumDataType(选项集) | 12 | VARCHAR | String | 50 | true |
| BigIntegerDataType | -5 | BIGINT | Long | 20 | false |

多选时两者 `getDatabaseDataType` 都返回 2011(NCLOB)，len 4000。
`getTypesCode(attr) = DataTypes.get(dataType).getTypeHelper().getDatabaseDataType(attr)` → 单选两侧都是 -5，**相等**。

⛔ 更正: 知识库《数据库规范.md》"自定义枚举（枚举组件）→ varchar" 对单选 CTPENUM **不成立**；varchar 是 EnumDataType（选项集）。

### 4. DDL 生成：走「不兼容修改」→ 删列+加列
`EntityTransportHandler`:
```java
// register4UpdateEntity:300  update 循环内
if (matchTypeChangeResolver(oldAttr, nowAttr, ctx) != null) { registrySql(...); continue; }
...
if (oldTypeCode != nowTypeCode) { dropOrRenameColumnBeforeAddColumn(...); continue; }  // 类型码相同，不走

// 唯一调用方:205 -> buildDDL:657
if (matchTypeChangeResolver(oldAttr, newAttr, ctx) != null
    || (old.dataType.equals(new.dataType) && multiSelect 相等)) continue;
dataTypeChangedAttributeMap.put(...);          // 类型变了 → 进这里
...
attributeAddDtoList.addAll(值);                 // 加入 add 列表
attributeDeleteDtoList.addAll(键);              // 加入 delete 列表
dataTypeChangedAttributeMap.keySet().forEach(update::remove);
```
`register4UpdateEntity`:
- delete 列表 → `mysql57DbCodeHandler.dropColumn(...)` （无条件，第 294-296 行）
- add 列表 → `mysql57DbCodeHandler.addColumn(...)` （第 366-374 行）
- **全程无任何数据搬运**（`UdcUpdateDataChange` 只被 `migrateColumnDate` 使用，此路径不调用）

### 5. 5 个 TypeChangeSqlResolver 全清单（无 ENTITY→CTPENUM）
```
Date2DateTimeSqlResolver                    DATE → DATETIME
Decimal2CurrencySqlResolver                 DECIMAL → CURRENCY
String2MultiLineStringSqlResolver           STRING → MULTILINESTRING
SingleAttachment2MultiAttachmentSqlResolver  单选附件 → 多选附件
MultiRelationType2MultiLineLongTextSqlResolver
    (ENTITY|CTPENUM|ATTACHMENT 多选) → MULTILINESTRING 且 len>=4000
```

### 6. enableDropColumn 默认 true → 列真删
`AutoCodeProperties`（@ConfigurationProperties(prefix="seeyon.autocode")）
```java
private Boolean enableDropColumn = true;
private Boolean createRollbackSql = true;
```
→ `dropOrRenameColumnBeforeAddColumn` 走 if 分支：DROP COLUMN + ADD COLUMN。
若被改成 false，同一方法走 else 分支：把旧列 rename 成 `backup_<yyyyMMddHHmmss><n>`（留备份，含数据），再 ADD COLUMN。
（但本路径不经过 dropOrRenameColumnBeforeAddColumn，而是 register4UpdateEntity 的 delete/add 列表 → **无条件 dropColumn**，
  备份分支不生效。）

### 7. 运行态：CTPENUM 的 relationEntity 被硬编码覆盖
`udc-starter-runtime` → `UdcEntityLogService:330`
```java
String relationEntity = attributeMeta.getRelationEntity();
if (DataType.CTPENUM.name().equals(dataType)) {
    relationEntity = "com.seeyon.boot.starter.enums.domain.entity.CtpEnumItem";
}
```
设计态 `CtpEnumDataType.check()` 只要求 relationEntity 非空（不校验内容）；
`EntityDataType.check()` 额外要求 relationType 非空非 NONE 且 relationApp+relationEntity 非空。

### 8. 能力开关差异（静默合规风险）
CtpEnumDataType 覆写：index/unique/fullSearch/log/supportCustom = true
                     sensitive/encryption/lengthRange/maxAndMin/decimalDigits/pattern = false
EntityDataType 支持 sensitive + encryption → 切换后字段级脱敏/加密配置失效。

### 9. 无存量校验
`EntityErrorCode` 无「类型变更校验存量数据」错误码；仅 ENTITY_0027 MULTISELECT_OUT_OF_RANGE /
ENTITY_0028 INVALID_MULTI_SELECT_FORMAT（运行时取值校验）。

### 10. 类型转换器白名单（22 个 @TypeMapping，无 ENTITY↔CTPENUM）
仅 StringToLong 涉及 CTPENUM：`@TypeMapping(source={STRING}, target={BIGINTEGER, CTPENUM}, isFormulaResult=true)`
→ 是公式求值结果类型，非字段类型迁移。

## 三、落地影响
1. 物理类型不变、类型码相同 → 除非 buildDDL 的 dataTypeChanged 分支，不会有 DDL 动作。
2. 该分支存在 → **DROP COLUMN + ADD COLUMN，列内数据清零，无迁移 SQL**。
3. 构建若生成 rollback SQL（createRollbackSql=true），需人工确认其是否含数据恢复（预期不含）。
4. 必须：先在测试应用验证构建产物 DDL/回滚 SQL，再决定是否在生产执行；生产前必须备份该列数据。
5. 刷数桥：目标配置表里若自带「已是同一枚举项 id」的列，可 JOIN 推出 UPDATE 语句。

## 四、未验证项
- UNVERIFIED: 实际构建产物中 rollback SQL 的具体内容（需在测试应用跑一次构建抓 liquibase changeset）
- UNVERIFIED: 同一字段在 udc_app_version / udc_last_version_metadata 快照里的一致性处理
- UNVERIFIED: 多选切换（multiSelect 变化）路径的完整行为（DataTypeChangeUtil 提前 return）
- UNVERIFIED: enableDropColumn 在客户环境 nacos 的实际取值（本地只有代码默认值，无环境配置快照）
