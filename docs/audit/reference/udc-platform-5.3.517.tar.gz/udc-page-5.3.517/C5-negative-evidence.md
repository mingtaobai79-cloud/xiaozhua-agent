# C5 负证据 — UdcBaseGeneralController base 段继承链全库检索

产出: implementer（R3, human 第 4 次指令: NEEDS_HUMAN 未回复则继续可离线部分）
证据等级: VERIFIED_STATIC_BYTECODE（定向 jar tf + javap -p/-v，全离线）
关联契约: udc.page_general.get_cascade_default_value（C5，page-readonly-contracts.md / registry-entries.md 条目 5）

## 1. 检索目标与背景

C5（`UdcBaseGeneralController#getCascadeDefaultValue`，@GET，method value=`{entityAppName}/{entityName}/{controlId}/get-cascade-default-value`，方法注解为 FACT）的完整路径 = 类级 base + method value。
`UdcBaseGeneralController` 自身无类级 @RequestMapping（javap -v 验证：attributes: 1，仅 RestApi 注解，class_sha256=19c40f0353d2346bd0e5c374e8e7a79b9268b739f18cc1049435c12b37e664c8），继承链为:
`UdcBaseGeneralController → BaseComponentController → BaseController`
完整 base 路径字面值需解析 `com.seeyon.boot.starter.web.BaseComponentController`（本地 5.3.517 全部 112 模块无此类，R2 记录）。

## 2. 全库扫描（main 前置事实，本刀定向复核照用）

- 扫描范围: `D:/repo/CHIT/com/seeyon/` 全版本、全模块（含 boot*、peixun*、customer* 等），共 **537 个 jar**。
- 扫描命令（javap 必须原生 D:/repo/... 路径；jar/javap = D:/software/java/bin JDK21）:
  对每个 jar: `jar tf <jar> | grep 'com/seeyon/boot/starter/web/BaseComponentController.class'`
- 命中: **仅 3 个相邻旧版本**，均在 `boot-starter-web` 模块:

| 命中 jar | 版本单元 | 类命中 | 类级 @RequestMapping |
|---|---|---|---|
| D:/repo/CHIT/com/seeyon/boot-starter-web/5.3.345/boot-starter-web-5.3.345.jar | 5.3.345 | com/seeyon/boot/starter/web/BaseComponentController.class | **无**（类级注解 0 个，javap -v 全文 RequestMapping 命中 0） |
| D:/repo/CHIT/com/seeyon/boot-starter-web/5.3.349/boot-starter-web-5.3.349.jar | 5.3.349 | 同上 | 同上 |
| D:/repo/CHIT/com/seeyon/boot-starter-web/5.3.358/boot-starter-web-5.3.358.jar | 5.3.358 | 同上 | 同上 |

- 5.3.517 单元（112 模块任一 jar）: **BaseComponentController.class 0 命中**。

## 3. 父类结构 javap 证据行（本刀自验，逐字摘录）

命令（以 5.3.345 为例，349/358 结果一致）:
`javap -p -cp D:/repo/CHIT/com/seeyon/boot-starter-web/5.3.345/boot-starter-web-5.3.345.jar com.seeyon.boot.starter.web.BaseComponentController`

```
public class com.seeyon.boot.starter.web.BaseComponentController extends com.seeyon.boot.starter.web.BaseController
```

`javap -v` 该类: class-level `RuntimeVisibleAnnotations` 段落**不存在**（0 注解）；全文 `RequestMapping` 命中计数 = 0。
同 jar 内父类:
`public abstract class com.seeyon.boot.starter.web.BaseController`（javap -v RequestMapping 命中 = 0）→ **继承链上无任何类级 base 路径字面值可提取**。

→ 结论: 即使 3 个旧版本存在该类，其结构（extends 抽象 BaseController、无类级 @RequestMapping）也**不含可 FACT 化的 base 路径字面值**，且 3 版本与 5.3.517 分属不同证据单元（见 §4 红线），不能把旧版本类结构写成 5.3.517 的 FACT。

## 4. 显式红线声明（版本单元纪律）

- 5.3.345 / 5.3.349 / 5.3.358 属**相邻旧版本证据单元**；5.3.517 为本地 Maven 证据单元。两单元**禁止混写**（全局硬约束: 本地 5.3.517 vs 测试环境 镜像 5.3.496 即为两个证据单元，同理旧版本亦然）。
- 本文件的旧版本类信息仅作**负证据支撑**（证明"该父类在任何可用构件中均无类级 base 字面值"），**不作为 5.3.517 的 FACT 引用**。
- C5 base 段维持 **UNRESOLVED-in-5.3.517**（等价于 HYPOTHESIS 级，不可升级 FACT）: 5.3.517 无 BaseComponentController 构件，完整 base 路径在本地离线环境**不可解析**；需 LIVE（或取得含 5.3.517 版 BaseComponentController 的构件）方可确证。
- 因此 C5 条目状态维持 `OperationStatus.UNKNOWN`、全条降级的处理不变；UDC-MERGE 若只收 FACT 条目，C5 整条丢弃（前 4 条 FACT 自成闭环）。

## 5. 判定

**完备负证据**成立: 全库 537 jar 中 BaseComponentController 仅 3 个旧版本命中、且均无类级 @RequestMapping（继承链 0 字面值）；5.3.517 单元 0 命中。C5 base 段 = UNRESOLVED-in-5.3.517，本轮不可离线升级，负证据已完备存档。
