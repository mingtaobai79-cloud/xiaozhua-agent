# R7 — uv run 回归验证 R6 产物（权威 uv venv）

产出: implementer（R7, human REGRESSION 修复后权威环境回归）
证据等级: VERIFIED_STATIC_BYTECODE + 运行时回归确认
关联: R6 config 化产物（_config_loader.py + registry.py 行 47 local_javap）

## 背景

REGRESSION 根因: `_config_loader.py` 依赖 pyyaml，但 pyproject.toml 原无该依赖 → 权威
uv venv 执行时 `import yaml` 报 ModuleNotFoundError。human 已修 pyproject 加
`dependencies=["pyyaml>=6.0"]` + uv.lock 同步（全仓 318 passed 确认）。

本刀用 `uv run` 姿势（依赖自动同步，不手改 pyproject/uv.lock）确认本域 registry 切片
在权威 venv 回归可用。

## 命令

```bash
cd D:/work/chit/seeyon-agent && uv run python "D:/software/多agent协助/agent-collaboration/session-20260917-215531-af9a0451/scratch/r7_uvrun_regression.py"
```

（`uv run` 自动同步 .venv 到 pyproject 声明的 pyyaml≥6.0，无需手改 lock）

## 完整 stdout

```
=== ① import components.platform_operations.registry (无 ModuleNotFoundError) ===
registry import OK

=== ② source_jar_ref 组装 ===
got   = jar:file:///D:/repo/CHIT/com/seeyon/udc-starter-runtime/5.3.517/udc-starter-runtime-5.3.517.jar
expect= jar:file:///D:/repo/CHIT/com/seeyon/udc-starter-runtime/5.3.517/udc-starter-runtime-5.3.517.jar
MATCH

=== ③ default() total ===
total = 31 (expect 31)

=== ④ 4 本域 has() ===
True udc.page_log.search
True udc.page_log.search_non_metadata
True udc.page_info.check_exists
True udc.page_info.select_host_and_only_page

=== ⑤ 条目 5 (C5) 已丢弃 has()=False ===
False udc.page_general.get_cascade_default_value
```

EXIT=0

## 结论: **PASS**

| 判据 | 结果 |
|---|---|
| ① `import components.platform_operations.registry` 成功（无 ModuleNotFoundError） | PASS |
| ② `source_jar_ref("udc-starter-runtime","5.3.517")` 组装 = 原 jar:file 绝对路径 | MATCH |
| ③ `UdcOperationRegistry.default()` total = 31 | PASS |
| ④ 4 本域 `has()` 全 True | PASS |
| ⑤ 条目 5 (C5) `has()` = False（已丢弃） | PASS |

## registry.py sha 前后一致（本刀零写）

pre = post = `332299c56e79c9de7e8094a260fa1cadf3127b0f7fefb0f31a5d056d953ca6de`

## 红线合规

- 禁改 pyproject.toml / uv.lock: 0 改动（`uv run` 自动同步不改文件）。
- 禁改 registry.py / _config_loader.py: 0 改动（sha 前后一致）。
- 冻结件 layer.py/seeyon_cli.py/README/两 audit/tests: 0 改动。
- 不跑全量 318: 本刀仅本域 registry 切片（防范围扩大/防爆窗）。
- 无 LIVE。
