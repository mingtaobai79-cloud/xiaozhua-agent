# registry-entries.md MERGE dry-run 证据（R4）

产出: implementer（R4, human 第 6 次指令: NEEDS_HUMAN 未回复→继续可离线部分；纯本域 2 文件 + scratch 脚本，不碰冻结件）。
目的: 补证三件套件 3「MERGE 任务照抄」——验证 `docs/operation-contracts/udc/page/registry-entries.md` 的 5 条 `UdcOperationContract(...)` 调用**逐字照抄可实例化、可构造 UdcOperationRegistry、与既有 default() 无 operation_id 冲突**。只读 import 仓库模块（`sys.path.insert` 仓库根），全程未写仓库任何文件；registry.py 仅读 + sha256 前后自证零改动。

## 1. 执行脚本

脚本: `D:\software\多agent协助\agent-collaboration\session-20260917-215531-af9a0451\scratch\merge_dryrun.py`（会话根 scratch，非仓库文件）。
命令（Windows，`python` = 3.11.9，非 python3；本机无 python3）:

```
cd D:/work/chit/seeyon-agent
python "D:/software/多agent协助/agent-collaboration/session-20260917-215531-af9a0451/scratch/merge_dryrun.py"
```

脚本 5 步:
1. 逐字 exec registry-entries.md 条目 1-5 的 `UdcOperationContract(...)` 调用（4 FACT + C5），验证语法可解析 + 形参匹配 models.py 真实 dataclass（10 位位置参数: operation_id, method, path, request_type, response_type, status, write, evidence, required_inputs, verification_rules）。
2. `UdcOperationRegistry(dict)` 构造成功 + `has()` 抽验。
3. 与 `UdcOperationRegistry.default()` 既有 operation_id 集合做冲突检查。
4. 逐条打印 `effective()` 门控结果（事实标注，不代决 MERGE 取舍）。
5. registry.py sha256 前后自证零改动。

依赖 import（只读）: `from components.platform_operations.models import UdcOperationContract, OperationStatus` + `from components.platform_operations.registry import UdcOperationRegistry`。

## 2. 完整 stdout（逐字落盘，EXIT=0）

```
=== STEP 1: instantiate 5 entries verbatim ===
OK instantiate udc.page_log.search (method=POST, status=OperationStatus.VERIFIED_STATIC_BYTECODE, write=False, inputs=('query',))
OK instantiate udc.page_log.search_non_metadata (method=POST, status=OperationStatus.VERIFIED_STATIC_BYTECODE, write=False, inputs=('query',))
OK instantiate udc.page_info.check_exists (method=POST, status=OperationStatus.VERIFIED_STATIC_BYTECODE, write=False, inputs=('pageExistsDtoList',))
OK instantiate udc.page_info.select_host_and_only_page (method=POST, status=OperationStatus.VERIFIED_STATIC_BYTECODE, write=False, inputs=('request',))
OK instantiate udc.page_general.get_cascade_default_value (method=GET, status=OperationStatus.UNKNOWN, write=False, inputs=('entityAppName', 'entityName', 'controlId'))
=== STEP 2: UdcOperationRegistry(dict) construction ===
OK registry constructed, 5 entries; has() spot-check udc.page_log.search=True
=== STEP 3: conflict check vs UdcOperationRegistry.default() ===
existing default() operation_ids: udc.application.get, udc.applog.select_by_id, udc.attribute.list, udc.datatype.get_all, udc.entity.all.by_app, udc.entity.all.by_entity, udc.entity.attribute.all_by_entity, udc.entity.attribute.by_primary, udc.entity.attribute.create, udc.entity.attribute.create_batch, udc.entity.attribute.delete, udc.entity.attribute.search, udc.entity.attribute.search.term, udc.entity.attribute.select, udc.entity.attribute.update, udc.entity.attributes.list, udc.entity.create, udc.entity.get, udc.entity.list, udc.entity.primary.by_app, udc.entity.root_id, udc.entity.search, udc.entity.search.term, udc.entity.select, udc.entity.tree.by_app, udc.entity.update, udc.microflow.function_node_tree
OK no conflict: 5 new ids disjoint from 27 existing ids
=== STEP 4: effective() gate fact (annotation only) ===
udc.page_log.search: method=POST status=OperationStatus.VERIFIED_STATIC_BYTECODE write=False -> effective()=False
udc.page_log.search_non_metadata: method=POST status=OperationStatus.VERIFIED_STATIC_BYTECODE write=False -> effective()=False
udc.page_info.check_exists: method=POST status=OperationStatus.VERIFIED_STATIC_BYTECODE write=False -> effective()=False
udc.page_info.select_host_and_only_page: method=POST status=OperationStatus.VERIFIED_STATIC_BYTECODE write=False -> effective()=False
udc.page_general.get_cascade_default_value: method=GET status=OperationStatus.UNKNOWN write=False -> effective()=False
=== STEP 5: registry.py sha256 (read-only, self-certify zero mutation) ===
pre =e9a195b2b2a75689cd9d9d812445011b32797c3a8dc15766a9c482aec016a43e
post=e9a195b2b2a75689cd9d9d812445011b32797c3a8dc15766a9c482aec016a43e
registry.py unchanged: True
=== OVERALL: PASS ===
EXIT=0
```

## 3. 结论

- **overall = PASS**: 5 条 `UdcOperationContract(...)` 逐字照抄全部可实例化（语法可解析、形参匹配 models.py dataclass、`OperationStatus` 值合法）、可入 `UdcOperationRegistry(dict)`、与既有 `default()` 的 27 个 operation_id **零冲突**。registry.py sha256 前后一致 → 零改动自证。
- 逐条: C1a/C1b/C2a/C2b（4 FACT, VERIFIED_STATIC_BYTECODE）OK；C5（UNKNOWN，base UNRESOLVED）OK 可构造（UNKNOWN 是合法枚举值，不影响构造）。
- **【effective() 门控事实标注 —— MERGE 业务取舍点，本任务只标注不代决】**: `UdcOperationContract.effective()` 判据 = `status ∈ {PASS, VERIFIED_STATIC_BYTECODE, OBSERVED} AND NOT write AND method.upper()=="GET"`（models.py:47-50）。本域 4 条读契约 method=POST（@PostMapping 注解字面值，禁改）→ **4 条 effective()=False**；C5 虽 method=GET 但 status=UNKNOWN → effective() 亦 False。**若 UDC-MERGE 按 `effective()` 过滤条目，本域 5 条全部被排除**（非仅 4 条——C5 的 GET 也不足以使其 effective，因 status 非三合法值之一）。MERGE 任务须决策: 调整 effective 门控 / 另立"只读契约就绪"判据 / 保留为参考条目不生效。本会话越权不判。
- 冲突检查实测既有 default() 全集 27 id（比 main 前置列举更多，main 列了代表性前缀；本域 5 id 全部 disjoint，无任一命中）。

## 4. 版本单元 / 冻结件纪律

- 只读 import 仓库 `models.py`/`registry.py`（sys.path 插入），**未写仓库任何文件**；registry.py 前后 sha256 一致（e9a195b2…）。
- 本刀产出仅: 本证据文件（本域 artifacts/）+ registry-entries.md 追加「MERGE 集成注记」节（本域，非冻结）+ 会话根 scratch/merge_dryrun.py（会话根，非仓库）。冻结件（registry.py/layer.py/seeyon_cli.py/tests/两 audit 文档/README）零改动。
- C5 base 段维持 UNRESOLVED-in-5.3.517（负证据见同目录 C5-negative-evidence.md），dry-run 中 C5 仅验证可构造，未升级任何 FACT。
