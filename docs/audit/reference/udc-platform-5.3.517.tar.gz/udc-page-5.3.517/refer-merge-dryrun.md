# refer 3 条 MERGE dry-run（R9, 2026-09-18, human 134117 催办→可离线部分）

产出: implementer（R9, 只读零写仓库，不碰 registry.py/pyproject/uv.lock/冻结件；实际落库等 human 授权 refer 落库 + effective() 门控取舍）。
目的: 补证三件套件 3 的 refer forward 候选（registry-entries.md 条目 6/7/8）「MERGE 任务可直接照抄」就绪态——逐字实例化 + 可构造 + 与既有 default() zero-conflict + effective() 事实呈现。
证据等级: VERIFIED_STATIC_BYTECODE + dry-run 运行时确认（uv run, 只读 import）。

## 前置事实（main 已核，照用）
- refer_evidence dict（registry-entries.md 行 90）: class=`com.seeyon.boot.starter.udcrt.proxy.controller.UdcReferController`, method=`selectTree`, class_sha256=`912383403dcd0e9e445225308b82a117850fbc98494e54243b6f2d454bf09664`, javap=`docs/audit/artifacts/udc-page-5.3.517/UdcReferController.javap.txt`, negative_evidence=`C5-negative-evidence.md`。
- 3 条逐字源 = registry-entries.md 条目 6/7/8（行 91/100/110），source=`本地maven构件5.3.517`（evidence dict `source` 字段=`local-maven-53517`），base=`UNRESOLVED-in-5.3.517`。

## 命令（uv run，权威 venv，依赖自动同步）

```bash
cd D:/work/chit/seeyon-agent && uv run python "D:/software/多agent协助/agent-collaboration/session-20260917-215531-af9a0451/scratch/r9_refer_merge_dryrun.py"
```

脚本全文（scratch/r9_refer_merge_dryrun.py, 6422B，复用 R4 merge_dryrun.py 模式 + refer 3 条逐字源 + 5 步自检）见下方引用。核心：`sys.path.insert(0, REPO)` → `from components.platform_operations.models import UdcOperationContract, OperationStatus` + `from components.platform_operations.registry import UdcOperationRegistry` → 逐字 exec refer 3 条（refer_evidence dict + 3 条 contracts[oid]=UdcOperationContract(...)）→ STEP1 实例化 / STEP2 构造 registry / STEP3 zero-conflict vs default() / STEP4 effective() 事实表 / STEP5 registry.py sha 前后。

## 完整 stdout（UV_EXIT=0）

```
=== STEP 1: instantiate 3 refer entries verbatim ===
OK instantiate udc.page_refer.select_tree (method=POST, status=OperationStatus.VERIFIED_STATIC_BYTECODE, write=False, inputs=('entityAppName', 'entityName', 'referGuid', 'treeQueryDto'))
OK instantiate udc.page_refer.select_by_id (method=GET, status=OperationStatus.VERIFIED_STATIC_BYTECODE, write=False, inputs=('entityAppName', 'entityName', 'referGuid', 'objectId'))
OK instantiate udc.page_refer.search_list_by_conditions (method=POST, status=OperationStatus.VERIFIED_STATIC_BYTECODE, write=False, inputs=('listRequest',))
=== STEP 2: UdcOperationRegistry(dict) construction ===
OK registry constructed, 3 entries; spot-check has(select_by_id)=True
=== STEP 3: zero-conflict check vs UdcOperationRegistry.default() ===
existing default() total = 32 ids; grep udc.page_refer = 0
OK zero-conflict: 3 new refer ids disjoint from 32 existing ids
=== STEP 4: effective() gate fact table (annotation only, no decision) ===
udc.page_refer.select_tree: method=POST status=OperationStatus.VERIFIED_STATIC_BYTECODE write=False -> effective()=False
udc.page_refer.select_by_id: method=GET status=OperationStatus.VERIFIED_STATIC_BYTECODE write=False -> effective()=True
udc.page_refer.search_list_by_conditions: method=POST status=OperationStatus.VERIFIED_STATIC_BYTECODE write=False -> effective()=False
=== STEP 5: registry.py sha256 (read-only, self-certify zero mutation) ===
pre =6b630df0bc52eca8d3efebb16c18c65c61e7cf482cc5036bfaeeaa1d5090de52
post=6b630df0bc52eca8d3efebb16c18c65c61e7cf482cc5036bfaeeaa1d5090de52
registry.py unchanged by this dry-run: True
=== OVERALL: PASS ===
```

EXIT=0（OVERALL PASS）

## zero-conflict 结果

- 既有 `default()` 现有 **32 个 operation_id**（R8 时代 total=31，本次多 1 条 `udc.metadata.page_tree`=他会话对共享 registry.py 的改动，非本任务产物，本刀不认领）。
- `grep udc.page_refer` 命中 = 0 → 3 条 refer 新 id（select_tree / select_by_id / search_list_by_conditions）**与既有 32 id 零冲突**（dry-run STEP3 实测 disjoint）。

## 3 条逐字实例化（registry-entries.md 条目 6/7/8 逐字段照抄，本刀零改文档）

| 条目 | operation_id | method | status | write | inputs |
|---|---|---|---|---|---|
| 6 | udc.page_refer.select_tree | POST | VERIFIED_STATIC_BYTECODE | False | (entityAppName, entityName, referGuid, treeQueryDto) |
| 7 | udc.page_refer.select_by_id | GET | VERIFIED_STATIC_BYTECODE | False | (entityAppName, entityName, referGuid, objectId) |
| 8 | udc.page_refer.search_list_by_conditions | POST | VERIFIED_STATIC_BYTECODE | False | (listRequest,) |

三条 path 段 = `<BASE-UNRESOLVED-in-5.3.517>/{entityAppName}/{entityName}/{referGuid}/{select-tree|objectId|search-list-by-conditions}`（base 段 UNRESOLVED-in-5.3.517，同 C5，负证据 C5-negative-evidence.md）。

## effective() 门控事实表（只呈现，不代决）

`UdcOperationContract.effective()`（models.py 判据）= `status ∈ {PASS, VERIFIED_STATIC_BYTECODE, OBSERVED} AND NOT write AND method.upper()=="GET"`。

| 条目 | method | status | write | effective() |
|---|---|---|---|---|
| 6 select_tree | POST | VERIFIED_STATIC_BYTECODE | False | **False** |
| 7 select_by_id | GET | VERIFIED_STATIC_BYTECODE | False | **True** |
| 8 search_list_by_conditions | POST | VERIFIED_STATIC_BYTECODE | False | **False** |

**门控取舍说明（本刀不代决）**：现行门控下 refer 3 条中仅 C7（select_by_id, @GET）= effective()=True；C6/C8（@POST 注解字面值禁改）= False。refer 3 条是否落 registry.py、以及若按 effective() 过滤会排除 2/3 条的取舍，均为 human 授权项（refer 落库授权 + effective() 门控取舍），**本 dry-run 只呈现事实、不写 registry.py、不代决**。实际落库须 human 授权解冻 + LIVE 解析 BaseComponentController 基址（UNRESOLVED-in-5.3.517 → 落地后 3 条方可全 FACT）。

## registry.py sha 前后自证零改动

- pre = post = `6b630df0bc52eca8d3efebb16c18c65c61e7cf482cc5036bfaeeaa1d5090de52`（本刀 dry-run 零写，只读 import + 只读 sha）。
- **漂移标注（非本刀触碰，供 main 对账）**：本刀开跑前 registry.py sha 已为 `6b630df0…`，而非 R8 时代的 `332299c5…`。差异来源 = 他会话向 `default()` 新增 `udc.metadata.page_tree`（total 31→32）。R9 的 zero-conflict 与 self-certify 均跑在**当前**（含该条）的 default() 上，安全性（`grep udc.page_refer`=0）不受影响；本刀未写 registry.py。

## 结论: **PASS**

refer 3 条（registry-entries.md 条目 6/7/8）已达「MERGE 任务可直接照抄」就绪态：逐字可实例化（语法 + 10 位形参匹配 models.py dataclass + OperationStatus.VERIFIED_STATIC_BYTECODE 合法）+ UdcOperationRegistry(dict) 可构造 + 与既有 32 operation_id 零冲突 + effective() 事实表落档 + registry.py 本刀零写。等 human 授权 refer 落库 + effective() 门控取舍后即可照抄入册。本轮无 LIVE（token 过期，独立缺口，非本刀）。
