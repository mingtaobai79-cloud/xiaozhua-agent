# M3 跨域同端点重叠矩阵 + 去重候选（R12, 2026-09-18）

产出: implementer（R12, human 19:52 催办→继续可离线部分；只读零写 registry.py，仅本域 1 新证据文件）。
目的: 把 meta-data 域与 page 域对**同一对物理端点**各登一份契约的跨域重叠，物化为 2 端点 × 4 条目矩阵 + 逐字段 diff + 去重候选标注。去重**取舍归 human 裁定**（本刀只标候选、不代决、不删改 registry.py 任何条目）。
证据等级: VERIFIED_STATIC_BYTECODE（registry.py 逐字 grep 实测，离线只读，未做 LIVE）。

## 基线锚定（本刀开跑前 registry.py 逐字 grep 实测，与 main 19:5x 一致，未漂移）
- registry.py sha256 = `37caf4d28b49a1963310c22c822e04e8deb57a3ff7565fdc89edd9bec6413856`（前缀 37caf4d2，**本刀构建时点值，历史记录**）。
- udc.* 条目总数 = 16（构建时点）；本任务 page 域 1-4 逐字完好；refer grep `udc.page_refer` = 0；M3 端点 check-page-exists = 2 / select-host-and-only-page-pages = 2。
- 4 条重叠条目逐字定位（grep -n 实测）: [A] 行57 / [B] 行62 / [C] 行58 / [D] 行60；evidence dict [A/C]=行54 `page_info_evidence`，[B]=行61 `metadata_page_exists_evidence`，[D]=行59 `metadata_anchor_evidence`。

> **基线重锚（后续轮次追加，不新增独立节）**: 主线 b8b5ac83 纯加法推进至活体 `registry.py` = **`aaaa2cfaa191c548…`**（`udc.*` 条目 16→**29**，本任务不涉及其新增域）。重锚核验：① 4 条重叠条目位置**未位移**（仍 [A]行57/[B]行62/[C]行58/[D]行60）；② 本任务 1-4 行 55-58 **4/4 VERBATIM-OK** 对活体 aaaa2cfa；③ 对活体全部 29 条 `udc.*` 端点做 path 去重，**跨域同端点仍仅 2 端点**（check-page-exists / select-host-and-only-page-pages 各 2 命中），主线新增 13 条未产生**新**同端点跨域重叠 → 本矩阵覆盖的 M3 重叠面**不变、无新增**；④ refer grep `udc.page_refer` 活体仍 = 0。结论：本矩阵 2×4 + diff + 去重候选在活体 aaaa2cfa 基线下**仍成立**，无需重开 R12；去重取舍仍留 human。

## ① 2 端点 × 4 条目重叠矩阵

### 端点 1：`udc-runtime/meta-data/check-page-exists`（POST, 返回 `ListResponse<Boolean>`, VERIFIED_STATIC_BYTECODE, write=False）

| 列 | [A] page 域本任务 | [B] metadata 域主线 C5 |
|---|---|---|
| operation_id | `udc.page_info.check_exists`（行57） | `udc.metadata.page_exists_check`（行62） |
| method | POST | POST（同） |
| path（物理端点） | `udc-runtime/meta-data/check-page-exists` | `udc-runtime/meta-data/check-page-exists`（**同**） |
| 返回 DTO | `ListResponse<Boolean>` | `ListResponse<Boolean>`（**同**） |
| status | VERIFIED_STATIC_BYTECODE | VERIFIED_STATIC_BYTECODE（**同**） |
| write | False | False（**同**） |
| request_type | `List<UdcRtPageExistsDto>(RequestBody, 参数名 pageExistsDtoList)` | `List<UdcRtPageExistsDto>(RequestBody)`（B 无参数名注释） |
| inputs（required_inputs） | `("pageExistsDtoList",)`（参数名） | `("UdcRtPageExistsDto",)`（类型名） |
| evidence dict | `page_info_evidence`（行54；javap=`docs/audit/artifacts/udc-page-5.3.517/UdcRtPageInfoController.javap.txt`，无 note 字段） | `metadata_page_exists_evidence`（行61；javap=`docs/audit/artifacts/udc-entity-5.3.517/UdcRtPageInfoController.javap.txt`，**多 note 字段**） |
| class/method/class_sha256（evidence 身份） | `UdcRtPageInfoController` / `checkPageExistsByConditions` / `76787348…` | 同（**逐字一致**） |
| verification_rules 条数 | 3 条 | 4 条 |
| verification_rules 关键差异 | ①同一条件列表 identity_matches ②存在恒true/不存在恒false ③网关前缀 UNVERIFIED | ①存在性探测面（Boolean 列表逐条对应） ②**按 08:45 规则② Boolean/HTTP200 不作 identity 锚点，本契约非验收 identity 面** ③**POST 执行层不放行（与 C4 同边界），运行态需确证只读探测，放行前维持 POLICY_DENIED** ④网关前缀 UNVERIFIED |

### 端点 2：`udc-runtime/meta-data/select-host-and-only-page-pages`（POST, 返回 `ListResponse<UdcMainPageMetadataDto>`, VERIFIED_STATIC_BYTECODE, write=False）

| 列 | [C] page 域本任务 | [D] metadata 域主线 C4 |
|---|---|---|
| operation_id | `udc.page_info.select_host_and_only_page`（行58） | `udc.metadata.page_tree`（行60） |
| method | POST | POST（同） |
| path（物理端点） | `udc-runtime/meta-data/select-host-and-only-page-pages` | 同（**同**） |
| 返回 DTO | `ListResponse<UdcMainPageMetadataDto>` | 同（**同**） |
| status | VERIFIED_STATIC_BYTECODE | 同（**同**） |
| write | False | False（**同**） |
| request_type | `UdcPagesMetaDataSearchDto(RequestBody, 参数名 request)` | `UdcPagesMetaDataSearchDto(RequestBody)`（D 无参数名注释） |
| inputs（required_inputs） | `("request",)`（参数名） | `("UdcPagesMetaDataSearchDto",)`（类型名） |
| evidence dict | `page_info_evidence`（行54；javap=`docs/audit/artifacts/udc-page-5.3.517/UdcRtPageInfoController.javap.txt`，无 note 字段） | `metadata_anchor_evidence`（行59；javap=`docs/audit/artifacts/udc-entity-5.3.517/UdcRtPageInfoController.javap.txt`，**多 note 字段**） |
| class/method/class_sha256（evidence 身份） | `UdcRtPageInfoController` / `selectHostAppAndOnlyPageAppPages` / `76787348…` | 同（**逐字一致**） |
| verification_rules 条数 | 3 条 | 4 条 |
| verification_rules 关键差异 | ①同一 UdcPagesMetaDataSearchDto identity_matches ②响应非空 UdcMainPageMetadataDto 列表 ③网关前缀 UNVERIFIED | ①回读该应用页面树元数据 identity_matches（**同一 target 双读 strip(traceId) 一致**） ②响应非空 UdcMainPageMetadataDto 列表 ③**运行态需确证该 POST 端点为只读读面（不强行升 GET；执行层放行前维持 POLICY_DENIED）** ④网关前缀 UNVERIFIED |

## ② 逐字段 diff（A vs B、C vs D）

**相同字段（物理等价，不可区分同源）**：method（均 POST）/ 物理端点 path / 返回 DTO / status（均 VERIFIED_STATIC_BYTECODE）/ write（均 False）/ evidence 三元组身份（class=`UdcRtPageInfoController` + 各方法 + class_sha256=`7678734875e3c96aa463bd94084061b23ab80d846aa82e3cfe96f79db14a2e02`，逐字一致）。

**不同字段（可区分、归域判据）**：

| 维度 | A（page_info.check_exists） | B（metadata.page_exists_check） | 差异定性 |
|---|---|---|---|
| operation_id 命名域 | `udc.page_info.*`（page 域） | `udc.metadata.*`（metadata 域） | 归域标签不同 |
| evidence dict 变量 | `page_info_evidence` | `metadata_page_exists_evidence` | 变量名不同 |
| evidence javap 目录 | `udc-page-5.3.517/UdcRtPageInfoController.javap.txt` | `udc-entity-5.3.517/UdcRtPageInfoController.javap.txt` | **跨域复用：B 挂 entity 域 javap 证据，非本域 page 域**（grep 实测） |
| evidence note 字段 | 无 | 有（POLICY_DENIED 注记） | B 多 1 字段 |
| inputs 取法 | 参数名 `("pageExistsDtoList",)` | 类型名 `("UdcRtPageExistsDto",)` | 参数名 vs 类型名 |
| verification_rules | 3 条 | 4 条（多 08:45 规则② + POLICY_DENIED 2 条） | B 更完整 |

| 维度 | C（page_info.select_host_and_only_page） | D（metadata.page_tree） | 差异定性 |
|---|---|---|---|
| operation_id 命名域 | `udc.page_info.*` | `udc.metadata.*` | 归域标签不同 |
| evidence dict 变量 | `page_info_evidence` | `metadata_anchor_evidence` | 变量名不同 |
| evidence javap 目录 | `udc-page-5.3.517/UdcRtPageInfoController.javap.txt` | `udc-entity-5.3.517/UdcRtPageInfoController.javap.txt` | **跨域复用：D 挂 entity 域 javap 证据，非本域 page 域**（grep 实测） |
| evidence note 字段 | 无 | 有（POLICY_DENIED 注记） | D 多 1 字段 |
| inputs 取法 | 参数名 `("request",)` | 类型名 `("UdcPagesMetaDataSearchDto",)` | 参数名 vs 类型名 |
| verification_rules | 3 条 | 4 条（多 strip(traceId) 双读 + POLICY_DENIED） | D 更完整 |

**结论**：物理端点 + method + 返回 DTO + status + write + 控制器/方法/字节码身份**全同**；差异仅在（i）operation_id 归域命名、（ii）evidence dict 变量名 + javap 证据目录（page vs entity）+ note 字段、（iii）inputs 参数名 vs 类型名、（iv）verification_rules 条数与措辞（B/D 已含 08:45 规则② Boolean 非锚点 + POLICY_DENIED 执行层注记，比 A/C 更完整）。

## ③ 去重候选标注（3 选 1，只标注不代决，归 human 裁定）

> 定性：这是**同一物理只读端点被 page 域与 metadata 域各登记一份**（cross-domain duplicate）。两域 evidence dict 都指向**同一字节码类 `UdcRtPageInfoController` + 同 class_sha256**，只是 javap 证据挂在各自域目录（page→`udc-page-5.3.517/`，metadata→`udc-entity-5.3.517/`）。metadata 域 B/D 的 verification_rules 已按 08:45 规则② 标注「Boolean/HTTP200 非 identity 锚点 + 运行态 POLICY_DENIED（POST 执行层不放行）」，信息更完整。以下为 3 种去重候选及各自代价，**取舍权 = human（归域+去重裁定项①/M3），本刀只标不代决、不删改 registry.py**。

- **候选 1：保留 metadata 域（B/D）为权威，page 域（A/C）降为 alias（指向 B/D）**
  - 依据：B/D 的 verification_rules 已含 08:45 规则②（Boolean 非锚点）+ POLICY_DENIED 执行层边界注记，信息更全；metadata 域为「平台 meta-data 首选读面」（084505 规则①）。
  - 代价：page 域 4 条里 2 条（A/C）不再是独立权威条目，改挂 alias；page 域契约文档（page-readonly-contracts.md C2a/C2b）须注明「权威已归 metadata 域」；若 page 域仍想保留自有 javap 证据目录，alias 需保留 javap 指针。
- **候选 2：保留 page 域（A/C）为权威，metadata 域（B/D）降为 alias（指向 A/C）**
  - 依据：page 域是本任务 human 授权落库的 1-4 条目，且 page 域 javap 证据目录（udc-page-5.3.517/）是 page 域专属取证单元。
  - 代价：B/D 的更完整 verification_rules（08:45 规则② + POLICY_DENIED）需回填到 A/C，否则信息退化；metadata 域 2 条改 alias；两域归域标签（metadata vs page_info）语义需 human 明确「以哪域为 meta-data 首选读面的归属」。
- **候选 3：合并为单一权威条目（取 B/D 的完整 verification_rules + A/C 的参数名 inputs，evidence 保留双 javap 指针或统一 1 个）**
  - 依据：物理端点唯一，合并后消除双登记，最清晰。
  - 代价：需重写 2 条为 1 条（改 registry.py，本刀红线禁止）；evidence dict 需定「挂哪个域的 javap 目录」；operation_id 二选一并把另一域改 alias；影响面最大，须 human 明确归域 + 授权 registry.py 单写方。

**本刀立场（不代决）**：仅物化矩阵 + diff + 3 候选 + 各自代价。归域（page_info vs metadata）与去重（保留谁/alias/合并）是业务裁定项，本任务无权定——红线明令「不评价 metadata/applog 域主线契约质量，只记字段事实 + 去重候选，归 human 裁定」。registry.py 任何条目本刀不删不改；实际去重须 human 授权 + 指定单写方（R9 已上报「外部并写污染」NEEDS_HUMAN：多会话并写同一 registry.py，基线不稳定，去重须先定单写方）。

## ④ registry.py sha 前后自证零改动 + 冻结件 0 改（readback）

- registry.py sha256 pre = post = `37caf4d28b49a1963310c22c822e04e8deb57a3ff7565fdc89edd9bec6413856`（本刀全只读，唯一写入 = 本文件）。
- 本刀仅新增本域 1 文件 `docs/audit/artifacts/udc-page-5.3.517/m3-overlap-matrix.md`；registry.py/pyproject/uv.lock/冻结件（layer.py/seeyon_cli.py/README/两 audit/tests）0 改动；未删改 registry.py 任何条目（去重仅标候选）。
- 无 LIVE（token 过期，独立缺口，非本刀）。

## 结论
矩阵 2 端点 × 4 条目齐 + 逐字段 diff（相同 6 字段 / 差异 4 维度）+ 去重 3 候选（含各自代价 + 归 human 裁定标注）+ registry.py sha 37caf4d2 前后一致 + 本刀仅 1 本域新文件。M3 跨域同端点重叠已物化为证据，去重取舍留 human（归域+去重裁定项①/M3）。
