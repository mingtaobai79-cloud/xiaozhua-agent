# -*- coding: utf-8 -*-
"""R2 step3 | 落盘 javap -p -v 原始证据件（含 provenance 十一字段头）

取证集合 = mapping-bearing 类（L-B 全量，用于双口径核对）
         ∪ 类名层强词干命中类（L-A）
         ∪ 常量池强词干命中且落在「标识符形态」token 的类（L-C 强命中载体）
"""
import hashlib
import json
import os
import re
import subprocess
import sys
import zipfile
from datetime import datetime, timezone

JAVAP = "C:/Program Files/Java/latest/jdk-21/bin/javap.exe"
JAR = "D:/repo/CHIT/com/seeyon/udc-starter-runtime/5.3.517/udc-starter-runtime-5.3.517.jar"
OUTDIR = os.environ.get(
    "UDC_RES_OUT",
    "D:/work/chit/seeyon-agent/docs/audit/artifacts/udc-resource-5.3.517",
)
IDENT = re.compile(r"resource|attachment|upload|download|file|asset|static|doc|skin|theme|media|image", re.I)
STRONG = ("resource", "attachment", "upload", "download", "file", "asset", "static",
         "doc", "skin", "theme", "media", "image")


def main():
    d = json.load(open(os.path.join(OUTDIR, "r1_step1_raw.json"), encoding="utf-8"))
    fqcn_set = set()
    reasons = {}
    for b in d["layer_B"]["bearing"]:
        fqcn_set.add(b["fqcn"])
        reasons.setdefault(b["fqcn"], []).append("L-B mapping-bearing")
    for k, v in d["layer_A"]["hits"].items():
        if k in STRONG:
            for f in v:
                fqcn_set.add(f)
                reasons.setdefault(f, []).append("L-A 类名强词干(%s)" % k)
    for c, k, s in d["layer_C"]["hits"]:
        if k not in STRONG:
            continue
        # 仅收「路径字面量形态」的强词干命中载体（避免把全 jar 拉进证据包）
        if s.startswith("/") and IDENT.search(s):
            fqcn_set.add(c)
            reasons.setdefault(c, []).append("L-C 常量池路径字面量强词干(%s):%s" % (k, s[:60]))

    zf = zipfile.ZipFile(JAR)
    jar_sha = d["jar_sha256"]
    rows = []
    for fqcn in sorted(fqcn_set):
        entry = fqcn.replace(".", "/") + ".class"
        try:
            raw = zf.read(entry)
        except KeyError:
            rows.append({"fqcn": fqcn, "error": "class entry not found: " + entry})
            continue
        sha = hashlib.sha256(raw).hexdigest()
        cmd = [JAVAP, "-J-Dstdout.encoding=UTF-8", "-p", "-v", "-cp", JAR, fqcn]
        p = subprocess.run(cmd, capture_output=True)
        out = p.stdout.decode("utf-8", "replace")
        if p.returncode != 0:
            out += "\n[stderr]\n" + p.stderr.decode("utf-8", "replace")
        simple = fqcn.split(".")[-1].replace("$", "_")
        fn = "r1-%s.javap.txt" % simple
        hdr = (
            "# provenance\n"
            "source_jar: %s\n"
            "source_jar_path: %s\n"
            "jar_sha256: %s\n"
            "class_fqcn: %s\n"
            "class_entry: %s\n"
            "class_sha256: %s\n"
            "class_bytes: %d\n"
            "command: %s\n"
            "exit_code: %d\n"
            "run_at_utc: %s\n"
            "evidence_level: VERIFIED_STATIC_BYTECODE\n"
            "取证理由: %s\n\n"
            % (
                os.path.basename(JAR),
                JAR,
                jar_sha,
                fqcn,
                entry,
                sha,
                len(raw),
                " ".join('"%s"' % c if " " in c else c for c in cmd),
                p.returncode,
                datetime.now(timezone.utc).isoformat(),
                "; ".join(reasons.get(fqcn, ["L-B/L-C 清单"])),
            )
        )
        with open(os.path.join(OUTDIR, fn), "w", encoding="utf-8", newline="\n") as f:
            f.write(hdr + out)
        rows.append(
            {
                "fqcn": fqcn,
                "file": fn,
                "class_entry": entry,
                "class_sha256": sha,
                "class_bytes": len(raw),
                "javap_exit_code": p.returncode,
                "file_bytes": os.path.getsize(os.path.join(OUTDIR, fn)),
                "reasons": reasons.get(fqcn, []),
            }
        )
    rep = {
        "step": "r1_step3_dump_report",
        "generated_at_utc": datetime.now(timezone.utc).isoformat(),
        "javap": JAVAP,
        "jar": JAR,
        "jar_sha256": jar_sha,
        "dump_count": len(rows),
        "rows": rows,
    }
    with open(os.path.join(OUTDIR, "r1_step3_dump_report.json"), "w", encoding="utf-8") as f:
        json.dump(rep, f, ensure_ascii=False, indent=1)
    print("dump_count:", len(rows), "errors:", [r["fqcn"] for r in rows if "error" in r])
    for r in rows:
        print(" %-72s %-52s %8d B rc=%s" % (r["fqcn"], r["file"], r["file_bytes"], r["javap_exit_code"]))


if __name__ == "__main__":
    sys.stdout.reconfigure(encoding="utf-8")
    main()
