# -*- coding: utf-8 -*-
"""R2 step4 | 由原始计数生成 resource 域扫描报告（resource-endpoint-literal-scan.md，只读输入）

输入: r1_step1_raw.json / r1_step3_dump_report.json / r1_step5_completeness.json
输出: resource-endpoint-literal-scan.md（L-A / L-B / L-C 全量表 + 完备性 + 双口径一致性 + 词干判定）
L-C 段口径: 逐词干去重计数 + 载体类清单（每词干最多 12 类）+ 「mapping-bearing 载体」的完整串；
           全量 2107 行命中行原文见 r1_step1_raw.json 的 layer_C.hits（本报告不复制全量以控体积）。
"""
import json
import os
import re
import sys
from datetime import datetime, timezone

OUTDIR = os.environ.get("UDC_RES_OUT", os.path.dirname(os.path.abspath(__file__)))
STRONG = ["resource", "attachment", "upload", "download", "file", "asset", "static",
          "doc", "skin", "theme", "media", "image"]
WEAK = ["url", "path", "template", "storage", "bucket", "blob", "stream", "pic", "photo", "attach"]
CN = ["附件", "文件", "资源", "上传", "下载", "静态", "图片", "模板", "文档", "皮肤", "主题"]
ORDER = STRONG + WEAK + CN
WRITE_VERB = ("create", "delete", "update", "import", "upgrade", "upload", "save", "copy", "publish")


def main():
    raw = json.load(open(os.path.join(OUTDIR, "r1_step1_raw.json"), encoding="utf-8"))
    dump = json.load(open(os.path.join(OUTDIR, "r1_step3_dump_report.json"), encoding="utf-8"))
    comp = json.load(open(os.path.join(OUTDIR, "r1_step5_completeness.json"), encoding="utf-8"))
    dump_by = {r["fqcn"]: r for r in dump["rows"]}
    bearing = {b["fqcn"] for b in raw["layer_B"]["bearing"]}

    L = []
    A = L.append
    A("# udc-resource-5.3.517｜resource 域三层扫描原始证据表（L-A / L-B / L-C）")
    A("")
    A("- 证据单元: 单 jar `udc-starter-runtime-5.3.517.jar`（任务声明构件）")
    A("- jar 绝对路径: `%s`" % raw["jar"])
    A("- jar sha256: `%s`（%d B）" % (raw["jar_sha256"], raw["jar_bytes"]))
    A("- class 条目: %d（含 `$` 内部类）／顶层类去 `$` = %d／非 class 资源条目 %d／解析错误 %d"
      % (raw["class_entry_count"], raw["top_level_class_count"], raw["resource_entry_count"],
         len(raw["parse_errors"])))
    A("- 词干（宽口径）: 强 %s；弱 %s；中文 %s" % ("/".join(STRONG), "/".join(WEAK), "/".join(CN)))
    A("- 生成脚本: `r1_scan_mapping_bearing.py` → `r1_step1_raw.json`；`r1_javap_dump.py` → `r1-<Class>.javap.txt` "
      "+ `r1_step3_dump_report.json`；`r1_completeness_checks.py` → `r1_step5_completeness.json`；本文件由 "
      "`r1_build_report.py` 生成（脚本骨架复用 R1 publish 域五脚本并改词干）")
    A("- 生成时刻(UTC): %s" % datetime.now(timezone.utc).isoformat())
    A("")
    A("## L-A 类名层（%d class 全量 × 宽口径关键词子串）" % raw["class_entry_count"])
    A("")
    A("| 关键词 | 命中数 | 全限定类名 |")
    A("|---|---|---|")
    for k in ORDER:
        v = raw["layer_A"]["hits"].get(k)
        if not v:
            continue
        A("| `%s` | %d | %s |" % (k, len(v), "<br>".join("`%s`" % x for x in v)))
    A("")
    A("- L-A 判定（逐类核 mapping-bearing 资格，R1 教训）: 强词干命中类共 %d 个"
      % len({x for k in STRONG + ["attach"] for x in raw["layer_A"]["hits"].get(k, [])}))
    A("  - `attachment`/`attach`/`template` 命中 = **同一族 6 类**（`AttachmentTemplateController` 控制器 + "
      "`AttachmentTemplateRtAppService` / `AttachmentTemplateRtService` / `AttachmentTemplateRtEntityDao` / "
      "`AttachmentTemplateRtEntity` / `AttachmentTemplateDto`），其中**仅 controller 为 mapping-bearing**。")
    A("  - `resource` 命中 2 类（`domain.service.ResourcePermissionService` / `domain.service.UdcDynamicResourceServiceImpl`）"
      "= **服务层**，非端点承载者。")
    A("  - `file` 命中 1 类（`event.event.ExternalFileEvent`）= **事件类**，非端点承载者。")
    A("  - `path` 命中 13 类（`proxy.UdcRestPathParse` / `proxy.MicroFlowRestPathParser` / `proxy.dto.*Path*`）"
      "= **REST 路径解析器族伪命中**（`path` 指 URL 路径解析，非静态资源/文件面）；"
      "`url` 命中 = `FormAppMbController`/`FormAppPcController` 类级基路径中的 `{pageUrl}` 路径变量（伪命中）。")
    A("  - `upload`/`download`/`static`/`asset`/`doc`/`skin`/`theme`/`media`/`image` 类名层 **0 命中**"
      "（其端点/常量命中见 L-B/L-C）。")
    A("")
    A("## L-B 端点路径字面量层")
    A("")
    A("- mapping-bearing 类（按映射注解描述符筛）: **%d**；端点行 **%d**（类级基路径 %d 行 + 方法级 %d 行）"
      % (len(bearing), raw["layer_B"]["endpoint_row_count"],
         len([b for b in raw["layer_B"]["bearing"] if b["class_level_paths"]]),
         len(raw["layer_B"]["endpoints"])))
    A("- 「常量池以 `/` 开头字面量」兜底口径: **%d** 条，其中含 resource 词干 **%d** 条: %s"
      % (comp["checkB_slash_literal_total"], len(comp["checkB_slash_literals_with_stem"]),
         comp["checkB_slash_literals_with_stem"] or "无"))
    A("")
    A("### L-B-1 mapping-bearing 类清单（%d）" % len(bearing))
    A("")
    A("| # | 类 | class_sha256 | class_bytes | stereotype | 类级基路径原值 | 方法级端点数 | javap 件 |")
    A("|---|---|---|---|---|---|---|---|")
    for i, b in enumerate(raw["layer_B"]["bearing"], 1):
        A("| %d | `%s` | `%s` | %d | %s | %s | %d | `%s` |"
          % (i, b["fqcn"], b["class_sha256"], b["class_bytes"], ",".join(b["stereotypes"]) or "(无)",
             "<br>".join("`%s`" % p for p in b["class_level_paths"]) or "(无类级 @RequestMapping)",
             b["method_count"], dump_by.get(b["fqcn"], {}).get("file", "-")))
    A("")
    A("### L-B-2 端点全量表（%d 行，逐条词干判定）" % raw["layer_B"]["endpoint_row_count"])
    A("")
    A("| # | 类 | 注解(HTTP) | 方法 | 路径原值 | 词干判定 |")
    A("|---|---|---|---|---|---|")
    cand = []
    wr = []
    READ_VERB = ("select", "query", "get", "list", "search", "download", "export", "detail", "check", "exist")
    for i, r in enumerate(raw["layer_B"]["endpoints"], 1):
        blob = (r["class"] + " " + " ".join(r["paths"])).lower()
        hit = [k for k in STRONG + WEAK if k in blob]
        m = r["method"].lower()
        if not hit:
            verdict = "EXCLUDED-NO-STEM"
        elif any(v in m for v in WRITE_VERB):
            verdict = "**WRITE-EXCLUDED(%s)**" % ",".join(hit[:3])
            wr.append(r)
        elif r["annotation"] == "GetMapping":
            verdict = "**CANDIDATE-GET(%s)**" % ",".join(hit[:3])
            cand.append(r)
        elif any(v in m for v in READ_VERB):
            verdict = "**CANDIDATE-READ-NONGET(%s)**" % ",".join(hit[:3])
            cand.append(r)
        else:
            verdict = "**NONGET-UNCLASSIFIED(%s)**" % ",".join(hit[:3])
            wr.append(r)
        A("| %d | `%s` | %s | `%s` | %s | %s |"
          % (i, r["class"].split(".")[-1], r["annotation"], r["method"],
             "<br>".join("`%s`" % p for p in r["paths"]), verdict))
    A("")
    A("## L-C 常量池全量层（%d 类 / %d 条 Utf8；命中去重后逐词干）" % (
        raw["class_entry_count"], raw["layer_C"]["utf8_total"]))
    A("")
    A("| 词干 | 去重命中条数 | 载体类数 | 其中 mapping-bearing 载体 |")
    A("|---|---|---|---|")
    seen = set()
    per = {}
    for c, k, s in raw["layer_C"]["hits"]:
        key = (c, k, s)
        if key in seen:
            continue
        seen.add(key)
        per.setdefault(k, []).append((c, s))
    for k in ORDER:
        if k not in per:
            continue
        carriers = sorted({c for c, _ in per[k]})
        mb = [c for c in carriers if c in bearing]
        A("| `%s` | %d | %d | %s |" % (k, len(per[k]), len(carriers),
                                       "<br>".join("`%s`" % x.split(".")[-1] for x in mb) or "0"))
    A("")
    A("- 全量命中行（含跨词干重复，%d 行）原文见 `r1_step1_raw.json` 的 `layer_C.hits`；下表按词干给出载体类清单"
      "（每词干最多 12 类）与「mapping-bearing 载体」的全部命中串。" % raw["layer_C"]["hit_count"])
    A("")
    for k in ORDER:
        if k not in per:
            continue
        carriers = sorted({c for c, _ in per[k]})
        A("### L-C-%s（去重 %d 条 / 载体 %d 类）" % (k, len(per[k]), len(carriers)))
        A("")
        A("- 载体类（前 12）: %s" % "、".join("`%s`" % c.split(".")[-1] for c in carriers[:12]))
        mbs = [(c, s) for c, s in per[k] if c in bearing]
        if mbs:
            A("- **mapping-bearing 载体命中串（全列）**:")
            for c, s in mbs:
                A("  - `%s` → `%s`" % (c.split(".")[-1], s[:140]))
        else:
            A("- mapping-bearing 载体命中: **0**（全落在非 controller 位）")
        A("")
    A("## 完备性三查 + 双口径一致性（r1_step5_completeness.json）")
    A("")
    A("| 查 | 口径 | 结果 |")
    A("|---|---|---|")
    A("| A | `@RestController`/`@Controller` stereotype 类是否全在 mapping-bearing 集内 | controller 类 %d；**bearing 集外 = %d** |"
      % (comp["checkA_stereotype_controller_classes"], len(comp["checkA_stereotype_outside_bearing"])))
    A("| A' | mapping-bearing 类中 `@interface`（元注解声明映射盲区） | %d |"
      % len(comp["checkA_annotation_type_in_bearing"]))
    A("| A'' | 仅 `@Component`（非 controller）类数（旁证） | %d |" % comp["checkA_component_only_classes"])
    A("| B | 全类常量池 `/` 开头字面量中的 resource 词干（端点表外新路径盲区） | %d 条: %s |"
      % (len(comp["checkB_slash_literals_with_stem"]), comp["checkB_slash_literals_with_stem"] or "无"))
    A("| C | 双口径: 自实现 JVMS 解析 vs javap -p -v 已解码文本独立再提取（annotation, path 原值）集合等值 | 比对 %d 类，**mismatch = %d** |"
      % (comp["mapping_bearing_classes_compared"], comp["mismatch_count"]))
    A("")
    A("## resource 域判定（本 jar 内，数据驱动）")
    A("")
    A("- 端点层含词干的行 = %d 条（GET 候选 %d / 写或非 GET %d）" % (len(cand) + len(wr), len(cand), len(wr)))
    for r in cand:
        A("  - CANDIDATE: `%s.%s` %s（%s） %s" % (r["class"].split(".")[-1], r["method"], r["annotation"], "GET" if r["annotation"] == "GetMapping" else "非 GET/查询形态", r["paths"]))
    for r in wr:
        A("  - EXCLUDED: `%s.%s` %s（%s） %s" % (r["class"].split(".")[-1], r["method"], r["annotation"], "写/非查询形态", r["paths"]))
    A("- 类级基路径含词干者: %s" % "；".join(
        "`%s` = %s" % (b["fqcn"].split(".")[-1], b["class_level_paths"])
        for b in raw["layer_B"]["bearing"] if re.search("|".join(STRONG + WEAK),
                                                        " ".join(b["class_level_paths"]), re.I)) or "无")
    A("")

    p = os.path.join(OUTDIR, "resource-endpoint-literal-scan.md")
    with open(p, "w", encoding="utf-8", newline="\n") as f:
        f.write("\n".join(L))
    print("wrote:", p, os.path.getsize(p), "B")


if __name__ == "__main__":
    sys.stdout.reconfigure(encoding="utf-8")
    main()
