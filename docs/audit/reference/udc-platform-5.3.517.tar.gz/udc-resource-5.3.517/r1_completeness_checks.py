# -*- coding: utf-8 -*-
"""R2 step5 | 完备性与双口径一致性核对（只读，resource 词干）

L4-A 完备性查 A: @RestController/@Controller stereotype 覆盖 —— stereotype 类是否全在 mapping-bearing 集内
L4-B 完备性查 B: 全 346 类常量池「以 / 开头」字面量中是否含 publish/deploy 词干（端点表外新路径盲区）
L4-C 完备性查 C: mapping-bearing 类中是否存在 @interface（自定义元注解声明映射的盲区）
L3  双口径一致性: 自实现 JVMS 解析结果 vs javap -p -v 已解码文本独立再提取的 (annotation, path) 集合等值比对
"""
import json
import os
import re
import sys
import zipfile

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import r1_scan_mapping_bearing as S  # noqa: E402

OUTDIR = os.environ.get("UDC_RES_OUT", HERE)
JAR = S.JAR
STEMS = ("resource", "attachment", "upload", "download", "file", "asset", "static",
         "doc", "skin", "theme", "media", "image")
ANN_LINE = re.compile(r"^(\s*)(\d+): #(\d+)\(")
FQN_LINE = re.compile(r"^\s+(org\.springframework\.web\.bind\.annotation\.\w+|com\.seeyon\.boot\.\w+(?:\.\w+)*)\(?\s*$")
VALUE_LINE = re.compile(r"^\s+(value|path)=(\[.*\]|\".*\")\s*$")
METHOD_LINE = re.compile(r"^\s{2}[^ ].*\(.*\);\s*$")


def javap_extract(text):
    """从 javap -p -v 文本独立再提取 (annotation_simple, values, level)。

    level: 'class' = 类级（缩进 2 空格） / 'method' = 方法级（缩进 6 空格）。
    """
    out = []
    lines = text.splitlines()
    cur_method = None
    for idx, ln in enumerate(lines):
        m = METHOD_LINE.match(ln)
        if m and not ln.strip().startswith("#"):
            nm = ln.strip()
            nm = nm[nm.find(" ") + 1 :]
            if "(" in nm:
                cur_method = nm[: nm.find("(")].split()[-1]
        a = ANN_LINE.match(ln)
        if not a:
            continue
        indent, _num, _cp = a.group(1), a.group(2), a.group(3)
        level = "class" if len(indent) <= 2 else "method"
        if level == "method" and cur_method is None:
            level = "method-unknown"
        # 找紧随的注解 FQN 行与 value/path 行
        fqn = None
        vals = []
        j = idx + 1
        while j < len(lines) and j < idx + 8:
            s = lines[j].strip()
            if s == ")":
                break
            fm = FQN_LINE.match(lines[j])
            if fm:
                fqn = fm.group(1)
            vm = VALUE_LINE.match(lines[j])
            if vm:
                key, raw = vm.group(1), vm.group(2)
                if raw.startswith("["):
                    vals = re.findall(r'"((?:[^"\\]|\\.)*)"', raw)
                else:
                    vals = [raw.strip('"')]
            j += 1
        out.append(
            {
                "annotation": (fqn or "").split(".")[-1],
                "fqn": fqn,
                "values": vals,
                "level": level,
                "method": cur_method if level != "class" else None,
            }
        )
    return out


def main():
    raw = json.load(open(os.path.join(OUTDIR, "r1_step1_raw.json"), encoding="utf-8"))
    dump = json.load(open(os.path.join(OUTDIR, "r1_step3_dump_report.json"), encoding="utf-8"))
    dump_by_fqcn = {r["fqcn"]: r for r in dump["rows"]}

    zf = zipfile.ZipFile(JAR)
    MAPPING_SIMPLE = {"RequestMapping", "GetMapping", "PostMapping", "PutMapping", "DeleteMapping", "PatchMapping"}

    # --- L4-A stereotype 覆盖 ---
    classes = [e for e in zf.namelist() if e.endswith(".class")]
    bearing_fqcn = {b["fqcn"] for b in raw["layer_B"]["bearing"]}
    stereo_all = []
    stereo_outside = []
    comp_only = []
    iface_decl = []
    for e in classes:
        fqcn = e[:-6].replace("/", ".")
        try:
            cp, cann, methods = S.parse_class(zf.read(e))
        except Exception as ex:  # noqa: BLE001
            continue
        st = [S.STEREOTYPES[d] for d, _ in cann if d in S.STEREOTYPES]
        ctl = [x for x in st if x in ("RestController", "Controller")]
        if ctl:
            stereo_all.append([fqcn, ctl])
            if fqcn not in bearing_fqcn:
                stereo_outside.append([fqcn, ctl])
        elif st:
            comp_only.append([fqcn, st])
    # 类声明含 interface/annotation 关键字者（javap 文本判定）
    iface_decl = []
    for fqcn in sorted(bearing_fqcn):
        r = dump_by_fqcn.get(fqcn)
        if not r:
            continue
        t = open(os.path.join(OUTDIR, r["file"]), encoding="utf-8").read()
        for ln in t.splitlines():
            if ln.startswith("public ") or ln.startswith("abstract ") or ln.startswith("interface "):
                if " interface " in ln or " @interface " in ln or "@interface" in ln:
                    iface_decl.append([fqcn, ln.strip()])
                break

    # --- L4-B 全类常量池 / 开头字面量的 publish 词干 ---
    slash_stem = []
    for fqcn, s in raw["layer_B"]["slash_literals"]:
        low = s.lower()
        if any(k in low for k in STEMS):
            slash_stem.append([fqcn, s])

    # --- L3 双口径一致性 ---
    my_rows = {}
    for r in raw["layer_B"]["endpoints"]:
        my_rows.setdefault(r["class"], set()).add((r["annotation"], tuple(r["paths"])))
    for b in raw["layer_B"]["bearing"]:
        if b["class_level_paths"]:
            my_rows.setdefault(b["fqcn"], set()).add(("RequestMapping", tuple(b["class_level_paths"])))

    mismatches = []
    javap_rows = {}
    for fqcn in sorted(bearing_fqcn):
        r = dump_by_fqcn.get(fqcn)
        if not r:
            mismatches.append([fqcn, "javap 证据件缺失"])
            continue
        text = open(os.path.join(OUTDIR, r["file"]), encoding="utf-8").read()
        anns = javap_extract(text)
        javap_rows[fqcn] = anns
        got = set()
        for a in anns:
            if a["annotation"] in MAPPING_SIMPLE:
                got.add((a["annotation"], tuple(a["values"])))
        mine = my_rows.get(fqcn, set())
        if got != mine:
            mismatches.append([fqcn, sorted(map(str, got - mine)), sorted(map(str, mine - got))])

    out = {
        "step": "r1_step5_completeness",
        "jar": JAR,
        "jar_sha256": raw["jar_sha256"],
        "checkA_stereotype_controller_classes": len(stereo_all),
        "checkA_stereotype_outside_bearing": stereo_outside,
        "checkA_component_only_classes": len(comp_only),
        "checkA_annotation_type_in_bearing": iface_decl,
        "checkB_slash_literals_with_stem": slash_stem,
        "checkB_slash_literal_total": raw["layer_B"]["slash_literal_count"],
        "checkC_bearing_count": len(bearing_fqcn),
        "checkC_interface_decl": iface_decl,
        "mapping_bearing_classes_compared": len(bearing_fqcn),
        "mismatch_count": len(mismatches),
        "mismatches": mismatches,
        "javap_annotation_rows": {k: v for k, v in javap_rows.items()},
    }
    with open(os.path.join(OUTDIR, "r1_step5_completeness.json"), "w", encoding="utf-8") as f:
        json.dump(out, f, ensure_ascii=False, indent=1)

    print("checkA stereotype 类:", len(stereo_all), "| 在 bearing 之外:", len(stereo_outside))
    for x in stereo_outside:
        print("   !", x)
    print("checkA bearing 内 @interface/interface 类:", len(iface_decl), iface_decl)
    print("checkB / 开头字面量总数:", raw["layer_B"]["slash_literal_count"], "| 含 resource 词干:", slash_stem)
    print("L3 双口径: 比对类数", len(bearing_fqcn), "| mismatch:", len(mismatches))
    for m in mismatches:
        print("   !", m)


if __name__ == "__main__":
    sys.stdout.reconfigure(encoding="utf-8")
    main()
