# udc-resource-5.3.517｜resource 域三层扫描原始证据表（L-A / L-B / L-C）

- 证据单元: 单 jar `udc-starter-runtime-5.3.517.jar`（任务声明构件）
- jar 绝对路径: `D:/repo/CHIT/com/seeyon/udc-starter-runtime/5.3.517/udc-starter-runtime-5.3.517.jar`
- jar sha256: `74ae50bd8510414113248f0b1d400bca80d2ae2e0022c9dbbb31321a6040a66f`（861880 B）
- class 条目: 346（含 `$` 内部类）／顶层类去 `$` = 307／非 class 资源条目 126／解析错误 0
- 词干（宽口径）: 强 resource/attachment/upload/download/file/asset/static/doc/skin/theme/media/image；弱 url/path/template/storage/bucket/blob/stream/pic/photo/attach；中文 附件/文件/资源/上传/下载/静态/图片/模板/文档/皮肤/主题
- 生成脚本: `r1_scan_mapping_bearing.py` → `r1_step1_raw.json`；`r1_javap_dump.py` → `r1-<Class>.javap.txt` + `r1_step3_dump_report.json`；`r1_completeness_checks.py` → `r1_step5_completeness.json`；本文件由 `r1_build_report.py` 生成（脚本骨架复用 R1 publish 域五脚本并改词干）
- 生成时刻(UTC): 2026-10-08T16:09:35.654747+00:00

## L-A 类名层（346 class 全量 × 宽口径关键词子串）

| 关键词 | 命中数 | 全限定类名 |
|---|---|---|
| `resource` | 2 | `com.seeyon.boot.starter.udcrt.domain.service.ResourcePermissionService`<br>`com.seeyon.boot.starter.udcrt.domain.service.UdcDynamicResourceServiceImpl` |
| `attachment` | 6 | `com.seeyon.boot.starter.udcrt.appservice.AttachmentTemplateRtAppService`<br>`com.seeyon.boot.starter.udcrt.controller.AttachmentTemplateController`<br>`com.seeyon.boot.starter.udcrt.domain.dao.AttachmentTemplateRtEntityDao`<br>`com.seeyon.boot.starter.udcrt.domain.entity.AttachmentTemplateRtEntity`<br>`com.seeyon.boot.starter.udcrt.domain.service.AttachmentTemplateRtService`<br>`com.seeyon.boot.starter.udcrt.dto.AttachmentTemplateDto` |
| `file` | 1 | `com.seeyon.boot.starter.udcrt.event.event.ExternalFileEvent` |
| `path` | 13 | `com.seeyon.boot.starter.udcrt.proxy.MicroFlowRestPathParser`<br>`com.seeyon.boot.starter.udcrt.proxy.UdcRestPathParse`<br>`com.seeyon.boot.starter.udcrt.proxy.dto.MicroFlowRestPathMetadataDto$1`<br>`com.seeyon.boot.starter.udcrt.proxy.dto.MicroFlowRestPathMetadataDto$AppName`<br>`com.seeyon.boot.starter.udcrt.proxy.dto.MicroFlowRestPathMetadataDto$Build`<br>`com.seeyon.boot.starter.udcrt.proxy.dto.MicroFlowRestPathMetadataDto$Builder`<br>`com.seeyon.boot.starter.udcrt.proxy.dto.MicroFlowRestPathMetadataDto$FromCustomApp`<br>`com.seeyon.boot.starter.udcrt.proxy.dto.MicroFlowRestPathMetadataDto$HostAppName`<br>`com.seeyon.boot.starter.udcrt.proxy.dto.MicroFlowRestPathMetadataDto$MicroFlowBaseInfo`<br>`com.seeyon.boot.starter.udcrt.proxy.dto.MicroFlowRestPathMetadataDto$ReqMethod`<br>`com.seeyon.boot.starter.udcrt.proxy.dto.MicroFlowRestPathMetadataDto`<br>`com.seeyon.boot.starter.udcrt.proxy.dto.UdcRestPathParseBaseDto`<br>`com.seeyon.boot.starter.udcrt.proxy.dto.UdcRestPathParseDto` |
| `template` | 6 | `com.seeyon.boot.starter.udcrt.appservice.AttachmentTemplateRtAppService`<br>`com.seeyon.boot.starter.udcrt.controller.AttachmentTemplateController`<br>`com.seeyon.boot.starter.udcrt.domain.dao.AttachmentTemplateRtEntityDao`<br>`com.seeyon.boot.starter.udcrt.domain.entity.AttachmentTemplateRtEntity`<br>`com.seeyon.boot.starter.udcrt.domain.service.AttachmentTemplateRtService`<br>`com.seeyon.boot.starter.udcrt.dto.AttachmentTemplateDto` |
| `attach` | 6 | `com.seeyon.boot.starter.udcrt.appservice.AttachmentTemplateRtAppService`<br>`com.seeyon.boot.starter.udcrt.controller.AttachmentTemplateController`<br>`com.seeyon.boot.starter.udcrt.domain.dao.AttachmentTemplateRtEntityDao`<br>`com.seeyon.boot.starter.udcrt.domain.entity.AttachmentTemplateRtEntity`<br>`com.seeyon.boot.starter.udcrt.domain.service.AttachmentTemplateRtService`<br>`com.seeyon.boot.starter.udcrt.dto.AttachmentTemplateDto` |

- L-A 判定（逐类核 mapping-bearing 资格，R1 教训）: 强词干命中类共 9 个
  - `attachment`/`attach`/`template` 命中 = **同一族 6 类**（`AttachmentTemplateController` 控制器 + `AttachmentTemplateRtAppService` / `AttachmentTemplateRtService` / `AttachmentTemplateRtEntityDao` / `AttachmentTemplateRtEntity` / `AttachmentTemplateDto`），其中**仅 controller 为 mapping-bearing**。
  - `resource` 命中 2 类（`domain.service.ResourcePermissionService` / `domain.service.UdcDynamicResourceServiceImpl`）= **服务层**，非端点承载者。
  - `file` 命中 1 类（`event.event.ExternalFileEvent`）= **事件类**，非端点承载者。
  - `path` 命中 13 类（`proxy.UdcRestPathParse` / `proxy.MicroFlowRestPathParser` / `proxy.dto.*Path*`）= **REST 路径解析器族伪命中**（`path` 指 URL 路径解析，非静态资源/文件面）；`url` 命中 = `FormAppMbController`/`FormAppPcController` 类级基路径中的 `{pageUrl}` 路径变量（伪命中）。
  - `upload`/`download`/`static`/`asset`/`doc`/`skin`/`theme`/`media`/`image` 类名层 **0 命中**（其端点/常量命中见 L-B/L-C）。

## L-B 端点路径字面量层

- mapping-bearing 类（按映射注解描述符筛）: **27**；端点行 **131**（类级基路径 24 行 + 方法级 131 行）
- 「常量池以 `/` 开头字面量」兜底口径: **40** 条，其中含 resource 词干 **1** 条: [['com.seeyon.boot.starter.udcrt.controller.DynamicJarController', '/download/{appName}']]

### L-B-1 mapping-bearing 类清单（27）

| # | 类 | class_sha256 | class_bytes | stereotype | 类级基路径原值 | 方法级端点数 | javap 件 |
|---|---|---|---|---|---|---|---|
| 1 | `com.seeyon.boot.starter.udcrt.controller.AppDraftController` | `5090304dcb69cd0d3cd7b4e961d6ceff5f41e56d27b60eecf48950a34e5fabb9` | 3704 | RestController | `udc-runtime/app-draft` | 6 | `r1-AppDraftController.javap.txt` |
| 2 | `com.seeyon.boot.starter.udcrt.controller.AttachmentTemplateController` | `72241cb3ae302c91cd3baba690eaa25656adcedc13e7cdf25413deebd31444f3` | 4744 | RestController | `udc-runtime/attachment-template` | 7 | `r1-AttachmentTemplateController.javap.txt` |
| 3 | `com.seeyon.boot.starter.udcrt.controller.CustomApplicationController` | `d3e82d8bbc65dc92d5f9d30532159f1d10169f2aef1eae6ab67c70d7ad75ae55` | 13271 | RestController | `udc-runtime/custom-app` | 13 | `r1-CustomApplicationController.javap.txt` |
| 4 | `com.seeyon.boot.starter.udcrt.controller.DynamicJarController` | `0eb1fd79e96e09eb0122c0aafd77d8922ee3163f46f5436a44c98b476726def2` | 5796 | RestController | `udc-runtime/dynamic/jar` | 4 | `r1-DynamicJarController.javap.txt` |
| 5 | `com.seeyon.boot.starter.udcrt.controller.FrontFunctionSupportController` | `c9be69ceb85a8c8e6e171b4f494c2d3124d9a08283b8cebfebca43e2a7db5f8a` | 1931 | RestController | `udc-runtime/function-support` | 1 | `r1-FrontFunctionSupportController.javap.txt` |
| 6 | `com.seeyon.boot.starter.udcrt.controller.GraphqlProxyController` | `a83c2355e040c799eddd152c43ad2d4dbc0ceb3cae444bfb892b785c5a6bcb56` | 1865 | RestController | `udc-runtime/graphql-proxy` | 1 | `r1-GraphqlProxyController.javap.txt` |
| 7 | `com.seeyon.boot.starter.udcrt.controller.RuntimeCOLISplitController` | `9033611697ec83af8f8853d870ea85334bacaf02e44ea2cecbb07e46881fa7c5` | 3267 | RestController | `udc-runtime/coli` | 2 | `r1-RuntimeCOLISplitController.javap.txt` |
| 8 | `com.seeyon.boot.starter.udcrt.controller.RuntimeEnvCheckController` | `86e4598cd2124e8bc0f280b17e7e9965d626acb5a0adb9b5a80026d41c193582` | 11474 | RestController | `udc-runtime/evn-check` | 5 | `r1-RuntimeEnvCheckController.javap.txt` |
| 9 | `com.seeyon.boot.starter.udcrt.controller.UdcAppLogController` | `f6a2111d3f5fd28b7c84d7eb1dddacd42ca38ffa0be194f2c34550faed2ee775` | 13089 | RestController | `udc-runtime/app-log` | 19 | `r1-UdcAppLogController.javap.txt` |
| 10 | `com.seeyon.boot.starter.udcrt.controller.UdcAttrSnapshotRtController` | `2cbd39885b7621d0539794c00650aa50831aa8e681ef06ef185cd6f922c07784` | 2473 | RestController | `udc-runtime/attr-snapshot` | 2 | `r1-UdcAttrSnapshotRtController.javap.txt` |
| 11 | `com.seeyon.boot.starter.udcrt.controller.UdcDataTypeController` | `03b3977b50574208eaad2b1925a80520a4686b268a56bacd35b87a144854bc38` | 1787 | RestController | `udc-runtime/datatype` | 1 | `r1-UdcDataTypeController.javap.txt` |
| 12 | `com.seeyon.boot.starter.udcrt.controller.UdcEntityUpdateRtTestController` | `612f6be8b1d46604be02fb2da348f38363b0ac9f7ecb87803ff8b108beddfc72` | 3404 | RestController | `udc-runtime/update-test` | 1 | `r1-UdcEntityUpdateRtTestController.javap.txt` |
| 13 | `com.seeyon.boot.starter.udcrt.controller.UdcFormDataQueryController` | `cabd312210665274361568181b6d41b9a86f7ed13f1dba7e3f844dc2e5ea5584` | 2221 | RestController | `udc-runtime/data` | 1 | `r1-UdcFormDataQueryController.javap.txt` |
| 14 | `com.seeyon.boot.starter.udcrt.controller.UdcFunctionNodeController` | `efd8f9143d0fd44d4e3033a4bb4877c09e891a1049f66382df1ae1d7d08a7748` | 1844 | RestController | `udc-runtime/meta-data` | 1 | `r1-UdcFunctionNodeController.javap.txt` |
| 15 | `com.seeyon.boot.starter.udcrt.controller.UdcRoleRtController` | `ed024802b6c205041e4368840993412be184ff67c5f9b12938bee5a13a2aae47` | 1826 | RestController | `udc-runtime/udc-role` | 1 | `r1-UdcRoleRtController.javap.txt` |
| 16 | `com.seeyon.boot.starter.udcrt.controller.UdcRtPageInfoController` | `7678734875e3c96aa463bd94084061b23ab80d846aa82e3cfe96f79db14a2e02` | 2872 | RestController | `udc-runtime/meta-data` | 2 | `r1-UdcRtPageInfoController.javap.txt` |
| 17 | `com.seeyon.boot.starter.udcrt.controller.UdcRtPageLogController` | `86efc8a3b0924cb46f4d8ca11b527ba9129f3dd6d938e345c5cb11be15038c5e` | 3156 | RestController | `udc-runtime/rt-page-log` | 4 | `r1-UdcRtPageLogController.javap.txt` |
| 18 | `com.seeyon.boot.starter.udcrt.controller.UdcRuntimeDatabaseController` | `588bc1cf97cf53357ce0a851d16eb28244b6a9607aa5c813b80e4c2c8d4b3c48` | 1876 | RestController | `udc-runtime/database` | 1 | `r1-UdcRuntimeDatabaseController.javap.txt` |
| 19 | `com.seeyon.boot.starter.udcrt.controller.UdcSerialConfigController` | `fe1e5a72d7a25b34c566a9f49dbd47461c0abe54735dbd190b62203b07f81658` | 13081 | RestController | `udc-runtime/serial-config` | 6 | `r1-UdcSerialConfigController.javap.txt` |
| 20 | `com.seeyon.boot.starter.udcrt.proxy.controller.FormAppInfoController` | `085c971cc601a904c4369ee339ffd31fdb4d08a6aa8ff678724c1c615b01dacb` | 763 | RestController | `{hostAppName}/dynamic-rest/com-seeyon/{currentAppName}/app-info` | 0 | `r1-FormAppInfoController.javap.txt` |
| 21 | `com.seeyon.boot.starter.udcrt.proxy.controller.FormAppMbController` | `c4dd9ab16749f4bcc06a497816ea4d44b7639f11e82f1cb6f683849687baa957` | 751 | RestController | `dynamic-rest/com-seeyon/{entityAppName}/mobile/{pageUrl}` | 0 | `r1-FormAppMbController.javap.txt` |
| 22 | `com.seeyon.boot.starter.udcrt.proxy.controller.FormAppPcController` | `ffa014071be9789cff70d152bf521943c7648703f82f082cd6351d8393594aa0` | 737 | RestController | `dynamic-rest/com-seeyon/{entityAppName}/{pageUrl}` | 0 | `r1-FormAppPcController.javap.txt` |
| 23 | `com.seeyon.boot.starter.udcrt.proxy.controller.FormReferController` | `81391cf270d4e3f3c52f1662c1b19620318045a607430cd73f8f7b5b388d460c` | 744 | RestController | `dynamic-rest/com-seeyon/{entityAppName}/{entityName}/refer` | 0 | `r1-FormReferController.javap.txt` |
| 24 | `com.seeyon.boot.starter.udcrt.proxy.controller.NormalAppInfoController` | `2b0574dc5ff19b0b39d84ce68796889c122f81d7626912f67b1e37bd7cdda195` | 737 | RestController | `{currentAppName}/app-info` | 0 | `r1-NormalAppInfoController.javap.txt` |
| 25 | `com.seeyon.boot.starter.udcrt.proxy.controller.UdcBaseAppInfoController` | `deebcc39cff41fc3b28748cacf5c44657a5f4cd600914b44ecd075436b3fde95` | 1653 | (无) | (无类级 @RequestMapping) | 1 | `r1-UdcBaseAppInfoController.javap.txt` |
| 26 | `com.seeyon.boot.starter.udcrt.proxy.controller.UdcBaseGeneralController` | `19c40f0353d2346bd0e5c374e8e7a79b9268b739f18cc1049435c12b37e664c8` | 33434 | (无) | (无类级 @RequestMapping) | 38 | `r1-UdcBaseGeneralController.javap.txt` |
| 27 | `com.seeyon.boot.starter.udcrt.proxy.controller.UdcReferController` | `912383403dcd0e9e445225308b82a117850fbc98494e54243b6f2d454bf09664` | 14214 | (无) | (无类级 @RequestMapping) | 14 | `r1-UdcReferController.javap.txt` |

### L-B-2 端点全量表（131 行，逐条词干判定）

| # | 类 | 注解(HTTP) | 方法 | 路径原值 | 词干判定 |
|---|---|---|---|---|---|
| 1 | `AppDraftController` | PostMapping | `createOrUpdate` | `create` | EXCLUDED-NO-STEM |
| 2 | `AppDraftController` | PostMapping | `exist` | `exist` | EXCLUDED-NO-STEM |
| 3 | `AppDraftController` | PostMapping | `select` | `select` | EXCLUDED-NO-STEM |
| 4 | `AppDraftController` | PostMapping | `delete` | `delete` | EXCLUDED-NO-STEM |
| 5 | `AppDraftController` | PostMapping | `deleteAll` | `delete-all` | EXCLUDED-NO-STEM |
| 6 | `AppDraftController` | PostMapping | `deleteTimeout` | `delete/timeout` | EXCLUDED-NO-STEM |
| 7 | `AttachmentTemplateController` | PostMapping | `create` | `/create` | **WRITE-EXCLUDED(attachment,template,attach)** |
| 8 | `AttachmentTemplateController` | PostMapping | `createBatch` | `/create-batch` | **WRITE-EXCLUDED(attachment,template,attach)** |
| 9 | `AttachmentTemplateController` | GetMapping | `selectByGuid` | `{guid}` | **CANDIDATE-GET(attachment,template,attach)** |
| 10 | `AttachmentTemplateController` | PostMapping | `selectByGuids` | `/select-by-guids` | **CANDIDATE-READ-NONGET(attachment,template,attach)** |
| 11 | `AttachmentTemplateController` | GetMapping | `selectByAppId` | `/app/{appId}` | **CANDIDATE-GET(attachment,template,attach)** |
| 12 | `AttachmentTemplateController` | PostMapping | `delete` | `/delete/{guid}` | **WRITE-EXCLUDED(attachment,template,attach)** |
| 13 | `AttachmentTemplateController` | PostMapping | `deleteByGuids` | `/delete-by-guids` | **WRITE-EXCLUDED(attachment,template,attach)** |
| 14 | `CustomApplicationController` | PostMapping | `create` | `/create` | EXCLUDED-NO-STEM |
| 15 | `CustomApplicationController` | PostMapping | `createAsync` | `/create-async` | EXCLUDED-NO-STEM |
| 16 | `CustomApplicationController` | PostMapping | `newLayoutCreateAsync` | `/new-layout-create-async` | EXCLUDED-NO-STEM |
| 17 | `CustomApplicationController` | PostMapping | `copy` | `/copy` | EXCLUDED-NO-STEM |
| 18 | `CustomApplicationController` | PostMapping | `copyAsync` | `/copy-async` | EXCLUDED-NO-STEM |
| 19 | `CustomApplicationController` | PostMapping | `deleteByIds` | `delete` | EXCLUDED-NO-STEM |
| 20 | `CustomApplicationController` | PostMapping | `updateCaption` | `/update-caption` | EXCLUDED-NO-STEM |
| 21 | `CustomApplicationController` | PostMapping | `updateUsageState` | `/update-usage-state` | EXCLUDED-NO-STEM |
| 22 | `CustomApplicationController` | PostMapping | `updateDeployState` | `/update-deploy-state` | EXCLUDED-NO-STEM |
| 23 | `CustomApplicationController` | PostMapping | `updateAuth` | `/update-auth` | EXCLUDED-NO-STEM |
| 24 | `CustomApplicationController` | PostMapping | `selectListByConditions` | `/search-no-page` | EXCLUDED-NO-STEM |
| 25 | `CustomApplicationController` | PostMapping | `selectListByConditions` | `/search-page` | EXCLUDED-NO-STEM |
| 26 | `CustomApplicationController` | PostMapping | `upgrade` | `/upgrade` | EXCLUDED-NO-STEM |
| 27 | `DynamicJarController` | PostMapping | `importJar` | `/import` | EXCLUDED-NO-STEM |
| 28 | `DynamicJarController` | GetMapping | `getRequestStatus` | `import/status/{requestId}` | EXCLUDED-NO-STEM |
| 29 | `DynamicJarController` | PostMapping | `downloadApp` | `/download/{appName}` | **CANDIDATE-READ-NONGET(download)** |
| 30 | `DynamicJarController` | GetMapping | `download` | `download` | **CANDIDATE-GET(download)** |
| 31 | `FrontFunctionSupportController` | PostMapping | `selectListByEntityName` | `calculate` | EXCLUDED-NO-STEM |
| 32 | `GraphqlProxyController` | PostMapping | `doGraphql` | `graphql` | EXCLUDED-NO-STEM |
| 33 | `RuntimeCOLISplitController` | PostMapping | `upgrade` | `upgrade` | EXCLUDED-NO-STEM |
| 34 | `RuntimeCOLISplitController` | PostMapping | `upload` | `upload/result` | **WRITE-EXCLUDED(upload)** |
| 35 | `RuntimeEnvCheckController` | GetMapping | `getBuildInfo` | `build-info/{appName}` | EXCLUDED-NO-STEM |
| 36 | `RuntimeEnvCheckController` | GetMapping | `checkAppVersion` | `app-version/{appName}` | EXCLUDED-NO-STEM |
| 37 | `RuntimeEnvCheckController` | GetMapping | `checkDataPermission` | `data-permission/{entityFullName}` | EXCLUDED-NO-STEM |
| 38 | `RuntimeEnvCheckController` | GetMapping | `checkResponseLength` | `response-length/{length}` | EXCLUDED-NO-STEM |
| 39 | `RuntimeEnvCheckController` | PostMapping | `checkRequestContent` | `request-content` | EXCLUDED-NO-STEM |
| 40 | `UdcAppLogController` | PostMapping | `createBatch` | `create-batch` | EXCLUDED-NO-STEM |
| 41 | `UdcAppLogController` | PostMapping | `search` | `search/microflow` | EXCLUDED-NO-STEM |
| 42 | `UdcAppLogController` | PostMapping | `searchDetails` | `search-details/microflow` | EXCLUDED-NO-STEM |
| 43 | `UdcAppLogController` | PostMapping | `searchFlowDetails` | `search-details/microflow/flowLog` | EXCLUDED-NO-STEM |
| 44 | `UdcAppLogController` | PostMapping | `searchDataFlow` | `search/dataflow` | EXCLUDED-NO-STEM |
| 45 | `UdcAppLogController` | PostMapping | `searchDataFlowDetails` | `search-details/dataflow` | EXCLUDED-NO-STEM |
| 46 | `UdcAppLogController` | PostMapping | `searchDeduction` | `search/deduction` | EXCLUDED-NO-STEM |
| 47 | `UdcAppLogController` | PostMapping | `searchDeductionDetails` | `search-details/deduction` | EXCLUDED-NO-STEM |
| 48 | `UdcAppLogController` | PostMapping | `searchAppDataLog` | `datalog/search` | EXCLUDED-NO-STEM |
| 49 | `UdcAppLogController` | GetMapping | `selectAppDataById` | `datalog/{id}` | EXCLUDED-NO-STEM |
| 50 | `UdcAppLogController` | GetMapping | `selectAppDataByDataId` | `datalog/list-by-dataid/{dataId}` | EXCLUDED-NO-STEM |
| 51 | `UdcAppLogController` | GetMapping | `deleteAll` | `delete-all` | EXCLUDED-NO-STEM |
| 52 | `UdcAppLogController` | GetMapping | `clearOrgManager` | `clear-org-manager` | EXCLUDED-NO-STEM |
| 53 | `UdcAppLogController` | GetMapping | `clearRuntimeDataSource` | `clear-runtime-data-source-cache` | EXCLUDED-NO-STEM |
| 54 | `UdcAppLogController` | PostMapping | `initTenantData` | `init-tenant-data` | EXCLUDED-NO-STEM |
| 55 | `UdcAppLogController` | PostMapping | `updateDataInitVersion` | `update-data-init-version` | EXCLUDED-NO-STEM |
| 56 | `UdcAppLogController` | GetMapping | `unloadDynamicApp` | `unload-dynamic-app/{appName}` | EXCLUDED-NO-STEM |
| 57 | `UdcAppLogController` | GetMapping | `setRestEnableLog` | `enable-log/{enable}` | EXCLUDED-NO-STEM |
| 58 | `UdcAppLogController` | PostMapping | `saveFrontLog` | `save/front-log` | EXCLUDED-NO-STEM |
| 59 | `UdcAttrSnapshotRtController` | GetMapping | `deleteByDataId` | `delete-by-data-id/{dataId}` | EXCLUDED-NO-STEM |
| 60 | `UdcAttrSnapshotRtController` | GetMapping | `deleteByMasterDataId` | `delete-by-master-data-id/{masterDataId}` | EXCLUDED-NO-STEM |
| 61 | `UdcDataTypeController` | GetMapping | `getDataTypes` | `getAll` | EXCLUDED-NO-STEM |
| 62 | `UdcEntityUpdateRtTestController` | PostMapping | `updateWithFields` | `update-with-fields` | EXCLUDED-NO-STEM |
| 63 | `UdcFormDataQueryController` | PostMapping | `queryFormData` | `/query` | EXCLUDED-NO-STEM |
| 64 | `UdcFunctionNodeController` | GetMapping | `selectFunctionNodeTreeMetaData` | `select-function-node-tree/{appName}` | EXCLUDED-NO-STEM |
| 65 | `UdcRoleRtController` | GetMapping | `search` | `has-system-admin/{appName}` | EXCLUDED-NO-STEM |
| 66 | `UdcRtPageInfoController` | PostMapping | `checkPageExistsByConditions` | `check-page-exists` | EXCLUDED-NO-STEM |
| 67 | `UdcRtPageInfoController` | PostMapping | `selectHostAppAndOnlyPageAppPages` | `select-host-and-only-page-pages` | EXCLUDED-NO-STEM |
| 68 | `UdcRtPageLogController` | PostMapping | `createBatch` | `create-batch` | EXCLUDED-NO-STEM |
| 69 | `UdcRtPageLogController` | PostMapping | `search` | `search` | EXCLUDED-NO-STEM |
| 70 | `UdcRtPageLogController` | PostMapping | `searchNonMetadata` | `search-non-metadata` | EXCLUDED-NO-STEM |
| 71 | `UdcRtPageLogController` | GetMapping | `deleteAll` | `delete-all` | EXCLUDED-NO-STEM |
| 72 | `UdcRuntimeDatabaseController` | GetMapping | `queryData` | `query-data` | EXCLUDED-NO-STEM |
| 73 | `UdcSerialConfigController` | PostMapping | `update` | `update` | EXCLUDED-NO-STEM |
| 74 | `UdcSerialConfigController` | PostMapping | `selectListByConditions` | `list` | EXCLUDED-NO-STEM |
| 75 | `UdcSerialConfigController` | GetMapping | `selectEntityList` | `select-entity-list` | EXCLUDED-NO-STEM |
| 76 | `UdcSerialConfigController` | PostMapping | `selectEntityBySerial` | `select-entity-by-serial-id` | EXCLUDED-NO-STEM |
| 77 | `UdcSerialConfigController` | GetMapping | `refreshHistoricalData` | `refresh-historical-data/{appName}` | EXCLUDED-NO-STEM |
| 78 | `UdcSerialConfigController` | GetMapping | `cacheEvict` | `cache-evict/{appName}` | EXCLUDED-NO-STEM |
| 79 | `UdcBaseAppInfoController` | GetMapping | `getDeployInfo` | `deploy-info` | EXCLUDED-NO-STEM |
| 80 | `UdcBaseGeneralController` | PostMapping | `create` | `{entityAppName}/{entityName}/{controlId}/create` | EXCLUDED-NO-STEM |
| 81 | `UdcBaseGeneralController` | PostMapping | `createBatch` | `{entityAppName}/{entityName}/{controlId}/create-batch` | EXCLUDED-NO-STEM |
| 82 | `UdcBaseGeneralController` | PostMapping | `deleteById` | `{entityAppName}/{entityName}/{controlId}/delete-by-id` | EXCLUDED-NO-STEM |
| 83 | `UdcBaseGeneralController` | PostMapping | `deleteByIds` | `{entityAppName}/{entityName}/{controlId}/delete-by-ids` | EXCLUDED-NO-STEM |
| 84 | `UdcBaseGeneralController` | PostMapping | `update` | `{entityAppName}/{entityName}/{controlId}/update` | EXCLUDED-NO-STEM |
| 85 | `UdcBaseGeneralController` | PostMapping | `updateBatch` | `{entityAppName}/{entityName}/{controlId}/update-batch` | EXCLUDED-NO-STEM |
| 86 | `UdcBaseGeneralController` | PostMapping | `operateRootBatch` | `{entityAppName}/{entityName}/{controlId}/operate-root-batch` | EXCLUDED-NO-STEM |
| 87 | `UdcBaseGeneralController` | PostMapping | `updateWithResult` | `{entityAppName}/{entityName}/{controlId}/update-with-result` | EXCLUDED-NO-STEM |
| 88 | `UdcBaseGeneralController` | PostMapping | `runtimeCopy` | `{entityAppName}/{entityName}/{controlId}/runtime-copy` | EXCLUDED-NO-STEM |
| 89 | `UdcBaseGeneralController` | GetMapping | `getCascadeDefaultValue` | `{entityAppName}/{entityName}/{controlId}/get-cascade-default-value` | EXCLUDED-NO-STEM |
| 90 | `UdcBaseGeneralController` | PostMapping | `selectCascadeByConditions` | `{entityAppName}/{entityName}/{controlId}/select-cascade-by-conditions` | EXCLUDED-NO-STEM |
| 91 | `UdcBaseGeneralController` | PostMapping | `selectCascadeById` | `{entityAppName}/{entityName}/select-cascade-by-id` | EXCLUDED-NO-STEM |
| 92 | `UdcBaseGeneralController` | PostMapping | `selectTreeGrid` | `{entityAppName}/{entityName}/{controlId}/select-tree-grid` | EXCLUDED-NO-STEM |
| 93 | `UdcBaseGeneralController` | PostMapping | `selectHighestTree` | `{entityAppName}/{entityName}/{controlId}/select-highest-tree` | EXCLUDED-NO-STEM |
| 94 | `UdcBaseGeneralController` | PostMapping | `selectAllChildren4HighestTree` | `{entityAppName}/{entityName}/{controlId}/select-highest-tree-children` | EXCLUDED-NO-STEM |
| 95 | `UdcBaseGeneralController` | PostMapping | `dynamicJoinSelect` | `filter-plan/{entityAppName}/{entityName}/{filterId}` | EXCLUDED-NO-STEM |
| 96 | `UdcBaseGeneralController` | PostMapping | `dynamicJoinSelectCount` | `filter-plan/{entityAppName}/{entityName}/{filterId}/count` | EXCLUDED-NO-STEM |
| 97 | `UdcBaseGeneralController` | PostMapping | `create4Bpm` | `{entityAppName}/{entityName}/{controlId}/create-bpm` | EXCLUDED-NO-STEM |
| 98 | `UdcBaseGeneralController` | PostMapping | `update4Bpm` | `{entityAppName}/{entityName}/{controlId}/update-bpm` | EXCLUDED-NO-STEM |
| 99 | `UdcBaseGeneralController` | PostMapping | `forwardCascadeByConditions` | `select-forward-data` | EXCLUDED-NO-STEM |
| 100 | `UdcBaseGeneralController` | PostMapping | `selectCascadeListByConditions` | `refer-carry/{entityAppName}/{entityName}/{controlId}/select-cascade-list-by-conditions` | EXCLUDED-NO-STEM |
| 101 | `UdcBaseGeneralController` | GetMapping | `selectById4Refer` | `page-refer/{entityAppName}/{entityName}/{referGuid}/{objectId}` | EXCLUDED-NO-STEM |
| 102 | `UdcBaseGeneralController` | PostMapping | `selectByIds4Refer` | `page-refer/{entityAppName}/{entityName}/{referGuid}/select-by-ids` | EXCLUDED-NO-STEM |
| 103 | `UdcBaseGeneralController` | PostMapping | `searchPageByCondition4Refer` | `page-refer/{entityAppName}/{entityName}/{referGuid}` | EXCLUDED-NO-STEM |
| 104 | `UdcBaseGeneralController` | PostMapping | `selectHighestTree4Refer` | `page-refer/{entityAppName}/{entityName}/{referGuid}/select-highest-tree` | EXCLUDED-NO-STEM |
| 105 | `UdcBaseGeneralController` | PostMapping | `selectAllChildren4Highest4Refer` | `page-refer/{entityAppName}/{entityName}/{referGuid}/select-highest-tree-children` | EXCLUDED-NO-STEM |
| 106 | `UdcBaseGeneralController` | PostMapping | `searchPageByCondition4TreeRefer` | `page-refer/{entityAppName}/{entityName}/{referGuid}/tree` | EXCLUDED-NO-STEM |
| 107 | `UdcBaseGeneralController` | PostMapping | `selectHighest4TreeRefer` | `page-refer/{entityAppName}/{entityName}/{referGuid}/tree/select-highest-tree` | EXCLUDED-NO-STEM |
| 108 | `UdcBaseGeneralController` | PostMapping | `selectAllChildren4Highest4TreeRefer` | `page-refer/{entityAppName}/{entityName}/{referGuid}/tree/select-highest-tree-children` | EXCLUDED-NO-STEM |
| 109 | `UdcBaseGeneralController` | PostMapping | `selectListByConditions4TreeRefer` | `page-refer/{entityAppName}/{entityName}/{referGuid}/tree/search-list-by-conditions` | EXCLUDED-NO-STEM |
| 110 | `UdcBaseGeneralController` | PostMapping | `selectTree` | `page-refer/{entityAppName}/{entityName}/{referGuid}/select-tree` | EXCLUDED-NO-STEM |
| 111 | `UdcBaseGeneralController` | PostMapping | `selectTree_tree` | `page-refer/{entityAppName}/{entityName}/{referGuid}/tree/select-tree` | EXCLUDED-NO-STEM |
| 112 | `UdcBaseGeneralController` | PostMapping | `importExcelData` | `{entityAppName}/{entityName}/{controlId}/import` | EXCLUDED-NO-STEM |
| 113 | `UdcBaseGeneralController` | PostMapping | `exportExcel` | `{entityAppName}/{entityName}/{controlId}/export` | EXCLUDED-NO-STEM |
| 114 | `UdcBaseGeneralController` | PostMapping | `dynamicSelect` | `dataflow/{entityName}/{restMappingName}/dynamic/select` | EXCLUDED-NO-STEM |
| 115 | `UdcBaseGeneralController` | PostMapping | `executeDataFlow` | `dataflow/{entityName}/{restMappingName}` | EXCLUDED-NO-STEM |
| 116 | `UdcBaseGeneralController` | GetMapping | `doGetMicroFlow` | `microflow/{microFlowName}`<br>`host/microflow/{microFlowName}` | EXCLUDED-NO-STEM |
| 117 | `UdcBaseGeneralController` | PostMapping | `doPostMicroFlow` | `microflow/{microFlowName}`<br>`host/microflow/{microFlowName}` | EXCLUDED-NO-STEM |
| 118 | `UdcReferController` | PostMapping | `selectHighestTree` | `{entityAppName}/{entityName}/{referGuid}/select-highest-tree` | EXCLUDED-NO-STEM |
| 119 | `UdcReferController` | PostMapping | `selectAllChildren4HighestTree` | `{entityAppName}/{entityName}/{referGuid}/select-highest-tree-children` | EXCLUDED-NO-STEM |
| 120 | `UdcReferController` | PostMapping | `selectTree` | `{entityAppName}/{entityName}/{referGuid}/select-tree` | EXCLUDED-NO-STEM |
| 121 | `UdcReferController` | PostMapping | `selectListByConditions` | `{entityAppName}/{entityName}/{referGuid}/search-list-by-conditions` | EXCLUDED-NO-STEM |
| 122 | `UdcReferController` | PostMapping | `searchPageByCondition` | `{entityAppName}/{entityName}/{referGuid}` | EXCLUDED-NO-STEM |
| 123 | `UdcReferController` | GetMapping | `selectById` | `{entityAppName}/{entityName}/{referGuid}/{objectId}` | EXCLUDED-NO-STEM |
| 124 | `UdcReferController` | GetMapping | `selectV1ById` | `{entityAppName}/{entityName}/{referGuid}/v1/{id}` | EXCLUDED-NO-STEM |
| 125 | `UdcReferController` | PostMapping | `selectV1ByIds` | `{entityAppName}/{entityName}/{referGuid}/v1/ids` | EXCLUDED-NO-STEM |
| 126 | `UdcReferController` | PostMapping | `selectByIds` | `{entityAppName}/{entityName}/{referGuid}/select-by-ids` | EXCLUDED-NO-STEM |
| 127 | `UdcReferController` | PostMapping | `selectHighestTree_tree` | `{entityAppName}/{entityName}/{referGuid}/tree/select-highest-tree` | EXCLUDED-NO-STEM |
| 128 | `UdcReferController` | PostMapping | `selectAllChildren4HighestTree_tree` | `{entityAppName}/{entityName}/{referGuid}/tree/select-highest-tree-children` | EXCLUDED-NO-STEM |
| 129 | `UdcReferController` | PostMapping | `selectTree_tree` | `{entityAppName}/{entityName}/{referGuid}/tree/select-tree` | EXCLUDED-NO-STEM |
| 130 | `UdcReferController` | PostMapping | `selectListByConditions_tree` | `entityAppName}/{entityName}/{referGuid}/tree/search-list-by-conditions` | EXCLUDED-NO-STEM |
| 131 | `UdcReferController` | PostMapping | `searchPage_treeByCondition` | `{entityAppName}/{entityName}/{referGuid}/tree` | EXCLUDED-NO-STEM |

## L-C 常量池全量层（346 类 / 38646 条 Utf8；命中去重后逐词干）

| 词干 | 去重命中条数 | 载体类数 | 其中 mapping-bearing 载体 |
|---|---|---|---|
| `resource` | 155 | 20 | `RuntimeEnvCheckController`<br>`UdcSerialConfigController`<br>`UdcBaseAppInfoController` |
| `attachment` | 84 | 10 | `AttachmentTemplateController` |
| `upload` | 25 | 7 | `RuntimeCOLISplitController`<br>`UdcBaseGeneralController` |
| `download` | 20 | 6 | `DynamicJarController` |
| `file` | 553 | 346 | `AppDraftController`<br>`AttachmentTemplateController`<br>`CustomApplicationController`<br>`DynamicJarController`<br>`FrontFunctionSupportController`<br>`GraphqlProxyController`<br>`RuntimeCOLISplitController`<br>`RuntimeEnvCheckController`<br>`UdcAppLogController`<br>`UdcAttrSnapshotRtController`<br>`UdcDataTypeController`<br>`UdcEntityUpdateRtTestController`<br>`UdcFormDataQueryController`<br>`UdcFunctionNodeController`<br>`UdcRoleRtController`<br>`UdcRtPageInfoController`<br>`UdcRtPageLogController`<br>`UdcRuntimeDatabaseController`<br>`UdcSerialConfigController`<br>`FormAppInfoController`<br>`FormAppMbController`<br>`FormAppPcController`<br>`FormReferController`<br>`NormalAppInfoController`<br>`UdcBaseAppInfoController`<br>`UdcBaseGeneralController`<br>`UdcReferController` |
| `static` | 3 | 2 | 0 |
| `doc` | 15 | 5 | 0 |
| `media` | 1 | 1 | 0 |
| `url` | 173 | 32 | `CustomApplicationController`<br>`UdcSerialConfigController`<br>`FormAppMbController`<br>`FormAppPcController` |
| `path` | 337 | 57 | `AttachmentTemplateController`<br>`DynamicJarController`<br>`RuntimeEnvCheckController`<br>`UdcAppLogController`<br>`UdcAttrSnapshotRtController`<br>`UdcFunctionNodeController`<br>`UdcRoleRtController`<br>`UdcSerialConfigController`<br>`UdcBaseAppInfoController`<br>`UdcBaseGeneralController`<br>`UdcReferController` |
| `template` | 109 | 20 | `AttachmentTemplateController` |
| `storage` | 26 | 9 | `DynamicJarController` |
| `bucket` | 3 | 1 | 0 |
| `stream` | 448 | 60 | `RuntimeCOLISplitController`<br>`UdcSerialConfigController` |
| `pic` | 6 | 5 | 0 |
| `attach` | 84 | 10 | `AttachmentTemplateController` |
| `附件` | 20 | 7 | `AttachmentTemplateController` |
| `文件` | 14 | 7 | `RuntimeCOLISplitController` |
| `资源` | 6 | 4 | `UdcSerialConfigController` |
| `上传` | 4 | 4 | `RuntimeCOLISplitController` |
| `下载` | 3 | 3 | 0 |
| `模板` | 18 | 8 | `AttachmentTemplateController` |

- 全量命中行（含跨词干重复，2107 行）原文见 `r1_step1_raw.json` 的 `layer_C.hits`；下表按词干给出载体类清单（每词干最多 12 类）与「mapping-bearing 载体」的全部命中串。

### L-C-resource（去重 155 条 / 载体 20 类）

- 载体类（前 12）: `PageCustomSearchAppService`、`UdcPageProxyAppService`、`UdcReadAppConfigAppService`、`UdcWaterMarkControlImpl`、`ColiDataUpgradeAppService`、`RuntimeEnvCheckController`、`UdcSerialConfigController`、`DynamicJarService`、`FormServiceProxy`、`ResourcePermissionService`、`UdcDynamicResourceServiceImpl`、`UdcFunctionNodeService`
- **mapping-bearing 载体命中串（全列）**:
  - `RuntimeEnvCheckController` → `udcFrontendResourceService`
  - `RuntimeEnvCheckController` → `Lcom/seeyon/boot/starter/extmetadata/domain/resource/UdcFrontendResourceService;`
  - `RuntimeEnvCheckController` → `udcLoadResourceService`
  - `RuntimeEnvCheckController` → `Lcom/seeyon/boot/starter/extmetadata/domain/resource/UdcLoadResourceService;`
  - `RuntimeEnvCheckController` → `frontResource`
  - `RuntimeEnvCheckController` → `com/seeyon/boot/starter/extmetadata/domain/resource/UdcLoadResourceService`
  - `RuntimeEnvCheckController` → `com/seeyon/boot/starter/extmetadata/domain/resource/UdcFrontendResourceService`
  - `RuntimeEnvCheckController` → `readFrontResourceJson`
  - `UdcSerialConfigController` → `udcLoadJarResourceAppService`
  - `UdcSerialConfigController` → `Lcom/seeyon/ctp/metadata/api/LoadJarResourceAppService;`
  - `UdcSerialConfigController` → `securityResourcePermissionService`
  - `UdcSerialConfigController` → `Lcom/seeyon/boot/starter/security/SecurityResourcePermissionService;`
  - `UdcSerialConfigController` → `serialConfigResourceId`
  - `UdcSerialConfigController` → `checkSerialConfigResourcePermission`
  - `UdcSerialConfigController` → `lambda$checkSerialConfigResourcePermission$1`
  - `UdcSerialConfigController` → `lambda$checkSerialConfigResourcePermission$0`
  - `UdcSerialConfigController` → `com/seeyon/ctp/metadata/api/LoadJarResourceAppService`
  - `UdcSerialConfigController` → `com/seeyon/boot/starter/security/SecurityResourcePermissionService`
  - `UdcSerialConfigController` → `checkResourcePermission`
  - `UdcBaseAppInfoController` → `udcLoadResourceService`
  - `UdcBaseAppInfoController` → `Lcom/seeyon/boot/starter/extmetadata/domain/resource/UdcLoadResourceService;`
  - `UdcBaseAppInfoController` → `com/seeyon/boot/starter/extmetadata/domain/resource/UdcLoadResourceService`

### L-C-attachment（去重 84 条 / 载体 10 类）

- 载体类（前 12）: `AttachmentTemplateRtAppService`、`AttachmentTemplateController`、`AttachmentTemplateRtEntityDao`、`AttachmentTemplateRtEntity`、`ApproveFeatureService`、`AttachmentTemplateRtService`、`UdcEntityLogService`、`UdcSecretCheckService`、`AttachmentTemplateDto`、`MicroFlowActivityTypeEnum`
- **mapping-bearing 载体命中串（全列）**:
  - `AttachmentTemplateController` → `attachmentTemplateAppService`
  - `AttachmentTemplateController` → `Lcom/seeyon/boot/starter/udcrt/appservice/AttachmentTemplateRtAppService;`
  - `AttachmentTemplateController` → `Lcom/seeyon/boot/starter/udcrt/controller/AttachmentTemplateController;`
  - `AttachmentTemplateController` → `(Lcom/seeyon/boot/starter/udcrt/dto/AttachmentTemplateDto;)Lcom/seeyon/boot/transport/SingleResponse;`
  - `AttachmentTemplateController` → `attachmentTemplateDto`
  - `AttachmentTemplateController` → `Lcom/seeyon/boot/starter/udcrt/dto/AttachmentTemplateDto;`
  - `AttachmentTemplateController` → `(Lcom/seeyon/boot/starter/udcrt/dto/AttachmentTemplateDto;)Lcom/seeyon/boot/transport/SingleResponse<Lcom/seeyon/boot/starter/udcrt/dto/Atta`
  - `AttachmentTemplateController` → `attachments`
  - `AttachmentTemplateController` → `Ljava/util/List<Lcom/seeyon/boot/starter/udcrt/dto/AttachmentTemplateDto;>;`
  - `AttachmentTemplateController` → `(Ljava/util/List<Lcom/seeyon/boot/starter/udcrt/dto/AttachmentTemplateDto;>;)Lcom/seeyon/boot/transport/ListResponse<Lcom/seeyon/boot/starte`
  - `AttachmentTemplateController` → `AttachmentTemplateController.java`
  - `AttachmentTemplateController` → `udc-runtime/attachment-template`
  - `AttachmentTemplateController` → `com/seeyon/boot/starter/udcrt/controller/AttachmentTemplateController`
  - `AttachmentTemplateController` → `com/seeyon/boot/starter/udcrt/appservice/AttachmentTemplateRtAppService`

### L-C-upload（去重 25 条 / 载体 7 类）

- 载体类（前 12）: `RuntimeCOLISplitController`、`DynamicJarService`、`FormServiceProxy`、`FormParamDto`、`MicroFlowActivityTypeEnum`、`FormErrorCode`、`UdcBaseGeneralController`
- **mapping-bearing 载体命中串（全列）**:
  - `RuntimeCOLISplitController` → `upload`
  - `RuntimeCOLISplitController` → `uploadResultDto`
  - `RuntimeCOLISplitController` → `Lcom/seeyon/boot/starter/file/dto/response/UploadResultDto;`
  - `RuntimeCOLISplitController` → `(Lorg/springframework/web/multipart/MultipartFile;)Lcom/seeyon/boot/transport/SingleResponse<Lcom/seeyon/boot/starter/file/dto/response/Uplo`
  - `RuntimeCOLISplitController` → `upload/result`
  - `RuntimeCOLISplitController` → `uploadForPublicNoDB`
  - `RuntimeCOLISplitController` → `(Ljava/io/InputStream;Ljava/lang/String;)Lcom/seeyon/boot/starter/file/dto/response/UploadResultDto;`
  - `UdcBaseGeneralController` → `(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lcom/seeyon/boot/starter/excel/dto/ExcelUploadRequestDto;)Lcom/seeyon/boot/transport/`
  - `UdcBaseGeneralController` → `uploadRequestDto`
  - `UdcBaseGeneralController` → `Lcom/seeyon/boot/starter/excel/dto/ExcelUploadRequestDto;`
  - `UdcBaseGeneralController` → `(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lcom/seeyon/boot/starter/excel/dto/ExcelUploadRequestDto;)Lcom/seeyon/boot/transport/`

### L-C-download（去重 20 条 / 载体 6 类）

- 载体类（前 12）: `UdcWaterMarkControlImpl`、`ColiDataUpgradeAppService`、`DynamicJarController`、`DynamicJarService`、`FromAcrossService`、`MicroFlowActivityTypeEnum`
- **mapping-bearing 载体命中串（全列）**:
  - `DynamicJarController` → `downloadApp`
  - `DynamicJarController` → `/download/{appName}`
  - `DynamicJarController` → `download`
  - `DynamicJarController` → `download appName:{},storageKey:{}`
  - `DynamicJarController` → `com/seeyon/boot/starter/file/storage/util/DownloadUtils`
  - `DynamicJarController` → `getDownloadContentDispositionStr`

### L-C-file（去重 553 条 / 载体 346 类）

- 载体类（前 12）: `PropDesc`、`AppRuntimeAutoConfiguration`、`FormEngineProperties`、`AppDraftAppService`、`DeployNoticeService`、`FormAppService`、`GraphqlProxyAppService`、`UdcBpmProcessService`、`UdcSerialConfigAppService`、`AppDraftAppServiceImpl`、`AttachmentTemplateRtAppService`、`AttributeSnapshotAppServiceImpl`
- **mapping-bearing 载体命中串（全列）**:
  - `AppDraftController` → `SourceFile`
  - `AttachmentTemplateController` → `(Ljava/lang/Long;)Lcom/seeyon/boot/transport/SingleResponse<Lcom/seeyon/udc/common/dto/CommonFileDto;>;`
  - `AttachmentTemplateController` → `(Ljava/util/List<Ljava/lang/Long;>;)Lcom/seeyon/boot/transport/ListResponse<Lcom/seeyon/udc/common/dto/CommonFileDto;>;`
  - `AttachmentTemplateController` → `(Ljava/lang/Long;)Lcom/seeyon/boot/transport/ListResponse<Lcom/seeyon/udc/common/dto/CommonFileDto;>;`
  - `AttachmentTemplateController` → `SourceFile`
  - `CustomApplicationController` → `SourceFile`
  - `DynamicJarController` → `fileService`
  - `DynamicJarController` → `Lcom/seeyon/boot/starter/file/FileService;`
  - `DynamicJarController` → `zipFileName`
  - `DynamicJarController` → `SourceFile`
  - `DynamicJarController` → `com/seeyon/boot/starter/file/storage/util/DownloadUtils`
  - `DynamicJarController` → `com/seeyon/boot/starter/file/FileService`
  - `FrontFunctionSupportController` → `SourceFile`
  - `GraphqlProxyController` → `SourceFile`
  - `RuntimeCOLISplitController` → `fileService`
  - `RuntimeCOLISplitController` → `Lcom/seeyon/boot/starter/file/FileService;`
  - `RuntimeCOLISplitController` → `(Lorg/springframework/web/multipart/MultipartFile;)Lcom/seeyon/boot/transport/SingleResponse;`
  - `RuntimeCOLISplitController` → `Lcom/seeyon/boot/starter/file/dto/response/UploadResultDto;`
  - `RuntimeCOLISplitController` → `file`
  - `RuntimeCOLISplitController` → `Lorg/springframework/web/multipart/MultipartFile;`
  - `RuntimeCOLISplitController` → `(Lorg/springframework/web/multipart/MultipartFile;)Lcom/seeyon/boot/transport/SingleResponse<Lcom/seeyon/boot/starter/file/dto/response/Uplo`
  - `RuntimeCOLISplitController` → `SourceFile`
  - `RuntimeCOLISplitController` → `org/springframework/web/multipart/MultipartFile`
  - `RuntimeCOLISplitController` → `getOriginalFilename`
  - `RuntimeCOLISplitController` → `com/seeyon/boot/starter/file/FileService`
  - `RuntimeCOLISplitController` → `(Ljava/io/InputStream;Ljava/lang/String;)Lcom/seeyon/boot/starter/file/dto/response/UploadResultDto;`
  - `RuntimeEnvCheckController` → `SourceFile`
  - `UdcAppLogController` → `SourceFile`
  - `UdcAttrSnapshotRtController` → `SourceFile`
  - `UdcDataTypeController` → `SourceFile`
  - `UdcEntityUpdateRtTestController` → `SourceFile`
  - `UdcFormDataQueryController` → `SourceFile`
  - `UdcFunctionNodeController` → `SourceFile`
  - `UdcRoleRtController` → `SourceFile`
  - `UdcRtPageInfoController` → `SourceFile`
  - `UdcRtPageLogController` → `SourceFile`
  - `UdcRuntimeDatabaseController` → `SourceFile`
  - `UdcSerialConfigController` → `SourceFile`
  - `UdcSerialConfigController` → `setJsonFileName`
  - `FormAppInfoController` → `SourceFile`
  - `FormAppMbController` → `SourceFile`
  - `FormAppPcController` → `SourceFile`
  - `FormReferController` → `SourceFile`
  - `NormalAppInfoController` → `SourceFile`
  - `UdcBaseAppInfoController` → `SourceFile`
  - `UdcBaseGeneralController` → `SourceFile`
  - `UdcReferController` → `SourceFile`

### L-C-static（去重 3 条 / 载体 2 类）

- 载体类（前 12）: `EntityEventDeepCopier`、`UdcAppLogHelper`
- mapping-bearing 载体命中: **0**（全落在非 controller 位）

### L-C-doc（去重 15 条 / 载体 5 类）

- 载体类（前 12）: `ColiDataUpgradeAppService`、`UdcSecretCheckService`、`CustomApplicationDto`、`CustomApplicationUpgradeDto`、`SerialEntityEventListener`
- mapping-bearing 载体命中: **0**（全落在非 controller 位）

### L-C-media（去重 1 条 / 载体 1 类）

- 载体类（前 12）: `CustomConstantRightParamParser`
- mapping-bearing 载体命中: **0**（全落在非 controller 位）

### L-C-url（去重 173 条 / 载体 32 类）

- 载体类（前 12）: `CustomApplicationAppService`、`DisplayNameAppService`、`GraphqlProxyAppServiceImpl`、`PageCustomSearchAppService`、`UdcPageProxyAppService`、`CustomApplicationController`、`UdcSerialConfigController`、`CustomApplication`、`UdcRtPageLog`、`AppDraftService`、`ApproveFeatureService`、`EntityRuntimeService`
- **mapping-bearing 载体命中串（全列）**:
  - `CustomApplicationController` → `pageUrlTypeEnum`
  - `CustomApplicationController` → `Lcom/seeyon/udc/common/enums/PageUrlTypeEnum;`
  - `CustomApplicationController` → `com/seeyon/udc/common/enums/PageUrlTypeEnum`
  - `CustomApplicationController` → `getPageUrlTypeEnum`
  - `CustomApplicationController` → `()Lcom/seeyon/udc/common/enums/PageUrlTypeEnum;`
  - `CustomApplicationController` → `getPageUrl`
  - `UdcSerialConfigController` → `getPageUrl`
  - `FormAppMbController` → `dynamic-rest/com-seeyon/{entityAppName}/mobile/{pageUrl}`
  - `FormAppPcController` → `dynamic-rest/com-seeyon/{entityAppName}/{pageUrl}`

### L-C-path（去重 337 条 / 载体 57 类）

- 载体类（前 12）: `GraphqlProxyAppServiceImpl`、`MicroFlowProxyAppMicroFlow`、`MicroFlowProxyAppMicroFlow$InvokeMethodMetadata`、`PageCustomSearchAppService`、`ReferDynamicSelectAppService`、`UdcBpmProcessServiceImpl`、`UdcPageProxyAppService`、`UdcPageProxyAppService$1`、`UdcProxyEntityAppService`、`ColiDataUpgradeAppService`、`AttachmentTemplateController`、`DynamicJarController`
- **mapping-bearing 载体命中串（全列）**:
  - `AttachmentTemplateController` → `Lorg/springframework/web/bind/annotation/PathVariable;`
  - `DynamicJarController` → `Lorg/springframework/web/bind/annotation/PathVariable;`
  - `RuntimeEnvCheckController` → `Lorg/springframework/web/bind/annotation/PathVariable;`
  - `UdcAppLogController` → `Lorg/springframework/web/bind/annotation/PathVariable;`
  - `UdcAttrSnapshotRtController` → `Lorg/springframework/web/bind/annotation/PathVariable;`
  - `UdcFunctionNodeController` → `Lorg/springframework/web/bind/annotation/PathVariable;`
  - `UdcRoleRtController` → `Lorg/springframework/web/bind/annotation/PathVariable;`
  - `UdcSerialConfigController` → `Lorg/springframework/web/bind/annotation/PathVariable;`
  - `UdcBaseAppInfoController` → `Lorg/springframework/web/bind/annotation/PathVariable;`
  - `UdcBaseGeneralController` → `pathParse`
  - `UdcBaseGeneralController` → `Lcom/seeyon/boot/starter/udcrt/proxy/UdcRestPathParse;`
  - `UdcBaseGeneralController` → `microFlowRestPathParser`
  - `UdcBaseGeneralController` → `Lcom/seeyon/boot/starter/udcrt/proxy/MicroFlowRestPathParser;`
  - `UdcBaseGeneralController` → `Lorg/springframework/web/bind/annotation/PathVariable;`
  - `UdcBaseGeneralController` → `Lcom/seeyon/boot/starter/udcrt/proxy/dto/UdcRestPathParseDto;`
  - `UdcBaseGeneralController` → `Lcom/seeyon/boot/starter/udcrt/proxy/dto/MicroFlowRestPathMetadataDto;`
  - `UdcBaseGeneralController` → `requestPath`
  - `UdcBaseGeneralController` → `()Lcom/seeyon/boot/starter/udcrt/proxy/dto/UdcRestPathParseDto;`
  - `UdcBaseGeneralController` → `com/seeyon/boot/starter/udcrt/proxy/dto/UdcRestPathParseDto`
  - `UdcBaseGeneralController` → `com/seeyon/boot/starter/udcrt/proxy/UdcRestPathParse`
  - `UdcBaseGeneralController` → `parseDataFlowRestPath2Dto`
  - `UdcBaseGeneralController` → `(Ljava/lang/String;)Lcom/seeyon/boot/starter/udcrt/proxy/dto/UdcRestPathParseDto;`
  - `UdcBaseGeneralController` → `(Lcom/seeyon/boot/starter/udcrt/proxy/dto/UdcRestPathParseDto;Lcom/seeyon/boot/starter/udcrt/proxy/dto/UdcDataFlowBaseRequestDto;)V`
  - `UdcBaseGeneralController` → `(Lcom/seeyon/boot/starter/udcrt/proxy/dto/UdcRestPathParseDto;)V`
  - `UdcBaseGeneralController` → `com/seeyon/boot/starter/udcrt/proxy/MicroFlowRestPathParser`
  - `UdcBaseGeneralController` → `(Ljava/lang/String;)Lcom/seeyon/boot/starter/udcrt/proxy/dto/MicroFlowRestPathMetadataDto;`
  - `UdcBaseGeneralController` → `(Lcom/seeyon/boot/starter/udcrt/proxy/dto/MicroFlowRestPathMetadataDto;)Lcom/seeyon/boot/starter/udcrt/proxy/dto/MicroFlowRestRequestDto;`
  - `UdcBaseGeneralController` → `(Ljava/lang/Object;Lcom/seeyon/boot/starter/udcrt/proxy/dto/MicroFlowRestPathMetadataDto;)Lcom/seeyon/boot/starter/udcrt/proxy/dto/MicroFlow`
  - `UdcBaseGeneralController` → `parseAndPaddingRestPath2Dto`
  - `UdcReferController` → `pathParse`
  - `UdcReferController` → `Lcom/seeyon/boot/starter/udcrt/proxy/UdcRestPathParse;`
  - `UdcReferController` → `Lorg/springframework/web/bind/annotation/PathVariable;`
  - `UdcReferController` → `requestPath`
  - `UdcReferController` → `Lcom/seeyon/boot/starter/udcrt/proxy/dto/UdcRestPathParseDto;`
  - `UdcReferController` → `()Lcom/seeyon/boot/starter/udcrt/proxy/dto/UdcRestPathParseDto;`
  - `UdcReferController` → `com/seeyon/boot/starter/udcrt/proxy/dto/UdcRestPathParseDto`
  - `UdcReferController` → `com/seeyon/boot/starter/udcrt/proxy/UdcRestPathParse`
  - `UdcReferController` → `parseAndPaddingReferRestPath2Dto`
  - `UdcReferController` → `(Ljava/lang/String;)Lcom/seeyon/boot/starter/udcrt/proxy/dto/UdcRestPathParseDto;`
  - `UdcReferController` → `(Lcom/seeyon/boot/starter/udcrt/proxy/dto/UdcRestPathParseDto;)V`

### L-C-template（去重 109 条 / 载体 20 类）

- 载体类（前 12）: `AttachmentTemplateRtAppService`、`AttachmentTemplateController`、`AttachmentTemplateRtEntityDao`、`AttachmentTemplateRtEntity`、`ApproveFeatureService`、`AttachmentTemplateRtService`、`EntityRuntimeService`、`ExpressionEntityParamRtServiceImpl`、`UdcPageInfoMetaDataEnhancedService`、`AttachmentTemplateDto`、`BaseFlowDto`、`BpmProcessLaunchResultDto`
- **mapping-bearing 载体命中串（全列）**:
  - `AttachmentTemplateController` → `attachmentTemplateAppService`
  - `AttachmentTemplateController` → `Lcom/seeyon/boot/starter/udcrt/appservice/AttachmentTemplateRtAppService;`
  - `AttachmentTemplateController` → `Lcom/seeyon/boot/starter/udcrt/controller/AttachmentTemplateController;`
  - `AttachmentTemplateController` → `(Lcom/seeyon/boot/starter/udcrt/dto/AttachmentTemplateDto;)Lcom/seeyon/boot/transport/SingleResponse;`
  - `AttachmentTemplateController` → `attachmentTemplateDto`
  - `AttachmentTemplateController` → `Lcom/seeyon/boot/starter/udcrt/dto/AttachmentTemplateDto;`
  - `AttachmentTemplateController` → `(Lcom/seeyon/boot/starter/udcrt/dto/AttachmentTemplateDto;)Lcom/seeyon/boot/transport/SingleResponse<Lcom/seeyon/boot/starter/udcrt/dto/Atta`
  - `AttachmentTemplateController` → `Ljava/util/List<Lcom/seeyon/boot/starter/udcrt/dto/AttachmentTemplateDto;>;`
  - `AttachmentTemplateController` → `(Ljava/util/List<Lcom/seeyon/boot/starter/udcrt/dto/AttachmentTemplateDto;>;)Lcom/seeyon/boot/transport/ListResponse<Lcom/seeyon/boot/starte`
  - `AttachmentTemplateController` → `AttachmentTemplateController.java`
  - `AttachmentTemplateController` → `udc-runtime/attachment-template`
  - `AttachmentTemplateController` → `com/seeyon/boot/starter/udcrt/controller/AttachmentTemplateController`
  - `AttachmentTemplateController` → `com/seeyon/boot/starter/udcrt/appservice/AttachmentTemplateRtAppService`

### L-C-storage（去重 26 条 / 载体 9 类）

- 载体类（前 12）: `DisplayNameAppService`、`DynamicJarController`、`AttachmentTemplateRtEntity`、`ApproveFeatureService`、`AttachmentTemplateRtService`、`DynamicJarService`、`UdcEntityLogService`、`UdcSecretCheckService`、`AttachmentTemplateDto`
- **mapping-bearing 载体命中串（全列）**:
  - `DynamicJarController` → `storageKey`
  - `DynamicJarController` → `download appName:{},storageKey:{}`
  - `DynamicJarController` → `com/seeyon/boot/starter/file/storage/util/DownloadUtils`

### L-C-bucket（去重 3 条 / 载体 1 类）

- 载体类（前 12）: `FromAcrossService$DataFilterHandler`
- mapping-bearing 载体命中: **0**（全落在非 controller 位）

### L-C-stream（去重 448 条 / 载体 60 类）

- 载体类（前 12）: `CustomApplicationAppService`、`DisplayNameAppService`、`DynamicSelectAppService`、`MicroFlowProxyAppMicroFlow$InvokeMethodMetadata`、`PageCustomSearchAppService`、`ReferDynamicSelectAppService`、`UdcPageProxyAppService`、`UdcSerialConfigAppServiceImpl`、`UdcWaterMarkControlImpl`、`ColiDataUpgradeAppService`、`RuntimeCOLISplitController`、`UdcSerialConfigController`
- **mapping-bearing 载体命中串（全列）**:
  - `RuntimeCOLISplitController` → `getInputStream`
  - `RuntimeCOLISplitController` → `()Ljava/io/InputStream;`
  - `RuntimeCOLISplitController` → `(Ljava/io/InputStream;Ljava/lang/String;)Lcom/seeyon/boot/starter/file/dto/response/UploadResultDto;`
  - `UdcSerialConfigController` → `stream`
  - `UdcSerialConfigController` → `()Ljava/util/stream/Stream;`
  - `UdcSerialConfigController` → `java/util/stream/Stream`
  - `UdcSerialConfigController` → `(Ljava/util/function/Predicate;)Ljava/util/stream/Stream;`
  - `UdcSerialConfigController` → `(Ljava/util/function/Function;)Ljava/util/stream/Stream;`

### L-C-pic（去重 6 条 / 载体 5 类）

- 载体类（前 12）: `AppLoadEventListener`、`BpmRetryDelayMessage`、`BpmRetryListener`、`DeployChangeEventListener`、`OpinionBoxListener`
- mapping-bearing 载体命中: **0**（全落在非 controller 位）

### L-C-attach（去重 84 条 / 载体 10 类）

- 载体类（前 12）: `AttachmentTemplateRtAppService`、`AttachmentTemplateController`、`AttachmentTemplateRtEntityDao`、`AttachmentTemplateRtEntity`、`ApproveFeatureService`、`AttachmentTemplateRtService`、`UdcEntityLogService`、`UdcSecretCheckService`、`AttachmentTemplateDto`、`MicroFlowActivityTypeEnum`
- **mapping-bearing 载体命中串（全列）**:
  - `AttachmentTemplateController` → `attachmentTemplateAppService`
  - `AttachmentTemplateController` → `Lcom/seeyon/boot/starter/udcrt/appservice/AttachmentTemplateRtAppService;`
  - `AttachmentTemplateController` → `Lcom/seeyon/boot/starter/udcrt/controller/AttachmentTemplateController;`
  - `AttachmentTemplateController` → `(Lcom/seeyon/boot/starter/udcrt/dto/AttachmentTemplateDto;)Lcom/seeyon/boot/transport/SingleResponse;`
  - `AttachmentTemplateController` → `attachmentTemplateDto`
  - `AttachmentTemplateController` → `Lcom/seeyon/boot/starter/udcrt/dto/AttachmentTemplateDto;`
  - `AttachmentTemplateController` → `(Lcom/seeyon/boot/starter/udcrt/dto/AttachmentTemplateDto;)Lcom/seeyon/boot/transport/SingleResponse<Lcom/seeyon/boot/starter/udcrt/dto/Atta`
  - `AttachmentTemplateController` → `attachments`
  - `AttachmentTemplateController` → `Ljava/util/List<Lcom/seeyon/boot/starter/udcrt/dto/AttachmentTemplateDto;>;`
  - `AttachmentTemplateController` → `(Ljava/util/List<Lcom/seeyon/boot/starter/udcrt/dto/AttachmentTemplateDto;>;)Lcom/seeyon/boot/transport/ListResponse<Lcom/seeyon/boot/starte`
  - `AttachmentTemplateController` → `AttachmentTemplateController.java`
  - `AttachmentTemplateController` → `udc-runtime/attachment-template`
  - `AttachmentTemplateController` → `com/seeyon/boot/starter/udcrt/controller/AttachmentTemplateController`
  - `AttachmentTemplateController` → `com/seeyon/boot/starter/udcrt/appservice/AttachmentTemplateRtAppService`

### L-C-附件（去重 20 条 / 载体 7 类）

- 载体类（前 12）: `UdcWaterMarkControlImpl`、`AttachmentTemplateController`、`AttachmentTemplateRtEntity`、`ApproveFeatureService`、`AttachmentTemplateRtService`、`AttachmentTemplateDto`、`MicroFlowActivityTypeEnum`
- **mapping-bearing 载体命中串（全列）**:
  - `AttachmentTemplateController` → `创建附件模板记录`
  - `AttachmentTemplateController` → `批量创建创建附件模板记录`
  - `AttachmentTemplateController` → `根据guid获取附件模板记录`
  - `AttachmentTemplateController` → `附件模板guid`
  - `AttachmentTemplateController` → `根据guids获取附件模板记录(批量查询)`
  - `AttachmentTemplateController` → `根据appId获取附件模板记录`
  - `AttachmentTemplateController` → `根据guid删除附件模板记录`
  - `AttachmentTemplateController` → `根据guids删除附件模板记录(批量删除)`
  - `AttachmentTemplateController` → `运行态附件模板接口`

### L-C-文件（去重 14 条 / 载体 7 类）

- 载体类（前 12）: `ColiDataUpgradeAppService`、`RuntimeCOLISplitController`、`AttachmentTemplateRtEntity`、`DynamicJarService`、`FromAcrossService`、`ExcelDynamicExportDto`、`AppStartupChecker`
- **mapping-bearing 载体命中串（全列）**:
  - `RuntimeCOLISplitController` → `拆分结果文件上传`

### L-C-资源（去重 6 条 / 载体 4 类）

- 载体类（前 12）: `UdcWaterMarkControlImpl`、`UdcSerialConfigController`、`FromAcrossService`、`CustomApplicationListener`
- **mapping-bearing 载体命中串（全列）**:
  - `UdcSerialConfigController` → `页面资源注册错误：{}`
  - `UdcSerialConfigController` → `页面资源注册错误：查询不到对应页面资源(_serialNumber)`

### L-C-上传（去重 4 条 / 载体 4 类）

- 载体类（前 12）: `ColiDataUpgradeAppService`、`RuntimeCOLISplitController`、`DynamicJarService`、`MicroFlowActivityTypeEnum`
- **mapping-bearing 载体命中串（全列）**:
  - `RuntimeCOLISplitController` → `拆分结果文件上传`

### L-C-下载（去重 3 条 / 载体 3 类）

- 载体类（前 12）: `DynamicJarService`、`FromAcrossService`、`MicroFlowActivityTypeEnum`
- mapping-bearing 载体命中: **0**（全落在非 controller 位）

### L-C-模板（去重 18 条 / 载体 8 类）

- 载体类（前 12）: `AttachmentTemplateController`、`AttachmentTemplateRtEntity`、`ApproveFeatureService`、`AttachmentTemplateRtService`、`AttachmentTemplateDto`、`BaseFlowDto`、`ExcelDynamicExportDto`、`UdcPagesMetaDataSearchEnhancedDto`
- **mapping-bearing 载体命中串（全列）**:
  - `AttachmentTemplateController` → `创建附件模板记录`
  - `AttachmentTemplateController` → `批量创建创建附件模板记录`
  - `AttachmentTemplateController` → `根据guid获取附件模板记录`
  - `AttachmentTemplateController` → `附件模板guid`
  - `AttachmentTemplateController` → `根据guids获取附件模板记录(批量查询)`
  - `AttachmentTemplateController` → `根据appId获取附件模板记录`
  - `AttachmentTemplateController` → `根据guid删除附件模板记录`
  - `AttachmentTemplateController` → `根据guids删除附件模板记录(批量删除)`
  - `AttachmentTemplateController` → `运行态附件模板接口`

## 完备性三查 + 双口径一致性（r1_step5_completeness.json）

| 查 | 口径 | 结果 |
|---|---|---|
| A | `@RestController`/`@Controller` stereotype 类是否全在 mapping-bearing 集内 | controller 类 24；**bearing 集外 = 0** |
| A' | mapping-bearing 类中 `@interface`（元注解声明映射盲区） | 0 |
| A'' | 仅 `@Component`（非 controller）类数（旁证） | 36 |
| B | 全类常量池 `/` 开头字面量中的 resource 词干（端点表外新路径盲区） | 1 条: [['com.seeyon.boot.starter.udcrt.controller.DynamicJarController', '/download/{appName}']] |
| C | 双口径: 自实现 JVMS 解析 vs javap -p -v 已解码文本独立再提取（annotation, path 原值）集合等值 | 比对 27 类，**mismatch = 0** |

## resource 域判定（本 jar 内，数据驱动）

- 端点层含词干的行 = 10 条（GET 候选 5 / 写或非 GET 5）
  - CANDIDATE: `AttachmentTemplateController.selectByGuid` GetMapping（GET） ['{guid}']
  - CANDIDATE: `AttachmentTemplateController.selectByGuids` PostMapping（非 GET/查询形态） ['/select-by-guids']
  - CANDIDATE: `AttachmentTemplateController.selectByAppId` GetMapping（GET） ['/app/{appId}']
  - CANDIDATE: `DynamicJarController.downloadApp` PostMapping（非 GET/查询形态） ['/download/{appName}']
  - CANDIDATE: `DynamicJarController.download` GetMapping（GET） ['download']
  - EXCLUDED: `AttachmentTemplateController.create` PostMapping（写/非查询形态） ['/create']
  - EXCLUDED: `AttachmentTemplateController.createBatch` PostMapping（写/非查询形态） ['/create-batch']
  - EXCLUDED: `AttachmentTemplateController.delete` PostMapping（写/非查询形态） ['/delete/{guid}']
  - EXCLUDED: `AttachmentTemplateController.deleteByGuids` PostMapping（写/非查询形态） ['/delete-by-guids']
  - EXCLUDED: `RuntimeCOLISplitController.upload` PostMapping（写/非查询形态） ['upload/result']
- 类级基路径含词干者: `AttachmentTemplateController` = ['udc-runtime/attachment-template']；`FormAppMbController` = ['dynamic-rest/com-seeyon/{entityAppName}/mobile/{pageUrl}']；`FormAppPcController` = ['dynamic-rest/com-seeyon/{entityAppName}/{pageUrl}']
