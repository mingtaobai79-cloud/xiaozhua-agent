# udc-biz 代码生成模板与包结构（javap/zip 静态）

> JAR: udc-biz-5.3.517.jar | 来源: Artifactory libs-release

## 代码生成模板（464 个文件）

### 2.7/beanname（1）
- `AppBeanNameModifier.java.ftl`

### 2.7/common（12）
- `constants.ftl`
- `formula-param-map.ftl`
- `macro-appservice-approval.ftl`
- `macro-dto-entity.ftl`
- `macro-entity-attribute-check-not-null.ftl`
- `macro-entity-check.ftl`
- `macro-entity-trim.ftl`
- `macro-entity-update.ftl`
- `macro-formula-entity.ftl`
- `macro.ftl`
- `orgUtils.ftl`
- `utils.ftl`

### 2.7/dto（1）
- `dto.java.ftl`

### 2.7/entity（19）
- `appservice.java.ftl`
- `appserviceImpl.java.ftl`
- `baseservice.java.ftl`
- `controller.java.ftl`
- `dao.java.ftl`
- `dto.java.ftl`
- `entity.java.ftl`
- `mybatis.xml.ftl`
- `pageEntityController.java.ftl`
- `pagecontroller.java.ftl`
- `third/`
- `third/third_appservice.java.ftl`
- `third/third_appserviceImpl.java.ftl`
- `third/third_baseservice.java.ftl`
- `third/third_controller.java.ftl`
- `third/third_page_entity_controller.java.ftl`
- `tree/`
- `tree/tree-entity-page-refer-controller.ftl`
- `tree/tree-entity-refer-controller.ftl`

### 2.7/entityrule（10）
- `AssignValueActivity.ftl`
- `AttributeRequiredActivity.ftl`
- `AttributeUniqueActivity.ftl`
- `DefaultValueActivity.ftl`
- `ShowMessageActivity.ftl`
- `common/`
- `common/EntityRuleTemplateUtil.ftl`
- `common/SetValueUtil.ftl`
- `entityValueForRoot.ftl`
- `ruleservice.java.ftl`

### 2.7/enums（1）
- `enums.java.ftl`

### 2.7/event（7）
- `business-event.java.ftl`
- `defaultevent.json`
- `service/`
- `service/event.business.class[service].event[import].ftl`
- `service/event.business.class[service].ftl`
- `service/event.entity.class[service].event[import].ftl`
- `service/event.entity.class[service].ftl`

### 2.7/feature（12）
- `tree_entity/`
- `tree_entity/template/`
- `tree_entity/template/feature.tree.entity.class[app_service].ftl`
- `tree_entity/template/feature.tree.entity.class[app_service_impl].ftl`
- `tree_entity/template/feature.tree.entity.class[controller].ftl`
- `tree_entity/template/feature.tree.entity.class[dao].ftl`
- `tree_entity/template/feature.tree.entity.class[service].ftl`
- `tree_entity/template/feature.tree.entity.class[service].method[create].ftl`
- `tree_entity/template/feature.tree.entity.class[service].method[create][before].ftl`
- `tree_entity/template/feature.tree.entity.class[service].method[delete].ftl`
- `tree_entity/template/feature.tree.entity.class[service].method[update].ftl`
- `tree_entity/template/feature.tree.entity.class[service].method[update][after].ftl`

### 2.7/filterplan（1）
- `filter-plan-controller.java.ftl`

### 2.7/microflow（55）
- `BusinessEventActivity.java.ftl`
- `CallAppServiceActivity.java.ftl`
- `ChangeBatchEntityActivity.java.ftl`
- `ChangeEntityActivity.java.ftl`
- `ChangeList.java.ftl`
- `ChangeVariableActivity.java.ftl`
- `ConnectorActivity.java.ftl`
- `ConvertDataActivity.java.ftl`
- `CreateBatchEntityActivity.java.ftl`
- `CreateEntityActivity.java.ftl`
- `CreateList.java.ftl`
- `CreateMapActivity.java.ftl`
- `CreateVariableActivity.java.ftl`
- `DataMappingActivity.java.ftl`
- `DeleteEntityActivity.java.ftl`
- `ListOperationActivity.java.ftl`
- `MapOperationActivity.java.ftl`
- `MicroFlowDomainService.java.ftl`
- `RetrieveActivity.java.ftl`
- `RetrieveArrayActivity.java.ftl`
- `SubMicroFlowActivity.java.ftl`
- `common/`
- `common/CallMethodUtil.java.ftl`
- `common/CommonUtil.java.ftl`
- `common/LogUtil.java.ftl`
- `common/MapUtil.java.ftl`
- `common/SetActionTypeUtil.java.ftl`
- `common/ValueUtil.java.ftl`
- `customerror/`
- `customerror/CustomError.java.ftl`
- `customerror/CustomErrorI18nCN.ftl`
- `customerror/CustomErrorI18nEN.ftl`
- `customerror/CustomErrorI18nTW.ftl`
- `customflow/`
- `customflow/CustomMicroFlowAppService.java.ftl`
- `customflow/CustomMicroFlowController.java.ftl`
- `event/`
- `event/BusinessEventListener.java.ftl`
- `event/ConnectorBusinessEventListener.java.ftl`
- `plugin/`
- `plugin/calldataflow/`
- `plugin/calldataflow/CallDataFlowActivity.java.ftl`
- `plugin/calldataflow/CallDataFlowActivityDI.ftl`
- `plugin/calldataflow/CallDataFlowActivityImport.ftl`
- `schedule/`
- `schedule/MicroFlowSchedule.java.ftl`
- `third/`
- `third/dynamicSearch.java.ftl`
- `web/`
- `web/MicroFlowAppService.java.ftl`
- `web/MicroFlowAppServiceImpl.java.ftl`
- `web/MicroFlowController.java.ftl`
- `web/host/`
- `web/host/HostAppMicroFlowAppServiceImpl.java.ftl`
- `web/host/HostAppMicroFlowController.java.ftl`

### 2.7/project（20）
- `backend/`
- `backend/${appName}-assemble/`
- `backend/${appName}-assemble/pom.xml.ftl`
- `backend/${appName}-assemble/src/`
- `backend/${appName}-assemble/src/main/`
- `backend/${appName}-assemble/src/main/java/`
- `backend/${appName}-assemble/src/main/java/${appPath}/`
- `backend/${appName}-assemble/src/main/java/${appPath}/Application.java.ftl`
- `backend/${appName}-assemble/src/main/resources/`
- `backend/${appName}-assemble/src/main/resources/application.yaml.ftl`
- `backend/${appName}-assemble/src/main/resources/build-info.json.ftl`
- `backend/${appName}-biz/`
- `backend/${appName}-biz/pom.xml.ftl`
- `backend/${appName}-facade/`
- `backend/${appName}-facade/pom.xml.ftl`
- `backend/${appName}-web/`
- `backend/${appName}-web/pom.xml.ftl`
- `backend/.gitignore.ftl`
- `backend/README.md.ftl`
- `backend/pom.xml.ftl`

### 2.7/refer（2）
- `entity-refer-controller.java.ftl`
- `page-refer-controller.java.ftl`

### 2.7/referconfig（2）
- `page_config.json.ftl`
- `refer_config.json.ftl`

### 2.8/app（2）
- `AppInfoController.java.ftl`
- `AppInfoService.java.ftl`

### 2.8/beanname（1）
- `AppBeanNameModifier.java.ftl`

### 2.8/common（13）
- `constants.ftl`
- `formula-param-map.ftl`
- `macro-appservice-approval.ftl`
- `macro-dto-entity.ftl`
- `macro-entity-attribute-check-not-null.ftl`
- `macro-entity-check.ftl`
- `macro-entity-trim.ftl`
- `macro-entity-update.ftl`
- `macro-formula-entity.ftl`
- `macro.ftl`
- `orgUtils.ftl`
- `reliable-invoker-helper.ftl`
- `utils.ftl`

### 2.8/dto（1）
- `dto.java.ftl`

### 2.8/entity（25）
- `appservice.java.ftl`
- `appserviceImpl.java.ftl`
- `baseservice.java.ftl`
- `controller.java.ftl`
- `dao.java.ftl`
- `dto.java.ftl`
- `dynamicdependency/`
- `dynamicdependency/outAppAppServiceProxy.java.ftl`
- `entity.java.ftl`
- `mybatis.xml.ftl`
- `pageCustomControllerDto.java.ftl`
- `pageEntityController.java.ftl`
- `pageEntityController2.java.ftl`
- `pagecontroller.java.ftl`
- `third/`
- `third/third_appservice.java.ftl`
- `third/third_appserviceImpl.java.ftl`
- `third/third_baseservice.java.ftl`
- `third/third_controller.java.ftl`
- `third/third_page_entity_controller.java.ftl`
- `tree/`
- `tree/tree-entity-page-refer-controller.ftl`
- `tree/tree-entity-refer-controller.ftl`
- `tree/tree-page-controller-fragment.ftl`
- `tree/tree-refer-controller-fragment.ftl`

### 2.8/entityrule（10）
- `AssignValueActivity.ftl`
- `AttributeRequiredActivity.ftl`
- `AttributeUniqueActivity.ftl`
- `DefaultValueActivity.ftl`
- `ShowMessageActivity.ftl`
- `common/`
- `common/EntityRuleTemplateUtil.ftl`
- `common/SetValueUtil.ftl`
- `entityValueForRoot.ftl`
- `ruleservice.java.ftl`

### 2.8/enums（1）
- `enums.java.ftl`

### 2.8/event（7）
- `business-event.java.ftl`
- `defaultevent.json`
- `service/`
- `service/event.business.class[service].event[import].ftl`
- `service/event.business.class[service].ftl`
- `service/event.entity.class[service].event[import].ftl`
- `service/event.entity.class[service].ftl`

### 2.8/feature（12）
- `tree_entity/`
- `tree_entity/template/`
- `tree_entity/template/feature.tree.entity.class[app_service].ftl`
- `tree_entity/template/feature.tree.entity.class[app_service_impl].ftl`
- `tree_entity/template/feature.tree.entity.class[controller].ftl`
- `tree_entity/template/feature.tree.entity.class[dao].ftl`
- `tree_entity/template/feature.tree.entity.class[service].ftl`
- `tree_entity/template/feature.tree.entity.class[service].method[create].ftl`
- `tree_entity/template/feature.tree.entity.class[service].method[create][before].ftl`
- `tree_entity/template/feature.tree.entity.class[service].method[delete].ftl`
- `tree_entity/template/feature.tree.entity.class[service].method[update].ftl`
- `tree_entity/template/feature.tree.entity.class[service].method[update][after].ftl`

### 2.8/filterplan（2）
- `filter-plan-controller-fragment.java.ftl`
- `filter-plan-controller.java.ftl`

### 2.8/microflow（59）
- `BusinessEventActivity.java.ftl`
- `CallAppServiceActivity.java.ftl`
- `ChangeBatchEntityActivity.java.ftl`
- `ChangeEntityActivity.java.ftl`
- `ChangeList.java.ftl`
- `ChangeVariableActivity.java.ftl`
- `ConnectorActivity.java.ftl`
- `ConvertDataActivity.java.ftl`
- `CreateBatchEntityActivity.java.ftl`
- `CreateEntityActivity.java.ftl`
- `CreateList.java.ftl`
- `CreateMapActivity.java.ftl`
- `CreateVariableActivity.java.ftl`
- `DataMappingActivity.java.ftl`
- `DeleteEntityActivity.java.ftl`
- `ListOperationActivity.java.ftl`
- `MapOperationActivity.java.ftl`
- `MicroFlowDomainService.java.ftl`
- `RetrieveActivity.java.ftl`
- `RetrieveArrayActivity.java.ftl`
- `SubMicroFlowActivity.java.ftl`
- `common/`
- `common/CallMethodUtil.java.ftl`
- `common/CommonUtil.java.ftl`
- `common/GenericInvokeUtil.java.ftl`
- `common/ListActivityUtil.java.ftl`
- `common/LogUtil.java.ftl`
- `common/MapUtil.java.ftl`
- `common/SetActionTypeUtil.java.ftl`
- `common/ValueUtil.java.ftl`
- `customerror/`
- `customerror/CustomError.java.ftl`
- `customerror/CustomErrorI18nCN.ftl`
- `customerror/CustomErrorI18nEN.ftl`
- `customerror/CustomErrorI18nTW.ftl`
- `customflow/`
- `customflow/CustomMicroFlowAppService.java.ftl`
- `customflow/CustomMicroFlowController.java.ftl`
- `event/`
- `event/BusinessEventListener.java.ftl`
- `event/ConnectorBusinessEventListener.java.ftl`
- `plugin/`
- `plugin/calldataflow/`
- `plugin/calldataflow/CallDataFlowActivity.java.ftl`
- `plugin/calldataflow/CallDataFlowActivityDI.ftl`
- `plugin/calldataflow/CallDataFlowActivityImport.ftl`
- `schedule/`
- `schedule/MicroFlowSchedule.java.ftl`
- `third/`
- `third/dynamicSearch.java.ftl`
- `web/`
- `web/MicroFlowAppService.java.ftl`
- `web/MicroFlowAppServiceImpl.java.ftl`
- `web/MicroFlowController.java.ftl`
- `web/host/`
- `web/host/HostAppMicroFlowAppServiceImpl.java.ftl`
- `web/host/HostAppMicroFlowController.java.ftl`
- `web/util/`
- `web/util/GraphQLControllerUtil.java.ftl`

### 2.8/project（19）
- `backend/`
- `backend/${appName}-assemble/`
- `backend/${appName}-assemble/pom.xml.ftl`
- `backend/${appName}-assemble/src/`
- `backend/${appName}-assemble/src/main/`
- `backend/${appName}-assemble/src/main/java/`
- `backend/${appName}-assemble/src/main/java/${appPath}/`
- `backend/${appName}-assemble/src/main/java/${appPath}/Application.java.ftl`
- `backend/${appName}-assemble/src/main/resources/`
- `backend/${appName}-assemble/src/main/resources/application.y.ftl`
- `backend/${appName}-biz/`
- `backend/${appName}-biz/pom.xml.ftl`
- `backend/${appName}-facade/`
- `backend/${appName}-facade/pom.xml.ftl`
- `backend/${appName}-web/`
- `backend/${appName}-web/pom.xml.ftl`
- `backend/.gitignore.ftl`
- `backend/README.md.ftl`
- `backend/pom.xml.ftl`

### 2.8/refer（4）
- `entity-refer-controller.java.ftl`
- `entity-refer-controller2.java.ftl`
- `page-refer-controller-fragment.java.ftl`
- `page-refer-controller.java.ftl`

### 2.8/referconfig（2）
- `page_config.json.ftl`
- `refer_config.json.ftl`

### 2.9/beanname（1）
- `AppBeanNameModifier.java.ftl`

### 2.9/common（13）
- `constants.ftl`
- `formula-param-map.ftl`
- `macro-appservice-approval.ftl`
- `macro-dto-entity.ftl`
- `macro-entity-attribute-check-not-null.ftl`
- `macro-entity-check.ftl`
- `macro-entity-trim.ftl`
- `macro-entity-update.ftl`
- `macro-formula-entity.ftl`
- `macro.ftl`
- `orgUtils.ftl`
- `reliable-invoker-helper.ftl`
- `utils.ftl`

### 2.9/dto（1）
- `dto.java.ftl`

### 2.9/entity（24）
- `appservice.java.ftl`
- `appserviceImpl.java.ftl`
- `baseservice.java.ftl`
- `controller.java.ftl`
- `dao.java.ftl`
- `dto.java.ftl`
- `dynamicdependency/`
- `dynamicdependency/outAppAppServiceProxy.java.ftl`
- `mybatis.xml.ftl`
- `pageCustomControllerDto.java.ftl`
- `pageEntityController.java.ftl`
- `pageEntityController2.java.ftl`
- `pagecontroller.java.ftl`
- `third/`
- `third/third_appservice.java.ftl`
- `third/third_appserviceImpl.java.ftl`
- `third/third_baseservice.java.ftl`
- `third/third_controller.java.ftl`
- `third/third_page_entity_controller.java.ftl`
- `tree/`
- `tree/tree-entity-page-refer-controller.ftl`
- `tree/tree-entity-refer-controller.ftl`
- `tree/tree-page-controller-fragment.ftl`
- `tree/tree-refer-controller-fragment.ftl`

### 2.9/entityrule（10）
- `AssignValueActivity.ftl`
- `AttributeRequiredActivity.ftl`
- `AttributeUniqueActivity.ftl`
- `DefaultValueActivity.ftl`
- `ShowMessageActivity.ftl`
- `common/`
- `common/EntityRuleTemplateUtil.ftl`
- `common/SetValueUtil.ftl`
- `entityValueForRoot.ftl`
- `ruleservice.java.ftl`

### 2.9/enums（1）
- `enums.java.ftl`

### 2.9/event（7）
- `business-event.java.ftl`
- `defaultevent.json`
- `service/`
- `service/event.business.class[service].event[import].ftl`
- `service/event.business.class[service].ftl`
- `service/event.entity.class[service].event[import].ftl`
- `service/event.entity.class[service].ftl`

### 2.9/feature（12）
- `tree_entity/`
- `tree_entity/template/`
- `tree_entity/template/feature.tree.entity.class[app_service].ftl`
- `tree_entity/template/feature.tree.entity.class[app_service_impl].ftl`
- `tree_entity/template/feature.tree.entity.class[controller].ftl`
- `tree_entity/template/feature.tree.entity.class[dao].ftl`
- `tree_entity/template/feature.tree.entity.class[service].ftl`
- `tree_entity/template/feature.tree.entity.class[service].method[create].ftl`
- `tree_entity/template/feature.tree.entity.class[service].method[create][before].ftl`
- `tree_entity/template/feature.tree.entity.class[service].method[delete].ftl`
- `tree_entity/template/feature.tree.entity.class[service].method[update].ftl`
- `tree_entity/template/feature.tree.entity.class[service].method[update][after].ftl`

### 2.9/filterplan（2）
- `filter-plan-controller-fragment.java.ftl`
- `filter-plan-controller.java.ftl`

### 2.9/microflow（65）
- `BusinessEventActivity.java.ftl`
- `CallAppServiceActivity.java.ftl`
- `ChangeBatchEntityActivity.java.ftl`
- `ChangeEntityActivity.java.ftl`
- `ChangeList.java.ftl`
- `ChangeVariableActivity.java.ftl`
- `ConnectorActivity.java.ftl`
- `ConvertDataActivity.java.ftl`
- `CreateBatchEntityActivity.java.ftl`
- `CreateEntityActivity.java.ftl`
- `CreateList.java.ftl`
- `CreateMapActivity.java.ftl`
- `CreateVariableActivity.java.ftl`
- `DataMappingActivity.java.ftl`
- `DeleteEntityActivity.java.ftl`
- `ListOperationActivity.java.ftl`
- `MapOperationActivity.java.ftl`
- `MicroFlowDomainService.java.ftl`
- `RetrieveActivity.java.ftl`
- `RetrieveArrayActivity.java.ftl`
- `SubMicroFlowActivity.java.ftl`
- `common/`
- `common/CallMethodUtil.java.ftl`
- `common/CommonUtil.java.ftl`
- `common/GenericInvokeUtil.java.ftl`
- `common/ListActivityUtil.java.ftl`
- `common/LogUtil.java.ftl`
- `common/MapUtil.java.ftl`
- `common/SetActionTypeUtil.java.ftl`
- `common/ValueUtil.java.ftl`
- `customerror/`
- `customerror/CustomError.java.ftl`
- `customerror/CustomErrorI18nCN.ftl`
- `customerror/CustomErrorI18nEN.ftl`
- `customerror/CustomErrorI18nTW.ftl`
- `customflow/`
- `customflow/CustomMicroFlowAppService.java.ftl`
- `customflow/CustomMicroFlowController.java.ftl`
- `customflow/CustomMicroFlowService.java.ftl`
- `customflow/DefaultCustomMicroFlowAppServiceImpl.java.ftl`
- `customflow/DefaultCustomMicroFlowBeanDefinitionRegistryPostProcessor.java.ftl`
- `customflow/DefaultCustomMicroFlowConfig.java.ftl`
- `customflow/MicroFlowDubboExportBeanPostProcessor.java.ftl`
- `event/`
- `event/BusinessEventListener.java.ftl`
- `event/ConnectorBusinessEventListener.java.ftl`
- `plugin/`
- `plugin/calldataflow/`
- `plugin/calldataflow/CallDataFlowActivity.java.ftl`
- `plugin/calldataflow/CallDataFlowActivityDI.ftl`
- `plugin/calldataflow/CallDataFlowActivityImport.ftl`
- `schedule/`
- `schedule/MicroFlowSchedule.java.ftl`
- `third/`
- `third/dynamicSearch.java.ftl`
- `web/`
- `web/CustomRestApiMicroFlowController.java.ftl`
- `web/MicroFlowAppService.java.ftl`
- `web/MicroFlowAppServiceImpl.java.ftl`
- `web/MicroFlowController.java.ftl`
- `web/host/`
- `web/host/HostAppMicroFlowAppServiceImpl.java.ftl`
- `web/host/HostAppMicroFlowController.java.ftl`
- `web/util/`
- `web/util/GraphQLControllerUtil.java.ftl`

### 2.9/project（19）
- `backend/`
- `backend/${appName}-assemble/`
- `backend/${appName}-assemble/pom.xml.ftl`
- `backend/${appName}-assemble/src/`
- `backend/${appName}-assemble/src/main/`
- `backend/${appName}-assemble/src/main/java/`
- `backend/${appName}-assemble/src/main/java/${appPath}/`
- `backend/${appName}-assemble/src/main/java/${appPath}/Application.java.ftl`
- `backend/${appName}-assemble/src/main/resources/`
- `backend/${appName}-assemble/src/main/resources/application.y.ftl`
- `backend/${appName}-biz/`
- `backend/${appName}-biz/pom.xml.ftl`
- `backend/${appName}-facade/`
- `backend/${appName}-facade/pom.xml.ftl`
- `backend/${appName}-web/`
- `backend/${appName}-web/pom.xml.ftl`
- `backend/.gitignore.ftl`
- `backend/README.md.ftl`
- `backend/pom.xml.ftl`

### 2.9/refer（4）
- `entity-refer-controller.java.ftl`
- `entity-refer-controller2.java.ftl`
- `page-refer-controller-fragment.java.ftl`
- `page-refer-controller.java.ftl`

### 2.9/referconfig（2）
- `page_config.json.ftl`
- `refer_config.json.ftl`

### 3.0/entity（2）
- `baseservice.java.ftl`
- `entity.java.ftl`

## 包结构（class 计数）

| 包 | class 数 |
|---|---|
| com/seeyon/udc/detection/task | 270 |
| com/seeyon/udc/microflow/domain | 175 |
| com/seeyon/udc/autocode/transport | 102 |
| com/seeyon/udc/entity/domain | 93 |
| com/seeyon/udc/autocode/v27 | 92 |
| com/seeyon/udc/page/domain | 82 |
| com/seeyon/udc/microflow/cascade | 78 |
| com/seeyon/udc/appservice | 71 |
| com/seeyon/udc/microflow/dto | 56 |
| com/seeyon/udc/expression/codegen | 56 |
| com/seeyon/udc/dto | 54 |
| com/seeyon/udc/autocode/task | 50 |
| com/seeyon/udc/entity/stereotype | 49 |
| com/seeyon/udc/model/parser | 49 |
| com/seeyon/udc/common/autocode | 48 |
| com/seeyon/udc/parser | 42 |
| com/seeyon/udc/autocode/metadata | 40 |
| com/seeyon/udc/microflow/util | 38 |
| com/seeyon/udc/utils | 35 |
| com/seeyon/udc/microflow/refactor | 33 |
| com/seeyon/udc/enums/microflow | 33 |
| com/seeyon/udc/auth/impl | 32 |
| com/seeyon/udc/autocode/template | 31 |
| com/seeyon/udc/api | 29 |
| com/seeyon/udc/expression/domain | 26 |
| com/seeyon/udc/microflow/functional | 24 |
| com/seeyon/udc/page/dto | 23 |
| com/seeyon/udc/entity/util | 22 |
| com/seeyon/udc/model/repository | 21 |
| com/seeyon/udc/metadata/query | 19 |
| com/seeyon/udc/enums | 19 |
| com/seeyon/udc/detection/context | 18 |
| com/seeyon/udc/microflow/common | 17 |
| com/seeyon/udc/common/validation | 16 |
| com/seeyon/udc/metadata/convert | 16 |
| com/seeyon/udc/exception | 15 |
| com/seeyon/udc/entity/dto | 13 |
| com/seeyon/udc/entity/copy | 13 |
| com/seeyon/udc/document | 13 |
| com/seeyon/udc/common/enums | 12 |
| com/seeyon/udc/domain/event | 12 |
| com/seeyon/udc/autocode | 11 |
| com/seeyon/udc/common/concurrent | 11 |
| com/seeyon/udc/system/domain | 11 |
| com/seeyon/udc/autocode/util | 10 |
| com/seeyon/udc/page/enums | 10 |
| com/seeyon/udc/system/dto | 10 |
| com/seeyon/udc/autocode/db | 9 |
| com/seeyon/udc/microflow/constant | 9 |
| com/seeyon/udc/auth/common | 8 |
| com/seeyon/udc/entity/transfer | 8 |
| com/seeyon/udc/common/application | 8 |
| com/seeyon/udc/detection | 8 |
| com/seeyon/udc/microflow/upgrade | 7 |
| com/seeyon/udc/common | 7 |
| com/seeyon/udc/detection/deploy | 7 |
| com/seeyon/udc/datatype/domain | 7 |
| com/seeyon/udc/page/util | 7 |
| com/seeyon/udc/compatibility/generator | 7 |
| com/seeyon/udc/compatibility/output | 7 |
| com/seeyon/udc/cache | 7 |
| com/seeyon/udc/system/sync | 7 |
| com/seeyon/udc/limit | 7 |
| com/seeyon/udc/autocode/interceptor | 6 |
| com/seeyon/udc/metadata/page | 6 |
| com/seeyon/udc/microflow/event | 5 |
| com/seeyon/udc/collaboration/filter | 5 |
| com/seeyon/udc/detection/listener | 5 |
| com/seeyon/udc/operationlog/dto | 5 |
| com/seeyon/udc/datatype | 5 |
| com/seeyon/udc/domain/listener | 5 |
| com/seeyon/udc/microflow/preset | 4 |
| com/seeyon/udc/collaboration/domain | 4 |
| com/seeyon/udc/auth | 4 |
| com/seeyon/udc/entity/listener | 4 |
| com/seeyon/udc/model | 4 |
| com/seeyon/udc/common/utils | 4 |
| com/seeyon/udc/metadata/utils | 4 |
| com/seeyon/udc/jackson/util | 4 |
| com/seeyon/udc/dependency/dto | 4 |
| com/seeyon/udc/dependency | 4 |
| com/seeyon/udc/deployment | 4 |
| com/seeyon/udc/autocode/form | 3 |
| com/seeyon/udc/autocode/i18n | 3 |
| com/seeyon/udc/microflow/collector | 3 |
| com/seeyon/udc/microflow | 3 |
| com/seeyon/udc/entity | 3 |
| com/seeyon/udc/operationlog/domain | 3 |
| com/seeyon/udc/metadata/app | 3 |
| com/seeyon/udc/metadata/dto | 3 |
| com/seeyon/udc/compatibility | 3 |
| com/seeyon/udc/domain/service | 3 |
| com/seeyon/udc/parameter/domain | 3 |
| com/seeyon/udc/attachment/domain | 3 |
| com/seeyon/udc/autocode/config | 2 |
| com/seeyon/udc/autocode/cache | 2 |
| com/seeyon/udc/model/domain | 2 |
| com/seeyon/udc/common/properties | 2 |
| com/seeyon/udc/common/detection | 2 |
| com/seeyon/udc/detection/config | 2 |
| com/seeyon/udc/detection/annotation | 2 |
| com/seeyon/udc/operationlog/aspect | 2 |
| com/seeyon/udc/multiedit/dto | 2 |
| com/seeyon/udc/expression/functions | 2 |
| com/seeyon/udc/system/enums | 2 |
| com/seeyon/udc/limit/dto | 2 |
| com/seeyon/udc/basicdata/commom | 2 |
| com/seeyon/udc/deployment/listener | 2 |
| com/seeyon/udc/autocode/file | 1 |
| com/seeyon/udc/microflow/operationLog | 1 |
| com/seeyon/udc/microflow/parse | 1 |
| com/seeyon/udc/microflow/support | 1 |
| com/seeyon/udc/collaboration/util | 1 |
| com/seeyon/udc/collaboration/common | 1 |
| com/seeyon/udc/collaboration/listener | 1 |
| com/seeyon/udc/auth/constant | 1 |
| com/seeyon/udc/auth/lateral | 1 |
| com/seeyon/udc/auth/util | 1 |
| com/seeyon/udc/auth/publish | 1 |
| com/seeyon/udc/entity/preset | 1 |
| com/seeyon/udc/entity/collector | 1 |
| com/seeyon/udc/model/listener | 1 |
| com/seeyon/udc/detection/websocket | 1 |
| com/seeyon/udc/detection/aspect | 1 |
| com/seeyon/udc/log/api | 1 |
| com/seeyon/udc/log/service | 1 |
| com/seeyon/udc/operationlog/job | 1 |
| com/seeyon/udc/operationlog | 1 |
| com/seeyon/udc/datatype/util | 1 |
| com/seeyon/udc/page/bo | 1 |
| com/seeyon/udc/page/constant | 1 |
| com/seeyon/udc/metadata/attribute | 1 |
| com/seeyon/udc/metadata/constant | 1 |
| com/seeyon/udc/multiedit/config | 1 |
| com/seeyon/udc/multiedit/websocket | 1 |
| com/seeyon/udc/multiedit/redis | 1 |
| com/seeyon/udc/multiedit/error | 1 |
| com/seeyon/udc/multiedit/constant | 1 |
| com/seeyon/udc/jackson/resolver | 1 |
| com/seeyon/udc/dependency/microflow | 1 |
| com/seeyon/udc/system/constants | 1 |
| com/seeyon/udc/system | 1 |
| com/seeyon/udc/config/dto | 1 |
| com/seeyon/udc/config | 1 |
| com/seeyon/udc/websocket | 1 |
| com/seeyon/udc/parameter/dto | 1 |
| com/seeyon/udc/limit/impl | 1 |
| com/seeyon/udc/deployment/service | 1 |
| com/seeyon/udc/attachment/dto | 1 |
