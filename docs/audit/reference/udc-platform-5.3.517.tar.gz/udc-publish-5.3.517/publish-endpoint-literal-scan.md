# udc-publish-5.3.517｜publish 域三层扫描原始证据表（L-A / L-B / L-C）

- 证据单元: 单 jar `udc-starter-runtime-5.3.517.jar`（任务声明构件，非 BI 先例的 6 jar 口径）
- jar 绝对路径: `D:/repo/CHIT/com/seeyon/udc-starter-runtime/5.3.517/udc-starter-runtime-5.3.517.jar`
- jar sha256: `74ae50bd8510414113248f0b1d400bca80d2ae2e0022c9dbbb31321a6040a66f`（861880 B）
- class 条目: 346（.class 口径含 `$` 内部类）／顶层类去 `$` = 307／非 class 资源条目 126
- 生成脚本: `r1_scan_mapping_bearing.py`（L-A/L-B/L-C 扫描）→ `r1_step1_raw.json`；`r1_javap_dump.py` → `r1-<Class>.javap.txt` + `r1_step3_dump_report.json`；`r1_completeness_checks.py` → `r1_step5_completeness.json`；本文件由 `r1_build_report.py` 生成
- 生成时刻(UTC): 2026-10-08T14:37:26.801644+00:00
- 解析错误类数: 0

## L-A 类名层（346 class 全量 × 宽口径关键词子串）

| 关键词 | 命中数 | 全限定类名 |
|---|---|---|
| `publish` | 7 | `com.seeyon.boot.starter.udcrt.event.publisher.EventPublisher$EventPhase`<br>`com.seeyon.boot.starter.udcrt.event.publisher.EventPublisher`<br>`com.seeyon.boot.starter.udcrt.event.publisher.EventPublisherHelper`<br>`com.seeyon.boot.starter.udcrt.event.publisher.impl.BusinessEventPublisher$1`<br>`com.seeyon.boot.starter.udcrt.event.publisher.impl.BusinessEventPublisher`<br>`com.seeyon.boot.starter.udcrt.event.publisher.impl.EntityEventPublisher$1`<br>`com.seeyon.boot.starter.udcrt.event.publisher.impl.EntityEventPublisher` |
| `deploy` | 3 | `com.seeyon.boot.starter.udcrt.api.DeployNoticeService`<br>`com.seeyon.boot.starter.udcrt.dto.CustomApplicationUpdateDeployStateDto`<br>`com.seeyon.boot.starter.udcrt.mq.DeployChangeEventListener` |
| `pub` | 7 | `com.seeyon.boot.starter.udcrt.event.publisher.EventPublisher$EventPhase`<br>`com.seeyon.boot.starter.udcrt.event.publisher.EventPublisher`<br>`com.seeyon.boot.starter.udcrt.event.publisher.EventPublisherHelper`<br>`com.seeyon.boot.starter.udcrt.event.publisher.impl.BusinessEventPublisher$1`<br>`com.seeyon.boot.starter.udcrt.event.publisher.impl.BusinessEventPublisher`<br>`com.seeyon.boot.starter.udcrt.event.publisher.impl.EntityEventPublisher$1`<br>`com.seeyon.boot.starter.udcrt.event.publisher.impl.EntityEventPublisher` |
| `notice` | 1 | `com.seeyon.boot.starter.udcrt.api.DeployNoticeService` |

- 命中汇总: 强词干 publish 7 / deploy 3；弱词干 pub 7 / notice 1；其余词干 0
- 类名层判定: **0 个 controller 类名承载 publish/deploy 域**——命中的 7 个 `event.publisher.*`为**事件发布器（EventPublisher 族，消息/业务事件投递工具类）**，2 个 `Deploy*`（`api.DeployNoticeService` 部署通知接口、`mq.DeployChangeEventListener` 部署变更 MQ 监听）与 1 个 `dto.CustomApplicationUpdateDeployStateDto` 均为服务/监听/DTO 层且非 mapping-bearing 类（见 L-B 表：三者均不在 27 个 mapping-bearing 类内）。`pub` 命中与 `publish` 命中为同 7 个类（子串关系）。

## L-B 端点路径字面量层

- mapping-bearing 类（按映射注解描述符筛，口径②）: **27** 个；端点行 **131** 条（类级基路径 24 行 + 方法级 131 行）
- 「常量池中以 `/` 开头字面量」兜底口径: **40** 条（其中含 publish/deploy 词干者 1 条: [['com.seeyon.boot.starter.udcrt.controller.CustomApplicationController', '/update-deploy-state']]）

### L-B-1 mapping-bearing 类清单（27）

| # | 类（class_sha256 前 12） | class_bytes | stereotype | 类级基路径原值 | 方法级端点数 | javap 证据件 |
|---|---|---|---|---|---|---|
| 1 | `com.seeyon.boot.starter.udcrt.controller.AppDraftController`<br>`5090304dcb69cd0d3cd7b4e961d6ceff5f41e56d27b60eecf48950a34e5fabb9` | 3704 | RestController | `udc-runtime/app-draft` | 6 | `r1-AppDraftController.javap.txt` |
| 2 | `com.seeyon.boot.starter.udcrt.controller.AttachmentTemplateController`<br>`72241cb3ae302c91cd3baba690eaa25656adcedc13e7cdf25413deebd31444f3` | 4744 | RestController | `udc-runtime/attachment-template` | 7 | `r1-AttachmentTemplateController.javap.txt` |
| 3 | `com.seeyon.boot.starter.udcrt.controller.CustomApplicationController`<br>`d3e82d8bbc65dc92d5f9d30532159f1d10169f2aef1eae6ab67c70d7ad75ae55` | 13271 | RestController | `udc-runtime/custom-app` | 13 | `r1-CustomApplicationController.javap.txt` |
| 4 | `com.seeyon.boot.starter.udcrt.controller.DynamicJarController`<br>`0eb1fd79e96e09eb0122c0aafd77d8922ee3163f46f5436a44c98b476726def2` | 5796 | RestController | `udc-runtime/dynamic/jar` | 4 | `r1-DynamicJarController.javap.txt` |
| 5 | `com.seeyon.boot.starter.udcrt.controller.FrontFunctionSupportController`<br>`c9be69ceb85a8c8e6e171b4f494c2d3124d9a08283b8cebfebca43e2a7db5f8a` | 1931 | RestController | `udc-runtime/function-support` | 1 | `r1-FrontFunctionSupportController.javap.txt` |
| 6 | `com.seeyon.boot.starter.udcrt.controller.GraphqlProxyController`<br>`a83c2355e040c799eddd152c43ad2d4dbc0ceb3cae444bfb892b785c5a6bcb56` | 1865 | RestController | `udc-runtime/graphql-proxy` | 1 | `r1-GraphqlProxyController.javap.txt` |
| 7 | `com.seeyon.boot.starter.udcrt.controller.RuntimeCOLISplitController`<br>`9033611697ec83af8f8853d870ea85334bacaf02e44ea2cecbb07e46881fa7c5` | 3267 | RestController | `udc-runtime/coli` | 2 | `r1-RuntimeCOLISplitController.javap.txt` |
| 8 | `com.seeyon.boot.starter.udcrt.controller.RuntimeEnvCheckController`<br>`86e4598cd2124e8bc0f280b17e7e9965d626acb5a0adb9b5a80026d41c193582` | 11474 | RestController | `udc-runtime/evn-check` | 5 | `r1-RuntimeEnvCheckController.javap.txt` |
| 9 | `com.seeyon.boot.starter.udcrt.controller.UdcAppLogController`<br>`f6a2111d3f5fd28b7c84d7eb1dddacd42ca38ffa0be194f2c34550faed2ee775` | 13089 | RestController | `udc-runtime/app-log` | 19 | `r1-UdcAppLogController.javap.txt` |
| 10 | `com.seeyon.boot.starter.udcrt.controller.UdcAttrSnapshotRtController`<br>`2cbd39885b7621d0539794c00650aa50831aa8e681ef06ef185cd6f922c07784` | 2473 | RestController | `udc-runtime/attr-snapshot` | 2 | `r1-UdcAttrSnapshotRtController.javap.txt` |
| 11 | `com.seeyon.boot.starter.udcrt.controller.UdcDataTypeController`<br>`03b3977b50574208eaad2b1925a80520a4686b268a56bacd35b87a144854bc38` | 1787 | RestController | `udc-runtime/datatype` | 1 | `r1-UdcDataTypeController.javap.txt` |
| 12 | `com.seeyon.boot.starter.udcrt.controller.UdcEntityUpdateRtTestController`<br>`612f6be8b1d46604be02fb2da348f38363b0ac9f7ecb87803ff8b108beddfc72` | 3404 | RestController | `udc-runtime/update-test` | 1 | `r1-UdcEntityUpdateRtTestController.javap.txt` |
| 13 | `com.seeyon.boot.starter.udcrt.controller.UdcFormDataQueryController`<br>`cabd312210665274361568181b6d41b9a86f7ed13f1dba7e3f844dc2e5ea5584` | 2221 | RestController | `udc-runtime/data` | 1 | `r1-UdcFormDataQueryController.javap.txt` |
| 14 | `com.seeyon.boot.starter.udcrt.controller.UdcFunctionNodeController`<br>`efd8f9143d0fd44d4e3033a4bb4877c09e891a1049f66382df1ae1d7d08a7748` | 1844 | RestController | `udc-runtime/meta-data` | 1 | `r1-UdcFunctionNodeController.javap.txt` |
| 15 | `com.seeyon.boot.starter.udcrt.controller.UdcRoleRtController`<br>`ed024802b6c205041e4368840993412be184ff67c5f9b12938bee5a13a2aae47` | 1826 | RestController | `udc-runtime/udc-role` | 1 | `r1-UdcRoleRtController.javap.txt` |
| 16 | `com.seeyon.boot.starter.udcrt.controller.UdcRtPageInfoController`<br>`7678734875e3c96aa463bd94084061b23ab80d846aa82e3cfe96f79db14a2e02` | 2872 | RestController | `udc-runtime/meta-data` | 2 | `r1-UdcRtPageInfoController.javap.txt` |
| 17 | `com.seeyon.boot.starter.udcrt.controller.UdcRtPageLogController`<br>`86efc8a3b0924cb46f4d8ca11b527ba9129f3dd6d938e345c5cb11be15038c5e` | 3156 | RestController | `udc-runtime/rt-page-log` | 4 | `r1-UdcRtPageLogController.javap.txt` |
| 18 | `com.seeyon.boot.starter.udcrt.controller.UdcRuntimeDatabaseController`<br>`588bc1cf97cf53357ce0a851d16eb28244b6a9607aa5c813b80e4c2c8d4b3c48` | 1876 | RestController | `udc-runtime/database` | 1 | `r1-UdcRuntimeDatabaseController.javap.txt` |
| 19 | `com.seeyon.boot.starter.udcrt.controller.UdcSerialConfigController`<br>`fe1e5a72d7a25b34c566a9f49dbd47461c0abe54735dbd190b62203b07f81658` | 13081 | RestController | `udc-runtime/serial-config` | 6 | `r1-UdcSerialConfigController.javap.txt` |
| 20 | `com.seeyon.boot.starter.udcrt.proxy.controller.FormAppInfoController`<br>`085c971cc601a904c4369ee339ffd31fdb4d08a6aa8ff678724c1c615b01dacb` | 763 | RestController | `{hostAppName}/dynamic-rest/com-seeyon/{currentAppName}/app-info` | 0 | `r1-FormAppInfoController.javap.txt` |
| 21 | `com.seeyon.boot.starter.udcrt.proxy.controller.FormAppMbController`<br>`c4dd9ab16749f4bcc06a497816ea4d44b7639f11e82f1cb6f683849687baa957` | 751 | RestController | `dynamic-rest/com-seeyon/{entityAppName}/mobile/{pageUrl}` | 0 | `r1-FormAppMbController.javap.txt` |
| 22 | `com.seeyon.boot.starter.udcrt.proxy.controller.FormAppPcController`<br>`ffa014071be9789cff70d152bf521943c7648703f82f082cd6351d8393594aa0` | 737 | RestController | `dynamic-rest/com-seeyon/{entityAppName}/{pageUrl}` | 0 | `r1-FormAppPcController.javap.txt` |
| 23 | `com.seeyon.boot.starter.udcrt.proxy.controller.FormReferController`<br>`81391cf270d4e3f3c52f1662c1b19620318045a607430cd73f8f7b5b388d460c` | 744 | RestController | `dynamic-rest/com-seeyon/{entityAppName}/{entityName}/refer` | 0 | `r1-FormReferController.javap.txt` |
| 24 | `com.seeyon.boot.starter.udcrt.proxy.controller.NormalAppInfoController`<br>`2b0574dc5ff19b0b39d84ce68796889c122f81d7626912f67b1e37bd7cdda195` | 737 | RestController | `{currentAppName}/app-info` | 0 | `r1-NormalAppInfoController.javap.txt` |
| 25 | `com.seeyon.boot.starter.udcrt.proxy.controller.UdcBaseAppInfoController`<br>`deebcc39cff41fc3b28748cacf5c44657a5f4cd600914b44ecd075436b3fde95` | 1653 | (无 stereotype) | (无类级 @RequestMapping) | 1 | `r1-UdcBaseAppInfoController.javap.txt` |
| 26 | `com.seeyon.boot.starter.udcrt.proxy.controller.UdcBaseGeneralController`<br>`19c40f0353d2346bd0e5c374e8e7a79b9268b739f18cc1049435c12b37e664c8` | 33434 | (无 stereotype) | (无类级 @RequestMapping) | 38 | `r1-UdcBaseGeneralController.javap.txt` |
| 27 | `com.seeyon.boot.starter.udcrt.proxy.controller.UdcReferController`<br>`912383403dcd0e9e445225308b82a117850fbc98494e54243b6f2d454bf09664` | 14214 | (无 stereotype) | (无类级 @RequestMapping) | 14 | `r1-UdcReferController.javap.txt` |

### L-B-2 端点全量表（131 行，逐条 publishing 判定）

| # | 类 | 注解(HTTP) | 方法 | 路径原值 | publish/deploy 词干判定 |
|---|---|---|---|---|---|
| 1 | `AppDraftController` | PostMapping | `createOrUpdate` | `create` | EXCLUDED-NO-STEM |
| 2 | `AppDraftController` | PostMapping | `exist` | `exist` | EXCLUDED-NO-STEM |
| 3 | `AppDraftController` | PostMapping | `select` | `select` | EXCLUDED-NO-STEM |
| 4 | `AppDraftController` | PostMapping | `delete` | `delete` | EXCLUDED-NO-STEM |
| 5 | `AppDraftController` | PostMapping | `deleteAll` | `delete-all` | EXCLUDED-NO-STEM |
| 6 | `AppDraftController` | PostMapping | `deleteTimeout` | `delete/timeout` | EXCLUDED-NO-STEM |
| 7 | `AttachmentTemplateController` | PostMapping | `create` | `/create` | EXCLUDED-NO-STEM |
| 8 | `AttachmentTemplateController` | PostMapping | `createBatch` | `/create-batch` | EXCLUDED-NO-STEM |
| 9 | `AttachmentTemplateController` | GetMapping | `selectByGuid` | `{guid}` | EXCLUDED-NO-STEM |
| 10 | `AttachmentTemplateController` | PostMapping | `selectByGuids` | `/select-by-guids` | EXCLUDED-NO-STEM |
| 11 | `AttachmentTemplateController` | GetMapping | `selectByAppId` | `/app/{appId}` | EXCLUDED-NO-STEM |
| 12 | `AttachmentTemplateController` | PostMapping | `delete` | `/delete/{guid}` | EXCLUDED-NO-STEM |
| 13 | `AttachmentTemplateController` | PostMapping | `deleteByGuids` | `/delete-by-guids` | EXCLUDED-NO-STEM |
| 14 | `CustomApplicationController` | PostMapping | `create` | `/create` | EXCLUDED-NO-STEM |
| 15 | `CustomApplicationController` | PostMapping | `createAsync` | `/create-async` | EXCLUDED-NO-STEM |
| 16 | `CustomApplicationController` | PostMapping | `newLayoutCreateAsync` | `/new-layout-create-async` | EXCLUDED-NO-STEM |
| 17 | `CustomApplicationController` | PostMapping | `copy` | `/copy` | EXCLUDED-NO-STEM |
| 18 | `CustomApplicationController` | PostMapping | `copyAsync` | `/copy-async` | EXCLUDED-NO-STEM |
| 19 | `CustomApplicationController` | PostMapping | `deleteByIds` | `delete` | EXCLUDED-NO-STEM |
| 20 | `CustomApplicationController` | PostMapping | `updateCaption` | `/update-caption` | EXCLUDED-NO-STEM |
| 21 | `CustomApplicationController` | PostMapping | `updateUsageState` | `/update-usage-state` | EXCLUDED-NO-STEM |
| 22 | `CustomApplicationController` | PostMapping | `updateDeployState` | `/update-deploy-state` | **HIT(deploy)** |
| 23 | `CustomApplicationController` | PostMapping | `updateAuth` | `/update-auth` | EXCLUDED-NO-STEM |
| 24 | `CustomApplicationController` | PostMapping | `selectListByConditions` | `/search-no-page` | EXCLUDED-NO-STEM |
| 25 | `CustomApplicationController` | PostMapping | `selectListByConditions` | `/search-page` | EXCLUDED-NO-STEM |
| 26 | `CustomApplicationController` | PostMapping | `upgrade` | `/upgrade` | EXCLUDED-NO-STEM |
| 27 | `DynamicJarController` | PostMapping | `importJar` | `/import` | EXCLUDED-NO-STEM |
| 28 | `DynamicJarController` | GetMapping | `getRequestStatus` | `import/status/{requestId}` | EXCLUDED-NO-STEM |
| 29 | `DynamicJarController` | PostMapping | `downloadApp` | `/download/{appName}` | EXCLUDED-NO-STEM |
| 30 | `DynamicJarController` | GetMapping | `download` | `download` | EXCLUDED-NO-STEM |
| 31 | `FrontFunctionSupportController` | PostMapping | `selectListByEntityName` | `calculate` | EXCLUDED-NO-STEM |
| 32 | `GraphqlProxyController` | PostMapping | `doGraphql` | `graphql` | EXCLUDED-NO-STEM |
| 33 | `RuntimeCOLISplitController` | PostMapping | `upgrade` | `upgrade` | EXCLUDED-NO-STEM |
| 34 | `RuntimeCOLISplitController` | PostMapping | `upload` | `upload/result` | EXCLUDED-NO-STEM |
| 35 | `RuntimeEnvCheckController` | GetMapping | `getBuildInfo` | `build-info/{appName}` | EXCLUDED-NO-STEM |
| 36 | `RuntimeEnvCheckController` | GetMapping | `checkAppVersion` | `app-version/{appName}` | EXCLUDED-NO-STEM |
| 37 | `RuntimeEnvCheckController` | GetMapping | `checkDataPermission` | `data-permission/{entityFullName}` | EXCLUDED-NO-STEM |
| 38 | `RuntimeEnvCheckController` | GetMapping | `checkResponseLength` | `response-length/{length}` | EXCLUDED-NO-STEM |
| 39 | `RuntimeEnvCheckController` | PostMapping | `checkRequestContent` | `request-content` | EXCLUDED-NO-STEM |
| 40 | `UdcAppLogController` | PostMapping | `createBatch` | `create-batch` | EXCLUDED-NO-STEM |
| 41 | `UdcAppLogController` | PostMapping | `search` | `search/microflow` | EXCLUDED-NO-STEM |
| 42 | `UdcAppLogController` | PostMapping | `searchDetails` | `search-details/microflow` | EXCLUDED-NO-STEM |
| 43 | `UdcAppLogController` | PostMapping | `searchFlowDetails` | `search-details/microflow/flowLog` | EXCLUDED-NO-STEM |
| 44 | `UdcAppLogController` | PostMapping | `searchDataFlow` | `search/dataflow` | EXCLUDED-NO-STEM |
| 45 | `UdcAppLogController` | PostMapping | `searchDataFlowDetails` | `search-details/dataflow` | EXCLUDED-NO-STEM |
| 46 | `UdcAppLogController` | PostMapping | `searchDeduction` | `search/deduction` | EXCLUDED-NO-STEM |
| 47 | `UdcAppLogController` | PostMapping | `searchDeductionDetails` | `search-details/deduction` | EXCLUDED-NO-STEM |
| 48 | `UdcAppLogController` | PostMapping | `searchAppDataLog` | `datalog/search` | EXCLUDED-NO-STEM |
| 49 | `UdcAppLogController` | GetMapping | `selectAppDataById` | `datalog/{id}` | EXCLUDED-NO-STEM |
| 50 | `UdcAppLogController` | GetMapping | `selectAppDataByDataId` | `datalog/list-by-dataid/{dataId}` | EXCLUDED-NO-STEM |
| 51 | `UdcAppLogController` | GetMapping | `deleteAll` | `delete-all` | EXCLUDED-NO-STEM |
| 52 | `UdcAppLogController` | GetMapping | `clearOrgManager` | `clear-org-manager` | EXCLUDED-NO-STEM |
| 53 | `UdcAppLogController` | GetMapping | `clearRuntimeDataSource` | `clear-runtime-data-source-cache` | EXCLUDED-NO-STEM |
| 54 | `UdcAppLogController` | PostMapping | `initTenantData` | `init-tenant-data` | EXCLUDED-NO-STEM |
| 55 | `UdcAppLogController` | PostMapping | `updateDataInitVersion` | `update-data-init-version` | EXCLUDED-NO-STEM |
| 56 | `UdcAppLogController` | GetMapping | `unloadDynamicApp` | `unload-dynamic-app/{appName}` | EXCLUDED-NO-STEM |
| 57 | `UdcAppLogController` | GetMapping | `setRestEnableLog` | `enable-log/{enable}` | EXCLUDED-NO-STEM |
| 58 | `UdcAppLogController` | PostMapping | `saveFrontLog` | `save/front-log` | EXCLUDED-NO-STEM |
| 59 | `UdcAttrSnapshotRtController` | GetMapping | `deleteByDataId` | `delete-by-data-id/{dataId}` | EXCLUDED-NO-STEM |
| 60 | `UdcAttrSnapshotRtController` | GetMapping | `deleteByMasterDataId` | `delete-by-master-data-id/{masterDataId}` | EXCLUDED-NO-STEM |
| 61 | `UdcDataTypeController` | GetMapping | `getDataTypes` | `getAll` | EXCLUDED-NO-STEM |
| 62 | `UdcEntityUpdateRtTestController` | PostMapping | `updateWithFields` | `update-with-fields` | EXCLUDED-NO-STEM |
| 63 | `UdcFormDataQueryController` | PostMapping | `queryFormData` | `/query` | EXCLUDED-NO-STEM |
| 64 | `UdcFunctionNodeController` | GetMapping | `selectFunctionNodeTreeMetaData` | `select-function-node-tree/{appName}` | EXCLUDED-NO-STEM |
| 65 | `UdcRoleRtController` | GetMapping | `search` | `has-system-admin/{appName}` | EXCLUDED-NO-STEM |
| 66 | `UdcRtPageInfoController` | PostMapping | `checkPageExistsByConditions` | `check-page-exists` | EXCLUDED-NO-STEM |
| 67 | `UdcRtPageInfoController` | PostMapping | `selectHostAppAndOnlyPageAppPages` | `select-host-and-only-page-pages` | EXCLUDED-NO-STEM |
| 68 | `UdcRtPageLogController` | PostMapping | `createBatch` | `create-batch` | EXCLUDED-NO-STEM |
| 69 | `UdcRtPageLogController` | PostMapping | `search` | `search` | EXCLUDED-NO-STEM |
| 70 | `UdcRtPageLogController` | PostMapping | `searchNonMetadata` | `search-non-metadata` | EXCLUDED-NO-STEM |
| 71 | `UdcRtPageLogController` | GetMapping | `deleteAll` | `delete-all` | EXCLUDED-NO-STEM |
| 72 | `UdcRuntimeDatabaseController` | GetMapping | `queryData` | `query-data` | EXCLUDED-NO-STEM |
| 73 | `UdcSerialConfigController` | PostMapping | `update` | `update` | EXCLUDED-NO-STEM |
| 74 | `UdcSerialConfigController` | PostMapping | `selectListByConditions` | `list` | EXCLUDED-NO-STEM |
| 75 | `UdcSerialConfigController` | GetMapping | `selectEntityList` | `select-entity-list` | EXCLUDED-NO-STEM |
| 76 | `UdcSerialConfigController` | PostMapping | `selectEntityBySerial` | `select-entity-by-serial-id` | EXCLUDED-NO-STEM |
| 77 | `UdcSerialConfigController` | GetMapping | `refreshHistoricalData` | `refresh-historical-data/{appName}` | EXCLUDED-NO-STEM |
| 78 | `UdcSerialConfigController` | GetMapping | `cacheEvict` | `cache-evict/{appName}` | EXCLUDED-NO-STEM |
| 79 | `UdcBaseAppInfoController` | GetMapping | `getDeployInfo` | `deploy-info` | **HIT(deploy)** |
| 80 | `UdcBaseGeneralController` | PostMapping | `create` | `{entityAppName}/{entityName}/{controlId}/create` | EXCLUDED-NO-STEM |
| 81 | `UdcBaseGeneralController` | PostMapping | `createBatch` | `{entityAppName}/{entityName}/{controlId}/create-batch` | EXCLUDED-NO-STEM |
| 82 | `UdcBaseGeneralController` | PostMapping | `deleteById` | `{entityAppName}/{entityName}/{controlId}/delete-by-id` | EXCLUDED-NO-STEM |
| 83 | `UdcBaseGeneralController` | PostMapping | `deleteByIds` | `{entityAppName}/{entityName}/{controlId}/delete-by-ids` | EXCLUDED-NO-STEM |
| 84 | `UdcBaseGeneralController` | PostMapping | `update` | `{entityAppName}/{entityName}/{controlId}/update` | EXCLUDED-NO-STEM |
| 85 | `UdcBaseGeneralController` | PostMapping | `updateBatch` | `{entityAppName}/{entityName}/{controlId}/update-batch` | EXCLUDED-NO-STEM |
| 86 | `UdcBaseGeneralController` | PostMapping | `operateRootBatch` | `{entityAppName}/{entityName}/{controlId}/operate-root-batch` | EXCLUDED-NO-STEM |
| 87 | `UdcBaseGeneralController` | PostMapping | `updateWithResult` | `{entityAppName}/{entityName}/{controlId}/update-with-result` | EXCLUDED-NO-STEM |
| 88 | `UdcBaseGeneralController` | PostMapping | `runtimeCopy` | `{entityAppName}/{entityName}/{controlId}/runtime-copy` | EXCLUDED-NO-STEM |
| 89 | `UdcBaseGeneralController` | GetMapping | `getCascadeDefaultValue` | `{entityAppName}/{entityName}/{controlId}/get-cascade-default-value` | EXCLUDED-NO-STEM |
| 90 | `UdcBaseGeneralController` | PostMapping | `selectCascadeByConditions` | `{entityAppName}/{entityName}/{controlId}/select-cascade-by-conditions` | EXCLUDED-NO-STEM |
| 91 | `UdcBaseGeneralController` | PostMapping | `selectCascadeById` | `{entityAppName}/{entityName}/select-cascade-by-id` | EXCLUDED-NO-STEM |
| 92 | `UdcBaseGeneralController` | PostMapping | `selectTreeGrid` | `{entityAppName}/{entityName}/{controlId}/select-tree-grid` | EXCLUDED-NO-STEM |
| 93 | `UdcBaseGeneralController` | PostMapping | `selectHighestTree` | `{entityAppName}/{entityName}/{controlId}/select-highest-tree` | EXCLUDED-NO-STEM |
| 94 | `UdcBaseGeneralController` | PostMapping | `selectAllChildren4HighestTree` | `{entityAppName}/{entityName}/{controlId}/select-highest-tree-children` | EXCLUDED-NO-STEM |
| 95 | `UdcBaseGeneralController` | PostMapping | `dynamicJoinSelect` | `filter-plan/{entityAppName}/{entityName}/{filterId}` | EXCLUDED-NO-STEM |
| 96 | `UdcBaseGeneralController` | PostMapping | `dynamicJoinSelectCount` | `filter-plan/{entityAppName}/{entityName}/{filterId}/count` | EXCLUDED-NO-STEM |
| 97 | `UdcBaseGeneralController` | PostMapping | `create4Bpm` | `{entityAppName}/{entityName}/{controlId}/create-bpm` | EXCLUDED-NO-STEM |
| 98 | `UdcBaseGeneralController` | PostMapping | `update4Bpm` | `{entityAppName}/{entityName}/{controlId}/update-bpm` | EXCLUDED-NO-STEM |
| 99 | `UdcBaseGeneralController` | PostMapping | `forwardCascadeByConditions` | `select-forward-data` | EXCLUDED-NO-STEM |
| 100 | `UdcBaseGeneralController` | PostMapping | `selectCascadeListByConditions` | `refer-carry/{entityAppName}/{entityName}/{controlId}/select-cascade-list-by-conditions` | EXCLUDED-NO-STEM |
| 101 | `UdcBaseGeneralController` | GetMapping | `selectById4Refer` | `page-refer/{entityAppName}/{entityName}/{referGuid}/{objectId}` | EXCLUDED-NO-STEM |
| 102 | `UdcBaseGeneralController` | PostMapping | `selectByIds4Refer` | `page-refer/{entityAppName}/{entityName}/{referGuid}/select-by-ids` | EXCLUDED-NO-STEM |
| 103 | `UdcBaseGeneralController` | PostMapping | `searchPageByCondition4Refer` | `page-refer/{entityAppName}/{entityName}/{referGuid}` | EXCLUDED-NO-STEM |
| 104 | `UdcBaseGeneralController` | PostMapping | `selectHighestTree4Refer` | `page-refer/{entityAppName}/{entityName}/{referGuid}/select-highest-tree` | EXCLUDED-NO-STEM |
| 105 | `UdcBaseGeneralController` | PostMapping | `selectAllChildren4Highest4Refer` | `page-refer/{entityAppName}/{entityName}/{referGuid}/select-highest-tree-children` | EXCLUDED-NO-STEM |
| 106 | `UdcBaseGeneralController` | PostMapping | `searchPageByCondition4TreeRefer` | `page-refer/{entityAppName}/{entityName}/{referGuid}/tree` | EXCLUDED-NO-STEM |
| 107 | `UdcBaseGeneralController` | PostMapping | `selectHighest4TreeRefer` | `page-refer/{entityAppName}/{entityName}/{referGuid}/tree/select-highest-tree` | EXCLUDED-NO-STEM |
| 108 | `UdcBaseGeneralController` | PostMapping | `selectAllChildren4Highest4TreeRefer` | `page-refer/{entityAppName}/{entityName}/{referGuid}/tree/select-highest-tree-children` | EXCLUDED-NO-STEM |
| 109 | `UdcBaseGeneralController` | PostMapping | `selectListByConditions4TreeRefer` | `page-refer/{entityAppName}/{entityName}/{referGuid}/tree/search-list-by-conditions` | EXCLUDED-NO-STEM |
| 110 | `UdcBaseGeneralController` | PostMapping | `selectTree` | `page-refer/{entityAppName}/{entityName}/{referGuid}/select-tree` | EXCLUDED-NO-STEM |
| 111 | `UdcBaseGeneralController` | PostMapping | `selectTree_tree` | `page-refer/{entityAppName}/{entityName}/{referGuid}/tree/select-tree` | EXCLUDED-NO-STEM |
| 112 | `UdcBaseGeneralController` | PostMapping | `importExcelData` | `{entityAppName}/{entityName}/{controlId}/import` | EXCLUDED-NO-STEM |
| 113 | `UdcBaseGeneralController` | PostMapping | `exportExcel` | `{entityAppName}/{entityName}/{controlId}/export` | EXCLUDED-NO-STEM |
| 114 | `UdcBaseGeneralController` | PostMapping | `dynamicSelect` | `dataflow/{entityName}/{restMappingName}/dynamic/select` | EXCLUDED-NO-STEM |
| 115 | `UdcBaseGeneralController` | PostMapping | `executeDataFlow` | `dataflow/{entityName}/{restMappingName}` | EXCLUDED-NO-STEM |
| 116 | `UdcBaseGeneralController` | GetMapping | `doGetMicroFlow` | `microflow/{microFlowName}`<br>`host/microflow/{microFlowName}` | EXCLUDED-NO-STEM |
| 117 | `UdcBaseGeneralController` | PostMapping | `doPostMicroFlow` | `microflow/{microFlowName}`<br>`host/microflow/{microFlowName}` | EXCLUDED-NO-STEM |
| 118 | `UdcReferController` | PostMapping | `selectHighestTree` | `{entityAppName}/{entityName}/{referGuid}/select-highest-tree` | EXCLUDED-NO-STEM |
| 119 | `UdcReferController` | PostMapping | `selectAllChildren4HighestTree` | `{entityAppName}/{entityName}/{referGuid}/select-highest-tree-children` | EXCLUDED-NO-STEM |
| 120 | `UdcReferController` | PostMapping | `selectTree` | `{entityAppName}/{entityName}/{referGuid}/select-tree` | EXCLUDED-NO-STEM |
| 121 | `UdcReferController` | PostMapping | `selectListByConditions` | `{entityAppName}/{entityName}/{referGuid}/search-list-by-conditions` | EXCLUDED-NO-STEM |
| 122 | `UdcReferController` | PostMapping | `searchPageByCondition` | `{entityAppName}/{entityName}/{referGuid}` | EXCLUDED-NO-STEM |
| 123 | `UdcReferController` | GetMapping | `selectById` | `{entityAppName}/{entityName}/{referGuid}/{objectId}` | EXCLUDED-NO-STEM |
| 124 | `UdcReferController` | GetMapping | `selectV1ById` | `{entityAppName}/{entityName}/{referGuid}/v1/{id}` | EXCLUDED-NO-STEM |
| 125 | `UdcReferController` | PostMapping | `selectV1ByIds` | `{entityAppName}/{entityName}/{referGuid}/v1/ids` | EXCLUDED-NO-STEM |
| 126 | `UdcReferController` | PostMapping | `selectByIds` | `{entityAppName}/{entityName}/{referGuid}/select-by-ids` | EXCLUDED-NO-STEM |
| 127 | `UdcReferController` | PostMapping | `selectHighestTree_tree` | `{entityAppName}/{entityName}/{referGuid}/tree/select-highest-tree` | EXCLUDED-NO-STEM |
| 128 | `UdcReferController` | PostMapping | `selectAllChildren4HighestTree_tree` | `{entityAppName}/{entityName}/{referGuid}/tree/select-highest-tree-children` | EXCLUDED-NO-STEM |
| 129 | `UdcReferController` | PostMapping | `selectTree_tree` | `{entityAppName}/{entityName}/{referGuid}/tree/select-tree` | EXCLUDED-NO-STEM |
| 130 | `UdcReferController` | PostMapping | `selectListByConditions_tree` | `entityAppName}/{entityName}/{referGuid}/tree/search-list-by-conditions` | EXCLUDED-NO-STEM |
| 131 | `UdcReferController` | PostMapping | `searchPage_treeByCondition` | `{entityAppName}/{entityName}/{referGuid}/tree` | EXCLUDED-NO-STEM |

## L-C 常量池全量层

- 全部 346 类的常量池 Utf8 总数: **38646**；publish 词干命中行数（含跨词干重复）: **352**

### L-C-publish（去重 90 条）

| 载体类 | 常量池 Utf8（截断 120 字符） |
|---|---|
| `com.seeyon.boot.starter.udcrt.appservice.CustomApplicationAppService` | `UNPUBLISHED` |
| `com.seeyon.boot.starter.udcrt.appservice.CustomApplicationAppService` | `PUBLISHING` |
| `com.seeyon.boot.starter.udcrt.controller.RuntimeEnvCheckController` | `publish` |
| `com.seeyon.boot.starter.udcrt.domain.entity.CustomApplication` | `UNPUBLISHED` |
| `com.seeyon.boot.starter.udcrt.domain.service.CustomApplicationService` | `publish` |
| `com.seeyon.boot.starter.udcrt.domain.service.CustomApplicationService` | `PUBLISHING` |
| `com.seeyon.boot.starter.udcrt.domain.service.DynamicJarService` | `publish` |
| `com.seeyon.boot.starter.udcrt.domain.service.FormServiceProxy` | `publish` |
| `com.seeyon.boot.starter.udcrt.domain.service.FromAcrossService` | `publish` |
| `com.seeyon.boot.starter.udcrt.domain.service.MicroFlowOrgPeopleService` | `PUBLISH_SCOPE` |
| `com.seeyon.boot.starter.udcrt.domain.service.MicroFlowOrgPeopleService` | `buildMemberCoreByPublishScope` |
| `com.seeyon.boot.starter.udcrt.domain.service.MicroFlowOrgPeopleService` | `publishScope` |
| `com.seeyon.boot.starter.udcrt.domain.service.MicroFlowOrgPeopleService` | `buildMemberPostCoreByPublishScope` |
| `com.seeyon.boot.starter.udcrt.dto.CustomApplicationDto` | `UNPUBLISHED` |
| `com.seeyon.boot.starter.udcrt.enums.MicroFlowActivityTypeEnum` | `PUBLISH_BUSINESS_EVENT` |
| `com.seeyon.boot.starter.udcrt.event.publisher.EventPublisher$EventPhase` | `Lcom/seeyon/boot/starter/udcrt/event/publisher/EventPublisher$EventPhase;` |
| `com.seeyon.boot.starter.udcrt.event.publisher.EventPublisher$EventPhase` | `[Lcom/seeyon/boot/starter/udcrt/event/publisher/EventPublisher$EventPhase;` |
| `com.seeyon.boot.starter.udcrt.event.publisher.EventPublisher$EventPhase` | `()[Lcom/seeyon/boot/starter/udcrt/event/publisher/EventPublisher$EventPhase;` |
| `com.seeyon.boot.starter.udcrt.event.publisher.EventPublisher$EventPhase` | `(Ljava/lang/String;)Lcom/seeyon/boot/starter/udcrt/event/publisher/EventPublisher$EventPhase;` |
| `com.seeyon.boot.starter.udcrt.event.publisher.EventPublisher$EventPhase` | `Ljava/lang/Enum<Lcom/seeyon/boot/starter/udcrt/event/publisher/EventPublisher$EventPhase;>;` |
| `com.seeyon.boot.starter.udcrt.event.publisher.EventPublisher$EventPhase` | `EventPublisher.java` |
| `com.seeyon.boot.starter.udcrt.event.publisher.EventPublisher$EventPhase` | `com/seeyon/boot/starter/udcrt/event/publisher/EventPublisher$EventPhase` |
| `com.seeyon.boot.starter.udcrt.event.publisher.EventPublisher$EventPhase` | `com/seeyon/boot/starter/udcrt/event/publisher/EventPublisher` |
| `com.seeyon.boot.starter.udcrt.event.publisher.EventPublisher` | `publish` |
| `com.seeyon.boot.starter.udcrt.event.publisher.EventPublisher` | `(Ljava/lang/String;Ljava/io/Serializable;Lcom/seeyon/boot/starter/udcrt/event/publisher/EventPublisher$EventPhase;)V` |
| `com.seeyon.boot.starter.udcrt.event.publisher.EventPublisher` | `<T::Ljava/io/Serializable;>(Ljava/lang/String;TT;Lcom/seeyon/boot/starter/udcrt/event/publisher/EventPublisher$EventPhas` |
| `com.seeyon.boot.starter.udcrt.event.publisher.EventPublisher` | `EventPublisher.java` |
| `com.seeyon.boot.starter.udcrt.event.publisher.EventPublisher` | `com/seeyon/boot/starter/udcrt/event/publisher/EventPublisher` |
| `com.seeyon.boot.starter.udcrt.event.publisher.EventPublisher` | `com/seeyon/boot/starter/udcrt/event/publisher/EventPublisher$EventPhase` |
| `com.seeyon.boot.starter.udcrt.event.publisher.EventPublisherHelper` | `entityEventPublisher` |
| `com.seeyon.boot.starter.udcrt.event.publisher.EventPublisherHelper` | `Lcom/seeyon/boot/starter/udcrt/event/publisher/impl/EntityEventPublisher;` |
| `com.seeyon.boot.starter.udcrt.event.publisher.EventPublisherHelper` | `businessEventPublisher` |
| `com.seeyon.boot.starter.udcrt.event.publisher.EventPublisherHelper` | `Lcom/seeyon/boot/starter/udcrt/event/publisher/impl/BusinessEventPublisher;` |
| `com.seeyon.boot.starter.udcrt.event.publisher.EventPublisherHelper` | `Lcom/seeyon/boot/starter/udcrt/event/publisher/EventPublisherHelper;` |
| `com.seeyon.boot.starter.udcrt.event.publisher.EventPublisherHelper` | `publishEntityEvent` |
| `com.seeyon.boot.starter.udcrt.event.publisher.EventPublisherHelper` | `(Ljava/io/Serializable;Lcom/seeyon/boot/starter/udcrt/event/publisher/EventPublisher$EventPhase;)V` |
| `com.seeyon.boot.starter.udcrt.event.publisher.EventPublisherHelper` | `Lcom/seeyon/boot/starter/udcrt/event/publisher/EventPublisher$EventPhase;` |
| `com.seeyon.boot.starter.udcrt.event.publisher.EventPublisherHelper` | `<T::Ljava/io/Serializable;>(TT;Lcom/seeyon/boot/starter/udcrt/event/publisher/EventPublisher$EventPhase;)V` |
| `com.seeyon.boot.starter.udcrt.event.publisher.EventPublisherHelper` | `publishBusinessEvent` |
| `com.seeyon.boot.starter.udcrt.event.publisher.EventPublisherHelper` | `(Ljava/lang/String;Lcom/seeyon/boot/mq/BaseMessage;Lcom/seeyon/boot/starter/udcrt/event/publisher/EventPublisher$EventPh` |
| `com.seeyon.boot.starter.udcrt.event.publisher.EventPublisherHelper` | `<T:Lcom/seeyon/boot/mq/BaseMessage;>(Ljava/lang/String;TT;Lcom/seeyon/boot/starter/udcrt/event/publisher/EventPublisher$` |
| `com.seeyon.boot.starter.udcrt.event.publisher.EventPublisherHelper` | `EventPublisherHelper.java` |
| `com.seeyon.boot.starter.udcrt.event.publisher.EventPublisherHelper` | `com/seeyon/boot/starter/udcrt/event/publisher/EventPublisherHelper` |
| `com.seeyon.boot.starter.udcrt.event.publisher.EventPublisherHelper` | `com/seeyon/boot/starter/udcrt/event/publisher/EventPublisher$EventPhase` |
| `com.seeyon.boot.starter.udcrt.event.publisher.EventPublisherHelper` | `com/seeyon/boot/starter/udcrt/event/publisher/impl/EntityEventPublisher` |
| `com.seeyon.boot.starter.udcrt.event.publisher.EventPublisherHelper` | `publish` |
| `com.seeyon.boot.starter.udcrt.event.publisher.EventPublisherHelper` | `(Ljava/lang/String;Ljava/io/Serializable;Lcom/seeyon/boot/starter/udcrt/event/publisher/EventPublisher$EventPhase;)V` |
| `com.seeyon.boot.starter.udcrt.event.publisher.EventPublisherHelper` | `com/seeyon/boot/starter/udcrt/event/publisher/impl/BusinessEventPublisher` |
| `com.seeyon.boot.starter.udcrt.event.publisher.EventPublisherHelper` | `com/seeyon/boot/starter/udcrt/event/publisher/EventPublisher` |
| `com.seeyon.boot.starter.udcrt.event.publisher.impl.BusinessEventPublisher$1` | `$SwitchMap$com$seeyon$boot$starter$udcrt$event$publisher$EventPublisher$EventPhase` |
| `com.seeyon.boot.starter.udcrt.event.publisher.impl.BusinessEventPublisher$1` | `BusinessEventPublisher.java` |
| `com.seeyon.boot.starter.udcrt.event.publisher.impl.BusinessEventPublisher$1` | `com/seeyon/boot/starter/udcrt/event/publisher/impl/BusinessEventPublisher$1` |
| `com.seeyon.boot.starter.udcrt.event.publisher.impl.BusinessEventPublisher$1` | `com/seeyon/boot/starter/udcrt/event/publisher/impl/BusinessEventPublisher` |
| `com.seeyon.boot.starter.udcrt.event.publisher.impl.BusinessEventPublisher$1` | `com/seeyon/boot/starter/udcrt/event/publisher/EventPublisher$EventPhase` |
| `com.seeyon.boot.starter.udcrt.event.publisher.impl.BusinessEventPublisher$1` | `()[Lcom/seeyon/boot/starter/udcrt/event/publisher/EventPublisher$EventPhase;` |
| `com.seeyon.boot.starter.udcrt.event.publisher.impl.BusinessEventPublisher$1` | `Lcom/seeyon/boot/starter/udcrt/event/publisher/EventPublisher$EventPhase;` |
| `com.seeyon.boot.starter.udcrt.event.publisher.impl.BusinessEventPublisher$1` | `com/seeyon/boot/starter/udcrt/event/publisher/EventPublisher` |
| `com.seeyon.boot.starter.udcrt.event.publisher.impl.BusinessEventPublisher` | `Lcom/seeyon/boot/starter/udcrt/event/publisher/impl/BusinessEventPublisher;` |
| `com.seeyon.boot.starter.udcrt.event.publisher.impl.BusinessEventPublisher` | `publish` |
| `com.seeyon.boot.starter.udcrt.event.publisher.impl.BusinessEventPublisher` | `(Ljava/lang/String;Ljava/io/Serializable;Lcom/seeyon/boot/starter/udcrt/event/publisher/EventPublisher$EventPhase;)V` |
| `com.seeyon.boot.starter.udcrt.event.publisher.impl.BusinessEventPublisher` | `Lcom/seeyon/boot/starter/udcrt/event/publisher/EventPublisher$EventPhase;` |
| `com.seeyon.boot.starter.udcrt.event.publisher.impl.BusinessEventPublisher` | `<T::Ljava/io/Serializable;>(Ljava/lang/String;TT;Lcom/seeyon/boot/starter/udcrt/event/publisher/EventPublisher$EventPhas` |
| `com.seeyon.boot.starter.udcrt.event.publisher.impl.BusinessEventPublisher` | `BusinessEventPublisher.java` |
| `com.seeyon.boot.starter.udcrt.event.publisher.impl.BusinessEventPublisher` | `com/seeyon/boot/starter/udcrt/event/publisher/impl/BusinessEventPublisher` |
| `com.seeyon.boot.starter.udcrt.event.publisher.impl.BusinessEventPublisher` | `com/seeyon/boot/starter/udcrt/event/publisher/EventPublisher` |
| `com.seeyon.boot.starter.udcrt.event.publisher.impl.BusinessEventPublisher` | `com/seeyon/boot/starter/udcrt/event/publisher/impl/BusinessEventPublisher$1` |
| `com.seeyon.boot.starter.udcrt.event.publisher.impl.BusinessEventPublisher` | `com/seeyon/boot/starter/udcrt/event/publisher/EventPublisher$EventPhase` |
| `com.seeyon.boot.starter.udcrt.event.publisher.impl.BusinessEventPublisher` | `$SwitchMap$com$seeyon$boot$starter$udcrt$event$publisher$EventPublisher$EventPhase` |
| `com.seeyon.boot.starter.udcrt.event.publisher.impl.EntityEventPublisher$1` | `$SwitchMap$com$seeyon$boot$starter$udcrt$event$publisher$EventPublisher$EventPhase` |
| `com.seeyon.boot.starter.udcrt.event.publisher.impl.EntityEventPublisher$1` | `EntityEventPublisher.java` |
| `com.seeyon.boot.starter.udcrt.event.publisher.impl.EntityEventPublisher$1` | `com/seeyon/boot/starter/udcrt/event/publisher/impl/EntityEventPublisher$1` |
| `com.seeyon.boot.starter.udcrt.event.publisher.impl.EntityEventPublisher$1` | `com/seeyon/boot/starter/udcrt/event/publisher/impl/EntityEventPublisher` |
| `com.seeyon.boot.starter.udcrt.event.publisher.impl.EntityEventPublisher$1` | `com/seeyon/boot/starter/udcrt/event/publisher/EventPublisher$EventPhase` |
| `com.seeyon.boot.starter.udcrt.event.publisher.impl.EntityEventPublisher$1` | `()[Lcom/seeyon/boot/starter/udcrt/event/publisher/EventPublisher$EventPhase;` |
| `com.seeyon.boot.starter.udcrt.event.publisher.impl.EntityEventPublisher$1` | `Lcom/seeyon/boot/starter/udcrt/event/publisher/EventPublisher$EventPhase;` |
| `com.seeyon.boot.starter.udcrt.event.publisher.impl.EntityEventPublisher$1` | `com/seeyon/boot/starter/udcrt/event/publisher/EventPublisher` |
| `com.seeyon.boot.starter.udcrt.event.publisher.impl.EntityEventPublisher` | `Lcom/seeyon/boot/starter/udcrt/event/publisher/impl/EntityEventPublisher;` |
| `com.seeyon.boot.starter.udcrt.event.publisher.impl.EntityEventPublisher` | `publish` |
| `com.seeyon.boot.starter.udcrt.event.publisher.impl.EntityEventPublisher` | `(Ljava/lang/String;Ljava/io/Serializable;Lcom/seeyon/boot/starter/udcrt/event/publisher/EventPublisher$EventPhase;)V` |
| `com.seeyon.boot.starter.udcrt.event.publisher.impl.EntityEventPublisher` | `Lcom/seeyon/boot/starter/udcrt/event/publisher/EventPublisher$EventPhase;` |
| `com.seeyon.boot.starter.udcrt.event.publisher.impl.EntityEventPublisher` | `<T::Ljava/io/Serializable;>(Ljava/lang/String;TT;Lcom/seeyon/boot/starter/udcrt/event/publisher/EventPublisher$EventPhas` |
| `com.seeyon.boot.starter.udcrt.event.publisher.impl.EntityEventPublisher` | `EntityEventPublisher.java` |
| `com.seeyon.boot.starter.udcrt.event.publisher.impl.EntityEventPublisher` | `com/seeyon/boot/starter/udcrt/event/publisher/impl/EntityEventPublisher` |
| `com.seeyon.boot.starter.udcrt.event.publisher.impl.EntityEventPublisher` | `com/seeyon/boot/starter/udcrt/event/publisher/EventPublisher` |
| `com.seeyon.boot.starter.udcrt.event.publisher.impl.EntityEventPublisher` | `com/seeyon/boot/starter/udcrt/event/publisher/impl/EntityEventPublisher$1` |
| `com.seeyon.boot.starter.udcrt.event.publisher.impl.EntityEventPublisher` | `com/seeyon/boot/starter/udcrt/event/publisher/EventPublisher$EventPhase` |
| `com.seeyon.boot.starter.udcrt.event.publisher.impl.EntityEventPublisher` | `$SwitchMap$com$seeyon$boot$starter$udcrt$event$publisher$EventPublisher$EventPhase` |
| `com.seeyon.boot.starter.udcrt.event.publisher.impl.EntityEventPublisher` | `publishAfterTransaction` |
| `com.seeyon.boot.starter.udcrt.migration.CustomApplicationHandler` | `UNPUBLISHED` |
| `com.seeyon.boot.starter.udcrt.proxy.UdcProxyAppServiceComponent` | `publish` |

### L-C-deploy（去重 108 条）

| 载体类 | 常量池 Utf8（截断 120 字符） |
|---|---|
| `com.seeyon.boot.starter.udcrt.api.DeployNoticeService` | `deployNotice` |
| `com.seeyon.boot.starter.udcrt.api.DeployNoticeService` | `Lcom/seeyon/boot/starter/udcrt/api/DeployNoticeService;` |
| `com.seeyon.boot.starter.udcrt.api.DeployNoticeService` | `DeployNoticeService.java` |
| `com.seeyon.boot.starter.udcrt.api.DeployNoticeService` | `com/seeyon/boot/starter/udcrt/api/DeployNoticeService` |
| `com.seeyon.boot.starter.udcrt.appservice.CustomApplicationAppService` | `updateDeployState` |
| `com.seeyon.boot.starter.udcrt.appservice.CustomApplicationAppService` | `updateDeployStateDto` |
| `com.seeyon.boot.starter.udcrt.appservice.CustomApplicationAppService` | `Lcom/seeyon/boot/starter/udcrt/dto/CustomApplicationUpdateDeployStateDto;` |
| `com.seeyon.boot.starter.udcrt.appservice.CustomApplicationAppService` | `deployStateEnum` |
| `com.seeyon.boot.starter.udcrt.appservice.CustomApplicationAppService` | `Lcom/seeyon/udc/common/enums/DeployStateEnum;` |
| `com.seeyon.boot.starter.udcrt.appservice.CustomApplicationAppService` | `Lcom/seeyon/boot/transport/SingleRequest<Lcom/seeyon/boot/starter/udcrt/dto/CustomApplicationUpdateDeployStateDto;>;` |
| `com.seeyon.boot.starter.udcrt.appservice.CustomApplicationAppService` | `(Lcom/seeyon/boot/transport/SingleRequest<Lcom/seeyon/boot/starter/udcrt/dto/CustomApplicationUpdateDeployStateDto;>;)Lc` |
| `com.seeyon.boot.starter.udcrt.appservice.CustomApplicationAppService` | `com/seeyon/boot/starter/udcrt/dto/CustomApplicationUpdateDeployStateDto` |
| `com.seeyon.boot.starter.udcrt.appservice.CustomApplicationAppService` | `com/seeyon/udc/common/enums/DeployStateEnum` |
| `com.seeyon.boot.starter.udcrt.appservice.CustomApplicationAppService` | `setDeployState` |
| `com.seeyon.boot.starter.udcrt.appservice.CustomApplicationAppService` | `(Lcom/seeyon/udc/common/enums/DeployStateEnum;)V` |
| `com.seeyon.boot.starter.udcrt.appservice.CustomApplicationAppService` | `getDeployState` |
| `com.seeyon.boot.starter.udcrt.appservice.CustomApplicationAppService` | `()Lcom/seeyon/udc/common/enums/DeployStateEnum;` |
| `com.seeyon.boot.starter.udcrt.appservice.PageCustomSearchAppService` | `appDeployTime` |
| `com.seeyon.boot.starter.udcrt.appservice.PageCustomSearchAppService` | `getAppDeployTime` |
| `com.seeyon.boot.starter.udcrt.appservice.PageCustomSearchAppService` | `deployInfoMap` |
| `com.seeyon.boot.starter.udcrt.appservice.PageCustomSearchAppService` | `deployTime` |
| `com.seeyon.boot.starter.udcrt.appservice.PageCustomSearchAppService` | `deployInfo` |
| `com.seeyon.boot.starter.udcrt.appservice.PageCustomSearchAppService` | `appDeployInfoMap` |
| `com.seeyon.boot.starter.udcrt.appservice.PageCustomSearchAppService` | `app-deploy-info.json` |
| `com.seeyon.boot.starter.udcrt.controller.CustomApplicationController` | `updateDeployState` |
| `com.seeyon.boot.starter.udcrt.controller.CustomApplicationController` | `(Ljava/lang/Long;Lcom/seeyon/udc/common/enums/DeployStateEnum;Ljava/lang/String;)Lcom/seeyon/boot/transport/SingleRespon` |
| `com.seeyon.boot.starter.udcrt.controller.CustomApplicationController` | `deployState` |
| `com.seeyon.boot.starter.udcrt.controller.CustomApplicationController` | `Lcom/seeyon/udc/common/enums/DeployStateEnum;` |
| `com.seeyon.boot.starter.udcrt.controller.CustomApplicationController` | `(Ljava/lang/Long;Lcom/seeyon/udc/common/enums/DeployStateEnum;Ljava/lang/String;)Lcom/seeyon/boot/transport/SingleRespon` |
| `com.seeyon.boot.starter.udcrt.controller.CustomApplicationController` | `/update-deploy-state` |
| `com.seeyon.boot.starter.udcrt.controller.CustomApplicationController` | `com/seeyon/boot/starter/udcrt/dto/CustomApplicationUpdateDeployStateDto` |
| `com.seeyon.boot.starter.udcrt.controller.CustomApplicationController` | `(Ljava/lang/Long;Lcom/seeyon/udc/common/enums/DeployStateEnum;Ljava/lang/String;)V` |
| `com.seeyon.boot.starter.udcrt.domain.entity.BaseFormEntity` | `deployTime` |
| `com.seeyon.boot.starter.udcrt.domain.entity.BaseFormEntity` | `deploy_time` |
| `com.seeyon.boot.starter.udcrt.domain.entity.BaseFormEntity` | `deployType` |
| `com.seeyon.boot.starter.udcrt.domain.entity.BaseFormEntity` | `Lcom/seeyon/udc/common/enums/DeployTypeEnum;` |
| `com.seeyon.boot.starter.udcrt.domain.entity.BaseFormEntity` | `deploy_type` |
| `com.seeyon.boot.starter.udcrt.domain.entity.BaseFormEntity` | `getDeployTime` |
| `com.seeyon.boot.starter.udcrt.domain.entity.BaseFormEntity` | `getDeployType` |
| `com.seeyon.boot.starter.udcrt.domain.entity.BaseFormEntity` | `()Lcom/seeyon/udc/common/enums/DeployTypeEnum;` |
| `com.seeyon.boot.starter.udcrt.domain.entity.BaseFormEntity` | `setDeployTime` |
| `com.seeyon.boot.starter.udcrt.domain.entity.BaseFormEntity` | `setDeployType` |
| `com.seeyon.boot.starter.udcrt.domain.entity.BaseFormEntity` | `(Lcom/seeyon/udc/common/enums/DeployTypeEnum;)V` |
| `com.seeyon.boot.starter.udcrt.domain.entity.CustomApplication` | `deployState` |
| `com.seeyon.boot.starter.udcrt.domain.entity.CustomApplication` | `Lcom/seeyon/udc/common/enums/DeployStateEnum;` |
| `com.seeyon.boot.starter.udcrt.domain.entity.CustomApplication` | `deploy_state` |
| `com.seeyon.boot.starter.udcrt.domain.entity.CustomApplication` | `getDeployState` |
| `com.seeyon.boot.starter.udcrt.domain.entity.CustomApplication` | `()Lcom/seeyon/udc/common/enums/DeployStateEnum;` |
| `com.seeyon.boot.starter.udcrt.domain.entity.CustomApplication` | `setDeployState` |
| `com.seeyon.boot.starter.udcrt.domain.entity.CustomApplication` | `(Lcom/seeyon/udc/common/enums/DeployStateEnum;)V` |
| `com.seeyon.boot.starter.udcrt.domain.entity.CustomApplication` | `com/seeyon/udc/common/enums/DeployStateEnum` |
| `com.seeyon.boot.starter.udcrt.domain.service.AbstractFromService` | `handleDeployNotice` |
| `com.seeyon.boot.starter.udcrt.domain.service.AbstractFromService` | `(Lcom/seeyon/udc/common/dto/DeployNoticeMsgDto;)V` |
| `com.seeyon.boot.starter.udcrt.domain.service.AbstractFromService` | `getDeployTime` |
| `com.seeyon.boot.starter.udcrt.domain.service.CustomApplicationService` | `handleDeployNotice` |
| `com.seeyon.boot.starter.udcrt.domain.service.CustomApplicationService` | `(Lcom/seeyon/udc/common/dto/DeployNoticeMsgDto;)V` |
| `com.seeyon.boot.starter.udcrt.domain.service.CustomApplicationService` | `Lcom/seeyon/udc/common/dto/DeployNoticeMsgDto;` |
| `com.seeyon.boot.starter.udcrt.domain.service.CustomApplicationService` | `deployState` |
| `com.seeyon.boot.starter.udcrt.domain.service.CustomApplicationService` | `Lcom/seeyon/udc/common/enums/DeployStateEnum;` |
| `com.seeyon.boot.starter.udcrt.domain.service.CustomApplicationService` | `updateDeployState` |
| `com.seeyon.boot.starter.udcrt.domain.service.CustomApplicationService` | `com/seeyon/udc/common/enums/DeployStateEnum` |
| `com.seeyon.boot.starter.udcrt.domain.service.CustomApplicationService` | `com/seeyon/udc/common/dto/DeployNoticeMsgDto` |
| `com.seeyon.boot.starter.udcrt.domain.service.CustomApplicationService` | `()Lcom/seeyon/udc/common/enums/DeployStateEnum;` |
| `com.seeyon.boot.starter.udcrt.domain.service.CustomApplicationService` | `setDeployState` |
| `com.seeyon.boot.starter.udcrt.domain.service.CustomApplicationService` | `(Lcom/seeyon/udc/common/enums/DeployStateEnum;)V` |
| `com.seeyon.boot.starter.udcrt.domain.service.CustomApplicationService` | `getDeployState` |
| `com.seeyon.boot.starter.udcrt.domain.service.CustomApplicationService` | `com/seeyon/udc/common/enums/DeployTypeEnum` |
| `com.seeyon.boot.starter.udcrt.domain.service.CustomApplicationService` | `Lcom/seeyon/udc/common/enums/DeployTypeEnum;` |
| `com.seeyon.boot.starter.udcrt.domain.service.CustomApplicationService` | `setDeployType` |
| `com.seeyon.boot.starter.udcrt.domain.service.CustomApplicationService` | `(Lcom/seeyon/udc/common/enums/DeployTypeEnum;)V` |
| `com.seeyon.boot.starter.udcrt.domain.service.FromAcrossService` | `com/seeyon/udc/common/enums/DeployStateEnum` |
| `com.seeyon.boot.starter.udcrt.domain.service.FromAcrossService` | `Lcom/seeyon/udc/common/enums/DeployStateEnum;` |
| `com.seeyon.boot.starter.udcrt.domain.service.FromAcrossService` | `getDeployState` |
| `com.seeyon.boot.starter.udcrt.domain.service.FromAcrossService` | `()Lcom/seeyon/udc/common/enums/DeployStateEnum;` |
| `com.seeyon.boot.starter.udcrt.dto.CustomApplicationDto` | `deployState` |
| `com.seeyon.boot.starter.udcrt.dto.CustomApplicationDto` | `Lcom/seeyon/udc/common/enums/DeployStateEnum;` |
| `com.seeyon.boot.starter.udcrt.dto.CustomApplicationDto` | `getDeployState` |
| `com.seeyon.boot.starter.udcrt.dto.CustomApplicationDto` | `()Lcom/seeyon/udc/common/enums/DeployStateEnum;` |
| `com.seeyon.boot.starter.udcrt.dto.CustomApplicationDto` | `setDeployState` |
| `com.seeyon.boot.starter.udcrt.dto.CustomApplicationDto` | `(Lcom/seeyon/udc/common/enums/DeployStateEnum;)V` |
| `com.seeyon.boot.starter.udcrt.dto.CustomApplicationUpdateDeployStateDto` | `deployState` |
| `com.seeyon.boot.starter.udcrt.dto.CustomApplicationUpdateDeployStateDto` | `Lcom/seeyon/udc/common/enums/DeployStateEnum;` |
| `com.seeyon.boot.starter.udcrt.dto.CustomApplicationUpdateDeployStateDto` | `Lcom/seeyon/boot/starter/udcrt/dto/CustomApplicationUpdateDeployStateDto;` |
| `com.seeyon.boot.starter.udcrt.dto.CustomApplicationUpdateDeployStateDto` | `getDeployState` |
| `com.seeyon.boot.starter.udcrt.dto.CustomApplicationUpdateDeployStateDto` | `()Lcom/seeyon/udc/common/enums/DeployStateEnum;` |
| `com.seeyon.boot.starter.udcrt.dto.CustomApplicationUpdateDeployStateDto` | `setDeployState` |
| `com.seeyon.boot.starter.udcrt.dto.CustomApplicationUpdateDeployStateDto` | `(Lcom/seeyon/udc/common/enums/DeployStateEnum;)V` |
| `com.seeyon.boot.starter.udcrt.dto.CustomApplicationUpdateDeployStateDto` | `(Ljava/lang/Long;Lcom/seeyon/udc/common/enums/DeployStateEnum;Ljava/lang/String;)V` |
| `com.seeyon.boot.starter.udcrt.dto.CustomApplicationUpdateDeployStateDto` | `CustomApplicationUpdateDeployStateDto.java` |
| `com.seeyon.boot.starter.udcrt.dto.CustomApplicationUpdateDeployStateDto` | `com/seeyon/boot/starter/udcrt/dto/CustomApplicationUpdateDeployStateDto` |
| `com.seeyon.boot.starter.udcrt.migration.CustomApplicationHandler` | `com/seeyon/udc/common/enums/DeployStateEnum` |
| `com.seeyon.boot.starter.udcrt.migration.CustomApplicationHandler` | `Lcom/seeyon/udc/common/enums/DeployStateEnum;` |
| `com.seeyon.boot.starter.udcrt.migration.CustomApplicationHandler` | `setDeployState` |
| `com.seeyon.boot.starter.udcrt.migration.CustomApplicationHandler` | `(Lcom/seeyon/udc/common/enums/DeployStateEnum;)V` |
| `com.seeyon.boot.starter.udcrt.mq.DeployChangeEventListener` | `Lcom/seeyon/boot/starter/udcrt/mq/DeployChangeEventListener;` |
| `com.seeyon.boot.starter.udcrt.mq.DeployChangeEventListener` | `onDeployChangeEvent` |
| `com.seeyon.boot.starter.udcrt.mq.DeployChangeEventListener` | `(Lcom/seeyon/udc/common/dto/DeployNoticeMsgDto;)V` |
| `com.seeyon.boot.starter.udcrt.mq.DeployChangeEventListener` | `deployNoticeMsgDto` |
| `com.seeyon.boot.starter.udcrt.mq.DeployChangeEventListener` | `Lcom/seeyon/udc/common/dto/DeployNoticeMsgDto;` |
| `com.seeyon.boot.starter.udcrt.mq.DeployChangeEventListener` | `(Lcom/seeyon/udc/common/dto/DeployNoticeMsgDto;Lcom/seeyon/boot/starter/udcrt/domain/service/AbstractFromService;)V` |
| `com.seeyon.boot.starter.udcrt.mq.DeployChangeEventListener` | `DeployChangeEventListener.java` |
| `com.seeyon.boot.starter.udcrt.mq.DeployChangeEventListener` | `com/seeyon/boot/starter/udcrt/mq/DeployChangeEventListener` |
| `com.seeyon.boot.starter.udcrt.mq.DeployChangeEventListener` | `com/seeyon/udc/common/dto/DeployNoticeMsgDto` |
| `com.seeyon.boot.starter.udcrt.mq.DeployChangeEventListener` | `(Lcom/seeyon/udc/common/dto/DeployNoticeMsgDto;)Ljava/util/function/Consumer;` |
| `com.seeyon.boot.starter.udcrt.mq.DeployChangeEventListener` | `handleDeployNotice` |
| `com.seeyon.boot.starter.udcrt.proxy.controller.UdcBaseAppInfoController` | `getDeployInfo` |
| `com.seeyon.boot.starter.udcrt.proxy.controller.UdcBaseAppInfoController` | `deploy-info` |
| `com.seeyon.boot.starter.udcrt.proxy.controller.UdcBaseAppInfoController` | `app-deploy-info.json` |

### L-C-pub（去重 97 条）

| 载体类 | 常量池 Utf8（截断 120 字符） |
|---|---|
| `cn.hutool.core.bean.PropDesc` | `isPublic` |
| `com.seeyon.boot.starter.udcrt.appservice.CustomApplicationAppService` | `UNPUBLISHED` |
| `com.seeyon.boot.starter.udcrt.appservice.CustomApplicationAppService` | `PUBLISHING` |
| `com.seeyon.boot.starter.udcrt.appservice.DisplayNameAppService` | `isPublic` |
| `com.seeyon.boot.starter.udcrt.controller.RuntimeCOLISplitController` | `uploadForPublicNoDB` |
| `com.seeyon.boot.starter.udcrt.controller.RuntimeEnvCheckController` | `publish` |
| `com.seeyon.boot.starter.udcrt.domain.entity.CustomApplication` | `UNPUBLISHED` |
| `com.seeyon.boot.starter.udcrt.domain.entity.IdToKeyMapEntity` | `isPublic` |
| `com.seeyon.boot.starter.udcrt.domain.service.CustomApplicationService` | `publish` |
| `com.seeyon.boot.starter.udcrt.domain.service.CustomApplicationService` | `PUBLISHING` |
| `com.seeyon.boot.starter.udcrt.domain.service.DynamicJarService` | `publish` |
| `com.seeyon.boot.starter.udcrt.domain.service.DynamicJarService` | `setIsPublic` |
| `com.seeyon.boot.starter.udcrt.domain.service.FormServiceProxy` | `publish` |
| `com.seeyon.boot.starter.udcrt.domain.service.FromAcrossService` | `publish` |
| `com.seeyon.boot.starter.udcrt.domain.service.MicroFlowOrgPeopleService` | `PUBLISH_SCOPE` |
| `com.seeyon.boot.starter.udcrt.domain.service.MicroFlowOrgPeopleService` | `buildMemberCoreByPublishScope` |
| `com.seeyon.boot.starter.udcrt.domain.service.MicroFlowOrgPeopleService` | `publishScope` |
| `com.seeyon.boot.starter.udcrt.domain.service.MicroFlowOrgPeopleService` | `buildMemberPostCoreByPublishScope` |
| `com.seeyon.boot.starter.udcrt.dto.CustomApplicationDto` | `UNPUBLISHED` |
| `com.seeyon.boot.starter.udcrt.dto.IdToKeyMapEntityDto` | `isPublic` |
| `com.seeyon.boot.starter.udcrt.dto.UdcRuntimeDataBaseColumnMetadataDto` | `isPublic` |
| `com.seeyon.boot.starter.udcrt.enums.MicroFlowActivityTypeEnum` | `PUBLISH_BUSINESS_EVENT` |
| `com.seeyon.boot.starter.udcrt.event.publisher.EventPublisher$EventPhase` | `Lcom/seeyon/boot/starter/udcrt/event/publisher/EventPublisher$EventPhase;` |
| `com.seeyon.boot.starter.udcrt.event.publisher.EventPublisher$EventPhase` | `[Lcom/seeyon/boot/starter/udcrt/event/publisher/EventPublisher$EventPhase;` |
| `com.seeyon.boot.starter.udcrt.event.publisher.EventPublisher$EventPhase` | `()[Lcom/seeyon/boot/starter/udcrt/event/publisher/EventPublisher$EventPhase;` |
| `com.seeyon.boot.starter.udcrt.event.publisher.EventPublisher$EventPhase` | `(Ljava/lang/String;)Lcom/seeyon/boot/starter/udcrt/event/publisher/EventPublisher$EventPhase;` |
| `com.seeyon.boot.starter.udcrt.event.publisher.EventPublisher$EventPhase` | `Ljava/lang/Enum<Lcom/seeyon/boot/starter/udcrt/event/publisher/EventPublisher$EventPhase;>;` |
| `com.seeyon.boot.starter.udcrt.event.publisher.EventPublisher$EventPhase` | `EventPublisher.java` |
| `com.seeyon.boot.starter.udcrt.event.publisher.EventPublisher$EventPhase` | `com/seeyon/boot/starter/udcrt/event/publisher/EventPublisher$EventPhase` |
| `com.seeyon.boot.starter.udcrt.event.publisher.EventPublisher$EventPhase` | `com/seeyon/boot/starter/udcrt/event/publisher/EventPublisher` |
| `com.seeyon.boot.starter.udcrt.event.publisher.EventPublisher` | `publish` |
| `com.seeyon.boot.starter.udcrt.event.publisher.EventPublisher` | `(Ljava/lang/String;Ljava/io/Serializable;Lcom/seeyon/boot/starter/udcrt/event/publisher/EventPublisher$EventPhase;)V` |
| `com.seeyon.boot.starter.udcrt.event.publisher.EventPublisher` | `<T::Ljava/io/Serializable;>(Ljava/lang/String;TT;Lcom/seeyon/boot/starter/udcrt/event/publisher/EventPublisher$EventPhas` |
| `com.seeyon.boot.starter.udcrt.event.publisher.EventPublisher` | `EventPublisher.java` |
| `com.seeyon.boot.starter.udcrt.event.publisher.EventPublisher` | `com/seeyon/boot/starter/udcrt/event/publisher/EventPublisher` |
| `com.seeyon.boot.starter.udcrt.event.publisher.EventPublisher` | `com/seeyon/boot/starter/udcrt/event/publisher/EventPublisher$EventPhase` |
| `com.seeyon.boot.starter.udcrt.event.publisher.EventPublisherHelper` | `entityEventPublisher` |
| `com.seeyon.boot.starter.udcrt.event.publisher.EventPublisherHelper` | `Lcom/seeyon/boot/starter/udcrt/event/publisher/impl/EntityEventPublisher;` |
| `com.seeyon.boot.starter.udcrt.event.publisher.EventPublisherHelper` | `businessEventPublisher` |
| `com.seeyon.boot.starter.udcrt.event.publisher.EventPublisherHelper` | `Lcom/seeyon/boot/starter/udcrt/event/publisher/impl/BusinessEventPublisher;` |
| `com.seeyon.boot.starter.udcrt.event.publisher.EventPublisherHelper` | `Lcom/seeyon/boot/starter/udcrt/event/publisher/EventPublisherHelper;` |
| `com.seeyon.boot.starter.udcrt.event.publisher.EventPublisherHelper` | `publishEntityEvent` |
| `com.seeyon.boot.starter.udcrt.event.publisher.EventPublisherHelper` | `(Ljava/io/Serializable;Lcom/seeyon/boot/starter/udcrt/event/publisher/EventPublisher$EventPhase;)V` |
| `com.seeyon.boot.starter.udcrt.event.publisher.EventPublisherHelper` | `Lcom/seeyon/boot/starter/udcrt/event/publisher/EventPublisher$EventPhase;` |
| `com.seeyon.boot.starter.udcrt.event.publisher.EventPublisherHelper` | `<T::Ljava/io/Serializable;>(TT;Lcom/seeyon/boot/starter/udcrt/event/publisher/EventPublisher$EventPhase;)V` |
| `com.seeyon.boot.starter.udcrt.event.publisher.EventPublisherHelper` | `publishBusinessEvent` |
| `com.seeyon.boot.starter.udcrt.event.publisher.EventPublisherHelper` | `(Ljava/lang/String;Lcom/seeyon/boot/mq/BaseMessage;Lcom/seeyon/boot/starter/udcrt/event/publisher/EventPublisher$EventPh` |
| `com.seeyon.boot.starter.udcrt.event.publisher.EventPublisherHelper` | `<T:Lcom/seeyon/boot/mq/BaseMessage;>(Ljava/lang/String;TT;Lcom/seeyon/boot/starter/udcrt/event/publisher/EventPublisher$` |
| `com.seeyon.boot.starter.udcrt.event.publisher.EventPublisherHelper` | `EventPublisherHelper.java` |
| `com.seeyon.boot.starter.udcrt.event.publisher.EventPublisherHelper` | `com/seeyon/boot/starter/udcrt/event/publisher/EventPublisherHelper` |
| `com.seeyon.boot.starter.udcrt.event.publisher.EventPublisherHelper` | `com/seeyon/boot/starter/udcrt/event/publisher/EventPublisher$EventPhase` |
| `com.seeyon.boot.starter.udcrt.event.publisher.EventPublisherHelper` | `com/seeyon/boot/starter/udcrt/event/publisher/impl/EntityEventPublisher` |
| `com.seeyon.boot.starter.udcrt.event.publisher.EventPublisherHelper` | `publish` |
| `com.seeyon.boot.starter.udcrt.event.publisher.EventPublisherHelper` | `(Ljava/lang/String;Ljava/io/Serializable;Lcom/seeyon/boot/starter/udcrt/event/publisher/EventPublisher$EventPhase;)V` |
| `com.seeyon.boot.starter.udcrt.event.publisher.EventPublisherHelper` | `com/seeyon/boot/starter/udcrt/event/publisher/impl/BusinessEventPublisher` |
| `com.seeyon.boot.starter.udcrt.event.publisher.EventPublisherHelper` | `com/seeyon/boot/starter/udcrt/event/publisher/EventPublisher` |
| `com.seeyon.boot.starter.udcrt.event.publisher.impl.BusinessEventPublisher$1` | `$SwitchMap$com$seeyon$boot$starter$udcrt$event$publisher$EventPublisher$EventPhase` |
| `com.seeyon.boot.starter.udcrt.event.publisher.impl.BusinessEventPublisher$1` | `BusinessEventPublisher.java` |
| `com.seeyon.boot.starter.udcrt.event.publisher.impl.BusinessEventPublisher$1` | `com/seeyon/boot/starter/udcrt/event/publisher/impl/BusinessEventPublisher$1` |
| `com.seeyon.boot.starter.udcrt.event.publisher.impl.BusinessEventPublisher$1` | `com/seeyon/boot/starter/udcrt/event/publisher/impl/BusinessEventPublisher` |
| `com.seeyon.boot.starter.udcrt.event.publisher.impl.BusinessEventPublisher$1` | `com/seeyon/boot/starter/udcrt/event/publisher/EventPublisher$EventPhase` |
| `com.seeyon.boot.starter.udcrt.event.publisher.impl.BusinessEventPublisher$1` | `()[Lcom/seeyon/boot/starter/udcrt/event/publisher/EventPublisher$EventPhase;` |
| `com.seeyon.boot.starter.udcrt.event.publisher.impl.BusinessEventPublisher$1` | `Lcom/seeyon/boot/starter/udcrt/event/publisher/EventPublisher$EventPhase;` |
| `com.seeyon.boot.starter.udcrt.event.publisher.impl.BusinessEventPublisher$1` | `com/seeyon/boot/starter/udcrt/event/publisher/EventPublisher` |
| `com.seeyon.boot.starter.udcrt.event.publisher.impl.BusinessEventPublisher` | `Lcom/seeyon/boot/starter/udcrt/event/publisher/impl/BusinessEventPublisher;` |
| `com.seeyon.boot.starter.udcrt.event.publisher.impl.BusinessEventPublisher` | `publish` |
| `com.seeyon.boot.starter.udcrt.event.publisher.impl.BusinessEventPublisher` | `(Ljava/lang/String;Ljava/io/Serializable;Lcom/seeyon/boot/starter/udcrt/event/publisher/EventPublisher$EventPhase;)V` |
| `com.seeyon.boot.starter.udcrt.event.publisher.impl.BusinessEventPublisher` | `Lcom/seeyon/boot/starter/udcrt/event/publisher/EventPublisher$EventPhase;` |
| `com.seeyon.boot.starter.udcrt.event.publisher.impl.BusinessEventPublisher` | `<T::Ljava/io/Serializable;>(Ljava/lang/String;TT;Lcom/seeyon/boot/starter/udcrt/event/publisher/EventPublisher$EventPhas` |
| `com.seeyon.boot.starter.udcrt.event.publisher.impl.BusinessEventPublisher` | `BusinessEventPublisher.java` |
| `com.seeyon.boot.starter.udcrt.event.publisher.impl.BusinessEventPublisher` | `com/seeyon/boot/starter/udcrt/event/publisher/impl/BusinessEventPublisher` |
| `com.seeyon.boot.starter.udcrt.event.publisher.impl.BusinessEventPublisher` | `com/seeyon/boot/starter/udcrt/event/publisher/EventPublisher` |
| `com.seeyon.boot.starter.udcrt.event.publisher.impl.BusinessEventPublisher` | `com/seeyon/boot/starter/udcrt/event/publisher/impl/BusinessEventPublisher$1` |
| `com.seeyon.boot.starter.udcrt.event.publisher.impl.BusinessEventPublisher` | `com/seeyon/boot/starter/udcrt/event/publisher/EventPublisher$EventPhase` |
| `com.seeyon.boot.starter.udcrt.event.publisher.impl.BusinessEventPublisher` | `$SwitchMap$com$seeyon$boot$starter$udcrt$event$publisher$EventPublisher$EventPhase` |
| `com.seeyon.boot.starter.udcrt.event.publisher.impl.EntityEventPublisher$1` | `$SwitchMap$com$seeyon$boot$starter$udcrt$event$publisher$EventPublisher$EventPhase` |
| `com.seeyon.boot.starter.udcrt.event.publisher.impl.EntityEventPublisher$1` | `EntityEventPublisher.java` |
| `com.seeyon.boot.starter.udcrt.event.publisher.impl.EntityEventPublisher$1` | `com/seeyon/boot/starter/udcrt/event/publisher/impl/EntityEventPublisher$1` |
| `com.seeyon.boot.starter.udcrt.event.publisher.impl.EntityEventPublisher$1` | `com/seeyon/boot/starter/udcrt/event/publisher/impl/EntityEventPublisher` |
| `com.seeyon.boot.starter.udcrt.event.publisher.impl.EntityEventPublisher$1` | `com/seeyon/boot/starter/udcrt/event/publisher/EventPublisher$EventPhase` |
| `com.seeyon.boot.starter.udcrt.event.publisher.impl.EntityEventPublisher$1` | `()[Lcom/seeyon/boot/starter/udcrt/event/publisher/EventPublisher$EventPhase;` |
| `com.seeyon.boot.starter.udcrt.event.publisher.impl.EntityEventPublisher$1` | `Lcom/seeyon/boot/starter/udcrt/event/publisher/EventPublisher$EventPhase;` |
| `com.seeyon.boot.starter.udcrt.event.publisher.impl.EntityEventPublisher$1` | `com/seeyon/boot/starter/udcrt/event/publisher/EventPublisher` |
| `com.seeyon.boot.starter.udcrt.event.publisher.impl.EntityEventPublisher` | `Lcom/seeyon/boot/starter/udcrt/event/publisher/impl/EntityEventPublisher;` |
| `com.seeyon.boot.starter.udcrt.event.publisher.impl.EntityEventPublisher` | `publish` |
| `com.seeyon.boot.starter.udcrt.event.publisher.impl.EntityEventPublisher` | `(Ljava/lang/String;Ljava/io/Serializable;Lcom/seeyon/boot/starter/udcrt/event/publisher/EventPublisher$EventPhase;)V` |
| `com.seeyon.boot.starter.udcrt.event.publisher.impl.EntityEventPublisher` | `Lcom/seeyon/boot/starter/udcrt/event/publisher/EventPublisher$EventPhase;` |
| `com.seeyon.boot.starter.udcrt.event.publisher.impl.EntityEventPublisher` | `<T::Ljava/io/Serializable;>(Ljava/lang/String;TT;Lcom/seeyon/boot/starter/udcrt/event/publisher/EventPublisher$EventPhas` |
| `com.seeyon.boot.starter.udcrt.event.publisher.impl.EntityEventPublisher` | `EntityEventPublisher.java` |
| `com.seeyon.boot.starter.udcrt.event.publisher.impl.EntityEventPublisher` | `com/seeyon/boot/starter/udcrt/event/publisher/impl/EntityEventPublisher` |
| `com.seeyon.boot.starter.udcrt.event.publisher.impl.EntityEventPublisher` | `com/seeyon/boot/starter/udcrt/event/publisher/EventPublisher` |
| `com.seeyon.boot.starter.udcrt.event.publisher.impl.EntityEventPublisher` | `com/seeyon/boot/starter/udcrt/event/publisher/impl/EntityEventPublisher$1` |
| `com.seeyon.boot.starter.udcrt.event.publisher.impl.EntityEventPublisher` | `com/seeyon/boot/starter/udcrt/event/publisher/EventPublisher$EventPhase` |
| `com.seeyon.boot.starter.udcrt.event.publisher.impl.EntityEventPublisher` | `$SwitchMap$com$seeyon$boot$starter$udcrt$event$publisher$EventPublisher$EventPhase` |
| `com.seeyon.boot.starter.udcrt.event.publisher.impl.EntityEventPublisher` | `publishAfterTransaction` |
| `com.seeyon.boot.starter.udcrt.migration.CustomApplicationHandler` | `UNPUBLISHED` |
| `com.seeyon.boot.starter.udcrt.proxy.UdcProxyAppServiceComponent` | `publish` |

### L-C-release（去重 3 条）

| 载体类 | 常量池 Utf8（截断 120 字符） |
|---|---|
| `com.seeyon.boot.starter.udcrt.domain.entity.BaseFormEntity` | `SMALLINT COMMENT '发布类型(TEST\|RELEASE)'` |
| `com.seeyon.boot.starter.udcrt.domain.service.CustomApplicationService` | `RELEASE` |
| `com.seeyon.boot.starter.udcrt.domain.service.database.UdcRuntimeDatabaseQueryService` | `releaseConnection` |

### L-C-topic（去重 6 条）

| 载体类 | 常量池 Utf8（截断 120 字符） |
|---|---|
| `com.seeyon.boot.starter.udcrt.event.listener.AppLoadEventListener` | `topic` |
| `com.seeyon.boot.starter.udcrt.event.listener.AppLoadEventListener` | `getCtpEnumIdReplaceJsonChangeTopic` |
| `com.seeyon.boot.starter.udcrt.event.listener.BpmRetryDelayMessage` | `topic` |
| `com.seeyon.boot.starter.udcrt.event.listener.BpmRetryListener` | `topic` |
| `com.seeyon.boot.starter.udcrt.mq.DeployChangeEventListener` | `topic` |
| `com.seeyon.boot.starter.udcrt.opinionbox.OpinionBoxListener` | `topic` |

### L-C-notice（去重 17 条）

| 载体类 | 常量池 Utf8（截断 120 字符） |
|---|---|
| `com.seeyon.boot.starter.udcrt.api.DeployNoticeService` | `deployNotice` |
| `com.seeyon.boot.starter.udcrt.api.DeployNoticeService` | `Lcom/seeyon/boot/starter/udcrt/api/DeployNoticeService;` |
| `com.seeyon.boot.starter.udcrt.api.DeployNoticeService` | `DeployNoticeService.java` |
| `com.seeyon.boot.starter.udcrt.api.DeployNoticeService` | `com/seeyon/boot/starter/udcrt/api/DeployNoticeService` |
| `com.seeyon.boot.starter.udcrt.domain.service.AbstractFromService` | `handleDeployNotice` |
| `com.seeyon.boot.starter.udcrt.domain.service.AbstractFromService` | `(Lcom/seeyon/udc/common/dto/DeployNoticeMsgDto;)V` |
| `com.seeyon.boot.starter.udcrt.domain.service.CustomApplicationService` | `handleDeployNotice` |
| `com.seeyon.boot.starter.udcrt.domain.service.CustomApplicationService` | `(Lcom/seeyon/udc/common/dto/DeployNoticeMsgDto;)V` |
| `com.seeyon.boot.starter.udcrt.domain.service.CustomApplicationService` | `Lcom/seeyon/udc/common/dto/DeployNoticeMsgDto;` |
| `com.seeyon.boot.starter.udcrt.domain.service.CustomApplicationService` | `com/seeyon/udc/common/dto/DeployNoticeMsgDto` |
| `com.seeyon.boot.starter.udcrt.mq.DeployChangeEventListener` | `(Lcom/seeyon/udc/common/dto/DeployNoticeMsgDto;)V` |
| `com.seeyon.boot.starter.udcrt.mq.DeployChangeEventListener` | `deployNoticeMsgDto` |
| `com.seeyon.boot.starter.udcrt.mq.DeployChangeEventListener` | `Lcom/seeyon/udc/common/dto/DeployNoticeMsgDto;` |
| `com.seeyon.boot.starter.udcrt.mq.DeployChangeEventListener` | `(Lcom/seeyon/udc/common/dto/DeployNoticeMsgDto;Lcom/seeyon/boot/starter/udcrt/domain/service/AbstractFromService;)V` |
| `com.seeyon.boot.starter.udcrt.mq.DeployChangeEventListener` | `com/seeyon/udc/common/dto/DeployNoticeMsgDto` |
| `com.seeyon.boot.starter.udcrt.mq.DeployChangeEventListener` | `(Lcom/seeyon/udc/common/dto/DeployNoticeMsgDto;)Ljava/util/function/Consumer;` |
| `com.seeyon.boot.starter.udcrt.mq.DeployChangeEventListener` | `handleDeployNotice` |

### L-C-发布（去重 20 条）

| 载体类 | 常量池 Utf8（截断 120 字符） |
|---|---|
| `com.seeyon.boot.starter.udcrt.appservice.CustomApplicationAppService` | `修改个性化页面应用发布状态` |
| `com.seeyon.boot.starter.udcrt.controller.CustomApplicationController` | `修改个性化页面应用发布状态` |
| `com.seeyon.boot.starter.udcrt.domain.entity.BaseFormEntity` | `DATETIME COMMENT '发布时间'` |
| `com.seeyon.boot.starter.udcrt.domain.entity.BaseFormEntity` | `发布时间` |
| `com.seeyon.boot.starter.udcrt.domain.entity.BaseFormEntity` | `发布类型` |
| `com.seeyon.boot.starter.udcrt.domain.entity.BaseFormEntity` | `SMALLINT COMMENT '发布类型(TEST\|RELEASE)'` |
| `com.seeyon.boot.starter.udcrt.domain.entity.CustomApplication` | `应用发布状态` |
| `com.seeyon.boot.starter.udcrt.domain.entity.CustomApplication` | `SMALLINT NOT NULL COMMENT '应用发布状态'` |
| `com.seeyon.boot.starter.udcrt.domain.entity.CustomApplication` | `应用发布失败原因` |
| `com.seeyon.boot.starter.udcrt.domain.entity.CustomApplication` | `VARCHAR(1000)  COMMENT '应用发布失败原因'` |
| `com.seeyon.boot.starter.udcrt.domain.service.CustomApplicationService` | `应用发布消息处理成功` |
| `com.seeyon.boot.starter.udcrt.domain.service.CustomApplicationService` | `处理应用发布消息失败:` |
| `com.seeyon.boot.starter.udcrt.domain.service.FromAcrossService` | `发布未成功数据忽略:{}` |
| `com.seeyon.boot.starter.udcrt.dto.CustomApplicationDto` | `应用发布状态` |
| `com.seeyon.boot.starter.udcrt.dto.CustomApplicationDto` | `应用发布失败原因` |
| `com.seeyon.boot.starter.udcrt.dto.CustomApplicationUpdateDeployStateDto` | `发布状态` |
| `com.seeyon.boot.starter.udcrt.dto.CustomApplicationUpdateDeployStateDto` | `修改个性化页面应用发布状态` |
| `com.seeyon.boot.starter.udcrt.listener.AppStartupChecker` | `应用启动检查，未找到锁文件，请检查是否进行了低代码平台锁定或者发布操作` |
| `com.seeyon.boot.starter.udcrt.mq.DeployChangeEventListener` | `接收到应用发布消息:{}` |
| `com.seeyon.boot.starter.udcrt.proxy.UdcRestPathParse` | `页面数据源信息不存在，请重新发布应用！` |

### L-C-推送（去重 1 条）

| 载体类 | 常量池 Utf8（截断 120 字符） |
|---|---|
| `com.seeyon.boot.starter.udcrt.domain.service.FromAcrossService$DataFilterHandler` | `应用[{}]存在设计态,忽略推送启用` |

### L-C-消息（去重 9 条）

| 载体类 | 常量池 Utf8（截断 120 字符） |
|---|---|
| `com.seeyon.boot.starter.udcrt.domain.service.BpmRetryService` | `流程发送失败，发送延迟消息....` |
| `com.seeyon.boot.starter.udcrt.domain.service.CustomApplicationService` | `应用发布消息处理成功` |
| `com.seeyon.boot.starter.udcrt.domain.service.CustomApplicationService` | `处理应用发布消息失败:` |
| `com.seeyon.boot.starter.udcrt.enums.MicroFlowActivityTypeEnum` | `业务消息` |
| `com.seeyon.boot.starter.udcrt.enums.MicroFlowActivityTypeEnum` | `消息中心` |
| `com.seeyon.boot.starter.udcrt.event.listener.BpmRetryDelayMessage` | `流程发送失败重试通用消息` |
| `com.seeyon.boot.starter.udcrt.event.listener.BpmRetryListener` | `收到流程失败重试延迟消息:【{}】` |
| `com.seeyon.boot.starter.udcrt.mq.DeployChangeEventListener` | `接收到应用发布消息:{}` |
| `com.seeyon.boot.starter.udcrt.mq.support.MicroFlowMqListenerIdempotenceSupport` | `消息已处理 idempotent key 为 {}，跳过重复执行，监听对象类型为 {}, 内容为 {}` |

### L-C-订阅（去重 1 条）

| 载体类 | 常量池 Utf8（截断 120 字符） |
|---|---|
| `com.seeyon.boot.starter.udcrt.domain.entity.UdcDataFlowLog` | `手工触发\|事件订阅` |

## 完备性三查 + 双口径一致性（r1_step5_completeness.json）

| 查 | 口径 | 结果 |
|---|---|---|
| A | `@RestController`/`@Controller` stereotype 类是否全在 mapping-bearing 集内 | controller 类 24 个；**bearing 集外 = 0**（缺口 0） |
| A' | mapping-bearing 类中是否存在 `@interface`（自定义元注解声明映射的盲区） | 0 |
| A'' | 仅 `@Component`（非 controller）的类数（旁证：非端点承载者） | 36 |
| B | 全类常量池 `/` 开头字面量中的 publish/deploy 词干（端点表外新路径盲区） | 1 条: [['com.seeyon.boot.starter.udcrt.controller.CustomApplicationController', '/update-deploy-state']] |
| C | L3 双口径: 自实现 JVMS 解析 vs javap -p -v 已解码文本独立再提取（annotation, path 原值）集合等值 | 比对 27 类，**mismatch = 0** |

## publish 域判定（本 jar 内）

- 只读候选（CANDIDATE，路径/基路径字面量含 publish/deploy 词干且注解为只读 GET）: **1** 条 ——`com.seeyon.boot.starter.udcrt.proxy.controller.UdcBaseAppInfoController.getDeployInfo`（`@GetMapping(value=["deploy-info"])`，返回 `SingleResponse<String>`，读 `app-deploy-info.json`）。
- 写形态（WRITE-EXCLUDED，标注不入契约）: **1** 条 ——`com.seeyon.boot.starter.udcrt.controller.CustomApplicationController.updateDeployState`（`@PostMapping("/update-deploy-state")`，入参 `(Long, DeployStateEnum, String)`，写发布状态）。
- 其余 129 行端点: EXCLUDED-NO-STEM（无 publish/deploy 词干）。
- L-C 层全部 publish/deploy 强词干常量：无一为端点路径声明（方法名 / 字段名 / 枚举常量 / 描述符 / 中文提示文案），唯一落在路径形态者是 `deploy-info`（已在 L-B 表）与 `/update-deploy-state`（写形态）。
