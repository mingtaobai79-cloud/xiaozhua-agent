# -*- coding: utf-8 -*-
"""R1 step4 | 由原始计数生成 publish 域扫描报告（publish-endpoint-literal-scan.md，只读输入）

输入: r1_step1_raw.json / r1_step3_dump_report.json / r1_step5_completeness.json
输出: publish-endpoint-literal-scan.md（L-A / L-B / L-C 全量表 + 完备性 + 双口径一致性）
"""
import json
import os
import sys
from datetime import datetime, timezone

OUTDIR = os.environ.get(
    "UDC_PUB_OUT",
    os.path.dirname(os.path.abspath(__file__)),
)
STRONG = ("publish", "deploy")
STEM_ORDER = [
    "publish", "deploy", "pub", "release", "dispatch", "topic", "channel", "emit",
    "notice", "announce", "broadcast", "发布", "部署", "推送", "公告", "通知", "消息", "广播", "订阅",
]


def main():
    raw = json.load(open(os.path.join(OUTDIR, "r1_step1_raw.json"), encoding="utf-8"))
    dump = json.load(open(os.path.join(OUTDIR, "r1_step3_dump_report.json"), encoding="utf-8"))
    comp = json.load(open(os.path.join(OUTDIR, "r1_step5_completeness.json"), encoding="utf-8"))
    dump_by_fqcn = {r["fqcn"]: r for r in dump["rows"]}

    L = []
    A = L.append
    A("# udc-publish-5.3.517｜publish 域三层扫描原始证据表（L-A / L-B / L-C）")
    A("")
    A("- 证据单元: 单 jar `udc-starter-runtime-5.3.517.jar`（任务声明构件，非 BI 先例的 6 jar 口径）")
    A("- jar 绝对路径: `%s`" % raw["jar"])
    A("- jar sha256: `%s`（%d B）" % (raw["jar_sha256"], raw["jar_bytes"]))
    A("- class 条目: %d（.class 口径含 `$` 内部类）／顶层类去 `$` = %d／非 class 资源条目 %d"
      % (raw["class_entry_count"], raw["top_level_class_count"], raw["resource_entry_count"]))
    A("- 生成脚本: `r1_scan_mapping_bearing.py`（L-A/L-B/L-C 扫描）→ `r1_step1_raw.json`；"
      "`r1_javap_dump.py` → `r1-<Class>.javap.txt` + `r1_step3_dump_report.json`；"
      "`r1_completeness_checks.py` → `r1_step5_completeness.json`；本文件由 `r1_build_report.py` 生成")
    A("- 生成时刻(UTC): %s" % datetime.now(timezone.utc).isoformat())
    A("- 解析错误类数: %d" % len(raw["parse_errors"]))
    A("")
    A("## L-A 类名层（346 class 全量 × 宽口径关键词子串）")
    A("")
    A("| 关键词 | 命中数 | 全限定类名 |")
    A("|---|---|---|")
    for k in STEM_ORDER:
        v = raw["layer_A"]["hits"].get(k)
        if not v:
            continue
        A("| `%s` | %d | %s |" % (k, len(v), "<br>".join("`%s`" % x for x in v)))
    tot_hit = sum(len(v) for v in raw["layer_A"]["hits"].values())
    A("")
    A("- 命中汇总: 强词干 publish %d / deploy %d；弱词干 pub %d / notice %d；其余词干 0"
      % (len(raw["layer_A"]["hits"].get("publish", [])), len(raw["layer_A"]["hits"].get("deploy", [])),
         len(raw["layer_A"]["hits"].get("pub", [])), len(raw["layer_A"]["hits"].get("notice", []))))
    A("- 类名层判定: **0 个 controller 类名承载 publish/deploy 域**——命中的 7 个 `event.publisher.*`"
      "为**事件发布器（EventPublisher 族，消息/业务事件投递工具类）**，2 个 `Deploy*`"
      "（`api.DeployNoticeService` 部署通知接口、`mq.DeployChangeEventListener` 部署变更 MQ 监听）"
      "与 1 个 `dto.CustomApplicationUpdateDeployStateDto` 均为服务/监听/DTO 层且非 mapping-bearing 类"
      "（见 L-B 表：三者均不在 27 个 mapping-bearing 类内）。`pub` 命中与 `publish` 命中为同 7 个类（子串关系）。")
    A("")
    A("## L-B 端点路径字面量层")
    A("")
    A("- mapping-bearing 类（按映射注解描述符筛，口径②）: **%d** 个；端点行 **%d** 条"
      "（类级基路径 %d 行 + 方法级 %d 行）"
      % (raw["layer_B"]["mapping_bearing_count"], raw["layer_B"]["endpoint_row_count"],
         len([b for b in raw["layer_B"]["bearing"] if b["class_level_paths"]]), len(raw["layer_B"]["endpoints"])))
    A("- 「常量池中以 `/` 开头字面量」兜底口径: **%d** 条（其中含 publish/deploy 词干者 %d 条: %s）"
      % (comp["checkB_slash_literal_total"], len(comp["checkB_slash_literals_with_stem"]),
         comp["checkB_slash_literals_with_stem"] or "无"))
    A("")
    A("### L-B-1 mapping-bearing 类清单（%d）" % raw["layer_B"]["mapping_bearing_count"])
    A("")
    A("| # | 类（class_sha256 前 12） | class_bytes | stereotype | 类级基路径原值 | 方法级端点数 | javap 证据件 |")
    A("|---|---|---|---|---|---|---|")
    for i, b in enumerate(raw["layer_B"]["bearing"], 1):
        r = dump_by_fqcn.get(b["fqcn"], {})
        A("| %d | `%s`<br>`%s` | %d | %s | %s | %d | `%s` |"
          % (i, b["fqcn"], b["class_sha256"], b["class_bytes"],
             ",".join(b["stereotypes"]) or "(无 stereotype)",
             "<br>".join("`%s`" % p for p in b["class_level_paths"]) or "(无类级 @RequestMapping)",
             b["method_count"], r.get("file", "-")))
    A("")
    A("### L-B-2 端点全量表（%d 行，逐条 publishing 判定）" % raw["layer_B"]["endpoint_row_count"])
    A("")
    A("| # | 类 | 注解(HTTP) | 方法 | 路径原值 | publish/deploy 词干判定 |")
    A("|---|---|---|---|---|---|")
    for i, r in enumerate(raw["layer_B"]["endpoints"], 1):
        paths = r["paths"]
        low = " ".join(paths).lower()
        hits = [k for k in ("publish", "deploy", "release", "pub") if k in low]
        if hits:
            verdict = "**HIT(%s)**" % ",".join(hits)
        else:
            verdict = "EXCLUDED-NO-STEM"
        A("| %d | `%s` | %s | `%s` | %s | %s |"
          % (i, r["class"].split(".")[-1], r["annotation"], r["method"],
             "<br>".join("`%s`" % p for p in paths), verdict))
    A("")
    A("## L-C 常量池全量层")
    A("")
    A("- 全部 %d 类的常量池 Utf8 总数: **%d**；publish 词干命中行数（含跨词干重复）: **%d**"
      % (raw["class_entry_count"], raw["layer_C"]["utf8_total"], raw["layer_C"]["hit_count"]))
    A("")
    seen = set()
    groups = {}
    for c, k, s in raw["layer_C"]["hits"]:
        key = (c, k, s)
        if key in seen:
            continue
        seen.add(key)
        groups.setdefault(k, []).append((c, s))
    for k in STEM_ORDER:
        if k not in groups:
            continue
        A("### L-C-%s（去重 %d 条）" % (k, len(groups[k])))
        A("")
        A("| 载体类 | 常量池 Utf8（截断 120 字符） |")
        A("|---|---|")
        for c, s in groups[k]:
            A("| `%s` | `%s` |" % (c, s[:120].replace("|", "\\|")))
        A("")
    A("## 完备性三查 + 双口径一致性（r1_step5_completeness.json）")
    A("")
    A("| 查 | 口径 | 结果 |")
    A("|---|---|---|")
    A("| A | `@RestController`/`@Controller` stereotype 类是否全在 mapping-bearing 集内 | controller 类 %d 个；**bearing 集外 = %d**（缺口 0） |"
      % (comp["checkA_stereotype_controller_classes"], len(comp["checkA_stereotype_outside_bearing"])))
    A("| A' | mapping-bearing 类中是否存在 `@interface`（自定义元注解声明映射的盲区） | %d |"
      % len(comp["checkA_annotation_type_in_bearing"]))
    A("| A'' | 仅 `@Component`（非 controller）的类数（旁证：非端点承载者） | %d |" % comp["checkA_component_only_classes"])
    A("| B | 全类常量池 `/` 开头字面量中的 publish/deploy 词干（端点表外新路径盲区） | %d 条: %s |"
      % (len(comp["checkB_slash_literals_with_stem"]), comp["checkB_slash_literals_with_stem"] or "无"))
    A("| C | L3 双口径: 自实现 JVMS 解析 vs javap -p -v 已解码文本独立再提取（annotation, path 原值）集合等值 | 比对 %d 类，**mismatch = %d** |"
      % (comp["mapping_bearing_classes_compared"], comp["mismatch_count"]))
    A("")
    A("## publish 域判定（本 jar 内）")
    A("")
    A("- 只读候选（CANDIDATE，路径/基路径字面量含 publish/deploy 词干且注解为只读 GET）: **1** 条 ——"
      "`com.seeyon.boot.starter.udcrt.proxy.controller.UdcBaseAppInfoController.getDeployInfo`"
      "（`@GetMapping(value=[\"deploy-info\"])`，返回 `SingleResponse<String>`，读 `app-deploy-info.json`）。")
    A("- 写形态（WRITE-EXCLUDED，标注不入契约）: **1** 条 ——"
      "`com.seeyon.boot.starter.udcrt.controller.CustomApplicationController.updateDeployState`"
      "（`@PostMapping(\"/update-deploy-state\")`，入参 `(Long, DeployStateEnum, String)`，写发布状态）。")
    A("- 其余 %d 行端点: EXCLUDED-NO-STEM（无 publish/deploy 词干）。"
      % (raw["layer_B"]["endpoint_row_count"] - 2))
    A("- L-C 层全部 publish/deploy 强词干常量：无一为端点路径声明（方法名 / 字段名 / 枚举常量 / 描述符 / 中文提示文案），"
      "唯一落在路径形态者是 `deploy-info`（已在 L-B 表）与 `/update-deploy-state`（写形态）。")
    A("")

    p = os.path.join(OUTDIR, "publish-endpoint-literal-scan.md")
    with open(p, "w", encoding="utf-8", newline="\n") as f:
        f.write("\n".join(L))
    print("wrote:", p, os.path.getsize(p), "B")


if __name__ == "__main__":
    sys.stdout.reconfigure(encoding="utf-8")
    main()
