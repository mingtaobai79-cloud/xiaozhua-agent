# -*- coding: utf-8 -*-
"""R1 step2 | 从 r1_step1_raw.json 导出命中清单（只读，供逐条判定）"""
import json
import os
import sys

OUTDIR = os.environ.get(
    "UDC_PUB_OUT",
    "D:/work/chit/seeyon-agent/docs/audit/artifacts/udc-publish-5.3.517",
)
d = json.load(open(os.path.join(OUTDIR, "r1_step1_raw.json"), encoding="utf-8"))

print("== L-A 类名层命中（完整 FQCN）==")
for k, v in sorted(d["layer_A"]["hits"].items()):
    print(" keyword=%-8s n=%d" % (k, len(v)))
    for f in v:
        print("     ", f)

print()
print("== L-B 端点表（%d 行）==" % d["layer_B"]["endpoint_row_count"])
for r in d["layer_B"]["endpoints"]:
    print(" %-70s | %-16s | %-32s | %s" % (r["class"], r["annotation"], r["method"], r["paths"]))

print()
print("== L-B 类级基路径（%d 类）==" % d["layer_B"]["mapping_bearing_count"])
for b in d["layer_B"]["bearing"]:
    print(" %-72s base=%s n_method=%d" % (b["fqcn"], b["class_level_paths"], b["method_count"]))

print()
print("== L-B / 开头常量池字面量（%d 条，兜底口径）==" % d["layer_B"]["slash_literal_count"])
for c, s in d["layer_B"]["slash_literals"]:
    print("  %-70s %s" % (c, s))

print()
print("== L-C 去重命中（按词干分组）==")
seen = set()
groups = {}
for c, k, s in d["layer_C"]["hits"]:
    key = (c, k, s)
    if key in seen:
        continue
    seen.add(key)
    groups.setdefault(k, []).append((c, s))
for k in ["publish", "deploy", "pub", "release", "dispatch", "topic", "channel", "emit",
          "notice", "announce", "broadcast", "发布", "部署", "推送", "公告", "通知", "消息", "广播", "订阅"]:
    if k in groups:
        print(" -- %s (%d 条)" % (k, len(groups[k])))
        for c, s in groups[k]:
            print("     %-72s %s" % (c, s[:150]))
