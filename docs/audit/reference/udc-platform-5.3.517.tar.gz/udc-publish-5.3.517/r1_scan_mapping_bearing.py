# -*- coding: utf-8 -*-
"""R1 step1 | udc-publish-5.3.517 宽口径三层扫描（只读，不写任何仓库业务文件）

层级:
  L-A 类名层       : 全部 .class 条目的 FQCN × publish 关键词宽口径子串
  L-B 端点路径字面量层: 按映射注解描述符筛 mapping-bearing 类 + 自实现 JVMS 解析器
                     取 @RequestMapping/@GetMapping/... 的 path/value element_value 原值
                     + 「常量池中以 / 开头的 Utf8」兜底口径
  L-C 常量池全量层 : 全部类的全部常量池 Utf8（含中文）逐条 publish 词干扫描

证据单元: 任务声明的单 jar（udc-starter-runtime-5.3.517.jar）。
变量: UDC_PUB_JAR / UDC_PUB_OUT。
"""
import hashlib
import json
import os
import struct
import sys
import zipfile
from datetime import datetime, timezone

JAR = os.environ.get(
    "UDC_PUB_JAR",
    "D:/repo/CHIT/com/seeyon/udc-starter-runtime/5.3.517/udc-starter-runtime-5.3.517.jar",
)
OUTDIR = os.environ.get(
    "UDC_PUB_OUT",
    "D:/work/chit/seeyon-agent/docs/audit/artifacts/udc-publish-5.3.517",
)

SPRING = "Lorg/springframework/web/bind/annotation/"
MAPPING_DESCS = {
    SPRING + "RequestMapping;": "RequestMapping",
    SPRING + "GetMapping;": "GetMapping",
    SPRING + "PostMapping;": "PostMapping",
    SPRING + "PutMapping;": "PutMapping",
    SPRING + "DeleteMapping;": "DeleteMapping",
    SPRING + "PatchMapping;": "PatchMapping",
}
JAXRS_DESCS = {
    "Ljavax/ws/rs/Path;": "JaxRsPath",
    "Ljavax/ws/rs/GET;": "JaxRsGET",
    "Ljavax/ws/rs/POST;": "JaxRsPOST",
    "Ljavax/ws/rs/PUT;": "JaxRsPUT",
    "Ljavax/ws/rs/DELETE;": "JaxRsDELETE",
}
STEREOTYPES = {
    "Lorg/springframework/web/bind/annotation/RestController;": "RestController",
    "Lorg/springframework/stereotype/Controller;": "Controller",
    "Lorg/springframework/stereotype/Component;": "Component",
}

# L-A / L-C 收词（宽口径，先收再逐条排除）
STRONG_KW = ["publish", "deploy"]
WEAK_KW = ["pub", "release", "dispatch", "topic", "channel", "emit", "notice", "announce", "broadcast"]
CN_KW = ["发布", "部署", "推送", "公告", "通知", "消息", "广播", "订阅"]
ALL_KW = STRONG_KW + WEAK_KW


# ---------------- JVMS 常量池 / 注解解析 ----------------
def cp_parse(b):
    n = struct.unpack_from(">H", b, 8)[0]
    i = 10
    cp = [None] * n
    k = 1
    while k < n:
        tag = b[i]
        i += 1
        if tag == 1:  # Utf8
            ln = struct.unpack_from(">H", b, i)[0]
            i += 2
            cp[k] = ("Utf8", b[i : i + ln].decode("utf-8", "replace"))
            i += ln
        elif tag in (3, 4):  # Integer / Float
            cp[k] = ("num",)
            i += 4
        elif tag in (5, 6):  # Long / Double (2 slots)
            cp[k] = ("long",)
            i += 8
            k += 1
        elif tag in (7, 8, 16, 19, 20):  # Class/String/MethodType/Module/Package
            cp[k] = ("ref2", struct.unpack_from(">H", b, i)[0])
            i += 2
        elif tag in (9, 10, 11, 12, 17, 18):  # refs
            cp[k] = ("ref4",)
            i += 4
        elif tag == 15:  # MethodHandle
            cp[k] = ("mh",)
            i += 3
        else:
            raise ValueError("cp tag %r at %d" % (tag, i))
        k += 1
    return cp, i


def utf8_at(cp, idx):
    e = cp[idx]
    if e and e[0] == "Utf8":
        return e[1]
    return None


def ev_parse(cp, b, i):
    """element_value -> (value, new_i)；常量串返回 str，数组返回 list。"""
    tag = chr(b[i])
    i += 1
    if tag in "BCDFIJSZs":
        v = utf8_at(cp, struct.unpack_from(">H", b, i)[0])
        i += 2
        return v, i
    if tag == "e":
        i += 4
        return None, i
    if tag == "c":
        v = utf8_at(cp, struct.unpack_from(">H", b, i)[0])
        i += 2
        return v, i
    if tag == "@":
        _, i, _ = ann_parse(cp, b, i)
        return None, i
    if tag == "[":
        n = struct.unpack_from(">H", b, i)[0]
        i += 2
        vals = []
        for _ in range(n):
            v, i = ev_parse(cp, b, i)
            vals.append(v)
        return vals, i
    raise ValueError("ev tag %r" % tag)


def ann_parse(cp, b, i):
    desc = utf8_at(cp, struct.unpack_from(">H", b, i)[0])
    i += 2
    npairs = struct.unpack_from(">H", b, i)[0]
    i += 2
    elems = {}
    for _ in range(npairs):
        name = utf8_at(cp, struct.unpack_from(">H", b, i)[0])
        i += 2
        v, i = ev_parse(cp, b, i)
        elems[name] = v
    return desc, i, elems


def attrs_parse(cp, b, i, want_ann):
    ac = struct.unpack_from(">H", b, i)[0]
    i += 2
    anns = []
    for _ in range(ac):
        name = utf8_at(cp, struct.unpack_from(">H", b, i)[0])
        i += 2
        ln = struct.unpack_from(">I", b, i)[0]
        i += 4
        end = i + ln
        if want_ann and name == "RuntimeVisibleAnnotations":
            n = struct.unpack_from(">H", b, i)[0]
            j = i + 2
            for _ in range(n):
                d, j, e = ann_parse(cp, b, j)
                anns.append((d, e))
        i = end
    return anns, i


def parse_class(b):
    if b[:4] != b"\xca\xfe\xba\xbe":
        raise ValueError("not a class file")
    cp, i = cp_parse(b)
    i += 6  # access_flags / this_class / super_class
    ic = struct.unpack_from(">H", b, i)[0]
    i += 2 + 2 * ic
    fc = struct.unpack_from(">H", b, i)[0]
    i += 2
    for _ in range(fc):
        i += 6
        _, i = attrs_parse(cp, b, i, False)
    mc = struct.unpack_from(">H", b, i)[0]
    i += 2
    methods = []
    for _ in range(mc):
        _acc, ni, di = struct.unpack_from(">HHH", b, i)
        i += 6
        manns, i = attrs_parse(cp, b, i, True)
        methods.append((utf8_at(cp, ni), utf8_at(cp, di), manns))
    cann, i = attrs_parse(cp, b, i, True)
    return cp, cann, methods


def paths_of(elems):
    """从映射注解 element_value 里取 path/value 原值（多条保留原序）。"""
    out = []
    for key in ("path", "value"):
        if key in elems:
            v = elems[key]
            if isinstance(v, list):
                out.extend([x for x in v if isinstance(x, str)])
            elif isinstance(v, str):
                out.append(v)
    return out


def kw_hits(text, kws):
    low = text.lower()
    return [k for k in kws if k.lower() in low]


def main():
    jar_bytes = open(JAR, "rb").read()
    jar_sha = hashlib.sha256(jar_bytes).hexdigest()
    zf = zipfile.ZipFile(JAR)
    entries = zf.namelist()
    classes = sorted(e for e in entries if e.endswith(".class"))
    resources = sorted(e for e in entries if not e.endswith(".class"))

    la_hits = {k: [] for k in ALL_KW + CN_KW}
    la_all = []
    for e in classes:
        fqcn = e[:-6].replace("/", ".")
        la_all.append(fqcn)
        for k in kw_hits(fqcn, ALL_KW):
            la_hits[k].append(fqcn)
        for k in CN_KW:
            if k in fqcn:
                la_hits[k].append(fqcn)

    bearing = []
    endpoints = []
    parse_errors = []
    class_sha = {}
    lc_hits = []
    utf8_total = 0
    slash_literals = []
    for e in classes:
        raw = zf.read(e)
        fqcn = e[:-6].replace("/", ".")
        class_sha[fqcn] = hashlib.sha256(raw).hexdigest()
        try:
            cp, cann, methods = parse_class(raw)
        except Exception as ex:  # noqa: BLE001
            parse_errors.append([fqcn, repr(ex)])
            continue
        pool = [x[1] for x in cp if x and x[0] == "Utf8"]
        utf8_total += len(pool)
        for s in pool:
            if s.startswith("/"):
                slash_literals.append([fqcn, s])
        for k in kw_hits("\n".join(pool), ALL_KW):
            for s in pool:
                if k.lower() in s.lower():
                    lc_hits.append([fqcn, k, s])
        for k in CN_KW:
            for s in pool:
                if k in s:
                    lc_hits.append([fqcn, k, s])

        pool_set = set(pool)
        is_bearing = any(d in pool_set for d in MAPPING_DESCS) or any(
            d in pool_set for d in JAXRS_DESCS
        )
        stereo = [STEREOTYPES[d] for d, _ in cann if d in STEREOTYPES]
        cl_base = []
        for d, el in cann:
            if d in MAPPING_DESCS:
                cl_base.extend(paths_of(el))
        m_rows = []
        for mn, md, ms in methods:
            for d, el in ms:
                if d in MAPPING_DESCS or d in JAXRS_DESCS:
                    name = MAPPING_DESCS.get(d) or JAXRS_DESCS.get(d)
                    m_rows.append(
                        {
                            "class": fqcn,
                            "method": mn,
                            "descriptor": md,
                            "annotation": name,
                            "paths": paths_of(el),
                        }
                    )
        if is_bearing or cl_base or m_rows:
            bearing.append(
                {
                    "fqcn": fqcn,
                    "class_entry": e,
                    "class_sha256": class_sha[fqcn],
                    "class_bytes": len(raw),
                    "stereotypes": stereo,
                    "class_level_paths": cl_base,
                    "method_count": len(m_rows),
                }
            )
            endpoints.extend(m_rows)

    out = {
        "step": "r1_step1_raw",
        "generated_at_utc": datetime.now(timezone.utc).isoformat(),
        "jar": JAR,
        "jar_sha256": jar_sha,
        "jar_bytes": len(jar_bytes),
        "class_entry_count": len(classes),
        "top_level_class_count": len({c.split("$")[0] for c in la_all}),
        "resource_entry_count": len(resources),
        "class_list": la_all,
        "res_class_entries": resources,
        "parse_errors": parse_errors,
        "layer_A": {"keywords": ALL_KW + CN_KW, "hits": {k: v for k, v in la_hits.items() if v}},
        "layer_B": {
            "mapping_bearing_count": len(bearing),
            "bearing": bearing,
            "endpoint_row_count": len(endpoints),
            "endpoints": endpoints,
            "slash_literal_count": len(slash_literals),
            "slash_literals": slash_literals,
        },
        "layer_C": {
            "utf8_total": utf8_total,
            "hit_count": len(lc_hits),
            "hits": lc_hits,
        },
        "class_sha256": class_sha,
    }
    os.makedirs(OUTDIR, exist_ok=True)
    p = os.path.join(OUTDIR, "r1_step1_raw.json")
    with open(p, "w", encoding="utf-8") as f:
        json.dump(out, f, ensure_ascii=False, indent=1)

    print("JAR sha256:", jar_sha)
    print("class entries:", len(classes), "top-level:", out["top_level_class_count"])
    print("parse_errors:", len(parse_errors))
    print("L-A hits:", json.dumps({k: len(v) for k, v in la_hits.items() if v}, ensure_ascii=False))
    print("L-B mapping-bearing:", len(bearing), "endpoint rows:", len(endpoints),
          "slash literals:", len(slash_literals))
    print("L-B bearing classes:")
    for x in bearing:
        print("   ", x["fqcn"], "| stereo=", x["stereotypes"], "| base=", x["class_level_paths"],
              "| methods=", x["method_count"])
    print("L-C utf8 total:", utf8_total, "hit rows:", len(lc_hits))
    seen = set()
    for c, k, s in lc_hits:
        key = (k, s)
        if key in seen:
            continue
        seen.add(key)
        print("    [C]", k, "|", c, "|", s[:160])
    print("wrote:", p)


if __name__ == "__main__":
    sys.stdout.reconfigure(encoding="utf-8")
    main()
