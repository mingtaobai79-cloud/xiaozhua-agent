# boot-starter-sensitive：接口与方法签名

> 自动生成，勿手改。`tools/core/platform/emit_package_surfaces.py` 重跑即可。
> 构件 `com.seeyon:boot-starter-sensitive`（jar `boot-starter-sensitive-5.3.603.jar`）
> 规模：9 类 / 0 接口 / 0 注解 / 0 枚举 / 1 个关键类 / 40 方法。
> 签名逐字来自 javap 原文；已去掉 `public` 前缀与 `throws` 子句。

## 一、接口（0）

（本构件没有接口）

## 二、关键类（1）

### `SensitiveWordService`（11 方法）

`com.seeyon.boot.starter.sensitive.domain.service.SensitiveWordService`

```java
    void sensitiveCheck(com.seeyon.boot.starter.sensitive.dto.SensitiveCheckDto, java.lang.Object);
    void sensitiveCheckNew(com.seeyon.boot.starter.sensitive.dto.SensitiveCheckDto, java.util.Map<java.lang.String, java.lang.Object>, java.util.Map<java.lang.String, java.lang.String>);
    private void setProperty(java.lang.Object, java.lang.String, java.lang.String, int, java.util.Map<java.lang.String, java.lang.String>)
    java.lang.Object invokeResult(java.lang.Object);
    java.lang.String getTranslateCode(java.lang.String, java.lang.String);
    java.lang.String invokeBpmTemplate(java.lang.Long, java.lang.String);
    com.seeyon.boot.transport.SingleResponse<java.lang.Object> invokeAppService(java.lang.String, java.lang.String, java.lang.String, java.lang.Object, java.lang.String);
```
