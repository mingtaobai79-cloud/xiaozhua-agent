# boot-starter-transaction：接口与方法签名

> 自动生成，勿手改。`tools/core/platform/emit_package_surfaces.py` 重跑即可。
> 构件 `com.seeyon:boot-starter-transaction`（jar `boot-starter-transaction-5.3.600.jar`）
> 规模：15 类 / 0 接口 / 0 注解 / 0 枚举 / 1 个关键类 / 56 方法。
> 签名逐字来自 javap 原文；已去掉 `public` 前缀与 `throws` 子句。

## 一、接口（0）

（本构件没有接口）

## 二、关键类（1）

### `TransactionAutoConfiguration`（22 方法）

`com.seeyon.boot.starter.transaction.TransactionAutoConfiguration`

```java
    org.apache.servicecomb.pack.omega.context.IdGenerator<java.lang.String> idGenerator();
    org.apache.servicecomb.pack.omega.context.OmegaContext omegaContext(org.apache.servicecomb.pack.omega.context.IdGenerator<java.lang.String>, org.apache.servicecomb.pack.omega.transaction.SagaMessageSender);
    org.apache.servicecomb.pack.omega.transaction.CallbackContext compensationContext(org.apache.servicecomb.pack.omega.context.OmegaContext, org.apache.servicecomb.pack.omega.transaction.SagaMessageSender);
    org.apache.servicecomb.pack.omega.transaction.CallbackContext coordinateContext(org.apache.servicecomb.pack.omega.context.OmegaContext, org.apache.servicecomb.pack.omega.transaction.SagaMessageSender);
    org.apache.servicecomb.pack.omega.context.ServiceConfig serviceConfig(java.lang.String, java.lang.String);
    org.apache.servicecomb.pack.omega.transaction.tcc.ParametersContext parametersContext();
    org.apache.servicecomb.pack.omega.connector.grpc.AlphaClusterDiscovery alphaClusterAddress(java.lang.String);
    private java.lang.String[] getCoordinatorServer(java.lang.String);
    private java.lang.String nameSpace();
    org.apache.servicecomb.pack.omega.connector.grpc.AlphaClusterConfig alphaClusterConfig(boolean, boolean, java.lang.String, java.lang.String, java.lang.String, org.apache.servicecomb.pack.omega.connector.grpc.AlphaClusterDiscovery, org.apache.servicecomb.pack.omega.transaction.MessageHandler, org.apache.servicecomb.pack.omega.transaction.tcc.TccMessageHandler);
    org.apache.servicecomb.pack.omega.connector.grpc.core.LoadBalanceContext sagaLoadBalanceSenderContext(org.apache.servicecomb.pack.omega.connector.grpc.AlphaClusterConfig, org.apache.servicecomb.pack.omega.context.ServiceConfig, int, int);
    org.apache.servicecomb.pack.omega.transaction.SagaMessageSender sagaLoadBalanceSender(org.apache.servicecomb.pack.omega.connector.grpc.core.LoadBalanceContext);
    org.apache.servicecomb.pack.omega.connector.grpc.core.LoadBalanceContext loadBalanceSenderContext(org.apache.servicecomb.pack.omega.connector.grpc.AlphaClusterConfig, org.apache.servicecomb.pack.omega.context.ServiceConfig, int, int);
    org.apache.servicecomb.pack.omega.transaction.tcc.TccMessageSender tccLoadBalanceSender(org.apache.servicecomb.pack.omega.connector.grpc.core.LoadBalanceContext);
    org.apache.servicecomb.pack.omega.transaction.MessageHandler messageHandler(org.apache.servicecomb.pack.omega.transaction.SagaMessageSender, org.apache.servicecomb.pack.omega.transaction.CallbackContext, org.apache.servicecomb.pack.omega.context.OmegaContext);
    org.apache.servicecomb.pack.omega.transaction.SagaStartAspect sagaStartAspect(org.apache.servicecomb.pack.omega.transaction.SagaMessageSender, org.apache.servicecomb.pack.omega.context.OmegaContext);
    com.seeyon.boot.starter.transaction.SagaAspect sagaAspect(org.apache.servicecomb.pack.omega.transaction.SagaMessageSender, org.apache.servicecomb.pack.omega.context.OmegaContext);
    com.seeyon.boot.starter.transaction.CompensableAnnotationProcessor compensableAnnotationProcessor(org.apache.servicecomb.pack.omega.context.OmegaContext, org.apache.servicecomb.pack.omega.transaction.CallbackContext);
    org.apache.servicecomb.pack.omega.transaction.tcc.TccMessageHandler coordinateMessageHandler(org.apache.servicecomb.pack.omega.transaction.tcc.TccMessageSender, org.apache.servicecomb.pack.omega.transaction.CallbackContext, org.apache.servicecomb.pack.omega.context.OmegaContext, org.apache.servicecomb.pack.omega.transaction.tcc.ParametersContext);
    org.apache.servicecomb.pack.omega.transaction.tcc.TccStartAspect tccStartAspect(org.apache.servicecomb.pack.omega.transaction.tcc.TccMessageSender, org.apache.servicecomb.pack.omega.context.OmegaContext);
    com.seeyon.boot.starter.transaction.TccParticipatorAspect tccParticipatorAspect(org.apache.servicecomb.pack.omega.transaction.tcc.TccMessageSender, org.apache.servicecomb.pack.omega.context.OmegaContext, org.apache.servicecomb.pack.omega.transaction.tcc.ParametersContext);
    com.seeyon.boot.starter.transaction.ParticipateAnnotationProcessor participateAnnotationProcessor(org.apache.servicecomb.pack.omega.context.OmegaContext, org.apache.servicecomb.pack.omega.transaction.CallbackContext);
```
