# boot-starter-elasticsearch：接口与方法签名

> 自动生成，勿手改。`tools/core/platform/emit_package_surfaces.py` 重跑即可。
> 构件 `com.seeyon:boot-starter-elasticsearch`（jar `boot-starter-elasticsearch-5.3.290.jar`）
> 规模：25 类 / 1 接口 / 0 注解 / 2 枚举 / 2 个关键类 / 252 方法。
> 签名逐字来自 javap 原文；已去掉 `public` 前缀与 `throws` 子句。

## 一、接口（1）

### `BaseElasticsearchRepository`（28 方法）

`com.seeyon.boot.starter.elasticsearch.repository.BaseElasticsearchRepository`

```java
    <S extends T> S save(S);
    <S extends T> java.lang.Iterable<S> saveAll(java.lang.Iterable<S>);
    void deleteById(java.lang.String);
    void deleteByIds(java.lang.Iterable<java.lang.String>);
    T selectById(java.lang.String);
    java.util.List<T> selectByIds(java.lang.Iterable<java.lang.String>);
    default T selectOneByCriteria(com.seeyon.boot.starter.elasticsearch.query.Criteria);
    java.util.List<T> selectListByCriteria(com.seeyon.boot.starter.elasticsearch.query.Criteria, com.seeyon.boot.transport.Sort);
    com.seeyon.boot.transport.PageData<T> selectPageByCriteria(com.seeyon.boot.transport.PageInfo, com.seeyon.boot.starter.elasticsearch.query.Criteria, com.seeyon.boot.transport.Sort);
    java.util.List<java.util.Map<java.lang.String, java.lang.Object>> selectListByCriteria(com.seeyon.boot.starter.elasticsearch.query.Criteria, java.util.List<com.seeyon.boot.starter.elasticsearch.query.QueryField>, com.seeyon.boot.transport.Sort);
    com.seeyon.boot.transport.PageData<java.util.Map<java.lang.String, java.lang.Object>> selectPageByCriteria(com.seeyon.boot.transport.PageInfo, com.seeyon.boot.starter.elasticsearch.query.Criteria, java.util.List<com.seeyon.boot.starter.elasticsearch.query.QueryField>, com.seeyon.boot.transport.Sort);
    long selectCountByCriteria(com.seeyon.boot.starter.elasticsearch.query.Criteria);
    default T selectOneByStringQuery(java.lang.String);
    java.util.List<T> selectListByStringQuery(java.lang.String, com.seeyon.boot.transport.Sort);
    com.seeyon.boot.transport.PageData<T> selectPageByStringQuery(com.seeyon.boot.transport.PageInfo, java.lang.String, com.seeyon.boot.transport.Sort);
    java.util.List<T> selectListByNativeQueryBuilder(org.springframework.data.elasticsearch.core.query.NativeSearchQueryBuilder, com.seeyon.boot.transport.Sort);
    org.springframework.data.elasticsearch.core.SearchHits<T> selectSearchHitsByNativeQueryBuilder(org.springframework.data.elasticsearch.core.query.NativeSearchQueryBuilder, com.seeyon.boot.transport.Sort);
    org.elasticsearch.action.search.SearchResponse suggest(org.elasticsearch.search.suggest.SuggestBuilder);
    long selectCountByStringQuery(java.lang.String);
    int updateById(java.lang.String, java.util.Map<java.lang.String, java.lang.Object>);
    int updateByScript(java.lang.String, java.lang.String, java.util.Map<java.lang.String, java.lang.Object>);
    int updateByScript(com.seeyon.boot.starter.elasticsearch.query.Criteria, java.lang.String, java.util.Map<java.lang.String, java.lang.Object>);
    int updateByCriteria(com.seeyon.boot.starter.elasticsearch.query.Criteria, java.util.Map<java.lang.String, java.lang.Object>);
    int updateByStringQuery(java.lang.String, java.util.Map<java.lang.String, java.lang.Object>);
    int deleteByCriteria(com.seeyon.boot.starter.elasticsearch.query.Criteria);
    int deleteByStringQuery(java.lang.String);
    com.seeyon.boot.starter.elasticsearch.aggregation.PartData compositeByCriteria(com.seeyon.boot.starter.elasticsearch.query.Criteria, java.util.List<com.seeyon.boot.starter.elasticsearch.query.CompositeField>, com.seeyon.boot.starter.elasticsearch.aggregation.Partition);
    java.util.List<java.util.Map<java.lang.String, java.lang.Object>> termByCriteria(com.seeyon.boot.starter.elasticsearch.query.Criteria, java.lang.String, com.seeyon.boot.starter.elasticsearch.enums.MetricAggregation...);
```

## 二、关键类（2）

### `ElasticsearchAutoConfiguration`（14 方法）

`com.seeyon.boot.starter.elasticsearch.ElasticsearchAutoConfiguration`

```java
    org.elasticsearch.client.RestHighLevelClient elasticsearchClient();
    protected java.util.Collection<java.lang.String> getMappingBasePackages();
    private org.springframework.data.elasticsearch.client.ClientConfiguration buildConfiguration();
    private org.elasticsearch.client.RestClient buildRestClient(org.springframework.data.elasticsearch.client.ClientConfiguration);
    static private static java.util.List<java.lang.String> formattedHosts(java.util.List<java.net.InetSocketAddress>, boolean);
    static private static org.apache.http.Header[] toHeaderArray(org.springframework.http.HttpHeaders);
```

### `ElasticsearchDisableAutoConfiguration`（3 方法）

`com.seeyon.boot.starter.elasticsearch.ElasticsearchDisableAutoConfiguration`

```java
    org.elasticsearch.client.RestHighLevelClient elasticsearchClient();
    private org.springframework.data.elasticsearch.client.ClientConfiguration buildConfiguration();
    protected java.util.Collection<java.lang.String> getMappingBasePackages();
```

## 四、枚举（2）

- `MappingType`（6 常量）：Keyword, Long, Integer, Double, Float, Date
- `MetricAggregation`（1 常量）：count
