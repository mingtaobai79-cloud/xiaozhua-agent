# devops-starter-artifact：接口与方法签名

> 自动生成，勿手改。`tools/core/platform/emit_package_surfaces.py` 重跑即可。
> 构件 `com.seeyon:devops-starter-artifact`（jar `devops-starter-artifact-5.3.600.jar`）
> 规模：51 类 / 4 接口 / 0 注解 / 3 枚举 / 20 个关键类 / 611 方法。
> 签名逐字来自 javap 原文；已去掉 `public` 前缀与 `throws` 子句。

## 一、接口（4）

### `ArtifactService`（19 方法）

`com.seeyon.devops.starter.artifact.ArtifactService`

```java
    com.seeyon.devops.starter.artifact.enums.MavenTypeEnum getMavenType();
    boolean upload(com.seeyon.devops.starter.artifact.dto.ArtifactDto)
    default boolean offlineMode();
    default java.lang.String defaultMavenCmd();
    default java.lang.String getMvnBasePath();
    default java.lang.String buildLocalDownPath(java.lang.String);
    java.lang.String download(com.seeyon.devops.starter.artifact.dto.ArtifactDto);
    java.lang.String download(com.seeyon.devops.starter.artifact.dto.ArtifactDto, java.util.function.Supplier<java.lang.Exception>);
    boolean delete(com.seeyon.devops.starter.artifact.dto.ArtifactDto);
    java.util.List<java.lang.String> downloadModuleJars(java.lang.String, java.lang.String, java.util.List<java.lang.String>, java.lang.String);
    default boolean exist(com.seeyon.devops.starter.artifact.dto.ArtifactDto);
    java.lang.String getLatestVersion(java.lang.String, java.lang.String, java.lang.String);
    java.util.List<java.lang.String> resolveVersionRange(com.seeyon.devops.starter.artifact.dto.VersionRangeArtifactDto);
    default java.util.List<java.lang.String> asyncDownloadAll(java.lang.String, java.lang.String, java.util.List<java.lang.String>, java.lang.String);
```

### `AbstractArtifactManager`（14 方法）

`com.seeyon.devops.starter.artifact.manager.AbstractArtifactManager`

```java
    com.seeyon.devops.common.enums.AppTypeEnum getAppType();
    java.util.List<java.lang.String> getModuleList();
    boolean exist(com.seeyon.devops.starter.artifact.dto.ArtifactDto);
    java.lang.String download(com.seeyon.devops.starter.artifact.dto.ArtifactDto);
    boolean upload(com.seeyon.devops.starter.artifact.dto.ArtifactDto)
    boolean delete(com.seeyon.devops.starter.artifact.dto.ArtifactDto);
    java.lang.String downloadForFerryboat(com.seeyon.devops.starter.artifact.dto.ArtifactDto);
    boolean uploadForFerryboat(com.seeyon.devops.starter.artifact.dto.ArtifactDto);
    java.util.List<java.lang.String> downloadLocalAppModuleJars(java.lang.String, java.lang.String, java.lang.String);
    java.util.List<java.lang.String> downloadRemoteAppModuleJars(java.lang.String, java.lang.String, java.lang.String);
    boolean bucketExchangeFerryboat(com.seeyon.devops.starter.artifact.dto.ArtifactDto);
    boolean batchBucketExchangeFerryboat(java.util.List<com.seeyon.devops.starter.artifact.dto.ArtifactDto>);
    boolean ferryboatExchangeBucket(com.seeyon.devops.starter.artifact.dto.ArtifactDto);
    boolean batchFerryboatExchangeBucket(java.util.List<com.seeyon.devops.starter.artifact.dto.ArtifactDto>);
```

### `NpmService`（5 方法）

`com.seeyon.devops.starter.artifact.npm.NpmService`

```java
    com.seeyon.devops.starter.artifact.enums.StorageTypeEnum getNpmType();
    java.io.InputStream getInputStream(java.lang.String);
    java.util.List<com.seeyon.devops.starter.artifact.npm.dto.PackageInfoDto> parsePackage(com.seeyon.devops.starter.artifact.npm.dto.FrontPackageDto);
    java.lang.String downloadTarFileByHostApp(java.lang.String, java.lang.String);
    default java.lang.String getProfile(java.lang.String);
```

### `Const`（0 方法） extends Const

`com.seeyon.devops.starter.artifact.constant.Const`

```java
```

## 二、关键类（20）

### `FormArtifactManager`（32 方法）

`com.seeyon.devops.starter.artifact.manager.FormArtifactManager`

```java
    com.seeyon.devops.common.enums.AppTypeEnum getAppType();
    java.util.List<java.lang.String> getModuleList();
    boolean exist(com.seeyon.devops.starter.artifact.dto.ArtifactDto);
    java.lang.String download(com.seeyon.devops.starter.artifact.dto.ArtifactDto);
    private java.lang.String downloadFormFerryboat(com.seeyon.devops.starter.artifact.dto.ArtifactDto);
    private void writeFromStream(java.io.InputStream, java.lang.String);
    java.lang.String downloadForFerryboat(com.seeyon.devops.starter.artifact.dto.ArtifactDto);
    boolean uploadForFerryboat(com.seeyon.devops.starter.artifact.dto.ArtifactDto);
    boolean upload(com.seeyon.devops.starter.artifact.dto.ArtifactDto)
    boolean delete(com.seeyon.devops.starter.artifact.dto.ArtifactDto);
    java.util.List<java.lang.String> downloadLocalAppModuleJars(java.lang.String, java.lang.String, java.lang.String);
    java.util.List<java.lang.String> downloadRemoteAppModuleJars(java.lang.String, java.lang.String, java.lang.String);
    java.util.List<java.lang.String> downloadModuleJars(java.lang.String, java.lang.String, java.util.List<java.lang.String>, java.lang.String);
    boolean bucketExchangeFerryboat(com.seeyon.devops.starter.artifact.dto.ArtifactDto);
    boolean batchBucketExchangeFerryboat(java.util.List<com.seeyon.devops.starter.artifact.dto.ArtifactDto>);
    boolean ferryboatExchangeBucket(com.seeyon.devops.starter.artifact.dto.ArtifactDto);
    boolean batchFerryboatExchangeBucket(java.util.List<com.seeyon.devops.starter.artifact.dto.ArtifactDto>);
    private java.lang.String buildCoordinatePath(com.seeyon.devops.starter.artifact.dto.ArtifactDto);
    private java.lang.String getMvnBasePath();
    java.util.List<java.lang.String> resolveDependencyJar(java.lang.String, java.io.File);
    java.util.List<java.lang.String> resolveDependencyJar(java.lang.String, java.io.File, java.util.function.Predicate<org.apache.maven.model.Dependency>);
    private java.util.List<java.lang.String> asyncDownloadAllFromFerryboat(java.lang.String, java.lang.String, java.util.List<java.lang.String>, java.lang.String);
```

### `FrontendService`（25 方法）

`com.seeyon.devops.starter.artifact.FrontendService`

```java
    void uploadFrontendResource();
    boolean uploadFrontendResource(com.seeyon.devops.starter.artifact.dto.ArtifactDto, boolean);
    private void unZipToStaticDir(java.lang.String, java.lang.String, java.lang.String);
    java.io.File uploadFrontendInternal(java.lang.String, java.lang.String, java.lang.String);
    private void uploadFile(java.io.File, java.lang.String)
    void uploadAssetsRecord(java.lang.String, java.lang.String, java.lang.String);
    void sandNotice(java.lang.String, java.lang.String);
    java.lang.String readFileMd5(java.lang.String);
    java.lang.String writeFileMd5(java.lang.String, java.lang.String);
    boolean downloadFrontApp2Local(java.lang.String, java.lang.String)
    boolean removeFrontAppFromLocal(java.lang.String);
```

### `ArtifactSyncService`（23 方法）

`com.seeyon.devops.starter.artifact.sync.ArtifactSyncService`

```java
    static private static java.lang.String getRelativePath(java.lang.String, java.lang.String);
    void onApplicationEvent(org.springframework.context.event.ContextRefreshedEvent);
    java.lang.String readFileMd5(java.lang.String, java.lang.String);
    java.lang.String readFileContent(java.lang.String, java.lang.String);
    boolean uploadHostAppLibJar();
    boolean compareMd5AndUpload(java.lang.String, java.lang.String, java.lang.String);
    java.io.File downloadFile2Local(java.lang.String, java.lang.String);
    java.lang.String detectHostAppNameJar(java.lang.String);
    private void processMetadata(java.lang.String, java.lang.String)
    boolean checkMd5AndSyncFile(java.lang.String, java.lang.String, java.lang.String);
    private void excludeJar(com.seeyon.devops.starter.artifact.dto.HostJarMetadataDto);
    java.lang.String getLibBasePath(java.lang.String);
    private java.util.List<java.lang.String> getAllJarFilePath();
    boolean isFatjar();
    void syncFacadeToMaven(java.util.List<java.lang.String>);
    void onApplicationEvent(org.springframework.context.ApplicationEvent);
```

### `NpmManager`（22 方法）

`com.seeyon.devops.starter.artifact.npm.NpmManager`

```java
    com.seeyon.devops.starter.artifact.enums.StorageTypeEnum getNpmType();
    com.seeyon.devops.starter.artifact.npm.NpmService getNpmService();
    com.seeyon.devops.starter.artifact.npm.NpmService getNpmService(com.seeyon.devops.starter.artifact.enums.StorageTypeEnum);
    java.io.InputStream getInputStream(java.lang.String);
    java.util.List<com.seeyon.devops.starter.artifact.npm.dto.BizPackageDto> getBizPackages();
    java.util.List<com.seeyon.devops.starter.artifact.npm.dto.PackageInfoDto> parsePackage(com.seeyon.devops.starter.artifact.npm.dto.FrontPackageDto);
    boolean matchData(com.seeyon.devops.starter.artifact.npm.dto.PackageInfoDto);
    boolean exist(java.lang.String);
    boolean publishIfAbsent(java.lang.String, java.lang.String, java.lang.String);
    java.lang.String npmFileUpload(java.io.InputStream, java.lang.String);
    java.lang.String downloadTarFile(java.lang.String);
    java.lang.String downloadTarFileByHostApp(java.lang.String, java.lang.String);
    java.util.List<java.lang.String> uncompress(java.io.File, java.lang.String);
    java.lang.String uploadMFAssetsFile(java.util.List<java.lang.String>);
    java.lang.String uploadMFAssetsFile(com.seeyon.devops.starter.artifact.npm.dto.PackageInfoDto, java.util.List<java.lang.String>);
    private java.lang.String getRemoteFileName(com.seeyon.devops.starter.artifact.npm.dto.PackageInfoDto, java.lang.String);
    void afterPropertiesSet()
```

### `FileManager`（21 方法）

`com.seeyon.devops.starter.artifact.FileManager`

```java
    static java.lang.String getBaseRootPath();
    static void setBaseRootPath(java.lang.String);
    static java.lang.String getAutoCodePath();
    static java.lang.String getAssetsPath();
    static java.lang.String getAssetsPathByApp(java.lang.String);
    static java.lang.String getAssetsUrlByApp(java.lang.String);
    static java.lang.String getFrontendDependencyPath();
    static java.lang.String getSharedDepsPath();
    static java.lang.String getFrontCodeEngineCliPath();
    static java.lang.String getFrontPipelineCliPath();
    static java.lang.String getMavenDependencyPath();
    static java.lang.String getMavenHomePath();
    static java.lang.String getNodeHomePath();
    static java.lang.String getNpmCliPath();
    static java.lang.String getNpmNpmrcPath();
    static java.lang.String getExecutableNode();
    static java.lang.String getYarnPath();
    static java.lang.String getWebLibPath();
    static java.lang.String getFrontendDependencyStaticPath();
    static java.lang.String getStaticPath();
    static org.apache.maven.model.Repository getDefaultRepository();
```

### `CommonService`（19 方法）

`com.seeyon.devops.starter.artifact.common.CommonService`

```java
    com.seeyon.devops.starter.artifact.enums.MavenTypeEnum getMavenType();
    boolean upload(com.seeyon.devops.starter.artifact.dto.ArtifactDto);
    java.lang.String download(com.seeyon.devops.starter.artifact.dto.ArtifactDto);
    java.lang.String download(com.seeyon.devops.starter.artifact.dto.ArtifactDto, java.util.function.Supplier<java.lang.Exception>);
    boolean delete(com.seeyon.devops.starter.artifact.dto.ArtifactDto);
    java.util.List<java.lang.String> downloadModuleJars(java.lang.String, java.lang.String, java.util.List<java.lang.String>, java.lang.String);
    java.lang.String getLatestVersion(java.lang.String, java.lang.String, java.lang.String);
    java.util.List<java.lang.String> resolveVersionRange(com.seeyon.devops.starter.artifact.dto.VersionRangeArtifactDto);
    void afterPropertiesSet()
    private org.eclipse.aether.RepositorySystem getRepositorySystem();
    private org.eclipse.aether.RepositorySystemSession getSession(org.eclipse.aether.RepositorySystem, java.lang.String);
    private org.eclipse.aether.repository.RemoteRepository getRemoteRepository(java.lang.String);
    private org.eclipse.aether.repository.RemoteRepository getRemoteRepository(java.lang.String, java.util.function.Supplier<org.eclipse.aether.repository.RepositoryPolicy>);
    private java.util.List<org.eclipse.aether.repository.RemoteRepository> getAllRemoteRepository();
    private java.util.List<org.eclipse.aether.repository.RemoteRepository> getAllRemoteRepository(java.util.function.Supplier<org.eclipse.aether.repository.RepositoryPolicy>);
```

### `ArtifactManager`（18 方法）

`com.seeyon.devops.starter.artifact.ArtifactManager`

```java
    static com.seeyon.devops.starter.artifact.manager.AbstractArtifactManager getArtifactManager(com.seeyon.devops.common.enums.AppTypeEnum);
    boolean isFerryboatMavenMode();
    com.seeyon.devops.starter.artifact.ArtifactMavenProperties getMavenProperties();
    java.lang.String getMvnBasePath();
    boolean exist(com.seeyon.devops.starter.artifact.dto.ArtifactDto);
    java.lang.String getLatestVersion(com.seeyon.devops.starter.artifact.dto.ArtifactDto);
    java.util.List<java.lang.String> resolveVersionRange(com.seeyon.devops.starter.artifact.dto.VersionRangeArtifactDto);
    boolean upload(com.seeyon.devops.starter.artifact.dto.ArtifactDto);
    java.lang.String download(com.seeyon.devops.starter.artifact.dto.ArtifactDto);
    java.lang.String download(com.seeyon.devops.starter.artifact.dto.ArtifactDto, java.util.function.Supplier<java.lang.Exception>);
    org.apache.commons.lang3.tuple.ImmutablePair<java.lang.Boolean, java.util.List<java.lang.String>> operationMavenCmd(java.lang.String, java.lang.String);
    private java.io.File getUserSettingsFile();
    boolean uploadFrontendResource(com.seeyon.devops.starter.artifact.dto.ArtifactDto);
    void afterPropertiesSet()
    com.seeyon.devops.starter.artifact.ArtifactService getArtifactService();
```

### `NormalArtifactManager`（15 方法）

`com.seeyon.devops.starter.artifact.manager.NormalArtifactManager`

```java
    com.seeyon.devops.common.enums.AppTypeEnum getAppType();
    java.util.List<java.lang.String> getModuleList();
    boolean exist(com.seeyon.devops.starter.artifact.dto.ArtifactDto);
    java.lang.String download(com.seeyon.devops.starter.artifact.dto.ArtifactDto);
    boolean upload(com.seeyon.devops.starter.artifact.dto.ArtifactDto)
    boolean delete(com.seeyon.devops.starter.artifact.dto.ArtifactDto);
    java.lang.String downloadForFerryboat(com.seeyon.devops.starter.artifact.dto.ArtifactDto);
    boolean uploadForFerryboat(com.seeyon.devops.starter.artifact.dto.ArtifactDto);
    java.util.List<java.lang.String> downloadLocalAppModuleJars(java.lang.String, java.lang.String, java.lang.String);
    java.util.List<java.lang.String> downloadRemoteAppModuleJars(java.lang.String, java.lang.String, java.lang.String);
    boolean bucketExchangeFerryboat(com.seeyon.devops.starter.artifact.dto.ArtifactDto);
    boolean batchBucketExchangeFerryboat(java.util.List<com.seeyon.devops.starter.artifact.dto.ArtifactDto>);
    boolean ferryboatExchangeBucket(com.seeyon.devops.starter.artifact.dto.ArtifactDto);
    boolean batchFerryboatExchangeBucket(java.util.List<com.seeyon.devops.starter.artifact.dto.ArtifactDto>);
```

### `BucketMavenService`（14 方法）

`com.seeyon.devops.starter.artifact.bucket.BucketMavenService`

```java
    com.seeyon.devops.starter.artifact.enums.MavenTypeEnum getMavenType();
    java.lang.String defaultMavenCmd();
    boolean upload(com.seeyon.devops.starter.artifact.dto.ArtifactDto);
    java.lang.String download(com.seeyon.devops.starter.artifact.dto.ArtifactDto);
    java.lang.String download(com.seeyon.devops.starter.artifact.dto.ArtifactDto, java.util.function.Supplier<java.lang.Exception>);
    boolean delete(com.seeyon.devops.starter.artifact.dto.ArtifactDto);
    java.util.List<java.lang.String> downloadModuleJars(java.lang.String, java.lang.String, java.util.List<java.lang.String>, java.lang.String);
    boolean exist(com.seeyon.devops.starter.artifact.dto.ArtifactDto);
    private java.lang.String buildCoordinatePath(com.seeyon.devops.starter.artifact.dto.ArtifactDto);
    java.lang.String getLatestVersion(java.lang.String, java.lang.String, java.lang.String);
    java.util.List<java.lang.String> resolveVersionRange(com.seeyon.devops.starter.artifact.dto.VersionRangeArtifactDto);
    void afterPropertiesSet()
    private java.util.TreeSet<java.lang.String> findVersionRange(com.seeyon.devops.starter.artifact.dto.ArtifactDto);
```

### `VersionUtils`（14 方法）

`com.seeyon.devops.starter.artifact.util.VersionUtils`

```java
    static boolean startWithNumber(java.lang.String);
    static boolean isDynamicApp(java.lang.String);
    static int compareVersion(java.lang.String, java.lang.String);
    static java.lang.String getBaseVersion(java.lang.String, boolean);
    static java.lang.String getBaseVersion(java.lang.String);
    static java.lang.String convertCopVersion(java.lang.String);
    static java.lang.String getMajorVersion(java.lang.String, boolean);
    static java.lang.String getMajorVersion(java.lang.String);
    static java.lang.String getFrontMajorVersion(java.lang.String);
    static java.util.List<java.lang.String> filterVersion(java.util.List<java.lang.String>);
    static java.util.List<java.lang.String> filterVersion(java.util.List<java.lang.String>, java.util.function.Predicate<java.lang.String>);
    static java.lang.String getPluginVersion();
```

### `ArtifactoryService`（11 方法）

`com.seeyon.devops.starter.artifact.artifactory.ArtifactoryService`

```java
    com.seeyon.devops.starter.artifact.enums.MavenTypeEnum getMavenType();
    boolean upload(com.seeyon.devops.starter.artifact.dto.ArtifactDto);
    private java.lang.String getRepoName(com.seeyon.devops.starter.artifact.dto.ArtifactDto);
    java.lang.String download(com.seeyon.devops.starter.artifact.dto.ArtifactDto);
    java.lang.String download(com.seeyon.devops.starter.artifact.dto.ArtifactDto, java.util.function.Supplier<java.lang.Exception>);
    boolean delete(com.seeyon.devops.starter.artifact.dto.ArtifactDto);
    java.util.List<java.lang.String> downloadModuleJars(java.lang.String, java.lang.String, java.util.List<java.lang.String>, java.lang.String);
    java.lang.String getLatestVersion(java.lang.String, java.lang.String, java.lang.String);
    java.util.List<java.lang.String> resolveVersionRange(com.seeyon.devops.starter.artifact.dto.VersionRangeArtifactDto);
    void afterPropertiesSet()
```

### `DefaultNpmService`（11 方法）

`com.seeyon.devops.starter.artifact.npm.npm.DefaultNpmService`

```java
    com.seeyon.devops.starter.artifact.enums.StorageTypeEnum getNpmType();
    java.io.InputStream getInputStream(java.lang.String);
    java.lang.String downloadTarFileByHostApp(java.lang.String, java.lang.String);
    java.util.List<com.seeyon.devops.starter.artifact.npm.dto.PackageInfoDto> parsePackage(com.seeyon.devops.starter.artifact.npm.dto.FrontPackageDto);
    java.util.List<com.seeyon.devops.starter.artifact.npm.dto.PackageInfoDto> parsePackage(java.lang.String);
    java.util.Map<java.lang.String, java.lang.String> getDistTagsMap(com.fasterxml.jackson.databind.JsonNode);
    java.util.List<com.seeyon.devops.starter.artifact.npm.dto.VersionDto> resolveFilterVersion(java.util.Map<java.lang.String, java.lang.String>, com.fasterxml.jackson.databind.JsonNode);
```

### `CmdService`（10 方法）

`com.seeyon.devops.starter.artifact.cmd.CmdService`

```java
    com.seeyon.devops.starter.artifact.enums.MavenTypeEnum getMavenType();
    boolean upload(com.seeyon.devops.starter.artifact.dto.ArtifactDto);
    java.lang.String download(com.seeyon.devops.starter.artifact.dto.ArtifactDto);
    java.lang.String download(com.seeyon.devops.starter.artifact.dto.ArtifactDto, java.util.function.Supplier<java.lang.Exception>);
    boolean delete(com.seeyon.devops.starter.artifact.dto.ArtifactDto);
    java.util.List<java.lang.String> downloadModuleJars(java.lang.String, java.lang.String, java.util.List<java.lang.String>, java.lang.String);
    java.lang.String getLatestVersion(java.lang.String, java.lang.String, java.lang.String);
    java.util.List<java.lang.String> resolveVersionRange(com.seeyon.devops.starter.artifact.dto.VersionRangeArtifactDto);
    private java.lang.String[] buildExecParam(java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String);
    private java.lang.String[] buildExecParam(java.lang.String, java.lang.String);
```

### `LocalService`（10 方法）

`com.seeyon.devops.starter.artifact.local.LocalService`

```java
    com.seeyon.devops.starter.artifact.enums.MavenTypeEnum getMavenType();
    java.lang.String defaultMavenCmd();
    boolean upload(com.seeyon.devops.starter.artifact.dto.ArtifactDto);
    java.lang.String download(com.seeyon.devops.starter.artifact.dto.ArtifactDto);
    java.lang.String download(com.seeyon.devops.starter.artifact.dto.ArtifactDto, java.util.function.Supplier<java.lang.Exception>);
    boolean delete(com.seeyon.devops.starter.artifact.dto.ArtifactDto);
    java.util.List<java.lang.String> downloadModuleJars(java.lang.String, java.lang.String, java.util.List<java.lang.String>, java.lang.String);
    java.lang.String getLatestVersion(java.lang.String, java.lang.String, java.lang.String);
    java.util.List<java.lang.String> resolveVersionRange(com.seeyon.devops.starter.artifact.dto.VersionRangeArtifactDto);
    boolean offlineMode();
```

### `NexusService`（8 方法）

`com.seeyon.devops.starter.artifact.nexus.NexusService`

```java
    com.seeyon.devops.starter.artifact.enums.MavenTypeEnum getMavenType();
    boolean upload(com.seeyon.devops.starter.artifact.dto.ArtifactDto);
    java.lang.String download(com.seeyon.devops.starter.artifact.dto.ArtifactDto);
    java.lang.String download(com.seeyon.devops.starter.artifact.dto.ArtifactDto, java.util.function.Supplier<java.lang.Exception>);
    boolean delete(com.seeyon.devops.starter.artifact.dto.ArtifactDto);
    java.util.List<java.lang.String> downloadModuleJars(java.lang.String, java.lang.String, java.util.List<java.lang.String>, java.lang.String);
    java.lang.String getLatestVersion(java.lang.String, java.lang.String, java.lang.String);
    java.util.List<java.lang.String> resolveVersionRange(com.seeyon.devops.starter.artifact.dto.VersionRangeArtifactDto);
```

### `ArtifactMavenUtil`（6 方法）

`com.seeyon.devops.starter.artifact.util.ArtifactMavenUtil`

```java
    static void deployToRepo(java.lang.String, java.lang.String, com.seeyon.devops.starter.artifact.dto.ArtifactDto)
    static java.lang.String downloadFromRepo(java.lang.String, java.lang.String, com.seeyon.devops.starter.artifact.dto.ArtifactDto)
    static com.seeyon.devops.common.resolver.ResolverResult resolveDependencies(java.lang.String, java.lang.String, com.seeyon.devops.starter.artifact.dto.ArtifactDto)
    static void copyBackup2WebStatic(java.lang.String);
    static boolean equalsMd5(java.io.File, java.io.File);
    static java.lang.String buildCoordinatePath(com.seeyon.devops.starter.artifact.dto.ArtifactDto);
```

### `NpmCliUtil`（5 方法）

`com.seeyon.devops.starter.artifact.npm.util.NpmCliUtil`

```java
    static boolean checkNpmEnv();
    static boolean init();
    static boolean ping();
    static java.util.List<java.lang.String> viewVersions(java.lang.String);
    static boolean publish(java.lang.String);
```

### `NfsNpmService`（4 方法）

`com.seeyon.devops.starter.artifact.npm.nfs.NfsNpmService`

```java
    com.seeyon.devops.starter.artifact.enums.StorageTypeEnum getNpmType();
    java.io.InputStream getInputStream(java.lang.String);
    java.util.List<com.seeyon.devops.starter.artifact.npm.dto.PackageInfoDto> parsePackage(com.seeyon.devops.starter.artifact.npm.dto.FrontPackageDto);
    java.lang.String downloadTarFileByHostApp(java.lang.String, java.lang.String);
```

### `Oss2NpmService`（4 方法）

`com.seeyon.devops.starter.artifact.npm.oss.Oss2NpmService`

```java
    com.seeyon.devops.starter.artifact.enums.StorageTypeEnum getNpmType();
    java.util.List<java.lang.String> getScanJsonList();
    java.util.List<com.seeyon.devops.starter.artifact.npm.dto.PackageInfoDto> parsePackage(com.seeyon.devops.starter.artifact.npm.dto.FrontPackageDto);
```

### `OssNpmService`（4 方法）

`com.seeyon.devops.starter.artifact.npm.oss.OssNpmService`

```java
    com.seeyon.devops.starter.artifact.enums.StorageTypeEnum getNpmType();
    java.io.InputStream getInputStream(java.lang.String);
    java.util.List<com.seeyon.devops.starter.artifact.npm.dto.PackageInfoDto> parsePackage(com.seeyon.devops.starter.artifact.npm.dto.FrontPackageDto);
    java.lang.String downloadTarFileByHostApp(java.lang.String, java.lang.String);
```

## 四、枚举（3）

- `MavenTypeEnum`（6 常量）：common, local, cmd, bucket, nexus, artifactory
- `ProfileEnum`（3 常量）：alpha, beta, latest
- `StorageTypeEnum`（4 常量）：nfs, oss, oss2, npm
