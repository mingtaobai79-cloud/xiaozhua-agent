# boot-starter-web：接口与方法签名

> 自动生成，勿手改。`tools/core/platform/emit_package_surfaces.py` 重跑即可。
> 构件 `com.seeyon:boot-starter-web`（jar `boot-starter-web-5.3.600.jar`）
> 规模：65 类 / 5 接口 / 2 注解 / 3 枚举 / 11 个关键类 / 628 方法。
> 签名逐字来自 javap 原文；已去掉 `public` 前缀与 `throws` 子句。

## 一、接口（5）

### `CsrfToken`（3 方法）

`com.seeyon.boot.starter.web.csrf.CsrfToken`

```java
    java.lang.String getHeaderName();
    java.lang.String getParameterName();
    java.lang.String getToken();
```

### `CsrfTokenRepository`（3 方法）

`com.seeyon.boot.starter.web.csrf.CsrfTokenRepository`

```java
    com.seeyon.boot.starter.web.csrf.CsrfToken generateToken(javax.servlet.http.HttpServletRequest);
    void saveToken(com.seeyon.boot.starter.web.csrf.CsrfToken, javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse);
    com.seeyon.boot.starter.web.csrf.CsrfToken loadToken(javax.servlet.http.HttpServletRequest);
```

### `CtpUpgrade`（1 方法）

`com.seeyon.boot.starter.upgrade.api.CtpUpgrade`

```java
    com.seeyon.boot.starter.upgrade.dto.UpgradeResult upgrade();
```

### `RequestMatcher`（1 方法）

`com.seeyon.boot.starter.web.csrf.RequestMatcher`

```java
    boolean matches(javax.servlet.http.HttpServletRequest);
```

### `AccessAuditLgDao`（0 方法） extends AccessAuditLg>

`com.seeyon.boot.starter.web.domain.dao.AccessAuditLgDao`

```java
```

## 二、关键类（11）

### `RequestMappingHandlerAdapter`（59 方法）

`org.springframework.web.servlet.mvc.method.annotation.RequestMappingHandlerAdapter`

```java
    org.springframework.web.method.support.HandlerMethodArgumentResolverComposite getOriginArgumentResolvers();
    org.springframework.web.method.support.HandlerMethodReturnValueHandlerComposite getOriginReturnValueHandlers();
    org.springframework.core.ParameterNameDiscoverer getOriginParameterNameDiscoverer();
    void setCustomArgumentResolvers(java.util.List<org.springframework.web.method.support.HandlerMethodArgumentResolver>);
    java.util.List<org.springframework.web.method.support.HandlerMethodArgumentResolver> getCustomArgumentResolvers();
    void setArgumentResolvers(java.util.List<org.springframework.web.method.support.HandlerMethodArgumentResolver>);
    java.util.List<org.springframework.web.method.support.HandlerMethodArgumentResolver> getArgumentResolvers();
    void setInitBinderArgumentResolvers(java.util.List<org.springframework.web.method.support.HandlerMethodArgumentResolver>);
    java.util.List<org.springframework.web.method.support.HandlerMethodArgumentResolver> getInitBinderArgumentResolvers();
    void setCustomReturnValueHandlers(java.util.List<org.springframework.web.method.support.HandlerMethodReturnValueHandler>);
    java.util.List<org.springframework.web.method.support.HandlerMethodReturnValueHandler> getCustomReturnValueHandlers();
    void setReturnValueHandlers(java.util.List<org.springframework.web.method.support.HandlerMethodReturnValueHandler>);
    java.util.List<org.springframework.web.method.support.HandlerMethodReturnValueHandler> getReturnValueHandlers();
    void setModelAndViewResolvers(java.util.List<org.springframework.web.servlet.mvc.annotation.ModelAndViewResolver>);
    java.util.List<org.springframework.web.servlet.mvc.annotation.ModelAndViewResolver> getModelAndViewResolvers();
    void setContentNegotiationManager(org.springframework.web.accept.ContentNegotiationManager);
    void setMessageConverters(java.util.List<org.springframework.http.converter.HttpMessageConverter<?>>);
    java.util.List<org.springframework.http.converter.HttpMessageConverter<?>> getMessageConverters();
    void setRequestBodyAdvice(java.util.List<org.springframework.web.servlet.mvc.method.annotation.RequestBodyAdvice>);
    void setResponseBodyAdvice(java.util.List<org.springframework.web.servlet.mvc.method.annotation.ResponseBodyAdvice<?>>);
    void setWebBindingInitializer(org.springframework.web.bind.support.WebBindingInitializer);
    org.springframework.web.bind.support.WebBindingInitializer getWebBindingInitializer();
    void setTaskExecutor(org.springframework.core.task.AsyncTaskExecutor);
    void setAsyncRequestTimeout(long);
    void setCallableInterceptors(java.util.List<org.springframework.web.context.request.async.CallableProcessingInterceptor>);
    void setDeferredResultInterceptors(java.util.List<org.springframework.web.context.request.async.DeferredResultProcessingInterceptor>);
    void setReactiveAdapterRegistry(org.springframework.core.ReactiveAdapterRegistry);
    org.springframework.core.ReactiveAdapterRegistry getReactiveAdapterRegistry();
    void setIgnoreDefaultModelOnRedirect(boolean);
    void setSessionAttributeStore(org.springframework.web.bind.support.SessionAttributeStore);
    void setCacheSecondsForSessionAttributeHandlers(int);
    void setSynchronizeOnSession(boolean);
    void setParameterNameDiscoverer(org.springframework.core.ParameterNameDiscoverer);
    void setBeanFactory(org.springframework.beans.factory.BeanFactory);
    protected org.springframework.beans.factory.config.ConfigurableBeanFactory getBeanFactory();
    void afterPropertiesSet();
    private void initControllerAdviceCache();
    private int getBodyAdviceCount(java.lang.Class<?>);
    private java.util.List<org.springframework.web.method.support.HandlerMethodArgumentResolver> getDefaultArgumentResolvers();
    private java.util.List<org.springframework.web.method.support.HandlerMethodArgumentResolver> getDefaultInitBinderArgumentResolvers();
    private java.util.List<org.springframework.web.method.support.HandlerMethodReturnValueHandler> getDefaultReturnValueHandlers();
    protected boolean supportsInternal(org.springframework.web.method.HandlerMethod);
    protected org.springframework.web.servlet.ModelAndView handleInternal(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse, org.springframework.web.method.HandlerMethod)
    protected long getLastModifiedInternal(javax.servlet.http.HttpServletRequest, org.springframework.web.method.HandlerMethod);
    private org.springframework.web.method.annotation.SessionAttributesHandler getSessionAttributesHandler(org.springframework.web.method.HandlerMethod);
    protected org.springframework.web.servlet.ModelAndView invokeHandlerMethod(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse, org.springframework.web.method.HandlerMethod)
    protected org.springframework.web.servlet.mvc.method.annotation.ServletInvocableHandlerMethod createInvocableHandlerMethod(org.springframework.web.method.HandlerMethod);
    private org.springframework.web.method.annotation.ModelFactory getModelFactory(org.springframework.web.method.HandlerMethod, org.springframework.web.bind.support.WebDataBinderFactory);
    private org.springframework.web.method.support.InvocableHandlerMethod createModelAttributeMethod(org.springframework.web.bind.support.WebDataBinderFactory, java.lang.Object, java.lang.reflect.Method);
    org.springframework.web.bind.support.WebDataBinderFactory getDataBinderFactory(org.springframework.web.method.HandlerMethod)
    private org.springframework.web.method.support.InvocableHandlerMethod createInitBinderMethod(java.lang.Object, java.lang.reflect.Method);
    protected org.springframework.web.method.annotation.InitBinderDataBinderFactory createDataBinderFactory(java.util.List<org.springframework.web.method.support.InvocableHandlerMethod>)
    private org.springframework.web.servlet.ModelAndView getModelAndView(org.springframework.web.method.support.ModelAndViewContainer, org.springframework.web.method.annotation.ModelFactory, org.springframework.web.context.request.NativeWebRequest)
```

### `AbstractHandlerMethodMapping`（39 方法）

`org.springframework.web.servlet.handler.AbstractHandlerMethodMapping`

```java
    void setPatternParser(org.springframework.web.util.pattern.PathPatternParser);
    void setDetectHandlerMethodsInAncestorContexts(boolean);
    void setHandlerMethodMappingNamingStrategy(org.springframework.web.servlet.handler.HandlerMethodMappingNamingStrategy<T>);
    org.springframework.web.servlet.handler.HandlerMethodMappingNamingStrategy<T> getNamingStrategy();
    java.util.Map<T, org.springframework.web.method.HandlerMethod> getHandlerMethods();
    java.util.List<org.springframework.web.method.HandlerMethod> getHandlerMethodsForMappingName(java.lang.String);
    org.springframework.web.servlet.handler.AbstractHandlerMethodMapping<T>.MappingRegistry getMappingRegistry();
    void registerMapping(T, java.lang.Object, java.lang.reflect.Method);
    void unregisterMapping(T);
    void afterPropertiesSet();
    protected void initHandlerMethods();
    protected java.lang.String[] getCandidateBeanNames();
    protected void processCandidateBean(java.lang.String);
    protected void detectHandlerMethods(java.lang.Object);
    private java.lang.String formatMappings(java.lang.Class<?>, java.util.Map<java.lang.reflect.Method, T>);
    protected void registerHandlerMethod(java.lang.Object, java.lang.reflect.Method, T);
    protected org.springframework.web.method.HandlerMethod createHandlerMethod(java.lang.Object, java.lang.reflect.Method);
    protected org.springframework.web.cors.CorsConfiguration initCorsConfiguration(java.lang.Object, java.lang.reflect.Method, T);
    protected void handlerMethodsInitialized(java.util.Map<T, org.springframework.web.method.HandlerMethod>);
    protected org.springframework.web.method.HandlerMethod getHandlerInternal(javax.servlet.http.HttpServletRequest)
    protected org.springframework.web.method.HandlerMethod lookupHandlerMethod(java.lang.String, javax.servlet.http.HttpServletRequest)
    private void addMatchingMappings(java.util.Collection<T>, java.util.List<org.springframework.web.servlet.handler.AbstractHandlerMethodMapping<T>.Match>, javax.servlet.http.HttpServletRequest);
    protected void handleMatch(T, java.lang.String, javax.servlet.http.HttpServletRequest);
    protected org.springframework.web.method.HandlerMethod handleNoMatch(java.util.Set<T>, java.lang.String, javax.servlet.http.HttpServletRequest)
    protected boolean hasCorsConfigurationSource(java.lang.Object);
    protected org.springframework.web.cors.CorsConfiguration getCorsConfiguration(java.lang.Object, javax.servlet.http.HttpServletRequest);
    protected abstract boolean isHandler(java.lang.Class<?>);
    protected abstract T getMappingForMethod(java.lang.reflect.Method, java.lang.Class<?>);
    protected java.util.Set<java.lang.String> getMappingPathPatterns(T);
    protected java.util.Set<java.lang.String> getDirectPaths(T);
    protected abstract T getMatchingMapping(T, javax.servlet.http.HttpServletRequest);
    protected abstract java.util.Comparator<T> getMappingComparator(javax.servlet.http.HttpServletRequest);
    protected java.lang.Object getHandlerInternal(javax.servlet.http.HttpServletRequest)
```

### `RequestMappingHandlerMapping`（35 方法）

`org.springframework.web.servlet.mvc.method.annotation.RequestMappingHandlerMapping`

```java
    void setUseSuffixPatternMatch(boolean);
    void setUseRegisteredSuffixPatternMatch(boolean);
    void setUseTrailingSlashMatch(boolean);
    void setPathPrefixes(java.util.Map<java.lang.String, java.util.function.Predicate<java.lang.Class<?>>>);
    java.util.Map<java.lang.String, java.util.function.Predicate<java.lang.Class<?>>> getPathPrefixes();
    void setContentNegotiationManager(org.springframework.web.accept.ContentNegotiationManager);
    org.springframework.web.accept.ContentNegotiationManager getContentNegotiationManager();
    void setEmbeddedValueResolver(org.springframework.util.StringValueResolver);
    void afterPropertiesSet();
    boolean useSuffixPatternMatch();
    boolean useRegisteredSuffixPatternMatch();
    boolean useTrailingSlashMatch();
    java.util.List<java.lang.String> getFileExtensions();
    org.springframework.web.servlet.mvc.method.RequestMappingInfo$BuilderConfiguration getBuilderConfiguration();
    protected boolean isHandler(java.lang.Class<?>);
    protected org.springframework.web.servlet.mvc.method.RequestMappingInfo getMappingForMethod(java.lang.reflect.Method, java.lang.Class<?>);
    java.lang.String getPathPrefix(java.lang.Class<?>);
    private org.springframework.web.servlet.mvc.method.RequestMappingInfo createRequestMappingInfo(java.lang.reflect.AnnotatedElement);
    protected org.springframework.web.servlet.mvc.condition.RequestCondition<?> getCustomTypeCondition(java.lang.Class<?>);
    protected org.springframework.web.servlet.mvc.condition.RequestCondition<?> getCustomMethodCondition(java.lang.reflect.Method);
    protected org.springframework.web.servlet.mvc.method.RequestMappingInfo createRequestMappingInfo(org.springframework.web.bind.annotation.RequestMapping, org.springframework.web.servlet.mvc.condition.RequestCondition<?>);
    protected java.lang.String[] resolveEmbeddedValuesInPatterns(java.lang.String[]);
    void registerMapping(org.springframework.web.servlet.mvc.method.RequestMappingInfo, java.lang.Object, java.lang.reflect.Method);
    protected void registerHandlerMethod(java.lang.Object, java.lang.reflect.Method, org.springframework.web.servlet.mvc.method.RequestMappingInfo);
    private void updateConsumesCondition(org.springframework.web.servlet.mvc.method.RequestMappingInfo, java.lang.reflect.Method);
    org.springframework.web.servlet.handler.RequestMatchResult match(javax.servlet.http.HttpServletRequest, java.lang.String);
    protected org.springframework.web.cors.CorsConfiguration initCorsConfiguration(java.lang.Object, java.lang.reflect.Method, org.springframework.web.servlet.mvc.method.RequestMappingInfo);
    private void updateCorsConfig(org.springframework.web.cors.CorsConfiguration, org.springframework.web.bind.annotation.CrossOrigin);
    private java.lang.String resolveCorsAnnotationValue(java.lang.String);
    org.springframework.web.method.HandlerMethod getHandlerMethod(javax.servlet.http.HttpServletRequest)
    org.springframework.web.servlet.HandlerInterceptor[] getInterceptors();
    protected java.lang.Object getMappingForMethod(java.lang.reflect.Method, java.lang.Class);
    protected org.springframework.web.cors.CorsConfiguration initCorsConfiguration(java.lang.Object, java.lang.reflect.Method, java.lang.Object);
    protected void registerHandlerMethod(java.lang.Object, java.lang.reflect.Method, java.lang.Object);
    void registerMapping(java.lang.Object, java.lang.Object, java.lang.reflect.Method);
```

### `UpgradeServiceDto`（14 方法）

`com.seeyon.boot.starter.upgrade.dto.UpgradeServiceDto`

```java
    java.lang.String getServiceName();
    java.lang.String getAppName();
    java.lang.Integer getOrder();
    boolean isSync();
    java.lang.String getUpgradeVersion();
    java.lang.String getFromVersion();
    java.lang.String getToVersion();
    void setServiceName(java.lang.String);
    void setAppName(java.lang.String);
    void setOrder(java.lang.Integer);
    void setSync(boolean);
    void setUpgradeVersion(java.lang.String);
    void setFromVersion(java.lang.String);
    void setToVersion(java.lang.String);
```

### `WebAutoConfiguration`（8 方法）

`com.seeyon.boot.starter.web.WebAutoConfiguration`

```java
    void configureMessageConverters(java.util.List<org.springframework.http.converter.HttpMessageConverter<?>>);
    void configurePathMatch(org.springframework.web.servlet.config.annotation.PathMatchConfigurer);
    void addArgumentResolvers(java.util.List<org.springframework.web.method.support.HandlerMethodArgumentResolver>);
    void addResourceHandlers(org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry);
    com.seeyon.boot.starter.web.filter.HttpsOnlyFilter httpsOnlyFilter();
    org.springframework.boot.web.servlet.ServletRegistrationBean statViewServlet();
    org.springframework.boot.web.servlet.FilterRegistrationBean webStatFilter();
```

### `WebExceptionHandler`（8 方法）

`com.seeyon.boot.starter.web.WebExceptionHandler`

```java
    private java.lang.String findErrorField(java.util.List<com.fasterxml.jackson.databind.JsonMappingException$Reference>);
    com.seeyon.boot.transport.BaseResponse uploadException(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse, org.springframework.web.multipart.MaxUploadSizeExceededException);
    com.seeyon.boot.transport.BaseResponse handleException(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse, org.springframework.web.method.HandlerMethod, java.lang.Exception);
    com.seeyon.boot.transport.BaseResponse handleException(java.lang.Exception, java.lang.String);
    com.seeyon.boot.transport.BaseResponse handleJsonMappingException(java.lang.Exception);
    private boolean isJsonRequest(javax.servlet.http.HttpServletRequest, java.lang.reflect.Method);
    void initialize();
    void onApplicationEvent(org.springframework.context.ApplicationEvent);
```

### `UpgradeProxyService`（4 方法）

`com.seeyon.boot.starter.upgrade.proxy.UpgradeProxyService`

```java
    com.seeyon.boot.transport.SingleResponse<com.seeyon.boot.starter.upgrade.dto.UpgradeResult> invokeSync(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.upgrade.dto.UpgradeServiceDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Boolean> invoke(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.upgrade.dto.UpgradeServiceDto>);
    private com.seeyon.boot.starter.upgrade.dto.UpgradeResult process(com.seeyon.boot.starter.upgrade.dto.UpgradeServiceDto);
```

### `ControllerFilterConfiguration`（4 方法）

`com.seeyon.boot.starter.web.ControllerFilterConfiguration`

```java
    void addInterceptors(org.springframework.web.servlet.config.annotation.InterceptorRegistry);
    com.seeyon.boot.starter.web.filter.AppContextFilter appContextFilter();
    private org.springframework.web.servlet.HandlerInterceptor auditLogInterceptor();
    org.springframework.web.servlet.HandlerInterceptor antiReCommitInterceptor();
```

### `AccessAuditLogServiceImpl`（4 方法）

`com.seeyon.boot.starter.web.domain.service.AccessAuditLogServiceImpl`

```java
    void initLogProcessor();
    void create(com.seeyon.boot.log.dto.AccessAuditDto, java.lang.String);
    void create(java.lang.String[], java.lang.String);
```

### `ComponentRequestUtils`（4 方法）

`com.seeyon.boot.starter.web.util.ComponentRequestUtils`

```java
    static private static org.springframework.web.servlet.mvc.method.annotation.RequestMappingHandlerMapping getRequestMappingHandlerMapping();
    static boolean isComponentRequestForMultiAppGraphql(javax.servlet.http.HttpServletRequest);
    static boolean isComponentRequest(javax.servlet.http.HttpServletRequest);
```

### `WebUtils`（4 方法）

`com.seeyon.boot.starter.web.util.WebUtils`

```java
    static boolean checkETag(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse, java.lang.String);
    static void writeETag(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse, java.lang.String);
    static void writeETag(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse, java.lang.String, long);
    static java.lang.String getClientIp(javax.servlet.http.HttpServletRequest);
```

## 三、注解（2）

| 注解 | 元素 |
|---|---|
| `Upgrade` | version |
| `AntiReCommit` | name, validate |

## 四、枚举（3）

- `CtpUpgradeStatus`（6 常量）：NONE, READY, ING, SUCCESS, FAILURE, NO_PROVIDER
- `UpgradeStatus`（2 常量）：SUCCESS, FAILURE
- `FieldType`（3 常量）：DTO, LIST, MAP
