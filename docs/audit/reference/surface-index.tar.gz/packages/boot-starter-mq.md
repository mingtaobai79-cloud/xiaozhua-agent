# boot-starter-mq：接口与方法签名

> 自动生成，勿手改。`tools/core/platform/emit_package_surfaces.py` 重跑即可。
> 构件 `com.seeyon:boot-starter-mq`（jar `boot-starter-mq-5.3.600.jar`）
> 规模：68 类 / 10 接口 / 1 注解 / 2 枚举 / 7 个关键类 / 495 方法。
> 签名逐字来自 javap 原文；已去掉 `public` 前缀与 `throws` 子句。

## 一、接口（10）

### `MessageListener`（14 方法）

`com.seeyon.boot.starter.mq.consumer.listener.MessageListener`

```java
    void onMessage(com.seeyon.boot.starter.mq.support.dto.MessageDto)
    java.lang.String getTopic();
    void setTopic(java.lang.String);
    com.seeyon.boot.starter.mq.consumer.wrapper.MethodWrapper getMethodWrapper();
    java.lang.String getProcessClassName();
    java.lang.String getProcessMethodName();
    java.lang.String getProcessParameterName();
    void setMethodWrapper(com.seeyon.boot.starter.mq.consumer.wrapper.MethodWrapper);
    void clearMethodWrapper();
    boolean isDynamicSubscribe();
    boolean isModuleSubscribe();
    void setModuleName(java.lang.String);
    java.lang.String getlistenerKey();
    java.lang.String generateListenerKey(java.lang.String, java.lang.String, java.lang.String);
```

### `MessageConsumer`（10 方法）

`com.seeyon.boot.starter.mq.consumer.MessageConsumer`

```java
    void start();
    void stop();
    void subscribe(java.lang.String, java.lang.Object, java.lang.reflect.Method);
    void unSubscribe(java.lang.String, java.lang.Object);
    void dynamicSubscribe(java.lang.String, java.lang.Class, java.lang.String);
    void unDynamicSubscribe(java.lang.String, java.lang.Class, java.lang.String);
    void moduleSubscribe(java.util.List<java.util.Map<java.lang.String, java.lang.Object>>, java.lang.String, java.lang.String);
    void moduleSubscribe(java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String);
    void unModuleSubscribe(java.util.List<java.util.Map<java.lang.String, java.lang.Object>>, java.lang.String, java.lang.String);
    java.util.Map getAllMessageListener();
```

### `MessageProducer`（6 方法）

`com.seeyon.boot.starter.mq.producer.MessageProducer`

```java
    boolean isAvailable();
    java.lang.String send(com.seeyon.boot.mq.BaseMessage);
    java.util.List<java.lang.String> send(java.util.List<com.seeyon.boot.mq.BaseMessage>);
    boolean sendDirectOneTime(com.seeyon.boot.mq.BaseMessage);
    java.lang.String sendDirectOneTimeReMsgId(com.seeyon.boot.mq.BaseMessage);
    void clearCache(java.lang.ClassLoader);
```

### `MQMessageSpi`（4 方法）

`com.seeyon.boot.starter.mq.spi.MQMessageSpi`

```java
    default boolean send(com.seeyon.boot.starter.mq.support.dto.MessageDto);
    default boolean sendBatch(java.util.List<com.seeyon.boot.starter.mq.support.dto.MessageDto>);
    default boolean subscribeTopic(java.lang.String);
    default boolean unSubscribeTopic(java.lang.String);
```

### `AdvancedMessageProducer`（3 方法） extends MessageProducer

`com.seeyon.boot.starter.mq.producer.AdvancedMessageProducer`

```java
    boolean send(com.seeyon.boot.starter.mq.support.dto.MessageDto);
    boolean sendBatch(java.util.List<com.seeyon.boot.starter.mq.support.dto.MessageDto>);
    boolean sendDirectOneTime(com.seeyon.boot.starter.mq.support.dto.MessageDto);
```

### `MqConstant`（1 方法）

`com.seeyon.boot.starter.mq.common.MqConstant`

```java
    boolean printLog(java.lang.String);
```

### `DelayTopic`（0 方法）

`com.seeyon.boot.starter.mq.message.DelayTopic`

```java
```

### `BusDynamicSubscribeDao`（0 方法） extends BusDynamicSubscribe>

`com.seeyon.boot.starter.mq.support.dao.BusDynamicSubscribeDao`

```java
```

### `DynamicSubscribeDao`（0 方法） extends DynamicSubscribe>

`com.seeyon.boot.starter.mq.support.dao.DynamicSubscribeDao`

```java
```

### `MQMessageDao`（0 方法） extends MQMessage>

`com.seeyon.boot.starter.mq.support.dao.MQMessageDao`

```java
```

## 二、关键类（7）

### `MessageListenerService`（25 方法）

`com.seeyon.boot.starter.mq.consumer.listener.MessageListenerService`

```java
    private com.seeyon.boot.starter.mq.converter.TopicConverter getTopicConverter();
    org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor getInvokeTaskPool();
    com.seeyon.boot.starter.mq.consumer.listener.MessageListener addMessageListener(java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String);
    com.seeyon.boot.starter.mq.consumer.listener.MessageListener addMessageListener(java.lang.String, java.lang.Object, java.lang.reflect.Method, java.lang.String);
    com.seeyon.boot.starter.mq.consumer.listener.MessageListener addMessageListener(java.lang.String, java.lang.Object, java.lang.reflect.Method);
    com.seeyon.boot.starter.mq.consumer.listener.MessageListener addMessageListener(java.lang.String, java.lang.String, java.lang.String, java.lang.String);
    com.seeyon.boot.starter.mq.consumer.listener.MessageListener addMessageListener(com.seeyon.boot.starter.mq.consumer.listener.MessageListener);
    com.seeyon.boot.starter.mq.consumer.listener.MessageListener addMessageListener(java.lang.String, java.lang.Class, java.lang.String);
    boolean topicMessageListenerIsEmpty(java.lang.String);
    void removeMethodWrapper(java.lang.String, java.lang.Object);
    void removeMessageListener(java.lang.String, java.lang.Object);
    com.seeyon.boot.starter.mq.consumer.listener.MessageListener removeMessageListener(java.lang.String, java.lang.String, java.lang.String, java.lang.String);
    com.seeyon.boot.starter.mq.consumer.listener.MessageListener removeMessageListener(java.lang.String, java.lang.Class, java.lang.String)
    com.seeyon.boot.starter.mq.consumer.listener.MessageListener findMessageListener(java.lang.String, java.lang.String, java.lang.String, java.lang.String);
    private void processDelay(com.seeyon.boot.starter.mq.support.dto.MessageDto);
    static void setRebalance(boolean);
    boolean antiDuplicate(com.seeyon.boot.starter.mq.support.dto.MessageDto);
    java.util.Map getAllMessageListener();
    void addForAntiDuplicate(java.util.Set<java.lang.String>);
    void addForAntiDuplicate(java.lang.String);
    void invoke(java.util.List<com.seeyon.boot.starter.mq.support.dto.MessageDto>)
    void invoke(com.seeyon.boot.starter.mq.support.dto.MessageDto);
```

### `DynamicSubscribeService`（15 方法）

`com.seeyon.boot.starter.mq.support.domainservice.DynamicSubscribeService`

```java
    void create(com.seeyon.boot.starter.mq.support.dto.DynamicSubscribeDto);
    com.seeyon.boot.starter.mq.support.dto.DynamicSubscribeDto selectById(java.lang.Long);
    void delete(com.seeyon.boot.starter.mq.support.dto.DynamicSubscribeDto);
    java.util.List<com.seeyon.boot.starter.mq.support.dto.DynamicSubscribeDto> selectAll();
    java.util.List<com.seeyon.boot.starter.mq.support.dto.DynamicSubscribeDto> merge(java.util.List<java.util.Map<java.lang.String, java.lang.Object>>, java.lang.String, java.lang.String);
    private java.lang.String gerTopicKey(com.seeyon.boot.starter.mq.support.entity.DynamicSubscribe);
    private java.lang.String gerTopicKey(java.util.Map<java.lang.String, java.lang.Object>);
    java.util.List<com.seeyon.boot.starter.mq.support.entity.DynamicSubscribe> selectByGa(java.lang.String, java.lang.String);
    com.seeyon.boot.starter.mq.support.dto.DynamicSubscribeDto selectByCmp(java.lang.String, java.lang.String, java.lang.String, java.lang.String);
    java.util.List<com.seeyon.boot.starter.mq.support.entity.DynamicSubscribe> select(java.util.Map<java.lang.String, java.lang.Object>);
```

### `BusDynamicSubscribeService`（11 方法）

`com.seeyon.boot.starter.mq.support.domainservice.BusDynamicSubscribeService`

```java
    void publishModuleAllCallback();
    void merge(com.seeyon.boot.starter.eventbus.ModuleMergeEvent);
    java.util.List<com.seeyon.boot.starter.eventbus.domain.dto.BusDynamicSubscribeDto> merge(java.util.List<java.util.Map<java.lang.String, java.lang.Object>>, java.lang.String, java.lang.String);
    private java.lang.String getEventBusKey(com.seeyon.boot.starter.eventbus.domain.entity.BusDynamicSubscribe);
    private java.lang.String getEventBusKey(java.util.Map<java.lang.String, java.lang.Object>);
    java.util.List<com.seeyon.boot.starter.eventbus.domain.entity.BusDynamicSubscribe> selectByGa(java.lang.String, java.lang.String);
    java.util.List<com.seeyon.boot.starter.eventbus.domain.entity.BusDynamicSubscribe> select(java.util.Map<java.lang.String, java.lang.Object>);
    void onApplicationEvent(com.seeyon.boot.event.SystemStartedEvent);
    void onApplicationEvent(org.springframework.context.ApplicationEvent);
```

### `MQMessageDomainService`（10 方法）

`com.seeyon.boot.starter.mq.support.domainservice.MQMessageDomainService`

```java
    private java.lang.Long save(com.seeyon.boot.starter.mq.support.dto.MessageDto, com.seeyon.boot.starter.mq.support.enums.MQStatusEnum);
    void markSuccess(java.lang.Long);
    void deleteById(java.lang.Long);
    void markFailure(com.seeyon.boot.starter.mq.support.dto.MessageDto);
    java.util.Map<java.lang.Long, com.seeyon.boot.starter.mq.support.dto.MessageDto> findFailure(int);
    java.util.Map<java.lang.Long, com.seeyon.boot.starter.mq.support.dto.MessageDto> deleteBeforeDays(int);
    void updateStatusFailueAndSendTimeById(java.lang.Long);
    private void updateStatus(java.lang.Long, com.seeyon.boot.starter.mq.support.enums.MQStatusEnum);
```

### `TopicConverter`（9 方法）

`com.seeyon.boot.starter.mq.converter.TopicConverter`

```java
    void addTopicItem(java.lang.String);
    boolean containsInnerTopic(java.lang.String);
    java.lang.String getInnerTopic(java.lang.String);
    java.lang.String getOuterTopic(java.lang.String);
    java.lang.String getTopicIncludeEnv(java.lang.String);
    java.lang.String getTopicExcludeEnv(java.lang.String);
    boolean isDynamicTopic(java.lang.String);
    private java.lang.String generateOuterTopic(java.lang.String);
    private boolean isSkipTopicConvert(java.lang.String);
```

### `MQAutoConfiguration`（4 方法）

`com.seeyon.boot.starter.mq.MQAutoConfiguration`

```java
    void afterPropertiesSet()
    com.seeyon.boot.starter.mq.converter.TopicConverter topicConverter();
    org.springframework.data.redis.listener.RedisMessageListenerContainer redisMessageListenerContainer(org.springframework.data.redis.connection.RedisConnectionFactory);
```

### `MQMessageCompUtils`（4 方法）

`com.seeyon.boot.starter.mq.util.MQMessageCompUtils`

```java
    static java.lang.String getTopicRedisKey();
    static com.seeyon.boot.starter.mq.spi.MQMessageSpi getMQMessageSpi(java.util.List<java.lang.String>);
    static void initMQSpi(java.util.List<java.lang.String>);
    static org.springframework.data.redis.core.RedisTemplate buildRedisTemplate(com.seeyon.boot.starter.mq.MQProperties);
```

## 三、注解（1）

| 注解 | 元素 |
|---|---|
| `MessageListener` | topic, broadcast |

## 四、枚举（2）

- `DelayTagEnum`（2 常量）：ADD, DELETE
- `MQStatusEnum`（3 常量）：init, failure, success
