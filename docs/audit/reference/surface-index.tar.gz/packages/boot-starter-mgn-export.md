# boot-starter-mgn-export：接口与方法签名

> 自动生成，勿手改。`tools/core/platform/emit_package_surfaces.py` 重跑即可。
> 构件 `com.seeyon:boot-starter-mgn-export`（jar `boot-starter-mgn-export-5.3.600.jar`）
> 规模：9 类 / 0 接口 / 0 注解 / 0 枚举 / 2 个关键类 / 48 方法。
> 签名逐字来自 javap 原文；已去掉 `public` 前缀与 `throws` 子句。

## 一、接口（0）

（本构件没有接口）

## 二、关键类（2）

### `DependentExportApiService`（11 方法）

`com.seeyon.boot.starter.export.service.DependentExportApiService`

```java
    com.seeyon.boot.starter.export.dto.DependentValidateDto getDependentVersionByName(java.lang.String, java.util.List<java.lang.String>, com.seeyon.boot.starter.system.env.enums.CtpSystemEnvEnum);
    com.seeyon.boot.starter.export.dto.DependentValidateDto getDependentVersionByName(java.lang.String, java.util.List<java.lang.String>, com.seeyon.boot.starter.system.env.enums.CtpSystemEnvEnum, java.lang.Boolean);
    private com.seeyon.boot.starter.export.dto.DependentValidateDto getDependentByNames(java.lang.String, java.util.List<java.lang.String>);
    java.util.Map<java.lang.String, java.util.List<com.seeyon.boot.starter.export.dto.DependentVersionDataDto>> getDependentDynamicVersion(java.lang.String, java.lang.String, com.seeyon.boot.starter.system.env.enums.CtpSystemEnvEnum);
    private java.util.Map<java.lang.String, java.util.List<com.seeyon.boot.starter.export.dto.DependentVersionDataDto>> getCurrentDependentVersion(java.lang.String, java.lang.String);
    private java.util.List<java.lang.String> getDependentList(java.util.jar.JarFile);
    private java.lang.Boolean compareVersion(java.lang.String, java.lang.String);
```

### `DependentExportVersionService`（6 方法）

`com.seeyon.boot.starter.export.service.DependentExportVersionService`

```java
    boolean uploadVersion(boolean);
    boolean uploadVersion();
    boolean uploadVersion(java.lang.String);
    synchronized boolean uploadVersion(java.lang.String, boolean);
    synchronized void uploadVersionIncrement(java.lang.String, java.lang.String);
    java.lang.String getJsonName(java.lang.String);
```
