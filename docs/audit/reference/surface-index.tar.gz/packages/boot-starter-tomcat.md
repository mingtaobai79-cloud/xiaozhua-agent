# boot-starter-tomcat：接口与方法签名

> 自动生成，勿手改。`tools/core/platform/emit_package_surfaces.py` 重跑即可。
> 构件 `com.seeyon:boot-starter-tomcat`（jar `boot-starter-tomcat-5.3.600.jar`）
> 规模：7 类 / 0 接口 / 0 注解 / 0 枚举 / 2 个关键类 / 51 方法。
> 签名逐字来自 javap 原文；已去掉 `public` 前缀与 `throws` 子句。

## 一、接口（0）

（本构件没有接口）

## 二、关键类（2）

### `NoSessionManager`（10 方法）

`com.seeyon.boot.starter.tomcat.NoSessionManager`

```java
    protected synchronized void startInternal()
    protected synchronized void stopInternal()
    void load()
    void unload()
    org.apache.catalina.Session createSession(java.lang.String);
    org.apache.catalina.Session createEmptySession();
    void add(org.apache.catalina.Session);
    org.apache.catalina.Session findSession(java.lang.String)
    org.apache.catalina.Session[] findSessions();
    void processExpires();
```

### `TomcatAutoConfiguration`（9 方法）

`com.seeyon.boot.starter.tomcat.TomcatAutoConfiguration`

```java
    org.springframework.boot.web.server.WebServerFactoryCustomizer<org.springframework.boot.web.embedded.tomcat.TomcatServletWebServerFactory> seeyonWebServerFactoryCustomizer();
    protected void processJspConfig(org.springframework.boot.web.embedded.tomcat.TomcatServletWebServerFactory);
    protected void processAccessLog(org.springframework.boot.web.embedded.tomcat.TomcatServletWebServerFactory);
    private void processWorkspace(org.springframework.boot.web.embedded.tomcat.TomcatServletWebServerFactory);
```
