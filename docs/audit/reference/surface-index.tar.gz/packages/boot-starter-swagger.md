# boot-starter-swagger：接口与方法签名

> 自动生成，勿手改。`tools/core/platform/emit_package_surfaces.py` 重跑即可。
> 构件 `com.seeyon:boot-starter-swagger`（jar `boot-starter-swagger-5.3.600.jar`）
> 规模：25 类 / 0 接口 / 0 注解 / 0 枚举 / 11 个关键类 / 131 方法。
> 签名逐字来自 javap 原文；已去掉 `public` 前缀与 `throws` 子句。

## 一、接口（0）

（本构件没有接口）

## 二、关键类（11）

### `SeeyonSwaggerBeanConfiguration`（18 方法）

`com.seeyon.boot.starter.swagger.spring.bean.SeeyonSwaggerBeanConfiguration`

```java
    java.lang.Runnable dockets();
    org.springframework.boot.web.servlet.ServletRegistrationBean swaggerPathServlet();
    springfox.documentation.spring.web.readers.operation.HandlerMethodResolver handlerMethodResolver();
    springfox.documentation.spring.web.DocumentationCache documentationCache();
    springfox.documentation.spi.service.contexts.Defaults defaults();
    springfox.documentation.PathProvider pathProvider();
    springfox.documentation.spring.web.json.JsonSerializer swaggerJsonSerializer(java.util.List<springfox.documentation.spring.web.json.JacksonModuleRegistrar>);
    springfox.documentation.spring.web.DescriptionResolver descriptionResolver();
    private springfox.documentation.service.ApiInfo apiInfo();
    void onApplicationEvent(com.seeyon.boot.event.SystemStartedEvent);
    void onApplicationEvent(org.springframework.context.ApplicationEvent);
```

### `SeeyonServiceModelToSwagger2MapperImpl`（14 方法）

`com.seeyon.boot.starter.swagger.spring.SeeyonServiceModelToSwagger2MapperImpl`

```java
    java.util.Map<java.lang.String, io.swagger.models.Model> modelsFromApiListings(springfox.documentation.swagger2.mappers.ModelMapper, java.util.Map<java.lang.String, java.util.List<springfox.documentation.service.ApiListing>>);
    private io.swagger.models.Path mapOperations(springfox.documentation.service.ApiDescription, com.google.common.base.Optional<io.swagger.models.Path>);
    private boolean hasOrder(java.util.List<springfox.documentation.service.ApiDescription>);
    protected java.util.Map<java.lang.String, io.swagger.models.Path> mapApiListings(java.util.Map<java.lang.String, java.util.List<springfox.documentation.service.ApiListing>>);
    private java.util.List<springfox.documentation.service.ApiDescription> flattening(java.util.List<springfox.documentation.service.ApiListing>);
    io.swagger.models.Swagger mapDocumentation(springfox.documentation.service.Documentation);
    protected io.swagger.models.Info mapApiInfo(springfox.documentation.service.ApiInfo);
    protected io.swagger.models.Contact map(springfox.documentation.service.Contact);
    protected io.swagger.models.Operation mapOperation(springfox.documentation.service.Operation);
    protected io.swagger.models.Tag mapTag(springfox.documentation.service.Tag);
    private springfox.documentation.service.ApiInfo fromResourceListingInfo(springfox.documentation.service.Documentation);
    protected java.util.List<io.swagger.models.Tag> tagSetToTagList(java.util.Set<springfox.documentation.service.Tag>);
    protected java.util.List<io.swagger.models.Scheme> stringSetToSchemeList(java.util.Set<java.lang.String>);
    protected java.util.List<io.swagger.models.parameters.Parameter> parameterListToParameterList(java.util.List<springfox.documentation.service.Parameter>);
```

### `SeeyonParameterBuilderPlugin`（11 方法）

`com.seeyon.boot.starter.swagger.plugins.SeeyonParameterBuilderPlugin`

```java
    boolean supports(springfox.documentation.spi.DocumentationType);
    void apply(springfox.documentation.spi.service.contexts.ParameterContext);
    java.lang.String findParameterType(springfox.documentation.spi.service.contexts.ParameterContext);
    private java.lang.String determineScalarParameterType(java.util.Set<? extends org.springframework.http.MediaType>, org.springframework.http.HttpMethod);
    private boolean isListOfFiles(com.fasterxml.classmate.ResolvedType);
    private boolean isFileType(com.fasterxml.classmate.ResolvedType);
    private boolean isRequired(springfox.documentation.spi.service.contexts.OperationContext, springfox.documentation.service.ResolvedMethodParameter);
    private boolean optionalButPresentInThePath(springfox.documentation.spi.service.contexts.OperationContext, org.springframework.web.bind.annotation.PathVariable, java.lang.String);
    boolean isOptional(springfox.documentation.service.ResolvedMethodParameter);
    private boolean isRequired(org.springframework.web.bind.annotation.RequestParam);
    boolean supports(java.lang.Object);
```

### `SeeyonOperationBuilderPlugin`（10 方法）

`com.seeyon.boot.starter.swagger.plugins.SeeyonOperationBuilderPlugin`

```java
    boolean supports(springfox.documentation.spi.DocumentationType);
    void apply(springfox.documentation.spi.service.contexts.OperationContext);
    private boolean handlerMethodHasFileParameter(springfox.documentation.spi.service.contexts.OperationContext);
    private java.util.Set<java.lang.String> toSet(java.util.Set<? extends org.springframework.http.MediaType>);
    private java.util.Set<java.lang.String> defaultTags(springfox.documentation.spi.service.contexts.OperationContext);
    private java.util.Set<java.lang.String> controllerTags(springfox.documentation.spi.service.contexts.OperationContext);
    private java.util.Set<java.lang.String> operationTags(springfox.documentation.spi.service.contexts.OperationContext);
    private com.google.common.base.Function<com.seeyon.boot.annotation.RestApiOperation, java.util.Set<java.lang.String>> tagsFromOperation();
    private com.google.common.base.Function<com.seeyon.boot.annotation.RestApi, java.util.Set<java.lang.String>> tagsFromController();
    boolean supports(java.lang.Object);
```

### `OptionalUtils`（9 方法）

`com.seeyon.boot.starter.swagger.util.OptionalUtils`

```java
    static com.google.common.base.Predicate<java.lang.String> emptyTags();
    static com.google.common.base.Predicate<springfox.documentation.RequestHandler> withGroup(java.lang.String);
    static com.google.common.base.Predicate<springfox.documentation.RequestHandler> notWithGroup(java.util.Set<java.lang.String>);
    static com.google.common.base.Predicate<springfox.documentation.RequestHandler> withMethodAnnotation(java.lang.Class<? extends java.lang.annotation.Annotation>);
    static com.google.common.base.Predicate<springfox.documentation.RequestHandler> withClassAnnotation(java.lang.Class<? extends java.lang.annotation.Annotation>);
    static com.google.common.base.Function<java.lang.Class<?>, java.lang.Boolean> annotationPresent(java.lang.Class<? extends java.lang.annotation.Annotation>);
    static com.google.common.base.Function<java.lang.Class<?>, java.lang.Boolean> handlerPackage(java.lang.String);
    static com.google.common.base.Predicate<springfox.documentation.RequestHandler> basePackage(java.lang.String);
    static com.google.common.base.Optional<? extends java.lang.Class<?>> declaringClass(springfox.documentation.RequestHandler);
```

### `DyClassUtils`（8 方法）

`com.seeyon.boot.starter.swagger.util.DyClassUtils`

```java
    static java.lang.Class<?> createDynamicModelClass(java.lang.String, java.util.Map<java.lang.String, java.lang.Class>, java.util.List<springfox.documentation.service.ResolvedMethodParameter>);
    static java.lang.Class<?> createDynamicModelClass(java.lang.String, java.util.List<java.lang.reflect.Field>);
    static java.lang.Class<?> load(java.lang.String);
    static private static javassist.CtField createField(springfox.documentation.service.ResolvedMethodParameter, java.util.Map<java.lang.String, java.lang.Class>, javassist.CtClass)
    static private static javassist.CtField createField(java.lang.reflect.Field, javassist.CtClass)
    static javassist.CtClass getFieldType(java.lang.Class<?>);
    static java.lang.String dyClassName(java.lang.String, java.lang.String, java.lang.String);
    static java.lang.String combinationParamsClassName(java.lang.String, java.lang.String);
```

### `SeeyonExpandedParameterBuilder`（6 方法）

`com.seeyon.boot.starter.swagger.plugins.SeeyonExpandedParameterBuilder`

```java
    void apply(springfox.documentation.spi.service.contexts.ParameterExpansionContext);
    boolean supports(springfox.documentation.spi.DocumentationType);
    private void fromApiParam(springfox.documentation.spi.service.contexts.ParameterExpansionContext, com.seeyon.boot.annotation.ParameterInfo);
    private void fromApiModelProperty(springfox.documentation.spi.service.contexts.ParameterExpansionContext, com.seeyon.boot.annotation.DtoAttribute);
    private springfox.documentation.builders.ParameterBuilder maybeSetParameterName(springfox.documentation.spi.service.contexts.ParameterExpansionContext);
    boolean supports(java.lang.Object);
```

### `SeeyonModelPropertyBuilderPlugin`（5 方法）

`com.seeyon.boot.starter.swagger.plugins.SeeyonModelPropertyBuilderPlugin`

```java
    boolean supports(springfox.documentation.spi.DocumentationType);
    void apply(springfox.documentation.spi.schema.contexts.ModelPropertyContext);
    private void buildDtoAttributes(springfox.documentation.spi.schema.contexts.ModelPropertyContext);
    static com.google.common.base.Function<com.seeyon.boot.annotation.DtoAttribute, java.lang.String> toExample();
    boolean supports(java.lang.Object);
```

### `SeeyonOperationModelsProviderPlugin`（4 方法）

`com.seeyon.boot.starter.swagger.plugins.SeeyonOperationModelsProviderPlugin`

```java
    boolean supports(springfox.documentation.spi.DocumentationType);
    void apply(springfox.documentation.spi.service.contexts.RequestMappingContext);
    private boolean startsWithOneOfPackages(java.lang.String, java.lang.String);
    boolean supports(java.lang.Object);
```

### `SeeyonModelBuilderPlugin`（3 方法）

`com.seeyon.boot.starter.swagger.plugins.SeeyonModelBuilderPlugin`

```java
    boolean supports(springfox.documentation.spi.DocumentationType);
    void apply(springfox.documentation.spi.schema.contexts.ModelContext);
    boolean supports(java.lang.Object);
```

### `ExtensionUtils`（3 方法）

`com.seeyon.boot.starter.swagger.util.ExtensionUtils`

```java
    static java.util.List<springfox.documentation.service.VendorExtension> buildStringExtensions(java.lang.String, java.lang.String);
    static java.util.List<springfox.documentation.service.VendorExtension> buildObjectExtensions(com.seeyon.boot.annotation.Custom[]);
    static java.util.List<springfox.documentation.service.VendorExtension> buildObjectExtensions(java.lang.String);
```
