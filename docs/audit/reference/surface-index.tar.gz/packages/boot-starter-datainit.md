# boot-starter-datainit：接口与方法签名

> 自动生成，勿手改。`tools/core/platform/emit_package_surfaces.py` 重跑即可。
> 构件 `com.seeyon:boot-starter-datainit`（jar `boot-starter-datainit-5.3.600.jar`）
> 规模：88 类 / 19 接口 / 0 注解 / 3 枚举 / 12 个关键类 / 587 方法。
> 签名逐字来自 javap 原文；已去掉 `public` 前缀与 `throws` 子句。

## 一、接口（19）

### `InitMonitorAppService`（5 方法）

`com.seeyon.boot.starter.datainit.appservice.InitMonitorAppService`

```java
    com.seeyon.boot.transport.PageResponse<com.seeyon.boot.starter.datainit.dto.AppStarterInitVersionDto> selectAppStarterInitVersions(com.seeyon.boot.transport.PageRequest);
    com.seeyon.boot.transport.SingleResponse<java.lang.String> executeOnetime(java.lang.Long);
    com.seeyon.boot.transport.SingleResponse<java.lang.String> executeWithRecordType(java.lang.Integer);
    com.seeyon.boot.transport.SingleResponse<java.lang.String> ignoreError(java.lang.Long);
    com.seeyon.boot.transport.ListResponse<com.seeyon.boot.starter.datainit.dto.AppInitSingleDetailDto> selectAppInitSingleDetails(java.util.Map<java.lang.String, java.lang.Object>);
```

### `DataInitializer`（4 方法）

`com.seeyon.boot.starter.datainit.extend.DataInitializer`

```java
    void initAppData(java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.ClassLoader);
    void initAppData(java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.ClassLoader, java.lang.Boolean);
    void initTenantData(java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.ClassLoader, java.lang.String)
    java.lang.Boolean deleteTenantData(java.lang.String, java.lang.String, java.lang.String);
```

### `DataInitAdapter`（3 方法）

`com.seeyon.boot.starter.datainit.adepter.DataInitAdapter`

```java
    default void beforeDml(com.seeyon.boot.starter.datainit.adepter.BeforeDmlParams);
    default void remoteBeforeDml(com.seeyon.boot.starter.datainit.adepter.BeforeDmlParams);
    default java.util.Set<java.lang.String> skipTenantInit();
```

### `DDLExceptionParser`（3 方法）

`com.seeyon.boot.starter.datainit.exception.DDLExceptionParser`

```java
    default boolean ignore(java.lang.String);
    java.util.Set<java.util.regex.Pattern> ignorePatterns();
```

### `TenantDataInitializerInterface`（3 方法）

`com.seeyon.boot.starter.datainit.service.TenantDataInitializerInterface`

```java
    com.seeyon.boot.transport.SingleResponse<java.lang.String> initTenantData(java.lang.String);
    default com.seeyon.boot.transport.SingleResponse<java.lang.String> initTenantData(java.lang.String, java.lang.String);
    com.seeyon.boot.transport.SingleResponse<java.lang.Boolean> deleteTenantData(java.lang.String);
```

### `BeforeBatchExeAdapter`（1 方法）

`com.seeyon.boot.starter.datainit.adepter.BeforeBatchExeAdapter`

```java
    default com.seeyon.boot.starter.datainit.adepter.BeforeBatchExeResult before(com.seeyon.boot.starter.datainit.adepter.BeforeBatchExeParams);
```

### `DdlInitAdapter`（1 方法）

`com.seeyon.boot.starter.datainit.adepter.DdlInitAdapter`

```java
    default void after(com.seeyon.boot.starter.datainit.adepter.AfterDdlParams);
```

### `EntitySortAdapter`（1 方法）

`com.seeyon.boot.starter.datainit.adepter.EntitySortAdapter`

```java
    default java.util.LinkedList<java.lang.String> sort(com.seeyon.boot.starter.datainit.adepter.EntitySortParams);
```

### `ProxyRelationJobInterface`（1 方法）

`com.seeyon.boot.starter.datainit.proxy.ProxyRelationJobInterface`

```java
    com.seeyon.boot.transport.SingleResponse<java.lang.String> initTenantData(com.seeyon.boot.starter.datainit.message.listener.DataInitializerMessage);
```

### `AppDataInitDetailDao`（0 方法） extends AppDataInitDetail>

`com.seeyon.boot.starter.datainit.domain.dao.AppDataInitDetailDao`

```java
```

### `AppDataInitVersionDao`（0 方法） extends AppDataInitVersion>

`com.seeyon.boot.starter.datainit.domain.dao.AppDataInitVersionDao`

```java
```

### `AppInitSingleDetailDao`（0 方法） extends AppInitSingleDetail>

`com.seeyon.boot.starter.datainit.domain.dao.AppInitSingleDetailDao`

```java
```

### `AppStarterInitDetailDao`（0 方法） extends AppStarterInitDetail>

`com.seeyon.boot.starter.datainit.domain.dao.AppStarterInitDetailDao`

```java
```

### `AppStarterInitVersionDao`（0 方法） extends AppStarterInitVersion>

`com.seeyon.boot.starter.datainit.domain.dao.AppStarterInitVersionDao`

```java
```

### `AppTenantIdRelationDao`（0 方法） extends AppTenantIdRelation>

`com.seeyon.boot.starter.datainit.domain.dao.AppTenantIdRelationDao`

```java
```

### `AppTenantIncrementVersionDao`（0 方法） extends AppTenantIncrementVersion>

`com.seeyon.boot.starter.datainit.domain.dao.AppTenantIncrementVersionDao`

```java
```

### `AppTenantInitDeleteDao`（0 方法） extends AppTenantInitDelete>

`com.seeyon.boot.starter.datainit.domain.dao.AppTenantInitDeleteDao`

```java
```

### `AppTenantInitDetailDao`（0 方法） extends AppTenantInitDetail>

`com.seeyon.boot.starter.datainit.domain.dao.AppTenantInitDetailDao`

```java
```

### `AppTenantInitVersionDao`（0 方法） extends AppTenantInitVersion>

`com.seeyon.boot.starter.datainit.domain.dao.AppTenantInitVersionDao`

```java
```

## 二、关键类（12）

### `DataRollbackService`（18 方法）

`com.seeyon.boot.starter.datainit.service.DataRollbackService`

```java
    void destroy();
    void addForInsert(java.lang.String, java.lang.Long);
    void addForUpdate(java.lang.String, java.lang.String);
    void addForDelete(java.lang.String, java.lang.String);
    void clearThreadLocal();
    void jsonRollBack(java.lang.ClassLoader, java.lang.String);
    void jsonRollBack(java.lang.ClassLoader, java.lang.Long);
    private void update(java.lang.String, java.util.List<java.lang.String>, java.lang.ClassLoader)
    private void deleteRollback(java.lang.String, java.util.List<java.lang.String>, java.lang.ClassLoader)
    private void delete(java.lang.String, java.util.List<java.lang.Long>)
    com.seeyon.boot.domain.dao.BaseDao getBaseDaoWithGenerics(java.lang.Class<?>);
```

### `InitDetailService`（11 方法）

`com.seeyon.boot.starter.datainit.domain.service.InitDetailService`

```java
    void addMd5FromDataPrivateDetail(java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String);
    void addStoryKeyFromDataPrivateDetail(java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String);
    java.lang.String getMd5FromDataPrivateDetail(java.lang.String, java.lang.String, java.lang.String, java.lang.String);
    java.lang.String getStoryKeyFromDataPrivateDetail(java.lang.String, java.lang.String, java.lang.String, java.lang.String);
    void addDataPublicDetail(java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String);
    void addMd5FromDataPublicDetail(java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String);
    void addStoryKeyFromDataPublicDetail(java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String);
    java.lang.String getMd5FromDataPublicDetail(java.lang.String, java.lang.String, java.lang.String, java.lang.String);
    java.lang.String getStoryKeyFromDataPublicDetail(java.lang.String, java.lang.String, java.lang.String, java.lang.String);
    void addTenantDetail(java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String);
    void addTenantErrorDetail(java.lang.String, java.lang.String, java.lang.String);
```

### `AppRelationStatusService`（7 方法）

`com.seeyon.boot.starter.datainit.service.AppRelationStatusService`

```java
    void updateStatus(java.lang.String, java.lang.String, java.lang.String, java.lang.String, com.seeyon.boot.starter.datainit.common.AppRelationStatusEnum);
    void updateAllStatus(java.lang.String, java.lang.String, java.lang.String, java.util.Map<java.lang.String, java.lang.Integer>);
    void updateErrMsg(java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String);
    java.util.Map<java.lang.String, java.lang.String> getErrMsg(java.lang.String, java.lang.String, java.lang.String);
    boolean isAllSuccess(java.lang.String, java.lang.String, java.lang.String, java.lang.Long, boolean);
    java.util.Map<java.lang.String, java.lang.Integer> getAllStatus(java.lang.String, java.lang.String, java.lang.String);
    void clearData(java.lang.String, java.lang.String, java.lang.String);
```

### `DataInitAdapterConfig`（6 方法）

`com.seeyon.boot.starter.datainit.adepter.DataInitAdapterConfig`

```java
    void addDdlAdapter(com.seeyon.boot.starter.datainit.adepter.DdlInitAdapter);
    void exeAfterDdl(com.seeyon.boot.starter.datainit.adepter.AfterDdlParams);
    void addAdapter(com.seeyon.boot.starter.datainit.adepter.DataInitAdapter);
    void exeRemoteBeforeDmlAdapter(com.seeyon.boot.starter.datainit.adepter.BeforeDmlParams);
    void exeBeforeDmlAdapter(com.seeyon.boot.starter.datainit.adepter.BeforeDmlParams);
    java.util.Set<java.lang.String> exeSkipTenantInit();
```

### `ExceptionCacheService`（6 方法）

`com.seeyon.boot.starter.datainit.exception.ExceptionCacheService`

```java
    void add(java.lang.String);
    void addListener(java.lang.String);
    java.lang.Integer getLimit();
    java.util.Map<java.lang.String, java.lang.String> get();
    java.util.Map<java.lang.String, java.lang.String> getListener();
```

### `JdbcDaoService`（6 方法）

`com.seeyon.boot.starter.datainit.service.JdbcDaoService`

```java
    java.util.List<java.util.Map<java.lang.String, java.lang.Object>> selectBatch(javax.sql.DataSource, java.util.Map<java.lang.String, java.lang.Object>, java.lang.String, java.util.List<java.lang.String>)
    int update(javax.sql.DataSource, java.lang.String, java.lang.Long, java.util.Map<java.lang.String, java.lang.Object>)
    int create(javax.sql.DataSource, java.lang.String, java.util.Map<java.lang.String, java.lang.Object>)
    private java.lang.String buildCreateSql(java.lang.String, java.util.Map<java.lang.String, java.lang.Object>);
    private java.lang.String buildUpdateSql(java.lang.String, java.lang.Long, java.util.Map<java.lang.String, java.lang.Object>);
    private java.lang.String buildSelectSql(java.util.Map<java.lang.String, java.lang.Object>, java.lang.String, java.util.List<java.lang.String>);
```

### `InitMonitorAppServiceImpl`（5 方法）

`com.seeyon.boot.starter.datainit.appservice.InitMonitorAppServiceImpl`

```java
    com.seeyon.boot.transport.PageResponse<com.seeyon.boot.starter.datainit.dto.AppStarterInitVersionDto> selectAppStarterInitVersions(com.seeyon.boot.transport.PageRequest);
    com.seeyon.boot.transport.SingleResponse<java.lang.String> executeOnetime(java.lang.Long);
    com.seeyon.boot.transport.SingleResponse<java.lang.String> executeWithRecordType(java.lang.Integer);
    com.seeyon.boot.transport.SingleResponse<java.lang.String> ignoreError(java.lang.Long);
    com.seeyon.boot.transport.ListResponse<com.seeyon.boot.starter.datainit.dto.AppInitSingleDetailDto> selectAppInitSingleDetails(java.util.Map<java.lang.String, java.lang.Object>);
```

### `AppInitSingleService`（5 方法）

`com.seeyon.boot.starter.datainit.domain.service.AppInitSingleService`

```java
    void executeOnetime(java.lang.Long);
    void executeWithRecordType(java.lang.Integer);
    private void executeOnetime(com.seeyon.boot.starter.datainit.domain.entity.AppInitSingleDetail);
    void ignoreError(java.lang.Long);
    java.util.List<com.seeyon.boot.starter.datainit.domain.entity.AppInitSingleDetail> selectAppInitSingleDetails(java.util.Map<java.lang.String, java.lang.Object>);
```

### `IdRelationCacheService`（3 方法）

`com.seeyon.boot.starter.datainit.service.IdRelationCacheService`

```java
    java.util.Map<java.lang.String, java.lang.String> getField(java.lang.String, java.lang.String, java.lang.String);
    void putData(java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String);
    void clearData(java.lang.String, java.lang.String, java.lang.String);
```

### `TenantDataInitRedoService`（3 方法）

`com.seeyon.boot.starter.datainit.service.TenantDataInitRedoService`

```java
    void addRedoTask(java.lang.String, java.lang.String, java.lang.String);
    void init();
```

### `DataInitTaskService`（3 方法）

`com.seeyon.boot.starter.datainit.task.DataInitTaskService`

```java
    com.seeyon.boot.transport.SingleResponse<?> exec();
```

### `StartersInitTaskService`（3 方法）

`com.seeyon.boot.starter.datainit.task.StartersInitTaskService`

```java
    com.seeyon.boot.transport.SingleResponse<?> exec();
```

## 四、枚举（3）

- `DataInitDbType`（2 常量）：INSERT, UPDATE
- `AppRelationStatusEnum`（3 常量）：START, SUCCESS, FAIL
- `SandboxStatusEnum`（2 常量）：DELETE, STOP
