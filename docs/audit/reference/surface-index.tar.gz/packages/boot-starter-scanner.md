# boot-starter-scanner：接口与方法签名

> 自动生成，勿手改。`tools/core/platform/emit_package_surfaces.py` 重跑即可。
> 构件 `com.seeyon:boot-starter-scanner`（jar `boot-starter-scanner-5.3.600.jar`）
> 规模：2 类 / 0 接口 / 0 注解 / 0 枚举 / 1 个关键类 / 124 方法。
> 签名逐字来自 javap 原文；已去掉 `public` 前缀与 `throws` 子句。

## 一、接口（0）

（本构件没有接口）

## 二、关键类（1）

### `MetadataScannerUtils`（58 方法）

`com.seeyon.boot.starter.scanner.util.MetadataScannerUtils`

```java
    static java.util.Map<java.lang.String, com.seeyon.ctp.metadata.dto.StarterMetadataDto> scanStarterInfoMetadata(java.lang.String);
    static void removeParameterNamesCache(java.util.List<java.lang.Class>);
    static <V> java.util.Map<java.lang.String, V> buildStarterMetadataMap(java.lang.String, java.util.Map<java.lang.String, V>);
    static com.seeyon.boot.starter.scanner.util.MetadataScannerUtils$MetadataClassLoader getClassLoader(java.lang.String);
    static java.lang.String readJson(java.util.jar.JarFile, java.util.jar.JarEntry);
    static java.lang.Class loadClass(com.seeyon.boot.starter.scanner.util.MetadataScannerUtils$MetadataClassLoader, java.lang.String)
    static java.lang.String readJarJson(java.util.jar.JarFile, java.util.jar.JarEntry);
    static java.util.List<java.lang.String> readJarTxtLines(java.util.jar.JarFile, java.util.jar.JarEntry);
    static java.util.Map<java.lang.String, java.lang.Class> classListToMap(java.util.List<java.lang.Class>);
    static java.util.Map<java.lang.String, com.seeyon.ctp.metadata.dto.DtoAttributeMetadataDto> sortDtoAttributeMetadata(java.util.Map<java.lang.String, com.seeyon.ctp.metadata.dto.DtoAttributeMetadataDto>);
    static java.util.Map<java.lang.String, com.seeyon.ctp.metadata.dto.EntityAttributeMetadataDto> sortEntityAttributeMetadata(java.util.Map<java.lang.String, com.seeyon.ctp.metadata.dto.EntityAttributeMetadataDto>);
    static void sortMetadataForList(java.util.List);
    static com.seeyon.ctp.metadata.dto.model.ItemDto buildItemDtoFromGenericType(java.lang.reflect.Type, java.lang.Class, int);
    static void setMapItemDtoValues(com.seeyon.ctp.metadata.dto.model.ItemDto, java.lang.reflect.Type, java.lang.reflect.Type, java.lang.Class);
    static void setItemDtoValues(com.seeyon.ctp.metadata.dto.model.ItemDto, java.lang.reflect.Type, java.lang.Class);
    static java.util.List<java.lang.String> buildEnumList(java.lang.Class);
    static java.lang.String getParameterNameByAnnotation(org.springframework.core.MethodParameter, java.lang.String);
    static java.lang.String getParameterNameByAnnotation(java.lang.reflect.Parameter, java.lang.String);
    static java.util.List<com.seeyon.ctp.metadata.dto.RestParamMetadataDto> buildRestParameter(org.springframework.web.servlet.mvc.method.RequestMappingInfo, org.springframework.web.method.HandlerMethod, java.util.List<java.lang.Class>, java.util.List<java.lang.Class>, java.lang.Class);
    static java.util.List<com.seeyon.ctp.metadata.dto.RestParamMetadataDto> buildRestParameter(java.lang.reflect.Method, java.util.List<java.lang.Class>, java.util.List<java.lang.Class>, java.lang.Class);
    static void collectDtoClass(java.util.List<java.lang.Class>, java.lang.reflect.Type);
    static boolean restParameterRequired(org.springframework.core.MethodParameter);
    static boolean restParameterRequired(java.lang.reflect.Parameter);
    static com.seeyon.ctp.metadata.dto.model.ParameterDto buildAppServiceParameter(java.lang.reflect.Method, java.util.List<java.lang.Class>, java.lang.Class);
    static com.seeyon.ctp.metadata.dto.model.ReturnValueDto buildReturnValue(java.lang.reflect.Method, java.util.List<java.lang.Class>, java.util.List<java.lang.Class>, java.lang.Class, java.lang.String);
    static java.util.Map<java.lang.String, java.lang.Object> readCustomsFromAnnotation(com.seeyon.boot.annotation.Custom[]);
    static java.lang.String getParameterType(java.lang.reflect.Parameter);
    static java.lang.String getParameterType(org.springframework.core.MethodParameter, org.springframework.web.servlet.mvc.method.RequestMappingInfo);
    static boolean isFileParameter(java.lang.reflect.Parameter);
    static java.lang.String determineScalarParameterType(java.util.Set<? extends org.springframework.http.MediaType>, java.lang.String);
    static java.lang.String getValidateGroups(java.lang.Class[]);
    static java.util.Map<java.lang.String, java.lang.Object> buildValidations(java.lang.annotation.Annotation[]);
    static java.lang.Class getControllerSuperClassVariable(java.lang.Class);
    static java.util.Map<java.lang.String, java.beans.PropertyDescriptor> getPropertyDescriptors(java.lang.Class);
    static void sortClassList(java.util.List<java.lang.Class>);
    static java.lang.String getClassLocation(java.lang.Class);
    static boolean isAppPublic(java.lang.String, java.lang.String);
    static boolean isAppPublic(java.lang.String, java.lang.Class);
    static boolean isStarter(java.lang.String);
    static boolean isStarter(java.lang.Class);
    static java.util.Map<java.lang.Class, java.util.List<java.lang.Class>> groupByAnnotation(java.util.List<java.lang.Class>);
    static void printDyClass(java.util.Map<java.lang.Class, java.util.List<java.lang.Class>>);
    static java.lang.String getCtpEnumJson(java.lang.String);
    static java.lang.String getCtpEnumItemJson(java.lang.String);
    static java.lang.String getPageInfoJson(java.lang.String);
    static java.util.List<java.lang.String> getReferJsonList();
    static java.util.Map<java.lang.String, java.util.Map<java.lang.Class, java.util.List<java.lang.Class>>> scannerAppClass(java.util.Map<java.lang.String, com.seeyon.boot.context.model.AppInfo>);
    static java.util.Set<java.lang.String> artifactIds(java.lang.String);
    static boolean artifactIdsContains(java.util.Set<java.lang.String>, java.lang.String);
    static private static void putGroupMap(java.util.Map<java.lang.Class, java.util.List<java.lang.Class>>, java.lang.Class, java.lang.Class);
    static private static java.lang.String getProjectNameByClass(java.lang.Class);
    static void clearModuleAppCache();
```
