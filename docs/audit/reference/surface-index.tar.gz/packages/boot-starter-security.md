# boot-starter-security：接口与方法签名

> 自动生成，勿手改。`tools/core/platform/emit_package_surfaces.py` 重跑即可。
> 构件 `com.seeyon:boot-starter-security`（jar `boot-starter-security-5.3.600.jar`）
> 规模：17 类 / 0 接口 / 0 注解 / 0 枚举 / 5 个关键类 / 83 方法。
> 签名逐字来自 javap 原文；已去掉 `public` 前缀与 `throws` 子句。

## 一、接口（0）

（本构件没有接口）

## 二、关键类（5）

### `SecurityHandlerInterceptor`（21 方法）

`com.seeyon.boot.starter.security.filter.SecurityHandlerInterceptor`

```java
    private boolean checkIgnorePath(java.lang.String);
    private boolean checkPublicAccessIgnorePath(java.lang.String);
    boolean preHandle(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse, java.lang.Object)
    private java.lang.Boolean checkOrgAdmin(java.util.Set<java.lang.String>, java.util.Set<java.lang.String>, java.lang.Long, java.lang.String, java.lang.Long);
    private java.lang.Boolean validateOrgAdminPermission(java.util.List<java.lang.String>, java.util.Set<java.lang.String>, java.lang.Long, java.lang.String, java.lang.Long);
    void postHandle(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse, java.lang.Object, org.springframework.web.servlet.ModelAndView)
    void afterCompletion(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse, java.lang.Object, java.lang.Exception)
    private com.seeyon.boot.exception.BusinessException handlerException();
    private java.util.Set<java.lang.String> handleRole(java.lang.String[]);
    private boolean checkComponentPermission(java.lang.Long, java.lang.String, java.lang.String, java.lang.String, java.lang.String);
    private boolean checkAppAdminPermission(javax.servlet.http.HttpServletRequest, java.util.Set<java.lang.String>, java.util.Set<java.lang.String>, java.lang.String, java.lang.String, java.lang.String, java.lang.Long);
    private java.lang.Boolean checkUrlPermission(java.lang.Long, java.lang.String, java.lang.String, java.lang.String);
    private boolean checkModuleAdmin(java.util.Set<java.lang.String>, java.util.Set<java.lang.String>, java.lang.Long, java.lang.String);
    private boolean checkPublicAccessPermission(org.springframework.web.method.HandlerMethod, java.lang.String, java.lang.String, java.lang.String);
    private void saveAuditLog(javax.servlet.http.HttpServletRequest, org.springframework.web.method.HandlerMethod, java.lang.String);
    private boolean checkIdentity(java.lang.String, java.lang.String);
    private java.lang.String parseRoleArg(java.lang.String, javax.servlet.http.HttpServletRequest, java.lang.String);
    private java.lang.Long getAuthOrgId(javax.servlet.http.HttpServletRequest, com.seeyon.boot.annotation.HasRole);
    static java.lang.Boolean isLong(java.lang.String);
    private javax.servlet.http.HttpServletRequest findSecurityHttpServletRequestWrapper(javax.servlet.http.HttpServletRequest);
    private com.seeyon.ctp.user.spi.SecurityCheckServiceSpi getSecurityService();
```

### `SecurityService`（20 方法）

`com.seeyon.boot.starter.security.service.SecurityService`

```java
    java.util.Set<java.lang.String> selectOrgRoleCodeByUser(java.lang.Long);
    java.util.Set<java.lang.String> selectOrgRoleCodeByUser(java.lang.Long, java.lang.Long);
    private java.lang.Boolean isChildrenInstitution(java.lang.Long);
    private java.lang.Boolean isChildrenOfCurrentInstitution(java.lang.Long);
    boolean checkComponent(java.lang.Long, java.lang.String);
    java.util.Set<java.lang.String> selectControlMenus(java.lang.String);
    java.lang.Boolean checkApplicationAuthAccess(java.lang.Long, java.lang.String);
    java.lang.Boolean checkApplicationAuthAllAccess(java.lang.String);
    java.util.Map<java.lang.String, java.lang.Object> selectUserResourceAction(java.lang.Long, java.lang.String);
    private java.lang.Long getTimeStamp(java.lang.String);
    java.util.Set<java.lang.String> selectUserMenuUrlActioin(java.lang.Long, java.lang.String);
    java.util.Map<java.lang.String, java.lang.Object> selectUserOrgAdminAppResourceAction(java.lang.Long, java.lang.Long, java.lang.String);
    java.util.Set<java.lang.String> selectUserMenuUrl(java.lang.Long, java.lang.String);
    java.util.List<java.lang.String> selectAppAdminRoleCode(java.lang.String);
    java.util.List<java.lang.String> checkPublicAccessResource(java.lang.String);
    boolean checkResourcePermission(java.lang.String, java.lang.String, java.util.Map<java.lang.String, java.lang.Object>);
    java.lang.Long getCloudId();
    java.lang.Boolean isTenantRootOrgAdmin(java.lang.Long);
    java.lang.Long getInstitutionByOrgId(java.lang.Long);
    private java.util.Map<java.lang.String, java.lang.Object> getOrgInfoById(java.lang.Long);
```

### `DataPermissionCheckService`（7 方法）

`com.seeyon.boot.starter.security.service.DataPermissionCheckService`

```java
    java.util.List<java.util.Map<java.lang.String, java.lang.String>> check(java.lang.String);
    private java.lang.String getAppName();
    java.lang.String processDataRule(java.lang.String, java.lang.String);
    private java.util.List<java.lang.String> checkColumnExist(java.lang.String, java.lang.String);
    private java.util.List<java.lang.String> filterExistColumnNames(java.lang.String, java.util.List<java.lang.String>, java.util.List<java.lang.String>);
    private java.util.List<java.lang.String> filterFields(java.lang.reflect.Field[], java.util.List<java.lang.String>);
    private java.lang.Boolean checkPermissionExit(java.lang.String);
```

### `SecurityResourcePermissionService`（5 方法）

`com.seeyon.boot.starter.security.SecurityResourcePermissionService`

```java
    boolean checkResourcePermission(java.lang.String, java.lang.Long, java.lang.String, java.lang.String, java.lang.String, java.lang.String, javax.servlet.http.HttpServletRequest);
    boolean checkResourcePermission(java.lang.Long, java.lang.String, java.lang.Long, java.lang.String, java.lang.String, java.lang.String, java.lang.String, javax.servlet.http.HttpServletRequest);
    private com.seeyon.ctp.user.spi.SecurityCheckServiceSpi getSecurityService();
    private com.seeyon.boot.exception.BusinessException handlerException();
    private void saveAuditLog(javax.servlet.http.HttpServletRequest, java.lang.String, java.lang.String, java.lang.String);
```

### `SecretService`（4 方法）

`com.seeyon.boot.starter.security.service.SecretService`

```java
    java.lang.Boolean checkSecret(java.lang.String, java.util.List, java.util.List);
    java.lang.Boolean secretEnable();
    java.util.Map<java.lang.Long, java.lang.Integer> selectSystemSecretMap();
    private java.lang.Integer getSecretNoById(java.lang.Long);
```
