# cip-openapi-common：接口与方法签名

> 自动生成，勿手改。`tools/core/platform/emit_package_surfaces.py` 重跑即可。
> 构件 `com.seeyon:cip-openapi-common`（jar `cip-openapi-common-5.3.260.jar`）
> 规模：21 类 / 1 接口 / 0 注解 / 1 枚举 / 1 个关键类 / 134 方法。
> 签名逐字来自 javap 原文；已去掉 `public` 前缀与 `throws` 子句。

## 一、接口（1）

### `ApiConstants`（0 方法）

`com.seeyon.cip.openapi.common.constant.ApiConstants`

```java
```

## 二、关键类（1）

### `OpenApiUtil`（11 方法）

`com.seeyon.cip.openapi.common.utils.OpenApiUtil`

```java
    static <T> T fromJson(java.lang.String, java.lang.Class<T>);
    static java.lang.String getBody(java.lang.Object);
    static java.util.Map<java.lang.String, java.lang.String> beanToMap(java.lang.Object);
    static private static java.util.Map<java.lang.String, java.lang.String> objToMap(java.lang.Object)
    static private static boolean isPrimitive(java.lang.Object);
    static java.lang.String getBodyBak(java.lang.Object);
    static java.lang.String doSign(java.lang.String, java.lang.String)
    static byte[] encryptHMAC(java.lang.String, java.lang.String)
    static byte[] encryptMd5(java.lang.String)
    static byte[] encryptMd5(byte[]);
    static java.lang.String byte2hex(byte[]);
```

## 四、枚举（1）

- `SignTypeEnum`（2 常量）：MD5, SHA256HEX
