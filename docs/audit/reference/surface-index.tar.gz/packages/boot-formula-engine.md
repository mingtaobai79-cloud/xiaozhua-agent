# boot-formula-engine：接口与方法签名

> 自动生成，勿手改。`tools/core/platform/emit_package_surfaces.py` 重跑即可。
> 构件 `com.seeyon:boot-formula-engine`（jar `boot-formula-engine-5.3.603.jar`）
> 规模：41 类 / 2 接口 / 6 注解 / 6 枚举 / 5 个关键类 / 384 方法。
> 签名逐字来自 javap 原文；已去掉 `public` 前缀与 `throws` 子句。

## 一、接口（2）

### `Caller`（3 方法）

`com.seeyon.boot.starter.formula.engine.extension.Caller`

```java
    java.lang.Object call(java.lang.Object[]);
    java.lang.Object callWithType(java.lang.Object[], java.lang.String, java.lang.String);
    java.lang.String getOperator();
```

### `FormulaDao`（0 方法） extends CtpFormula>

`com.seeyon.boot.starter.formula.domain.dao.FormulaDao`

```java
```

## 二、关键类（5）

### `FormulaService`（16 方法）

`com.seeyon.boot.starter.formula.domain.service.FormulaService`

```java
    com.seeyon.boot.starter.formula.dto.FormulaOpResultDto validate(com.seeyon.boot.starter.formula.dto.FormulaDto);
    java.util.List<com.seeyon.boot.starter.formula.enums.FormulaFunctionCategoryEnum> getFormulaCategoryList();
    java.util.List<com.seeyon.boot.starter.formula.enums.FormulaDataTypeEnum> getFormulaDateTypeList();
    com.seeyon.boot.starter.formula.dto.FormulaOpResultDto create(com.seeyon.boot.starter.formula.dto.FormulaDto);
    private void addFunction(com.seeyon.boot.starter.formula.dto.FormulaDto);
    private void removeFunction(java.lang.String);
    com.seeyon.boot.starter.formula.engine.dto.FunctionDto formula2function(com.seeyon.boot.starter.formula.dto.FormulaDto);
    com.seeyon.boot.starter.formula.dto.FormulaOpResultDto update(com.seeyon.boot.starter.formula.dto.FormulaDto);
    com.seeyon.boot.starter.formula.dto.FormulaDto selectById(java.lang.Long);
    java.util.List<com.seeyon.boot.starter.formula.dto.FormulaDto> selectByIds(java.util.List<java.lang.Long>);
    com.seeyon.boot.transport.PageData<com.seeyon.boot.starter.formula.dto.FormulaDto> selectPageByCondition(com.seeyon.boot.transport.PageInfo, java.util.Map<java.lang.String, java.lang.Object>, com.seeyon.boot.transport.Sort);
    boolean exists(java.lang.String);
    com.seeyon.boot.starter.formula.dto.FormulaDto selectByName(java.lang.String);
    int deleteById(java.lang.Long);
    int deleteByIds(java.util.List<java.lang.Long>);
    java.util.List<com.seeyon.boot.starter.formula.dto.GrammarDto> getGrammarList();
```

### `FormulaAppService`（12 方法）

`com.seeyon.boot.starter.formula.appservice.FormulaAppService`

```java
    com.seeyon.boot.transport.SingleResponse<com.seeyon.boot.starter.formula.dto.FormulaOpResultDto> validate(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.formula.dto.FormulaDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.boot.starter.formula.dto.FormulaOpResultDto> create(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.formula.dto.FormulaDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.boot.starter.formula.dto.FormulaOpResultDto> update(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.formula.dto.FormulaDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> deleteById(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> deleteByIds(com.seeyon.boot.transport.SingleRequest<java.util.List<java.lang.Long>>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.boot.starter.formula.enums.FormulaFunctionCategoryEnum> getFormulaCategoryList();
    com.seeyon.boot.transport.ListResponse<com.seeyon.boot.starter.formula.enums.FormulaDataTypeEnum> getFormulaDateTypeList();
    com.seeyon.boot.transport.SingleResponse<java.lang.Boolean> exists(com.seeyon.boot.transport.SingleRequest<java.lang.String>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.boot.starter.formula.dto.FormulaDto> selectById(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.boot.starter.formula.dto.FormulaDto> selectByIds(com.seeyon.boot.transport.SingleRequest<java.util.List<java.lang.Long>>);
    com.seeyon.boot.transport.PageResponse<com.seeyon.boot.starter.formula.dto.FormulaDto> selectPageByCondition(com.seeyon.boot.transport.PageRequest);
    com.seeyon.boot.transport.ListResponse<com.seeyon.boot.starter.formula.dto.GrammarDto> getGrammarList();
```

### `FormulaResultTypeUtil`（6 方法）

`com.seeyon.boot.starter.formula.engine.utils.FormulaResultTypeUtil`

```java
    static boolean isInteger(java.lang.String);
    static boolean isFloat(java.lang.String);
    static java.lang.Object dataTypeTransfer(java.lang.Object, java.lang.String);
    static private static boolean isNull2Long(java.lang.Object, java.lang.String);
    static private static java.lang.String getResultTypeCaption(java.lang.Object);
```

### `ExpressionEncryptUtil`（6 方法）

`com.seeyon.boot.starter.formula.util.ExpressionEncryptUtil`

```java
    static java.lang.String encrypt(java.lang.String);
    static java.lang.String decrypt(java.lang.String);
    static java.lang.String AESEncrypt(java.lang.String);
    static java.lang.String AESDecrypt(java.lang.String, boolean);
    static java.lang.String decryptAlwaysSuccess(java.lang.String);
    static boolean isBase64Encoded(java.lang.String);
```

### `AggUtils`（3 方法）

`com.seeyon.boot.starter.formula.engine.utils.AggUtils`

```java
    static java.lang.Object[] getFieldValues(java.util.List, java.lang.String);
    static private static java.lang.ClassLoader getDefaultClassLoader();
    static private static java.lang.String getterName(java.lang.String);
```

## 三、注解（6）

| 注解 | 元素 |
|---|---|
| `Function` | category, displayName, description, sort, hidden, terminalSupport |
| `FunctionClass` |  |
| `ParamLinkage` | isLinkage, linkageIndex |
| `Parameter` | displayName, description, dataType |
| `Parameters` | value |
| `ReturnValue` | dataType, description, appName, fullName |

## 四、枚举（6）

- `ChangeFunctionParamStateEnum`（2 常量）：OLD, NEW
- `ControlTypeEnum`（7 常量）：REFERENCE, DYNAMIC_SELECTOR, CTP_ENUM, ENUM, DATE, DATE_TIME, TIME
- `TerminalSupportTypeEnum`（3 常量）：ALL, FRONTEND, BACKEND
- `ValidateErrorType`（4 常量）：SYNTAX_ERROR, FUNCTION_EXIST_ERROR, FUNCTION_PARAMETER_ERROR, FUNCTION_RUNTIME_ERROR
- `FormulaDataTypeEnum`（11 常量）：None, String, Integer, BigInteger, Decimal, Boolean, DateTime, Date, Time, Object, Array
- `FormulaFunctionCategoryEnum`（11 常量）：BASIC, SYSTEM, DATE, MATH, TEXT, AGG, CONDITION, BIZ, LIST, CHANGE, ENUM
