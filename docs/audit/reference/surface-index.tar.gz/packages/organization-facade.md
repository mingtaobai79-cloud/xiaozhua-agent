# organization-facade：接口与方法签名

> 自动生成，勿手改。`tools/core/platform/emit_package_surfaces.py` 重跑即可。
> 构件 `com.seeyon:organization-facade`（jar `organization-facade-5.3.601.jar`）
> 规模：414 类 / 54 接口 / 1 注解 / 64 枚举 / 3 个关键类 / 6409 方法。
> 签名逐字来自 javap 原文；已去掉 `public` 前缀与 `throws` 子句。

## 一、接口（54）

### `OrgCommonAppService`（45 方法）

`com.seeyon.organization.api.common.OrgCommonAppService`

```java
    com.seeyon.boot.transport.SingleResponse<java.util.Map<java.lang.String, java.lang.Object>> selectMemberInfoById(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.SingleResponse<java.util.Map<java.lang.Long, java.util.Map<java.lang.String, java.util.List>>> selectMemberDepartmentInfoById(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    default com.seeyon.boot.transport.SingleResponse<java.util.Map<java.lang.String, java.lang.Object>> selectMemberMultiDimOrgInfo(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    default com.seeyon.boot.transport.SingleResponse<java.util.Map<java.lang.Long, java.util.Map<java.lang.String, java.util.List>>> selectMemberInstitutionInfoById(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.organization.dto.core.OrgMemberCoreDto> selectMemberBySelectPeopleData(com.seeyon.boot.transport.SingleRequest<java.util.List<com.seeyon.organization.dto.common.SelectPeopleDataDto>>);
    com.seeyon.boot.transport.PageResponse<com.seeyon.organization.dto.core.OrgMemberCoreDto> selectPageMemberBySelectPeopleData(com.seeyon.boot.transport.PageDtoRequest<java.util.List<com.seeyon.organization.dto.common.SelectPeopleDataDto>>);
    default com.seeyon.boot.transport.PageResponse<java.lang.Long> selectPageMemberBySelectPeopleIdData(com.seeyon.boot.transport.PageDtoRequest<java.util.List<com.seeyon.organization.dto.common.SelectPeopleDataDto>>);
    com.seeyon.boot.transport.ListResponse<java.util.List<com.seeyon.organization.dto.core.OrgMemberCoreDto>> selectMemberBySelectPeopleDatas(com.seeyon.boot.transport.SingleRequest<java.util.List<java.util.List<com.seeyon.organization.dto.common.SelectPeopleDataDto>>>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.organization.dto.core.OrgMemberCoreDto> selectMemberBySelectPeopleDataJson(com.seeyon.boot.transport.SingleRequest<java.lang.String>);
    com.seeyon.boot.transport.PageResponse<com.seeyon.organization.dto.core.OrgMemberCoreDto> selectPageMemberBySelectPeopleDataJson(com.seeyon.boot.transport.PageDtoRequest<java.lang.String>);
    default com.seeyon.boot.transport.PageResponse<java.lang.Long> selectPageMemberBySelectPeopleIdDataJson(com.seeyon.boot.transport.PageDtoRequest<java.lang.String>);
    com.seeyon.boot.transport.ListResponse<java.util.List<com.seeyon.organization.dto.core.OrgMemberCoreDto>> selectMemberBySelectPeopleDataJsons(com.seeyon.boot.transport.SingleRequest<java.util.List<java.lang.String>>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Boolean> isMemberInSelectPeopleDataJson(com.seeyon.boot.transport.SingleRequest<com.seeyon.organization.dto.common.MemberInSelectPeopleDataDto>);
    com.seeyon.boot.transport.ListResponse<java.lang.Long> selectMemberByOrgId(com.seeyon.boot.transport.SingleRequest<java.util.Map<java.lang.String, java.lang.Object>>);
    com.seeyon.boot.transport.PageResponse<java.lang.Long> selectPageMemberByOrgId(com.seeyon.boot.transport.PageRequest);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> selectMemberCountByOrgId(com.seeyon.boot.transport.SingleRequest<java.util.Map<java.lang.String, java.lang.Object>>);
    com.seeyon.boot.transport.ListResponse<java.lang.Long> selectMemberByPostId(com.seeyon.boot.transport.SingleRequest<java.util.Map<java.lang.String, java.lang.Object>>);
    com.seeyon.boot.transport.ListResponse<java.lang.Long> selectMemberByJobId(com.seeyon.boot.transport.SingleRequest<java.util.Map<java.lang.String, java.lang.Object>>);
    com.seeyon.boot.transport.ListResponse<java.lang.Long> selectMemberByLevelId(com.seeyon.boot.transport.SingleRequest<java.util.Map<java.lang.String, java.lang.Object>>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.organization.dto.core.OrgMemberCoreDto> selectMemberByUserId(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.ListResponse<java.lang.Long> selectChildrenOrgIdByCondition(com.seeyon.boot.transport.SingleRequest<java.util.Map<java.lang.String, java.lang.Object>>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.organization.dto.core.OrgUnitCoreDto> selectChildrenOrgByCondition(com.seeyon.boot.transport.SingleRequest<java.util.Map<java.lang.String, java.lang.Object>>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.organization.dto.core.OrgMetadataColumnCoreDto> selectOrgMetadataColumnList(com.seeyon.boot.transport.SingleRequest<com.seeyon.organization.dto.common.SelectMetadataDto>);
    com.seeyon.boot.transport.ListResponse<java.lang.Long> selectParentIds(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.organization.dto.core.OrgUnitCoreDto> selectRoot();
    com.seeyon.boot.transport.ListResponse<com.seeyon.organization.dto.common.OrgUnitTeamInfoDto> selectOrgUnitTeamList(com.seeyon.boot.transport.SingleRequest<com.seeyon.organization.dto.common.SearchUnitTeamDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Boolean> isRole(com.seeyon.boot.transport.SingleRequest<java.util.Map<java.lang.String, java.lang.Object>>);
    com.seeyon.boot.transport.SingleResponse<java.util.List<java.lang.Long>> selectMemberOfUnitMetadataOfMemberId(com.seeyon.boot.transport.SingleRequest<java.util.Map<java.lang.String, java.lang.Object>>);
    com.seeyon.boot.transport.ListResponse<java.lang.Long> selectManagerDepartmentByMemberId(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.ListResponse<java.lang.Long> selectLeaderDepartmentByMemberId(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.SingleResponse<java.util.List<java.lang.Long>> selectAllDomainIdsByMemberId(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.SingleResponse<java.util.List<java.lang.Long>> selectDomainIdsByMemberId(com.seeyon.boot.transport.SingleRequest<com.seeyon.organization.dto.domainid.OrgDomainIdDto>);
    com.seeyon.boot.transport.SingleResponse<java.util.Map<com.seeyon.organization.enums.domainid.OrgDomainTypeEnum, java.util.Set<java.lang.Long>>> selectDomainMapByMemberId(com.seeyon.boot.transport.SingleRequest<com.seeyon.organization.dto.domainid.OrgDomainIdDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.String> fillSelectPeopleData(com.seeyon.boot.transport.SingleRequest<java.lang.String>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Boolean> canManage(com.seeyon.boot.transport.SingleRequest<com.seeyon.organization.dto.common.OrgMemberManagePermissionDto>);
    com.seeyon.boot.transport.SingleResponse<java.util.List<java.lang.Long>> selectSecretMemberIds(com.seeyon.boot.transport.SingleRequest<com.seeyon.organization.dto.common.SelectSecretMemberDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.organization.dto.common.OrgManageOrgDto> selectManageOrgByRole(com.seeyon.boot.transport.SingleRequest<com.seeyon.organization.dto.common.SelectManageOrgDto>);
    com.seeyon.boot.transport.SingleResponse<java.util.List<java.lang.Long>> selectInOrgScopeIds(com.seeyon.boot.transport.SingleRequest<com.seeyon.organization.dto.common.OrgInScopeDataDto>);
    com.seeyon.boot.transport.SingleResponse<java.util.List<com.seeyon.organization.dto.common.OrgEntitySearchResultDto>> selectEntityIdByCode(com.seeyon.boot.transport.SingleRequest<java.util.List<com.seeyon.organization.dto.common.OrgEntitySearchDto>>);
    default com.seeyon.boot.transport.SingleResponse<java.util.List<com.seeyon.organization.dto.common.ScopeTypeNameDto>> selectScopeTypeName(com.seeyon.boot.transport.SingleRequest<java.util.List<com.seeyon.organization.dto.common.SelectScopeTypeNameDto>>);
    default com.seeyon.boot.transport.ListResponse<com.seeyon.organization.dto.common.OrgSensitiveFieldPermissionDto> selectSensitiveFieldInfo(com.seeyon.boot.transport.SingleRequest<com.seeyon.organization.dto.common.SelectSensitiveFieldPermissionDto>);
    default com.seeyon.boot.transport.ListResponse<com.seeyon.organization.dto.common.OrgSensitiveFileMemberDto> selectSensitiveFieldMember(com.seeyon.boot.transport.SingleRequest<com.seeyon.organization.dto.common.SelectSensitiveFileMemberDto>);
    default com.seeyon.boot.transport.SingleResponse<java.util.Map<java.lang.String, java.lang.Object>> selectMemberExtendInfoById(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    default com.seeyon.boot.transport.SingleResponse<java.lang.String> selectNameBySelectPeopleData(com.seeyon.boot.transport.SingleRequest<java.lang.String>);
    default com.seeyon.boot.transport.SingleResponse<java.lang.Boolean> containsAny(com.seeyon.boot.transport.SingleRequest<com.seeyon.organization.dto.common.SelectPeopleContainsAnyDto>);
```

### `OrgWorkFlowAppService`（37 方法）

`com.seeyon.organization.api.app.workflow.OrgWorkFlowAppService`

```java
    com.seeyon.boot.transport.SingleResponse<com.seeyon.organization.dto.api.app.workflow.WorkFlowMatchResponseDto> selectMemberPostBySelectPeople(com.seeyon.boot.transport.SingleRequest<com.seeyon.organization.dto.api.app.workflow.WorkFlowMatchRequestDto>);
    com.seeyon.boot.transport.SingleResponse<java.util.Map<java.lang.Long, java.util.List<com.seeyon.organization.dto.api.app.workflow.WorkFlowMatchResponseDto>>> selectMemberPostBySelectPeoples(com.seeyon.boot.transport.SingleRequest<java.util.Map<java.lang.Long, java.util.List<com.seeyon.organization.dto.api.app.workflow.WorkFlowMatchRequestDto>>>);
    default com.seeyon.boot.transport.SingleResponse<com.seeyon.organization.dto.api.app.workflow.WorkFlowMatchResponseToFileDto> selectMemberPostBySelectPeoplesReturnFile(com.seeyon.boot.transport.SingleRequest<com.seeyon.organization.dto.api.app.workflow.WorkFlowMatchRequestCustomModeDto>);
    default com.seeyon.boot.transport.SingleResponse<java.util.Map<java.lang.Long, com.seeyon.organization.dto.api.app.workflow.WorkFlowMatchResponseFileKeyDto>> selectReturnFileByKey(com.seeyon.boot.transport.SingleRequest<com.seeyon.organization.dto.api.app.workflow.WorkFlowSelectStorageKeyRequestDto>);
    default com.seeyon.boot.transport.SingleResponse<java.lang.Boolean> deleteReturnFileByKey(com.seeyon.boot.transport.SingleRequest<com.seeyon.organization.dto.api.app.workflow.WorkFlowSelectStorageKeyRequestDto>);
    com.seeyon.boot.transport.ListResponse<java.lang.Long> selectListByCondition(com.seeyon.boot.transport.SingleRequest<com.seeyon.organization.dto.api.app.workflow.WorkFlowConditionMatchRequestDto>);
    com.seeyon.boot.transport.SingleResponse<java.util.Map<java.lang.String, java.util.List<java.lang.Object>>> selectListByMetaCondition(com.seeyon.boot.transport.SingleRequest<java.util.List<com.seeyon.organization.dto.api.app.workflow.WorkFlowConditionMetaMatchRequestDto>>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Boolean> isOfUp(com.seeyon.boot.transport.SingleRequest<com.seeyon.organization.dto.api.app.workflow.SelectPeopleDataWfDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.organization.dto.api.app.workflow.WorkFlowOfUpDto> selectOfUp(com.seeyon.boot.transport.SingleRequest<com.seeyon.organization.dto.api.app.workflow.SelectPeopleDataWfDto>);
    com.seeyon.boot.transport.ListResponse<java.lang.String> selectPreParameterKey(com.seeyon.boot.transport.SingleRequest<java.util.List<com.seeyon.organization.dto.api.app.workflow.SelectPeopleDataWfDto>>);
    com.seeyon.boot.transport.SingleResponse<java.util.Map<java.lang.String, java.util.List<java.lang.Long>>> selectMemberOfUnitMetadataOfMemberIds(com.seeyon.boot.transport.SingleRequest<java.util.Map<java.lang.String, com.seeyon.organization.dto.api.app.workflow.SuperviseConditionDto>>);
    com.seeyon.boot.transport.SingleResponse<java.util.Map<java.lang.String, java.util.List<java.lang.Long>>> selectMemberOfMemberMetadataOfMemberIds(com.seeyon.boot.transport.SingleRequest<java.util.Map<java.lang.String, com.seeyon.organization.dto.api.app.workflow.SuperviseConditionDto>>);
    com.seeyon.boot.transport.SingleResponse<java.util.List<java.lang.String>> selectMetadataListOfUnitMetadataOfMemberId(com.seeyon.boot.transport.SingleRequest<com.seeyon.organization.dto.api.app.workflow.SuperviseMetadataConditionDto>);
    com.seeyon.boot.transport.SingleResponse<java.util.List<java.lang.String>> selectMetadataListOfMemberMetadataOfMemberId(com.seeyon.boot.transport.SingleRequest<com.seeyon.organization.dto.api.app.workflow.SuperviseMetadataConditionDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Boolean> funcMemberIn(com.seeyon.boot.transport.SingleRequest<com.seeyon.organization.dto.api.app.workflow.FunctionInDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Boolean> funcOrgIn(com.seeyon.boot.transport.SingleRequest<com.seeyon.organization.dto.api.app.workflow.FunctionInDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Boolean> funcMultMemberIn(com.seeyon.boot.transport.SingleRequest<com.seeyon.organization.dto.api.app.workflow.FunctionInDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Boolean> funcMultOrgIn(com.seeyon.boot.transport.SingleRequest<com.seeyon.organization.dto.api.app.workflow.FunctionInDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Boolean> funcOrgRoleIn(com.seeyon.boot.transport.SingleRequest<com.seeyon.organization.dto.api.app.workflow.FunctionOrgRoleInDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.organization.dto.api.app.workflow.OrgMemberPostWfDto> selectMemberPostById(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.organization.dto.common.SelectPeopleDataDto> getSelectPeopleDataWfJson(com.seeyon.boot.transport.SingleRequest<java.util.List<com.seeyon.organization.dto.api.app.workflow.WorkFlowDataTestRequestDto>>);
    com.seeyon.boot.transport.SingleResponse<java.util.List<com.seeyon.organization.dto.api.app.workflow.WorkFlowSplitUnitNodeResponseDto>> selectSplitUnitNodeInfo(com.seeyon.boot.transport.SingleRequest<com.seeyon.organization.dto.api.app.workflow.WorkFlowMatchRequestDto>);
    com.seeyon.boot.transport.SingleResponse<java.util.List<com.seeyon.organization.dto.api.app.workflow.WorkFlowSplitMemberNodeResponseDto>> selectSplitMemberNodeInfo(com.seeyon.boot.transport.SingleRequest<com.seeyon.organization.dto.api.app.workflow.WorkFlowSplitMemberNodeRequestDto>);
    com.seeyon.boot.transport.SingleResponse<java.util.Map<java.lang.String, java.lang.String>> selectNodeName(com.seeyon.boot.transport.SingleRequest<java.util.List<java.lang.String>>);
    com.seeyon.boot.transport.SingleResponse<java.util.Map<java.lang.Long, java.lang.String>> selectNamesByIds(com.seeyon.boot.transport.SingleRequest<com.seeyon.organization.dto.api.app.workflow.SearchNameDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.String> getEntityNameBySelectPeoples(com.seeyon.boot.transport.SingleRequest<java.util.List<com.seeyon.organization.dto.common.SelectPeopleDataDto>>);
    com.seeyon.boot.transport.SingleResponse<java.util.List<com.seeyon.organization.dto.api.app.workflow.SelectPeopleCodeDataDto>> selectPeopleCodeDataDto(com.seeyon.boot.transport.SingleRequest<java.util.List<com.seeyon.organization.dto.common.SelectPeopleDataDto>>);
    com.seeyon.boot.transport.SingleResponse<java.util.Map<java.lang.Long, java.util.List<com.seeyon.organization.dto.common.SelectPeopleDataDto>>> selectPeopleDataDtoFromTransData(com.seeyon.boot.transport.SingleRequest<com.seeyon.organization.dto.api.app.workflow.SelectPeopleTransDataDto>);
    com.seeyon.boot.transport.SingleResponse<java.util.List<com.seeyon.organization.dto.api.app.workflow.SelectPeopleCodeDataDto>> selectPeopleIdsCodeData(com.seeyon.boot.transport.SingleRequest<com.seeyon.organization.dto.api.app.workflow.SelectPeopleIdsTransDataDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.organization.dto.api.app.workflow.SelectPeopleIdsTransNewMapDto> selectPeopleIdsDataDtoFromTransData(com.seeyon.boot.transport.SingleRequest<java.util.List<com.seeyon.organization.dto.api.app.workflow.SelectPeopleCodeDataDto>>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.organization.dto.api.app.workflow.SelectPeopleDataValidDto> checkSelectPeopleData(com.seeyon.boot.transport.SingleRequest<java.util.List<com.seeyon.organization.dto.common.SelectPeopleDataDto>>);
    com.seeyon.boot.transport.SingleResponse<java.lang.String> selectSortField(com.seeyon.boot.transport.SingleRequest<com.seeyon.organization.dto.api.app.workflow.WorkFlowSortRequestDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.organization.dto.api.app.workflow.OrgMemberPostIdentityDto> selectMemberPostListByCondition(com.seeyon.boot.transport.SingleRequest<java.util.Map<java.lang.String, java.lang.Object>>);
    default com.seeyon.boot.transport.SingleResponse<java.util.List<com.seeyon.organization.dto.api.app.workflow.OrgAboutIdDataDto>> selectOrgSameTypeChildList(com.seeyon.boot.transport.SingleRequest<java.util.List<java.lang.Long>>);
    default com.seeyon.boot.transport.SingleResponse<com.seeyon.organization.dto.api.app.workflow.SupervisorMultipleDataDto> selectSupervisorMultipleData(com.seeyon.boot.transport.SingleRequest<com.seeyon.organization.dto.api.app.workflow.SupervisorMultipleParams>);
    default com.seeyon.boot.transport.SingleResponse<com.seeyon.organization.dto.api.app.workflow.UserRoleAuthAndManageDataDto> selectUserRoleAuthAndManageData(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    default com.seeyon.boot.transport.SingleResponse<java.util.Map<java.lang.Long, java.util.Map<java.lang.String, java.lang.Object>>> selectFirstLevelDepartmentInfoByIds(com.seeyon.boot.transport.SingleRequest<java.util.List<java.lang.Long>>);
```

### `OrgUnitBaseAppService`（20 方法）

`com.seeyon.organization.api.core.unit.OrgUnitBaseAppService`

```java
    com.seeyon.boot.transport.SingleResponse<java.lang.Long> create(com.seeyon.boot.transport.SingleRequest<com.seeyon.organization.dto.core.base.OrgCreateUnitBaseDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> update(com.seeyon.boot.transport.SingleRequest<com.seeyon.organization.dto.core.base.OrgUpdateUnitBaseDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.organization.dto.core.response.OrgUnitDto> selectById(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.organization.dto.core.response.OrgUnitDto> selectByIds(com.seeyon.boot.transport.SingleRequest<java.util.List<java.lang.Long>>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.organization.dto.core.OrgUnitCoreDto> selectOrgById(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.organization.dto.core.OrgUnitCoreDto> selectOrgByIds(com.seeyon.boot.transport.SingleRequest<java.util.List<java.lang.Long>>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.organization.dto.core.response.OrgUnitDto> selectCascadeById(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.organization.dto.core.response.OrgUnitDto> selectCascadeByIds(com.seeyon.boot.transport.SingleRequest<java.util.List<java.lang.Long>>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.organization.dto.core.response.OrgUnitDto> selectListByConditions(com.seeyon.boot.transport.ListRequest);
    com.seeyon.boot.transport.ListResponse<com.seeyon.organization.dto.core.OrgUnitCoreDto> selectOrgListByCondition(com.seeyon.boot.transport.ListRequest);
    com.seeyon.boot.transport.PageResponse<com.seeyon.organization.dto.core.response.OrgUnitDto> selectPageByConditions(com.seeyon.boot.transport.PageRequest);
    com.seeyon.boot.transport.PageResponse<com.seeyon.organization.dto.core.OrgUnitCoreDto> selectOrgPageListByCondition(com.seeyon.boot.transport.PageRequest);
    com.seeyon.boot.transport.ListResponse<java.util.Map<java.lang.String, java.lang.Object>> selectOrgListPropertiesByOrgIds(com.seeyon.boot.transport.SingleRequest<com.seeyon.organization.dto.core.SimpleConditionByIdsDto>);
    com.seeyon.boot.transport.PageResponse<java.util.Map<java.lang.String, java.lang.Object>> selectOrgPageListPropertiesByCondition(com.seeyon.boot.transport.PageDtoRequest<com.seeyon.organization.dto.core.SimpleConditionByParamsDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.organization.dto.core.response.OrgUnitDto> selectLegalByMemberId(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.ListResponse<java.lang.Long> selectLegalIdByMemberId(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.PageResponse<com.seeyon.organization.dto.core.response.OrgUnitDto> dynamicJoinSelect(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.dynamicsql.dto.ProxyJoinParamDto>);
    com.seeyon.boot.transport.PageResponse<com.seeyon.organization.dto.core.response.OrgUnitDto> dynamicSelect(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.dynamicsql.dto.ProxyParamDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.organization.dto.core.response.OrgUnitDto> selectCascadeByConditions(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.dynamicsql.dto.QueryConditionDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.organization.dto.core.response.OrgUnitDto> selectCascadeListByConditions(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.dynamicsql.dto.QueryConditionDto>);
```

### `OrgMemberBaseAppService`（18 方法）

`com.seeyon.organization.api.core.member.OrgMemberBaseAppService`

```java
    com.seeyon.boot.transport.SingleResponse<java.lang.Long> create(com.seeyon.boot.transport.SingleRequest<com.seeyon.organization.dto.core.base.OrgCreateMemberBaseDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> update(com.seeyon.boot.transport.SingleRequest<com.seeyon.organization.dto.core.base.OrgUpdateMemberBaseDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.organization.dto.core.response.OrgMemberDto> selectById(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.organization.dto.core.response.OrgMemberDto> selectByIds(com.seeyon.boot.transport.SingleRequest<java.util.List<java.lang.Long>>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.organization.dto.core.response.OrgMemberDto> selectCascadeById(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.organization.dto.core.response.OrgMemberDto> selectCascadeByIds(com.seeyon.boot.transport.SingleRequest<java.util.List<java.lang.Long>>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.organization.dto.core.response.OrgMemberDto> selectListByConditions(com.seeyon.boot.transport.ListRequest);
    com.seeyon.boot.transport.ListResponse<com.seeyon.organization.dto.core.OrgMemberCoreDto> selectMemberListByCondition(com.seeyon.boot.transport.ListRequest);
    com.seeyon.boot.transport.PageResponse<com.seeyon.organization.dto.core.response.OrgMemberDto> selectPageByConditions(com.seeyon.boot.transport.PageRequest);
    com.seeyon.boot.transport.PageResponse<com.seeyon.organization.dto.core.OrgMemberCoreDto> selectMemberPageListByCondition(com.seeyon.boot.transport.PageRequest);
    com.seeyon.boot.transport.ListResponse<java.util.Map<java.lang.String, java.lang.Object>> selectMemberListPropertiesByMemberIds(com.seeyon.boot.transport.SingleRequest<com.seeyon.organization.dto.core.SimpleConditionByIdsDto>);
    com.seeyon.boot.transport.PageResponse<java.util.Map<java.lang.String, java.lang.Object>> selectMemberPageListPropertiesByCondition(com.seeyon.boot.transport.PageDtoRequest<com.seeyon.organization.dto.core.SimpleConditionByParamsDto>);
    com.seeyon.boot.transport.PageResponse<com.seeyon.organization.dto.core.response.OrgMemberDto> dynamicJoinSelect(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.dynamicsql.dto.ProxyJoinParamDto>);
    default com.seeyon.boot.transport.SingleResponse<java.lang.Integer> dynamicCountJoinSelect(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.dynamicsql.dto.ProxyJoinParamDto>);
    com.seeyon.boot.transport.PageResponse<com.seeyon.organization.dto.core.response.OrgMemberDto> dynamicSelect(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.dynamicsql.dto.ProxyParamDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.organization.dto.core.response.OrgMemberDto> selectCascadeByConditions(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.dynamicsql.dto.QueryConditionDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.organization.dto.core.response.OrgMemberDto> selectCascadeListByConditions(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.dynamicsql.dto.QueryConditionDto>);
    default com.seeyon.boot.transport.ListResponse<com.seeyon.organization.dto.common.OrgMemberInfoDto> selectInfoListByExtendCode(com.seeyon.boot.transport.SingleRequest<com.seeyon.organization.dto.core.OrgMemberConditionDto>);
```

### `OrgMetadataCoreAppService`（16 方法）

`com.seeyon.organization.api.core.metadata.OrgMetadataCoreAppService`

```java
    com.seeyon.boot.transport.ListResponse<com.seeyon.organization.dto.core.OrgMetadataColumnCoreDto> selectOrgMetadataColumnListByCondition(com.seeyon.boot.transport.SingleRequest<java.util.Map<java.lang.String, java.lang.Object>>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.organization.dto.core.OrgMetadataColumnCoreDto> selectMetadataColumnList(com.seeyon.boot.transport.SingleRequest<com.seeyon.organization.dto.core.SearchMetadataColumnDto>);
    com.seeyon.boot.transport.PageResponse<com.seeyon.organization.dto.core.OrgMetadataColumnCoreDto> selectPageMetadataColumnList(com.seeyon.boot.transport.PageRequest);
    com.seeyon.boot.transport.ListResponse<com.seeyon.organization.dto.core.OrgUnitCoreDto> selectOrgByUnitMemberMetadata(com.seeyon.boot.transport.SingleRequest<java.util.Map<java.lang.String, java.lang.Object>>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.organization.dto.core.OrgMemberCoreDto> selectMemberByUnitMetadata(com.seeyon.boot.transport.SingleRequest<java.util.Map<java.lang.String, java.lang.Object>>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.organization.dto.core.OrgMemberCoreDto> selectMemberByUnitMemberMetadata(com.seeyon.boot.transport.SingleRequest<java.util.Map<java.lang.String, java.lang.Object>>);
    com.seeyon.boot.transport.SingleResponse<java.util.Map<java.lang.String, java.lang.Object>> selectMemberMetadataInfo(com.seeyon.boot.transport.SingleRequest<com.seeyon.organization.dto.sync.search.SearchMemberMetadataDto>);
    com.seeyon.boot.transport.SingleResponse<java.util.Map<java.lang.String, java.lang.Object>> selectOrgMetadataInfo(com.seeyon.boot.transport.SingleRequest<com.seeyon.organization.dto.sync.search.SearchUnitMetadataDto>);
    default com.seeyon.boot.transport.SingleResponse<java.util.Map<java.lang.Long, java.util.Map<java.lang.String, java.lang.Object>>> selectOrgMetadataInfos(com.seeyon.boot.transport.SingleRequest<com.seeyon.organization.dto.sync.search.SearchUnitMetadatasDto>);
    com.seeyon.boot.transport.SingleResponse<java.util.Map<java.lang.String, java.lang.Boolean>> selectOrgRoleByMemberMetadata(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.SingleResponse<java.util.Map<java.lang.String, java.util.List<java.lang.Long>>> selectOrgIdByMemberIdInInstitution(com.seeyon.boot.transport.SingleRequest<com.seeyon.organization.dto.sync.search.SearchOrgIdMetadataInfoDto>);
    com.seeyon.boot.transport.SingleResponse<java.util.List<java.lang.Long>> selectEntityIdByMetadataValue(com.seeyon.boot.transport.SingleRequest<com.seeyon.organization.dto.sync.search.SearchEntityIdByMetadataValueDto>);
    default com.seeyon.boot.transport.PageResponse<java.lang.Long> selectEntityIdByMetadataValuePageList(com.seeyon.boot.transport.PageRequest);
    com.seeyon.boot.transport.ListResponse<java.lang.Long> selectEntityIdsByMetadataValue(com.seeyon.boot.transport.SingleRequest<com.seeyon.organization.dto.sync.search.SearchEntityIdByMetadataValueDto>);
    default com.seeyon.boot.transport.PageResponse<com.seeyon.organization.dto.core.response.OrgUnitMetadataValueDto> selectUnitMetadataPageList(com.seeyon.boot.transport.PageDtoRequest<com.seeyon.organization.dto.core.request.OrgUnitMetadataRequestDto>);
    default com.seeyon.boot.transport.PageResponse<com.seeyon.organization.dto.core.response.OrgMemberMetadataValueDto> selectMemberMetadataPageList(com.seeyon.boot.transport.PageDtoRequest<com.seeyon.organization.dto.core.request.OrgMemberMetadataRequestDto>);
```

### `OrgMemberSyncAppService`（14 方法）

`com.seeyon.organization.api.app.sync.OrgMemberSyncAppService`

```java
    com.seeyon.boot.transport.SingleResponse<com.seeyon.organization.dto.sync.OrgSyncInfoDto> createBatch(com.seeyon.boot.transport.SingleRequest<com.seeyon.organization.dto.sync.OrgBatchMemberDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.organization.dto.sync.OrgMemberDataDto> selectByCodes(com.seeyon.boot.transport.SingleRequest<com.seeyon.organization.dto.sync.search.SearchMemberConditionApiDto>);
    default com.seeyon.boot.transport.ListResponse<com.seeyon.organization.dto.sync.OrgMemberDataDto> selectByThirdIds(com.seeyon.boot.transport.SingleRequest<com.seeyon.organization.dto.sync.search.SearchMemberConditionApiDto>);
    com.seeyon.boot.transport.PageResponse<com.seeyon.organization.dto.sync.OrgMemberDataDto> selectByCondition(com.seeyon.boot.transport.PageDtoRequest<com.seeyon.organization.dto.sync.search.SearchMemberApiDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.organization.dto.sync.OrgSyncInfoDto> createBatchMemberPost(com.seeyon.boot.transport.SingleRequest<com.seeyon.organization.dto.sync.OrgBatchMemberPostDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.organization.dto.sync.OrgSyncInfoDto> createBatchMemberMetadata(com.seeyon.boot.transport.SingleRequest<com.seeyon.organization.dto.sync.OrgBatchMetadataDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.organization.dto.sync.OrgUserFixDto> fixCtpUserId(com.seeyon.boot.transport.SingleRequest<com.seeyon.organization.dto.sync.OrgUserFixDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> disableMember(com.seeyon.boot.transport.SingleRequest<java.lang.String>);
    default com.seeyon.boot.transport.SingleResponse<java.lang.Integer> disableMemberByThirdIds(com.seeyon.boot.transport.SingleRequest<java.lang.String>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.organization.dto.sync.OrgNaturalMemberDataDto> selectNaturalMemberByPhoneNumber(com.seeyon.boot.transport.SingleRequest<java.lang.String>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.organization.dto.sync.OrgNaturalMemberDataDto> selectNaturalMemberByCodes(com.seeyon.boot.transport.SingleRequest<com.seeyon.organization.dto.sync.search.SearchMemberConditionApiDto>);
    com.seeyon.boot.transport.PageResponse<com.seeyon.organization.dto.sync.OrgNaturalMemberDataDto> selectNaturalMemberInfoPageListByCondition(com.seeyon.boot.transport.PageDtoRequest<com.seeyon.organization.dto.sync.search.SearchMemberListApiDto>);
    com.seeyon.boot.transport.PageResponse<com.seeyon.organization.dto.sync.OrgOutsideUnitManagerDto> selectOutSideInstitutionManagerPageByCondition(com.seeyon.boot.transport.PageDtoRequest<com.seeyon.organization.dto.sync.search.SearchOutSideManagerApiDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.organization.dto.sync.OrgSyncInfoDto> createBatchNaturalMember(com.seeyon.boot.transport.SingleRequest<com.seeyon.organization.dto.sync.OrgBatchNaturalMemberDto>);
```

### `OrgZhongheService`（14 方法）

`com.seeyon.organization.api.app.third.zhonghe.OrgZhongheService`

```java
    default com.seeyon.boot.transport.ListResponse<com.seeyon.organization.dto.api.app.third.zhonghe.MemberRoleDto> selectMemberByRole(com.seeyon.boot.transport.SingleRequest<java.lang.String>);
    default com.seeyon.boot.transport.ListResponse<com.seeyon.organization.dto.api.app.third.zhonghe.SearchOrgResultDto> selectOrgByMetadataCustomizeZBBM(com.seeyon.boot.transport.SingleRequest<com.seeyon.organization.dto.api.app.third.zhonghe.SearchOrgDto>);
    default com.seeyon.boot.transport.ListResponse<com.seeyon.organization.dto.api.app.third.zhonghe.SearchOrgResultDto> selectOrgListByMetadata(com.seeyon.boot.transport.SingleRequest<com.seeyon.organization.dto.api.app.third.zhonghe.SearchOrgDto>);
    default com.seeyon.boot.transport.ListResponse<com.seeyon.organization.dto.api.app.third.zhonghe.SearchOrgResultDto> selectOrgTreeByMetadata(com.seeyon.boot.transport.SingleRequest<com.seeyon.organization.dto.api.app.third.zhonghe.SearchOrgDto>);
    default com.seeyon.boot.transport.SingleResponse<java.lang.String> selectEnumItemValueById(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    default com.seeyon.boot.transport.SingleResponse<java.util.Map<java.lang.Long, java.lang.String>> selectEnumItemValueByIds(com.seeyon.boot.transport.SingleRequest<java.util.List<java.lang.Long>>);
    default com.seeyon.boot.transport.SingleResponse<java.util.Map<java.lang.Long, java.util.List<java.lang.Long>>> selectLeadersBySecretary(com.seeyon.boot.transport.SingleRequest<java.util.List<java.lang.Long>>);
    default com.seeyon.boot.transport.ListResponse<com.seeyon.organization.dto.api.app.third.zhonghe.LeaderSecretaryDto> selectSecretaryListByLeaderId(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    default com.seeyon.boot.transport.ListResponse<com.seeyon.organization.dto.api.app.third.zhonghe.LeaderSecretaryDto> selectLeaderListBySecretaryId(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    default com.seeyon.boot.transport.ListResponse<com.seeyon.organization.dto.api.app.third.zhonghe.SearchOrgResultDto> selectOrgTreeReceiveDept(com.seeyon.boot.transport.SingleRequest<com.seeyon.organization.dto.api.app.third.zhonghe.SearchOrgDto>);
    default com.seeyon.boot.transport.ListResponse<com.seeyon.organization.dto.api.app.third.zhonghe.SearchOrgResultDto> selectRecOrgTree(com.seeyon.boot.transport.SingleRequest<java.util.List<java.lang.Long>>);
    default com.seeyon.boot.transport.ListResponse<com.seeyon.organization.dto.api.app.third.zhonghe.SearchOrgResultDto> getCurrentSectorOrgList(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    default com.seeyon.boot.transport.ListResponse<com.seeyon.organization.dto.api.app.third.zhonghe.SearchOrgResultDto> getOtherSectorOrgList(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    default com.seeyon.boot.transport.SingleResponse<java.lang.Integer> getOrgUnitTeamOrgCount(com.seeyon.boot.transport.SingleRequest<com.seeyon.organization.dto.api.app.third.zhonghe.OrgUnitTeamSearchDto>);
```

### `OrgJobBaseAppService`（14 方法）

`com.seeyon.organization.api.core.job.OrgJobBaseAppService`

```java
    com.seeyon.boot.transport.SingleResponse<java.lang.Long> create(com.seeyon.boot.transport.SingleRequest<com.seeyon.organization.dto.core.request.OrgJobRequestDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> update(com.seeyon.boot.transport.SingleRequest<com.seeyon.organization.dto.core.request.OrgJobRequestDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.organization.dto.core.response.OrgJobDto> selectById(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.organization.dto.core.response.OrgJobDto> selectByIds(com.seeyon.boot.transport.SingleRequest<java.util.List<java.lang.Long>>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.organization.dto.core.response.OrgJobDto> selectCascadeById(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.organization.dto.core.response.OrgJobDto> selectCascadeByIds(com.seeyon.boot.transport.SingleRequest<java.util.List<java.lang.Long>>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.organization.dto.core.response.OrgJobDto> selectListByConditions(com.seeyon.boot.transport.ListRequest);
    com.seeyon.boot.transport.PageResponse<com.seeyon.organization.dto.core.response.OrgJobDto> selectPageByConditions(com.seeyon.boot.transport.PageRequest);
    com.seeyon.boot.transport.ListResponse<java.util.Map<java.lang.String, java.lang.Object>> selectJobListPropertiesByJobIds(com.seeyon.boot.transport.SingleRequest<com.seeyon.organization.dto.core.SimpleConditionByIdsDto>);
    com.seeyon.boot.transport.PageResponse<java.util.Map<java.lang.String, java.lang.Object>> selectJobPageListPropertiesByCondition(com.seeyon.boot.transport.PageDtoRequest<com.seeyon.organization.dto.core.SimpleConditionByParamsDto>);
    com.seeyon.boot.transport.PageResponse<com.seeyon.organization.dto.core.response.OrgJobDto> dynamicJoinSelect(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.dynamicsql.dto.ProxyJoinParamDto>);
    com.seeyon.boot.transport.PageResponse<com.seeyon.organization.dto.core.response.OrgJobDto> dynamicSelect(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.dynamicsql.dto.ProxyParamDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.organization.dto.core.response.OrgJobDto> selectCascadeByConditions(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.dynamicsql.dto.QueryConditionDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.organization.dto.core.response.OrgJobDto> selectCascadeListByConditions(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.dynamicsql.dto.QueryConditionDto>);
```

### `OrgLevelBaseAppService`（14 方法）

`com.seeyon.organization.api.core.level.OrgLevelBaseAppService`

```java
    com.seeyon.boot.transport.SingleResponse<java.lang.Long> create(com.seeyon.boot.transport.SingleRequest<com.seeyon.organization.dto.core.request.OrgLevelRequestDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> update(com.seeyon.boot.transport.SingleRequest<com.seeyon.organization.dto.core.request.OrgLevelRequestDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.organization.dto.core.response.OrgLevelDto> selectById(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.organization.dto.core.response.OrgLevelDto> selectByIds(com.seeyon.boot.transport.SingleRequest<java.util.List<java.lang.Long>>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.organization.dto.core.response.OrgLevelDto> selectCascadeById(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.organization.dto.core.response.OrgLevelDto> selectCascadeByIds(com.seeyon.boot.transport.SingleRequest<java.util.List<java.lang.Long>>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.organization.dto.core.response.OrgLevelDto> selectListByConditions(com.seeyon.boot.transport.ListRequest);
    com.seeyon.boot.transport.PageResponse<com.seeyon.organization.dto.core.response.OrgLevelDto> selectPageByConditions(com.seeyon.boot.transport.PageRequest);
    com.seeyon.boot.transport.ListResponse<java.util.Map<java.lang.String, java.lang.Object>> selectLevelListPropertiesByLevelIds(com.seeyon.boot.transport.SingleRequest<com.seeyon.organization.dto.core.SimpleConditionByIdsDto>);
    com.seeyon.boot.transport.PageResponse<java.util.Map<java.lang.String, java.lang.Object>> selectLevelPageListPropertiesByCondition(com.seeyon.boot.transport.PageDtoRequest<com.seeyon.organization.dto.core.SimpleConditionByParamsDto>);
    com.seeyon.boot.transport.PageResponse<com.seeyon.organization.dto.core.response.OrgLevelDto> dynamicJoinSelect(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.dynamicsql.dto.ProxyJoinParamDto>);
    com.seeyon.boot.transport.PageResponse<com.seeyon.organization.dto.core.response.OrgLevelDto> dynamicSelect(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.dynamicsql.dto.ProxyParamDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.organization.dto.core.response.OrgLevelDto> selectCascadeByConditions(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.dynamicsql.dto.QueryConditionDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.organization.dto.core.response.OrgLevelDto> selectCascadeListByConditions(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.dynamicsql.dto.QueryConditionDto>);
```

### `OrgPostBaseAppService`（14 方法）

`com.seeyon.organization.api.core.post.OrgPostBaseAppService`

```java
    com.seeyon.boot.transport.SingleResponse<java.lang.Long> create(com.seeyon.boot.transport.SingleRequest<com.seeyon.organization.dto.core.request.OrgPostRequestDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> update(com.seeyon.boot.transport.SingleRequest<com.seeyon.organization.dto.core.request.OrgPostRequestDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.organization.dto.core.response.OrgPostDto> selectById(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.organization.dto.core.response.OrgPostDto> selectByIds(com.seeyon.boot.transport.SingleRequest<java.util.List<java.lang.Long>>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.organization.dto.core.response.OrgPostDto> selectCascadeById(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.organization.dto.core.response.OrgPostDto> selectCascadeByIds(com.seeyon.boot.transport.SingleRequest<java.util.List<java.lang.Long>>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.organization.dto.core.response.OrgPostDto> selectListByConditions(com.seeyon.boot.transport.ListRequest);
    com.seeyon.boot.transport.PageResponse<com.seeyon.organization.dto.core.response.OrgPostDto> selectPageByConditions(com.seeyon.boot.transport.PageRequest);
    com.seeyon.boot.transport.PageResponse<com.seeyon.organization.dto.core.response.OrgPostDto> dynamicSelect(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.dynamicsql.dto.ProxyParamDto>);
    com.seeyon.boot.transport.ListResponse<java.util.Map<java.lang.String, java.lang.Object>> selectPostListPropertiesByPostIds(com.seeyon.boot.transport.SingleRequest<com.seeyon.organization.dto.core.SimpleConditionByIdsDto>);
    com.seeyon.boot.transport.PageResponse<java.util.Map<java.lang.String, java.lang.Object>> selectPostPageListPropertiesByCondition(com.seeyon.boot.transport.PageDtoRequest<com.seeyon.organization.dto.core.SimpleConditionByParamsDto>);
    com.seeyon.boot.transport.PageResponse<com.seeyon.organization.dto.core.response.OrgPostDto> dynamicJoinSelect(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.dynamicsql.dto.ProxyJoinParamDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.organization.dto.core.response.OrgPostDto> selectCascadeByConditions(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.dynamicsql.dto.QueryConditionDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.organization.dto.core.response.OrgPostDto> selectCascadeListByConditions(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.dynamicsql.dto.QueryConditionDto>);
```

### `OrgMemberCoreAppService`（13 方法）

`com.seeyon.organization.api.core.member.OrgMemberCoreAppService`

```java
    com.seeyon.boot.transport.SingleResponse<com.seeyon.organization.dto.core.OrgMemberCoreDto> selectMemberById(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.organization.dto.common.OrgMemberInfoDto> selectMemberInfoById(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.organization.dto.core.OrgMemberCoreDto> selectMemberByIds(com.seeyon.boot.transport.SingleRequest<java.util.List<java.lang.Long>>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.organization.dto.core.OrgMemberCoreDto> selectMemberByIdsIgnoreTenantId(com.seeyon.boot.transport.SingleRequest<java.util.List<java.lang.Long>>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.organization.dto.common.OrgMemberInfoDto> selectMemberInfoByIds(com.seeyon.boot.transport.SingleRequest<java.util.List<java.lang.Long>>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.organization.dto.core.OrgMemberCoreDto> selectMemberListByCondition(com.seeyon.boot.transport.SingleRequest<java.util.Map<java.lang.String, java.lang.Object>>);
    com.seeyon.boot.transport.PageResponse<com.seeyon.organization.dto.core.OrgMemberCoreDto> selectMemberPageListByCondition(com.seeyon.boot.transport.PageRequest);
    com.seeyon.boot.transport.ListResponse<com.seeyon.organization.dto.common.OrgMemberInfoDto> selectMemberInfoListByCondition(com.seeyon.boot.transport.SingleRequest<java.util.Map<java.lang.String, java.lang.Object>>);
    com.seeyon.boot.transport.PageResponse<com.seeyon.organization.dto.common.OrgMemberInfoDto> selectMemberInfoPageListByCondition(com.seeyon.boot.transport.PageRequest);
    com.seeyon.boot.transport.ListResponse<java.util.Map<java.lang.String, java.lang.Object>> selectMemberByCodeIgnoreTenant(com.seeyon.boot.transport.SingleRequest<java.util.List<java.lang.String>>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> modifyMemberInfoBySelf(com.seeyon.boot.transport.SingleRequest<com.seeyon.organization.dto.core.base.OrgModifyMemberInfoSelfDto>);
    com.seeyon.boot.transport.ListResponse<java.util.Map<java.lang.String, java.lang.Object>> selectMemberListPropertiesByMemberIds(com.seeyon.boot.transport.SingleRequest<com.seeyon.organization.dto.core.SimpleConditionByIdsDto>);
    com.seeyon.boot.transport.PageResponse<java.util.Map<java.lang.String, java.lang.Object>> selectMemberPageListPropertiesByCondition(com.seeyon.boot.transport.PageDtoRequest<com.seeyon.organization.dto.core.SimpleConditionByParamsDto>);
```

### `OrgMemberPostBaseAppService`（13 方法）

`com.seeyon.organization.api.core.memberpost.OrgMemberPostBaseAppService`

```java
    com.seeyon.boot.transport.SingleResponse<java.lang.Long> create(com.seeyon.boot.transport.SingleRequest<com.seeyon.organization.dto.core.OrgMemberPostDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> update(com.seeyon.boot.transport.SingleRequest<com.seeyon.organization.dto.core.OrgMemberPostDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.organization.dto.core.OrgMemberPostDto> selectById(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.organization.dto.core.OrgMemberPostDto> selectByIds(com.seeyon.boot.transport.SingleRequest<java.util.List<java.lang.Long>>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.organization.dto.core.OrgMemberPostDto> selectCascadeById(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.organization.dto.core.OrgMemberPostDto> selectCascadeByIds(com.seeyon.boot.transport.SingleRequest<java.util.List<java.lang.Long>>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.organization.dto.core.OrgMemberPostDto> selectListByConditions(com.seeyon.boot.transport.ListRequest);
    com.seeyon.boot.transport.PageResponse<com.seeyon.organization.dto.core.OrgMemberPostDto> selectPageByConditions(com.seeyon.boot.transport.PageRequest);
    com.seeyon.boot.transport.PageResponse<com.seeyon.organization.dto.core.OrgMemberPostDto> dynamicJoinSelect(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.dynamicsql.dto.ProxyJoinParamDto>);
    default com.seeyon.boot.transport.SingleResponse<java.lang.Integer> dynamicCountJoinSelect(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.dynamicsql.dto.ProxyJoinParamDto>);
    com.seeyon.boot.transport.ListResponse<java.util.Map<java.lang.String, java.lang.Object>> selectMemberPostListPropertiesByMemberIds(com.seeyon.boot.transport.SingleRequest<com.seeyon.organization.dto.core.SimpleConditionByIdsDto>);
    com.seeyon.boot.transport.PageResponse<java.util.Map<java.lang.String, java.lang.Object>> selectMemberPostPageListPropertiesByCondition(com.seeyon.boot.transport.PageDtoRequest<com.seeyon.organization.dto.core.SimpleConditionByParamsDto>);
    com.seeyon.boot.transport.PageResponse<com.seeyon.organization.dto.core.OrgMemberPostDto> dynamicSelect(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.dynamicsql.dto.ProxyParamDto>);
```

### `OrgMemberRoleBaseAppService`（13 方法）

`com.seeyon.organization.api.core.memberrole.OrgMemberRoleBaseAppService`

```java
    com.seeyon.boot.transport.SingleResponse<com.seeyon.organization.dto.core.response.OrgMemberRoleDto> selectById(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.organization.dto.core.response.OrgMemberRoleDto> selectByIds(com.seeyon.boot.transport.SingleRequest<java.util.List<java.lang.Long>>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.organization.dto.core.response.OrgMemberRoleDto> selectCascadeById(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.organization.dto.core.response.OrgMemberRoleDto> selectCascadeByIds(com.seeyon.boot.transport.SingleRequest<java.util.List<java.lang.Long>>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.organization.dto.core.response.OrgMemberRoleDto> selectListByConditions(com.seeyon.boot.transport.ListRequest);
    default com.seeyon.boot.transport.ListResponse<com.seeyon.organization.dto.core.response.OrgMemberRoleDto> selectListByCondition(com.seeyon.boot.transport.SingleRequest<com.seeyon.organization.dto.core.base.SearchOrgMemberRoleDto>);
    com.seeyon.boot.transport.PageResponse<com.seeyon.organization.dto.core.response.OrgMemberRoleDto> selectPageByConditions(com.seeyon.boot.transport.PageRequest);
    default com.seeyon.boot.transport.PageResponse<com.seeyon.organization.dto.core.response.OrgMemberRoleDto> selectPageByConditions(com.seeyon.boot.transport.PageDtoRequest<com.seeyon.organization.dto.core.base.SearchOrgMemberRoleDto>);
    com.seeyon.boot.transport.PageResponse<com.seeyon.organization.dto.core.response.OrgMemberRoleDto> dynamicJoinSelect(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.dynamicsql.dto.ProxyJoinParamDto>);
    com.seeyon.boot.transport.PageResponse<com.seeyon.organization.dto.core.response.OrgMemberRoleDto> dynamicSelect(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.dynamicsql.dto.ProxyParamDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.organization.dto.core.response.OrgMemberRoleDto> selectCascadeByConditions(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.dynamicsql.dto.QueryConditionDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.organization.dto.core.response.OrgMemberRoleDto> selectCascadeListByConditions(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.dynamicsql.dto.QueryConditionDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.organization.dto.sync.OrgSyncInfoDto> createOrUpdateBatch(com.seeyon.boot.transport.SingleRequest<java.util.List<com.seeyon.organization.dto.core.base.OrgMemberRoleBaseDto>>);
```

### `OrgRoleBaseAppService`（13 方法）

`com.seeyon.organization.api.core.orgrole.OrgRoleBaseAppService`

```java
    com.seeyon.boot.transport.SingleResponse<com.seeyon.organization.dto.core.response.OrgRoleDto> selectById(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.organization.dto.core.response.OrgRoleDto> selectByIds(com.seeyon.boot.transport.SingleRequest<java.util.List<java.lang.Long>>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.organization.dto.core.response.OrgRoleDto> selectCascadeById(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.organization.dto.core.response.OrgRoleDto> selectCascadeByIds(com.seeyon.boot.transport.SingleRequest<java.util.List<java.lang.Long>>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.organization.dto.core.response.OrgRoleDto> selectListByConditions(com.seeyon.boot.transport.ListRequest);
    default com.seeyon.boot.transport.ListResponse<com.seeyon.organization.dto.core.response.OrgRoleDto> selectListByCondition(com.seeyon.boot.transport.SingleRequest<com.seeyon.organization.dto.core.base.SearchOrgRoleDto>);
    com.seeyon.boot.transport.PageResponse<com.seeyon.organization.dto.core.response.OrgRoleDto> selectPageByConditions(com.seeyon.boot.transport.PageRequest);
    default com.seeyon.boot.transport.PageResponse<com.seeyon.organization.dto.core.response.OrgRoleDto> selectPageByConditions(com.seeyon.boot.transport.PageDtoRequest<com.seeyon.organization.dto.core.base.SearchOrgRoleDto>);
    com.seeyon.boot.transport.PageResponse<com.seeyon.organization.dto.core.response.OrgRoleDto> dynamicJoinSelect(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.dynamicsql.dto.ProxyJoinParamDto>);
    com.seeyon.boot.transport.PageResponse<com.seeyon.organization.dto.core.response.OrgRoleDto> dynamicSelect(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.dynamicsql.dto.ProxyParamDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.organization.dto.core.response.OrgRoleDto> selectCascadeByConditions(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.dynamicsql.dto.QueryConditionDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.organization.dto.core.response.OrgRoleDto> selectCascadeListByConditions(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.dynamicsql.dto.QueryConditionDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.organization.dto.sync.OrgSyncInfoDto> createOrUpdateBatch(com.seeyon.boot.transport.SingleRequest<java.util.List<com.seeyon.organization.dto.core.base.OrgRoleBaseDto>>);
```

### `OrgUnitCoreAppService`（13 方法）

`com.seeyon.organization.api.core.unit.OrgUnitCoreAppService`

```java
    com.seeyon.boot.transport.SingleResponse<com.seeyon.organization.dto.core.OrgUnitCoreDto> selectOrgById(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.organization.dto.common.OrgUnitInfoDto> selectOrgInfoById(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.organization.dto.core.OrgUnitCoreDto> selectOrgByIds(com.seeyon.boot.transport.SingleRequest<java.util.List<java.lang.Long>>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.organization.dto.core.OrgUnitCoreDto> selectOrgByIdsIgnoreTenantId(com.seeyon.boot.transport.SingleRequest<java.util.List<java.lang.Long>>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.organization.dto.common.OrgUnitInfoDto> selectOrgInfoByIds(com.seeyon.boot.transport.SingleRequest<java.util.List<java.lang.Long>>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.organization.dto.core.OrgUnitCoreDto> selectOrgListByCondition(com.seeyon.boot.transport.SingleRequest<java.util.Map<java.lang.String, java.lang.Object>>);
    com.seeyon.boot.transport.PageResponse<com.seeyon.organization.dto.core.OrgUnitCoreDto> selectOrgPageListByCondition(com.seeyon.boot.transport.PageRequest);
    com.seeyon.boot.transport.ListResponse<com.seeyon.organization.dto.common.OrgUnitInfoDto> selectOrgInfoListByCondition(com.seeyon.boot.transport.SingleRequest<java.util.Map<java.lang.String, java.lang.Object>>);
    com.seeyon.boot.transport.PageResponse<com.seeyon.organization.dto.common.OrgUnitInfoDto> selectOrgInfoPageListByCondition(com.seeyon.boot.transport.PageRequest);
    com.seeyon.boot.transport.ListResponse<java.util.Map<java.lang.String, java.lang.Object>> selectMetadataPropertiesByOrgIds(com.seeyon.boot.transport.SingleRequest<java.util.Map<java.lang.String, java.lang.Object>>);
    com.seeyon.boot.transport.ListResponse<java.util.Map<java.lang.String, java.lang.Object>> selectOrgListPropertiesByOrgIds(com.seeyon.boot.transport.SingleRequest<com.seeyon.organization.dto.core.SimpleConditionByIdsDto>);
    com.seeyon.boot.transport.PageResponse<java.util.Map<java.lang.String, java.lang.Object>> selectOrgPageListPropertiesByCondition(com.seeyon.boot.transport.PageDtoRequest<com.seeyon.organization.dto.core.SimpleConditionByParamsDto>);
    com.seeyon.boot.transport.PageResponse<java.lang.Long> selectTraditionToSimpleNameByCondition(com.seeyon.boot.transport.PageRequest);
```

### `OrgBusinessBaseAppService`（11 方法）

`com.seeyon.organization.api.core.business.OrgBusinessBaseAppService`

```java
    com.seeyon.boot.transport.SingleResponse<com.seeyon.organization.dto.core.response.OrgBusinessDto> selectById(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.organization.dto.core.response.OrgBusinessDto> selectByIds(com.seeyon.boot.transport.SingleRequest<java.util.List<java.lang.Long>>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.organization.dto.core.response.OrgBusinessDto> selectCascadeById(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.organization.dto.core.response.OrgBusinessDto> selectCascadeByIds(com.seeyon.boot.transport.SingleRequest<java.util.List<java.lang.Long>>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.organization.dto.core.response.OrgBusinessDto> selectListByConditions(com.seeyon.boot.transport.ListRequest);
    com.seeyon.boot.transport.PageResponse<com.seeyon.organization.dto.core.response.OrgBusinessDto> selectPageByConditions(com.seeyon.boot.transport.PageRequest);
    com.seeyon.boot.transport.PageResponse<com.seeyon.organization.dto.core.response.OrgBusinessDto> dynamicJoinSelect(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.dynamicsql.dto.ProxyJoinParamDto>);
    default com.seeyon.boot.transport.SingleResponse<java.lang.Integer> dynamicCountJoinSelect(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.dynamicsql.dto.ProxyJoinParamDto>);
    com.seeyon.boot.transport.PageResponse<com.seeyon.organization.dto.core.response.OrgBusinessDto> dynamicSelect(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.dynamicsql.dto.ProxyParamDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.organization.dto.core.response.OrgBusinessDto> selectCascadeByConditions(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.dynamicsql.dto.QueryConditionDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.organization.dto.core.response.OrgBusinessDto> selectCascadeListByConditions(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.dynamicsql.dto.QueryConditionDto>);
```

### `OrgPortalAppService`（10 方法）

`com.seeyon.organization.api.app.portal.OrgPortalAppService`

```java
    com.seeyon.boot.transport.PageResponse<java.util.Map<java.lang.String, java.lang.Object>> selectSwitchInstitution(com.seeyon.boot.transport.PageRequest);
    com.seeyon.boot.transport.ListResponse<java.util.Map<java.lang.String, java.lang.Object>> selectSwitchInstitutions(com.seeyon.boot.transport.SingleRequest);
    com.seeyon.boot.transport.ListResponse<java.util.Map<java.lang.String, java.lang.Object>> selectSwitchInstitutionByMemberId(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.SingleResponse<java.util.Map<java.lang.String, java.lang.Object>> selectLoginUserInfo(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.SingleResponse<java.util.Map<java.lang.String, java.lang.Object>> selectCurrentLoginUserInfo(com.seeyon.boot.transport.SingleRequest<java.util.Map<java.lang.String, java.lang.Object>>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Boolean> isOrgAdmin(com.seeyon.boot.transport.SingleRequest<java.util.Map<java.lang.String, java.lang.Object>>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.organization.dto.core.OrgMemberPostCoreDto> selectMainMemberPostByMemberId(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.SingleResponse<java.util.Map<java.lang.Long, com.seeyon.organization.dto.core.OrgMemberPostCoreDto>> selectMainMemberPostByMemberIdsIgnoreTenant(com.seeyon.boot.transport.SingleRequest<java.util.List<java.lang.Long>>);
    com.seeyon.boot.transport.SingleResponse<java.util.Map<java.lang.Long, com.seeyon.organization.dto.core.OrgMemberPostCoreDto>> selectMainMemberPostByMemberIdsAllTenant(com.seeyon.boot.transport.SingleRequest<java.util.List<java.util.Map<java.lang.String, java.lang.Object>>>);
    com.seeyon.boot.transport.SingleResponse<java.util.Map<java.lang.String, java.lang.String>> selectPeopleTabCustomSet();
```

### `OrgUnitVerticalBaseAppService`（10 方法）

`com.seeyon.organization.api.core.unitvertical.OrgUnitVerticalBaseAppService`

```java
    com.seeyon.boot.transport.SingleResponse<com.seeyon.organization.dto.core.response.OrgUnitVerticalDto> selectById(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.organization.dto.core.response.OrgUnitVerticalDto> selectByIds(com.seeyon.boot.transport.SingleRequest<java.util.List<java.lang.Long>>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.organization.dto.core.response.OrgUnitVerticalDto> selectCascadeById(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.organization.dto.core.response.OrgUnitVerticalDto> selectCascadeByIds(com.seeyon.boot.transport.SingleRequest<java.util.List<java.lang.Long>>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.organization.dto.core.response.OrgUnitVerticalDto> selectListByConditions(com.seeyon.boot.transport.ListRequest);
    com.seeyon.boot.transport.PageResponse<com.seeyon.organization.dto.core.response.OrgUnitVerticalDto> selectPageByConditions(com.seeyon.boot.transport.PageRequest);
    com.seeyon.boot.transport.PageResponse<com.seeyon.organization.dto.core.response.OrgUnitVerticalDto> dynamicJoinSelect(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.dynamicsql.dto.ProxyJoinParamDto>);
    com.seeyon.boot.transport.PageResponse<com.seeyon.organization.dto.core.response.OrgUnitVerticalDto> dynamicSelect(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.dynamicsql.dto.ProxyParamDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.organization.dto.core.response.OrgUnitVerticalDto> selectCascadeByConditions(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.dynamicsql.dto.QueryConditionDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.organization.dto.core.response.OrgUnitVerticalDto> selectCascadeListByConditions(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.dynamicsql.dto.QueryConditionDto>);
```

### `OcipUnitAppService`（8 方法）

`com.seeyon.organization.api.app.ocip.OcipUnitAppService`

```java
    com.seeyon.boot.transport.SingleResponse<java.lang.String> pushAccountAll(com.seeyon.boot.transport.SingleRequest<java.lang.String>);
    com.seeyon.boot.transport.SingleResponse<java.lang.String> pushAccountAllByIncrement(com.seeyon.boot.transport.SingleRequest<java.lang.String>);
    com.seeyon.boot.transport.SingleResponse<java.lang.String> pushAccountBatch(com.seeyon.boot.transport.SingleRequest<java.lang.String>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> pushAccountIncrement(com.seeyon.boot.transport.SingleRequest<java.util.List<java.lang.Long>>);
    com.seeyon.boot.transport.SingleResponse<java.lang.String> pushDepartmentAll(com.seeyon.boot.transport.SingleRequest<java.lang.String>);
    com.seeyon.boot.transport.SingleResponse<java.lang.String> pushDepartmentAllByIncrement(com.seeyon.boot.transport.SingleRequest<java.lang.String>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> pushDepartmentIncrement(com.seeyon.boot.transport.SingleRequest<java.util.List<java.lang.Long>>);
    com.seeyon.boot.transport.SingleResponse<java.lang.String> pushDepartmentBatch(com.seeyon.boot.transport.SingleRequest<java.lang.String>);
```

### `OrgUnitSyncAppService`（8 方法）

`com.seeyon.organization.api.app.sync.OrgUnitSyncAppService`

```java
    com.seeyon.boot.transport.SingleResponse<com.seeyon.organization.dto.sync.OrgSyncInfoDto> createBatch(com.seeyon.boot.transport.SingleRequest<com.seeyon.organization.dto.sync.OrgBatchUnitDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.organization.dto.sync.OrgSyncInfoDto> createBatchUnitMetadata(com.seeyon.boot.transport.SingleRequest<com.seeyon.organization.dto.sync.OrgBatchMetadataDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.organization.dto.sync.OrgUnitDataDto> selectByCodes(com.seeyon.boot.transport.SingleRequest<com.seeyon.organization.dto.sync.search.SearchUnitConditionApiDto>);
    default com.seeyon.boot.transport.ListResponse<com.seeyon.organization.dto.sync.OrgUnitDataDto> selectByThirdIds(com.seeyon.boot.transport.SingleRequest<com.seeyon.organization.dto.sync.search.SearchUnitConditionApiDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.organization.dto.sync.OrgUnitDataDto> selectChildrenByCondition(com.seeyon.boot.transport.SingleRequest<com.seeyon.organization.dto.sync.search.SearchUnitApiDto>);
    com.seeyon.boot.transport.PageResponse<com.seeyon.organization.dto.sync.OrgUnitDataDto> selectPageChildrenByCondition(com.seeyon.boot.transport.PageDtoRequest<com.seeyon.organization.dto.sync.search.SearchUnitApiDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> disableOrganization(com.seeyon.boot.transport.SingleRequest<com.seeyon.organization.dto.sync.OrgDisableUnitDto>);
    com.seeyon.boot.transport.PageResponse<com.seeyon.organization.dto.sync.OrgUnitDataDto> selectPageByConditions(com.seeyon.boot.transport.PageDtoRequest<com.seeyon.organization.dto.sync.search.SearchUnitListApiDto>);
```

### `OrgUnitTeamCoreAppService`（8 方法）

`com.seeyon.organization.api.core.unitteam.OrgUnitTeamCoreAppService`

```java
    com.seeyon.boot.transport.SingleResponse<java.lang.Long> create(com.seeyon.boot.transport.SingleRequest<com.seeyon.organization.dto.core.request.OrgUnitTeamDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> delete(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    default com.seeyon.boot.transport.SingleResponse<java.lang.Integer> update(com.seeyon.boot.transport.SingleRequest<com.seeyon.organization.dto.core.request.OrgUnitTeamDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.organization.dto.common.OrgUnitTeamInfoDto> selectUnitTeamById(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.organization.dto.common.OrgUnitTeamInfoDto> selectUnitTeamByIds(com.seeyon.boot.transport.SingleRequest<java.util.List<java.lang.Long>>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.organization.dto.common.OrgUnitTeamInfoDto> selectUnitTeamListByCondition(com.seeyon.boot.transport.SingleRequest<java.util.Map<java.lang.String, java.lang.Object>>);
    com.seeyon.boot.transport.PageResponse<com.seeyon.organization.dto.common.OrgUnitTeamInfoDto> selectUnitTeamPageListByCondition(com.seeyon.boot.transport.PageRequest);
    default com.seeyon.boot.transport.SingleResponse<java.lang.Integer> selectSortId();
```

### `OrgJobCoreAppService`（6 方法）

`com.seeyon.organization.api.core.job.OrgJobCoreAppService`

```java
    com.seeyon.boot.transport.SingleResponse<com.seeyon.organization.dto.core.OrgJobCoreDto> selectJobById(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.organization.dto.core.OrgJobCoreDto> selectJobByIds(com.seeyon.boot.transport.SingleRequest<java.util.List<java.lang.Long>>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.organization.dto.core.OrgJobCoreDto> selectJobListByCondition(com.seeyon.boot.transport.SingleRequest<java.util.Map<java.lang.String, java.lang.Object>>);
    com.seeyon.boot.transport.PageResponse<com.seeyon.organization.dto.core.OrgJobCoreDto> selectJobPageListByCondition(com.seeyon.boot.transport.PageRequest);
    com.seeyon.boot.transport.ListResponse<java.util.Map<java.lang.String, java.lang.Object>> selectJobListPropertiesByJobIds(com.seeyon.boot.transport.SingleRequest<com.seeyon.organization.dto.core.SimpleConditionByIdsDto>);
    com.seeyon.boot.transport.PageResponse<java.util.Map<java.lang.String, java.lang.Object>> selectJobPageListPropertiesByCondition(com.seeyon.boot.transport.PageDtoRequest<com.seeyon.organization.dto.core.SimpleConditionByParamsDto>);
```

### `OrgLevelCoreAppService`（6 方法）

`com.seeyon.organization.api.core.level.OrgLevelCoreAppService`

```java
    com.seeyon.boot.transport.SingleResponse<com.seeyon.organization.dto.core.OrgLevelCoreDto> selectLevelById(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.organization.dto.core.OrgLevelCoreDto> selectLevelByIds(com.seeyon.boot.transport.SingleRequest<java.util.List<java.lang.Long>>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.organization.dto.core.OrgLevelCoreDto> selectLevelListByCondition(com.seeyon.boot.transport.SingleRequest<java.util.Map<java.lang.String, java.lang.Object>>);
    com.seeyon.boot.transport.PageResponse<com.seeyon.organization.dto.core.OrgLevelCoreDto> selectLevelPageListByCondition(com.seeyon.boot.transport.PageRequest);
    com.seeyon.boot.transport.ListResponse<java.util.Map<java.lang.String, java.lang.Object>> selectLevelListPropertiesByLevelIds(com.seeyon.boot.transport.SingleRequest<com.seeyon.organization.dto.core.SimpleConditionByIdsDto>);
    com.seeyon.boot.transport.PageResponse<java.util.Map<java.lang.String, java.lang.Object>> selectLevelPageListPropertiesByCondition(com.seeyon.boot.transport.PageDtoRequest<com.seeyon.organization.dto.core.SimpleConditionByParamsDto>);
```

### `OrgPostCoreAppService`（6 方法）

`com.seeyon.organization.api.core.post.OrgPostCoreAppService`

```java
    com.seeyon.boot.transport.SingleResponse<com.seeyon.organization.dto.core.OrgPostCoreDto> selectPostById(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.organization.dto.core.OrgPostCoreDto> selectPostByIds(com.seeyon.boot.transport.SingleRequest<java.util.List<java.lang.Long>>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.organization.dto.core.OrgPostCoreDto> selectPostListByCondition(com.seeyon.boot.transport.SingleRequest<java.util.Map<java.lang.String, java.lang.Object>>);
    com.seeyon.boot.transport.PageResponse<com.seeyon.organization.dto.core.OrgPostCoreDto> selectPostPageListByCondition(com.seeyon.boot.transport.PageRequest);
    com.seeyon.boot.transport.ListResponse<java.util.Map<java.lang.String, java.lang.Object>> selectPostListPropertiesByPostIds(com.seeyon.boot.transport.SingleRequest<com.seeyon.organization.dto.core.SimpleConditionByIdsDto>);
    com.seeyon.boot.transport.PageResponse<java.util.Map<java.lang.String, java.lang.Object>> selectPostPageListPropertiesByCondition(com.seeyon.boot.transport.PageDtoRequest<com.seeyon.organization.dto.core.SimpleConditionByParamsDto>);
```

### `OrgMemberPostCoreAppService`（5 方法）

`com.seeyon.organization.api.core.memberpost.OrgMemberPostCoreAppService`

```java
    com.seeyon.boot.transport.ListResponse<com.seeyon.organization.dto.core.OrgMemberPostCoreDto> selectMemberPostListByCondition(com.seeyon.boot.transport.SingleRequest<java.util.Map<java.lang.String, java.lang.Object>>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.organization.dto.core.OrgMemberPostCoreDto> selectMemberPostListByMemberIds(com.seeyon.boot.transport.SingleRequest<java.util.List<java.lang.Long>>);
    com.seeyon.boot.transport.PageResponse<com.seeyon.organization.dto.core.OrgMemberPostCoreDto> selectMemberPostPageListByCondition(com.seeyon.boot.transport.PageRequest);
    com.seeyon.boot.transport.ListResponse<java.util.Map<java.lang.String, java.lang.Object>> selectMemberPostListPropertiesByMemberIds(com.seeyon.boot.transport.SingleRequest<com.seeyon.organization.dto.core.SimpleConditionByIdsDto>);
    com.seeyon.boot.transport.PageResponse<java.util.Map<java.lang.String, java.lang.Object>> selectMemberPostPageListPropertiesByCondition(com.seeyon.boot.transport.PageDtoRequest<com.seeyon.organization.dto.core.SimpleConditionByParamsDto>);
```

### `OrgSystemTeamCoreAppService`（5 方法）

`com.seeyon.organization.api.core.systemteam.OrgSystemTeamCoreAppService`

```java
    com.seeyon.boot.transport.ListResponse<com.seeyon.organization.dto.core.OrgMemberCoreDto> selectTeamMemberByTeamId(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.organization.dto.core.OrgMemberCoreDto> selectTeamMemberByTeamIds(com.seeyon.boot.transport.SingleRequest<java.util.List<java.lang.Long>>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.organization.dto.core.OrgTeamCoreDto> selectTeamById(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.organization.dto.core.OrgTeamCoreDto> selectTeamByIds(com.seeyon.boot.transport.SingleRequest<java.util.List<java.lang.Long>>);
    com.seeyon.boot.transport.PageResponse<com.seeyon.organization.dto.core.OrgTeamCoreDto> selectTeamByCondition(com.seeyon.boot.transport.PageRequest);
```

### `OcipLevelAppService`（4 方法）

`com.seeyon.organization.api.app.ocip.OcipLevelAppService`

```java
    com.seeyon.boot.transport.SingleResponse<java.lang.String> pushAll(com.seeyon.boot.transport.SingleRequest<java.lang.String>);
    com.seeyon.boot.transport.SingleResponse<java.lang.String> pushAllByIncrement(com.seeyon.boot.transport.SingleRequest<java.lang.String>);
    com.seeyon.boot.transport.SingleResponse<java.lang.String> pushBatch(com.seeyon.boot.transport.SingleRequest<java.lang.String>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> pushLevelIncrement(com.seeyon.boot.transport.SingleRequest<java.util.List<java.lang.Long>>);
```

### `OcipMemberAppService`（4 方法）

`com.seeyon.organization.api.app.ocip.OcipMemberAppService`

```java
    com.seeyon.boot.transport.SingleResponse<java.lang.String> pushAll(com.seeyon.boot.transport.SingleRequest<java.lang.String>);
    com.seeyon.boot.transport.SingleResponse<java.lang.String> pushAllByIncrement(com.seeyon.boot.transport.SingleRequest<java.lang.String>);
    com.seeyon.boot.transport.SingleResponse<java.lang.String> pushBatch(com.seeyon.boot.transport.SingleRequest<java.lang.String>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> pushMemberIncrement(com.seeyon.boot.transport.SingleRequest<java.util.List<java.lang.Long>>);
```

### `OcipPostAppService`（4 方法）

`com.seeyon.organization.api.app.ocip.OcipPostAppService`

```java
    com.seeyon.boot.transport.SingleResponse<java.lang.String> pushAll(com.seeyon.boot.transport.SingleRequest<java.lang.String>);
    com.seeyon.boot.transport.SingleResponse<java.lang.String> pushAllByIncrement(com.seeyon.boot.transport.SingleRequest<java.lang.String>);
    com.seeyon.boot.transport.SingleResponse<java.lang.String> pushBatch(com.seeyon.boot.transport.SingleRequest<java.lang.String>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> pushPostIncrement(com.seeyon.boot.transport.SingleRequest<java.util.List<java.lang.Long>>);
```

### `OrgJobSyncAppService`（4 方法）

`com.seeyon.organization.api.app.sync.OrgJobSyncAppService`

```java
    com.seeyon.boot.transport.ListResponse<com.seeyon.organization.dto.sync.OrgJobDataDto> selectByCodes(com.seeyon.boot.transport.SingleRequest<com.seeyon.organization.dto.sync.search.SearchJobApiDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.organization.dto.sync.OrgSyncInfoDto> createBatch(com.seeyon.boot.transport.SingleRequest<com.seeyon.organization.dto.sync.OrgBatchJobDto>);
    com.seeyon.boot.transport.PageResponse<com.seeyon.organization.dto.sync.OrgJobDataDto> selectPageByConditions(com.seeyon.boot.transport.PageDtoRequest<com.seeyon.organization.dto.sync.search.SearchPostListApiDto>);
    default com.seeyon.boot.transport.ListResponse<com.seeyon.organization.dto.sync.OrgJobDataDto> selectByThirds(com.seeyon.boot.transport.SingleRequest<com.seeyon.organization.dto.sync.search.SearchJobByThirdIdApiDto>);
```

### `OrgLevelSyncAppService`（4 方法）

`com.seeyon.organization.api.app.sync.OrgLevelSyncAppService`

```java
    com.seeyon.boot.transport.ListResponse<com.seeyon.organization.dto.sync.OrgLevelDataDto> selectByCodes(com.seeyon.boot.transport.SingleRequest<com.seeyon.organization.dto.sync.search.SearchLevelApiDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.organization.dto.sync.OrgSyncInfoDto> createBatch(com.seeyon.boot.transport.SingleRequest<com.seeyon.organization.dto.sync.OrgBatchLevelDto>);
    com.seeyon.boot.transport.PageResponse<com.seeyon.organization.dto.sync.OrgLevelDataDto> selectPageByConditions(com.seeyon.boot.transport.PageDtoRequest<com.seeyon.organization.dto.sync.search.SearchLevelListApiDto>);
    default com.seeyon.boot.transport.ListResponse<com.seeyon.organization.dto.sync.OrgLevelDataDto> selectByThirdIds(com.seeyon.boot.transport.SingleRequest<com.seeyon.organization.dto.sync.search.SearchLevelByThirdIdApiDto>);
```

### `OrgPostSyncAppService`（4 方法）

`com.seeyon.organization.api.app.sync.OrgPostSyncAppService`

```java
    com.seeyon.boot.transport.SingleResponse<com.seeyon.organization.dto.sync.OrgSyncInfoDto> createBatch(com.seeyon.boot.transport.SingleRequest<com.seeyon.organization.dto.sync.OrgBatchPostDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.organization.dto.sync.OrgPostDataDto> selectByCodes(com.seeyon.boot.transport.SingleRequest<com.seeyon.organization.dto.sync.search.SearchPostApiDto>);
    com.seeyon.boot.transport.PageResponse<com.seeyon.organization.dto.sync.OrgPostDataDto> selectPageByConditions(com.seeyon.boot.transport.PageDtoRequest<com.seeyon.organization.dto.sync.search.SearchPostListApiDto>);
    default com.seeyon.boot.transport.ListResponse<com.seeyon.organization.dto.sync.OrgPostDataDto> selectByThirdIds(com.seeyon.boot.transport.SingleRequest<com.seeyon.organization.dto.sync.search.SearchPostByThirdIdApiDto>);
```

### `OrgTeamSyncAppService`（4 方法）

`com.seeyon.organization.api.app.sync.OrgTeamSyncAppService`

```java
    com.seeyon.boot.transport.SingleResponse<com.seeyon.organization.dto.sync.OrgTeamDataDto> selectByCode(com.seeyon.boot.transport.SingleRequest<java.lang.String>);
    com.seeyon.boot.transport.PageResponse<com.seeyon.organization.dto.sync.OrgTeamDataDto> selectPageByConditions(com.seeyon.boot.transport.PageDtoRequest<com.seeyon.organization.dto.sync.search.SearchTeamListApiDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.organization.dto.sync.OrgSyncInfoDto> create(com.seeyon.boot.transport.SingleRequest<com.seeyon.organization.dto.sync.OrgTeamDataDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.organization.dto.sync.OrgSyncInfoDto> createBatch(com.seeyon.boot.transport.SingleRequest<com.seeyon.organization.dto.sync.OrgBatchTeamDto>);
```

### `OrgMemberRoleCoreAppService`（4 方法）

`com.seeyon.organization.api.core.memberrole.OrgMemberRoleCoreAppService`

```java
    com.seeyon.boot.transport.SingleResponse<com.seeyon.organization.dto.core.OrgMemberRoleCoreDto> selectById(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.organization.dto.core.OrgMemberRoleCoreDto> selectByIds(com.seeyon.boot.transport.SingleRequest<java.util.List<java.lang.Long>>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.organization.dto.core.OrgMemberRoleCoreDto> selectListByConditions(com.seeyon.boot.transport.SingleRequest<java.util.Map<java.lang.String, java.lang.Object>>);
    com.seeyon.boot.transport.PageResponse<com.seeyon.organization.dto.core.OrgMemberRoleCoreDto> selectPageByConditions(com.seeyon.boot.transport.PageRequest);
```

### `OrgRoleCoreAppService`（4 方法）

`com.seeyon.organization.api.core.orgrole.OrgRoleCoreAppService`

```java
    com.seeyon.boot.transport.SingleResponse<com.seeyon.organization.dto.core.OrgRoleCoreDto> selectById(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.organization.dto.core.OrgRoleCoreDto> selectByIds(com.seeyon.boot.transport.SingleRequest<java.util.List<java.lang.Long>>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.organization.dto.core.OrgRoleCoreDto> selectListByConditions(com.seeyon.boot.transport.SingleRequest<java.util.Map<java.lang.String, java.lang.Object>>);
    com.seeyon.boot.transport.PageResponse<com.seeyon.organization.dto.core.OrgRoleCoreDto> selectPageByConditions(com.seeyon.boot.transport.PageRequest);
```

### `OrgSelectPeopleForDeptAppService`（3 方法）

`com.seeyon.organization.api.selectpeople.department.OrgSelectPeopleForDeptAppService`

```java
    com.seeyon.boot.transport.SingleResponse<com.seeyon.organization.dto.selectpeople.SelectPeopleUserDepartmentTreeListDto> departmentTree(com.seeyon.boot.transport.SingleRequest<com.seeyon.organization.dto.selectpeople.SearchDepartmentTree>);
    com.seeyon.boot.transport.SingleResponse<java.lang.String> selectOrgPath(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.organization.dto.selectpeople.SelectPeopleUserDepartmentTreeExtensionDto> departmentTreeExtensionList(com.seeyon.boot.transport.SingleRequest<java.util.List<java.lang.Long>>);
```

### `OrgAppCommonAppService`（2 方法）

`com.seeyon.organization.api.app.appcommon.OrgAppCommonAppService`

```java
    com.seeyon.boot.transport.ListResponse<java.lang.Long> selectAccessViewMember(com.seeyon.boot.transport.SingleRequest<java.util.List<java.lang.Long>>);
    com.seeyon.boot.transport.ListResponse<java.lang.Long> selectAccessViewOrg(com.seeyon.boot.transport.SingleRequest<java.util.List<java.lang.Long>>);
```

### `OrgMobileAppService`（2 方法）

`com.seeyon.organization.api.app.m5.OrgMobileAppService`

```java
    com.seeyon.boot.transport.PageResponse<java.lang.String> selectPagePhoneNumber(com.seeyon.boot.transport.PageRequest);
    com.seeyon.boot.transport.SingleResponse<java.lang.String> selectOfflineStorageKey(com.seeyon.boot.transport.SingleRequest);
```

### `MultiOrgDepSyncService`（2 方法）

`com.seeyon.organization.api.app.sync.MultiOrgDepSyncService`

```java
    com.seeyon.boot.transport.SingleResponse<com.seeyon.organization.dto.sync.OrgSyncInfoDto> multiOrgCreateBatch(com.seeyon.boot.transport.SingleRequest<com.seeyon.organization.dto.sync.multi.MultiOrgDepSyncBatchDto>);
    com.seeyon.boot.transport.PageResponse<com.seeyon.organization.dto.sync.multi.MultiOrgDepSyncSearchResponse> selectPageChildrenByCondition(com.seeyon.boot.transport.PageDtoRequest<com.seeyon.organization.dto.sync.multi.MultiOrgDepSyncSearchChildDto>);
```

### `MultiOrgMemberSyncService`（2 方法）

`com.seeyon.organization.api.app.sync.MultiOrgMemberSyncService`

```java
    com.seeyon.boot.transport.SingleResponse<com.seeyon.organization.dto.sync.OrgSyncInfoDto> MultiOrgMemberCreateBatch(com.seeyon.boot.transport.SingleRequest<com.seeyon.organization.dto.sync.multi.MultiOrgMemberSyncBatchDto>);
    com.seeyon.boot.transport.PageResponse<com.seeyon.organization.dto.sync.multi.MultiOrgMemberSyncSearchByOrgCodeResponse> selectByCodes(com.seeyon.boot.transport.PageDtoRequest<com.seeyon.organization.dto.sync.multi.MultiOrgMemberSyncSearchByOrgCodeDto>);
```

### `MultiOrgSyncService`（2 方法）

`com.seeyon.organization.api.app.sync.MultiOrgSyncService`

```java
    com.seeyon.boot.transport.SingleResponse<com.seeyon.organization.dto.sync.OrgSyncInfoDto> multiOrgCreateBatch(com.seeyon.boot.transport.SingleRequest<com.seeyon.organization.dto.sync.multi.MultiOrgSyncBatchDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.organization.dto.sync.multi.MultiOrgSyncSearchResponse> selectByCodes(com.seeyon.boot.transport.SingleRequest<com.seeyon.organization.dto.sync.multi.MultiOrgSyncSearchDto>);
```

### `OrgRoleSyncService`（2 方法）

`com.seeyon.organization.api.app.sync.OrgRoleSyncService`

```java
    com.seeyon.boot.transport.SingleResponse<com.seeyon.organization.dto.sync.OrgSyncInfoDto> createBatch(com.seeyon.boot.transport.SingleRequest<com.seeyon.organization.dto.sync.OrgBatchOrgRoleDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.organization.dto.sync.OrgRoleDataDto> selectByCodes(com.seeyon.boot.transport.SingleRequest<java.util.List<java.lang.String>>);
```

### `OrgSelectPeopleForInstAppService`（2 方法）

`com.seeyon.organization.api.selectpeople.institution.OrgSelectPeopleForInstAppService`

```java
    com.seeyon.boot.transport.ListResponse<com.seeyon.organization.dto.selectpeople.SelectPeopleUnitDto> selectFirstChildrenUnits(com.seeyon.boot.transport.SingleRequest<com.seeyon.organization.dto.selectpeople.SearchUnitDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.organization.dto.selectpeople.SelectPeopleUnitDto> searchInstitution(com.seeyon.boot.transport.SingleRequest<com.seeyon.organization.dto.selectpeople.SearchUnitByKeyDto>);
```

### `OrgSelectPeopleForMemberAppService`（2 方法）

`com.seeyon.organization.api.selectpeople.member.OrgSelectPeopleForMemberAppService`

```java
    com.seeyon.boot.transport.ListResponse<com.seeyon.organization.dto.selectpeople.SelectPeopleMemberDto> searchMemberByGroup(com.seeyon.boot.transport.SingleRequest<com.seeyon.organization.dto.selectpeople.SearchByKeyDto>);
    com.seeyon.boot.transport.PageResponse<com.seeyon.organization.dto.selectpeople.SelectPeopleMemberDto> selectMembersByOrg(com.seeyon.boot.transport.PageRequest);
```

### `OrgAffairAppService`（1 方法）

`com.seeyon.organization.api.app.affair.OrgAffairAppService`

```java
    com.seeyon.boot.transport.ListResponse<com.seeyon.organization.dto.api.app.affair.OrgEntityIdCodeDto> selectByIdOrCode(com.seeyon.boot.transport.SingleRequest<java.util.List<com.seeyon.organization.dto.api.app.affair.OrgEntityIdCodeDto>>);
```

### `AuthorizationAppService`（1 方法）

`com.seeyon.organization.api.app.authorization.AuthorizationAppService`

```java
    com.seeyon.boot.transport.SingleResponse<java.lang.String> registerAppResourceAndPermission(com.seeyon.boot.transport.SingleRequest<com.seeyon.organization.dto.api.app.authorization.AuthorizationResourceAndPermissionDto>);
```

### `OrgEdocAppService`（1 方法）

`com.seeyon.organization.api.app.edoc.OrgEdocAppService`

```java
    com.seeyon.boot.transport.SingleResponse<java.util.List<java.util.Map<java.lang.Long, java.lang.Integer>>> selectSortByIds(com.seeyon.boot.transport.SingleRequest<com.seeyon.organization.dto.api.app.edoc.SearchSortDto>);
```

### `OrgPlatformAppService`（1 方法）

`com.seeyon.organization.api.app.platform.OrgPlatformAppService`

```java
    com.seeyon.boot.transport.SingleResponse<java.util.Map<java.lang.String, java.lang.Object>> selectWatermarkInfoByMemberId(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
```

### `OrgMemberRoleSyncService`（1 方法）

`com.seeyon.organization.api.app.sync.OrgMemberRoleSyncService`

```java
    com.seeyon.boot.transport.SingleResponse<com.seeyon.organization.dto.sync.OrgSyncInfoDto> createBatch(com.seeyon.boot.transport.SingleRequest<com.seeyon.organization.dto.sync.OrgBatchMemberRoleDto>);
```

### `OrgBusinessCoreAppService`（1 方法）

`com.seeyon.organization.api.core.business.OrgBusinessCoreAppService`

```java
    com.seeyon.boot.transport.ListResponse<com.seeyon.organization.dto.core.OrgBusinessCoreDto> selectBusinessListByCondition(com.seeyon.boot.transport.SingleRequest<java.util.Map<java.lang.String, java.lang.Object>>);
```

### `OrgInstitutionExecutiveAppService`（1 方法）

`com.seeyon.organization.api.core.institution.OrgInstitutionExecutiveAppService`

```java
    com.seeyon.boot.transport.SingleResponse<java.util.Map<java.lang.Long, java.lang.Boolean>> checkUserExecutiveHide(com.seeyon.boot.transport.SingleRequest<java.util.List<java.lang.Long>>);
```

### `OrgUnitVerticalCoreAppService`（1 方法）

`com.seeyon.organization.api.core.unitvertical.OrgUnitVerticalCoreAppService`

```java
    com.seeyon.boot.transport.ListResponse<com.seeyon.organization.dto.core.OrgUnitVerticalCoreDto> selectUnitVerticalListByCondition(com.seeyon.boot.transport.SingleRequest<java.util.Map<java.lang.String, java.lang.Object>>);
```

### `OrgParameterCoreAppService`（1 方法）

`com.seeyon.organization.api.parameter.OrgParameterCoreAppService`

```java
    com.seeyon.boot.transport.SingleResponse<java.lang.String> selectValueByParamsKey(com.seeyon.boot.transport.SingleRequest<java.lang.String>);
```

### `TenantManageAppService`（1 方法）

`com.seeyon.organization.api.tenant.TenantManageAppService`

```java
    com.seeyon.boot.transport.ListResponse<java.util.HashMap<java.lang.Long, java.lang.Integer>> selectEnableUnitNumIgnoreTenant();
```

## 二、关键类（3）

### `OrgOutsideUnitManagerDto`（34 方法）

`com.seeyon.organization.dto.sync.OrgOutsideUnitManagerDto`

```java
    java.lang.Long getId();
    java.lang.String getName();
    java.lang.String getCode();
    java.lang.String getPhoneNumber();
    java.lang.String getUsername();
    com.seeyon.organization.enums.core.MemberGenderEnum getGender();
    java.lang.String getEffectiveTime();
    java.lang.String getInvalidTime();
    java.lang.Integer getSortId();
    java.lang.Boolean getIsEnable();
    java.lang.String getImage();
    java.lang.String getEmail();
    com.seeyon.organization.enums.core.MemberTypeEnum getMemberType();
    java.lang.String getOutsideInstitutionCode();
    java.lang.Long getOutsideInstitutionId();
    java.util.Date getCreateTime();
    java.util.Date getUpdateTime();
    void setId(java.lang.Long);
    void setName(java.lang.String);
    void setCode(java.lang.String);
    void setPhoneNumber(java.lang.String);
    void setUsername(java.lang.String);
    void setGender(com.seeyon.organization.enums.core.MemberGenderEnum);
    void setEffectiveTime(java.lang.String);
    void setInvalidTime(java.lang.String);
    void setSortId(java.lang.Integer);
    void setIsEnable(java.lang.Boolean);
    void setImage(java.lang.String);
    void setEmail(java.lang.String);
    void setMemberType(com.seeyon.organization.enums.core.MemberTypeEnum);
    void setOutsideInstitutionCode(java.lang.String);
    void setOutsideInstitutionId(java.lang.Long);
    void setCreateTime(java.util.Date);
    void setUpdateTime(java.util.Date);
```

### `OrgWorkFlowUtil`（12 方法）

`com.seeyon.organization.api.app.workflow.util.OrgWorkFlowUtil`

```java
    static java.lang.String compress(java.lang.String);
    static java.lang.String uncompress(java.lang.String);
    static byte[] compress(byte[]);
    static byte[] uncompress(byte[]);
    static java.util.Map<java.lang.String, java.lang.String> selectSelectPeopleParameterInfo(java.util.List<com.seeyon.organization.dto.api.app.workflow.SelectPeopleDataWfDto>);
    static java.util.Map<java.lang.String, java.lang.String> selectSelectPeopleOrgInfo(java.util.List<com.seeyon.organization.dto.api.app.workflow.SelectPeopleDataWfDto>);
    static java.lang.Boolean sysCfgShowValidation(java.lang.String, java.util.List<java.util.List<com.seeyon.organization.dto.api.app.workflow.SelectPeopleDataWfDto>>);
    static private static java.lang.Boolean hasOrgRole(java.util.List<com.seeyon.organization.dto.api.app.workflow.SelectPeopleDataWfDto>);
    static private static java.util.Map<java.lang.String, java.lang.String> selectSelectPeopleDataInfo(java.util.List<com.seeyon.organization.dto.api.app.workflow.SelectPeopleDataWfDto>, java.lang.String);
    static private static java.lang.Boolean isLong(java.lang.String);
    static java.lang.Boolean checkEffectiveData(com.seeyon.organization.dto.api.app.workflow.SelectPeopleCheckEffectiveDataDto);
    static private static java.lang.String getType(java.lang.String);
```

### `SearchOutSideManagerApiDto`（6 方法）

`com.seeyon.organization.dto.sync.search.SearchOutSideManagerApiDto`

```java
    java.lang.String getStartTime();
    java.lang.String getEndTime();
    java.lang.String getOutsideInstitutionCode();
    void setStartTime(java.lang.String);
    void setEndTime(java.lang.String);
    void setOutsideInstitutionCode(java.lang.String);
```

## 三、注解（1）

| 注解 | 元素 |
|---|---|
| `EncryptFilter` | isDecrypt, isEncrypt |

## 四、枚举（64）

- `AddressBookClientTypeEnum`（3 常量）：NONE, PC, MOBILE
- `AddressBookSetItemEnum`（3 常量）：NONE, PC_LIST, MEMBER_CARD
- `AddressPermissionEnum`（3 常量）：NONE, ACCESS_MEMBER, SENSITIVE_MEMBER
- `OrgOnlineStatusEnum`（3 常量）：NONE, ON_LINE, OFF_LINE
- `AccessDepartmentTypeEnum`（6 常量）：NONE, DEFAULT, ACCESS, ACCESS_SELF, NO_ACCESS, ACCESS_PART_MEMBER
- `AccessInstitutionTypeEnum`（3 常量）：NONE, SELF_AND_CHILDREN, SELF
- `BusinessTypeEnum`（3 常量）：NONE, BUSINESS_MULTI_UNIT, BUSINESS_LINE
- `CategoryEnum`（3 常量）：NONE, BENCH_MARK, SELF_BUILT
- `GlobalPermissionTypeEnum`（4 常量）：NONE, VIEW_EACH, VIEW_CHILD, VIEW_SELF
- `IncludeChildTypeEnum`（9 常量）：NONE, INSTITUTION, DEPARTMENT, BUSINESS_DEPARTMENT, OUTSIDE_DEPARTMENT, ROLE, POST, JOB, LEVEL
- `MemberGenderEnum`（4 常量）：NONE, MALE, FEMALE, UN_KNOW
- `MemberTypeEnum`（4 常量）：NONE, MEMBER, OUTSIDE_MEMBER, NATURAL_MEMBER
- `MessageStatusEnum`（4 常量）：NONE, SUCCESS, FAILED, SKIP
- `OrgEntityTypeEnum`（27 常量）：NONE, UNIT, INSTITUTION, DEPARTMENT, POST, UNIT_POST, POST_DIMENSION, BUSINESS, BUSINESS_MULTI_UNIT, BUSINESS_LINE, METADATA, LEVEL …
- `OrgManageOrgScopeEnum`（3 常量）：NONE, INSTITUTION, INSTITUTIONS
- `OrgManagerTreeScopeEnum`（3 常量）：NONE, ALL, ORG
- `OrgMetadataTypeEnum`（13 常量）：NONE, TEXT, DATE, SINGLE_OPTION, MULTIPLE_OPTION, SINGLE_UNIT, MULTIPLE_UNIT, SINGLE_MEMBER, MULTIPLE_MEMBER, EXTERNAL_SINGLE_UNIT, EXTERNAL_MULTIPLE_UNIT, EXTERNAL_SINGLE_MEMBER …
- `OrgRoleScopeEnum`（6 常量）：NONE, UNIT, UNITS, SPECIFY_UNIT, SPECIFY_UNITS, SPECIFY_BUSINESS
- `OrgSensitiveFieldEnum`（5 常量）：NONE, FULL_POST, PHONE_NUMBER, EMAIL, OFFICE_NUMBER
- `OrgSensitiveFieldPermissionEnum`（4 常量）：NONE, ALL_VIEW, NO_VIEW, PART_VIEW
- `OrgSyncTypeEnum`（17 常量）：NONE, BATCH_UNITS, BATCH_POSTS, BATCH_MEMBERS, BATCH_JOBS, BATCH_LEVELS, BATCH_MEMBER_POSTS, BATCH_UNIT_METADATA, BATCH_MEMBER_METADATA, BATCH_NATURAL_MEMBERS, TEAMS, BATCH_TEAMS …
- `OutsidePermissionTypeEnum`（4 常量）：NONE, DEFAULT, NO_OUTSIDE_ACCESS, NO_ACCESS
- `OutsideScopeEnum`（5 常量）：NONE, UNIT, UNITS, SPECIFY_UNIT, SPECIFY_UNITS
- `PermissionTypeEnum`（3 常量）：NONE, VIEWING, NO_VIEWING
- `ScopeTypeEnum`（6 常量）：NONE, INSTITUTION, INSTITUTIONS, ONLY_CHILDREN, SPECIFY_INSTITUTION, SPECIFY_INSTITUTIONS
- `TaskStatusEnum`（2 常量）：NONE, COMPLETE
- `UnitTypeEnum`（6 常量）：NONE, INSTITUTION, DEPARTMENT, OUTSIDE_INSTITUTION, OUTSIDE_DEPARTMENT, LOCAL
- `UserTypeEnum`（3 常量）：NONE, MEMBER, EXTERNAL_MEMBER
- `WorkFlowMessageStatusEnum`（3 常量）：NONE, SUCCESS, FAILED
- `OrgDomainTypeEnum`（17 常量）：NONE, INSTITUTION, INSTITUTION_UP, DEPARTMENT, DEPARTMENT_UP, POST, JOB, LEVEL, MEMBER, TEAM, OUTSIDE_INSTITUTION, OUTSIDE_DEPARTMENT …
- `OcipEntityTypeEnum`（8 常量）：NONE, OCIP_VIEW, OCIP_UNIT, OCIP_ACCOUNT, OCIP_DEPARTMENT, UNIT, INSTITUTION, DEPARTMENT
- `OcipMemberPostTypeEnum`（4 常量）：NONE, post_main, post_second, post_concurrent
- `OcipUploadDataScopeEnum`（4 常量）：NONE, ALL, BATCH, INCREMENT
- `OcipUploadDataTypeEnum`（6 常量）：NONE, ACCOUNT, DEPARTMENT, POST, LEVEL, MEMBER
- `OcipUploadModeEnum`（3 常量）：NONE, PACK, SINGLE
- `OcipUploadStatusEnum`（8 常量）：NONE, SUCCESS, UPLOADING, WAITING, STOP, RECEIVED, NORECEIVED, FAIL
- `OrgScopeEnum`（15 常量）：NONE, INSTITUTION, INSTITUTIONS, ONLY_CHILDREN, SPECIFY_INSTITUTION, SPECIFY_INSTITUTIONS, UNIT, UNITS, ONLY_CHILDREN_UNITS, SPECIFY_UNIT, SPECIFY_UNITS, SPECIFY_BUSINESS …
- `OrgScopeOptionEnum`（3 常量）：NONE, IN, NOT_IN
- `OrgScopePropertyEnum`（3 常量）：NONE, UNIT_TYPE, UNIT_METADATA
- `OrgParameterTypeEnum`（5 常量）：NONE, SWITCH, RADIO, MULTIPLE, TEXT
- `ListConditionEnum`（17 常量）：NONE, INSTITUTION, DEPARTMENT, POST, JOB, LEVEL, TEAM, ROLE, MEMBER, UNIT, PARENTUNIT, PARENTINSTITUTION …
- `ListConditionOperatorEnum`（4 常量）：NONE, IN, AND, OR
- `PermissionEnum`（4 常量）：NONE, ORGANIZATION, ORGANIZATION_ADMIN, ALL
- `SearchTypeEnum`（4 常量）：NONE, ALL, MEMBER, UNIT
- `SelectPeopleThemeEnum`（4 常量）：NONE, NORMAL, THEME1, THEME2
- `ExistDataDealTypeEnum`（3 常量）：NONE, SKIP, COVER
- `TeamTypeEnum`（3 常量）：NONE, SYSTEM, PERSONAL
- `OrgTransferAffairTypeEnum`（3 常量）：NONE, DISPOSABLE, DIVIDE
- `OrgTransferAgentOperatorEnum`（5 常量）：NONE, CREATE, EDIT, CANCEL, HYPHEN
- `OrgTransferProcessMethodEnum`（3 常量）：NONE, APPEND, DELETE
- `OrgTransferRecordTypeEnum`（9 常量）：NONE, TODO, AGENT, ORG, BPM, APP, ROLE, ORG_ROLE, PROCESSED_SENT
- `OrgTransferTypeEnum`（3 常量）：NONE, UNIT_METADATA, MEMBER_METADATA
- `DirectionEnum`（3 常量）：NONE, UP, DOWN
- `FieldSelectDataSizeEnum`（3 常量）：NONE, SINGLE, MULTIPLE
- `JoinerEnum`（5 常量）：NONE, IS, BE, BELONG, INSIDE
- `NodeParamEnum`（66 常量）：NONE, FORMULA, CONDITION, NODE_TYPE, MEMBER, SENDER, DEPARTMENT, SENDER_DEPARTMENT, PARENT_DEPARTMENT, FIRST_DEPARTMENT, MANAGER_DEPARTMENT, LEADER_DEPARTMENT …
- `NodeTestEnum`（1 常量）：NONE
- `NodeTypeEnum`（39 常量）：NONE, MEMBER, DEPARTMENT, INSTITUTION, UNIT, POST, NODE, PARAMETER_MEMBER, PARAMETER_DEPARTMENT, PARAMETER_INSTITUTION, PARAMETER_UNIT, PARAMETER_POST …
- `OfUpTypeEnum`（4 常量）：NONE, ROOT, INSTITUTION, FIRST_LEVEL_DEPARTMENT
- `PreMemberPostTypeEnum`（4 常量）：NONE, ALL, MAIN, CONCURRENT
- `ResultTypeEnum`（3 常量）：NONE, TYPE_NORMAL, TYPE_FILE
- `SelectModeEnum`（3 常量）：NONE, ADAPTIVE_MODE, FILE_MODE
- `SortTypeEnum`（5 常量）：NONE, SORT_ASC, SORT_DESC, ENTITY_FIELD, SYSTEM_SEQUENCE_SERIAL
- `WorkFlowOfUpEnum`（4 常量）：NONE, SELECTED, NO_PEOPLE_UP, START_UP
