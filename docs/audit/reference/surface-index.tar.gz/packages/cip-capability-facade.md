# cip-capability-facade：接口与方法签名

> 自动生成，勿手改。`tools/core/platform/emit_package_surfaces.py` 重跑即可。
> 构件 `com.seeyon:cip-capability-facade`（jar `cip-capability-facade-5.3.276.jar`）
> 规模：490 类 / 46 接口 / 0 注解 / 10 枚举 / 32 个关键类 / 4378 方法。
> 签名逐字来自 javap 原文；已去掉 `public` 前缀与 `throws` 子句。

## 一、接口（46）

### `CapabilityManageAppService`（53 方法）

`com.seeyon.cip.capability.api.core.manage.CapabilityManageAppService`

```java
    com.seeyon.boot.transport.PageResponse<com.seeyon.cip.capability.dto.manage.SelectProviderDto> selectPageByConditions(com.seeyon.boot.transport.PageRequest);
    com.seeyon.boot.transport.SingleResponse<java.lang.Boolean> operationEnable(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.manage.SelectProvicerEnableDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Boolean> updateDefaultProvider(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.manage.SelectProvicerEnableDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.cip.capability.dto.manage.ClassifyProviderDto> selectProvidersByEnum(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.provider.enums.CapabilityEnum>);
    default com.seeyon.boot.transport.ListResponse<com.seeyon.cip.capability.dto.manage.ClassifyProviderDto> selectEnableProvidersByEnum(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.provider.enums.CapabilityEnum>);
    default com.seeyon.boot.transport.ListResponse<com.seeyon.cip.capability.dto.manage.ClassifyProviderCloudDto> selectProvidersListByEnum(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.provider.enums.CapabilityEnum>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.capability.dto.manage.SelectProviderDto> selectOptionalProvider(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.cip.capability.dto.manage.ProviderParameterDto> editProviderParams(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> createParamBatch(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.manage.ProviderParameterRequestDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> deleteParam(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Void> refreshProvide();
    com.seeyon.boot.transport.ListResponse<com.seeyon.cip.capability.dto.ocr.OcrActiveXInfoResponse> selectActiveXFunctionByEnum(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.provider.enums.CapabilityEnum>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.capability.dto.manager.CloudConnectPropertiesDto> getLinkProperties();
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.capability.dto.manager.CloudConnectPropertiesDto> getCloudProperties(com.seeyon.boot.transport.SingleRequest<java.lang.Void>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> saveLinkProperties(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.manager.CloudConnectPropertiesDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.openapi.common.message.ApiSingleResponse> sendOpenApiRequest(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.manage.OpenApiSendDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.openapi.common.message.ApiPageResponse> sendOpenApiRequestPage(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.manage.OpenApiSendDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.capability.dto.manage.CloudConnectInfoDto> getCloudConnect(com.seeyon.boot.transport.SingleRequest<java.lang.Void>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.capability.dto.manage.ProviderChannelResponseDto> getCurrentCapabilityChannelInfo(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.manage.ProviderChannelRequestDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.cip.capability.dto.manage.ProviderParameterDto> selectProviderParameter(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.manage.BaseInfoParameterDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.capability.dto.manage.ProviderEnableDto> queryEnableByEnum(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.provider.enums.CapabilityEnum>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.capability.dto.manage.BatchQueryEnableResDto> batchQueryEnableByEnum(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.manage.BatchQueryEnableReqDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.capability.dto.manage.ProviderEnableDto> queryEnable(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.manage.CapabilityNameEnumDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Void> checkFeatureByEnum(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.provider.enums.CapabilityEnum>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.cip.capability.dto.ServiceFeatureDto> selectFeatureByEnum(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.provider.enums.CapabilityEnum>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.cip.capability.dto.manage.CountResultDto> selectCountByEnum(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.manage.CountQueryDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.cip.capability.dto.manage.CountResultDto> selectOpenapiCount(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.manage.OpenapiCountQueryDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.capability.dto.manage.CapabilityCycleCountResultDto> selectCloudCount(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.manage.OpenapiCapabilityQueryDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.capability.dto.manage.CapabilityCycleCountResultDto> selectLocalCloudCount(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.manage.OpenapiCapabilityQueryDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Void> setCapabilityCycleCount(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.manage.CapabilityCycleCountDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Void> setAllCapabilityCycleCount(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.manage.AllCapabilityCycleCountDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Void> rechargeCapabilityCycleCount(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.manage.AllCapabilityCycleCountDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.capability.dto.manage.EventCallbackConfigResultDto> selectCallbackConfig(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.manage.EventCallbackConfigQueryDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.String> refreshEventToken(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.manage.EventCallbackConfigQueryDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Void> modifyEventToken(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.manage.EventCallbackConfigQueryDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Void> authConfigEdit(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.manage.AuthConfigDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.capability.dto.manage.AuthConfigDto> authConfigQuery(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.manage.CountQueryDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.cip.capability.dto.manage.OpeningCapabilityDto> queryUseCount(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.manage.UseCountQueryDto>);
    default com.seeyon.boot.transport.SingleResponse<java.lang.Void> operationEnableChannel(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.manage.OperateChannelEnableDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.capability.dto.manage.ThirdAppInfoDto> queryThirdAppInfo(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.manage.OpenAppQueryDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.cip.capability.dto.manage.QueryParameterResDto> queryParams(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.manage.QueryParameterReqDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.capability.dto.manage.QueryRegisterAppInfoResDto> queryRegisterAppInfo(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.manage.QueryRegisterAppInfoReqDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.capability.dto.manage.QueryFeatureResDto> queryFeature(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.manage.QueryFeatureDto>);
    default com.seeyon.boot.transport.SingleResponse<java.lang.Long> appEnable(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.manage.appchannel.CipAppEnableDto>);
    default com.seeyon.boot.transport.PageResponse<com.seeyon.cip.capability.dto.manage.appchannel.CipAppQueryDto> selectAppPageByConditions(com.seeyon.boot.transport.PageRequest);
    default com.seeyon.boot.transport.SingleResponse<java.lang.Long> createApp(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.manage.appchannel.CipAppCreateDto>);
    default com.seeyon.boot.transport.SingleResponse<java.lang.Integer> updateApp(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.manage.appchannel.CipAppUpdateDto>);
    default com.seeyon.boot.transport.SingleResponse<java.lang.Integer> deleteApp(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    default com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.capability.dto.manage.appchannel.QueryFeatureWithChannelResDto> queryFeatureWithChannelByAbilityEnum(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.manage.appchannel.QueryFeatureWithChannelDto>);
    default com.seeyon.boot.transport.SingleResponse<java.lang.Integer> createAppConfig(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.manage.appchannel.CipAppFeatureProviderCreateInDto>);
    default com.seeyon.boot.transport.SingleResponse<java.lang.Integer> updateAppConfig(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.manage.appchannel.CipAppFeatureProviderCreateInDto>);
    default com.seeyon.boot.transport.SingleResponse<java.util.List<com.seeyon.cip.capability.dto.manage.appchannel.CipAppFeatureProviderDetailDto>> getAppConfig(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    default com.seeyon.boot.transport.ListResponse<com.seeyon.cip.capability.dto.manage.appchannel.CipAppFeatureMappingDto> selectAppFeatureMappingDetails(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
```

### `SignatureAppService`（39 方法）

`com.seeyon.cip.capability.api.common.signature.SignatureAppService`

```java
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.capability.dto.signature.SignatureFileResponseDto> getSignatureViewUrl(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.signature.SignatureFileRequestDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.capability.dto.signature.SignatureDownResDto> downFile(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.signature.SignatureDownReqDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.capability.dto.signature.SignatureSealResDto> getSealInfo(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.signature.SignatureSealReqDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.provider.dto.signature.sign.FileInfoDto> uploadFile(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.provider.dto.signature.sign.UploadFileDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.provider.dto.signature.sign.InitiateSignResultDto> initiateSign(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.provider.dto.signature.sign.InitiateSignDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.provider.dto.signature.sign.InitiateSignResultDto> initiateSignFree(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.provider.dto.signature.sign.InitiateSignFreeDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.provider.dto.signature.org.OrganizationResultDto> createOrg(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.provider.dto.signature.org.OrganizationDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.provider.dto.signature.org.OrganizationResultDto> updateOrg(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.provider.dto.signature.org.OrganizationUpdateDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.provider.dto.signature.org.OrganizationDetailDto> detailOrg(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.provider.dto.signature.org.OrganizationQueryDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.provider.dto.signature.org.UserResultDto> batchCreateUser(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.provider.dto.signature.org.BatchCreateUserDto>);
    com.seeyon.boot.transport.PageResponse<com.seeyon.cip.provider.dto.signature.template.TemplateInfoDto> selectPageByConditions(com.seeyon.boot.transport.PageDtoRequest<com.seeyon.cip.provider.dto.signature.template.TemplatePageDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.provider.dto.signature.template.TemplateControlResultDto> getTemplateContents(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.provider.dto.signature.template.TemplateBaseDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.provider.dto.signature.template.GeneratePdfResultDto> generatePdfFile(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.provider.dto.signature.template.GeneratePdfDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.provider.dto.signature.sign.SignAreaResultDto> signToolsConfig(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.provider.dto.signature.sign.SignAreaConfigDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.provider.dto.signature.sign.SignAreaDetailDto> signToolsConfigDetail(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.provider.dto.signature.sign.SignAreaSelectDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.provider.dto.signature.sign.VerifySignatureResultDto> verifySignature(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.provider.dto.signature.sign.VerifySignatureDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.provider.dto.signature.org.SuccessData> userUpdate(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.provider.dto.signature.org.UserUpdateDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.provider.dto.signature.org.UserUpdateDto> userDetail(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.provider.dto.signature.org.UserQueryDto>);
    com.seeyon.boot.transport.PageResponse<com.seeyon.cip.provider.dto.signature.seal.SealDataDto> sealList(com.seeyon.boot.transport.PageDtoRequest<com.seeyon.cip.provider.dto.signature.seal.SealQueryDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.provider.dto.signature.sign.FileDownloadDto> downloadFile(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.provider.dto.signature.sign.FileInfoDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.provider.dto.signature.sign.InvalidFlowResDto> invalidFlow(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.provider.dto.signature.sign.InvalidFlowReqDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.provider.dto.signature.org.OrganizationResultDto> createOuterOrg(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.provider.dto.signature.org.outer.OuterOrganizationDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.provider.dto.signature.org.OrganizationResultDto> updateOuterOrg(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.provider.dto.signature.org.outer.OuterOrganizationUpdateDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.provider.dto.signature.org.outer.OuterOrganizationDetailDto> detailOuterOrg(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.provider.dto.signature.org.OrganizationQueryDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.provider.dto.signature.org.UserResultDto> batchCreateOuterUser(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.provider.dto.signature.org.outer.OuterBatchCreateUserDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.provider.dto.signature.org.SuccessData> outerUserUpdate(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.provider.dto.signature.org.outer.OuterUserUpdateDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.provider.dto.signature.org.outer.OuterUserUpdateDto> outerUserDetail(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.provider.dto.signature.org.UserQueryDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.provider.dto.signature.org.DeleteInnerUsersResDto> deleteInnerUsers(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.provider.dto.signature.org.DeleteInnerUsersReqDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.provider.dto.signature.org.QuerySsoResDto> querySsoUrl(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.provider.dto.signature.org.QuerySsoReqDto>);
    default com.seeyon.boot.transport.PageResponse<com.seeyon.cip.provider.dto.signature.seal.SealSignerDataDto> sealSigners(com.seeyon.boot.transport.PageDtoRequest<com.seeyon.cip.provider.dto.signature.seal.SealSignerQueryDto>);
    default com.seeyon.boot.transport.SingleResponse<java.lang.String> stamp(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.provider.dto.signature.seal.ThreePartySealIntegrationDto>);
    default com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.provider.dto.signature.seal.ContractResponseDto> withfileupload(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.provider.dto.signature.seal.ThreePartySealIntegrationDto>);
    default com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.capability.dto.signature.AgainContractResponse> invalid(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.provider.dto.signature.seal.ThreePartySealIntegrationDto>);
    default com.seeyon.boot.transport.SingleResponse recall(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.provider.dto.signature.seal.ThreePartySealIntegrationDto>);
    default com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.provider.dto.signature.contractlock.SealListResultDto> sealGetList(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.provider.dto.signature.seal.ThreePartySealIntegrationDto>);
    default com.seeyon.boot.transport.SingleResponse<java.lang.String> preSign(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.provider.dto.signature.sign.PreSignDto>);
    default com.seeyon.boot.transport.SingleResponse<java.lang.String> initPreSign(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.provider.dto.signature.sign.InitPreSignDto>);
    default com.seeyon.boot.transport.SingleResponse<java.lang.String> verifySeal(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.provider.dto.signature.sign.VerifySealDto>);
    default com.seeyon.boot.transport.SingleResponse finish(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.provider.dto.signature.contractlock.ContractLockRequestDto>);
```

### `DocOnlineAppService`（28 方法）

`com.seeyon.cip.capability.api.common.doc.DocOnlineAppService`

```java
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.capability.dto.doc.DocViewUrlDto> getOfficeViewUrl(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.doc.DocViewDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.capability.dto.doc.CompositeViewResDto> getCompositeViewUrl(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.doc.CompositeViewDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.capability.dto.doc.LatestPicViewResDto> getLatestPicViewUrl(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.doc.LatestPicViewDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.capability.dto.doc.DocEditUrlDto> getOfficeEditUrl(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.doc.DocEditDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.capability.dto.doc.DocFileConvertStateDto> cpsOfficeConvert(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.doc.DocFileConvertDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.capability.dto.doc.DocFileConvertBatchStateDto> cpsOfficeBatchConvert(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.doc.DocFileBatchConvertDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.capability.dto.doc.DocFileSingleConvertResDto> cpsOfficeConvertPdfToSinglePng(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.doc.DocFileSingleConvertDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.capability.dto.doc.DocFileSingleConvertResDto> cpsOfficeConvertPdfToHtml(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.doc.DocFileSingleConvertDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.capability.dto.doc.DocFileConvertStateDto> cpsOfficeOperateClean(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.doc.DocFileOperateCleanDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.capability.dto.doc.DocFileConvertStateDto> cpsOfficeOperateTextWatermark(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.doc.DocFileOperateTextWatermarkDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.capability.dto.doc.DocFileConvertBatchStateDto> cpsOfficeOperateBatchTextWatermark(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.doc.DocFileOperateBatchTextWatermarkDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.capability.dto.doc.DocFileConvertStateDto> cpsOfficeOperateImageWatermark(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.doc.DocFileOperateImageWatermarkDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.capability.dto.doc.DocFileInfoResponseDto> getLatestDocFileInfoByStorageKey(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.doc.DocFileInfoRequestDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.capability.dto.doc.DocFileInfoBatchResponseDto> batchGetLatestDocFileInfoByStorageKey(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.doc.DocFileInfoBatchRequestDto>);
    com.seeyon.boot.transport.PageResponse<com.seeyon.cip.capability.dto.doc.DocFileVersionPageResponseDto> selectDocFileVersionPage(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.doc.DocFileVersionPageRequestDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.capability.dto.doc.DocAuthorityInfoResponseDto> getAuthorityInfo(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.doc.DocAuthorityInfoRequestDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.capability.dto.doc.DocFileConvertStateDto> cpsOfficeBookmark(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.doc.DocQueryBookmarkDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.capability.dto.doc.DocFileConvertStateDto> cpsWrapHeader(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.doc.DocWrapHeaderDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.capability.dto.doc.DocFileConvertStateDto> setBookmarkPermissions(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.doc.DocSetBookmarkPermissionsDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.capability.dto.doc.DocPdfEncryptResponseDto> encryptPdfProtection(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.doc.DocPdfEncryptRequestDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.capability.dto.doc.DocFileConvertStateDto> cpsMerge(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.doc.DocMergeDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.capability.dto.doc.DocFileConvertStateDto> cpsTaskQuery(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.doc.DocQueryTaskDto>);
    default com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.capability.dto.doc.NotifyResDto> onNotify(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.doc.NotifyReqDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.capability.dto.doc.DocFileUrlResDto> getFileUrl(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.doc.DocFileUrlReqDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.capability.dto.doc.DocFileConvertStateDto> extractPictures(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.doc.DocExtractPicReqDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.capability.dto.doc.DocUserNotifyResDto> userNotify(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.doc.DocUserNotifyReqDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.capability.dto.doc.DocCheckContentResponseDto> checkContent(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.doc.DocCheckContentRequestDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.capability.dto.doc.DocEncryptFileResponseDto> checkAndEncrypt(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.doc.DocEncryptFileRequestDto>);
```

### `IntelligentMissiveAppService`（26 方法）

`com.seeyon.cip.capability.api.common.missive.IntelligentMissiveAppService`

```java
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.capability.dto.missive.ExtractingTaskResDto> createExtractingTask(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.missive.ExtractingTaskReqDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.capability.dto.missive.ExtractingDetailResDto> queryExtractingDetail(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.missive.ExtractingDetailReqDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.capability.dto.missive.DiffRuleResDto> queryDiffRule(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.missive.DiffRuleReqDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.capability.dto.missive.DiffTaskResDto> createDocDiffTask(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.missive.DiffTaskReqDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.capability.dto.missive.DiffPageResDto> queryDocDiffPage(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.missive.DiffPageReqDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.capability.dto.missive.DiffDetailResDto> queryDocDiffDetail(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.missive.DiffDetailReqDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.capability.dto.missive.DiffDetailViewResDto> queryDocDiffView(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.missive.DiffDetailReqDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.capability.dto.missive.CardRuleResDto> queryCardRule(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.missive.CardRuleReqDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.capability.dto.missive.ReviewTaskResDto> createReviewTask(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.missive.ReviewTaskReqDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.capability.dto.missive.ReviewDetailResDto> queryReviewDetail(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.missive.ReviewDetailReqDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.capability.dto.missive.TableTaskResDto> createTableTask(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.missive.TableTaskReqDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.capability.dto.missive.TableDetailResDto> queryTableDetail(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.missive.TableDetailReqDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.capability.dto.missive.SettingTaskResDto> createSettingByTemplate(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.missive.SettingTaskReqDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.capability.dto.missive.ProofreadTaskResDto> createOnlineProofread(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.missive.ProofreadTaskReqDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.capability.dto.missive.ProofreadTaskResDto> queryProofreadDetail(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.missive.ProofreadTaskDetailReqDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.capability.dto.missive.SensitiveWordResDto> checkSensitiveWord(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.missive.SensitiveWordReqDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.capability.dto.missive.UploadTempFileResDto> uploadTempFile(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.missive.UploadTempFileReqDto>);
    com.seeyon.boot.transport.PageResponse<com.seeyon.cip.capability.dto.missive.RecommendResDto> createRecommend(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.missive.RecommendReqDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.capability.dto.missive.IntelligentWriteResDto> createWrite(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.missive.IntelligentWriteReqDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.capability.dto.missive.IntelligentWriteQueryResDto> queryWrite(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.missive.IntelligentWriteQueryReqDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.capability.dto.missive.IntelligentPushOfficialResDto> pushOfficial(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.missive.IntelligentPushOfficialReqDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.capability.dto.missive.AssistReadingResDto> assistReading(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.missive.AssistReadingReqDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.capability.dto.missive.QueryResultResDto> queryResultByTaskId(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.missive.QueryResultReqDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.capability.dto.missive.ReadingDetailResDto> readingDetail(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.missive.ReadingDetailReqDto>);
    com.seeyon.boot.transport.PageResponse<com.seeyon.cip.capability.dto.missive.RetrievalResDto> retrieval(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.missive.RetrievalReqDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.capability.dto.missive.RelatedResDto> queryRelated(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.missive.RelatedReqDto>);
```

### `EnterpriseCreditAppService`（25 方法）

`com.seeyon.cip.capability.api.common.credit.EnterpriseCreditAppService`

```java
    com.seeyon.boot.transport.PageResponse<com.seeyon.cip.capability.dto.credit.EnterpriseBasicInfoResponse> pageEnterpriseInfo(com.seeyon.boot.transport.PageRequest);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.capability.dto.credit.EnterpriseBasicBusinessInfoResponseDto> getBasicBusinessInfo(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.credit.EnterpriseCreditRequestDto>);
    com.seeyon.boot.transport.PageResponse<com.seeyon.cip.capability.dto.credit.EnterpriseBasicInfoResponse> pageEnterpriseInfo(com.seeyon.boot.transport.PageDtoRequest<com.seeyon.cip.capability.dto.credit.EnterpriseCreditRequestDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.provider.dto.credit.EnterpriseBasicInfoDto> getBasicInfo(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.provider.dto.credit.CreditRequestDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.provider.dto.credit.EnterprisePartnersDto> getPartners(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.provider.dto.credit.CreditRequestDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.provider.dto.credit.EnterpriseCourtNoticeDto> getCourtNotice(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.provider.dto.credit.CreditRequestDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.provider.dto.credit.EnterpriseCaseDetailDto> getCaseDetailList(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.provider.dto.credit.CreditRequestDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.provider.dto.credit.EnterpriseAdminPunishDto> getAdminPunish(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.provider.dto.credit.CreditRequestDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.provider.dto.credit.EnterpriseEnvpDto> getEnvp(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.provider.dto.credit.CreditRequestDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.provider.dto.credit.EnterpriseEnvpDetailDto> getEnvpDetail(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.provider.dto.credit.CreditRequestDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.provider.dto.credit.EnterpriseBiddingDto> getBiddingList(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.provider.dto.credit.CreditRequestDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.provider.dto.credit.EnterpriseBiddingDetailDto> getBiddingDetail(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.provider.dto.credit.CreditRequestDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.provider.dto.credit.EnterpriseAdministrativeLicenseDto> getAdministrativeLicenseList(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.provider.dto.credit.CreditRequestDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.provider.dto.credit.EnterpriseEntCreditRatingDto> getEntCreditRating(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.provider.dto.credit.CreditRequestDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.cip.provider.dto.credit.EnterpriseTaxpayerDto> getTaxpayerList(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.provider.dto.credit.CreditRequestDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.provider.dto.credit.EnterpriseTrademarkDto> getTrademark(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.provider.dto.credit.CreditRequestDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.provider.dto.credit.EnterpriseTrademarkDetailDto> getTrademarkDetail(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.provider.dto.credit.CreditRequestDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.provider.dto.credit.EnterprisePatentDto> getPatentList(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.provider.dto.credit.CreditRequestDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.provider.dto.credit.EnterprisePatentDetailDto> getPatentDetail(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.provider.dto.credit.CreditRequestDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.provider.dto.credit.EnterpriseCopyrightSoftDto> getCopyrightSoft(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.provider.dto.credit.CreditRequestDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.provider.dto.credit.EnterpriseCertificateDto> getCertificate(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.provider.dto.credit.CreditRequestDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.provider.dto.credit.EnterpriseProjectDto> getProject(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.provider.dto.credit.CreditRequestDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.provider.dto.credit.EnterpriseFinancingDto> getFinancing(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.provider.dto.credit.CreditRequestDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.provider.dto.credit.EnterpriseShellEntInfoDto> getShellEntInfoByName(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.provider.dto.credit.CreditRequestDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.provider.dto.credit.EntJusticeScoreDto> getEntJusticeScore(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.provider.dto.credit.CreditRequestExtendDto>);
```

### `OcrAppService`（20 方法）

`com.seeyon.cip.capability.api.common.ocr.OcrAppService`

```java
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.capability.dto.ocr.card.IdCardFrontResponse> getIdCardFrontData(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.ocr.OcrRequestDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.capability.dto.ocr.card.IdCardBackResponse> getIdCardBackData(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.ocr.OcrRequestDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.capability.dto.ocr.card.BankCardResponse> getBankCardData(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.ocr.OcrRequestDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.capability.dto.ocr.card.BusinessCardResponse> getBusinessCardData(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.ocr.OcrRequestDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.capability.dto.ocr.card.BusinessLicenseResponse> getBusinessLicenseData(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.ocr.OcrRequestDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.capability.dto.ocr.finance.TaxInvoiceResponse> getTaxInvoiceData(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.ocr.OcrRequestDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.capability.dto.ocr.finance.TaxInvoiceResponse> getTaxRollInvoiceData(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.ocr.OcrRequestDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.capability.dto.ocr.finance.TrainTicketResponse> getTrainTicketData(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.ocr.OcrRequestDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.capability.dto.ocr.finance.TaxiReceiptResponse> getTaxiReceiptData(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.ocr.OcrRequestDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.capability.dto.ocr.finance.AirTicketResponse> getAirTicketData(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.ocr.OcrRequestDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.capability.dto.ocr.finance.TollInvoiceResponse> getTollInvoiceData(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.ocr.OcrRequestDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.capability.dto.ocr.finance.BusTicketResponse> getBusTicketData(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.ocr.OcrRequestDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.capability.dto.ocr.finance.QuotaInvoiceResponse> getQuotaInvoiceData(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.ocr.OcrRequestDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.capability.dto.ocr.finance.WayBillResponse> getWaybillData(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.ocr.OcrRequestDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.capability.dto.ocr.finance.GeneralInVoiceResponse> getGeneralInVoiceData(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.ocr.OcrRequestDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.capability.dto.ocr.custom.CustomOcrResponse> getCustomData(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.ocr.OcrRequestDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.capability.dto.ocr.finance.InvoiceVerificationResponse> verificationInvoice(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.ocr.InvoiceVerificationRequestDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.capability.dto.CipBaseResponse> getCommonParentData(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.ocr.OcrRequestDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.capability.dto.ocr.OcrCommonResponse> getCommonData(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.ocr.OcrRequestDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.capability.dto.ocr.ExtractContentResDto> extractContent(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.ocr.ExtractContentReqDto>);
```

### `VideoMeetingAppService`（20 方法）

`com.seeyon.cip.capability.api.common.video.VideoMeetingAppService`

```java
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.provider.dto.video.response.VideoMeetingOutDto> createVideoMeeting(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.provider.dto.video.request.VideoMeetingCreateDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.provider.dto.video.response.VideoMeetingOutDto> createPersonalVideoMeeting(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.provider.dto.video.request.VideoMeetingPersonalCreateDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.provider.dto.video.response.VideoMeetingOutDto> updateVideoMeeting(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.provider.dto.video.request.VideoMeetingUpdateDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Void> cancelVideoMeeting(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.provider.dto.video.request.VideoMeetingOperateDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Void> finishVideoMeeting(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.provider.dto.video.request.VideoMeetingOperateDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.provider.dto.video.response.VideoMeetingOutDto> getMeetingDetail(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.provider.dto.video.request.VideoMeetingDetailDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.provider.dto.video.response.VideoMeetingAuthOutDto> auth(com.seeyon.boot.transport.SingleRequest<java.lang.String>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.cip.provider.dto.video.response.VideoMeetingRoomDto> selectVideoMeetingRoom(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.provider.dto.video.request.VideoMeetingRoomSelectDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.cip.provider.dto.video.response.VideoMeetingRoomMemberDto> selectMemberMeetingRoom(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.provider.dto.video.request.VideoMeetingRoomSelectDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Void> updateVideoMeetingRoom(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.provider.dto.video.request.VideoMeetingRoomUpdateDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Void> deleteVideoMeetingRoom(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.provider.dto.video.request.VideoMeetingRoomOperateDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Void> allotVmwareMeetingRoom(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.provider.dto.video.request.VideoMeetingRoomAllotDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Void> recycleVmwareMeetingRoom(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.provider.dto.video.request.VideoMeetingRoomOperateDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.provider.dto.video.VideoMeetingUserDto> addMeetingUser(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.provider.dto.video.VideoMeetingUserDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.provider.dto.video.response.VideoMeetingEndedDetailDto> getEndedMeetingDetail(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.provider.dto.video.request.VideoMeetingEndedSelectDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.provider.dto.video.response.VideoMeetingRecordDto> getMeetingRecord(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.provider.dto.video.request.VideoMeetingRecordSelectDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Void> addMeetingRoomResource(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.provider.dto.video.request.VideoMeetingRoomResourceDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Void> updateMeetingRoomResource(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.provider.dto.video.request.VideoMeetingRoomResourceDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Void> refreshMeetingRoomResource(com.seeyon.boot.transport.SingleRequest<java.lang.Void>);
    <T, Res> Res eventCallback(com.seeyon.boot.transport.SingleRequest<T>);
```

### `BusinessTripAppService`（14 方法）

`com.seeyon.cip.capability.api.common.trip.BusinessTripAppService`

```java
    com.seeyon.boot.transport.SingleResponse<java.lang.Void> departmentSync(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.provider.dto.trip.TripDeptSyncRequestDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Void> isvUserSync(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.provider.dto.trip.TripUserSyncRequestDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.provider.dto.trip.TripCitySyncResponseDto> isvCitySync(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.provider.dto.trip.TripCitySyncRequestDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.String> addressGetBook(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.provider.dto.trip.TripAddressGetBookRequestDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.String> addressGetOrder(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.provider.dto.trip.TripAddressGetOrderRequestDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.String> addressGetManager(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.provider.dto.trip.TripAddressGetManagerRequestDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.String> addressGetH5(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.provider.dto.trip.TripAddressGetH5RequestDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.provider.dto.trip.TripCostCenterQueryResponseDto> costCenterQuery(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.provider.dto.trip.TripCostCenterQueryRequestDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.provider.dto.trip.TripInvoiceQueryResponseDto> invoiceSearch(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.provider.dto.trip.TripInvoiceQueryRequestDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.provider.dto.trip.TripApplyAddResponseDto> applyAdd(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.provider.dto.trip.TripApplyAddRequestDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.provider.dto.trip.TripApplyAddResponseDto> applyApprove(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.provider.dto.trip.TripApplyApproveRequestDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.provider.dto.trip.TripApplyAddResponseDto> exceedApplySync(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.provider.dto.trip.TripExceedApplySyncRequestDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.provider.dto.trip.TripApplyAddResponseDto> commonApplySync(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.provider.dto.trip.TripCommonApplySyncRequestDto>);
    <Res> Res eventCallback(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.trip.EventMsgDto>);
```

### `ShortMessageTemplateAppService`（14 方法）

`com.seeyon.cip.capability.api.core.sms.ShortMessageTemplateAppService`

```java
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.capability.dto.sms.ShortMessageProviderTemplateDto> createShortMessageTemplate(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.sms.ShortMessageTemplateDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.capability.dto.sms.ShortMessageProviderTemplateDto> createSMSTemplate(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.sms.ShortMessageTemplateDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> updateTemplate(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.sms.ShortMessageTemplateDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> setTemplateSign(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.sms.SmsSetSignDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.capability.dto.sms.ShortMessageTemplateDto> selectTemplateById(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.capability.dto.sms.ShortMessageTemplateDto> selectTemplateByCode(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.provider.dto.sms.SmsTemplateQueryDto>);
    com.seeyon.boot.transport.PageResponse<com.seeyon.cip.capability.dto.sms.ShortMessageStorehouseDto> selectPageStoreLibrary(com.seeyon.boot.transport.PageRequest);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> deleteTemplateById(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> deleteTemplateByIds(com.seeyon.boot.transport.SingleRequest<java.util.List<java.lang.Long>>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> updateShortMessageTemplate(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.sms.ShortMessageTemplateDto>);
    com.seeyon.boot.transport.PageResponse<com.seeyon.cip.capability.dto.sms.ShortMessageTemplateDto> selectPageByConditions(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.sms.SmsSearchDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.cip.capability.dto.info.CapabilityEnumItemDto> selectTemplateTypeListByConditions(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.sms.SmsSearchDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Boolean> checkTemplateCode(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.sms.RepeatTemplateCodeRequestDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.cip.capability.dto.sms.LanguageDto> getLanguage();
```

### `DocCallBackAppService`（12 方法）

`com.seeyon.cip.capability.api.common.doc.DocCallBackAppService`

```java
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.capability.dto.doc.DocCallbackDto> fileInfo(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.doc.DocFileInfoDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.capability.dto.doc.DocCallbackDto> userInfo(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.doc.DocFileInfoDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.capability.dto.doc.DocCallbackDto> editFileOnline(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.doc.DocFileInfoDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.capability.dto.doc.DocCallbackDto> editFileSave(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.doc.DocFileInfoDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.capability.dto.doc.DocCallbackDto> editFileVersion(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.doc.DocFileInfoDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.capability.dto.doc.DocCallbackDto> editFileRename(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.doc.DocFileInfoDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.capability.dto.doc.DocCallbackDto> editOnNotify(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.doc.DocFileInfoDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.capability.dto.doc.DocCallbackDto> editUserAuth(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.doc.DocFileInfoDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.capability.dto.doc.DocCallbackDto> editInfo(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.doc.DocFileInfoDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.capability.dto.doc.DocCallbackDto> editFileHistory(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.doc.DocFileInfoDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.capability.dto.doc.DocCallbackDto> editFileNotify(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.doc.DocFileInfoDto>);
    void fileConvert(com.seeyon.boot.transport.SingleRequest<java.util.Map<java.lang.String, java.lang.Object>>);
```

### `ShortMessageSignAppService`（12 方法）

`com.seeyon.cip.capability.api.core.sms.ShortMessageSignAppService`

```java
    com.seeyon.boot.transport.SingleResponse<java.lang.Long> createShortMessageSign(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.sms.ShortMessageSignDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Long> createSmsSign(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.sms.SmsSignCloudDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> updateTemplateSign(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.sms.ShortMessageSignDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> updateSmsSign(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.sms.SmsSignCloudDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> updateShortMessageSign(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.sms.ShortMessageSignDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Boolean> checkRepeatSignName(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.sms.RepeatSignRequestDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.capability.dto.sms.ShortMessageSignDto> selectRecentTimeSign(com.seeyon.boot.transport.SingleRequest<java.lang.Void>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.cip.capability.dto.sms.ShortMessageSignDto> selectValidSign(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.sms.SmsSearchDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> deleteShortMessageSign(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.PageResponse<com.seeyon.cip.capability.dto.sms.ShortMessageSignDto> selectPageSignByConditions(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.sms.SmsSearchDto>);
    com.seeyon.boot.transport.PageResponse<com.seeyon.cip.capability.dto.sms.ShortMessageSignDto> exportSignByConditions(com.seeyon.boot.transport.PageRequest);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.capability.dto.sms.ShortMessageSignDto> selectSignById(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
```

### `BankpayAppService`（11 方法）

`com.seeyon.cip.capability.api.common.bankpay.BankpayAppService`

```java
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.capability.dto.bankpay.account.BalanceQueryRespDto> balanceQuery(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.bankpay.account.BalanceQueryReqDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.capability.dto.bankpay.payment.PaymentTransferRespDto> paymentTransfer(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.bankpay.payment.PaymentTransferReqDto>);
    com.seeyon.boot.transport.PageResponse<com.seeyon.cip.capability.dto.bankpay.account.AccountDetailRespDto> accountDetail(com.seeyon.boot.transport.PageDtoRequest<com.seeyon.cip.capability.dto.bankpay.account.AccountDetailReqDto>);
    com.seeyon.boot.transport.PageResponse<com.seeyon.cip.capability.dto.bankpay.account.AccountSummaryRespDto> accountSummary(com.seeyon.boot.transport.PageDtoRequest<com.seeyon.cip.capability.dto.bankpay.account.AccountDetailReqDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.capability.dto.bankpay.account.AccountInDetailRespDto> accountInDetail(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.bankpay.account.AccountInDetailReqDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.capability.dto.bankpay.payment.ExpenseRespDto> expensesFinance(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.bankpay.payment.ExpenseReqDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.cip.capability.dto.bankpay.other.CityCodeComparisonTableDownloadRespDto> cityCodeComparisonTableDownload(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.bankpay.other.CityCodeComparisonTableDownloadReqDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.cip.capability.dto.bankpay.other.CurrencyCodeComparisonTableDownloadRespDto> currencyCodeComparisonTableDownload(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.bankpay.other.CurrencyCodeComparisonTableDownloadReqDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.cip.capability.dto.bankpay.other.PaymentBankInformationRespDto> paymentBankInformation(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.bankpay.other.PaymentBankInformationReqDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.capability.dto.bankpay.other.AccountNameCheckRespDto> accountNameCheck(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.bankpay.other.AccountNameCheckReqDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.capability.dto.bankpay.other.TransactionStatusQueryRespDto> transactionStatusQuery(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.bankpay.other.TransactionStatusQueryReqDto>);
```

### `ContractsAppService`（11 方法）

`com.seeyon.cip.capability.api.common.econtracts.ContractsAppService`

```java
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.capability.dto.econtracts.response.PersonalCertificateResponse> processPersonalCertificate(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.econtracts.request.PersonalCertificateRequestDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.capability.dto.econtracts.response.PersonCertificateInfoResponse> processPersonCertificateInfo(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.econtracts.request.PersonalCertificateRequestDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.capability.dto.econtracts.response.CompanyCertificateResponse> processEnterpriseCertificate(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.econtracts.request.EnterpriseCertificateRequestDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.capability.dto.econtracts.response.BpmTemplateValidCheckResponse> processBpmTemplateValidCheck(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.econtracts.request.BpmTemplateValidCheckRequestDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.capability.dto.econtracts.response.ContractsUploadResponse> processFileUpload(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.econtracts.request.FileUploadRequestDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.capability.dto.econtracts.response.SignTaskUrlResponse> processSignTaskCreate(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.econtracts.request.SignTaskCreateRequestDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.capability.dto.econtracts.response.SignTaskUrlResponse> processSignTaskUrl(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.econtracts.request.SignTaskRequestDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.capability.dto.econtracts.response.SignTaskDetailResponse> processSignTaskDetails(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.econtracts.request.SignTaskRequestDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.capability.dto.econtracts.response.SignTaskExternalStatusResponse> processSignTaskExternal(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.econtracts.request.SignTaskRequestDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.capability.dto.econtracts.response.SignTaskFileResponse> processSignTaskFile(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.econtracts.request.SignTaskRequestDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.capability.dto.econtracts.response.SignTaskCancelResponse> processSignTaskCancel(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.econtracts.request.SignTaskRequestDto>);
```

### `EmailPrivateAppService`（11 方法）

`com.seeyon.cip.capability.api.common.email.EmailPrivateAppService`

```java
    com.seeyon.boot.transport.SingleResponse<java.lang.Void> insertOrUpdateEmailConfig(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.email.CipEmailConfigDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Void> deleteEmailConfig();
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.capability.dto.email.CipEmailConfigDto> getCompanySystemEmail();
    com.seeyon.boot.transport.SingleResponse<java.lang.Void> addEmailTemplate(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.email.CipEmailTemplateDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Void> modifyEmailTemplate(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.email.CipEmailTemplateDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.capability.dto.email.CipEmailTemplateDto> selectEmailTemplate(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Void> deleteEmailTemplate(com.seeyon.boot.transport.SingleRequest<java.lang.String>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> deleteEmailTemplates(com.seeyon.boot.transport.SingleRequest<java.util.List<java.lang.Long>>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.capability.dto.email.EmailSendResultDto> testSendEmail(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.email.EmailConfigTestDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Void> insertOrUpdateEmailLimitConfig(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.email.CipEmailLimitConfigDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.capability.dto.email.CipEmailLimitConfigDto> getEmailLimit();
```

### `MobilePluginAppletAppService`（11 方法）

`com.seeyon.cip.capability.api.common.mobileplugin.MobilePluginAppletAppService`

```java
    com.seeyon.boot.transport.SingleResponse<java.lang.String> receiveTicket(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.mobileplugin.applet.MobilePluginAppletReceiveTicketDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.capability.dto.mobileplugin.applet.MobilePluginAppletOpenQueryAuthResultDto> bindAuth(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.mobileplugin.applet.MobilePluginAppletOpenQueryDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.String> authUrl(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.mobileplugin.applet.MobilePluginAppletOpenPreAuthDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.cip.capability.dto.mobileplugin.applet.MobilePluginAppletCodeTemplateDto> templateList(com.seeyon.boot.transport.SingleRequest<java.lang.String>)
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.capability.dto.mobileplugin.applet.MobilePluginAppletOpenResultDto> uploadCode(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.mobileplugin.applet.MobilePluginAppletOpenCommitDto>)
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.capability.dto.mobileplugin.applet.MobilePluginAppletOpenResultDto> privacySetting(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.mobileplugin.applet.MobilePluginAppletOpenQueryDto>)
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.capability.dto.mobileplugin.applet.MobilePluginAppletOpenAuditResultDto> submitAudit(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.mobileplugin.applet.MobilePluginAppletOpenQueryDto>)
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.capability.dto.mobileplugin.applet.MobilePluginAppletOpenAuditStatusDto> getAuditStatus(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.mobileplugin.applet.MobilePluginMobilePluginAppletOpenAuditQueryDto>)
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.capability.dto.mobileplugin.applet.MobilePluginAppletOpenResultDto> undoCodeAudit(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.mobileplugin.applet.MobilePluginAppletOpenCommonDto>)
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.capability.dto.mobileplugin.applet.MobilePluginAppletOpenResultDto> releaseAudited(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.mobileplugin.applet.MobilePluginAppletOpenCommonDto>)
    com.seeyon.boot.transport.SingleResponse<java.lang.String> queryBindAuth(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.mobileplugin.applet.MobilePluginAppletOpenQueryDto>);
```

### `PhysicalSealAppService`（10 方法）

`com.seeyon.cip.capability.api.common.physical.PhysicalSealAppService`

```java
    com.seeyon.boot.transport.SingleResponse<java.lang.Void> syncDept(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.provider.dto.physicalseal.PhysicalSealDeptDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Void> syncMember(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.provider.dto.physicalseal.PhysicalSealMemberDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.String> applyAuthorize(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.provider.dto.physicalseal.PhysicalSealApplyDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.String> queryApplyRecord(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.provider.dto.physicalseal.PhysicalSealApplyIdDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Void> cancelApply(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.provider.dto.physicalseal.PhysicalSealApplyIdDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.provider.dto.physicalseal.PhysicalSealsDto> querySeals(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.provider.dto.physicalseal.PhysicalSealEmptyDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.provider.dto.physicalseal.PhysicalSealImagesDto> getImageByApplyId(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.provider.dto.physicalseal.PhysicalSealApplyIdDto>);
    com.seeyon.boot.transport.SingleResponse<java.util.List<com.seeyon.cip.provider.dto.physicalseal.PhysicalSealFileDto>> getImage(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.provider.dto.physicalseal.PhysicalSealImageDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.provider.dto.physicalseal.PhysicalSealReWriteDto> reWrite(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.provider.dto.physicalseal.PhysicalSealReWriteDto>);
    <Res> Res eventCallback(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.provider.dto.physicalseal.PhysicalSealReWriteDto>);
```

### `EmailAppService`（9 方法）

`com.seeyon.cip.capability.api.common.email.EmailAppService`

```java
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.capability.dto.email.EmailSendResultDto> sendNormalEmail(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.email.EmailDetailsDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.capability.dto.email.EmailSendResultDto> sendNormalEmailByAccount(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.email.EmailAppointAccountDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.capability.dto.email.EmailSendResultDto> sendPersonalEmail(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.email.EmailDetailsDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.capability.dto.email.EmailSendResultDto> testSendPersonalEmail(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.email.CipEmailUserAccountTestDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> insertOrUpdate(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.email.CipEmailUserAccountDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.capability.dto.email.CipEmailUserAccountDto> findCipEmailUserAccount(com.seeyon.boot.transport.SingleRequest<java.lang.Void>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.capability.dto.email.EmailSendResultDto> sendTemplateEmail(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.email.EmailTemplateSendDto>);
    com.seeyon.boot.transport.PageResponse<com.seeyon.cip.capability.dto.email.CipEmailTemplateDto> selectPageEmailTemplate(com.seeyon.boot.transport.PageRequest);
    com.seeyon.boot.transport.SingleResponse<java.lang.String> captchaEmail(com.seeyon.boot.transport.SingleRequest<java.lang.String>);
```

### `InvoiceAppService`（9 方法）

`com.seeyon.cip.capability.api.common.invoice.InvoiceAppService`

```java
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.capability.dto.invoice.response.InvoiceOutDto> getOcrInvoiceData(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.invoice.request.InvoiceOcrDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.capability.dto.invoice.response.InvoiceOutDto> getOcrAsyncResult(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.invoice.request.InvoiceOcrAsyncDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.capability.dto.invoice.response.InvoiceOutItemDto> getOcrInvoiceSingle(com.seeyon.boot.transport.SingleRequest<java.lang.String>);
    com.seeyon.boot.transport.SingleResponse<java.lang.String> verificationInvoice(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.invoice.request.InvoiceCheckDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.capability.dto.invoice.response.InvoiceCheckOutDto> batchGetInvoice(com.seeyon.boot.transport.SingleRequest<java.lang.String>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.capability.dto.invoice.response.InvoiceCheckOutItemDto> scanCodeIdentifyInvoice(com.seeyon.boot.transport.SingleRequest<java.lang.String>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.capability.dto.invoice.response.InvoiceCheckOutItemDto> invoiceOcrAndCheck(com.seeyon.boot.transport.SingleRequest<java.lang.String>);
    com.seeyon.boot.transport.PageResponse<com.seeyon.cip.capability.dto.invoice.response.InvoiceOcrPageResDto> queryOcrPage(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.invoice.request.InvoiceOcrPageReqDto>);
    com.seeyon.boot.transport.PageResponse<com.seeyon.cip.capability.dto.invoice.response.InvoiceCheckPageResDto> queryCheckPage(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.invoice.request.InvoiceCheckPageReqDto>);
```

### `MobilePluginConfigAppService`（9 方法）

`com.seeyon.cip.capability.api.common.mobileplugin.MobilePluginConfigAppService`

```java
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.provider.dto.mobileplugin.MobilePluginPlatformConfigDto> selectOneByConditions(com.seeyon.boot.transport.SingleRequest<java.util.Map<java.lang.String, java.lang.Object>>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.provider.dto.mobileplugin.MobilePluginPlatformConfigDto> selectById(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Long> create(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.provider.dto.mobileplugin.MobilePluginPlatformConfigDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> update(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.provider.dto.mobileplugin.MobilePluginPlatformConfigDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> updateStatus(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.provider.dto.mobileplugin.MobilePluginPlatformConfigDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> deleteByIds(com.seeyon.boot.transport.SingleRequest<java.util.List<java.lang.Long>>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.provider.enums.mobileplugin.AccessModeEnum> getWorkWxAccessMode(com.seeyon.boot.transport.SingleRequest<java.lang.Void>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.cip.capability.dto.mobileplugin.MobilePluginPlatformTypeDto> getPlatformTypeList(com.seeyon.boot.transport.SingleRequest<java.lang.Void>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.provider.dto.mobileplugin.MobilePluginPlatformConfigDto> selectOneByConditionsIgnoreTenant(com.seeyon.boot.transport.SingleRequest<java.util.Map<java.lang.String, java.lang.Object>>);
```

### `CapabilityEnumAppService`（9 方法）

`com.seeyon.cip.capability.api.core.info.CapabilityEnumAppService`

```java
    com.seeyon.boot.transport.ListResponse<com.seeyon.cip.capability.dto.info.CapabilityEnumDto> selectList(com.seeyon.boot.transport.ListRequest);
    com.seeyon.boot.transport.ListResponse<com.seeyon.cip.capability.dto.info.CapabilityEnumItemDto> selectItemList(com.seeyon.boot.transport.ListRequest);
    com.seeyon.boot.transport.SingleResponse<java.lang.Long> create(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.info.CapabilityEnumDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Long> createItem(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.info.CapabilityEnumItemDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> delete(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> deleteItem(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> update(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.info.CapabilityEnumDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> updateItem(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.info.CapabilityEnumItemDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> deleteItemByIds(com.seeyon.boot.transport.SingleRequest<java.util.List<java.lang.Long>>);
```

### `PayAppService`（8 方法）

`com.seeyon.cip.capability.api.common.pay.PayAppService`

```java
    default com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.provider.dto.pay.H5PayOrderResultDto> h5Pay(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.provider.dto.pay.H5PayOrderParamsDto>);
    default com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.provider.dto.pay.TransactionResultDto> queryTransactionByOutTradeNo(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.provider.dto.pay.TransactionParamsDto>);
    default com.seeyon.boot.transport.SingleResponse<java.lang.Void> closeTransaction(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.provider.dto.pay.TransactionParamsDto>);
    default com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.provider.dto.pay.RefundResultDto> refund(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.provider.dto.pay.RefundParamsDto>);
    default com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.provider.dto.pay.QueryRefundResultDto> queryRefund(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.provider.dto.pay.QueryRefundParamsDto>);
    default com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.provider.dto.pay.BillDownloadResultDto> downloadTradeBill(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.provider.dto.pay.BillDownloadParamsDto>);
    default com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.provider.dto.pay.BillDownloadResultDto> downloadFundFlowBill(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.provider.dto.pay.BillDownloadParamsDto>);
    default com.seeyon.boot.transport.ListResponse<com.seeyon.cip.provider.dto.pay.CertificateDto> getCert(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.provider.dto.pay.CertificateReqDto>);
```

### `SealAppService`（7 方法）

`com.seeyon.cip.capability.api.common.econtracts.SealAppService`

```java
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.capability.dto.econtracts.BaseContractsResponse> uploadSeal(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.econtracts.request.SealRequestDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.capability.dto.econtracts.BaseContractsResponse> listSeal(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.econtracts.request.SealRequestDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.capability.dto.econtracts.BaseContractsResponse> getSealDetails(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.econtracts.request.SealRequestDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.capability.dto.econtracts.BaseContractsResponse> authSeal(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.econtracts.request.SealRequestDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.capability.dto.econtracts.BaseContractsResponse> cancelAuthSeal(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.econtracts.request.SealRequestDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.capability.dto.econtracts.BaseContractsResponse> deleteAuthSeal(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.econtracts.request.SealRequestDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.capability.dto.econtracts.BaseContractsResponse> syncCompanySeal(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.econtracts.request.SealRequestDto>);
```

### `LocationAppService`（7 方法）

`com.seeyon.cip.capability.api.common.location.LocationAppService`

```java
    com.seeyon.boot.transport.SingleResponse<java.lang.String> getLocation(com.seeyon.boot.transport.SingleRequest<java.lang.Void>);
    com.seeyon.boot.transport.SingleResponse<java.lang.String> getDistance(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.location.request.DistanceDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.provider.dto.location.GeocoderResultDto> geocoding(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.provider.dto.location.GeocoderRequestDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.cip.provider.dto.location.DistrictsDto> regionSearch(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.provider.dto.location.RegionDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.provider.dto.location.JsApiDto> getJsApiInfo(com.seeyon.boot.transport.SingleRequest<java.lang.Void>);
    default com.seeyon.boot.transport.ListResponse<com.seeyon.cip.provider.dto.location.SearchResultDto> keywordSearch(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.provider.dto.location.KeywordSearchDto>);
    default com.seeyon.boot.transport.ListResponse<com.seeyon.cip.provider.dto.location.SearchResultDto> aroundSearch(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.provider.dto.location.AroundSearchDto>);
```

### `VoiceAppService`（7 方法）

`com.seeyon.cip.capability.api.common.voice.VoiceAppService`

```java
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.capability.dto.voice.RealTimeResDto> createRealTime(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.voice.RealtimeDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.capability.dto.voice.CreateVoiceFileResDto> createVoiceFile(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.voice.CreateVoiceFileDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.capability.dto.voice.QueryVoiceFileResDto> queryVoiceFileResult(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.voice.QueryVoiceFileDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.capability.dto.voice.CreateWordsResDto> createFileConvertWords(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.voice.CreateWordsDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.capability.dto.voice.QueryConvertResultResDto> queryConvertWordsResult(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.voice.QueryConvertResultDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.capability.dto.voice.CreateIntelligentDigestResDto> createIntelligentDigest(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.voice.CreateIntelligentDigestDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.capability.dto.voice.QueryIntelligentDigestResDto> queryIntelligentDigestResult(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.voice.QueryIntelligentDigestDto>);
```

### `OfdAppService`（5 方法）

`com.seeyon.cip.capability.api.common.ofd.OfdAppService`

```java
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.capability.dto.ofd.OfdFileResponseDto> getOfdViewUrl(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.ofd.OfdFileRequestDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.capability.dto.ofd.OfdDownResDto> downFile(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.ofd.OfdDownReqDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.capability.dto.ofd.OfdSealResDto> getSealInfo(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.ofd.OfdSealReqDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.cip.capability.dto.ofd.OfdSealItemResDto> getSealList(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.ofd.OfdSealItemReqDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.cip.capability.dto.ofd.OfdMetaDataResDto> getOfdMetaData(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.ofd.OfdMetaDataReqDto>);
```

### `MerchantAppService`（5 方法）

`com.seeyon.cip.capability.api.common.pay.MerchantAppService`

```java
    default com.seeyon.boot.transport.SingleResponse<java.lang.Long> createMerchant(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.pay.MerchantDto>);
    default com.seeyon.boot.transport.SingleResponse<java.lang.Integer> updateMerchant(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.pay.MerchantDto>);
    default com.seeyon.boot.transport.SingleResponse<java.lang.Integer> deleteMerchant(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    default com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.capability.dto.pay.MerchantDto> detailMerchant(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    default com.seeyon.boot.transport.PageResponse<com.seeyon.cip.capability.dto.pay.MerchantDto> selectPageMerchantByConditions(com.seeyon.boot.transport.PageRequest);
```

### `ShortMessageProviderTemplateAppService`（5 方法）

`com.seeyon.cip.capability.api.core.sms.ShortMessageProviderTemplateAppService`

```java
    com.seeyon.boot.transport.SingleResponse<java.lang.Long> createShortMessageTemplateContent(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.sms.ShortMessageProviderTemplateDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> updateTemplateContent(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.sms.ShortMessageProviderTemplateDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.capability.dto.sms.ShortMessageProviderTemplateDto> selectTemplateContentById(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> deleteTemplateContent(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.cip.capability.dto.sms.ShortMessageProviderTemplateDto> selectTemplateContentByConditions(com.seeyon.boot.transport.PageRequest);
```

### `ArchivesAppService`（4 方法）

`com.seeyon.cip.capability.api.common.archives.ArchivesAppService`

```java
    default com.seeyon.boot.transport.SingleResponse<java.lang.String> titleAttribute(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    default com.seeyon.boot.transport.ListResponse<com.seeyon.cip.provider.dto.archives.ArchiveSettingCategoryDto> queryArchiveSystemCategory(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    default com.seeyon.boot.transport.ListResponse<com.seeyon.cip.provider.dto.archives.FieldMappingDto> selectAttributesByTypeIds(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.provider.dto.archives.FieldMappingRequestDto>);
    default com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.provider.dto.archives.ArchiveResultDto> startArchiving(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.provider.dto.archives.ArchivingInfoWrapperDto>);
```

### `FaceIdAppService`（4 方法）

`com.seeyon.cip.capability.api.common.faceid.FaceIdAppService`

```java
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.capability.dto.faceid.FaceAddResDto> addFace(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.faceid.FaceAddReqDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.capability.dto.faceid.FaceIdentifyResDto> faceCheck(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.faceid.FaceIdentifyReqDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.capability.dto.faceid.FaceUpdateResDto> updateFace(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.faceid.FaceUpdateReqDto>);
    default com.seeyon.boot.transport.SingleResponse<java.lang.String> getAccessToken(com.seeyon.boot.transport.SingleRequest<java.lang.Void>);
```

### `ScheduleAppService`（4 方法）

`com.seeyon.cip.capability.api.common.schedule.ScheduleAppService`

```java
    default com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.provider.dto.schedule.ScheduleInfoDto> addSchedule(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.provider.dto.schedule.AddScheduleDto>);
    default com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.provider.dto.schedule.ScheduleInfoDto> updateSchedule(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.provider.dto.schedule.UpdateScheduleDto>);
    default com.seeyon.boot.transport.SingleResponse<java.lang.Void> cancelSchedule(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.provider.dto.schedule.ScheduleInfoDto>);
    default com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.provider.dto.schedule.ScheduleDetailDto> detailSchedule(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.provider.dto.schedule.ScheduleInfoDto>);
```

### `ShortMessageAppService`（4 方法）

`com.seeyon.cip.capability.api.common.sms.ShortMessageAppService`

```java
    com.seeyon.boot.transport.SingleResponse<java.lang.Void> sendShortMessage(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.sms.SmsSendDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.capability.dto.sms.SmsResponseDto> sendSycShortMessage(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.sms.SmsSendDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Void> sendShortMessageAsync(com.seeyon.boot.transport.SingleRequest<java.util.List<com.seeyon.cip.capability.dto.sms.SmsSendDto>>);
    default com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.capability.dto.sms.SmsResponseDto> inspectSms(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.sms.SmsInspectionDto>);
```

### `AiAppService`（3 方法）

`com.seeyon.cip.capability.api.core.ai.AiAppService`

```java
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.capability.dto.ai.AiThirdAppInfoDto> createThirdApp(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.ai.AiAppInfoDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.capability.dto.ai.AiThirdAppInfoDto> thirdAppIncrease(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.ai.AiAppInfoDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.capability.dto.ai.AiAppUsageInfoDto> queryUsageAmount(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.ai.AiAppUsageQueryDto>);
```

### `CapabilityAccessLogDbAppService`（3 方法）

`com.seeyon.cip.capability.api.core.log.CapabilityAccessLogDbAppService`

```java
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.provider.dto.log.CipAccessOpenLogDto> selectById(com.seeyon.boot.transport.SingleRequest<java.lang.String>);
    com.seeyon.boot.transport.PageResponse<com.seeyon.cip.provider.dto.log.CipAccessOpenLogDto> selectPageByConditions(com.seeyon.boot.transport.PageRequest);
    com.seeyon.boot.transport.ListResponse<com.seeyon.cip.capability.dto.log.CapabilityStatisticalResultsDto> countByConditions(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.log.CapabilityStatisticalRequestDto>);
```

### `ExcelSmsImportAndExportAppService`（3 方法）

`com.seeyon.cip.capability.api.core.sms.ExcelSmsImportAndExportAppService`

```java
    com.seeyon.boot.transport.ListResponse<com.seeyon.cip.capability.dto.sms.ExcelImportResponseDto> importExcel(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.sms.ExcelSmsImportDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.String> exportExcel(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.enums.sms.ExcelSheetEnum>);
    com.seeyon.boot.transport.SingleResponse<java.lang.String> exportExcelTemplate(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.enums.sms.ExcelSheetEnum>);
```

### `CensorAppService`（2 方法）

`com.seeyon.cip.capability.api.common.censor.CensorAppService`

```java
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.capability.dto.censor.TextCensorResDto> textCensor(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.censor.TextCensorReqDto>);
    default com.seeyon.boot.transport.SingleResponse<java.lang.Boolean> censorChange(com.seeyon.boot.transport.SingleRequest<java.util.Map<java.lang.String, java.lang.Object>>);
```

### `CompanyAccountServiceAppService`（2 方法）

`com.seeyon.cip.capability.api.common.econtracts.CompanyAccountServiceAppService`

```java
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> createOrUpdate(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.econtracts.request.CommonCompanyAccountDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.capability.dto.econtracts.request.CommonCompanyAccountDto> queryCompanyAccountInfo(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
```

### `InvoiceImageAppService`（2 方法）

`com.seeyon.cip.capability.api.common.invoice.InvoiceImageAppService`

```java
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.capability.dto.invoice.response.InvoiceImageResDto> createImageTask(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.invoice.request.InvoiceImageReqDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.capability.dto.invoice.response.InvoiceImageUploadResDto> uploadImageFile(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.invoice.request.InvoiceImageUploadReqDto>);
```

### `TranslationAppService`（2 方法）

`com.seeyon.cip.capability.api.common.translation.TranslationAppService`

```java
    com.seeyon.boot.transport.SingleResponse<java.lang.String> translate(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.translation.TranslationDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.cip.provider.dto.translation.LanguageDto> getLanguages(com.seeyon.boot.transport.SingleRequest<java.lang.Void>);
```

### `WeatherAppService`（2 方法）

`com.seeyon.cip.capability.api.common.weather.WeatherAppService`

```java
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.provider.dto.weather.LocationDto> getLocation(com.seeyon.boot.transport.SingleRequest<java.lang.Void>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.capability.dto.weather.WeatherDto> getWeather(com.seeyon.boot.transport.SingleRequest<java.lang.String>);
```

### `TokenAppService`（2 方法）

`com.seeyon.cip.capability.api.core.token.TokenAppService`

```java
    com.seeyon.boot.transport.SingleResponse<java.lang.String> selectTokenExpireTime(com.seeyon.boot.transport.SingleRequest<java.lang.String>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Boolean> saveTokenExpireTime(com.seeyon.boot.transport.SingleRequest<java.lang.String>, com.seeyon.boot.transport.SingleRequest<java.lang.String>);
```

### `DocGeneralizeAppService`（1 方法）

`com.seeyon.cip.capability.api.common.doc.DocGeneralizeAppService`

```java
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.capability.dto.doc.DocAuthorityInfoResponseDto> getAuthorityInfoProxy(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.doc.DocAuthorityInfoProxyRequestDto>);
```

### `ContractsCallBackAppService`（1 方法）

`com.seeyon.cip.capability.api.common.econtracts.ContractsCallBackAppService`

```java
    com.seeyon.boot.transport.SingleResponse<java.lang.String> callBack(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.econtracts.BaseContractsRequestDto>);
```

### `GisAppService`（1 方法）

`com.seeyon.cip.capability.api.common.gis.GisAppService`

```java
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.capability.dto.gis.GisTokenDto> getToken(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.provider.dto.gis.request.GisTokenRequestDto>);
```

### `OfflineMessageAppService`（1 方法）

`com.seeyon.cip.capability.api.common.message.OfflineMessageAppService`

```java
    com.seeyon.boot.transport.SingleResponse<java.lang.Void> pushMessage(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.provider.dto.message.offline.OfflineMessageDto>);
```

### `ResumeAppService`（1 方法）

`com.seeyon.cip.capability.api.common.resume.ResumeAppService`

```java
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.provider.dto.resume.response.ResumeResultDto> analysisResume(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.provider.dto.resume.request.ResumeRequestDto>);
```

### `SearchAppService`（1 方法）

`com.seeyon.cip.capability.api.common.search.SearchAppService`

```java
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.capability.dto.search.QuerySearchResDto> querySearchUrl(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.search.QuerySearchReqDto>);
```

## 二、关键类（32）

### `ShortMessageTemplateDto`（38 方法）

`com.seeyon.cip.capability.dto.sms.ShortMessageTemplateDto`

```java
    void setId(java.lang.Long);
    void setName(java.lang.String);
    void setCode(java.lang.String);
    void setTemplateTypeEnumsId(java.lang.Long);
    void setTemplateTypeEnumsName(java.lang.String);
    void setTemplateLanguage(java.lang.String);
    void setTemplateLanguageName(java.lang.String);
    void setTemplateStatusEnum(com.seeyon.cip.capability.enums.sms.TemplateStatusEnum);
    void setTemplateContent(java.lang.String);
    void setPrepare(java.lang.Boolean);
    void setLibrary(java.lang.Boolean);
    void setApplicationDescription(java.lang.String);
    void setAuditDescription(java.lang.String);
    void setCreateTime(java.util.Date);
    void setInterfaceLink(java.lang.Boolean);
    void setSignId(java.lang.Long);
    void setSignName(java.lang.String);
    void setProviderTemplateDtoList(java.util.List<com.seeyon.cip.capability.dto.sms.ShortMessageProviderTemplateDto>);
    void setParamsDtos(java.util.List<com.seeyon.cip.capability.dto.sms.ShortMessageTemplateParamsDto>);
    java.lang.Long getId();
    java.lang.String getName();
    java.lang.String getCode();
    java.lang.Long getTemplateTypeEnumsId();
    java.lang.String getTemplateTypeEnumsName();
    java.lang.String getTemplateLanguage();
    java.lang.String getTemplateLanguageName();
    com.seeyon.cip.capability.enums.sms.TemplateStatusEnum getTemplateStatusEnum();
    java.lang.String getTemplateContent();
    java.lang.Boolean getPrepare();
    java.lang.Boolean getLibrary();
    java.lang.String getApplicationDescription();
    java.lang.String getAuditDescription();
    java.util.Date getCreateTime();
    java.lang.Boolean getInterfaceLink();
    java.lang.Long getSignId();
    java.lang.String getSignName();
    java.util.List<com.seeyon.cip.capability.dto.sms.ShortMessageProviderTemplateDto> getProviderTemplateDtoList();
    java.util.List<com.seeyon.cip.capability.dto.sms.ShortMessageTemplateParamsDto> getParamsDtos();
```

### `EmailConfigTestDto`（28 方法）

`com.seeyon.cip.capability.dto.email.EmailConfigTestDto`

```java
    void setEmailAccount(java.lang.String);
    void setSendHost(java.lang.String);
    void setSendSsl(java.lang.Boolean);
    void setSendPort(java.lang.Integer);
    void setLoginName(java.lang.String);
    void setLoginPassword(java.lang.String);
    void setContentWithLink(java.lang.Boolean);
    void setLinkLogin(java.lang.Boolean);
    void setEffectiveTime(java.lang.Integer);
    void setPrefix(java.lang.String);
    void setAppName(java.lang.String);
    void setDebugging(java.lang.Boolean);
    void setMailTo(java.lang.String);
    void setContentLink(java.lang.String);
    java.lang.String getEmailAccount();
    java.lang.String getSendHost();
    java.lang.Boolean getSendSsl();
    java.lang.Integer getSendPort();
    java.lang.String getLoginName();
    java.lang.String getLoginPassword();
    java.lang.Boolean getContentWithLink();
    java.lang.Boolean getLinkLogin();
    java.lang.Integer getEffectiveTime();
    java.lang.String getPrefix();
    java.lang.String getAppName();
    java.lang.Boolean getDebugging();
    java.lang.String getMailTo();
    java.lang.String getContentLink();
```

### `SelectProviderDto`（26 方法）

`com.seeyon.cip.capability.dto.manage.SelectProviderDto`

```java
    void setId(java.lang.Long);
    void setCapabilityName(java.lang.String);
    void setCapabilityCode(java.lang.Integer);
    void setEnable(java.lang.Boolean);
    void setDefaultProvider(java.lang.String);
    void setProviderName(java.lang.String);
    void setCallBackType(java.lang.Integer);
    void setCreateTime(java.util.Date);
    void setIconPath(java.lang.String);
    void setDescription(java.lang.String);
    void setNameI18n(java.lang.String);
    void setProviderEnable(java.lang.Boolean);
    void setSort(java.lang.Integer);
    java.lang.Long getId();
    java.lang.String getCapabilityName();
    java.lang.Integer getCapabilityCode();
    java.lang.Boolean getEnable();
    java.lang.String getDefaultProvider();
    java.lang.String getProviderName();
    java.lang.Integer getCallBackType();
    java.util.Date getCreateTime();
    java.lang.String getIconPath();
    java.lang.String getDescription();
    java.lang.String getNameI18n();
    java.lang.Boolean getProviderEnable();
    java.lang.Integer getSort();
```

### `CipEmailConfigDto`（20 方法）

`com.seeyon.cip.capability.dto.email.CipEmailConfigDto`

```java
    void setEmailAccount(java.lang.String);
    void setSendHost(java.lang.String);
    void setSendPort(java.lang.Integer);
    void setSendSsl(java.lang.Boolean);
    void setLoginName(java.lang.String);
    void setLoginPassword(java.lang.String);
    void setContentWithLink(java.lang.Boolean);
    void setLinkLogin(java.lang.Boolean);
    void setEffectiveTime(java.lang.Integer);
    void setPrefix(java.lang.String);
    java.lang.String getEmailAccount();
    java.lang.String getSendHost();
    java.lang.Integer getSendPort();
    java.lang.Boolean getSendSsl();
    java.lang.String getLoginName();
    java.lang.String getLoginPassword();
    java.lang.Boolean getContentWithLink();
    java.lang.Boolean getLinkLogin();
    java.lang.Integer getEffectiveTime();
    java.lang.String getPrefix();
```

### `CipEmailTemplateDto`（18 方法）

`com.seeyon.cip.capability.dto.email.CipEmailTemplateDto`

```java
    void setId(java.lang.Long);
    void setTemplateCode(java.lang.String);
    void setTemplateName(java.lang.String);
    void setEmailSubject(java.lang.String);
    void setEmailContent(java.lang.String);
    void setAttachments(java.util.List<com.seeyon.cip.capability.dto.email.EmailAttachmentDto>);
    void setCreateTime(java.util.Date);
    void setSubjectParamsList(java.util.List<java.lang.String>);
    void setContentParamsList(java.util.List<java.lang.String>);
    java.lang.Long getId();
    java.lang.String getTemplateCode();
    java.lang.String getTemplateName();
    java.lang.String getEmailSubject();
    java.lang.String getEmailContent();
    java.util.List<com.seeyon.cip.capability.dto.email.EmailAttachmentDto> getAttachments();
    java.util.Date getCreateTime();
    java.util.List<java.lang.String> getSubjectParamsList();
    java.util.List<java.lang.String> getContentParamsList();
```

### `ShortMessageProviderTemplateDto`（18 方法）

`com.seeyon.cip.capability.dto.sms.ShortMessageProviderTemplateDto`

```java
    void setId(java.lang.Long);
    void setTemplateId(java.lang.Long);
    void setSignId(java.lang.Long);
    void setTemplateContent(java.lang.String);
    void setProviderTemplateCode(java.lang.String);
    void setProvider(java.lang.String);
    void setTemplateStatusEnum(com.seeyon.cip.capability.enums.sms.TemplateStatusEnum);
    void setApplicationDescription(java.lang.String);
    void setAuditDescription(java.lang.String);
    java.lang.Long getId();
    java.lang.Long getTemplateId();
    java.lang.Long getSignId();
    java.lang.String getTemplateContent();
    java.lang.String getProviderTemplateCode();
    java.lang.String getProvider();
    com.seeyon.cip.capability.enums.sms.TemplateStatusEnum getTemplateStatusEnum();
    java.lang.String getApplicationDescription();
    java.lang.String getAuditDescription();
```

### `ProviderParameterDto`（16 方法）

`com.seeyon.cip.capability.dto.manage.ProviderParameterDto`

```java
    void setId(java.lang.Long);
    void setCapabilityName(java.lang.String);
    void setParameterName(java.lang.String);
    void setValue(java.lang.String);
    void setProvider(java.lang.String);
    void setDescription(java.lang.String);
    void setPreset(java.lang.Boolean);
    void setEncryption(java.lang.Boolean);
    java.lang.Long getId();
    java.lang.String getCapabilityName();
    java.lang.String getParameterName();
    java.lang.String getValue();
    java.lang.String getProvider();
    java.lang.String getDescription();
    java.lang.Boolean getPreset();
    java.lang.Boolean getEncryption();
```

### `CipAppFeatureProviderCreateDto`（16 方法）

`com.seeyon.cip.capability.dto.manage.appchannel.CipAppFeatureProviderCreateDto`

```java
    java.lang.Long getAppId();
    com.seeyon.cip.provider.enums.CapabilityEnum getCapabilityEnum();
    java.lang.String getFeatureGroup();
    java.lang.String getFeatureCode();
    java.lang.String getProvider();
    java.lang.String getProviderCode();
    void setAppId(java.lang.Long);
    void setCapabilityEnum(com.seeyon.cip.provider.enums.CapabilityEnum);
    void setFeatureGroup(java.lang.String);
    void setFeatureCode(java.lang.String);
    void setProvider(java.lang.String);
    void setProviderCode(java.lang.String);
    boolean equals(java.lang.Object);
    protected boolean canEqual(java.lang.Object);
    int hashCode();
    java.lang.String toString();
```

### `MobilePluginAppletCodeTemplateDto`（16 方法）

`com.seeyon.cip.capability.dto.mobileplugin.applet.MobilePluginAppletCodeTemplateDto`

```java
    void setTemplateId(java.lang.Long);
    void setUserVersion(java.lang.String);
    void setUserDesc(java.lang.String);
    void setTemplateType(java.lang.Integer);
    void setCreateTime(java.util.Date);
    void setSourceMiniProgramAppid(java.lang.String);
    void setSourceMiniProgram(java.lang.String);
    void setExtraParams(java.util.Map<java.lang.String, java.lang.Object>);
    java.lang.Long getTemplateId();
    java.lang.String getUserVersion();
    java.lang.String getUserDesc();
    java.lang.Integer getTemplateType();
    java.util.Date getCreateTime();
    java.lang.String getSourceMiniProgramAppid();
    java.lang.String getSourceMiniProgram();
    java.util.Map<java.lang.String, java.lang.Object> getExtraParams();
```

### `BpmTemplateData`（14 方法）

`com.seeyon.cip.capability.dto.econtracts.request.BpmTemplateData`

```java
    void setActivityName(java.lang.String);
    void setPolicyId(java.lang.String);
    void setActorParticipantTypeId(java.lang.String);
    void setActorParticipantId(java.lang.String);
    void setActorRoleId(java.lang.String);
    void setHumenActivity(boolean);
    void setActorSize(int);
    java.lang.String getActivityName();
    java.lang.String getPolicyId();
    java.lang.String getActorParticipantTypeId();
    java.lang.String getActorParticipantId();
    java.lang.String getActorRoleId();
    boolean isHumenActivity();
    int getActorSize();
```

### `EmailTemplateSendDto`（14 方法）

`com.seeyon.cip.capability.dto.email.EmailTemplateSendDto`

```java
    void setTemplateCode(java.lang.String);
    void setTo(java.util.List<java.lang.String>);
    void setSubjectParams(java.util.Map<java.lang.String, java.lang.Object>);
    void setContentParams(java.util.Map<java.lang.String, java.lang.Object>);
    void setContentLink(java.lang.String);
    void setMemberIdList(java.util.List<java.lang.String>);
    void setOrgIdList(java.util.List<java.lang.String>);
    java.lang.String getTemplateCode();
    java.util.List<java.lang.String> getTo();
    java.util.Map<java.lang.String, java.lang.Object> getSubjectParams();
    java.util.Map<java.lang.String, java.lang.Object> getContentParams();
    java.lang.String getContentLink();
    java.util.List<java.lang.String> getMemberIdList();
    java.util.List<java.lang.String> getOrgIdList();
```

### `CipAppFeatureProviderDetailDto`（14 方法）

`com.seeyon.cip.capability.dto.manage.appchannel.CipAppFeatureProviderDetailDto`

```java
    java.lang.Long getAppId();
    com.seeyon.cip.provider.enums.CapabilityEnum getCapabilityEnum();
    java.lang.String getFeatureCode();
    java.lang.String getProvider();
    java.lang.String getProviderCode();
    void setAppId(java.lang.Long);
    void setCapabilityEnum(com.seeyon.cip.provider.enums.CapabilityEnum);
    void setFeatureCode(java.lang.String);
    void setProvider(java.lang.String);
    void setProviderCode(java.lang.String);
    boolean equals(java.lang.Object);
    protected boolean canEqual(java.lang.Object);
    int hashCode();
    java.lang.String toString();
```

### `SelectProviderCloudDto`（12 方法）

`com.seeyon.cip.capability.dto.manage.SelectProviderCloudDto`

```java
    void setId(java.lang.Long);
    void setTenantName(java.lang.String);
    void setEnable(java.lang.Boolean);
    void setDefaultProvider(java.lang.String);
    void setProviderName(java.lang.String);
    void setCreateTime(java.util.Date);
    java.lang.Long getId();
    java.lang.String getTenantName();
    java.lang.Boolean getEnable();
    java.lang.String getDefaultProvider();
    java.lang.String getProviderName();
    java.util.Date getCreateTime();
```

### `CipEmailLimitConfigDto`（10 方法）

`com.seeyon.cip.capability.dto.email.CipEmailLimitConfigDto`

```java
    void setDayLimit(java.lang.Integer);
    void setHourLimit(java.lang.Integer);
    void setMinuteLimit(java.lang.Integer);
    void setIsLimit(java.lang.Boolean);
    void setWhiteList(java.lang.String);
    java.lang.Integer getDayLimit();
    java.lang.Integer getHourLimit();
    java.lang.Integer getMinuteLimit();
    java.lang.Boolean getIsLimit();
    java.lang.String getWhiteList();
```

### `AuthConfigDto`（10 方法）

`com.seeyon.cip.capability.dto.manage.AuthConfigDto`

```java
    void setCapabilityName(java.lang.String);
    void setProvider(java.lang.String);
    void setType(com.seeyon.cip.capability.enums.StatisticsTypeEnum);
    void setStartTime(java.util.Date);
    void setEndTime(java.util.Date);
    java.lang.String getCapabilityName();
    java.lang.String getProvider();
    com.seeyon.cip.capability.enums.StatisticsTypeEnum getType();
    java.util.Date getStartTime();
    java.util.Date getEndTime();
```

### `EventCallbackConfigQueryDto`（10 方法）

`com.seeyon.cip.capability.dto.manage.EventCallbackConfigQueryDto`

```java
    com.seeyon.cip.provider.enums.CapabilityEnum getCapabilityEnum();
    java.lang.String getProvider();
    java.lang.String getToken();
    void setCapabilityEnum(com.seeyon.cip.provider.enums.CapabilityEnum);
    void setProvider(java.lang.String);
    void setToken(java.lang.String);
    boolean equals(java.lang.Object);
    protected boolean canEqual(java.lang.Object);
    int hashCode();
    java.lang.String toString();
```

### `ProviderManageDto`（10 方法）

`com.seeyon.cip.capability.dto.manage.ProviderManageDto`

```java
    void setId(java.lang.Long);
    void setCapabilityName(java.lang.String);
    void setCapabilityCode(java.lang.String);
    void setEnable(java.lang.Boolean);
    void setProviderNames(java.lang.String);
    java.lang.Long getId();
    java.lang.String getCapabilityName();
    java.lang.String getCapabilityCode();
    java.lang.Boolean getEnable();
    java.lang.String getProviderNames();
```

### `SmsTemplateTypeListDto`（10 方法）

`com.seeyon.cip.capability.dto.sms.SmsTemplateTypeListDto`

```java
    void setName(java.lang.String);
    void setItemValue(java.lang.String);
    void setCreateTime(java.util.Date);
    void setPrepare(java.lang.Boolean);
    void setUse(java.lang.Boolean);
    java.lang.String getName();
    java.lang.String getItemValue();
    java.util.Date getCreateTime();
    java.lang.Boolean getPrepare();
    java.lang.Boolean getUse();
```

### `EventCallbackConfigResultDto`（8 方法）

`com.seeyon.cip.capability.dto.manage.EventCallbackConfigResultDto`

```java
    java.lang.String getCallbackUrl();
    java.lang.String getCallbackToken();
    void setCallbackUrl(java.lang.String);
    void setCallbackToken(java.lang.String);
    boolean equals(java.lang.Object);
    protected boolean canEqual(java.lang.Object);
    int hashCode();
    java.lang.String toString();
```

### `ProviderEnableDto`（8 方法）

`com.seeyon.cip.capability.dto.manage.ProviderEnableDto`

```java
    void setCapabilityName(java.lang.String);
    void setEnable(java.lang.Boolean);
    void setProviderName(java.lang.String);
    void setProviderCode(java.lang.String);
    java.lang.String getCapabilityName();
    java.lang.Boolean getEnable();
    java.lang.String getProviderName();
    java.lang.String getProviderCode();
```

### `ClassifyProviderCloudDto`（6 方法）

`com.seeyon.cip.capability.dto.manage.ClassifyProviderCloudDto`

```java
    void setProviderCode(java.lang.String);
    void setProviderName(java.lang.String);
    void setEnable(boolean);
    java.lang.String getProviderCode();
    java.lang.String getProviderName();
    boolean isEnable();
```

### `ProviderChargesDto`（6 方法）

`com.seeyon.cip.capability.dto.manage.ProviderChargesDto`

```java
    void setOpenAppId(java.lang.Long);
    void setUserId(java.lang.Long);
    void setChargesData(java.util.Map<java.lang.String, java.lang.Integer>);
    java.lang.Long getOpenAppId();
    java.lang.Long getUserId();
    java.util.Map<java.lang.String, java.lang.Integer> getChargesData();
```

### `ProviderChargesRecordDto`（6 方法）

`com.seeyon.cip.capability.dto.manage.ProviderChargesRecordDto`

```java
    void setCapabilityName(java.lang.String);
    void setUseCount(java.lang.Integer);
    void setAvailableCount(java.lang.Integer);
    java.lang.String getCapabilityName();
    java.lang.Integer getUseCount();
    java.lang.Integer getAvailableCount();
```

### `ProviderOpenApiDto`（6 方法）

`com.seeyon.cip.capability.dto.manage.ProviderOpenApiDto`

```java
    void setDefaultCategory(java.lang.String);
    void setDefaultApi(java.util.List<java.lang.String>);
    void setDefaultCharge(java.util.List<java.lang.String>);
    java.lang.String getDefaultCategory();
    java.util.List<java.lang.String> getDefaultApi();
    java.util.List<java.lang.String> getDefaultCharge();
```

### `ProviderParameterRequestDto`（6 方法）

`com.seeyon.cip.capability.dto.manage.ProviderParameterRequestDto`

```java
    void setProviderManagerId(java.lang.Long);
    void setParameterList(java.util.List<com.seeyon.cip.capability.dto.manage.ProviderParameterDto>);
    void setDefaultProvider(java.lang.String);
    java.lang.Long getProviderManagerId();
    java.util.List<com.seeyon.cip.capability.dto.manage.ProviderParameterDto> getParameterList();
    java.lang.String getDefaultProvider();
```

### `CipAppFeatureProviderCreateInDto`（6 方法）

`com.seeyon.cip.capability.dto.manage.appchannel.CipAppFeatureProviderCreateInDto`

```java
    java.util.List<com.seeyon.cip.capability.dto.manage.appchannel.CipAppFeatureProviderCreateDto> getFeatureProviderList();
    void setFeatureProviderList(java.util.List<com.seeyon.cip.capability.dto.manage.appchannel.CipAppFeatureProviderCreateDto>);
    boolean equals(java.lang.Object);
    protected boolean canEqual(java.lang.Object);
    int hashCode();
    java.lang.String toString();
```

### `RepeatTemplateCodeRequestDto`（6 方法）

`com.seeyon.cip.capability.dto.sms.RepeatTemplateCodeRequestDto`

```java
    void setId(java.lang.Long);
    void setTemplateCode(java.lang.String);
    void setLanguage(java.lang.String);
    java.lang.Long getId();
    java.lang.String getTemplateCode();
    java.lang.String getLanguage();
```

### `ShortMessageTemplateParamsDto`（6 方法）

`com.seeyon.cip.capability.dto.sms.ShortMessageTemplateParamsDto`

```java
    void setName(java.lang.String);
    void setDescription(java.lang.String);
    void setValue(java.lang.String);
    java.lang.String getName();
    java.lang.String getDescription();
    java.lang.String getValue();
```

### `BpmTemplateValidCheckRequestDto`（4 方法）

`com.seeyon.cip.capability.dto.econtracts.request.BpmTemplateValidCheckRequestDto`

```java
    void setRequestParam(com.seeyon.cip.capability.dto.econtracts.CommonContractDataDto);
    com.seeyon.cip.capability.dto.econtracts.CommonContractDataDto getRequestParam();
    void setCommonBpmTemplateValidCheckDto(com.seeyon.cip.capability.dto.econtracts.request.CommonBpmTemplateValidCheckDto);
    com.seeyon.cip.capability.dto.econtracts.request.CommonBpmTemplateValidCheckDto getCommonBpmTemplateValidCheckDto();
```

### `InvoiceOcrProviderDto`（4 方法）

`com.seeyon.cip.capability.dto.invoice.request.InvoiceOcrProviderDto`

```java
    java.lang.Long getInvokeId();
    java.util.Map<java.lang.String, java.lang.String> getStorageKeys();
    void setInvokeId(java.lang.Long);
    void setStorageKeys(java.util.Map<java.lang.String, java.lang.String>);
```

### `ClassifyProviderDto`（4 方法）

`com.seeyon.cip.capability.dto.manage.ClassifyProviderDto`

```java
    void setProviderCode(java.lang.String);
    void setProviderName(java.lang.String);
    java.lang.String getProviderCode();
    java.lang.String getProviderName();
```

### `ProviderChannelResponseDto`（4 方法）

`com.seeyon.cip.capability.dto.manage.ProviderChannelResponseDto`

```java
    void setCapabilityChannelCode(java.lang.String);
    void setCapabilityChannelDescription(java.lang.String);
    java.lang.String getCapabilityChannelCode();
    java.lang.String getCapabilityChannelDescription();
```

## 四、枚举（10）

- `StatisticsTypeEnum`（4 常量）：Consumption, Capacity, Cycle, Both
- `AppSourceEnum`（3 常量）：PRECAST, MANUAL_NEW, DUBBO
- `ConvertStatusEnum`（3 常量）：RUNNING, SUCCESS, FAILURE
- `DocOperateEnum`（13 常量）：OPERATE_VIEW, OPERATE_EDIT, OPERATE_EDIT_PRINT, OPERATE_CONVERT, OPERATE_CONVERT_PRINT, OPERATE_CLEAN, OPERATE_TEXT_WATERMARK, OPERATE_IMAGE_WATERMARK, OPERATE_OFFICE_QUERY_BOOKMARK, OPERATE_OFFICE_WARP_HEADER, OPERATE_OFFICE_SET_BOOKMARK_PERMS, OPERATE_OFFICE_MERGE …
- `ContractsCapabilityEnums`（19 常量）：PERSONAL_CERTIFICATE, ENTERPRISE_CERTIFICATE, CREATE_SIGN_TASK, VIEW_SIGN_DETAIL, VIEW_SIGN_EXTERNAL_STATUS, VIEW_SIGN_FILE, CANCEL_SIGN_TASK, SIGN_TASK_URL, CHECK_BPM_TEMPLATE, SEAL_UPLOAD, SEAL_AUTHORITY, SEAL_AUTHORITY_CANCEL …
- `DistanceEnum`（2 常量）：METER, KILOMETER
- `StatisticalTypeEnum`（2 常量）：INSTITUTION, MEMBER
- `ExcelImportTypeEnum`（2 常量）：UPDATE, IGNORE
- `ExcelSheetEnum`（2 常量）：TEMPLATE, SIGN
- `TemplateStatusEnum`（5 常量）：PENDING_APPROVE, DRAFT, APPROVE, IN_REVIEW, NOT_APPROVED
