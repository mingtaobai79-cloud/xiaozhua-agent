# boot-starter-enums：接口与方法签名

> 自动生成，勿手改。`tools/core/platform/emit_package_surfaces.py` 重跑即可。
> 构件 `com.seeyon:boot-starter-enums`（jar `boot-starter-enums-5.3.603.jar`）
> 规模：51 类 / 4 接口 / 0 注解 / 2 枚举 / 12 个关键类 / 754 方法。
> 签名逐字来自 javap 原文；已去掉 `public` 前缀与 `throws` 子句。

## 一、接口（4）

### `CtpEnumItemDao`（1 方法） extends CtpEnumItem>

`com.seeyon.boot.starter.enums.domain.dao.CtpEnumItemDao`

```java
    java.lang.Integer calcEnumItemOrderNo(java.util.Map<java.lang.String, java.lang.Object>);
```

### `CtpEnumItemFilterInterface`（1 方法）

`com.seeyon.boot.starter.enums.domain.filter.CtpEnumItemFilterInterface`

```java
    java.util.List<com.seeyon.boot.starter.enums.dto.CtpEnumItemSimpleDto> filter(java.util.List<com.seeyon.boot.starter.enums.dto.CtpEnumItemSimpleDto>);
```

### `CtpEnumCategoryDao`（0 方法） extends CtpEnumCategory>

`com.seeyon.boot.starter.enums.domain.dao.CtpEnumCategoryDao`

```java
```

### `CtpEnumDao`（0 方法） extends CtpEnum>

`com.seeyon.boot.starter.enums.domain.dao.CtpEnumDao`

```java
```

## 二、关键类（12）

### `CtpEnumItemService`（135 方法）

`com.seeyon.boot.starter.enums.domain.service.CtpEnumItemService`

```java
    java.lang.Long create(com.seeyon.boot.starter.enums.dto.CtpEnumItemDto);
    void dealCascadeEnumItemCache(java.lang.String);
    java.lang.Integer createBatchForAppApproval(java.util.List<com.seeyon.boot.starter.enums.dto.CtpEnumItemDto>);
    java.lang.Integer createOrUpdateBatchForOnlypage(java.util.List<com.seeyon.boot.starter.enums.dto.CtpEnumItemDto>);
    java.lang.Integer update(com.seeyon.boot.starter.enums.dto.CtpEnumItemDto);
    private void getEnableEnumItemList(com.seeyon.boot.starter.enums.domain.entity.CtpEnumItem, java.util.List<com.seeyon.boot.starter.enums.domain.entity.CtpEnumItem>, java.lang.Boolean);
    private void getParentEnumItemList(com.seeyon.boot.starter.enums.domain.entity.CtpEnumItem, java.util.List<com.seeyon.boot.starter.enums.domain.entity.CtpEnumItem>, java.lang.Boolean);
    private void checkEnumType(com.seeyon.boot.starter.enums.dto.CtpEnumItemDto);
    private void checkNameUnique(com.seeyon.boot.starter.enums.dto.CtpEnumItemDto);
    private void checkValueUnique(com.seeyon.boot.starter.enums.dto.CtpEnumItemDto);
    java.lang.Integer updatePresetBatch(java.util.Map<java.lang.String, java.lang.Object>);
    java.lang.Integer updateDataStatusBatch(java.util.Map<java.lang.String, java.lang.Object>);
    int deleteByConditions(java.util.Map<java.lang.String, java.lang.Object>);
    int deleteByIds(java.util.List<java.lang.Long>);
    private void getDeleteEnumItemList(java.util.List<com.seeyon.boot.starter.enums.domain.entity.CtpEnumItem>, java.util.List<com.seeyon.boot.starter.enums.domain.entity.CtpEnumItem>);
    private void getChildDeleteEnumItemList(java.util.List<com.seeyon.boot.starter.enums.domain.entity.CtpEnumItem>, java.util.List<com.seeyon.boot.starter.enums.domain.entity.CtpEnumItem>, java.util.Map<java.lang.Long, java.util.List<com.seeyon.boot.starter.enums.domain.entity.CtpEnumItem>>);
    com.seeyon.boot.starter.enums.dto.CtpEnumItemDto selectById(java.lang.Long);
    java.util.List<com.seeyon.boot.starter.enums.dto.CtpEnumItemDto> selectByIds(java.util.List<java.lang.Long>);
    java.util.List<com.seeyon.boot.starter.enums.dto.CtpEnumItemDto> selectByAppId(java.lang.Long);
    java.util.List<com.seeyon.boot.starter.enums.dto.CtpEnumItemDto> selectByAppIdAndAppGuid(java.lang.Long, java.lang.Long);
    java.util.List<com.seeyon.boot.starter.enums.dto.CtpEnumItemDto> selectByAppGuidForDataInit(java.lang.Long);
    java.util.List<com.seeyon.boot.starter.enums.dto.CtpEnumItemDto> selectByAppGuid(java.lang.Long);
    java.util.List<com.seeyon.boot.starter.enums.dto.CtpEnumItemDto> queryByGuid(java.lang.Long);
    java.util.List<com.seeyon.boot.starter.enums.dto.CtpEnumItemDto> queryByAppIdAndGuid(java.lang.Long, java.lang.Long);
    com.seeyon.boot.transport.PageData<com.seeyon.boot.starter.enums.dto.CtpEnumItemTreeDto> selectTreePageByConditions(com.seeyon.boot.transport.PageInfo, java.util.Map<java.lang.String, java.lang.Object>, com.seeyon.boot.transport.Sort);
    private java.util.List<com.seeyon.boot.starter.enums.dto.CtpEnumItemTreeDto> buildCtpEnumItemTreeNew(java.util.List<com.seeyon.boot.starter.enums.dto.CtpEnumItemTreeDto>, java.util.List<com.seeyon.boot.starter.enums.domain.entity.CtpEnum>, boolean);
    private void setChildEnumItem(java.util.Map<java.lang.Long, java.util.List<com.seeyon.boot.starter.enums.dto.CtpEnumItemTreeDto>>, com.seeyon.boot.starter.enums.dto.CtpEnumItemTreeDto, boolean);
    private java.util.List<com.seeyon.boot.starter.enums.dto.CtpEnumItemTreeDto> buildCtpEnumItemTree(java.util.List<com.seeyon.boot.starter.enums.dto.CtpEnumItemTreeDto>, java.util.List<com.seeyon.boot.starter.enums.domain.entity.CtpEnum>, boolean);
    private void recursionFn(java.util.List<com.seeyon.boot.starter.enums.dto.CtpEnumItemTreeDto>, com.seeyon.boot.starter.enums.dto.CtpEnumItemTreeDto, boolean);
    private java.util.List<com.seeyon.boot.starter.enums.dto.CtpEnumItemTreeDto> getChildList(java.util.List<com.seeyon.boot.starter.enums.dto.CtpEnumItemTreeDto>, com.seeyon.boot.starter.enums.dto.CtpEnumItemTreeDto);
    private void getCtpEnumItems(java.util.List<com.seeyon.boot.starter.enums.domain.entity.CtpEnumItem>, java.util.List<com.seeyon.boot.starter.enums.domain.entity.CtpEnumItem>, int);
    java.util.List<com.seeyon.boot.starter.enums.dto.CtpEnumItemTreeDto> selectListByConditions(java.util.Map<java.lang.String, java.lang.Object>);
    void deleteEnumItemsByEnumCodes(java.util.List<java.lang.Long>);
    int deleteByAppId4Udc(java.lang.Long);
    com.seeyon.boot.transport.PageData<com.seeyon.boot.starter.enums.dto.CtpEnumItemDto> selectPageByConditions(com.seeyon.boot.transport.PageInfo, java.util.Map<java.lang.String, java.lang.Object>, com.seeyon.boot.transport.Sort);
    java.util.List<com.seeyon.boot.starter.enums.dto.CtpEnumItemDto> selectByEnumCode(java.lang.String);
    java.util.List<com.seeyon.boot.starter.enums.dto.CtpEnumItemSimpleDto> selectByEnumCodeAndAppId(com.seeyon.boot.starter.enums.dto.CtpEnumItemParamDto);
    java.util.List<com.seeyon.boot.starter.enums.dto.CtpEnumItemDto> selectCascadeTreeByEnumCode(com.seeyon.boot.starter.enums.dto.CtpEnumItemParamDto);
    private void queryCascade(java.lang.Long, java.util.List<java.lang.String>);
    private void queryCascadeNew(java.lang.Long, java.util.List<java.lang.String>, java.lang.Integer);
    private void queryCascadeWithLevel(java.lang.Long, java.util.List<java.lang.String>, java.lang.Integer);
    private void queryEnumItem(java.util.List<java.lang.String>, java.lang.Object, java.util.List<com.seeyon.boot.starter.enums.dto.CtpEnumItemSimpleDto>, org.springframework.cache.Cache, java.lang.String, java.lang.Boolean, java.lang.Boolean, java.lang.Boolean);
    private void queryEnumItemNew(java.util.List<java.lang.String>, java.lang.Object, java.lang.Object, java.util.List<com.seeyon.boot.starter.enums.dto.CtpEnumItemSimpleDto>, org.springframework.cache.Cache, java.lang.String, java.lang.Boolean, java.lang.Boolean, java.lang.Boolean);
    java.util.List<com.seeyon.boot.starter.enums.dto.CtpEnumItemSimpleDto> selectByEnumCodesAndAppId(com.seeyon.boot.starter.enums.dto.CtpEnumItemParamDto);
    java.util.List<com.seeyon.boot.starter.enums.dto.CtpEnumItemSimpleDto> selectByEnumCodesAndAppId(java.util.Map<java.lang.String, java.lang.Object>);
    private java.util.List<com.seeyon.boot.starter.enums.domain.entity.CtpEnum> selectEnumList(java.util.List<java.lang.String>, java.util.Map<java.lang.String, java.lang.Object>);
    private void buildEnumItemParam(java.util.List<com.seeyon.boot.starter.enums.domain.entity.CtpEnum>, java.lang.Long, java.util.Map<java.lang.String, java.lang.Object>, boolean);
    void copyByEnumCode(java.lang.String, java.lang.Long, java.lang.Long);
    void copyCascadeEnumItem(java.util.Map<java.lang.Long, com.seeyon.boot.starter.enums.domain.entity.CtpEnum>);
    java.util.List<com.seeyon.boot.starter.enums.dto.CtpEnumItemDto> selectByEnumId(java.lang.Long);
    java.util.List<com.seeyon.boot.starter.enums.domain.entity.CtpEnumItem> selectByEnumIds(java.util.List<java.lang.Long>);
    java.util.List<com.seeyon.boot.starter.enums.dto.CtpEnumItemDto> selectByEnumIdsToDto(java.util.List<java.lang.Long>);
    com.seeyon.boot.starter.enums.dto.CtpEnumItemDto selectByEnumCodeAndItemValue(java.util.Map<java.lang.String, java.lang.Object>);
    java.util.List<com.seeyon.boot.starter.enums.dto.CtpEnumItemDto> selectChildByEnumIdAndItemValue(java.util.Map<java.lang.String, java.lang.Object>);
    java.util.List<com.seeyon.boot.starter.enums.dto.CtpEnumItemDto> selectChildByEnumCodeAndItemValue(com.seeyon.boot.starter.enums.dto.CtpEnumItemParamDto);
    java.util.List<com.seeyon.boot.starter.enums.dto.CtpEnumItemDto> selectChildByEnumCodeAndItemValue(java.util.Map<java.lang.String, java.lang.Object>);
    private com.seeyon.boot.starter.enums.dto.CtpEnumItemDto selectEnumItemByEnumCodeAndValue(java.lang.String, java.lang.String, java.lang.Object);
    java.lang.Integer calcEnumItemOrderNo(java.util.Map<java.lang.String, java.lang.Object>);
    java.util.List<com.seeyon.boot.starter.enums.dto.CtpEnumItemDto> selectByGuids(java.util.List<java.lang.Long>, java.lang.String);
    java.util.Map<java.lang.Long, java.lang.String> selectEnumItemFullName(java.util.Map<java.lang.String, java.lang.Object>);
    private void getEnumItemFullName(java.util.Map<java.lang.Long, java.lang.String>, java.util.List<com.seeyon.boot.starter.enums.dto.CtpEnumItemTreeDto>, com.seeyon.boot.starter.enums.domain.entity.CtpEnum, java.lang.StringBuilder);
    com.seeyon.boot.transport.PageData<com.seeyon.boot.starter.enums.dto.CtpEnumItemDto> selectAllPageByConditions(com.seeyon.boot.transport.PageInfo, java.util.Map<java.lang.String, java.lang.Object>, com.seeyon.boot.transport.Sort);
    void deleteByAppId4AppApproval(java.util.Map<java.lang.String, java.lang.Object>);
    void deleteByAppId4Udc(java.util.Map<java.lang.String, java.lang.Object>);
    private void publicEnumItemDeleteEvent(java.util.List<com.seeyon.boot.starter.enums.domain.entity.CtpEnumItem>);
    java.lang.String exportTemplateFile(com.seeyon.boot.starter.enums.dto.CtpEnumItemImportResultDto);
    java.lang.String exportEnumItem(com.seeyon.boot.starter.enums.dto.CtpEnumItemImportResultDto);
    com.seeyon.boot.starter.enums.dto.CtpEnumItemImportResultDto importEnumItem(com.seeyon.boot.starter.enums.dto.CtpEnumItemImportResultDto);
    private java.util.List<com.seeyon.boot.starter.enums.domain.entity.CtpEnumItem> getEnumItemList(com.seeyon.boot.starter.enums.domain.entity.CtpEnum, java.util.List<com.seeyon.boot.starter.enums.domain.entity.CtpEnum>);
    void clearCache(java.lang.String, java.lang.Long, java.lang.String);
    java.lang.Integer deleteById(java.lang.Long);
```

### `CtpEnumService`（68 方法）

`com.seeyon.boot.starter.enums.domain.service.CtpEnumService`

```java
    java.lang.Long create(com.seeyon.boot.starter.enums.dto.CtpEnumDto);
    java.lang.Integer createBatchForAppApproval(java.util.List<com.seeyon.boot.starter.enums.dto.CtpEnumDto>);
    java.lang.Integer update(com.seeyon.boot.starter.enums.dto.CtpEnumDto);
    int deleteByConditions(java.util.Map<java.lang.String, java.lang.Object>);
    private void packageChildren(java.util.List<com.seeyon.boot.starter.enums.dto.CtpEnumDto>, com.seeyon.boot.starter.enums.domain.entity.CtpEnum);
    private void checkCodeUnique(com.seeyon.boot.starter.enums.dto.CtpEnumDto, boolean);
    java.lang.Integer updatePresetBatch(java.util.Map<java.lang.String, java.lang.Object>);
    java.lang.Integer updateDataStatusBatch(java.util.Map<java.lang.String, java.lang.Object>);
    int deleteByIds(java.util.List<java.lang.Long>);
    java.lang.Long copyById(java.lang.Long);
    private void copyCode(com.seeyon.boot.starter.enums.domain.entity.CtpEnum);
    com.seeyon.boot.starter.enums.dto.CtpEnumDto selectById(java.lang.Long);
    java.util.List<com.seeyon.boot.starter.enums.dto.CtpEnumDto> selectByIds(java.util.List<java.lang.Long>);
    java.util.List<com.seeyon.boot.starter.enums.dto.CtpEnumDto> selectByAppId(java.lang.Long);
    java.util.List<com.seeyon.boot.starter.enums.dto.CtpEnumDto> selectByAppIdAndAppGuid(java.lang.Long, java.lang.Long);
    java.util.List<com.seeyon.boot.starter.enums.dto.CtpEnumDto> selectByAppGuid(java.lang.Long);
    java.util.List<com.seeyon.boot.starter.enums.dto.CtpEnumDto> queryByGuid(java.lang.Long);
    java.util.List<com.seeyon.boot.starter.enums.dto.CtpEnumDto> queryByAppIdAndGuid(java.lang.Long, java.lang.Long);
    com.seeyon.boot.transport.PageData<com.seeyon.boot.starter.enums.dto.CtpEnumDto> selectPageByConditions(com.seeyon.boot.transport.PageInfo, java.util.Map<java.lang.String, java.lang.Object>, com.seeyon.boot.transport.Sort);
    java.util.List<com.seeyon.boot.starter.enums.dto.CtpEnumDto> selectListByConditions(java.util.Map<java.lang.String, java.lang.Object>, com.seeyon.boot.transport.Sort);
    java.util.List<com.seeyon.boot.starter.enums.dto.CtpEnumDto> selectListByConditionsNoLevel(java.util.Map<java.lang.String, java.lang.Object>, com.seeyon.boot.transport.Sort);
    java.util.List<com.seeyon.boot.starter.enums.dto.CtpEnumDto> selectByConditionsContainsCascade(java.util.Map<java.lang.String, java.lang.Object>, com.seeyon.boot.transport.Sort);
    java.util.List<com.seeyon.boot.starter.enums.dto.CtpEnumDto> selectByConditionsContainsCascadeEnable(java.util.Map<java.lang.String, java.lang.Object>, com.seeyon.boot.transport.Sort);
    void deleteEnums(java.lang.Long);
    int deleteByAppId4Udc(java.lang.Long);
    void deleteByAppId4Udc(java.util.Map<java.lang.String, java.lang.Object>);
    com.seeyon.boot.starter.enums.dto.CtpEnumDto selectByCode(java.lang.String);
    com.seeyon.boot.starter.enums.dto.CtpEnumDto selectParentByCode(java.util.Map<java.lang.String, java.lang.Object>);
    com.seeyon.boot.starter.enums.dto.CtpEnumDto selectByRootEnumIdAndEnumLevel(java.util.Map<java.lang.String, java.lang.Object>);
    void deleteByAppId4AppApproval(java.util.Map<java.lang.String, java.lang.Object>);
    private void removeAppGuid(java.util.Map<java.lang.String, java.lang.Object>);
    java.lang.Integer calcEnumOrderNo(java.util.Map<java.lang.String, java.lang.Object>);
    void updateByItem(java.util.List<java.lang.Long>);
```

### `CtpEnumCategoryService`（36 方法）

`com.seeyon.boot.starter.enums.domain.service.CtpEnumCategoryService`

```java
    java.lang.Long create(com.seeyon.boot.starter.enums.dto.CtpEnumCategoryDto);
    java.lang.Integer createBatchForAppApproval(java.util.List<com.seeyon.boot.starter.enums.dto.CtpEnumCategoryDto>);
    java.lang.Integer update(com.seeyon.boot.starter.enums.dto.CtpEnumCategoryDto);
    int deleteByConditions(java.util.Map<java.lang.String, java.lang.Object>);
    java.lang.Integer updatePresetBatch(java.util.Map<java.lang.String, java.lang.Object>);
    java.lang.Integer updateDataStatusBatch(java.util.Map<java.lang.String, java.lang.Object>);
    int deleteById(java.lang.Long);
    com.seeyon.boot.starter.enums.dto.CtpEnumCategoryDto selectById(java.lang.Long);
    java.util.List<com.seeyon.boot.starter.enums.dto.CtpEnumCategoryDto> selectByAppId(java.lang.Long);
    java.util.List<com.seeyon.boot.starter.enums.dto.CtpEnumCategoryDto> selectByAppIdAndAppGuid(java.lang.Long, java.lang.Long);
    java.util.List<com.seeyon.boot.starter.enums.dto.CtpEnumCategoryDto> selectByAppGuid(java.lang.Long);
    private java.util.List<com.seeyon.boot.starter.enums.dto.CtpEnumCategoryDto> queryByGuid(java.lang.Long);
    private java.util.List<com.seeyon.boot.starter.enums.dto.CtpEnumCategoryDto> queryByAppIdAndGuid(java.lang.Long, java.lang.Long);
    java.util.List<com.seeyon.boot.starter.enums.dto.CtpEnumCategoryAndItemDto> selectListByConditions(java.util.Map<java.lang.String, java.lang.Object>, com.seeyon.boot.transport.Sort);
    int deleteByAppId4Udc(java.lang.Long);
    com.seeyon.boot.starter.enums.dto.CtpEnumCategoryAndEnumDto selectCategoryAndEnum(java.lang.String);
    com.seeyon.boot.starter.enums.dto.CtpEnumCategoryAndEnumDto selectCategoryAndEnumByAppName(com.seeyon.boot.starter.enums.dto.CtpEnumCategoryAndEnumSearchDto);
    com.seeyon.boot.starter.enums.dto.CtpEnumCategoryAndEnumDto selectCategoryAndEnumByAppIdAndAppGuid(java.lang.String, java.lang.String);
    private void checkNameUnique(com.seeyon.boot.starter.enums.dto.CtpEnumCategoryDto);
    void deleteByAppId4AppApproval(java.lang.String);
    void deleteByAppId4Udc(java.lang.String);
```

### `CtpEnumItemAppService`（32 方法）

`com.seeyon.boot.starter.enums.appservice.CtpEnumItemAppService`

```java
    com.seeyon.boot.transport.SingleResponse<java.lang.Long> create(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.enums.dto.CtpEnumItemDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> createBatchForAppApproval(java.util.List<com.seeyon.boot.starter.enums.dto.CtpEnumItemDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> createOrUpdateBatchForOnlypage(java.util.List<com.seeyon.boot.starter.enums.dto.CtpEnumItemDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> update(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.enums.dto.CtpEnumItemDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> updatePresetBatch(com.seeyon.boot.transport.ListRequest);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> updateDataStatusBatch(com.seeyon.boot.transport.ListRequest);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> deleteByIds(com.seeyon.boot.transport.SingleRequest<java.util.List<java.lang.Long>>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.boot.starter.enums.dto.CtpEnumItemDto> selectById(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.boot.starter.enums.dto.CtpEnumItemDto> selectByIds(com.seeyon.boot.transport.SingleRequest<java.util.List<java.lang.Long>>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.boot.starter.enums.dto.CtpEnumItemTreeDto> selectListByConditions(com.seeyon.boot.transport.ListRequest);
    com.seeyon.boot.transport.PageResponse<com.seeyon.boot.starter.enums.dto.CtpEnumItemTreeDto> selectTreePageByConditions(com.seeyon.boot.transport.PageRequest);
    com.seeyon.boot.transport.PageResponse<com.seeyon.boot.starter.enums.dto.CtpEnumItemDto> selectPageByConditions(com.seeyon.boot.transport.PageRequest);
    com.seeyon.boot.transport.ListResponse<com.seeyon.boot.starter.enums.dto.CtpEnumItemDto> selectByEnumCode(com.seeyon.boot.transport.SingleRequest<java.lang.String>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.boot.starter.enums.dto.CtpEnumItemSimpleDto> selectByEnumCodeAndAppId(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.enums.dto.CtpEnumItemParamDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.boot.starter.enums.dto.CtpEnumItemSimpleDto> selectByEnumCodesAndAppIdForUdc(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.enums.dto.CtpEnumItemParamDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.boot.starter.enums.dto.CtpEnumItemSimpleDto> selectByEnumCodesAndAppId(com.seeyon.boot.transport.ListRequest);
    com.seeyon.boot.transport.ListResponse<com.seeyon.boot.starter.enums.dto.CtpEnumItemDto> selectByEnumId(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.boot.starter.enums.dto.CtpEnumItemDto> selectByEnumIds(com.seeyon.boot.transport.SingleRequest<java.util.List<java.lang.Long>>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.boot.starter.enums.dto.CtpEnumItemDto> selectByEnumCodeAndItemValue(com.seeyon.boot.transport.ListRequest);
    com.seeyon.boot.transport.ListResponse<com.seeyon.boot.starter.enums.dto.CtpEnumItemDto> selectChildByEnumIdAndItemValue(com.seeyon.boot.transport.ListRequest);
    com.seeyon.boot.transport.ListResponse<com.seeyon.boot.starter.enums.dto.CtpEnumItemDto> selectChildByEnumCodeAndItemValueForUdc(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.enums.dto.CtpEnumItemParamDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.boot.starter.enums.dto.CtpEnumItemDto> selectChildByEnumCodeAndItemValue(com.seeyon.boot.transport.ListRequest);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> calcEnumItemOrderNo(com.seeyon.boot.transport.ListRequest);
    com.seeyon.boot.transport.ListResponse<com.seeyon.boot.starter.enums.dto.CtpEnumItemDto> selectByGuids(com.seeyon.boot.transport.SingleRequest<java.util.List<java.lang.Long>>, com.seeyon.boot.transport.SingleRequest<java.lang.String>);
    com.seeyon.boot.transport.SingleResponse<java.util.Map<java.lang.Long, java.lang.String>> selectEnumItemFullName(com.seeyon.boot.transport.ListRequest);
    com.seeyon.boot.transport.PageResponse<com.seeyon.boot.starter.enums.dto.CtpEnumItemDto> selectAllPageByConditions(com.seeyon.boot.transport.PageRequest);
    com.seeyon.boot.transport.ListResponse<com.seeyon.boot.starter.enums.dto.CtpEnumItemDto> selectByAppGuid(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.SingleResponse<java.lang.String> exportTemplateFile(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.enums.dto.CtpEnumItemImportResultDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.String> exportEnumItem(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.enums.dto.CtpEnumItemImportResultDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.boot.starter.enums.dto.CtpEnumItemImportResultDto> importEnumItem(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.enums.dto.CtpEnumItemImportResultDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.boot.starter.enums.dto.CtpEnumItemDto> selectCascadeTreeByEnumCode(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.enums.dto.CtpEnumItemParamDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> deleteById(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
```

### `CtpEnumAppService`（19 方法）

`com.seeyon.boot.starter.enums.appservice.CtpEnumAppService`

```java
    com.seeyon.boot.transport.SingleResponse<java.lang.Long> create(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.enums.dto.CtpEnumDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> createBatchForAppApproval(java.util.List<com.seeyon.boot.starter.enums.dto.CtpEnumDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> createOrUpdateBatchForOnlypage(java.util.List<com.seeyon.boot.starter.enums.dto.CtpEnumDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> update(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.enums.dto.CtpEnumDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> updatePresetBatch(com.seeyon.boot.transport.ListRequest);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> updateDataStatusBatch(com.seeyon.boot.transport.ListRequest);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> deleteByIds(com.seeyon.boot.transport.SingleRequest<java.util.List<java.lang.Long>>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Long> copyById(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.boot.starter.enums.dto.CtpEnumDto> selectById(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.boot.starter.enums.dto.CtpEnumDto> selectByIds(com.seeyon.boot.transport.SingleRequest<java.util.List<java.lang.Long>>);
    com.seeyon.boot.transport.PageResponse<com.seeyon.boot.starter.enums.dto.CtpEnumDto> selectPageByConditions(com.seeyon.boot.transport.PageRequest);
    com.seeyon.boot.transport.ListResponse<com.seeyon.boot.starter.enums.dto.CtpEnumDto> selectListByConditions(com.seeyon.boot.transport.ListRequest);
    com.seeyon.boot.transport.ListResponse<com.seeyon.boot.starter.enums.dto.CtpEnumDto> selectListByConditionsNoLevel(com.seeyon.boot.transport.ListRequest);
    com.seeyon.boot.transport.ListResponse<com.seeyon.boot.starter.enums.dto.CtpEnumDto> selectByConditionsContainsCascade(com.seeyon.boot.transport.ListRequest);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.boot.starter.enums.dto.CtpEnumDto> selectByCode(com.seeyon.boot.transport.SingleRequest<java.lang.String>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.boot.starter.enums.dto.CtpEnumDto> selectParentByCode(com.seeyon.boot.transport.ListRequest);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.boot.starter.enums.dto.CtpEnumDto> selectByRootEnumIdAndEnumLevel(com.seeyon.boot.transport.ListRequest);
    com.seeyon.boot.transport.ListResponse<com.seeyon.boot.starter.enums.dto.CtpEnumDto> selectByAppGuid(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> calcEnumOrderNo(com.seeyon.boot.transport.ListRequest);
```

### `CtpEnumUpgradeExtendService`（16 方法）

`com.seeyon.boot.starter.enums.domain.service.upgrade.CtpEnumUpgradeExtendService`

```java
    void upgradeOrderNo(java.lang.String, java.lang.String);
    static int getIntRandom(java.lang.Integer);
    void upgradeAppId(java.lang.String, java.lang.String);
    void upgradeEnumAppId();
    private java.util.Map<java.lang.Long, java.lang.Long> getApplicationIdByGuid(java.util.List<java.lang.Long>);
```

### `EnumCacheUtils`（16 方法）

`com.seeyon.boot.starter.enums.util.EnumCacheUtils`

```java
    java.lang.Object get(java.lang.String);
    java.lang.Object getLocal(java.lang.String);
    java.lang.Object getLocal(java.lang.String, java.lang.Long);
    java.lang.Boolean isPreparingCache(java.lang.String);
    int getLocalCacheCount();
    java.lang.Object getLocalCache(java.lang.String);
    java.util.List multiGet(java.util.Collection);
    void set(java.lang.String, java.lang.Object);
    void setLocalCache(java.lang.String, java.lang.Object);
    void setLocalCache(java.lang.String, java.lang.Object, long);
    void setLocalCacheIsPreparing(java.lang.String);
    void set(java.lang.String, java.lang.Object, long);
    void delete(java.lang.String);
    void delete(java.util.Collection<java.lang.String>);
    java.util.Set keys(java.lang.String);
    private java.lang.Boolean isLong(java.lang.String);
```

### `CtpEnumCategoryAppService`（14 方法）

`com.seeyon.boot.starter.enums.appservice.CtpEnumCategoryAppService`

```java
    com.seeyon.boot.transport.SingleResponse<java.lang.Long> create(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.enums.dto.CtpEnumCategoryDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> createBatchForAppApproval(java.util.List<com.seeyon.boot.starter.enums.dto.CtpEnumCategoryDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> createOrUpdateBatchForOnlypage(java.util.List<com.seeyon.boot.starter.enums.dto.CtpEnumCategoryDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> update(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.enums.dto.CtpEnumCategoryDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> updatePresetBatch(com.seeyon.boot.transport.ListRequest);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> updateDataStatusBatch(com.seeyon.boot.transport.ListRequest);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> deleteById(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.boot.starter.enums.dto.CtpEnumCategoryDto> selectById(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.boot.starter.enums.dto.CtpEnumCategoryAndItemDto> selectListByConditions(com.seeyon.boot.transport.ListRequest);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.boot.starter.enums.dto.CtpEnumCategoryAndEnumDto> selectCategoryAndEnum(com.seeyon.boot.transport.SingleRequest<java.lang.String>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.boot.starter.enums.dto.CtpEnumCategoryAndEnumDto> selectCategoryAndEnumByAppName(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.enums.dto.CtpEnumCategoryAndEnumSearchDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.boot.starter.enums.dto.CtpEnumCategoryDto> selectByAppGuid(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Void> deleteByAppId4AppApproval(com.seeyon.boot.transport.SingleRequest<java.lang.String>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Void> deleteByAppId4Udc(com.seeyon.boot.transport.SingleRequest<java.lang.String>);
```

### `EnumItemExportUtils`（9 方法）

`com.seeyon.boot.starter.enums.util.EnumItemExportUtils`

```java
    static void checkExcelDataValidate(java.util.LinkedHashMap<java.lang.Integer, java.lang.Object>, java.lang.StringBuilder, boolean, java.util.List<java.lang.Object>);
    static void setStatus(java.lang.Object, java.lang.StringBuilder);
    static void getImportEnumItemList(java.util.LinkedHashMap<java.lang.Integer, java.lang.Object>, com.seeyon.boot.starter.enums.dto.CtpEnumItemImportDto, boolean);
    static void setEnumItemStatus(java.lang.Object, com.seeyon.boot.starter.enums.dto.CtpEnumItemImportDto);
    static java.util.List<java.lang.Object> getErrorData(com.seeyon.boot.starter.enums.dto.CtpEnumItemImportDto, boolean, java.lang.String);
    static void getHeader(com.seeyon.boot.starter.enums.CtpEnumType, com.seeyon.boot.util.excel.model.SheetModel, boolean);
    static void setCellStyle(com.seeyon.boot.util.excel.model.style.CellStyle);
    static java.lang.String getCurrentI18nName(java.lang.String);
    static java.lang.String getCurrentI18nName(java.lang.String, java.lang.String);
```

### `CtpEnumDataInitBeforeUpdateService`（5 方法）

`com.seeyon.boot.starter.enums.domain.service.deploy.CtpEnumDataInitBeforeUpdateService`

```java
    private com.seeyon.boot.starter.enums.domain.dao.CtpEnumDao getCtpEnumDao();
    com.seeyon.boot.starter.datainit.adepter.BeforeBatchExeResult before(com.seeyon.boot.starter.datainit.adepter.BeforeBatchExeParams);
```

### `CtpEnumItemDataInitBeforeUpdateService`（5 方法）

`com.seeyon.boot.starter.enums.domain.service.deploy.CtpEnumItemDataInitBeforeUpdateService`

```java
    private com.seeyon.boot.starter.enums.domain.dao.CtpEnumItemDao getCtpEnumItemDao();
    com.seeyon.boot.starter.datainit.adepter.BeforeBatchExeResult before(com.seeyon.boot.starter.datainit.adepter.BeforeBatchExeParams);
```

### `CtpEnumItemDataInitExtService`（5 方法）

`com.seeyon.boot.starter.enums.domain.service.deploy.CtpEnumItemDataInitExtService`

```java
    private com.seeyon.boot.starter.enums.domain.service.CtpEnumItemService getCtpEnumItemService();
    com.seeyon.boot.starter.datainit.adepter.BeforeBatchExeResult before(com.seeyon.boot.starter.datainit.adepter.BeforeBatchExeParams);
    private java.util.List<java.lang.Object> mergeData(com.seeyon.boot.starter.datainit.adepter.BeforeBatchExeParams);
```

## 四、枚举（2）

- `BizType`（5 常量）：UDC_DESIGN, UDC_RUNTIME, FORM, ORGANIZATION, CTP_AFFAIR
- `CtpEnumType`（3 常量）：SAME_LEVEL, MULTI_LEVEL, CASCADE
