# boot-license-generator：接口与方法签名

> 自动生成，勿手改。`tools/core/platform/emit_package_surfaces.py` 重跑即可。
> 构件 `com.seeyon:boot-license-generator`（jar `boot-license-generator-2.6.0.jar`）
> 规模：8 类 / 0 接口 / 0 注解 / 0 枚举 / 1 个关键类 / 61 方法。
> 签名逐字来自 javap 原文；已去掉 `public` 前缀与 `throws` 子句。

## 一、接口（0）

（本构件没有接口）

## 二、关键类（1）

### `KryoUtil`（8 方法）

`com.seeyon.boot.license.KryoUtil`

```java
    static byte[] serialize(java.lang.Object);
    static byte[] serializeForObjectArray(java.lang.Object[]);
    static java.lang.Object[] deserializeToObjectArray(byte[]);
    static java.lang.String serializeToStr(java.lang.Object);
    static java.lang.Object deserialize(byte[]);
    static java.lang.Object deserializeStr(java.lang.String);
    static <T> T copy(T);
```
