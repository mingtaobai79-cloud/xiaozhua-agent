# app-common-facade：接口与方法签名

> 自动生成，勿手改。`tools/core/platform/emit_package_surfaces.py` 重跑即可。
> 构件 `com.seeyon:app-common-facade`（jar `app-common-facade-5.3.274.jar`）
> 规模：103 类 / 19 接口 / 0 注解 / 19 枚举 / 4 个关键类 / 1053 方法。
> 签名逐字来自 javap 原文；已去掉 `public` 前缀与 `throws` 子句。

## 一、接口（19）

### `CategoryCommonAppService`（12 方法）

`com.seeyon.app.common.category.api.CategoryCommonAppService`

```java
    com.seeyon.boot.transport.SingleResponse<java.lang.Long> create(com.seeyon.boot.transport.SingleRequest<com.seeyon.app.common.category.dto.CategoryDto>);
    default com.seeyon.boot.transport.SingleResponse<java.lang.Integer> createBatch(com.seeyon.boot.transport.SingleRequest<com.seeyon.app.common.category.dto.CategorySyncBatchDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> update(com.seeyon.boot.transport.SingleRequest<com.seeyon.app.common.category.dto.CategoryDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> deleteById(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.app.common.category.dto.CategoryDto> selectById(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.app.common.category.dto.CategoryDto> selectListByConditions(com.seeyon.boot.transport.ListRequest);
    com.seeyon.boot.transport.ListResponse<com.seeyon.app.common.category.dto.CategoryTreeDto> selectTreeByIds(com.seeyon.boot.transport.SingleRequest<java.util.List<java.lang.Long>>);
    com.seeyon.boot.transport.ListResponse<java.lang.Long> selectChildrenById(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.ListResponse<java.lang.Long> selectChildrenByCode(com.seeyon.boot.transport.SingleRequest<java.lang.String>);
    default com.seeyon.boot.transport.SingleResponse<java.util.List<com.seeyon.app.common.category.dto.CategoryRelationMapDto>> checkCategoryBatch(com.seeyon.boot.transport.SingleRequest<java.util.List<com.seeyon.app.common.category.dto.CategoryDto>>);
    default com.seeyon.boot.transport.SingleResponse<java.util.List<com.seeyon.app.common.category.dto.CategoryRelationMapDto>> getCategoryDataInitResult(com.seeyon.boot.transport.SingleRequest<java.lang.String>);
    default com.seeyon.boot.transport.ListResponse<com.seeyon.app.common.category.dto.CategoryDto> selectAllParentByIds(com.seeyon.boot.transport.SingleRequest<java.util.List<java.lang.Long>>);
```

### `WorktimeAppService`（12 方法）

`com.seeyon.app.common.worktime.api.WorktimeAppService`

```java
    com.seeyon.boot.transport.SingleResponse<com.seeyon.app.common.worktime.dto.WorktimeDto> selectWorktimeByOrgIdAndYear(com.seeyon.boot.transport.SingleRequest<com.seeyon.app.common.worktime.dto.WorktimeYearDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.app.common.worktime.dto.WorktimeSetDto> selectByOrgIdAndYear(com.seeyon.boot.transport.SingleRequest<com.seeyon.app.common.worktime.dto.WorktimeYearDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.app.common.worktime.dto.WorktimeSetDto> getByParentOrgIdAndYear(com.seeyon.boot.transport.SingleRequest<com.seeyon.app.common.worktime.dto.WorktimeYearDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.app.common.worktime.dto.WorktimeResDto> getWorkTimeByYear(com.seeyon.boot.transport.SingleRequest<com.seeyon.app.common.worktime.dto.WorktimeYearDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.app.common.worktime.dto.WorktimeResDto> getWorkTimeBetweenYear(com.seeyon.boot.transport.SingleRequest<com.seeyon.app.common.worktime.dto.WorktimeBetweenYearDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.app.common.worktime.dto.WorktimeResDto> getWorkTimeBetweenDate(com.seeyon.boot.transport.SingleRequest<com.seeyon.app.common.worktime.dto.WorktimeDateTimeDto>);
    com.seeyon.boot.transport.SingleResponse<java.util.Date> getWorkEndDate(com.seeyon.boot.transport.SingleRequest<com.seeyon.app.common.worktime.dto.WorktimeAfterTimeDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.app.common.worktime.dto.WorkDayTypeDto> getWorkDayType(com.seeyon.boot.transport.SingleRequest<com.seeyon.app.common.worktime.dto.WorktimeDateDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.app.common.worktime.dto.WorktimeFestivalDto> getFestivalByYear(com.seeyon.boot.transport.SingleRequest<java.lang.Integer>);
    com.seeyon.boot.transport.SingleResponse<java.util.Date> selectSpecifyWorkDay(com.seeyon.boot.transport.SingleRequest<com.seeyon.app.common.worktime.dto.WorkDayRequestDto>);
    com.seeyon.boot.transport.ListResponse<java.lang.String> selectNonWorkDayList(com.seeyon.boot.transport.SingleRequest<com.seeyon.app.common.worktime.dto.WorktimeDateTimeDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> syncWorktimeSpecialDay(com.seeyon.boot.transport.SingleRequest<com.seeyon.app.common.worktime.dto.WorktimeSyncSpecialDayDto>);
```

### `AgentCoreAppService`（10 方法）

`com.seeyon.app.common.agent.api.AgentCoreAppService`

```java
    com.seeyon.boot.transport.ListResponse<com.seeyon.app.common.agent.dto.AgentInfoDto> selectListByCondition(com.seeyon.boot.transport.SingleRequest<java.util.Map<java.lang.String, java.lang.Object>>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Long> create(com.seeyon.boot.transport.SingleRequest<com.seeyon.app.common.agent.dto.AgentDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> update(com.seeyon.boot.transport.SingleRequest<com.seeyon.app.common.agent.dto.AgentDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.app.common.agent.dto.AgentDto> selectById(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.app.common.agent.dto.AgentDto> selectByIds(com.seeyon.boot.transport.SingleRequest<java.util.List<java.lang.Long>>);
    com.seeyon.boot.transport.PageResponse<com.seeyon.app.common.agent.dto.AgentDto> selectPageByCondition(com.seeyon.boot.transport.PageRequest);
    com.seeyon.boot.transport.PageResponse<com.seeyon.app.common.agent.dto.AgentDto> selectBizAgentPageByCondition(com.seeyon.boot.transport.PageRequest);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> cancelAgent(com.seeyon.boot.transport.SingleRequest<java.util.Map<java.lang.String, java.lang.Object>>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> batch(com.seeyon.boot.transport.SingleRequest<java.util.List<com.seeyon.app.common.agent.dto.AgentDto>>);
    default com.seeyon.boot.transport.SingleResponse<com.seeyon.app.common.agent.dto.AgentPropertiesSetDto> getAgentProperties();
```

### `AgentCommonAppService`（9 方法）

`com.seeyon.app.common.agent.api.AgentCommonAppService`

```java
    com.seeyon.boot.transport.ListResponse<com.seeyon.app.common.agent.dto.AgentInfoDto> selectByAgentUserId(com.seeyon.boot.transport.SingleRequest<java.util.Map<java.lang.String, java.lang.Object>>);
    com.seeyon.boot.transport.SingleResponse<java.util.Map<java.lang.String, java.lang.Object>> hasAgent(com.seeyon.boot.transport.SingleRequest<com.seeyon.app.common.agent.dto.AgentParamDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.app.common.agent.dto.AgentInfoDto> selectByUserIdAndTemplate(com.seeyon.boot.transport.SingleRequest<com.seeyon.app.common.agent.dto.AgentParamDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.app.common.agent.dto.AgentInfoDto> selectById(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Long> create(com.seeyon.boot.transport.SingleRequest<com.seeyon.app.common.agent.dto.AgentDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> update(com.seeyon.boot.transport.SingleRequest<com.seeyon.app.common.agent.dto.AgentDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> deleteAgent(com.seeyon.boot.transport.SingleRequest<java.util.Map<java.lang.String, java.lang.Object>>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.app.common.agent.dto.AgentDto> selectListByConditions(com.seeyon.boot.transport.ListRequest);
    com.seeyon.boot.transport.ListResponse<com.seeyon.app.common.agent.dto.AgentDto> selectEffectiveAgentList(com.seeyon.boot.transport.SingleRequest<com.seeyon.app.common.agent.dto.AgentEffectiveRequestDto>);
```

### `MyAttentionCommonAppService`（9 方法）

`com.seeyon.app.common.attention.api.MyAttentionCommonAppService`

```java
    com.seeyon.boot.transport.SingleResponse<java.lang.Long> create(com.seeyon.boot.transport.SingleRequest<com.seeyon.app.common.attention.dto.MyAttentionDto>);
    default com.seeyon.boot.transport.SingleResponse<java.lang.Integer> createOrUpdateBatch(com.seeyon.boot.transport.SingleRequest<java.util.List<com.seeyon.app.common.attention.dto.MyAttentionDto>>);
    default com.seeyon.boot.transport.SingleResponse<java.lang.Integer> deleteBatchByObjectIds(com.seeyon.boot.transport.SingleRequest<com.seeyon.app.common.attention.dto.MyAttentionBatchDeleteDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> deleteByObjectIdOrPageUrl(com.seeyon.boot.transport.SingleRequest<java.util.Map<java.lang.String, java.lang.Object>>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Boolean> isAttention(com.seeyon.boot.transport.SingleRequest<java.util.Map<java.lang.String, java.lang.Object>>);
    com.seeyon.boot.transport.SingleResponse<java.util.List<com.seeyon.app.common.attention.dto.MyAttentionQueryDto>> getAttentionByObjectIds(com.seeyon.boot.transport.SingleRequest<java.util.List<java.lang.Long>>);
    com.seeyon.boot.transport.ListResponse<java.lang.Long> getAttentionUserIdsByObjectIds(com.seeyon.boot.transport.SingleRequest<java.util.List<java.lang.Long>>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> update(com.seeyon.boot.transport.SingleRequest<com.seeyon.app.common.attention.dto.MyAttentionDto>);
    com.seeyon.boot.transport.PageResponse<com.seeyon.app.common.attention.dto.MyAttentionQueryDto> selectPageByConditions(com.seeyon.boot.transport.PageRequest);
```

### `ImageAppService`（4 方法）

`com.seeyon.app.common.image.api.ImageAppService`

```java
    com.seeyon.boot.transport.SingleResponse<java.lang.Boolean> create(com.seeyon.boot.transport.SingleRequest<java.util.List<com.seeyon.app.common.image.dto.ImageDto>>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> update(com.seeyon.boot.transport.SingleRequest<java.util.List<com.seeyon.app.common.image.dto.ImageDto>>);
    com.seeyon.boot.transport.PageResponse<com.seeyon.app.common.image.dto.ImageDto> selectImage(com.seeyon.boot.transport.PageRequest);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> deleteImage(com.seeyon.boot.transport.SingleRequest<java.util.List<java.lang.Long>>);
```

### `ImageCategoryAppService`（4 方法）

`com.seeyon.app.common.image.api.ImageCategoryAppService`

```java
    com.seeyon.boot.transport.SingleResponse<java.lang.Long> save(com.seeyon.boot.transport.SingleRequest<com.seeyon.app.common.image.dto.ImageCategoryDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.app.common.image.dto.ImageCategoryDto> selectImageCategory(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> deleteCategory(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> selectCountByCategoryId(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
```

### `ImageStoreAppService`（4 方法）

`com.seeyon.app.common.image.api.ImageStoreAppService`

```java
    com.seeyon.boot.transport.SingleResponse<java.lang.Long> save(com.seeyon.boot.transport.SingleRequest<com.seeyon.app.common.image.dto.ImageStoreDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.app.common.image.dto.ImageStoreDto> selectImageStore();
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> deleteStore(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.app.common.image.dto.ImageStoreAndCategoryDto> selectStoreAndCategory();
```

### `IntegralLedgerOprateAppService`（4 方法）

`com.seeyon.app.common.integral.api.IntegralLedgerOprateAppService`

```java
    com.seeyon.boot.transport.SingleResponse<com.seeyon.app.common.integral.dto.IntegralLedgerDto> create(com.seeyon.boot.transport.SingleRequest<com.seeyon.app.common.integral.dto.IntegralLedgerDto>);
    com.seeyon.boot.transport.SingleResponse<java.util.List<com.seeyon.app.common.integral.dto.IntegralLedgerDto>> createBatch(com.seeyon.boot.transport.SingleRequest<java.util.List<com.seeyon.app.common.integral.dto.IntegralLedgerDto>>);
    com.seeyon.boot.transport.PageResponse<com.seeyon.app.common.integral.dto.IntegralLedgerDto> selectPageByConditions(com.seeyon.boot.transport.PageDtoRequest<com.seeyon.app.common.integral.dto.IntegralLedgerDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.app.common.integral.dto.IntegralRankResultDto> selectRankById(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
```

### `MgnAggDataInitAppService`（4 方法）

`com.seeyon.app.common.mgn.api.MgnAggDataInitAppService`

```java
    com.seeyon.boot.transport.ListResponse<com.seeyon.app.common.mgn.dto.CtpMgnAggDataDto> selectListByConditions(com.seeyon.boot.transport.ListRequest);
    com.seeyon.boot.transport.ListResponse<com.seeyon.app.common.mgn.dto.CtpMgnAggDataDto> selectListByMap(com.seeyon.boot.transport.SingleRequest<java.util.Map<java.lang.String, java.lang.Object>>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Long> create(com.seeyon.boot.transport.SingleRequest<com.seeyon.app.common.mgn.dto.CtpMgnAggDataDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> update(com.seeyon.boot.transport.SingleRequest<com.seeyon.app.common.mgn.dto.CtpMgnAggDataDto>);
```

### `SystemConfigCommonAppService`（4 方法）

`com.seeyon.app.common.system.api.SystemConfigCommonAppService`

```java
    com.seeyon.boot.transport.SingleResponse<com.seeyon.app.common.system.dto.I18nConfigDto> getI18nConfig(com.seeyon.boot.transport.SingleRequest<java.util.Map<java.lang.String, java.lang.Object>>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.app.common.system.dto.SystemConfigDto> getSystemConfig(com.seeyon.boot.transport.SingleRequest<java.util.Map<java.lang.String, java.lang.Object>>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> saveSystemConfig(com.seeyon.boot.transport.SingleRequest<java.util.Map<java.lang.String, java.lang.Object>>);
    default com.seeyon.boot.transport.SingleResponse<java.util.Map<java.lang.Long, java.lang.String>> getLocaleParameterByUserIds(com.seeyon.boot.transport.SingleRequest<java.util.List<java.lang.Long>>);
```

### `ThemeAppService`（4 方法）

`com.seeyon.app.common.theme.api.ThemeAppService`

```java
    com.seeyon.boot.transport.SingleResponse<com.seeyon.app.common.theme.dto.ThemeDto> selectById(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Long> create(com.seeyon.boot.transport.SingleRequest<com.seeyon.app.common.theme.dto.ThemeDto>);
    com.seeyon.boot.transport.PageResponse<com.seeyon.app.common.theme.dto.ThemeDto> selectPagePropertiesByConditions(com.seeyon.boot.transport.PageRequest);
    com.seeyon.boot.transport.SingleResponse<java.lang.Boolean> publishById(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
```

### `AssociateCommonAppService`（3 方法）

`com.seeyon.app.common.associate.api.AssociateCommonAppService`

```java
    com.seeyon.boot.transport.ListResponse<com.seeyon.app.common.associate.dto.AssociateEntityReferDto> selectEntityConfigByConditions(com.seeyon.boot.transport.ListRequest);
    com.seeyon.boot.transport.ListResponse<com.seeyon.app.common.associate.dto.AssociateCompleteDto> selectAssociateCompleteByAppName(com.seeyon.boot.transport.SingleRequest<java.lang.String>);
    default com.seeyon.boot.transport.ListResponse<com.seeyon.app.common.associate.dto.AssociateCompleteDto> selectAssociateCompleteByControlCodes(com.seeyon.boot.transport.ListRequest);
```

### `LabelAppService`（3 方法）

`com.seeyon.app.common.label.api.LabelAppService`

```java
    com.seeyon.boot.transport.SingleResponse<java.lang.Boolean> updateReferenceCount(com.seeyon.boot.transport.SingleRequest<com.seeyon.app.common.label.dto.LabelDepartmentDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Boolean> batchUpdateReferenceCount(com.seeyon.boot.transport.SingleRequest<com.seeyon.app.common.label.dto.LabelUpdateCountDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.app.common.label.dto.LabelDto> batchSelectLabelDtos(com.seeyon.boot.transport.SingleRequest<java.util.List<java.lang.Long>>);
```

### `SealCommonAppService`（3 方法）

`com.seeyon.app.common.seal.api.SealCommonAppService`

```java
    com.seeyon.boot.transport.ListResponse<com.seeyon.app.common.seal.dto.SealDto> selectUsableList(com.seeyon.boot.transport.ListRequest);
    com.seeyon.boot.transport.SingleResponse<java.lang.Boolean> checkSealPassword(com.seeyon.boot.transport.SingleRequest<com.seeyon.app.common.seal.dto.SealPasswordCheckDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.app.common.seal.dto.SealDto> selectListByCondition(com.seeyon.boot.transport.ListRequest);
```

### `QrCodeCommonAppService`（2 方法）

`com.seeyon.app.common.qrcode.api.QrCodeCommonAppService`

```java
    com.seeyon.boot.transport.SingleResponse<com.seeyon.app.common.qrcode.dto.QrCodeResultDto> create(com.seeyon.boot.transport.SingleRequest<com.seeyon.app.common.qrcode.dto.QrCodeCreateDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.app.common.qrcode.dto.QrCodeDto> selectByJson(com.seeyon.boot.transport.SingleRequest<java.lang.String>);
```

### `VideoMeetingRoomCommonAppService`（2 方法）

`com.seeyon.app.common.videomeeting.api.VideoMeetingRoomCommonAppService`

```java
    com.seeyon.boot.transport.SingleResponse<com.seeyon.app.common.videomeeting.dto.VideoMeetingRoomDto> selectById(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.app.common.videomeeting.dto.VideoMeetingRoomDto> selectAuthedVideoMeetingRoomList();
```

### `StyleFileAppService`（1 方法）

`com.seeyon.app.common.style.api.StyleFileAppService`

```java
    com.seeyon.boot.transport.SingleResponse<com.seeyon.app.common.style.dto.StyleFileDto> getCurrentTenantPortalFile();
```

### `WaterMarkCommonAppService`（1 方法）

`com.seeyon.app.common.watermark.api.WaterMarkCommonAppService`

```java
    com.seeyon.boot.transport.SingleResponse<com.seeyon.app.common.watermark.dto.WaterMarkConfigDto> getWaterMarkConfig(com.seeyon.boot.transport.SingleRequest<java.util.Map<java.lang.String, java.lang.Object>>);
```

## 二、关键类（4）

### `I18nConfigDto`（32 方法）

`com.seeyon.app.common.system.dto.I18nConfigDto`

```java
    java.lang.String getLocale();
    java.lang.String getDateFormat();
    java.lang.String getTimeFormat();
    java.lang.String getFirstDayInWeek();
    java.lang.String getNumberDecimalDigits();
    java.lang.String getNumberNegativePattern();
    java.lang.String getNumberGroupEnable();
    java.lang.String getNumberGroupSeparator();
    java.lang.String getNumberDecimalSeparator();
    java.lang.String getCurrencySymbol();
    java.lang.String getCurrencyDecimalDigits();
    java.lang.String getCurrencyPositivePattern();
    java.lang.String getCurrencyNegativePattern();
    java.lang.String getCurrencyGroupEnable();
    java.lang.String getCurrencyGroupSeparator();
    java.lang.String getCurrencyDecimalSeparator();
    void setLocale(java.lang.String);
    void setDateFormat(java.lang.String);
    void setTimeFormat(java.lang.String);
    void setFirstDayInWeek(java.lang.String);
    void setNumberDecimalDigits(java.lang.String);
    void setNumberNegativePattern(java.lang.String);
    void setNumberGroupEnable(java.lang.String);
    void setNumberGroupSeparator(java.lang.String);
    void setNumberDecimalSeparator(java.lang.String);
    void setCurrencySymbol(java.lang.String);
    void setCurrencyDecimalDigits(java.lang.String);
    void setCurrencyPositivePattern(java.lang.String);
    void setCurrencyNegativePattern(java.lang.String);
    void setCurrencyGroupEnable(java.lang.String);
    void setCurrencyGroupSeparator(java.lang.String);
    void setCurrencyDecimalSeparator(java.lang.String);
```

### `AttachmentConfigDto`（30 方法）

`com.seeyon.app.common.system.dto.AttachmentConfigDto`

```java
    java.lang.Integer getMaxSize();
    java.lang.Integer getMaxNumber();
    java.lang.Integer getImageMaxSize();
    java.lang.Boolean getTrackRevisions();
    java.lang.Boolean getShowTraceBtn();
    java.lang.String getAttachOpenType();
    java.lang.String getAttachFormatSetting();
    java.lang.String getAttachSelectSupportFormat();
    java.lang.String getAttachSelectLimitFormat();
    java.lang.String getAttachSupportFormat();
    java.lang.String getAttachLimitFormat();
    java.lang.String getMobileAttachPerviewScaling();
    java.lang.Boolean getMobileGlobalPriority();
    java.lang.String getMobileAttachSupport();
    java.lang.Boolean getWebQrUpload();
    void setMaxSize(java.lang.Integer);
    void setMaxNumber(java.lang.Integer);
    void setImageMaxSize(java.lang.Integer);
    void setTrackRevisions(java.lang.Boolean);
    void setShowTraceBtn(java.lang.Boolean);
    void setAttachOpenType(java.lang.String);
    void setAttachFormatSetting(java.lang.String);
    void setAttachSelectSupportFormat(java.lang.String);
    void setAttachSelectLimitFormat(java.lang.String);
    void setAttachSupportFormat(java.lang.String);
    void setAttachLimitFormat(java.lang.String);
    void setMobileAttachPerviewScaling(java.lang.String);
    void setMobileGlobalPriority(java.lang.Boolean);
    void setMobileAttachSupport(java.lang.String);
    void setWebQrUpload(java.lang.Boolean);
```

### `WaterMarkConfigDto`（12 方法）

`com.seeyon.app.common.watermark.dto.WaterMarkConfigDto`

```java
    java.lang.String getEnabled();
    java.lang.String getScope();
    java.lang.String getContent();
    java.lang.String getFont();
    java.lang.String getAngle();
    java.util.List<java.lang.String> getApps();
    void setEnabled(java.lang.String);
    void setScope(java.lang.String);
    void setContent(java.lang.String);
    void setFont(java.lang.String);
    void setAngle(java.lang.String);
    void setApps(java.util.List<java.lang.String>);
```

### `SystemConfigDto`（8 方法）

`com.seeyon.app.common.system.dto.SystemConfigDto`

```java
    com.seeyon.app.common.system.dto.I18nConfigDto getI18nConfigDto();
    com.seeyon.app.common.watermark.dto.WaterMarkConfigDto getWaterMarkConfigDto();
    com.seeyon.app.common.system.dto.AttachmentConfigDto getAttachmentConfigDto();
    com.seeyon.app.common.system.dto.IdentityConfigDto getIdentityConfigDto();
    void setI18nConfigDto(com.seeyon.app.common.system.dto.I18nConfigDto);
    void setWaterMarkConfigDto(com.seeyon.app.common.watermark.dto.WaterMarkConfigDto);
    void setAttachmentConfigDto(com.seeyon.app.common.system.dto.AttachmentConfigDto);
    void setIdentityConfigDto(com.seeyon.app.common.system.dto.IdentityConfigDto);
```

## 四、枚举（19）

- `AgentContentEnum`（2 常量）：ALL_TEMPLATE, ASSIGN_TEMPLATE
- `AgentDetailTypeEnum`（3 常量）：PROCESS_TEMPLATE, PROCESS_CATEGORIES, NON_PROCESS_CATEGORIES
- `AgentIsShowEnum`（7 常量）：NONE, ORIGINAL_TO_SENDEE, SENDEE, SENDEE_TO_ORIGINAL, ITEM_OWNER, INVESTOR, DONOR
- `AgentMatterTypeEnum`（4 常量）：PROCESSOR, SPONSOR, CUSTOMSET, NODE
- `AgentOperationEnum`（3 常量）：GROUP_MANAGER, UNIT_MANAGER, ONESELF
- `AgentOperationTypeEnum`（5 常量）：CREATE, UPDATE, CANCEL, EFFICACY, START
- `AgentScopeTypeEnum`（6 常量）：DEPARTMENT, MEMBER, INSTITUTION, NODE, INSTITUTION_SUB, TEAM
- `AgentSignatureAreaEnum`（3 常量）：NONE, OPINION_AREA, ALL_AREA
- `AgentSuffixTypeEnum`（2 常量）：NONE, AGENT_NAME_SGIN
- `AgentTypeEnum`（6 常量）：NORMAL, HANDOVER, HANDOVER_SEPARATELY, BIZ_AGENT, SUBLICENSE, HANDOVER_ALREADY
- `AttentionTypeEnum`（2 常量）：ATTENTION, FAVORITE
- `CategoryOperationTypeEnum`（3 常量）：CREATE, UPDATE, DELETE
- `OperationTypeEnum`（17 常量）：LOGIN, PUBLISH, PUBLISHAPPROVED, REFERENCED, READ, LIKE, COMMENT, SHARE, FEATURED, PINNEDTOP, PUBLISHANSWER, LIKEANSWER …
- `CodeTypeEnum`（2 常量）：QRCODE, BARCODE
- `SealTypeEnum`（2 常量）：SIGN, SEAL
- `FestivalTypeEnum`（9 常量）：NEW_YEARS_DAY, NEW_YEARS_EVE, SPRING_FESTIVAL, CHING_MING_FESTIVAL, MAY_DAY, DRAGON_BOAT_FESTIVAL, MOON_FESTIVAL, NATIONAL_DAY, CUSTOM
- `MonthUnitEnum`（3 常量）：MONTH, SEASON, YEAR
- `TimeUnitEnum`（3 常量）：MINUTE, HOUR, DAY
- `WorkDayTypeEnum`（4 常量）：WORK, WEEKEND, HOLIDAY, UNDEFIND
