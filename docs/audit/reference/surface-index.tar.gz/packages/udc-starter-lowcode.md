# udc-starter-lowcode：接口与方法签名

> 自动生成，勿手改。`tools/core/platform/emit_package_surfaces.py` 重跑即可。
> 构件 `com.seeyon:udc-starter-lowcode`（jar `udc-starter-lowcode-5.3.605.jar`）
> 规模：121 类 / 28 接口 / 9 注解 / 3 枚举 / 30 个关键类 / 1089 方法。
> 签名逐字来自 javap 原文；已去掉 `public` 前缀与 `throws` 子句。

## 一、接口（28）

### `BaseCurdService`（35 方法）

`com.seeyon.boot.starter.lowcode.core.BaseCurdService`

```java
    default java.util.List<D> selectListByCondition(java.lang.String, java.lang.Object, com.seeyon.boot.transport.Sort);
    default boolean selectExceedsOneThousandRecordsByInCondition(java.lang.String, java.lang.Object);
    default java.util.List<D> selectByParentId(java.lang.Long);
    default java.util.List<D> selectByParentIdIgnoreSort(java.lang.Long);
    default java.util.List<D> selectByParentIds(java.util.Collection<java.lang.Long>);
    default java.util.List<D> selectByParentIdsIgnoreSort(java.util.Collection<java.lang.Long>);
    default int selectCountByWrapper(com.seeyon.boot.domain.dao.Wrapper);
    default int selectCountByConditions(java.util.Map<java.lang.String, java.lang.Object>);
    default java.util.List<D> selectListByWrapper(com.seeyon.boot.domain.dao.Wrapper);
    default java.util.List<D> selectListByConditions(java.util.Map<java.lang.String, java.lang.Object>, com.seeyon.boot.transport.Sort);
    default com.seeyon.boot.transport.PageData<D> selectPageByWrapper(com.seeyon.boot.transport.PageInfo, com.seeyon.boot.domain.dao.Wrapper);
    default com.seeyon.boot.transport.PageData<D> selectPageByConditions(com.seeyon.boot.transport.PageInfo, java.util.Map<java.lang.String, java.lang.Object>, com.seeyon.boot.transport.Sort);
    default java.util.List<D> selectListByComplexConditions(java.util.Map<java.lang.String, java.lang.Object>, com.seeyon.boot.transport.Sort);
    default com.seeyon.boot.transport.PageData<D> selectPageByComplexConditions(com.seeyon.boot.transport.PageInfo, java.util.Map<java.lang.String, java.lang.Object>, com.seeyon.boot.transport.Sort);
    default int selectCountByComplexConditions(java.util.Map<java.lang.String, java.lang.Object>);
    default java.lang.String selectListFuncByComplexConditions(java.util.Map<java.lang.String, java.lang.Object>, com.seeyon.boot.transport.Sort, java.lang.String, java.util.List<java.lang.String>);
    default java.lang.String selectFuncByConditions(java.util.Map<java.lang.String, java.lang.Object>, com.seeyon.boot.transport.Sort, java.lang.String, java.util.List<java.lang.String>);
    default java.util.List<D> selectListByDynamicConditions(java.util.Map<java.lang.String, java.lang.Object>, com.seeyon.boot.transport.Sort);
    default java.util.List<D> selectListByDynamicConditions(java.util.List<com.seeyon.boot.starter.mybatis.util.SeeyonKeyMap>, com.seeyon.boot.transport.Sort);
    default void afterBeforeEventCheck(java.util.List<D>);
```

### `EntityRuntimeLogCallBack`（28 方法） extends BaseEntityActionDto>

`com.seeyon.boot.starter.lowcode.callback.EntityRuntimeLogCallBack`

```java
    default void beginCreateLog(java.util.List<D>);
    default void resetInsertAndOrderNoLog(java.util.List<D>);
    default void beginPreCreateBatchLog(java.util.List<D>);
    default void endePreCreateBatchLog(java.util.List<D>);
    default void beforeCreateLog(java.util.List<D>);
    default void beginBeforeEventLog(java.util.List<D>, java.lang.String);
    default void endBeforeEventLog(java.util.List<D>, java.lang.String);
    default void middleCreateLog(java.util.List<D>);
    default void endCreateLog(java.util.List<D>);
    default void beginUpdateLog(java.util.List<D>);
    default void beginBeforeUpdateLog(java.util.List<D>);
    default void endBeforeUpdateLog(java.util.List<D>);
    default void listToMapLog(java.util.List<D>);
    default void mergeMapDataLog(java.util.List<D>);
    default void beginPermissionBuildInitialValueLog(D, java.lang.String);
    default void endPermissionBuildInitialValueLog(D, java.lang.String);
    default void beginPreUpdateBatchLog(java.util.List<D>);
    default void endPreUpdateBatchLog(java.util.List<D>);
    default void endUpdateLog(java.util.List<D>);
    default void beginUpdate4BpmLog(D);
    default void beginAfterApprovalUpdateLog(D);
    default void endAfterApprovalUpdateLog(D);
    default void endUpdate4BpmLog(D);
    default void beginCreate4BpmLog(D);
    default void beginAfterApprovalCreateLog(D);
    default void endAfterApprovalCreateLog(D);
    default void endCreate4BpmLog(D);
    default void entityDeleteLog(java.util.List<D>);
```

### `UpdateService`（15 方法） extends BaseService<D>

`com.seeyon.boot.starter.lowcode.core.UpdateService`

```java
    default int create(D);
    default int createBatch(java.util.List<D>);
    default int update(D);
    default int updateWithFields(java.util.Map<java.lang.String, java.lang.Object>);
    default int updateNoEvents(D);
    default int updateBatch(java.util.List<D>);
    default int deleteById(java.lang.Long);
    default int deleteByIds(java.util.Collection<java.lang.Long>);
```

### `MethodCallBack`（10 方法）

`com.seeyon.boot.starter.lowcode.callback.MethodCallBack`

```java
    default void beforeSelect(java.util.List<D>);
    default void afterSelect(java.util.List<D>);
    default void beforeCreate(java.util.List<D>);
    default void middleCreate(java.util.List<D>);
    default void afterCreate(java.util.List<D>);
    default void beforeUpdate(java.util.List<D>);
    default void afterUpdate(java.util.List<D>, java.util.Map<java.lang.Long, D>);
    default void beforeDelete(java.util.List<D>);
    default void afterDelete(java.util.List<D>);
    default D getDefaultValue();
```

### `AppInfoService`（10 方法）

`com.seeyon.boot.starter.lowcode.context.AppInfoService`

```java
    java.lang.String getAppName();
    java.lang.String getHostAppName();
    java.lang.String getAppVersion();
    java.lang.String getCaption();
    java.lang.String getSourceType();
    java.lang.String getDynamicModuleGroup();
    java.lang.String getDynamicFeatureType();
    java.lang.String getCopVersion();
    java.lang.String getBuildTime();
    java.lang.String getUdcVersion();
```

### `AppStartUpProcessor`（7 方法） extends Ordered

`com.seeyon.boot.starter.lowcode.processor.AppStartUpProcessor`

```java
    default int getOrder();
    default void onStartLoad(com.seeyon.udc.common.dto.AppInfoDto);
    default void onCompleteMetadataRegister(com.seeyon.udc.common.dto.AppInfoDto);
    default void onCompleteDdlInit(com.seeyon.udc.common.dto.AppInfoDto);
    default void onCompleteTenantInit(com.seeyon.udc.common.dto.AppInfoDto);
    default void onCompleteLoad(com.seeyon.udc.common.dto.AppInfoDto);
    default void onUnLoad(com.seeyon.udc.common.dto.AppInfoDto);
```

### `ApprovalCallBack`（6 方法）

`com.seeyon.boot.starter.lowcode.callback.ApprovalCallBack`

```java
    default void beforeApprovalCreate(com.seeyon.boot.starter.lowcode.dto.ApprovalContext);
    default void afterApprovalCreate(com.seeyon.boot.starter.lowcode.dto.ApprovalContext);
    default void beforeApprovalUpdate(com.seeyon.boot.starter.lowcode.dto.ApprovalContext);
    default void afterApprovalUpdate(com.seeyon.boot.starter.lowcode.dto.ApprovalContext);
    default void beforeApprovalCreateValidate(com.seeyon.boot.starter.lowcode.dto.ApprovalContext);
    default void beforeApprovalUpdateValidate(com.seeyon.boot.starter.lowcode.dto.ApprovalContext);
```

### `ApprovalCallBackExt`（6 方法）

`com.seeyon.boot.starter.lowcode.callback.ApprovalCallBackExt`

```java
    default void beforeApprovalCreate(com.seeyon.boot.starter.lowcode.dto.ApprovalContext);
    default void afterApprovalCreate(com.seeyon.boot.starter.lowcode.dto.ApprovalContext);
    default void beforeApprovalUpdate(com.seeyon.boot.starter.lowcode.dto.ApprovalContext);
    default void afterApprovalUpdate(com.seeyon.boot.starter.lowcode.dto.ApprovalContext);
    default void beforeApprovalCreateValidate(com.seeyon.boot.starter.lowcode.dto.ApprovalContext);
    default void beforeApprovalUpdateValidate(com.seeyon.boot.starter.lowcode.dto.ApprovalContext);
```

### `QueryService`（6 方法） extends BaseService<D>

`com.seeyon.boot.starter.lowcode.core.QueryService`

```java
    default D selectById(java.lang.Long);
    default java.util.List<D> selectByIds(java.util.Collection<java.lang.Long>);
    default java.lang.Enum selectBillStatusById(java.lang.Long);
```

### `AttributeSnapshotAppService`（4 方法）

`com.seeyon.boot.starter.lowcode.api.AttributeSnapshotAppService`

```java
    java.util.List<com.seeyon.boot.starter.lowcode.dto.AttributeSnapshotDto> selectByDataId(java.lang.Long);
    java.util.List<com.seeyon.boot.starter.lowcode.dto.AttributeSnapshotDto> selectByDataIds(java.util.List<java.lang.Long>);
    java.util.List<com.seeyon.boot.starter.lowcode.dto.AttributeSnapshotDto> selectByMasterDataId(java.lang.Long);
    java.util.List<com.seeyon.boot.starter.lowcode.dto.AttributeSnapshotDto> selectByMasterDataIds(java.util.List<java.lang.Long>);
```

### `EntityAttrSnapshotCallBack`（4 方法）

`com.seeyon.boot.starter.lowcode.callback.EntityAttrSnapshotCallBack`

```java
    <T extends com.seeyon.udc.common.dto.BaseEntityActionDto> void saveSnapshot(java.util.List<T>, com.seeyon.boot.starter.lowcode.core.EntityMeta);
    <T extends com.seeyon.udc.common.dto.BaseEntityActionDto> void updateSnapshot(java.util.List<T>, java.util.Map<java.lang.Long, T>, java.util.Map<java.lang.Long, T>, com.seeyon.boot.starter.lowcode.core.EntityMeta);
    void deleteByDataMasterIds(java.util.List<java.lang.Long>);
    void deleteDataIds(java.util.List<java.lang.Long>);
```

### `UdcModuleBeanHandler`（3 方法）

`com.seeyon.boot.starter.lowcode.context.UdcModuleBeanHandler`

```java
    com.seeyon.udc.common.enums.ApplicationSourceEnum getAppType();
    <T> T getBeanObject(java.lang.String, java.lang.String);
    java.lang.Class getClass(java.lang.String, java.lang.String)
```

### `BaseService`（3 方法） extends BaseEntityActionDto>

`com.seeyon.boot.starter.lowcode.core.BaseService`

```java
    java.lang.Class<?> getEntityClass();
    default java.lang.Class<?> getDtoClass();
    default <DAO extends com.seeyon.boot.domain.dao.BaseDao> DAO getMapper();
```

### `EventHelper`（3 方法）

`com.seeyon.boot.starter.lowcode.helper.EventHelper`

```java
    void beforeEvent(com.seeyon.boot.starter.lowcode.helper.EventContainer);
    void afterEvent(com.seeyon.boot.starter.lowcode.helper.EventContainer);
    void transactionSuccessEvent(com.seeyon.boot.starter.lowcode.helper.EventContainer);
```

### `DataVisitor`（3 方法） extends Ordered

`com.seeyon.boot.starter.lowcode.visitor.DataVisitor`

```java
    boolean match(com.seeyon.boot.starter.lowcode.context.OperateContext);
    void visit(com.seeyon.boot.starter.lowcode.context.OperateContext);
    default java.lang.String getSimpleName();
```

### `PermissionCallBack`（2 方法）

`com.seeyon.boot.starter.lowcode.callback.PermissionCallBack`

```java
    default <T extends com.seeyon.udc.common.dto.BaseEntityActionDto> T buildInitialValue(com.seeyon.boot.starter.lowcode.core.EntityMeta, T, T);
    default <T extends com.seeyon.udc.common.dto.BaseEntityActionDto> void requiredValidate(com.seeyon.boot.starter.lowcode.core.EntityMeta, T, T);
```

### `DataProcessor`（2 方法）

`com.seeyon.boot.starter.lowcode.processor.DataProcessor`

```java
    void dataProcess(com.seeyon.boot.starter.lowcode.context.OperateContext);
    void flowProcess(com.seeyon.boot.starter.lowcode.context.OperateContext);
```

### `DataTransferAppService`（1 方法）

`com.seeyon.boot.starter.lowcode.api.DataTransferAppService`

```java
    default com.seeyon.boot.transport.SingleResponse<com.seeyon.udc.common.transfer.DataTransferResponse> dataTransfer(com.seeyon.boot.transport.SingleRequest<com.seeyon.udc.common.transfer.DataTransferRequest>);
```

### `BillStateCallBack`（1 方法）

`com.seeyon.boot.starter.lowcode.callback.BillStateCallBack`

```java
    default <T extends com.seeyon.udc.common.dto.BaseEntityActionDto> T checkBillState(T, T);
```

### `EntityDataDiffCallBack`（1 方法）

`com.seeyon.boot.starter.lowcode.callback.EntityDataDiffCallBack`

```java
    <T extends com.seeyon.udc.common.dto.BaseEntityActionDto> java.util.List<com.seeyon.boot.starter.lowcode.dto.BaseCrudDiffDto> diffData(java.util.List<T>, java.util.Map<java.lang.Long, T>, java.util.Map<java.lang.Long, T>, com.seeyon.boot.starter.lowcode.core.EntityMeta);
```

### `PreCopyCallBack`（1 方法）

`com.seeyon.boot.starter.lowcode.callback.PreCopyCallBack`

```java
    default void preCopyBatch(java.util.List<D>);
```

### `PreCreateCallBack`（1 方法）

`com.seeyon.boot.starter.lowcode.callback.PreCreateCallBack`

```java
    default void preCreateBatch(java.util.List<D>);
```

### `PreUpdateCallBack`（1 方法）

`com.seeyon.boot.starter.lowcode.callback.PreUpdateCallBack`

```java
    default void preUpdateBatch(java.util.List<D>);
```

### `SecretCallBack`（1 方法）

`com.seeyon.boot.starter.lowcode.callback.SecretCallBack`

```java
    <D extends com.seeyon.udc.common.dto.BaseEntityActionDto> void checkSecret(java.util.Collection<D>);
```

### `ValidateCallBack`（1 方法） extends BaseDto>

`com.seeyon.boot.starter.lowcode.callback.ValidateCallBack`

```java
    default void assertjsr303(D);
```

### `EntityLogFilter`（1 方法）

`com.seeyon.boot.starter.lowcode.config.EntityLogFilter`

```java
    boolean ignoreLog(java.lang.String);
```

### `DataTransferService`（1 方法） extends BaseService<D>

`com.seeyon.boot.starter.lowcode.core.DataTransferService`

```java
    java.util.List<com.seeyon.boot.starter.excel.dto.biz.ExcelImportResultDto> importEntityInitData(com.seeyon.boot.starter.excel.dto.biz.ExcelImportTransDto);
```

### `OperateListener`（1 方法）

`com.seeyon.boot.starter.lowcode.listener.OperateListener`

```java
    void onOperate(com.seeyon.boot.starter.lowcode.context.OperateContext);
```

## 二、关键类（30）

### `BaseEntityCurdService`（199 方法）

`com.seeyon.boot.starter.lowcode.service.BaseEntityCurdService`

```java
    static private static <D extends com.seeyon.udc.common.dto.BaseEntityActionDto> void handlerCaseId(D);
    void afterPropertiesSet()
    void asyncInit();
    java.lang.Class<D> getDtoClass();
    <DAO extends com.seeyon.boot.domain.dao.BaseDao> DAO getMapper();
    private void resetNormal(java.util.List<D>);
    int operateRootBatch(java.util.List<D>);
    int create(D);
    int createBatch(java.util.List<D>);
    private int recursiveCreate(com.seeyon.boot.starter.lowcode.core.EntityMeta, java.util.List<D>);
    java.lang.Long copyAndInsert(java.lang.Long);
    D runtimeCopy(java.lang.Long);
    D updateWithResult(D);
    D createWithResult(D);
    int update(D);
    int updateNoEvents(D);
    int updateWithFields(java.util.Map<java.lang.String, java.lang.Object>);
    private java.lang.Object getChildDtoFromMap(java.util.Map<java.lang.String, java.lang.Object>, com.seeyon.boot.starter.lowcode.core.EntityMeta);
    private void checkChildEntityData(java.util.Map<java.lang.String, java.lang.Object>);
    private int updateBase(D, boolean, boolean);
    protected com.seeyon.boot.starter.lowcode.service.BaseEntityCurdService<D> getBaseEntityCurdService();
    private int deleteData(com.seeyon.boot.starter.lowcode.core.EntityMeta, java.util.Map<java.lang.Long, D>);
    private int deleteData(com.seeyon.boot.starter.lowcode.core.EntityMeta, java.util.Map<java.lang.Long, D>, boolean);
    private int recursiveUpdate(com.seeyon.boot.starter.lowcode.core.EntityMeta, java.util.List<D>, java.util.Map<java.lang.Long, D>);
    private int recursiveUpdate(com.seeyon.boot.starter.lowcode.core.EntityMeta, java.util.List<D>, java.util.Map<java.lang.Long, D>, boolean);
    private void recursiveCheck(com.seeyon.boot.starter.lowcode.core.EntityMeta, java.util.List<D>, java.util.Map<java.lang.Long, D>);
    private void recursiveCheck(com.seeyon.boot.starter.lowcode.core.EntityMeta, java.util.List<D>, java.util.Map<java.lang.Long, D>, java.lang.StringBuilder);
    private java.lang.String checkSystemAttribute(D, java.util.List<D>, java.util.List<D>, java.util.Map<java.lang.Long, D>);
    private void handleSelfUpdate(java.util.concurrent.atomic.AtomicInteger, com.seeyon.boot.starter.lowcode.core.EntityMeta, java.util.List<D>, java.util.Map<java.lang.Long, D>, boolean);
    int updateRootEntity(D);
    int updateRootEntity(D, D);
    int updateStatusType(D);
    java.util.List<D> updateBatchWithResult(java.util.List<D>);
    int updateBatch(java.util.List<D>);
    D selectCascadeById(java.lang.Long);
    D doSelectCascadeById(java.lang.Long);
    D doParallelSelectCascadeById(java.lang.Long);
    private void setSingeSubDtoList(java.lang.Long, D, com.seeyon.boot.starter.lowcode.core.EntityMeta, java.util.function.Supplier<java.util.Map<java.lang.String, com.seeyon.boot.starter.lowcode.dto.MapConditionDto>>);
    private void setMultiSubDtoList(java.util.Collection<java.lang.Long>, java.util.List<D>, com.seeyon.boot.starter.lowcode.core.EntityMeta, java.util.function.Supplier<java.util.Map<java.lang.String, com.seeyon.boot.starter.lowcode.dto.MapConditionDto>>);
    private void handleSubRelation(java.util.List<com.seeyon.udc.common.dto.BaseEntityActionDto>, com.seeyon.boot.starter.lowcode.core.EntityMeta, java.util.function.Supplier);
    void recursiveSelect(java.util.Collection<java.lang.Long>, java.util.List<D>);
    void recursiveSelectWithCondition(java.util.Collection<java.lang.Long>, java.util.List<D>, java.util.Map<java.lang.String, com.seeyon.boot.starter.lowcode.dto.MapConditionDto>);
    java.util.List<D> selectCascadeByIds(java.util.Collection<java.lang.Long>);
    java.util.List<D> selectCascadeListByWrapper(com.seeyon.boot.domain.dao.Wrapper);
    java.util.List<D> selectCascadeListByWrapper(com.seeyon.boot.domain.dao.Wrapper, java.util.List<com.seeyon.boot.starter.lowcode.dto.MapConditionDto>);
    java.util.List<D> selectCascadeListByConditions(java.util.List<com.seeyon.boot.starter.lowcode.dto.MapConditionDto>);
    int deleteById(java.lang.Long);
    int deleteByIds(java.util.Collection<java.lang.Long>);
    private int recursiveDelete(com.seeyon.boot.starter.lowcode.core.EntityMeta, java.util.Map<java.lang.Long, D>);
    int deleteByComplexConditions(java.util.Map<java.lang.String, java.lang.Object>);
    java.util.Map<java.lang.Long, D> listToMap(java.util.List<D>);
    private java.util.List<D> validateCreate(java.util.List<D>);
    private java.util.List<D> validateUpdate(java.util.List<D>);
    D validate(D);
    D getCascadeDefaultValue();
    D getCascadeDefaultValue(java.lang.String);
    private void recursiveDefaultValue(com.seeyon.boot.starter.lowcode.core.EntityMeta, D);
    java.util.List<com.seeyon.boot.starter.excel.dto.biz.ExcelImportResultDto> importEntityInitData(com.seeyon.boot.starter.excel.dto.biz.ExcelImportTransDto);
    private java.util.Map<java.lang.String, java.lang.String> buildInitDataMap(com.seeyon.boot.starter.lowcode.core.EntityMeta, java.util.Collection<? extends com.seeyon.udc.common.dto.BaseEntityActionDto>);
    private void uniqueFieldCheck(com.seeyon.boot.starter.lowcode.core.EntityMeta, com.seeyon.udc.common.dto.BaseEntityActionDto, java.util.List<D>, java.util.Map<java.lang.String, java.util.List<java.lang.String>>, java.util.HashMap<java.lang.Integer, com.seeyon.boot.starter.excel.dto.biz.ExcelImportResultDto>);
    com.seeyon.boot.transport.PageData<D> dynamicJoinSelect(com.seeyon.boot.starter.dynamicsql.dto.ProxyJoinParamDto);
    java.lang.Integer dynamicCountJoinSelect(com.seeyon.boot.starter.dynamicsql.dto.ProxyJoinParamDto);
    <D> com.seeyon.boot.transport.PageResponse<D> dynamicSelect(com.seeyon.boot.starter.dynamicsql.dto.ProxyParamDto);
    protected void sendMessage(java.io.Serializable);
    com.seeyon.udc.common.dto.ResultDto create4Bpm(D);
    D create4BpmInternal(D, com.seeyon.boot.starter.lowcode.dto.ApprovalContext);
    private boolean isMainProcess(com.seeyon.boot.starter.lowcode.dto.ApprovalContext);
    com.seeyon.udc.common.dto.ResultDto update4Bpm(D);
    D selectCustomCascadeByCondition(com.seeyon.boot.starter.dynamicsql.dto.QueryConditionDto);
    java.util.List<D> selectCustomCascadeListByCondition(com.seeyon.boot.starter.dynamicsql.dto.QueryConditionDto);
    void recursiveSelectOne2OneCascadeByCondition(com.seeyon.boot.starter.lowcode.core.EntityMeta, java.util.List<java.lang.Long>, java.util.List<D>, java.util.Map<java.lang.String, com.seeyon.boot.starter.dynamicsql.dto.QueryConditionDto>);
    D selectOne2OneCascadeByDyCondition(com.seeyon.boot.starter.dynamicsql.dto.QueryConditionDto);
    java.util.List<D> selectOne2OneCascadeListByDyCondition(com.seeyon.boot.starter.dynamicsql.dto.QueryConditionDto);
    D processingTemplateData(D);
    D processingForwardData(D);
    private D recursiveEntityRuntimeData(com.seeyon.boot.starter.lowcode.core.EntityMeta, D, com.seeyon.boot.starter.lowcode.enums.RecursiveType);
    com.seeyon.udc.common.dto.ForceUpdateResultDto forceUpdate(D);
    private java.util.Set<java.lang.String> getUpdateRootFiled(java.lang.Object);
    private void setJdbcDriverIfNecessary(com.seeyon.boot.starter.dynamicsql.dto.ProxyJoinParamDto);
    private void printTransactionInfo();
    java.lang.Class<?> getEntityClass();
    com.seeyon.boot.starter.lowcode.core.EntityMeta getEntityMeta();
    static private static java.lang.Object $deserializeLambda$(java.lang.invoke.SerializedLambda);
```

### `DtoConvertUtil`（58 方法）

`com.seeyon.boot.starter.lowcode.util.DtoConvertUtil`

```java
    static <DTO extends com.seeyon.udc.common.dto.BaseEntityActionDto, T> DTO setValueHandle(com.seeyon.boot.starter.lowcode.core.EntityMeta, DTO, java.util.function.Supplier<T>, java.util.function.BiConsumer<DTO, T>);
    static <DTO extends com.seeyon.udc.common.dto.BaseEntityActionDto> DTO resetInsertHandle(com.seeyon.boot.starter.lowcode.core.EntityMeta, DTO, java.util.function.BiConsumer<DTO, DTO>);
    static <DTO extends com.seeyon.udc.common.dto.BaseEntityActionDto> DTO forEach(com.seeyon.boot.starter.lowcode.core.EntityMeta, DTO, java.util.function.Consumer<DTO>);
    static <DTO extends com.seeyon.udc.common.dto.BaseEntityActionDto> void forEach(com.seeyon.boot.starter.lowcode.core.EntityMeta, java.util.List<DTO>, java.util.function.BiConsumer<com.seeyon.boot.starter.lowcode.core.EntityMeta, java.util.List<DTO>>);
    static <DTO extends com.seeyon.udc.common.dto.BaseEntityActionDto> java.util.Map<java.lang.Long, DTO> defaultUpdateListToMap(com.seeyon.boot.starter.lowcode.core.EntityMeta, java.util.List<DTO>);
    static <DTO extends com.seeyon.udc.common.dto.BaseEntityActionDto> java.util.Map<java.lang.Long, DTO> listToMap(com.seeyon.boot.starter.lowcode.core.EntityMeta, java.util.List<DTO>);
    static <DTO extends com.seeyon.udc.common.dto.BaseEntityActionDto> java.util.Map<java.lang.Long, DTO> listToMap(com.seeyon.boot.starter.lowcode.core.EntityMeta, java.util.List<DTO>, java.util.function.Predicate<DTO>);
    static <DTO extends com.seeyon.udc.common.dto.BaseEntityActionDto> java.util.Map<java.lang.Long, DTO> listToMap(com.seeyon.boot.starter.lowcode.core.EntityMeta, java.util.List<DTO>, java.util.function.Consumer<DTO>);
    static <DTO extends com.seeyon.udc.common.dto.BaseEntityActionDto> java.util.Map<java.lang.Long, DTO> listToMap(com.seeyon.boot.starter.lowcode.core.EntityMeta, java.util.List<DTO>, java.util.function.Consumer<DTO>, java.util.function.Predicate<DTO>);
    static <DTO extends com.seeyon.udc.common.dto.BaseEntityActionDto> java.util.Map<java.lang.Long, DTO> listToMap(com.seeyon.boot.starter.lowcode.core.EntityMeta, java.util.List<DTO>, java.util.function.Consumer<DTO>, java.util.function.BiConsumer<DTO, java.util.List<DTO>>, java.util.function.Predicate<DTO>);
    static <DTO extends com.seeyon.udc.common.dto.BaseEntityActionDto> java.util.List<DTO> mergeMapData(com.seeyon.boot.starter.lowcode.core.EntityMeta, java.util.Map<java.lang.Long, DTO>, java.util.Map<java.lang.Long, DTO>);
    static private static <DTO extends com.seeyon.udc.common.dto.BaseEntityActionDto> java.util.Set<java.lang.String> checkNullFieldsAndCollectNullFieldsNames(DTO);
    static private static <DTO extends com.seeyon.udc.common.dto.BaseEntityActionDto> void checkFieldEnableNullValue(DTO, java.lang.String);
    static <DTO extends com.seeyon.udc.common.dto.BaseEntityActionDto> java.util.List<DTO> forEachMergedChildDto(com.seeyon.boot.starter.lowcode.core.EntityMeta, java.util.List<DTO>, java.util.Map<java.lang.Long, DTO>, java.util.function.Predicate<DTO>);
    static <DTO extends com.seeyon.udc.common.dto.BaseEntityActionDto> java.util.List<DTO> forEachMergedChildDto(com.seeyon.boot.starter.lowcode.core.EntityMeta, java.util.List<DTO>, java.util.Map<java.lang.Long, DTO>);
    static <DTO extends com.seeyon.udc.common.dto.BaseEntityActionDto> java.util.List<DTO> forEachMergedChildDto(com.seeyon.boot.starter.lowcode.core.EntityMeta, java.util.List<DTO>, java.util.Map<java.lang.Long, DTO>, java.util.function.Consumer<DTO>, java.util.function.Predicate<DTO>);
    static <DTO extends com.seeyon.udc.common.dto.BaseEntityActionDto> void fillDeletedData(com.seeyon.boot.starter.lowcode.core.EntityMeta, java.util.List<DTO>, java.util.Map<java.lang.Long, DTO>);
    static <DTO extends com.seeyon.udc.common.dto.BaseEntityActionDto> java.util.Map<com.seeyon.boot.enums.ActionType, java.util.List<DTO>> groupByAction(java.util.List<DTO>);
    static <DTO extends com.seeyon.udc.common.dto.BaseEntityActionDto> void copyValueIfTargetFieldIsNull(DTO, DTO, java.util.List<java.lang.String>, java.util.List<java.lang.String>);
    static <DTO extends com.seeyon.udc.common.dto.BaseEntityActionDto> void forEach(com.seeyon.boot.starter.lowcode.core.EntityMeta, java.util.Collection<DTO>, java.util.Collection<DTO>, java.util.function.BiConsumer<com.seeyon.boot.starter.lowcode.core.EntityMeta, cn.hutool.core.lang.Pair<java.util.Collection<DTO>, java.util.Collection<DTO>>>);
    static private static <DTO extends com.seeyon.udc.common.dto.BaseEntityActionDto> java.util.List<DTO> getChildDtoList(DTO, com.seeyon.boot.starter.lowcode.core.EntityMeta);
    static private static <DTO extends com.seeyon.udc.common.dto.BaseEntityActionDto> boolean fixActionTypeByDFS(com.seeyon.boot.starter.lowcode.core.EntityMeta, java.util.Collection<DTO>);
    static private static <DTO extends com.seeyon.udc.common.dto.BaseEntityActionDto> boolean checkUpdateActionType(DTO);
```

### `DtoFieldHelper`（39 方法）

`com.seeyon.boot.starter.lowcode.helper.DtoFieldHelper`

```java
    static final <D extends com.seeyon.udc.common.dto.BaseEntityActionDto> D throwActionTypeIfAbsent(D);
    static final <D extends com.seeyon.udc.common.dto.BaseEntityActionDto> D setIdIfAbsent(D);
    static final <D extends com.seeyon.udc.common.dto.BaseEntityActionDto> java.util.List<D> setParentIdIfAbsent(D, java.util.List<D>);
    static final <D extends com.seeyon.udc.common.dto.BaseEntityActionDto> D setActionTypeIfAbsent(D, com.seeyon.boot.enums.ActionType);
    static final <D extends com.seeyon.udc.common.dto.BaseEntityActionDto> D setActionType(D, com.seeyon.boot.enums.ActionType);
    static final <D extends com.seeyon.udc.common.dto.BaseEntityActionDto> D resetInsert(D, D);
    static final <D extends com.seeyon.udc.common.dto.BaseEntityActionDto> D resetChildNormal(D);
    static final <D extends com.seeyon.udc.common.dto.BaseEntityActionDto> D resetId(D, D);
    static final <D extends com.seeyon.udc.common.dto.BaseEntityActionDto> void set1ToNDtoList(D, com.seeyon.boot.starter.lowcode.core.EntityMeta, java.util.List<D>);
    static <D extends com.seeyon.udc.common.dto.BaseEntityActionDto> void setSubEntityOrderNo(com.seeyon.boot.starter.lowcode.core.EntityMeta, java.util.List<D>);
    static <D extends com.seeyon.udc.common.dto.BaseEntityActionDto> java.util.List<com.seeyon.boot.starter.lowcode.dto.AggEntityChangeDto> diffDataByList(com.seeyon.boot.starter.lowcode.core.EntityMeta, java.util.List<D>, java.util.List<D>);
    static <D extends com.seeyon.udc.common.dto.BaseEntityActionDto> java.util.List<com.seeyon.boot.starter.lowcode.dto.EntityChangeDto> diffDataByMap(com.seeyon.boot.starter.lowcode.core.EntityMeta, java.util.Map<java.lang.Long, D>, java.util.Map<java.lang.Long, D>);
    static private static <D extends com.seeyon.udc.common.dto.BaseEntityActionDto> java.util.List<com.seeyon.boot.starter.lowcode.dto.AttributeChangeDto> extractAttrChange(com.seeyon.boot.starter.lowcode.core.EntityMeta, D, D);
    static private static boolean isContentField(com.seeyon.boot.starter.lowcode.core.AttributeMeta);
    static private static <D extends com.seeyon.udc.common.dto.BaseEntityActionDto> java.util.List<com.seeyon.boot.starter.lowcode.dto.AttributeChangeDto> extractAttrChange(com.seeyon.boot.starter.lowcode.core.EntityMeta, D, D, java.util.Set<java.lang.String>);
    static private static boolean isEmptyOrZero(java.lang.Object);
    static private static boolean isEmpty(java.lang.Object);
    static private static java.util.List<java.lang.String> listEnableExtField(com.seeyon.boot.starter.lowcode.core.EntityMeta);
```

### `EntityRelationHandler`（34 方法）

`com.seeyon.boot.starter.lowcode.core.EntityRelationHandler`

```java
    static private static org.apache.commons.lang3.tuple.MutablePair<java.util.Set<java.lang.Class<?>>, java.util.Set<java.lang.Class<?>>> getClassSet(java.lang.ClassLoader, java.lang.String);
    static private static void scanClass(java.lang.ClassLoader, java.lang.String);
    static java.util.Map<java.lang.String, com.seeyon.boot.starter.lowcode.core.EntityMeta> parse(java.lang.ClassLoader, java.lang.String);
    static private static void buildSubEntity(java.lang.String, com.seeyon.boot.starter.lowcode.core.EntityMeta, java.util.Set<com.seeyon.boot.starter.lowcode.core.EntityMeta>);
    static java.lang.String convertDtoList(com.seeyon.boot.annotation.enums.RelationType, java.lang.String);
    static void clearCache(java.net.URLClassLoader, java.lang.String);
    static private static void parseAttribute(java.lang.Class<?>, java.lang.Class<?>, com.seeyon.boot.starter.lowcode.core.EntityMeta);
```

### `EntityEventHelper`（27 方法）

`com.seeyon.boot.starter.lowcode.helper.EntityEventHelper`

```java
    void beforeEvent(com.seeyon.boot.starter.lowcode.helper.EventContainer);
    void afterEvent(com.seeyon.boot.starter.lowcode.helper.EventContainer);
    void transactionSuccessEvent(com.seeyon.boot.starter.lowcode.helper.EventContainer);
    private java.util.List<java.lang.Long> getIds(java.util.Collection<com.seeyon.udc.common.dto.BaseEntityActionDto>);
    private void printDataList(java.lang.String, com.seeyon.boot.starter.lowcode.helper.EventContainer);
```

### `EntityConfig`（18 方法）

`com.seeyon.boot.starter.lowcode.config.EntityConfig`

```java
    boolean isEnableLog();
    boolean isParallelHandle();
    boolean isRestEnableLog();
    boolean isEnableDeleteAsync();
    int getExpireTime();
    java.util.List<java.lang.String> getIgnoreEntityLog();
    boolean isEnableRelationQueryAsync();
    void setParallelHandle(boolean);
    void setEnableLog(boolean);
    void setRestEnableLog(boolean);
    void setEnableDeleteAsync(boolean);
    void setExpireTime(int);
    void setIgnoreEntityLog(java.util.List<java.lang.String>);
    void setEnableRelationQueryAsync(boolean);
    boolean equals(java.lang.Object);
    protected boolean canEqual(java.lang.Object);
    int hashCode();
    java.lang.String toString();
```

### `CacheUtil`（18 方法）

`com.seeyon.boot.starter.lowcode.util.CacheUtil`

```java
    static org.springframework.cache.annotation.CacheConfig getCacheConfig(java.lang.Class<?>);
    static java.lang.String generateKeyPrefix(java.lang.Object);
    static java.lang.StringBuilder generateFromKeyPrefix(java.lang.ClassLoader);
    static java.lang.String generateSingleKeyPrefix(java.lang.Object);
    static java.lang.String generateSingleKeyPrefixByKey(java.lang.String);
    static java.util.List<java.lang.String> generateCacheKey(java.lang.String, java.lang.Object[]);
    static java.lang.String getCompletekey(java.lang.String, java.lang.reflect.Method, java.lang.Object[]);
    static void evict(java.lang.Class<?>, java.util.Collection<java.lang.Long>);
    static void evictSpecifiedEntity(java.lang.Class<?>);
```

### `EntityMetaUtil`（17 方法）

`com.seeyon.boot.starter.lowcode.util.EntityMetaUtil`

```java
    static void forEachMeta(com.seeyon.boot.starter.lowcode.core.EntityMeta, java.util.function.Consumer<com.seeyon.boot.starter.lowcode.core.EntityMeta>);
    static java.util.Map<java.lang.Class, com.seeyon.boot.starter.lowcode.core.EntityMeta> toDtoClassMetaMap(com.seeyon.boot.starter.lowcode.core.EntityMeta);
    static java.util.Map<java.lang.Class, com.seeyon.boot.starter.lowcode.core.EntityMeta> toDtoClassParentMetaMap(com.seeyon.boot.starter.lowcode.core.EntityMeta);
    static java.util.Map<java.lang.Class, com.seeyon.boot.starter.lowcode.core.EntityMeta> toEntityClassMetaMap(com.seeyon.boot.starter.lowcode.core.EntityMeta);
    static java.util.Map<java.lang.String, com.seeyon.boot.starter.lowcode.core.EntityMeta> toEntityFullNameMetaMap(com.seeyon.boot.starter.lowcode.core.EntityMeta);
    static java.util.Map<java.lang.Class, java.util.List<java.lang.String>> toSubDtoListNameMap(com.seeyon.boot.starter.lowcode.core.EntityMeta);
    static java.lang.String genKey(java.lang.ClassLoader, java.lang.String);
    static void getChildEntityMeta(com.seeyon.boot.starter.lowcode.core.EntityMeta, java.util.List<com.seeyon.boot.starter.lowcode.core.EntityMeta>);
    static java.util.Map<java.lang.Class, com.seeyon.boot.starter.lowcode.core.EntityMeta> getLeafMetaMap(com.seeyon.boot.starter.lowcode.core.EntityMeta);
```

### `AppStartUpManager`（15 方法）

`com.seeyon.boot.starter.lowcode.processor.AppStartUpManager`

```java
    void afterPropertiesSet()
    private void init();
    void onAfterLocalTenantInitEvent(com.seeyon.boot.starter.datainit.message.listener.AfterLocalTenantInitMessage);
    void onCompleteMetadataRegisterEvent(com.seeyon.ctp.metadata.event.MetadataRegisterEvent);
    void onModuleAppLoadEvent(com.seeyon.boot.loader.ModuleAppLoadEvent);
    private void doProcessor(java.util.function.Consumer<com.seeyon.boot.starter.lowcode.processor.AppStartUpProcessor>);
    void onApplicationEvent(com.seeyon.boot.event.SystemStartedEvent);
```

### `ReflectFieldUtil`（13 方法）

`com.seeyon.boot.starter.lowcode.util.ReflectFieldUtil`

```java
    static void clearCache();
    static java.util.Optional<java.lang.Class<?>> getClassForName(java.lang.String);
    static java.lang.reflect.Field getField(java.lang.Object, java.lang.String);
    static java.lang.Object getFieldValue(java.lang.Object, java.lang.String)
    static java.lang.String getFieldDataType(java.lang.reflect.Field);
    static java.util.Collection<java.lang.reflect.Field> getFieldList(java.lang.Class<?>);
    static <D> D getInstance(java.lang.Class<? extends D>);
    static private static java.lang.Object $deserializeLambda$(java.lang.invoke.SerializedLambda);
```

### `QueryConditionUtil`（11 方法）

`com.seeyon.boot.starter.lowcode.util.QueryConditionUtil`

```java
    static void condition2Map(com.seeyon.boot.starter.dynamicsql.dto.QueryConditionDto, java.util.Map<java.lang.String, com.seeyon.boot.starter.dynamicsql.dto.QueryConditionDto>);
    static boolean containsUnderlinedEntities(com.seeyon.boot.starter.dynamicsql.dto.QueryConditionDto);
    static java.lang.Long onlyIdSearch(com.seeyon.boot.starter.dynamicsql.dto.QueryConditionDto);
    static private static java.lang.Long selectIdSearch(java.util.List<java.util.Map<java.lang.String, java.lang.Object>>);
    static boolean useSelectCascadeId(com.seeyon.boot.starter.dynamicsql.dto.QueryConditionDto);
```

### `DynamicConditionUtil`（9 方法）

`com.seeyon.boot.starter.lowcode.util.DynamicConditionUtil`

```java
    static com.seeyon.boot.starter.dynamicsql.dto.ProxyJoinParamDto getProxyJoinParamDto4Query(com.seeyon.boot.starter.dynamicsql.dto.QueryConditionDto);
    static private static void forDownEntityInfo(com.seeyon.boot.starter.dynamicsql.dto.QueryEntityDto, java.util.Map<java.lang.String, com.seeyon.boot.starter.dynamicsql.dto.QueryOne2OneEntityDto>, java.util.List<java.lang.String>, java.util.List<com.seeyon.boot.starter.dynamicsql.dto.JoinParamDto>, java.util.Map<java.lang.String, java.util.Set<java.lang.String>>);
    static private static void recursionUpEntityInfo(com.seeyon.boot.starter.dynamicsql.dto.QueryEntityDto, java.util.Map<java.lang.String, com.seeyon.boot.starter.dynamicsql.dto.QueryOne2OneEntityDto>, java.util.List<java.lang.String>, java.util.List<com.seeyon.boot.starter.dynamicsql.dto.JoinParamDto>, java.util.Map<java.lang.String, java.util.Set<java.lang.String>>);
    static private static void addJoinParamDto(com.seeyon.boot.starter.dynamicsql.dto.QueryEntityDto, com.seeyon.boot.starter.dynamicsql.dto.QueryEntityDto, boolean, java.util.List<java.lang.String>, java.util.List<com.seeyon.boot.starter.dynamicsql.dto.JoinParamDto>, java.util.Map<java.lang.String, java.util.Set<java.lang.String>>);
    static void addParentId2DynamicCondition(com.seeyon.boot.starter.dynamicsql.dto.DynamicConditionDto, java.util.List<java.lang.Long>, java.lang.String);
    static private static com.seeyon.boot.starter.dynamicsql.dto.DynamicConditionDto getDynamicConditionDtoByQuery(com.seeyon.boot.starter.dynamicsql.dto.QueryConditionDto);
```

### `DataTransferAppServiceImpl`（8 方法）

`com.seeyon.boot.starter.lowcode.appservice.DataTransferAppServiceImpl`

```java
    com.seeyon.boot.transport.SingleResponse<com.seeyon.udc.common.transfer.DataTransferResponse> dataTransfer(com.seeyon.boot.transport.SingleRequest<com.seeyon.udc.common.transfer.DataTransferRequest>);
    private void asyncHandleData(com.seeyon.udc.common.transfer.DataTransferRequest, java.util.Map<java.lang.String, java.util.Map<java.lang.String, java.lang.Object>>, java.lang.String);
```

### `BusinessEventHelper`（8 方法）

`com.seeyon.boot.starter.lowcode.helper.BusinessEventHelper`

```java
    void beforeEvent(com.seeyon.boot.mq.BaseMessage);
    void afterEvent(com.seeyon.boot.mq.BaseMessage);
    void afterEventSentDirect(com.seeyon.boot.mq.BaseMessage);
    void transactionSuccessEvent(com.seeyon.boot.mq.BaseMessage);
    private void sendMQ(com.seeyon.boot.mq.BaseMessage);
    private void sendDirectOneTime(com.seeyon.boot.mq.BaseMessage);
```

### `DbMap2DtoUtil`（7 方法）

`com.seeyon.boot.starter.lowcode.util.DbMap2DtoUtil`

```java
    static <D extends com.seeyon.udc.common.dto.BaseEntityActionDto> java.util.List<D> dbMap2List(com.seeyon.boot.starter.lowcode.core.EntityMeta, java.util.List<java.lang.String>, java.util.List<java.lang.Object>);
    static private static <D extends com.seeyon.udc.common.dto.BaseEntityActionDto> void recursiveBuildData(com.seeyon.boot.starter.lowcode.core.EntityMeta, java.util.Map<java.lang.Long, D>, java.util.Map<java.lang.String, java.util.List<D>>);
    static private static <D extends com.seeyon.udc.common.dto.BaseEntityActionDto> void recursiveBuildData4Up(com.seeyon.boot.starter.lowcode.core.EntityMeta, java.util.Map<java.lang.Long, D>, java.util.Map<java.lang.String, java.util.List<D>>);
    static private static <D extends com.seeyon.udc.common.dto.BaseEntityActionDto> void recursiveBuildDataItem4Up(com.seeyon.boot.starter.lowcode.core.EntityMeta, boolean, D, D, java.util.Map<java.lang.Long, D>, java.util.Map<java.lang.String, java.util.List<D>>);
```

### `UdcThreadLocalUtil`（6 方法）

`com.seeyon.boot.starter.lowcode.util.UdcThreadLocalUtil`

```java
    static <T> T get(java.lang.String);
    static <T> T get(java.lang.String, T);
    static void set(java.lang.String, java.lang.Object);
    static void add(java.lang.String, java.lang.Object);
    static void remove();
    static void removeByKey(java.lang.String);
```

### `MyBeanFactoryCacheOperationSourceAdvisor`（5 方法）

`com.seeyon.boot.starter.lowcode.cache.MyBeanFactoryCacheOperationSourceAdvisor`

```java
    void setCacheOperationSource(org.springframework.cache.interceptor.CacheOperationSource);
    void setClassFilter(org.springframework.aop.ClassFilter);
    org.springframework.aop.Pointcut getPointcut();
```

### `DataWorkHandler`（5 方法）

`com.seeyon.boot.starter.lowcode.disruptor.DataWorkHandler`

```java
    void onEvent(com.seeyon.boot.starter.lowcode.context.OperateContext)
    private void processEvent(com.seeyon.boot.starter.lowcode.context.OperateContext);
    void onEvent(java.lang.Object)
```

### `UdcModuleBeanFactory`（4 方法）

`com.seeyon.boot.starter.lowcode.context.UdcModuleBeanFactory`

```java
    static com.seeyon.boot.starter.lowcode.context.UdcModuleBeanHandler getModuleBeanHandler(java.lang.String);
    static com.seeyon.boot.starter.lowcode.context.UdcModuleBeanHandler getModuleBeanHandler(com.seeyon.udc.common.enums.ApplicationSourceEnum);
    void afterPropertiesSet()
```

### `AsyncTaskExecutor`（4 方法）

`com.seeyon.boot.starter.lowcode.core.AsyncTaskExecutor`

```java
    static java.util.concurrent.Future submitTask(java.lang.Runnable);
    static private static java.util.concurrent.ThreadPoolExecutor createThreadPoolExecutor();
    static void ensureAsyncTasksFinish();
    static boolean isStarted();
```

### `ExceptionEventHandler`（4 方法）

`com.seeyon.boot.starter.lowcode.disruptor.ExceptionEventHandler`

```java
    void handleEventException(java.lang.Throwable, long, com.seeyon.boot.starter.lowcode.context.OperateContext);
    void handleOnStartException(java.lang.Throwable);
    void handleOnShutdownException(java.lang.Throwable);
    void handleEventException(java.lang.Throwable, long, java.lang.Object);
```

### `TransactionUtil`（4 方法）

`com.seeyon.boot.starter.lowcode.util.TransactionUtil`

```java
    static <T> void transactionWrapper(java.util.function.Consumer<T>, T);
    static void doAfterCommit(java.lang.Runnable, java.lang.Integer);
    static void doAfterCommit(java.lang.Runnable);
```

### `RedisCacheManagerResolver`（3 方法）

`com.seeyon.boot.starter.lowcode.cache.RedisCacheManagerResolver`

```java
    protected org.springframework.data.redis.cache.RedisCache createRedisCache(java.lang.String, org.springframework.data.redis.cache.RedisCacheConfiguration);
    java.util.Map<java.lang.String, org.springframework.data.redis.cache.RedisCacheConfiguration> getCacheConfigurations();
```

### `UdcProxyCachingConfiguration`（3 方法）

`com.seeyon.boot.starter.lowcode.cache.UdcProxyCachingConfiguration`

```java
    com.seeyon.boot.starter.lowcode.cache.MyBeanFactoryCacheOperationSourceAdvisor udcCacheAdvisor(org.springframework.cache.interceptor.CacheOperationSource, org.springframework.cache.interceptor.CacheInterceptor);
    org.springframework.cache.interceptor.CacheOperationSource cacheOperationSource();
    org.springframework.cache.interceptor.CacheInterceptor cacheInterceptor(org.springframework.cache.interceptor.CacheOperationSource);
```

### `FormModuleBeanHandler`（3 方法）

`com.seeyon.boot.starter.lowcode.context.FormModuleBeanHandler`

```java
    com.seeyon.udc.common.enums.ApplicationSourceEnum getAppType();
    <T> T getBeanObject(java.lang.String, java.lang.String);
    java.lang.Class getClass(java.lang.String, java.lang.String)
```

### `NormalModuleBeanHandler`（3 方法）

`com.seeyon.boot.starter.lowcode.context.NormalModuleBeanHandler`

```java
    com.seeyon.udc.common.enums.ApplicationSourceEnum getAppType();
    <T> T getBeanObject(java.lang.String, java.lang.String);
    java.lang.Class getClass(java.lang.String, java.lang.String)
```

### `BusinessExceptionUtil`（3 方法）

`com.seeyon.boot.starter.lowcode.exception.util.BusinessExceptionUtil`

```java
    static java.util.Optional<java.lang.String> getDefaultMessage(java.lang.String, java.lang.Object...);
    static java.util.Optional<java.lang.String> getMeaningfulMessage(java.lang.String, java.lang.Object...);
```

### `BaseEntityCurdServiceHelper`（3 方法）

`com.seeyon.boot.starter.lowcode.helper.BaseEntityCurdServiceHelper`

```java
    com.seeyon.boot.starter.lowcode.service.BaseEntityCurdService<? extends com.seeyon.udc.common.dto.BaseEntityActionDto> getBaseEntityCurdService(java.lang.String, java.lang.String);
    com.seeyon.boot.starter.lowcode.service.BaseEntityCurdService<? extends com.seeyon.udc.common.dto.BaseEntityActionDto> getBaseEntityCurdService(java.lang.String);
    com.seeyon.boot.starter.lowcode.service.BaseEntityCurdService<? extends com.seeyon.udc.common.dto.BaseEntityActionDto> getBaseEntityCurdService(java.lang.Class<?>);
```

### `EventHandlerBeanPostProcessor`（3 方法）

`com.seeyon.boot.starter.lowcode.processor.EventHandlerBeanPostProcessor`

```java
    static boolean containsKey(java.lang.String);
    java.lang.Object postProcessAfterInitialization(java.lang.Object, java.lang.String)
```

### `EntityReflectionUtil`（3 方法）

`com.seeyon.boot.starter.lowcode.util.EntityReflectionUtil`

```java
    static void doByFieldPath(java.util.List<?>, java.lang.String[], com.seeyon.boot.starter.lowcode.util.EntityReflectionUtil$FieldCallback);
    static private static void doByFieldPath(java.util.List<?>, java.lang.String[], int, com.seeyon.boot.starter.lowcode.util.EntityReflectionUtil$FieldCallback);
```

## 三、注解（9）

| 注解 | 元素 |
|---|---|
| `ECacheEvict` |  |
| `ECachePut` | condition |
| `ECacheable` | condition |
| `ENoCache` | enabled |
| `MethodBizProxy` |  |
| `PriorityCache` | cacheName, cacheManager, isAggregateRoot |
| `RCacheable` | condition |
| `RecycleSerialNumber` |  |
| `UseUdcAppLog` | logModule, appName, signatureName |

## 四、枚举（3）

- `AttrSnapshotRefType`（2 常量）：ENTITY, CTP_ENUM
- `FlowActionType`（6 常量）：NONE, SAVE, SEND, REPEAL, TASK_TO_SENDER, RE_SEND
- `RecursiveType`（2 常量）：TEMPLATE, FORWARD
