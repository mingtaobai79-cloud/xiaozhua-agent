# cip-manager-facade：接口与方法签名

> 自动生成，勿手改。`tools/core/platform/emit_package_surfaces.py` 重跑即可。
> 构件 `com.seeyon:cip-manager-facade`（jar `cip-manager-facade-5.3.273.jar`）
> 规模：95 类 / 13 接口 / 0 注解 / 16 枚举 / 2 个关键类 / 865 方法。
> 签名逐字来自 javap 原文；已去掉 `public` 前缀与 `throws` 子句。

## 一、接口（13）

### `MiddleTableOperationAppService`（12 方法）

`com.seeyon.cip.plug.api.MiddleTableOperationAppService`

```java
    default com.seeyon.boot.transport.SingleResponse<java.lang.Void> saveUnit(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.plug.dto.midddletable.UnitInfoReqDto>);
    default com.seeyon.boot.transport.SingleResponse<java.lang.Void> saveLevel(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.plug.dto.midddletable.LevelInfoReqDto>);
    default com.seeyon.boot.transport.SingleResponse<java.lang.Void> savePost(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.plug.dto.midddletable.PostInfoReqDto>);
    default com.seeyon.boot.transport.SingleResponse<java.lang.Void> saveDuty(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.plug.dto.midddletable.DutyInfoReqDto>);
    default com.seeyon.boot.transport.SingleResponse<java.lang.Void> saveMember(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.plug.dto.midddletable.MemberInfoReqDto>);
    default com.seeyon.boot.transport.SingleResponse<java.lang.String> fullFinish(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    default com.seeyon.boot.transport.PageResponse<com.seeyon.cip.plug.dto.midddletable.UnitInfoDto> queryUnit(com.seeyon.boot.transport.PageRequest);
    default com.seeyon.boot.transport.PageResponse<com.seeyon.cip.plug.dto.midddletable.LevelInfoDto> queryLevel(com.seeyon.boot.transport.PageRequest);
    default com.seeyon.boot.transport.PageResponse<com.seeyon.cip.plug.dto.midddletable.PostInfoDto> queryPost(com.seeyon.boot.transport.PageRequest);
    default com.seeyon.boot.transport.PageResponse<com.seeyon.cip.plug.dto.midddletable.MemberInfoDto> queryMember(com.seeyon.boot.transport.PageRequest);
    default com.seeyon.boot.transport.SingleResponse<java.lang.Void> delete(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.plug.dto.midddletable.MiddleTableDeleteReqDto>);
    default com.seeyon.boot.transport.SingleResponse<java.lang.Void> runningOrgSyncNowByLinkerCode(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.plug.dto.midddletable.RunningOrgSyncNowDto>);
```

### `OrgIntegrationAppService`（10 方法）

`com.seeyon.cip.basic.api.OrgIntegrationAppService`

```java
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.basic.dto.card.QueryResDto> queryCardInfo(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.basic.dto.card.QueryReqDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Boolean> updateCardInfo(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.basic.dto.card.UpdateReqDto>);
    com.seeyon.boot.transport.SingleResponse<java.util.List<com.seeyon.cip.basic.dto.card.ServiceTypeDto>> queryServiceTypeInfo();
    com.seeyon.boot.transport.SingleResponse<java.util.List<java.util.Map<java.lang.String, java.lang.Object>>> queryJsApiAddressByCode(java.lang.String);
    com.seeyon.boot.transport.SingleResponse<java.util.Map<java.lang.String, com.seeyon.cip.basic.dto.card.QueryRunResDto>> queryCardRunInfo(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.basic.dto.card.QueryRunReqDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.basic.dto.card.StaffCardShowTypeDto> queryCardShowInfo();
    com.seeyon.boot.transport.SingleResponse<java.lang.Boolean> queryCardShowIsCustomAvatar(com.seeyon.boot.transport.SingleRequest<java.lang.Void>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.basic.dto.card.StaffCardDefaultResultDto> queryDefaultCardInfo(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.basic.dto.card.QueryRunReqDto>);
    com.seeyon.boot.transport.SingleResponse<java.util.Map<java.lang.String, java.lang.Object>> queryDefaultCardCustomAvatar(com.seeyon.boot.transport.SingleRequest<java.util.List<java.lang.String>>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.basic.dto.card.StaffCardThirdNativeDto> queryThirdNativeCardInfo(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.basic.dto.card.QueryThirdNativeCardReqDto>);
```

### `OpenCapabilityAppService`（6 方法）

`com.seeyon.cip.capability.appservice.api.OpenCapabilityAppService`

```java
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.openapi.operate.dto.AppBasicInfoDto> createApp(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.openapi.operate.dto.AppCreateDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Void> updateAppCharges(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.CapabilityRechargeDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.cip.openapi.operate.dto.OpeningCapabilityDto> queryUseCount(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.capability.dto.CapabilityCountQueryDto>);
    default com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.openapi.operate.dto.AppBasicInfoDto> createTenantApp(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.openapi.operate.dto.TenantAppCreateDto>);
    default com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.openapi.operate.dto.TicketDto> getTicket(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.openapi.operate.dto.CreateUserDto>);
    default com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.openapi.operate.dto.AppUrlResponseDto> getAppUrl(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.openapi.operate.dto.AppUrlRequestDto>);
```

### `PersonnelCardService`（5 方法）

`com.seeyon.cip.basic.api.PersonnelCardService`

```java
    default java.lang.String getServiceCode();
    java.lang.String getServiceName();
    java.util.Map<java.lang.String, java.lang.Object[]> getServiceResParam();
    java.util.List<java.util.Map<java.lang.String, java.lang.Object>> queryJsApiAddressParam();
    java.util.Map<java.lang.String, java.lang.Object> result(java.util.Map<java.lang.String, java.lang.Object>);
```

### `DefaultCardInfoService`（4 方法）

`com.seeyon.cip.basic.api.DefaultCardInfoService`

```java
    default java.lang.String getBeanName();
    java.lang.String getName();
    java.lang.String getTypeCaption();
    com.seeyon.cip.basic.dto.card.StaffCardDefaultRunDto buildCardInfo(java.lang.String, java.lang.String, java.lang.String, java.lang.String);
```

### `PluginAffairAppService`（4 方法）

`com.seeyon.cip.plug.api.PluginAffairAppService`

```java
    default com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.plug.dto.PluginAffairResultDto> addModifyPluginAffair(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.plug.dto.PluginAffairBatchDto>);
    default com.seeyon.boot.transport.SingleResponse<java.lang.Void> processRevoke(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.plug.dto.PluginAffairGroupDto>);
    default com.seeyon.boot.transport.SingleResponse<java.lang.Void> processTerminate(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.plug.dto.PluginAffairGroupDto>);
    default com.seeyon.boot.transport.SingleResponse<java.lang.String> getExternalIdByAffairId(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
```

### `WarningManageAppService`（2 方法）

`com.seeyon.cip.custom.api.WarningManageAppService`

```java
    default com.seeyon.boot.transport.SingleResponse<java.lang.Long> addWarningInfo(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.custom.dto.CipWarningInfoDto>);
    default com.seeyon.boot.transport.SingleResponse<java.lang.Void> modifyWarningInfo(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.custom.dto.CipWarningInfoDto>);
```

### `CipFileAppService`（2 方法）

`com.seeyon.cip.openapi.operate.api.CipFileAppService`

```java
    default com.seeyon.boot.transport.SingleResponse<java.lang.Void> uploadFiles(com.seeyon.boot.transport.SingleRequest<java.lang.Void>);
    default com.seeyon.boot.transport.SingleResponse<java.lang.Boolean> deleteByStorageKeys(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.openapi.operate.dto.FileDeleteDto>);
```

### `PluginStatusAppService`（2 方法）

`com.seeyon.cip.plug.api.PluginStatusAppService`

```java
    com.seeyon.boot.transport.ListResponse<com.seeyon.cip.plug.dto.PlugStatusDto> selectStatusByPlugIds(com.seeyon.boot.transport.SingleRequest<java.util.List<java.lang.Long>>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.cip.plug.dto.PlugStatusDto> selectStatusByLinkerIds(com.seeyon.boot.transport.SingleRequest<java.util.List<java.lang.Long>>);
```

### `WarningCallBackAppService`（1 方法）

`com.seeyon.cip.custom.api.WarningCallBackAppService`

```java
    default com.seeyon.boot.transport.SingleResponse<java.lang.Void> redoWarning(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.custom.dto.CipWarningInfoDto>);
```

### `CipMessageAppService`（1 方法）

`com.seeyon.cip.openapi.operate.api.CipMessageAppService`

```java
    default com.seeyon.boot.transport.SingleResponse<java.lang.Boolean> deliveryMqMessage(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.openapi.operate.dto.CipMessageDeliveryDto>);
```

### `OpenApiNotifyAppService`（1 方法）

`com.seeyon.cip.openapi.operate.api.OpenApiNotifyAppService`

```java
    default com.seeyon.boot.transport.SingleResponse<java.lang.Void> batchSaveOpenApiNotify(com.seeyon.boot.transport.SingleRequest<java.util.List<com.seeyon.cip.openapi.operate.dto.CipNotifyMessageDto>>);
```

### `PluginMessageAppService`（1 方法）

`com.seeyon.cip.plug.api.PluginMessageAppService`

```java
    default com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.plug.dto.PluginMessageResultDto> syncPluginMessage(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.plug.dto.PluginMessageBatchDto>);
```

## 二、关键类（2）

### `ConfigDto`（24 方法）

`com.seeyon.cip.basic.dto.card.ConfigDto`

```java
    void setId(java.lang.Long);
    void setShowTypeEnum(com.seeyon.cip.basic.enums.card.ShowTypeEnum);
    void setThirdWebAddress(java.lang.String);
    void setThirdWebWidth(java.math.BigDecimal);
    void setThirdWebHeight(java.math.BigDecimal);
    void setThirdMobileAddress(java.lang.String);
    void setThirdMobileWidth(java.math.BigDecimal);
    void setThirdMobileHeight(java.math.BigDecimal);
    void setPrimordialJsApi(java.lang.String);
    void setPrimordialJsApiMin(java.lang.String);
    void setPrimordialAppId(java.lang.String);
    void setPrimordialAppSecret(java.lang.String);
    java.lang.Long getId();
    com.seeyon.cip.basic.enums.card.ShowTypeEnum getShowTypeEnum();
    java.lang.String getThirdWebAddress();
    java.math.BigDecimal getThirdWebWidth();
    java.math.BigDecimal getThirdWebHeight();
    java.lang.String getThirdMobileAddress();
    java.math.BigDecimal getThirdMobileWidth();
    java.math.BigDecimal getThirdMobileHeight();
    java.lang.String getPrimordialJsApi();
    java.lang.String getPrimordialJsApiMin();
    java.lang.String getPrimordialAppId();
    java.lang.String getPrimordialAppSecret();
```

### `ServiceTypeDto`（4 方法）

`com.seeyon.cip.basic.dto.card.ServiceTypeDto`

```java
    void setServiceCode(java.lang.String);
    void setServiceName(java.lang.String);
    java.lang.String getServiceCode();
    java.lang.String getServiceName();
```

## 四、枚举（16）

- `RequestTypeEnum`（2 常量）：PRIMORDIAL, CONNECTOR
- `ServiceTypeEnum`（2 常量）：FEI_SHU, DING_DING
- `ShowTypeEnum`（4 常量）：DEFAULT, THIRD, NATIVE, SELECTED_TYPE
- `ActionResultTypeEnum`（2 常量）：SUCCESS, FAIL
- `ApplicationTypeEnum`（2 常量）：InCip, OutCip
- `AppStatusEnum`（2 常量）：ONLINE, OFFLINE
- `NotifyTypeEnum`（2 常量）：OpenEvent, OpenApi
- `AffairActionEnum`（3 常量）：START, OTHER, MODIFY_AGENT
- `AffairResultEnum`（4 常量）：ADD, MODIFY, IGNORE, ERR
- `GenderEnum`（4 常量）：NONE, MALE, FEMALE, UN_KNOW
- `MemberTypeEnum`（2 常量）：MEMBER, OUTSIDE_MEMBER
- `MiddleTableCategoryEnum`（3 常量）：NONE, BENCH_MARK, SELF_BUILT
- `MiddleTableDimensionEnum`（5 常量）：UNIT, LEVEVL, POSITION, MEMBER, STAFF_DUTY
- `MiddleTableUnitTypeEnum`（5 常量）：INSTITUTION, DEPARTMENT, OUTSIDE_INSTITUTION, OUTSIDE_DEPARTMENT, LOCAL
- `ScopeTypeEnum`（6 常量）：NONE, INSTITUTION, INSTITUTIONS, ONLY_CHILDREN, SPECIFY_INSTITUTION, SPECIFY_INSTITUTIONS
- `UserIdTypeEnum`（5 常量）：OUTER_ID, V8_ID, V8_CODE, V8_LOGIN_NAME, V8_PHONE
