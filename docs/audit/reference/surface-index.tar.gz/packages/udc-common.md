# udc-common：接口与方法签名

> 自动生成，勿手改。`tools/core/platform/emit_package_surfaces.py` 重跑即可。
> 构件 `com.seeyon:udc-common`（jar `udc-common-5.3.605.jar`）
> 规模：424 类 / 13 接口 / 1 注解 / 64 枚举 / 38 个关键类 / 4454 方法。
> 签名逐字来自 javap 原文；已去掉 `public` 前缀与 `throws` 子句。

## 一、接口（13）

### `UdcDataType`（39 方法） extends DataType<T>

`com.seeyon.udc.common.datatype.UdcDataType`

```java
    default boolean supportCustom();
    default boolean custom();
    default java.lang.String getBaseDataType();
    java.util.List<java.util.Map<java.lang.String, java.lang.Object>> getExtensionProperties();
    java.lang.String getDefaultDataProperties();
    com.seeyon.udc.common.datatype.TypeHelper getTypeHelper();
    java.util.List<java.lang.String> getFrontComponent();
    int getLength();
    default boolean inDataMapping();
    default boolean inCondition();
    boolean hasDefaultValue();
    boolean multiSelect();
    boolean calculable();
    boolean aggregation();
    boolean index();
    boolean sensitive();
    boolean encryption();
    default boolean enableSensitiveWordCheck();
    boolean log();
    boolean lengthRange();
    boolean maxAndMin();
    boolean decimalDigits();
    boolean unique();
    boolean pattern();
    boolean fullSearch();
    default boolean i18n();
    default boolean list();
    default boolean detail();
    default boolean quickSearch();
    default boolean generateDbDefaultValue(com.seeyon.udc.common.dto.AttributeDto);
    default boolean generateDbNotNullConstraints(com.seeyon.udc.common.dto.AttributeDto);
    default java.lang.Object dbDefaultValue(com.seeyon.udc.common.dto.AttributeDto);
    default java.util.List<java.lang.String> getValidationAnnotations(com.seeyon.udc.common.datatype.UdcDataTypeProperties);
    boolean check(com.seeyon.udc.common.datatype.UdcDataTypeProperties);
    default boolean supportParameter();
    default java.lang.Object processingTemplateData(java.lang.Object);
    default java.lang.Object processingForwardData(java.lang.Object);
    default java.lang.String uniqueKey(java.lang.Object);
    default java.util.Map<java.lang.String, java.util.Map<java.lang.String, java.lang.Object>> selectDisplayList(java.util.Map<java.lang.String, java.lang.Object>);
```

### `MappingMode`（14 方法）

`com.seeyon.udc.common.mappingmode.MappingMode`

```java
    java.lang.String getName();
    java.lang.String getCaption();
    com.seeyon.udc.common.enums.MappingModeCategoryEnum getMappingModeCategory();
    java.util.List<com.seeyon.udc.common.enums.DataFlowOperationTypeEnum> getSupportOperationType();
    java.util.List<java.lang.String> getTargetDataTypes();
    default java.util.List<java.lang.String> getSourceDataTypes();
    java.lang.Boolean getSupportWriteBack();
    default java.lang.Boolean getIntersection();
    java.lang.Integer getOrder();
    java.lang.Object calculate(java.util.List<java.lang.Object>);
    void processingMapping(java.lang.Object, com.seeyon.udc.common.dto.DataFlowMappingRowDto, java.util.Map<java.lang.String, java.lang.Object>, java.util.List<java.util.Map<java.lang.String, java.lang.Object>>, com.seeyon.udc.common.dto.DynamicExecuteExtendDto);
    default java.lang.Boolean checkMappingField();
    java.lang.Boolean checkFieldExtProperties();
    java.lang.String groupingFunctionResultType();
```

### `MicroFlowSchemaDeterminer`（12 方法）

`com.seeyon.udc.domain.MicroFlowSchemaDeterminer`

```java
    java.lang.Long getAppId();
    java.lang.String getName();
    java.lang.String getCaption();
    java.lang.String getDescription();
    com.seeyon.udc.common.enums.MicroFlowTypeEnum getType();
    com.seeyon.udc.common.enums.MicroFlowTriggerTypeEnum getTriggerType();
    java.lang.String getSourceId();
    java.lang.String getJsonSchema();
    java.lang.String getDataSchema();
    com.seeyon.udc.common.enums.MicroFlowOpenApiStateTypeEnum getOpenApi();
    com.seeyon.udc.common.enums.MicroFlowRestApiStateEnum getRestApi();
    java.lang.String getRestPath();
```

### `TypeHelper`（7 方法）

`com.seeyon.udc.common.datatype.TypeHelper`

```java
    int getDatabaseDataType(com.seeyon.udc.common.dto.BaseUdcAttributeDto);
    java.lang.String getJavaType(com.seeyon.udc.common.dto.BaseUdcAttributeDto);
    int getLength(com.seeyon.udc.common.dto.BaseUdcAttributeDto);
    default int getDefaultMaxLength(com.seeyon.udc.common.dto.BaseUdcAttributeDto);
    int getDatabaseDataType(com.seeyon.boot.starter.extmetadata.dto.UdcAttributeMetaDataDto);
    java.lang.String getJavaType(com.seeyon.boot.starter.extmetadata.dto.UdcAttributeMetaDataDto);
    int getLength(com.seeyon.boot.starter.extmetadata.dto.UdcAttributeMetaDataDto);
```

### `DeductionSearchMethodType`（6 方法）

`com.seeyon.udc.common.deduction.searchmethod.DeductionSearchMethodType`

```java
    java.lang.String getName();
    java.lang.String getCaption();
    java.lang.Integer getOrder();
    com.seeyon.udc.common.enums.DeductionSearchMethodTypeEnum getDeductionSearchMethodTypeEnum();
    default java.util.List<java.lang.String> getTargetDataTypes();
    default java.util.List<java.lang.String> getSourceDataTypes();
```

### `MicroFlowLastVersionMetadataEnabler`（5 方法）

`com.seeyon.udc.domain.MicroFlowLastVersionMetadataEnabler`

```java
    com.seeyon.udc.common.enums.MicroFlowTypeEnum getType();
    com.seeyon.udc.common.enums.MicroFlowTriggerTypeEnum getTriggerType();
    com.seeyon.udc.common.enums.MicroFlowDataStateEnum getState();
    com.seeyon.udc.common.enums.MicroFlowLastVersionMetadataStateEnum getLastVersionMetadataState();
    default boolean enableLastVersionMetadata();
```

### `CustomPlanPageFeatureHandler`（2 方法）

`com.seeyon.udc.common.customplan.handler.CustomPlanPageFeatureHandler`

```java
    default boolean pageSupportCustomPlan(com.seeyon.boot.starter.extmetadata.dto.UdcPageMetadataV2Dto);
    default boolean pageSupportCustomPlan(com.seeyon.udc.common.dto.UdcPageMetadataDto);
```

### `LambdaMeta`（2 方法）

`com.seeyon.udc.common.support.LambdaMeta`

```java
    java.lang.String getImplMethodName();
    java.lang.Class<?> getInstantiatedClass();
```

### `UdcTreeQueryService`（1 方法）

`com.seeyon.udc.common.api.UdcTreeQueryService`

```java
    com.seeyon.boot.transport.PageResponse selectTreeData(com.seeyon.boot.transport.SingleRequest<com.seeyon.udc.common.dto.tree.UdcTreeQueryDto>);
```

### `Functor`（1 方法）

`com.seeyon.udc.common.utils.Functor`

```java
    <R> F map(java.util.function.Function<T, R>);
```

### `OperationLogSchema`（1 方法）

`com.seeyon.udc.domain.OperationLogSchema`

```java
    java.lang.String getOperationLogSchema();
```

### `UConsumer`（0 方法）

`com.seeyon.udc.common.support.UConsumer`

```java
```

### `UFunction`（0 方法）

`com.seeyon.udc.common.support.UFunction`

```java
```

## 二、关键类（38）

### `FileUtils`（72 方法）

`com.seeyon.udc.common.utils.FileUtils`

```java
    static java.io.File newFile(java.lang.String);
    static java.io.File newFileWithParentDir(java.lang.String);
    static java.io.FileOutputStream openOutputStream(java.io.File, boolean)
    static java.io.File newFileMorePath(java.lang.String, java.lang.String...);
    static boolean moveFile(java.io.File, java.io.File);
    static boolean exist(java.lang.String);
    static boolean exist(java.io.File);
    static java.lang.String readFileToString(java.io.File)
    static byte[] readFileToByteArray(java.io.File)
    static java.lang.String getName(java.lang.String);
    static byte[] toByteArray(java.io.InputStream)
    static void writeStringToFile(java.io.File, java.lang.String, java.lang.String)
    static void writeStringToFile(java.io.File, java.lang.String)
    static void writeString(java.lang.String, java.lang.String);
    static void copyFileToDirectory(java.io.File, java.io.File)
    static java.io.BufferedInputStream getInputStream(java.lang.String)
    static java.io.BufferedInputStream getInputStream(java.io.File)
    static java.util.Collection<java.io.File> listFiles(java.io.File, org.apache.commons.io.filefilter.IOFileFilter, org.apache.commons.io.filefilter.IOFileFilter);
    static java.util.Collection<java.io.File> listFiles(java.io.File, java.lang.String[], boolean);
    static boolean deleteQuietly(java.io.File);
    static boolean delete(java.io.File);
    static boolean deleteQuietly(java.lang.String);
    static void writeLines(java.io.File, java.util.Collection<?>, boolean)
    static void cleanDirectory(java.io.File)
    static void forceDelete(java.io.File)
    static void deleteDirectory(java.io.File)
    static boolean isSymlink(java.io.File)
    static java.io.File getAbsoluteFile(java.io.File);
    static java.io.File newFile(java.io.File, java.lang.String);
    static java.io.File getCanonicalFile(java.io.File)
    static java.lang.String readResourceToString(java.lang.String)
    static java.io.File readResourceFile(java.lang.String)
    static java.lang.String getFileMd5(java.lang.String)
    static java.lang.String getFileMd5(java.io.File)
    static void saveFile(java.io.File, java.io.InputStream);
    static java.lang.String getRelativePath(java.io.File, java.io.File);
    static java.util.List<java.lang.String> searchAllNotIgnoreFile(java.io.File);
    static private static java.util.List<java.lang.String> searchAllNotIgnoreFileOfZip(java.lang.String, int);
    static private static java.util.List<java.lang.String> listFilePathOfZip(java.lang.String, java.lang.String);
    static java.io.File getFile(java.lang.String);
    static private static java.io.File getFileByClassLoader(java.lang.String)
    static private static java.lang.ClassLoader getDefaultClassLoader();
    static private static void searchAllNotIgnoreFile(java.io.File, java.util.List<java.lang.String>);
    static java.io.File parentMkdir(java.lang.String);
    static void parentMkdir(java.io.File);
    static private static boolean isIgnoreFile(java.io.File);
    static private static java.lang.String toFilePathIfIsUrl(java.io.File);
    static <T> T jsonToBean(java.lang.String, java.lang.Class<T>);
    static <T> java.util.List<T> jsonToBeanList(java.lang.String, java.lang.Class<T>);
    static private static void copy(java.io.InputStream, java.io.OutputStream);
    static private static java.lang.String[] toSuffixes(java.lang.String[]);
    static void replace(java.util.Collection<java.io.File>, java.util.Map<java.lang.String, java.lang.String>);
    static java.lang.String getFileName(java.io.File);
    static java.lang.String getFilePath(java.io.File);
    static java.lang.String getFileAbsolutePath(java.io.File);
    static boolean isDirectory(java.io.File);
    static boolean isHidden(java.io.File);
    static boolean isFile(java.io.File);
    static boolean exists(java.io.File);
    static boolean isAbsolute(java.io.File);
    static java.io.File getParentFile(java.io.File);
    static java.lang.String getParent(java.io.File);
    static boolean mkdirs(java.io.File);
    static java.net.URI toURI(java.io.File);
    static java.io.File[] listFiles(java.io.File);
    static java.io.File[] listFiles(java.io.File, java.io.FileFilter);
    static boolean rename(java.io.File, java.io.File);
    static long lastModified(java.io.File);
    static long length(java.io.File);
```

### `DataFlowEntityUtil`（42 方法）

`com.seeyon.udc.common.utils.DataFlowEntityUtil`

```java
    static com.seeyon.udc.common.dto.DataFlowEntityDto getRootEntity(com.seeyon.udc.common.dto.DataFlowEntityDto);
    static java.util.Set<java.lang.String> getAllEntityName(com.seeyon.udc.common.dto.DataFlowEntityDto);
    static java.util.Set<java.lang.String> getAllEntityName(com.seeyon.udc.common.dto.DataFlowEntityDto, boolean);
    static private static void lookDown(java.util.Set<java.lang.String>, com.seeyon.udc.common.dto.DataFlowEntityDto, boolean);
    static java.util.Set<java.lang.String> upEntity(com.seeyon.udc.common.dto.DataFlowEntityDto);
    static java.util.Set<java.lang.String> upEntity(com.seeyon.udc.common.dto.DataFlowEntityDto, boolean);
    static private static void lookUp(java.util.Set<java.lang.String>, com.seeyon.udc.common.dto.DataFlowEntityDto, boolean);
    static java.util.Map<java.lang.String, com.seeyon.udc.common.dto.DataFlowEntityDto> toMap(java.util.List<com.seeyon.udc.common.dto.DataFlowEntityDto>);
    static private static void toMap(java.util.Map<java.lang.String, com.seeyon.udc.common.dto.DataFlowEntityDto>, com.seeyon.udc.common.dto.DataFlowEntityDto);
    static void getEntityId(java.util.Set<java.lang.Long>, com.seeyon.udc.common.dto.DataFlowEntityDto);
    static java.util.Map<java.lang.String, java.lang.Integer> getEntityLevel(com.seeyon.udc.common.dto.DataFlowEntityDto);
    static private static void getEntityLevel(java.util.Map<java.lang.String, java.lang.Integer>, com.seeyon.udc.common.dto.DataFlowEntityDto, java.lang.Integer);
    static void generateSortMark(java.util.Map<java.lang.String, java.lang.String>, com.seeyon.udc.common.dto.DataFlowEntityDto);
    static private static void recursionGenerateSortMark(java.lang.String, com.seeyon.udc.common.utils.SortMarkGenerator, java.util.Map<java.lang.String, java.lang.String>, com.seeyon.udc.common.dto.DataFlowEntityDto);
    static void collectCtpEnum(java.util.Map<java.lang.String, java.util.Set<java.lang.String>>, java.util.Map<java.lang.String, java.util.List<com.seeyon.udc.common.dto.DataFlowAttributeDto>>, java.util.Map<java.lang.String, java.util.Set<java.lang.String>>, java.util.Map<java.lang.String, java.util.List<com.seeyon.udc.common.dto.DataFlowAttributeDto>>, com.seeyon.udc.common.dto.DataFlowEntityDto);
    static java.util.List<com.seeyon.udc.common.dto.DataFlowEnumItemDto> filterBillStatusType(com.seeyon.udc.common.dto.DataFlowAttributeDto, java.util.List<com.seeyon.udc.common.dto.DataFlowEnumItemDto>);
```

### `EntityUtil`（36 方法）

`com.seeyon.udc.common.utils.EntityUtil`

```java
    static com.seeyon.udc.common.dto.EntityDto getRootEntity(com.seeyon.udc.common.dto.EntityDto);
    static boolean isRootType(com.seeyon.udc.common.dto.EntityBaseDto);
    static boolean isChildType(com.seeyon.udc.common.dto.EntityDto);
    static void loadEntityAggregation(java.util.Map<java.lang.Long, com.seeyon.udc.common.dto.EntityDto>);
    static void loadEntityAggregation(java.util.Map<java.lang.Long, com.seeyon.udc.common.dto.EntityDto>, boolean);
    static private static void recursionLoadParentEntity(com.seeyon.udc.common.dto.EntityDto, java.util.Set<java.lang.Long>, java.util.Map<java.lang.Long, com.seeyon.udc.common.dto.EntityDto>, boolean);
    static void loadEntity4CodeAggregation(java.util.Map<java.lang.Long, com.seeyon.udc.common.dto.Entity4CodeDto>);
    static void loadEntity4CodeAggregation(java.util.Map<java.lang.Long, com.seeyon.udc.common.dto.Entity4CodeDto>, boolean);
    static private static void recursionLoadParentEntity4Code(com.seeyon.udc.common.dto.Entity4CodeDto, java.util.Set<java.lang.Long>, java.util.Map<java.lang.Long, com.seeyon.udc.common.dto.Entity4CodeDto>, boolean);
    static java.util.List<java.lang.Long> strIdToLong(java.lang.String);
    static java.lang.String getEntityFullNameByDtoName(java.lang.String);
    static java.lang.String getOldEntityName(java.lang.String);
    static java.lang.String getOldEntityCaption(java.lang.String);
    static java.lang.String getSimpleNameFromFullName(java.lang.String);
    static java.util.Date getDateDefaultValueByStringOrTimeStamp(java.lang.String);
    static java.util.Date getDateTimeDefaultValueByStringOrTimeStamp(java.lang.String);
    static java.util.List<com.seeyon.udc.common.dto.EntityDto> getEntitySystemExcludeSelf(com.seeyon.udc.common.dto.EntityDto, java.util.Map<java.lang.Long, com.seeyon.udc.common.dto.EntityDto>);
    static private static void getEntitySystem(com.seeyon.udc.common.dto.EntityDto, java.util.Map<java.lang.Long, com.seeyon.udc.common.dto.EntityDto>, java.util.List<com.seeyon.udc.common.dto.EntityDto>);
    static boolean isPublished(com.seeyon.udc.common.dto.UdcBaseEntityDto);
    static boolean isDeployPublishStateEnum(java.util.function.Supplier<com.seeyon.udc.common.enums.PublishStateEnum>);
    static boolean isDeploy(com.seeyon.udc.common.dto.UdcBaseEntityDto);
    static boolean isDeploy(com.seeyon.udc.domain.entity.UdcBaseEntity);
    static boolean isDeploy(java.util.Collection<? extends com.seeyon.udc.domain.entity.UdcBaseEntity>);
    static java.lang.String getAppServiceFullNameByEntityName(java.lang.String, java.lang.String);
    static java.lang.String getRuntimeDtoName(java.lang.String);
    static java.lang.String getEntityFullNameByAttributeFullName(java.lang.String);
    static boolean isScalabilityEntity(com.seeyon.udc.common.dto.EntityDto);
    static java.util.List<com.seeyon.udc.common.dto.EntityDto> lookUpEntityList(com.seeyon.udc.common.dto.EntityDto);
    static com.seeyon.udc.common.dto.EntityDto getRootEntity(java.util.Map<java.lang.Long, com.seeyon.udc.common.dto.EntityDto>, com.seeyon.udc.common.dto.EntityDto);
    static java.util.List<com.seeyon.udc.common.dto.EntityDto> getAllChildren(java.util.List<com.seeyon.udc.common.dto.EntityDto>, java.lang.Long);
    static private static void findChildren(java.util.List<com.seeyon.udc.common.dto.EntityDto>, java.lang.Long, java.util.List<com.seeyon.udc.common.dto.EntityDto>);
```

### `JsonPathHelper`（26 方法）

`com.seeyon.udc.common.utils.JsonPathHelper`

```java
    void run(org.springframework.boot.ApplicationArguments)
    static java.util.Set<java.lang.String> getPath(java.lang.String, java.lang.String, com.jayway.jsonpath.Predicate...);
    static java.util.Set<java.lang.String> getPath(com.jayway.jsonpath.DocumentContext, java.lang.String, com.jayway.jsonpath.Predicate...);
    static java.util.List<java.lang.String> convert2PathList(java.lang.String);
    static java.lang.String appendPath(java.lang.String, java.lang.String);
    static java.lang.String getDetailedPath(java.util.List<java.lang.String>, int, java.util.List<java.lang.String>);
    static java.lang.String getDetailedPathCommon(java.util.List<java.lang.String>, int, java.util.List<java.lang.String>);
    static <T> java.util.Map<java.lang.String, T> getDetailedPathAndReadPath(com.jayway.jsonpath.DocumentContext, java.lang.String, T, com.jayway.jsonpath.Predicate...);
    static <T> java.util.Map<java.lang.String, T> getDetailedPathAndReadPath(java.lang.String, java.lang.String, T, com.jayway.jsonpath.Predicate...);
    static <T> java.util.Map<java.lang.String, T> getDetailedPathAndReadPath(com.jayway.jsonpath.DocumentContext, java.lang.String, com.jayway.jsonpath.TypeRef<T>, T);
    static <T> java.util.Map<java.lang.String, T> getDetailedPathAndReadPath(java.lang.String, java.lang.String, com.jayway.jsonpath.TypeRef<T>, T);
    static <T> java.util.Map<java.lang.String, T> getDetailedPathAndReadPath(com.jayway.jsonpath.DocumentContext, java.lang.String, java.lang.Class<T>, T, com.jayway.jsonpath.Predicate...);
    static <T> java.util.Map<java.lang.String, T> getDetailedPathAndReadPath(java.lang.String, java.lang.String, java.lang.Class<T>, T, com.jayway.jsonpath.Predicate...);
    static <T> T readPath(java.lang.String, java.lang.String, T, com.jayway.jsonpath.Predicate...);
    static <T> T readPath(com.jayway.jsonpath.DocumentContext, java.lang.String, T, com.jayway.jsonpath.Predicate...);
    static <T> T readPath(java.lang.String, java.lang.String, java.lang.Class<T>, T, com.jayway.jsonpath.Predicate...);
    static <T> T readPath(com.jayway.jsonpath.DocumentContext, java.lang.String, java.lang.Class<T>, T, com.jayway.jsonpath.Predicate...);
    static <T> T readPath(java.lang.String, java.lang.String, com.jayway.jsonpath.TypeRef<T>, T);
    static <T> T readPath(com.jayway.jsonpath.DocumentContext, java.lang.String, com.jayway.jsonpath.TypeRef<T>, T);
    static com.jayway.jsonpath.DocumentContext delete(com.jayway.jsonpath.DocumentContext, java.lang.String, com.jayway.jsonpath.Predicate...);
    static com.jayway.jsonpath.DocumentContext parse(java.lang.String);
    static java.util.List<java.util.Map<java.lang.String, java.lang.Object>> getAllSchemaMap(com.jayway.jsonpath.DocumentContext);
```

### `CompletableFutureUtils`（21 方法）

`com.seeyon.udc.common.utils.CompletableFutureUtils`

```java
    static <R> java.util.concurrent.CompletableFuture<R> apply(java.util.List<R>, com.seeyon.udc.common.support.UFunction<java.util.List<R>, R>);
    static <T> void parallelListBatch(java.util.List<T>, com.seeyon.udc.common.support.UConsumer<T>);
    static <T, R> java.util.List<R> parallelListBatch(T, java.util.List<com.seeyon.udc.common.support.UFunction<T, R>>);
    static <T> void parallelListBatch(java.util.List<T>, com.seeyon.udc.common.support.UConsumer<T>, java.util.concurrent.Executor);
    static <T, R> java.util.List<R> parallelListBatch(T, java.util.List<com.seeyon.udc.common.support.UFunction<T, R>>, java.util.concurrent.Executor);
    static <T, R> java.util.Map<java.lang.Class, R> parallelMapBatch(java.util.Map<com.seeyon.udc.common.support.UFunction<T, R>, T>);
    static <T, R> java.util.Map<java.lang.Class, R> parallelMapBatch(java.util.Map<com.seeyon.udc.common.support.UFunction<T, R>, T>, java.util.concurrent.Executor);
    static <T, U> java.util.concurrent.CompletableFuture thenApplyBatch(java.util.concurrent.CompletableFuture<T>, java.util.List<com.seeyon.udc.common.support.UFunction<T, U>>);
```

### `ReferRuntimeConfigDto`（18 方法）

`com.seeyon.udc.common.dto.ReferRuntimeConfigDto`

```java
    java.lang.String getAppName();
    java.lang.String getDrivenEntity();
    java.lang.String getSourceRefer();
    java.util.List<java.lang.String> getEntities();
    com.seeyon.udc.common.dto.ReferConstraintDto getConstraintRule();
    java.util.List<java.util.Map<java.lang.String, java.lang.Object>> getShowSetting();
    java.util.List<java.util.Map<java.lang.String, java.lang.Object>> getSortSetting();
    java.util.List<java.util.Map<java.lang.String, java.lang.Object>> getSearchSetting();
    java.util.List<java.util.Map<java.lang.String, java.lang.Object>> getCond();
    void setAppName(java.lang.String);
    void setDrivenEntity(java.lang.String);
    void setSourceRefer(java.lang.String);
    void setEntities(java.util.List<java.lang.String>);
    void setConstraintRule(com.seeyon.udc.common.dto.ReferConstraintDto);
    void setShowSetting(java.util.List<java.util.Map<java.lang.String, java.lang.Object>>);
    void setSortSetting(java.util.List<java.util.Map<java.lang.String, java.lang.Object>>);
    void setSearchSetting(java.util.List<java.util.Map<java.lang.String, java.lang.Object>>);
    void setCond(java.util.List<java.util.Map<java.lang.String, java.lang.Object>>);
```

### `AnnotationUtils`（18 方法）

`com.seeyon.udc.common.utils.AnnotationUtils`

```java
    static boolean isEntity(java.lang.Class<?>, java.lang.Class<? extends java.lang.annotation.Annotation>);
    static boolean isEntity(java.lang.Class<?>);
    static boolean isMasterEntity(java.lang.Class<?>);
    static boolean isEntityFrom(java.lang.Class<?>, java.lang.String...);
    static com.seeyon.boot.annotation.enums.EntityType getEntityType(java.lang.Class<?>);
    static <T> T getAnnotationValue(java.lang.reflect.AnnotatedElement, java.lang.Class<? extends java.lang.annotation.Annotation>, java.lang.String);
    static java.lang.String getCustomAttributeValue(java.lang.reflect.AnnotatedElement, java.lang.Class<? extends java.lang.annotation.Annotation>, java.lang.String);
    static java.util.Map<java.lang.String, java.lang.String> getCustomAttributeMap(java.lang.reflect.AnnotatedElement, java.lang.Class<? extends java.lang.annotation.Annotation>);
    static java.util.List<com.seeyon.boot.annotation.CustomAttribute> getCustomAttribute(java.lang.reflect.AnnotatedElement, java.lang.Class<? extends java.lang.annotation.Annotation>);
    static void setAllFieldNullObject(java.lang.Object);
```

### `AppLogUtil`（17 方法）

`com.seeyon.udc.common.utils.AppLogUtil`

```java
    static boolean isLogEnabled(java.lang.String);
    static boolean enableLog(java.lang.String);
    static boolean enableLog(java.lang.String, long, java.util.concurrent.TimeUnit);
    static int getStorageOfMonth(java.lang.String);
    static long getDefaultExpireTime(java.lang.String);
    static boolean renewal(java.lang.String, long, java.util.concurrent.TimeUnit);
    static java.lang.Long getExpire(java.lang.String);
    static private static boolean determineLogEnabled(java.lang.String);
    static void removeLocalAppLogCacheByAppName(java.lang.String);
    static void removeLocalDataMonitorCacheByAppName(java.lang.String);
    static private static java.lang.String appLogkey(java.lang.String);
    static private static java.lang.String appDataMonitorLogkey(java.lang.String);
    static private static void init();
    static java.lang.String changeAppLogTopic();
    static java.lang.String changeAppDataMonitorLogTopic();
    static boolean isDataMonitorLogEnabled();
    static boolean enableDataLog(int);
```

### `FormulaUtil`（17 方法）

`com.seeyon.udc.common.utils.FormulaUtil`

```java
    static java.util.Set<java.lang.Long> getEntityListFromFormulaJson(java.lang.String);
    static java.util.Set<java.lang.Long> getEntityListFromFormula(com.seeyon.boot.starter.formula.dto.ExpressionDefinitionDto);
    static java.util.Set<java.lang.Long> getAttributeListFromFormulaJson(java.lang.String);
    static java.util.Set<java.lang.Long> getAttributeListFromFormula(com.seeyon.boot.starter.formula.dto.ExpressionDefinitionDto);
    static java.lang.Long findLastEntityId(java.util.List<com.seeyon.boot.starter.formula.dto.param.EntityRuleParamResolveBo>);
    static java.util.Set<java.lang.Long> getAllEntityIdSet(java.util.List<java.util.List<com.seeyon.boot.starter.formula.dto.param.EntityRuleParamResolveBo>>);
    static java.util.Map<java.lang.String, java.lang.String> resolveField(com.seeyon.boot.starter.formula.dto.ExpressionDefinitionDto);
    static boolean isOldValueContext(com.seeyon.boot.starter.formula.dto.variable.SchemaStructureDto);
```

### `ResponseUtils`（15 方法）

`com.seeyon.udc.common.utils.ResponseUtils`

```java
    static <T> java.util.Optional<T> ofNullable(com.seeyon.boot.transport.SingleResponse<T>);
    static <T, X extends java.lang.Throwable> T requireNonNull(com.seeyon.boot.transport.SingleResponse<T>, java.util.function.Supplier<? extends X>)
    static <T> java.util.Optional<java.util.List<T>> ofNullable(com.seeyon.boot.transport.ListResponse<T>);
    static <T, X extends java.lang.Throwable> java.util.List<T> requireNonNull(com.seeyon.boot.transport.ListResponse<T>, java.util.function.Supplier<? extends X>)
    static <T> java.util.Optional<com.seeyon.boot.transport.PageData<T>> ofNullable(com.seeyon.boot.transport.PageResponse<T>);
    static <T, X extends java.lang.Throwable> com.seeyon.boot.transport.PageData<T> requireNonNull(com.seeyon.boot.transport.PageResponse<T>, java.util.function.Supplier<? extends X>)
    static <T> T responseResolve(com.seeyon.boot.transport.SingleResponse<T>, java.lang.String);
    static <T> java.util.List<T> listResponseResolve(com.seeyon.boot.transport.ListResponse<T>, java.lang.String);
    static <T> java.util.List<T> pageResponseResolve(com.seeyon.boot.transport.PageResponse<T>, java.lang.String);
    static com.seeyon.boot.transport.BaseResponse checkResponse(com.seeyon.boot.transport.BaseResponse, java.lang.Class<? extends com.seeyon.boot.transport.BaseResponse>, java.lang.String);
    static private static com.seeyon.boot.transport.BaseResponse getResponseInstance(java.lang.Class<? extends com.seeyon.boot.transport.BaseResponse>);
    static void checkResponse(com.seeyon.boot.transport.BaseResponse, java.lang.String);
```

### `AppLogConfigDto`（14 方法）

`com.seeyon.udc.common.dto.AppLogConfigDto`

```java
    boolean isSandbox();
    java.lang.String getAppName();
    boolean isLogEnabled();
    java.lang.Long getDefaultExpireTime();
    java.lang.Long getExpireTime();
    void setSandbox(boolean);
    void setAppName(java.lang.String);
    void setLogEnabled(boolean);
    void setDefaultExpireTime(java.lang.Long);
    void setExpireTime(java.lang.Long);
    boolean equals(java.lang.Object);
    protected boolean canEqual(java.lang.Object);
    int hashCode();
    java.lang.String toString();
```

### `ClassUtils`（13 方法）

`com.seeyon.udc.common.utils.ClassUtils`

```java
    static boolean isBoolean(java.lang.Class<?>);
    static boolean isProxy(java.lang.Class<?>);
    static java.lang.Class<?> getUserClass(java.lang.Class<?>);
    static java.lang.Class<?> getUserClass(java.lang.Object);
    static <T> T newInstance(java.lang.Class<T>);
    static <T> T newInstance(java.lang.String);
    static java.lang.Class<?> toClassConfident(java.lang.String);
    static java.lang.Class<?> toClassConfident(java.lang.String, java.lang.ClassLoader);
    static private static java.lang.Class<?> loadClass(java.lang.String, java.lang.ClassLoader[])
    static java.lang.String getPackageName(java.lang.Class<?>);
    static java.lang.String getPackageName(java.lang.String);
    static java.lang.ClassLoader getDefaultClassLoader();
    static private static java.lang.ClassLoader[] getClassLoaders(java.lang.ClassLoader);
```

### `AttributeUtil`（12 方法）

`com.seeyon.udc.common.utils.AttributeUtil`

```java
    static boolean isEncryptionAttr(com.seeyon.udc.common.dto.DataFlowAttributeDto);
    static void setAttributeMappingProp(com.seeyon.udc.common.dto.DataFlowAttributeDto);
    static boolean needChangeDataType(com.seeyon.udc.common.dto.DataFlowAttributeDto, com.seeyon.udc.common.dto.DataFlowAttributeDto);
    static boolean dbEnumMapping2MultiDbEnum(com.seeyon.udc.common.dto.DataFlowAttributeDto, com.seeyon.udc.common.dto.DataFlowAttributeDto);
    static private static com.seeyon.udc.common.datatype.CommonDataTypes getDataTypes();
    static java.lang.Integer getI18nAttrMaxLength(java.lang.String);
    static java.lang.Integer getI18nAttrMinLength(java.lang.String);
    static boolean isAttributeSetAttribute(com.seeyon.udc.common.dto.AttributeDto);
    static boolean isEntityAttribute(com.seeyon.udc.common.dto.AttributeDto);
```

### `DataConvertUtil`（12 方法）

`com.seeyon.udc.common.utils.DataConvertUtil`

```java
    static java.lang.Class getClass(java.lang.String);
    static java.lang.String getDtoFullName(java.lang.Object, java.lang.String);
    static java.util.List<java.lang.reflect.Field> getAllField(com.seeyon.udc.common.dto.BaseEntityActionDto);
    static java.lang.Object getFieldValue(java.lang.String, java.lang.Object);
    static void setFieldValue(java.lang.Object, java.lang.String, java.lang.Class, java.lang.Object);
    static java.lang.Object setNullValue4Formula(java.lang.Object, java.lang.Object, java.util.List<java.lang.String>);
    static java.math.BigDecimal string2BigDecimal(java.lang.String);
    static java.lang.Long string2Long(java.lang.String);
    static java.lang.Integer string2Integer(java.lang.String);
    static java.lang.Boolean validityCheck4BigDecimal(java.lang.Object, java.lang.Object);
    static java.lang.Boolean validityCheck4Long(java.lang.Object, java.lang.Object);
    static java.lang.Boolean validityCheck4Integer(java.lang.Object, java.lang.Object);
```

### `DtoCodeUtil`（11 方法）

`com.seeyon.udc.common.utils.DtoCodeUtil`

```java
    static java.lang.String handleEntityName4Dto(java.lang.String);
    static java.lang.String handleCapEntityName4Dto(java.lang.String);
    static java.lang.String handleAttributeName4Dto(java.lang.String);
    static java.lang.String handleCapAttributeName4Dto(java.lang.String);
    static java.lang.String handleOneToOneEntityName4Dto(java.lang.String);
    static java.lang.String handleOneToOneCapEntityName4Dto(java.lang.String);
    static java.lang.String handleOneToManyEntityName4Dto(java.lang.String);
    static java.lang.String handleOneToManyCapEntityName4Dto(java.lang.String);
    static java.lang.String getDtoNameByEntityName(java.lang.String);
    static java.lang.String getUncapDtoNameByEntityName(java.lang.String);
    static java.lang.String getCapDtoNameByEntityName(java.lang.String);
```

### `FullNameCommonUtil`（11 方法）

`com.seeyon.udc.common.utils.FullNameCommonUtil`

```java
    static java.lang.String subStartLastDot(java.lang.String);
    static java.lang.String subUntilLastDot(java.lang.String);
    static java.lang.String getDtoNameByFullName(java.lang.String);
    static java.lang.String getConnectorDtoName(java.lang.String);
    static java.lang.String getConnectorEnumName(java.lang.String);
    static java.lang.String getDynamicDependencyDtoFullName(java.lang.String, java.lang.String);
    static java.lang.String getDynamicDependencyEnumFullName(java.lang.String, java.lang.String);
    static java.lang.String getBasePackage(com.seeyon.boot.starter.extmetadata.dto.UdcApplicationMetaDataDto);
    static protected static java.lang.String getUdcEnumFullName(java.lang.String, java.lang.String, java.lang.String);
    static protected static java.lang.String completeModuleNameAsPackageName(java.lang.String);
    static private static java.lang.String get62SystemMd5(java.lang.String);
```

### `RequestUtils`（10 方法）

`com.seeyon.udc.common.concurrent.RequestUtils`

```java
    <T> void requestAsync(java.lang.String, java.util.concurrent.Callable<T>);
    <T> void requestAsync(java.lang.String, long, java.util.concurrent.Callable<T>);
    <T> void requestAsync(java.lang.String, long, java.util.concurrent.Callable<T>, java.util.function.Consumer<com.seeyon.udc.common.concurrent.RequestStatusDto>);
    com.seeyon.udc.common.concurrent.RequestStatusDto getRequestStatus(java.lang.String);
    static java.lang.String getRequestKey(java.lang.String);
    private java.util.concurrent.locks.Lock getDistributedLock(java.lang.String);
    <T> com.seeyon.udc.common.concurrent.RequestStatusDto complete(T);
    com.seeyon.udc.common.concurrent.RequestStatusDto exception(java.lang.String);
    com.seeyon.udc.common.concurrent.RequestStatusDto processing();
```

### `WidgetConfigDto`（10 方法）

`com.seeyon.udc.common.dto.WidgetConfigDto`

```java
    void setPc(java.lang.String);
    void setMobile(java.lang.String);
    void setList(java.lang.Boolean);
    void setDetail(java.lang.Boolean);
    void setQuickSearch(java.lang.Boolean);
    java.lang.String getPc();
    java.lang.String getMobile();
    java.lang.Boolean getList();
    java.lang.Boolean getDetail();
    java.lang.Boolean getQuickSearch();
```

### `EntityDataSourceUtil`（10 方法）

`com.seeyon.udc.common.utils.EntityDataSourceUtil`

```java
    static void mergeRuntimeEntityDataSourceDto(com.seeyon.udc.common.dto.datasource.RuntimeEntityDataSourceDto, java.util.List<com.seeyon.udc.common.dto.datasource.RuntimeEntityDataSourceDto>);
    static java.util.List<com.seeyon.udc.common.dto.datasource.RuntimeEntityDataSourceDto> mergeRelationalDataSource(java.util.List<com.seeyon.udc.common.dto.datasource.RuntimeEntityDataSourceDto>, java.util.List<com.seeyon.udc.common.dto.datasource.RuntimeEntityDataSourceDto>);
    static void mergeRuntimeDataSourceEntityInfo(com.seeyon.udc.common.dto.datasource.RuntimeDataSourceEntityInfoDto, com.seeyon.udc.common.dto.datasource.RuntimeDataSourceEntityInfoDto);
    static com.seeyon.udc.common.dto.datasource.RuntimeDataSourceAssAttributeInfoDto mergeRuntimeAssAttributeInfoDto(java.util.Map<java.lang.String, com.seeyon.udc.common.dto.datasource.RuntimeDataSourceAssAttributeInfoDto>, com.seeyon.udc.common.dto.datasource.RuntimeDataSourceAssAttributeInfoDto);
```

### `UdcApplicationDependentMetadata4OssService`（9 方法）

`com.seeyon.udc.common.metadata.oss.UdcApplicationDependentMetadata4OssService`

```java
    java.util.List<com.seeyon.udc.common.dto.DependentApplicationDto> selectByName(java.lang.String);
    java.util.Map<java.lang.String, java.lang.String> selectFrontendDependent(com.seeyon.boot.starter.extmetadata.dto.request.UdcMetaDataSearchDto);
    private java.lang.String readFrontDependentJson(java.lang.String);
    private java.lang.String readJsonFromStorage(java.lang.String);
    private java.lang.String readJsonByHttp(java.lang.String, java.lang.String);
    private java.lang.String readJsonByFile(java.lang.String, java.lang.String);
    private java.lang.String readJsonForMonolithic(java.lang.String);
```

### `UdcStringUtils`（9 方法）

`com.seeyon.udc.common.utils.UdcStringUtils`

```java
    static java.lang.String removeSplit(java.lang.String);
    static java.lang.String camelWithSplit(java.lang.String, java.lang.String);
    static java.lang.String camelToSpine(java.lang.String);
    static java.lang.String pastFormat(java.util.List<java.lang.String>);
    static java.lang.String generateSerialVersionUuid();
    static boolean isNumber(java.lang.String);
    static boolean checkVersion(java.lang.String, java.lang.String);
    static boolean isValidVersion(java.lang.String);
    static java.lang.String increaseVersion(java.lang.String);
```

### `UdcEntityMetadata4OssService`（8 方法）

`com.seeyon.udc.common.metadata.oss.UdcEntityMetadata4OssService`

```java
    java.util.List<com.seeyon.udc.common.dto.EntityDto> selectEntityItemByAppName(java.lang.String);
    java.util.List<com.seeyon.udc.common.dto.EntityDto> selectEntitiesByAppName(java.lang.String);
    private void resolveEntityFullName(com.seeyon.udc.common.dto.ApplicationDto, java.util.List<com.seeyon.udc.common.dto.EntityDto>);
    private void resolveAttributeFullName(com.seeyon.udc.common.dto.ApplicationDto, java.util.List<com.seeyon.udc.common.dto.EntityDto>, java.util.List<com.seeyon.udc.common.dto.AttributeDto>);
    static java.lang.String getEntityFullNamePrefix(com.seeyon.udc.common.dto.ApplicationDto);
    static private static java.lang.String getEntity4DtoFullNamePrefix(com.seeyon.udc.common.dto.ApplicationDto);
    static private static java.lang.String getJavaBasePackage(com.seeyon.udc.common.dto.ApplicationDto);
```

### `DecimalDataTypeHelper`（7 方法）

`com.seeyon.udc.common.datatype.helper.DecimalDataTypeHelper`

```java
    int getDatabaseDataType(com.seeyon.udc.common.dto.BaseUdcAttributeDto);
    java.lang.String getJavaType(com.seeyon.udc.common.dto.BaseUdcAttributeDto);
    int getLength(com.seeyon.udc.common.dto.BaseUdcAttributeDto);
    int getDatabaseDataType(com.seeyon.boot.starter.extmetadata.dto.UdcAttributeMetaDataDto);
    java.lang.String getJavaType(com.seeyon.boot.starter.extmetadata.dto.UdcAttributeMetaDataDto);
    int getLength(com.seeyon.boot.starter.extmetadata.dto.UdcAttributeMetaDataDto);
    int getDefaultMaxLength(com.seeyon.udc.common.dto.BaseUdcAttributeDto);
```

### `TreeNodeUtil`（7 方法）

`com.seeyon.udc.common.utils.TreeNodeUtil`

```java
    static <T extends com.seeyon.udc.common.dto.BaseTreeDto> java.util.List<T> fastBuildTree(java.util.List<T>, java.util.function.Function<T, java.lang.Long>);
    static <T extends com.seeyon.udc.common.dto.BaseTreeDto> java.util.List<T> fastBuildTree(java.util.List<T>, java.util.function.Function<T, java.lang.Long>, java.lang.Long);
```

### `DefaultTypeHelper`（6 方法）

`com.seeyon.udc.common.datatype.DefaultTypeHelper`

```java
    int getDatabaseDataType(com.seeyon.udc.common.dto.BaseUdcAttributeDto);
    java.lang.String getJavaType(com.seeyon.udc.common.dto.BaseUdcAttributeDto);
    int getLength(com.seeyon.udc.common.dto.BaseUdcAttributeDto);
    int getDatabaseDataType(com.seeyon.boot.starter.extmetadata.dto.UdcAttributeMetaDataDto);
    java.lang.String getJavaType(com.seeyon.boot.starter.extmetadata.dto.UdcAttributeMetaDataDto);
    int getLength(com.seeyon.boot.starter.extmetadata.dto.UdcAttributeMetaDataDto);
```

### `AppConfigChangeListener`（6 方法）

`com.seeyon.udc.common.listener.AppConfigChangeListener`

```java
    void onAppLogMessage(org.springframework.data.redis.connection.Message, byte[]);
    private void onAppDataMonitorLogMessage(org.springframework.data.redis.connection.Message, byte[]);
    void registerAppConfigChangeListener();
    void afterPropertiesSet()
```

### `DynamicDependencyUtil`（6 方法）

`com.seeyon.udc.common.utils.DynamicDependencyUtil`

```java
    static boolean isFormNormal(com.seeyon.udc.common.dto.DependentApplicationDto);
    static java.lang.String convertDynamicDependencyDtoFullName(java.lang.String, java.lang.String);
    static java.lang.String convertDynamicDependencyAppServiceFullName(java.lang.String, java.lang.String, java.lang.String);
    static java.lang.String getDynamicDependencyAppServiceName(java.lang.String);
    static java.lang.String convertDynamicDependencyEnumFullName(java.lang.String, java.lang.String);
    static boolean isDynamicDependencyFullName(java.lang.String, java.util.Set<java.lang.String>, com.seeyon.udc.common.dto.ApplicationDto);
```

### `UdcJsonUtils`（6 方法）

`com.seeyon.udc.common.utils.UdcJsonUtils`

```java
    static <T> T fromJson(java.lang.String, java.lang.Class<T>);
    static java.lang.String toJson(java.lang.Object);
    static java.util.List toList(java.lang.String);
    static <T> java.util.List<T> toList(java.lang.String, java.lang.Class<T>);
    static java.util.Map<java.lang.String, java.lang.Object> toMap(java.lang.String);
    static private static com.seeyon.boot.exception.BusinessException newBusinessException(java.lang.String, java.lang.Throwable);
```

### `CompletionExecutor`（5 方法）

`com.seeyon.udc.common.concurrent.CompletionExecutor`

```java
    java.util.concurrent.Future<T> submit(com.seeyon.udc.common.concurrent.NamedFutureTask<T>);
    java.util.concurrent.Future<T> submitMiddle(com.seeyon.udc.common.concurrent.NamedFutureTask<T>);
    java.util.concurrent.Future<T> submitHigh(com.seeyon.udc.common.concurrent.NamedFutureTask<T>);
    void waitTimeout();
    private void cancel();
```

### `TypeConverterSingleCase`（5 方法）

`com.seeyon.udc.common.datatype.convert.TypeConverterSingleCase`

```java
    java.lang.Object convert(java.lang.String, java.lang.String, java.lang.Object);
    java.util.Set<java.lang.String> getSourceTypesByTargetType(com.seeyon.udc.common.datatype.UdcDataType);
    java.util.Map<com.seeyon.udc.common.datatype.UdcDataType, java.util.Set<java.lang.String>> getSourceTypesByTargetTypes(java.util.Set<com.seeyon.udc.common.datatype.UdcDataType>);
    private java.util.Map<java.lang.String, com.seeyon.udc.common.datatype.convert.BaseConverter> getOriginalConverterMap();
    void init();
```

### `AppNameUtil`（5 方法）

`com.seeyon.udc.common.utils.AppNameUtil`

```java
    static java.lang.String getAppNameByDtoFullName(java.lang.String);
    static java.lang.String getAppNameByDomainPackage(java.lang.String);
    static java.lang.String getAppNameByEntityFullName(java.lang.String);
    static java.lang.String getAppNameByArgs(java.lang.Object[]);
    static java.lang.String getAppNameByTarget(java.lang.Object);
```

### `ExprEntityDataTypeUtil`（5 方法）

`com.seeyon.udc.common.utils.ExprEntityDataTypeUtil`

```java
    static boolean supportExpr(java.lang.String);
    static boolean isBasicType(java.lang.String);
    static boolean isEntityType(java.lang.String);
    static boolean isEnumType(java.lang.String);
    static boolean isJavaEnumType(java.lang.String);
```

### `UdcI18nUtils`（5 方法）

`com.seeyon.udc.common.utils.UdcI18nUtils`

```java
    static private static void init();
    static java.lang.String getEnumItemMessage(java.lang.String, java.lang.String);
    static java.lang.String getMetadataMessage(java.lang.String, java.lang.String);
    static java.lang.String getMetadataMessage(java.lang.String, java.lang.String, java.lang.String);
    static java.lang.String getErrorMsgByErrorCode(java.lang.String);
```

### `DbUtils`（4 方法）

`com.seeyon.udc.common.utils.DbUtils`

```java
    static java.lang.String getDbTableName(com.seeyon.udc.common.dto.ApplicationDto, com.seeyon.udc.common.dto.EntityBaseDto);
    static java.lang.String getColumnName(java.lang.String);
    static com.seeyon.boot.domain.dao.support.DatabaseType getDatabaseType(javax.sql.DataSource);
    static void checkTableNameByRule(java.lang.String, javax.sql.DataSource);
```

### `CustomPlanFeatureHandlerFacade`（3 方法）

`com.seeyon.udc.common.customplan.CustomPlanFeatureHandlerFacade`

```java
    boolean pageSupportCustomPlan(com.seeyon.boot.starter.extmetadata.dto.UdcPageMetadataV2Dto);
    void afterPropertiesSet()
    private com.seeyon.udc.common.customplan.handler.CustomPlanPageFeatureHandler getCustomPlanFeatureHandler(java.lang.String);
```

### `UdcAttributeMetadata4OssService`（3 方法）

`com.seeyon.udc.common.metadata.oss.UdcAttributeMetadata4OssService`

```java
    java.util.List<com.seeyon.udc.common.dto.AttributeDto> selectByAppName(java.lang.String);
    java.util.List<com.seeyon.udc.common.dto.AttributeDto> selectByEntityIds(java.lang.String, java.util.List<java.lang.Long>);
```

### `NumberConversionUtil`（3 方法）

`com.seeyon.udc.common.utils.NumberConversionUtil`

```java
    static java.lang.String getBinaryCode(byte);
    static java.lang.String get62(byte[]);
    static private static void get62StringBuilder(java.math.BigInteger, java.lang.StringBuilder);
```

### `OutAppAppServiceProxyUtil`（3 方法）

`com.seeyon.udc.common.utils.OutAppAppServiceProxyUtil`

```java
    static java.lang.String getAppServiceProxyPackage(java.lang.String, java.lang.String);
    static java.lang.String getAppServiceProxyFullName(java.lang.String, java.lang.String, java.lang.String);
    static java.lang.String getAppServiceProxyName(java.lang.String);
```

## 三、注解（1）

| 注解 | 元素 |
|---|---|
| `TypeMapping` | sourceType, targetType, isFormulaResult |

## 四、枚举（64）

- `RequestStatusEnum`（4 常量）：PROCESSING, COMPLETE, EXCEPTION, TIMEOUT
- `ComponentSourceTypeEnum`（3 常量）：INNER, CUSTOMIZE, THIRD_PARTY
- `AppStateEnum`（5 常量）：NONE, STOP, RUNNING, PENDING, FAILED
- `ApplicationFeatureEnum`（6 常量）：STANDARD, BUSINESS, FORM, ONLYPAGE, INTEGRATION, LAYOUT
- `ApplicationSourceEnum`（2 常量）：NORMAL, FORM
- `ArtifactSourceEnum`（3 常量）：DEFAULT, MAVEN, OSS
- `AttributeActionType`（4 常量）：ADD, UPDATE, DELETE, DEFAULT
- `AttributeSetSourceTypeEnum`（3 常量）：UDC, ISV, APP
- `CreationMethodEnum`（3 常量）：MANUAL, FROM_TEMPLATE, PAGE_LAYOUT
- `DataFlowFixedValueTypeEnum`（2 常量）：CONSTANT, SYSTEM_VARIABLE
- `DataFlowLogActionTypeEnum`（17 常量）：START, FILTER_EVENT, FILTER_WRITE_BACK_EVENT, FILTER_SOURCE_ENTITY, QUERY_SOURCE_DATA, QUERY_TARGET_DATA, FLAT_SOURCE_DATA, FLAT_TARGET_DATA, GROUP_SOURCE_DATA, ROW_CONDITION, ASSEMBLE_TARGET_DATA, CREATE_TARGET_DATA …
- `DataFlowOperationTypeEnum`（3 常量）：CREATE, UPDATE, CREATE_OR_UPDATE
- `DataNotFoundStrategyEnum`（2 常量）：ERROR, SKIP
- `DataSourceTypeEnum`（5 常量）：ENTITY, FILTER, REFER, REFER_CARRY, _PAGE_RELATIVE_ENTITY
- `DataTypeCategoryEnum`（3 常量）：PRIMITIVE, COMPOSITE, ENUM
- `DataTypeDefaultComponentEnum`（19 常量）：STRING, MULTILINESTRING, INTEGER, BIGINTEGER, DECIMAL, CURRENCY, DATE, TIME, DATETIME, BOOLEAN, ENUM, CTPENUM …
- `DataTypePropertiesCheckEnum`（4 常量）：ENTITY, CTP_ENUM, ENUM, ATTACHMENT
- `DeductionAlgorithmOperatorEnum`（2 常量）：PLUS_EQUAL, SUBTRACT_EQUAL
- `DeductionFieldTypeEnum`（5 常量）：BILL_STATUS, BILL_CATEGORY, SECONDARY_FIELD_SUSPEND, SECONDARY_FIELD_TERMINATE, SECONDARY_FIELD_INVALID
- `DeductionLogActionTypeEnum`（8 常量）：START, DETERMINE_EXECUTE, FLAT_SOURCE_DATA, QUERY_DEDUCTION_TARGET_DATA, CHECK_ALGORITHM, DO_ALGORITHM, UNDO_ALGORITHM, END
- `DeductionSearchMethodTypeEnum`（2 常量）：EQUAL, CONSTANT
- `DeductionStartStateEnum`（3 常量）：ON, OFF, DRAFT
- `DeployBusinessTypeEnum`（6 常量）：STANDARD, REPUBLISH, UPGRADE, ON_ONLINE, DELTA, FORM_CROSS_ENV_PUSH
- `DeployStateEnum`（4 常量）：UNPUBLISHED, PUBLISHING, SUCCESS, FAIL
- `DeployTypeEnum`（4 常量）：TEST, RELEASE, ON_ONLINE, DELTA
- `DesignStateEnum`（2 常量）：DESIGN, RUNTIME
- `ElementTypeEnum`（11 常量）：ALL, BASIC, ATTRIBUTE, RULE, REFER, EVENT, INDEX, PAGE_SCHEMA, IN_PARAMS, IN_PORTLET_PARAMS, FILTER_PLAN
- `EntityRuntimeLogStepTypeEnum`（28 常量）：beginCreateLog, resetInsertAndOrderNoLog, beginPreCreateBatchLog, endePreCreateBatchLog, beforeCreateLog, beginBeforeEventLog, endBeforeEventLog, middleCreateLog, endCreateLog, beginCreate4BpmLog, beginAfterApprovalCreateLog, endAfterApprovalCreateLog …
- `ExpressionElementTypeEnum`（3 常量）：FIELD, CONDITIONAL, LOGIC
- `GroupTypeEnum`（4 常量）：DEFAULT, VALIDATE, ASSIGN_VALUE, DEFAULT_VALUE
- `GroupingFieldDataTypeEnum`（1 常量）：ATTACHMENT
- `IndexSourceEnum`（3 常量）：SYSTEM_PRESET, MANUAL_CREATE, ATTRIBUTE_UNIQUE
- `IndexTypeEnum`（2 常量）：NORMAL, UNIQUE
- `InnerPageComponentEnum`（68 常量）：UDC_GRID_PC, Udc_Container_PC, COLLAPSE_PC, TABS_PC, UDC_PANEL_PC, UDC_SUB_PAGE_PC, UDC_PLACEHOLDER_PC, UDC_GRID_MOBILE, Udc_Container_MOBILE, COLLAPSE_MOBILE, TABS_MOBILE, UDC_PLACEHOLDER_MOBILE …
- `LogModuleEnum`（4 常量）：MICRO_FLOW, DATA_FLOW, DEDUCTION, ENTITY
- `LogicOperationEnum`（2 常量）：AND, OR
- `MappingModeCategoryEnum`（4 常量）：FIELD, FIXED_VALUE, FORMULA, GROUPING_FUNCTION
- `MicroFlowActivityTypeEnum`（102 常量）：CONNECTOR, CREATE_VARIABLE, CHANGE_VARIABLE, CREATE_LIST, CHANGE_LIST, PUBLISH_BUSINESS_EVENT, ATTRIBUTE_REQUIRED, ASSIGN_VALUE, SHOW_MESSAGE, ATTRIBUTE_UNIQUE, RETRIEVE, RETRIEVE_ARRAY …
- `MicroFlowDataStateEnum`（2 常量）：DRAFT, RELEASE
- `MicroFlowLastVersionMetadataStateEnum`（2 常量）：DISABLED, ENABLED
- `MicroFlowOpenApiStateTypeEnum`（2 常量）：STOP, SYNC
- `MicroFlowRestApiStateEnum`（2 常量）：DISABLED, ENABLED
- `MicroFlowTriggerTypeEnum`（4 常量）：BUSINESS_EVENT, SCHEDULE, MANUAL, FRONTEND_PARAM
- `MicroFlowTypeEnum`（5 常量）：SERVICE, FRONTEND, ENTITY_RULE, CUSTOM, FUNCTION
- `ModuleSubTypeEnum`（6 常量）：MICRO_FLOW_MANUAL, MICRO_FLOW_FRONTEND, MICRO_FLOW_ENTITY_RULE, MICRO_FLOW_BUSINESS_EVENT, MICRO_FLOW_SCHEDULE, MICRO_FLOW_FUNCTION
- `ModuleTypeEnum`（32 常量）：ENTITY, CONNECTOR, MICRO, PAGE, DATA_FLOW, UDC_CDP_DATA_STREAM, UDC_CDP_DATA_MODEL, UDC_CDP_DATA_REPORT, UDC_BPM_PROCESS, UDC_CDP_DATA_ATOM, UDC_CDP_DATA_DERIVE, UDC_CDP_DATA_TABLE …
- `OpenStateEnum`（3 常量）：EDIT, VIEW, INPUT
- `PageNavTypeEnum`（5 常量）：PAGE, MENU_PAGE, UDC_CDP_DATA_REPORT, THIRD_RESOURCE, SPACE_MENU
- `PageSchemaStateEnum`（6 常量）：NONE, EMPTY, DRAFT, FORMAL, CUSTOMIZE, REFERENCE
- `ProjectTypeEnum`（3 常量）：FRONTEND, BACKEND, ALL
- `PublishStateEnum`（2 常量）：PUBLISHED, UNPUBLISH
- `ReferConfigSourceTypeEnum`（2 常量）：ENTITY, BASIC_DATA
- `RuntimeModifyStateEnum`（2 常量）：ON, OFF
- `SearchOperationEnum`（16 常量）：EQ, NEQ, GT, LT, GE, LE, LLIKE, RLIKE, LIKE, NOTLIKE, IN, NOTIN …
- `SourceDataTypeEnum`（4 常量）：SELECT, CONDITION, EVENT_DATA, SELECT_PARAM
- `TerminalTypeEnum`（3 常量）：ALL, PC, MOBILE
- `TriggerPointEnum`（2 常量）：MANUALLY, EVENT_SUBSCRIBE
- `UdcControlResourceActionEnum`（4 常量）：basic, readonly, disabled, invisible
- `UdcDataStateEnum`（2 常量）：DRAFT, RELEASE
- `UdcEnumTypeEnum`（3 常量）：DEFAULT, CONNECTOR, DYNAMIC_DEPENDENCY
- `UdcNodeTypeEnum`（5 常量）：MENU, PAGE, REPORT, EXT_LINK, PORTAL_SPACE
- `UsageStateEnum`（3 常量）：ON, OFF, SYSTEM_OFF
- `ValidationTypeEnum`（2 常量）：ENVIRONMENT, PACKAGE
- `VersionTypeEnum`（2 常量）：RELEASE, SNAPSHOT
