# boot-starter-spi：接口与方法签名

> 自动生成，勿手改。`tools/core/platform/emit_package_surfaces.py` 重跑即可。
> 构件 `com.seeyon:boot-starter-spi`（jar `boot-starter-spi-5.3.600.jar`）
> 规模：12 类 / 1 接口 / 0 注解 / 0 枚举 / 1 个关键类 / 52 方法。
> 签名逐字来自 javap 原文；已去掉 `public` 前缀与 `throws` 子句。

## 一、接口（1）

### `SpiArtifactService`（1 方法）

`com.seeyon.boot.starter.spi.plugin.SpiArtifactService`

```java
    java.lang.String download(com.seeyon.boot.starter.spi.plugin.ArtifactInfo);
```

## 二、关键类（1）

### `SpiMavenService`（6 方法）

`com.seeyon.boot.starter.spi.plugin.maven.SpiMavenService`

```java
    java.lang.String download(com.seeyon.boot.starter.spi.plugin.ArtifactInfo);
    private org.eclipse.aether.repository.RemoteRepository getRemoteRepository(java.lang.String);
    void afterPropertiesSet()
    private org.eclipse.aether.RepositorySystem getRepositorySystem();
    private org.eclipse.aether.RepositorySystemSession getSession(org.eclipse.aether.RepositorySystem, java.lang.String);
    private java.lang.String getMvnBasePath();
```
