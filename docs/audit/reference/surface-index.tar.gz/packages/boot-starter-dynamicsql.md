# boot-starter-dynamicsql：接口与方法签名

> 自动生成，勿手改。`tools/core/platform/emit_package_surfaces.py` 重跑即可。
> 构件 `com.seeyon:boot-starter-dynamicsql`（jar `boot-starter-dynamicsql-5.3.600.jar`）
> 规模：42 类 / 5 接口 / 0 注解 / 1 枚举 / 7 个关键类 / 381 方法。
> 签名逐字来自 javap 原文；已去掉 `public` 前缀与 `throws` 子句。

## 一、接口（5）

### `DynamicSelectMapper`（1 方法）

`com.seeyon.boot.starter.dynamicsql.mapper.DynamicSelectMapper`

```java
    java.util.List<java.util.Map<java.lang.String, java.lang.Object>> dynamicSelectPageByConditions(com.seeyon.boot.transport.PageInfo, java.lang.String, com.seeyon.boot.transport.Sort, java.util.Map<java.lang.String, java.lang.Object>);
```

### `DateParser`（1 方法）

`com.seeyon.boot.starter.dynamicsql.oracle.DateParser`

```java
    default java.lang.Object parser(java.lang.Object);
```

### `DynamicSqlParameterDataParser`（1 方法）

`com.seeyon.boot.starter.dynamicsql.util.DynamicSqlParameterDataParser`

```java
    java.lang.Object dataParser(java.lang.Class<?>, java.lang.Object, java.lang.String, java.lang.Class<?>);
```

### `DynamicSqlReturnDataParser`（1 方法）

`com.seeyon.boot.starter.dynamicsql.util.DynamicSqlReturnDataParser`

```java
    java.lang.Object dataParser(java.lang.Class<?>, java.lang.Object, java.lang.String, java.lang.Class<?>);
```

### `DynamicSelectDao`（0 方法）

`com.seeyon.boot.starter.dynamicsql.domain.dao.DynamicSelectDao`

```java
```

## 二、关键类（7）

### `DynamicSelectService`（69 方法）

`com.seeyon.boot.starter.dynamicsql.appservice.DynamicSelectService`

```java
    com.seeyon.boot.transport.PageData<java.lang.String> dynamicJoinSelect(com.seeyon.boot.transport.PageInfo, com.seeyon.boot.starter.dynamicsql.dto.MainConditionDto, com.seeyon.boot.transport.Sort, com.seeyon.boot.starter.dynamicsql.dto.DynamicConditionDto);
    com.seeyon.boot.transport.PageResponse<java.lang.Object> dynamicJoinSelectObject(com.seeyon.boot.transport.PageInfo, com.seeyon.boot.starter.dynamicsql.dto.MainConditionDto, com.seeyon.boot.transport.Sort, com.seeyon.boot.starter.dynamicsql.dto.DynamicConditionDto);
    com.seeyon.boot.transport.PageResponse<java.lang.Object> dynamicJoinSelectObject(com.seeyon.boot.transport.PageInfo, com.seeyon.boot.starter.dynamicsql.dto.MainConditionDto, com.seeyon.boot.transport.Sort, com.seeyon.boot.starter.dynamicsql.dto.DynamicConditionDto, java.lang.Boolean);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> dynamicJoinSelectCountObject(com.seeyon.boot.transport.PageInfo, com.seeyon.boot.starter.dynamicsql.dto.MainConditionDto, com.seeyon.boot.transport.Sort, com.seeyon.boot.starter.dynamicsql.dto.DynamicConditionDto);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> dynamicJoinSelectCountObject(com.seeyon.boot.transport.PageInfo, com.seeyon.boot.starter.dynamicsql.dto.MainConditionDto, com.seeyon.boot.transport.Sort, com.seeyon.boot.starter.dynamicsql.dto.DynamicConditionDto, java.lang.Boolean);
    private com.seeyon.boot.starter.mybatis.page.MyBatisPageInfo<java.util.Map<java.lang.String, java.lang.Object>> selectByConditionDynamic(com.seeyon.boot.transport.PageInfo, com.seeyon.boot.starter.dynamicsql.dto.MainConditionDto, com.seeyon.boot.transport.Sort, com.seeyon.boot.starter.dynamicsql.dto.DynamicConditionDto, java.lang.Boolean);
    private java.lang.String map2Json(com.seeyon.boot.starter.mybatis.page.MyBatisPageInfo<java.util.Map<java.lang.String, java.lang.Object>>, com.seeyon.boot.starter.dynamicsql.dto.MainConditionDto);
    void entityCacheClear();
    void dtoCacheClear();
    void unloadDynamicCode(java.lang.String, java.lang.String);
    void unloadModuleApp(com.seeyon.boot.loader.ModuleAppLoadEvent);
    void unloadDynamicApp(com.seeyon.boot.loader.SeeyonURLClassLoader);
    void onApplicationEvent(com.seeyon.boot.event.ModuleUnloadEvent);
    private void addSkipCache(java.lang.String, java.lang.String);
    java.lang.Object fieldParse(java.lang.Object, java.lang.String, java.lang.String);
    private java.util.List<java.lang.Object> map2Object(com.seeyon.boot.starter.mybatis.page.MyBatisPageInfo<java.util.Map<java.lang.String, java.lang.Object>>, com.seeyon.boot.starter.dynamicsql.dto.MainConditionDto);
    private void childrenMap2Json(java.util.Map<java.lang.String, java.lang.Object>, java.util.Map<java.lang.String, java.lang.Object>, com.seeyon.boot.starter.dynamicsql.dto.ChildrenConditionDto, java.util.Map<java.lang.Object, java.lang.Object>, java.lang.String);
    java.lang.String toLowerCaseFirstOne(java.lang.String);
    private java.lang.String buildSql(com.seeyon.boot.starter.dynamicsql.dto.MainConditionDto, com.seeyon.boot.transport.Sort, com.seeyon.boot.starter.dynamicsql.dto.DynamicConditionDto, java.util.Map<java.lang.String, java.lang.Object>, com.seeyon.boot.transport.PageInfo);
    private java.lang.String buildSqlSelect(com.seeyon.boot.starter.dynamicsql.dto.MainConditionDto);
    private void buildSqlSelectForChildren(com.seeyon.boot.starter.dynamicsql.dto.ChildrenConditionDto, java.util.List<java.lang.String>);
    private java.lang.String buildSqlJoinList(com.seeyon.boot.starter.dynamicsql.dto.MainConditionDto);
    private java.lang.String buildSqlJoinListForChildren(com.seeyon.boot.starter.dynamicsql.dto.ChildrenConditionDto, java.lang.String);
    boolean permissionCheck(java.lang.String);
    private java.lang.String buildSqlCondition(com.seeyon.boot.starter.dynamicsql.dto.MainConditionDto, com.seeyon.boot.starter.dynamicsql.dto.DynamicConditionDto, java.util.Map<java.lang.String, java.lang.Object>);
    java.lang.String permissionAdd(java.util.List<java.util.Map<java.lang.String, java.lang.String>>, java.lang.String, java.lang.String, java.lang.String);
    private java.lang.String buildSqlInConditionItem(java.lang.Object, java.util.Map<java.lang.String, java.lang.Object>);
    private java.lang.String buildSqlFromStr();
    private java.lang.String buildSqlConditionItem(java.lang.Object, java.lang.String, java.util.Map<java.lang.String, java.lang.Object>);
    java.lang.String buildSqlForOrAnd(java.lang.Object, java.lang.String, java.lang.String, java.util.Map<java.lang.String, java.lang.Object>);
    java.lang.String buildSqlForAttribute(java.lang.String, java.lang.String, java.lang.String, java.util.Map<java.lang.String, java.lang.Object>);
    boolean enumMultiple(java.lang.Class<?>, java.lang.Class<?>, java.lang.String, java.util.Map<java.lang.String, java.lang.Object>, java.lang.String, java.lang.Integer, java.lang.String, java.lang.StringBuilder, java.lang.String);
    boolean booleanParser(java.lang.Class<?>);
    java.lang.Integer booleanParser(java.lang.Class<?>, java.lang.String);
    private void addJoinFromCondition(java.lang.String);
    private boolean objectIsNotNull(java.lang.Object);
    java.lang.String buildSqlForOrAndGetItemKey(java.lang.Object);
    java.lang.Object buildSqlForOrAndGetItemValue(java.lang.Object);
    private java.lang.String buildSqlOrderBy(com.seeyon.boot.transport.Sort, com.seeyon.boot.transport.PageInfo, java.lang.String);
    private void autoSort(java.util.List<java.lang.String>, java.util.List<java.lang.String>, com.seeyon.boot.transport.Sort$Order);
    com.seeyon.boot.starter.dynamicsql.appservice.DynamicSelectValidateService$TreeNode findParentOneToManyTreeNode(com.seeyon.boot.starter.dynamicsql.appservice.DynamicSelectValidateService$TreeNode);
    void addSort(com.seeyon.boot.starter.dynamicsql.appservice.DynamicSelectValidateService$TreeNode, java.util.List<java.lang.String>, java.util.List<java.lang.String>, java.lang.String);
    private com.seeyon.boot.starter.dynamicsql.appservice.DynamicSelectValidateService$TreeNode iteratorNode(com.seeyon.boot.starter.dynamicsql.appservice.DynamicSelectValidateService$TreeNode, java.lang.String);
    private void joinDtoCacheAdd(java.lang.String);
    private void inDtoCacheAdd(java.lang.String);
    boolean joinDtoCacheIsExist(java.lang.String);
    void joinIfAddCacheAdd(java.lang.String);
    private void isAutoAddCacheAdd(java.lang.String);
    java.lang.String getParentRefAttr(java.lang.String, java.lang.String);
    private java.lang.String getDtoFullNameFromDict(java.lang.String);
    java.lang.String getParentDtoFullName(java.lang.String);
    java.lang.String dtoToEntity(java.lang.String);
    private java.lang.String entityToDto(java.lang.String);
    private java.lang.String getEntityName(java.lang.String);
    java.lang.String getTableName(java.lang.String);
    tk.mybatis.mapper.entity.EntityTable getEntityTable(java.lang.String);
    java.lang.String getTableColumnName(java.lang.String, java.lang.String);
    private java.lang.Class<?> getTableColumnType(java.lang.String, java.lang.String);
    private void validate(com.seeyon.boot.starter.dynamicsql.dto.MainConditionDto);
    private void validateChildren(com.seeyon.boot.starter.dynamicsql.dto.ChildrenConditionDto);
    private com.seeyon.boot.transport.PageData toPageData(com.seeyon.boot.starter.mybatis.page.MyBatisPageInfo, java.lang.String);
    private com.seeyon.boot.transport.PageData toPageData(com.seeyon.boot.starter.mybatis.page.MyBatisPageInfo, java.util.List);
    private java.lang.Class<?> getDtoCacheClass(java.lang.String)
    private java.lang.Class<?> getEntityCacheClass(java.lang.String);
    void onApplicationEvent(org.springframework.context.ApplicationEvent);
```

### `DynamicEntitySelectService`（46 方法）

`com.seeyon.boot.starter.dynamicsql.appservice.DynamicEntitySelectService`

```java
    void entityCacheClear();
    void dtoCacheClear();
    void unloadDynamicCode(java.lang.String, java.lang.String);
    void unloadModuleApp(com.seeyon.boot.loader.ModuleAppLoadEvent);
    void unloadDynamicApp(com.seeyon.boot.loader.SeeyonURLClassLoader);
    void onApplicationEvent(com.seeyon.boot.event.ModuleUnloadEvent);
    com.seeyon.boot.transport.PageResponse<java.lang.Object> dynamicProxySelect(com.seeyon.boot.starter.dynamicsql.dto.ProxyParamDto);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> dynamicProxySelectCount(com.seeyon.boot.starter.dynamicsql.dto.ProxyParamDto);
    private com.seeyon.boot.transport.SingleResponse<java.lang.Integer> dynamicJoinSelectCountObject(com.seeyon.boot.transport.PageInfo, com.seeyon.boot.starter.dynamicsql.dto.MainConditionDto, com.seeyon.boot.transport.Sort, com.seeyon.boot.starter.dynamicsql.dto.DynamicConditionDto, java.lang.Boolean);
    private com.seeyon.boot.transport.PageResponse<java.lang.Object> dynamicJoinSelectObject(com.seeyon.boot.transport.PageInfo, com.seeyon.boot.starter.dynamicsql.dto.MainConditionDto, com.seeyon.boot.transport.Sort, com.seeyon.boot.starter.dynamicsql.dto.DynamicConditionDto, java.lang.Boolean);
    private com.seeyon.boot.starter.mybatis.page.MyBatisPageInfo<java.util.Map<java.lang.String, java.lang.Object>> selectByConditionDynamic(com.seeyon.boot.transport.PageInfo, com.seeyon.boot.starter.dynamicsql.dto.MainConditionDto, com.seeyon.boot.transport.Sort, com.seeyon.boot.starter.dynamicsql.dto.DynamicConditionDto, java.lang.Boolean);
    private java.lang.String buildSql(com.seeyon.boot.starter.dynamicsql.dto.MainConditionDto, com.seeyon.boot.transport.Sort, com.seeyon.boot.starter.dynamicsql.dto.DynamicConditionDto, java.util.Map<java.lang.String, java.lang.Object>);
    private java.lang.String buildSqlSelect(com.seeyon.boot.starter.dynamicsql.dto.MainConditionDto);
    private java.lang.String buildSqlFrom(com.seeyon.boot.starter.dynamicsql.dto.MainConditionDto);
    private java.lang.String buildSqlCondition(com.seeyon.boot.starter.dynamicsql.dto.MainConditionDto, com.seeyon.boot.starter.dynamicsql.dto.DynamicConditionDto, java.util.Map<java.lang.String, java.lang.Object>);
    private java.lang.String buildSqlOrderBy(com.seeyon.boot.transport.Sort);
    private java.lang.String buildSqlConditionItem(java.lang.Object, java.lang.String, java.util.Map<java.lang.String, java.lang.Object>);
    java.lang.String buildSqlForOrAnd(java.lang.Object, java.lang.String, java.lang.String, java.util.Map<java.lang.String, java.lang.Object>);
    java.lang.String buildSqlForAttribute(java.lang.String, java.lang.String, java.lang.String, java.util.Map<java.lang.String, java.lang.Object>);
    java.lang.String buildSqlForOrAndGetItemKey(java.lang.Object);
    java.lang.Object buildSqlForOrAndGetItemValue(java.lang.Object);
    boolean enumMultiple(java.lang.Class<?>, java.lang.Class<?>, java.lang.String, java.util.Map<java.lang.String, java.lang.Object>, java.lang.String, java.lang.Integer, java.lang.String, java.lang.StringBuilder, java.lang.String);
    java.lang.String permissionAdd(java.util.List<java.util.Map<java.lang.String, java.lang.String>>, java.lang.String, java.lang.String, java.lang.String);
    boolean booleanParser(java.lang.Class<?>);
    java.lang.Integer booleanParser(java.lang.Class<?>, java.lang.String);
    private java.util.List<java.lang.Object> parseData(com.seeyon.boot.starter.mybatis.page.MyBatisPageInfo<java.util.Map<java.lang.String, java.lang.Object>>, com.seeyon.boot.starter.dynamicsql.dto.MainConditionDto);
    java.lang.Object fieldParse(java.lang.Object, java.lang.String, java.lang.String);
    private java.lang.String getDtoFullNameFromDict(java.lang.String);
    private com.seeyon.boot.transport.PageData toPageData(com.seeyon.boot.starter.mybatis.page.MyBatisPageInfo, java.util.List);
    private boolean objectIsNotNull(java.lang.Object);
    private boolean permissionCheck(java.lang.String);
    private java.lang.Class getDtoCacheClass(java.lang.String)
    java.lang.String dtoToEntity(java.lang.String);
    private java.lang.String entityToDto(java.lang.String);
    private java.lang.String getEntityName(java.lang.String);
    java.lang.String getTableName(java.lang.String);
    tk.mybatis.mapper.entity.EntityTable getEntityTable(java.lang.String);
    java.lang.String getTableColumnName(java.lang.String, java.lang.String);
    private java.lang.Class<?> getTableColumnType(java.lang.String, java.lang.String);
    private java.lang.Class<?> getEntityCacheClass(java.lang.String);
    java.lang.Object parseIntegerField(java.lang.Class, java.lang.Object);
    void validate(com.seeyon.boot.starter.dynamicsql.dto.MainConditionDto, com.seeyon.boot.starter.dynamicsql.dto.DynamicConditionDto);
    void onApplicationEvent(org.springframework.context.ApplicationEvent);
```

### `DynamicAutoJoinSelectService`（42 方法）

`com.seeyon.boot.starter.dynamicsql.appservice.DynamicAutoJoinSelectService`

```java
    void entityCacheClear();
    void unloadDynamicCode(java.lang.String, java.lang.String);
    void unloadModuleApp(com.seeyon.boot.loader.ModuleAppLoadEvent);
    void unloadDynamicApp(com.seeyon.boot.loader.SeeyonURLClassLoader);
    void onApplicationEvent(com.seeyon.boot.event.ModuleUnloadEvent);
    com.seeyon.boot.transport.PageResponse<java.lang.Object> dynamicProxySelect(com.seeyon.boot.starter.dynamicsql.dto.ProxyJoinParamDto);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> dynamicProxySelectCount(com.seeyon.boot.starter.dynamicsql.dto.ProxyJoinParamDto);
    private void init(com.seeyon.boot.starter.dynamicsql.dto.ProxyJoinParamDto)
    private java.lang.String getFullNameFromSimple(java.lang.String);
    private java.lang.Class<?> getEntityCacheClass(java.lang.String);
    private com.seeyon.boot.starter.mybatis.page.MyBatisPageInfo<java.util.Map<java.lang.String, java.lang.Object>> selectByConditionDynamic(com.seeyon.boot.starter.dynamicsql.dto.ProxyJoinParamDto);
    private java.util.List<java.util.Map<java.lang.String, java.lang.Object>> selectByConditionDynamicCount(com.seeyon.boot.starter.dynamicsql.dto.ProxyJoinParamDto);
    private java.lang.String buildSql(com.seeyon.boot.starter.dynamicsql.dto.ProxyJoinParamDto, java.util.Map<java.lang.String, java.lang.Object>);
    private java.lang.String buildSqlSelect(java.util.Map<java.lang.String, java.util.Set<java.lang.String>>, java.util.List<java.lang.String>);
    private java.lang.String buildSqlFrom(java.lang.String, java.util.List<com.seeyon.boot.starter.dynamicsql.dto.JoinParamDto>);
    private java.lang.String buildSqlJoin(com.seeyon.boot.starter.dynamicsql.dto.JoinParamDto);
    private java.lang.String buildSqlGroup(java.util.Map<java.lang.String, java.util.Set<java.lang.String>>);
    private java.lang.String buildSqlCondition(java.lang.String, com.seeyon.boot.starter.dynamicsql.dto.DynamicConditionDto, java.util.Map<java.lang.String, java.lang.Object>, java.util.List<java.lang.String>);
    java.lang.String permissionAdd(java.util.List<java.util.Map<java.lang.String, java.lang.String>>, java.lang.String, java.lang.String, java.lang.String);
    boolean permissionCheck(java.lang.String);
    private java.lang.String buildSqlOrderBy(com.seeyon.boot.transport.Sort, com.seeyon.boot.transport.PageInfo, java.lang.String);
    private java.lang.String buildSqlConditionItem(java.lang.Object, java.lang.String, java.util.Map<java.lang.String, java.lang.Object>);
    java.lang.String buildSqlForOrAnd(java.lang.Object, java.lang.String, java.lang.String, java.util.Map<java.lang.String, java.lang.Object>);
    java.lang.String buildSqlForAttribute(java.lang.String, java.lang.String, java.lang.String, java.util.Map<java.lang.String, java.lang.Object>);
    java.lang.String buildSqlForOrAndGetItemKey(java.lang.Object);
    java.lang.Object buildSqlForOrAndGetItemValue(java.lang.Object);
    boolean enumMultiple(java.lang.Class<?>, java.lang.Class<?>, java.lang.String, java.util.Map<java.lang.String, java.lang.Object>, java.lang.String, java.lang.Integer, java.lang.String, java.lang.StringBuilder, java.lang.String);
    boolean booleanParser(java.lang.Class<?>);
    java.lang.Integer booleanParser(java.lang.Class<?>, java.lang.String);
    private java.util.List<java.lang.Object> parseData(com.seeyon.boot.starter.mybatis.page.MyBatisPageInfo<java.util.Map<java.lang.String, java.lang.Object>>);
    java.lang.Object fieldParse(java.lang.Object, java.lang.String, java.lang.String);
    private com.seeyon.boot.transport.PageData toPageData(com.seeyon.boot.starter.mybatis.page.MyBatisPageInfo, java.util.List);
    private boolean objectIsNotNull(java.lang.Object);
    java.lang.String getTableName(java.lang.String);
    java.lang.String getTableColumnName(java.lang.String, java.lang.String);
    private java.lang.Class<?> getTableColumnType(java.lang.String, java.lang.String);
    java.lang.Object parseIntegerField(java.lang.Class, java.lang.Object);
    void validate(com.seeyon.boot.starter.dynamicsql.dto.ProxyJoinParamDto);
    void onApplicationEvent(org.springframework.context.ApplicationEvent);
```

### `DynamicAliasSelectService`（40 方法）

`com.seeyon.boot.starter.dynamicsql.appservice.DynamicAliasSelectService`

```java
    void entityCacheClear();
    void unloadDynamicCode(java.lang.String, java.lang.String);
    void unloadModuleApp(com.seeyon.boot.loader.ModuleAppLoadEvent);
    void unloadDynamicApp(com.seeyon.boot.loader.SeeyonURLClassLoader);
    void onApplicationEvent(com.seeyon.boot.event.ModuleUnloadEvent);
    com.seeyon.boot.transport.PageResponse<java.lang.Object> dynamicProxySelect(com.seeyon.boot.starter.dynamicsql.dto.ProxyJoinAliasDto);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> dynamicProxySelectCount(com.seeyon.boot.starter.dynamicsql.dto.ProxyJoinAliasDto);
    private void init(com.seeyon.boot.starter.dynamicsql.dto.ProxyJoinAliasDto)
    private java.lang.String getFullNameFromAlias(java.lang.String);
    private java.lang.Class<?> getEntityCacheClass(java.lang.String);
    private com.seeyon.boot.starter.mybatis.page.MyBatisPageInfo<java.util.Map<java.lang.String, java.lang.Object>> selectByConditionDynamic(com.seeyon.boot.starter.dynamicsql.dto.ProxyJoinAliasDto);
    private java.util.List<java.util.Map<java.lang.String, java.lang.Object>> selectByConditionDynamicCount(com.seeyon.boot.starter.dynamicsql.dto.ProxyJoinAliasDto);
    private java.lang.String buildSql(com.seeyon.boot.starter.dynamicsql.dto.ProxyJoinAliasDto, java.util.Map<java.lang.String, java.lang.Object>);
    private java.lang.String buildSqlSelect(java.util.Map<java.lang.String, java.util.Set<java.lang.String>>, java.util.List<java.lang.String>);
    private java.lang.String buildSqlFrom(java.lang.String, java.util.List<com.seeyon.boot.starter.dynamicsql.dto.JoinAliasDto>);
    private java.lang.String buildSqlJoin(com.seeyon.boot.starter.dynamicsql.dto.JoinAliasDto);
    private java.lang.String buildSqlGroup(java.util.Map<java.lang.String, java.util.Set<java.lang.String>>);
    private java.lang.String buildSqlCondition(java.lang.String, com.seeyon.boot.starter.dynamicsql.dto.DynamicConditionDto, java.util.Map<java.lang.String, java.lang.Object>, java.util.Map<java.lang.String, java.lang.String>);
    private java.lang.String buildSqlOrderBy(com.seeyon.boot.transport.Sort, com.seeyon.boot.transport.PageInfo, java.lang.String);
    private java.lang.String buildSqlConditionItem(java.lang.Object, java.lang.String, java.util.Map<java.lang.String, java.lang.Object>);
    java.lang.String buildSqlForOrAnd(java.lang.Object, java.lang.String, java.lang.String, java.util.Map<java.lang.String, java.lang.Object>);
    java.lang.String buildSqlForAttribute(java.lang.String, java.lang.String, java.lang.String, java.util.Map<java.lang.String, java.lang.Object>);
    java.lang.String buildSqlForOrAndGetItemKey(java.lang.Object);
    java.lang.Object buildSqlForOrAndGetItemValue(java.lang.Object);
    boolean enumMultiple(java.lang.Class<?>, java.lang.Class<?>, java.lang.String, java.util.Map<java.lang.String, java.lang.Object>, java.lang.String, java.lang.Integer, java.lang.String, java.lang.StringBuilder, java.lang.String);
    boolean booleanParser(java.lang.Class<?>);
    java.lang.Integer booleanParser(java.lang.Class<?>, java.lang.String);
    private java.util.List<java.lang.Object> parseData(com.seeyon.boot.starter.mybatis.page.MyBatisPageInfo<java.util.Map<java.lang.String, java.lang.Object>>);
    java.lang.Object fieldParse(java.lang.Object, java.lang.String, java.lang.String);
    private com.seeyon.boot.transport.PageData toPageData(com.seeyon.boot.starter.mybatis.page.MyBatisPageInfo, java.util.List);
    private boolean objectIsNotNull(java.lang.Object);
    java.lang.String getTableName(java.lang.String);
    java.lang.String getTableColumnName(java.lang.String, java.lang.String);
    private java.lang.Class<?> getTableColumnType(java.lang.String, java.lang.String);
    java.lang.Object parseIntegerField(java.lang.Class, java.lang.Object);
    void validate(com.seeyon.boot.starter.dynamicsql.dto.ProxyJoinAliasDto);
    void onApplicationEvent(org.springframework.context.ApplicationEvent);
```

### `DynamicSelectValidateService`（27 方法）

`com.seeyon.boot.starter.dynamicsql.appservice.DynamicSelectValidateService`

```java
    void validateDescartes(java.lang.Class<?>, com.seeyon.boot.starter.dynamicsql.dto.MainConditionDto, com.seeyon.boot.starter.dynamicsql.dto.DynamicConditionDto);
    void validate(com.seeyon.boot.starter.dynamicsql.dto.MainConditionDto, com.seeyon.boot.starter.dynamicsql.dto.DynamicConditionDto);
    boolean setCheck(java.util.Set<java.lang.String>, java.util.Set<java.lang.String>);
    private void buildParamsSet(com.seeyon.boot.starter.dynamicsql.dto.MainConditionDto, com.seeyon.boot.starter.dynamicsql.dto.DynamicConditionDto, java.util.Set<java.lang.String>);
    void checkCondition(java.lang.Object, java.util.Set<java.lang.String>);
    private void checkForOrAnd(java.lang.Object, java.util.Set<java.lang.String>);
    java.lang.String getDtoSimpleNameFromCondKey(java.lang.String);
    private java.lang.String getDtoFullNameFromDict(java.lang.String);
    java.lang.String checkForOrAndGetItemKey(java.lang.Object);
    java.lang.Object checkForOrAndGetItemValue(java.lang.Object);
    private void oneToManyCheck(com.seeyon.boot.starter.dynamicsql.dto.ChildrenConditionDto, java.util.Set<java.lang.String>);
    void paramDtosAdd(java.util.Set<java.lang.String>, com.seeyon.boot.starter.dynamicsql.appservice.DynamicSelectValidateService$TreeNode, com.seeyon.boot.starter.dynamicsql.dto.ChildrenConditionDto);
    private com.seeyon.boot.starter.dynamicsql.appservice.DynamicSelectValidateService$TreeNode iteratorNode(com.seeyon.boot.starter.dynamicsql.appservice.DynamicSelectValidateService$TreeNode, java.lang.String);
    private void buildValidateSet(java.lang.String);
    void ifIteratorNode(com.seeyon.boot.starter.dynamicsql.appservice.DynamicSelectValidateService$TreeNode, java.util.Stack<com.seeyon.boot.starter.dynamicsql.appservice.DynamicSelectValidateService$TreeNode>);
    private void iteratorNode(com.seeyon.boot.starter.dynamicsql.appservice.DynamicSelectValidateService$TreeNode, java.util.Stack<com.seeyon.boot.starter.dynamicsql.appservice.DynamicSelectValidateService$TreeNode>);
    private void buildTreeNode(java.lang.Class<?>, java.lang.Boolean);
    void buildChildrenTreeNode(com.seeyon.boot.starter.dynamicsql.appservice.DynamicSelectValidateService$TreeNode, java.lang.Class<?>, java.lang.Boolean, int);
    private void dtoDictMapAdd(java.lang.String, java.lang.String);
    private void pathSetMapAdd(java.util.Set<java.lang.String>);
    boolean annontationCheckRef(java.lang.Class<?>, java.lang.Class<?>);
    com.seeyon.boot.starter.dynamicsql.appservice.DynamicSelectValidateService$TreeNode getTreeNodeInstance(boolean);
    void TreeNodeTest();
    java.util.Map<java.lang.String, com.seeyon.boot.starter.dynamicsql.appservice.DynamicSelectValidateService$TreeNode> getTreeNodeMap();
    java.util.Map<java.lang.String, java.util.Set<java.util.Set<java.lang.String>>> getPathSetMap();
    java.util.Map<java.lang.String, java.util.Map<java.lang.String, java.lang.String>> getDtoDictMap();
```

### `ThreadLocalUtil`（7 方法）

`com.seeyon.boot.starter.dynamicsql.util.ThreadLocalUtil`

```java
    static <T> T get(java.lang.String);
    static <T> T get(java.lang.String, T);
    static void set(java.lang.String, java.lang.Object);
    static void remove();
    static void destroy();
```

### `DynamicProxySelectService`（6 方法）

`com.seeyon.boot.starter.dynamicsql.appservice.DynamicProxySelectService`

```java
    com.seeyon.boot.transport.PageResponse<java.lang.Object> dynamicProxySelect(com.seeyon.boot.starter.dynamicsql.dto.ProxyParamDto);
    com.seeyon.boot.transport.PageResponse<java.lang.Object> dynamicOneEntitySelect(com.seeyon.boot.starter.dynamicsql.dto.ProxyParamDto);
    com.seeyon.boot.transport.PageResponse<java.lang.Object> dynamicJoinSelect(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.dynamicsql.dto.ProxyJoinParamDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> dynamicJoinSelectCount(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.dynamicsql.dto.ProxyJoinParamDto>);
    com.seeyon.boot.transport.PageResponse<java.lang.Object> dynamicAliasSelect(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.dynamicsql.dto.ProxyJoinAliasDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> dynamicAliasSelectCount(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.dynamicsql.dto.ProxyJoinAliasDto>);
```

## 四、枚举（1）

- `JoinType`（2 常量）：LEFT, INNER
