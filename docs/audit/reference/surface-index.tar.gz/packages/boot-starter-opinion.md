# boot-starter-opinion：接口与方法签名

> 自动生成，勿手改。`tools/core/platform/emit_package_surfaces.py` 重跑即可。
> 构件 `com.seeyon:boot-starter-opinion`（jar `boot-starter-opinion-5.3.260.jar`）
> 规模：64 类 / 6 接口 / 0 注解 / 2 枚举 / 9 个关键类 / 990 方法。
> 签名逐字来自 javap 原文；已去掉 `public` 前缀与 `throws` 子句。

## 一、接口（6）

### `OpinionService`（56 方法）

`com.seeyon.boot.starter.opinion.domain.service.OpinionService`

```java
    java.lang.Long create(com.seeyon.boot.starter.opinion.dto.table.OpinionDto);
    int update(com.seeyon.boot.starter.opinion.dto.table.OpinionDto);
    int updateSilent(com.seeyon.boot.starter.opinion.dto.table.OpinionDto);
    int updateBatch(java.util.List<com.seeyon.boot.starter.opinion.dto.table.OpinionDto>, java.util.Set<java.lang.String>);
    java.util.List<com.seeyon.boot.starter.opinion.dto.table.OpinionDto> selectInformBeforeSend(java.lang.Long, java.lang.Long);
    int transToOpinionDraftByAffairId(com.seeyon.boot.starter.opinion.dto.biz.OpinionTransDraftDto);
    int deleteById(java.lang.Long);
    int deleteById(java.lang.Long, boolean);
    int batchDeleteById(java.util.List<java.lang.Long>);
    int delete(java.lang.Long);
    int batchDelete(java.util.List<java.lang.Long>);
    int deleteByObjectId(java.lang.Long);
    default int deleteByAffairId(java.lang.Long, com.seeyon.boot.starter.opinion.enums.OpinionTypeEnum);
    int updateRestartByObjectId(java.lang.Long);
    com.seeyon.boot.starter.opinion.dto.table.OpinionDto selectById(java.lang.Long);
    java.util.List<com.seeyon.boot.starter.opinion.dto.table.OpinionDto> selectOpinionListByObjectIdAndSubObjectId(java.lang.Long, java.lang.Long);
    com.seeyon.boot.transport.PageData<com.seeyon.boot.starter.opinion.dto.table.OpinionDto> selectTopReplyListByObjectId(java.lang.Long, java.lang.Long, com.seeyon.boot.transport.PageInfo);
    com.seeyon.boot.transport.PageData<com.seeyon.boot.starter.opinion.dto.table.OpinionDto> selectOpinionPageByCache(java.lang.Long, java.lang.Long, com.seeyon.boot.transport.PageInfo);
    com.seeyon.boot.transport.PageData<com.seeyon.boot.starter.opinion.dto.table.OpinionDto> selectTopReplyListByObjectId(com.seeyon.boot.starter.opinion.dto.biz.OpinionRequestDto, com.seeyon.boot.transport.PageInfo);
    java.util.Map<java.lang.Long, java.util.List<com.seeyon.boot.starter.opinion.dto.table.OpinionDto>> selectSubOpinionListByIds(java.util.List<java.lang.Long>, boolean, java.util.List<com.seeyon.boot.starter.opinion.dto.table.OpinionDto>);
    java.util.Map<java.lang.Long, java.util.List<com.seeyon.boot.starter.opinion.dto.table.OpinionDto>> selectSubOpinionListByIds(java.util.List<java.lang.Long>, java.lang.String, boolean, java.util.List<com.seeyon.boot.starter.opinion.dto.table.OpinionDto>);
    com.seeyon.boot.starter.opinion.dto.table.OpinionDto selectDraftListByObjectIdAndSubObjectId(java.lang.Long, java.lang.Long, java.lang.Long);
    com.seeyon.boot.starter.opinion.dto.table.OpinionDto getUserLastOpinion(java.lang.Long, java.lang.Long);
    java.util.List<com.seeyon.boot.starter.opinion.dto.table.OpinionDto> selectByObjectId(java.lang.Long, int, int);
    java.util.List<com.seeyon.boot.starter.opinion.dto.table.OpinionDto> selectByObjectIdAndPermissionIds(java.lang.Long, java.util.List<java.lang.Long>, java.lang.Boolean, java.util.List<com.seeyon.boot.transport.Sort$Order>);
    default java.util.List<com.seeyon.boot.starter.opinion.dto.table.OpinionDto> selectByObjectId(java.lang.Long, int, int, com.seeyon.boot.transport.Sort$Direction, java.lang.Boolean);
    default com.seeyon.boot.transport.PageData<com.seeyon.boot.starter.opinion.dto.table.OpinionDto> selectPageDataByObjectId(java.lang.Long, int, int, com.seeyon.boot.transport.Sort$Direction, java.lang.Boolean);
    default java.util.List<com.seeyon.boot.starter.opinion.dto.table.OpinionDto> selectOpinionByObjectIdAndType(java.lang.Long, com.seeyon.boot.starter.opinion.enums.OpinionTypeEnum, java.lang.Long);
    java.util.List<com.seeyon.boot.starter.opinion.dto.table.OpinionDto> selectOpinionGroupByActivityNode(java.lang.Long, int, int);
    java.util.List<com.seeyon.boot.starter.opinion.dto.table.OpinionDto> selectGroupByActivityNode(java.lang.Long, int, int);
    default java.util.List<com.seeyon.boot.starter.opinion.dto.table.OpinionDto> selectGroupByActivityNode(java.lang.Long, int, int, com.seeyon.boot.transport.Sort$Direction, java.lang.Boolean);
    default com.seeyon.boot.transport.PageData<com.seeyon.boot.starter.opinion.dto.table.OpinionDto> selectPageDataGroupByActivityNode(java.lang.Long, int, int, com.seeyon.boot.transport.Sort$Direction, java.lang.Boolean);
    default com.seeyon.boot.transport.PageData<com.seeyon.boot.starter.opinion.dto.table.OpinionDto> selectOpinionByObjectIdAndNodeId(java.lang.Long, java.lang.Long, int, int, com.seeyon.boot.transport.Sort$Direction);
    default com.seeyon.boot.transport.PageData<com.seeyon.boot.starter.opinion.dto.table.OpinionDto> selectOpinionByObjectIdAndOpinionType(java.lang.Long, java.util.List<com.seeyon.boot.starter.opinion.enums.OpinionTypeEnum>, int, int, com.seeyon.boot.transport.Sort$Direction, java.lang.Boolean, java.lang.Boolean, java.lang.Integer);
    default com.seeyon.boot.transport.PageData<com.seeyon.boot.starter.opinion.dto.table.OpinionDto> pageQueryInformOpinion(com.seeyon.boot.starter.opinion.dto.biz.InformOpinionQueryDto);
    default com.seeyon.boot.transport.PageData<com.seeyon.boot.starter.opinion.dto.table.OpinionDto> selectOpinionByObjectIdAndOpinionType(java.lang.Long, java.util.List<com.seeyon.boot.starter.opinion.enums.OpinionTypeEnum>, int, int, com.seeyon.boot.transport.Sort$Direction);
    default java.util.List<com.seeyon.boot.starter.opinion.dto.table.OpinionDto> selectOpinionByObjectIdAndOpinionTypes(java.lang.Long, java.util.List<com.seeyon.boot.starter.opinion.enums.OpinionTypeEnum>);
    default boolean existOpinion(java.lang.Long, com.seeyon.boot.starter.opinion.enums.OpinionTypeEnum);
    default boolean existOpinionByObjectIdAndOpinionType(java.lang.Long, com.seeyon.boot.starter.opinion.enums.OpinionTypeEnum);
    java.util.List<com.seeyon.boot.starter.opinion.dto.table.OpinionDto> getOpinionByReplyTopId(java.lang.Long);
    com.seeyon.boot.starter.opinion.dto.table.OpinionDto selectPostScriptDraft(java.lang.Long);
    com.seeyon.boot.starter.opinion.dto.table.OpinionDto selectOpinionDraft(java.lang.Long, java.lang.Long);
    com.seeyon.boot.starter.opinion.dto.table.OpinionDto selectOpinionDraft(java.lang.Long, java.lang.Long, java.lang.Long);
    java.util.List<com.seeyon.boot.starter.opinion.dto.table.OpinionDto> selectOpinionByActivityId(java.lang.Long, java.lang.Long, int, int);
    java.util.Map<java.lang.String, java.lang.Long> selectOpinionAttachmentByObjectId(java.lang.Long);
    java.util.List<com.seeyon.boot.starter.opinion.dto.table.OpinionAttachmentDto> selectOpinionAttachmentListByObjectId(java.lang.Long);
    java.util.List<com.seeyon.boot.starter.opinion.dto.table.OpinionDto> selectOptionAndSubObject(java.lang.Long, java.util.List<java.lang.Long>);
    java.lang.Integer batchCreate(java.util.List<com.seeyon.boot.starter.opinion.dto.table.OpinionDto>);
    java.lang.Integer createBatchIgnoreTime(java.util.List<com.seeyon.boot.starter.opinion.dto.table.OpinionDto>);
    java.util.List<com.seeyon.boot.starter.opinion.dto.table.OpinionDto> selectOptionByObjectIdAndOperation(java.lang.Long, java.lang.String);
    com.seeyon.boot.starter.opinion.dto.table.OpinionDto getUserLastOpinionByOperationsAndOpinionTypes(java.lang.Long, java.lang.Long, java.util.List<com.seeyon.boot.starter.opinion.enums.OpinionTypeEnum>, java.util.List<java.lang.String>);
    java.util.List<com.seeyon.boot.starter.opinion.dto.table.OpinionDto> selectById(java.util.List<java.lang.Long>);
    default java.util.List<com.seeyon.boot.starter.opinion.dto.biz.OpinionNodeDto> selectNodeInfoByCaseId(java.lang.Long);
    int forwardCaseOpinion(java.lang.Long, java.lang.Long, java.lang.Integer, java.lang.Boolean, java.lang.Boolean);
    java.util.List<com.seeyon.boot.starter.opinion.dto.table.OpinionDto> searchOpinionNoPage(com.seeyon.boot.starter.opinion.dto.biz.OpinionSearchRequestDto);
    java.util.List<com.seeyon.boot.starter.opinion.dto.table.OpinionDto> searchOpinionNodeList(java.lang.Long);
```

### `ExtendComponentManager`（9 方法） extends InitializingBean

`com.seeyon.boot.starter.opinion.domain.extend.ExtendComponentManager`

```java
    default boolean checkObjectExist(java.lang.Long);
    default boolean hasCommentSecurity(java.lang.Long);
    default boolean hasAnonymousCommentSecurity(java.lang.Long);
    default boolean hasPraiseSecurity(java.lang.Long);
    default boolean hasDeleteCommentSecurity(java.lang.Long);
    default boolean hasAdminCommentSecurity(java.lang.Long);
    default boolean addAdminCommentSecurity(java.util.List<java.lang.Long>);
    default com.seeyon.boot.transport.PageData<com.seeyon.boot.starter.opinion.dto.biz.OpinionAtPersonDto> atPersonList(com.seeyon.boot.transport.PageInfo, java.util.Map<java.lang.String, java.lang.Object>);
    default void sendMessage(com.seeyon.boot.starter.opinion.dto.biz.OpinionExtendDto);
```

### `OpinionAdminService`（3 方法）

`com.seeyon.boot.starter.opinion.domain.extend.OpinionAdminService`

```java
    boolean match(java.lang.String);
    void modifyOpinion(com.seeyon.boot.starter.opinion.dto.biz.OpinionAdminModifyDto);
    void deleteOpinion(com.seeyon.boot.starter.opinion.dto.biz.OpinionAdminDeleteDto);
```

### `ExtraUpdateMapper`（1 方法）

`com.seeyon.boot.starter.opinion.domain.service.mysql.dao.ExtraUpdateMapper`

```java
    int updateWithWrapper(com.seeyon.boot.starter.opinion.domain.service.mysql.dao.ExtraUpdateMapper$ExtraUpdateWrapper);
```

### `OpinionDao`（0 方法）

`com.seeyon.boot.starter.opinion.domain.service.mysql.dao.OpinionDao`

```java
```

### `PraiseDao`（0 方法） extends Praise>

`com.seeyon.boot.starter.opinion.domain.service.mysql.dao.PraiseDao`

```java
```

## 二、关键类（9）

### `OpinionServiceImpl4Mysql`（102 方法）

`com.seeyon.boot.starter.opinion.domain.service.mysql.service.OpinionServiceImpl4Mysql`

```java
    java.lang.Long create(com.seeyon.boot.starter.opinion.dto.table.OpinionDto);
    private java.util.Date getActivityFirstTimeFromDatabase(java.lang.Long, java.lang.Long, java.lang.Long, java.lang.Long, java.lang.Long);
    int updateSilent(com.seeyon.boot.starter.opinion.dto.table.OpinionDto);
    int update(com.seeyon.boot.starter.opinion.dto.table.OpinionDto);
    int updateBatch(java.util.List<com.seeyon.boot.starter.opinion.dto.table.OpinionDto>, java.util.Set<java.lang.String>);
    int transToOpinionDraftByAffairId(com.seeyon.boot.starter.opinion.dto.biz.OpinionTransDraftDto);
    int deleteById(java.lang.Long);
    int deleteById(java.lang.Long, boolean);
    int batchDeleteById(java.util.List<java.lang.Long>);
    int deleteByObjectId(java.lang.Long);
    int deleteByAffairId(java.lang.Long, com.seeyon.boot.starter.opinion.enums.OpinionTypeEnum);
    int updateRestartByObjectId(java.lang.Long);
    com.seeyon.boot.starter.opinion.dto.table.OpinionDto selectById(java.lang.Long);
    java.util.List<com.seeyon.boot.starter.opinion.dto.table.OpinionDto> selectOpinionListByObjectIdAndSubObjectId(java.lang.Long, java.lang.Long);
    com.seeyon.boot.transport.PageData<com.seeyon.boot.starter.opinion.dto.table.OpinionDto> selectTopReplyListByObjectId(java.lang.Long, java.lang.Long, com.seeyon.boot.transport.PageInfo);
    com.seeyon.boot.transport.PageData<com.seeyon.boot.starter.opinion.dto.table.OpinionDto> selectOpinionPageByCache(java.lang.Long, java.lang.Long, com.seeyon.boot.transport.PageInfo);
    com.seeyon.boot.transport.PageData<com.seeyon.boot.starter.opinion.dto.table.OpinionDto> selectTopReplyListByObjectId(com.seeyon.boot.starter.opinion.dto.biz.OpinionRequestDto, com.seeyon.boot.transport.PageInfo);
    java.util.Map<java.lang.Long, java.util.List<com.seeyon.boot.starter.opinion.dto.table.OpinionDto>> selectSubOpinionListByIds(java.util.List<java.lang.Long>, boolean, java.util.List<com.seeyon.boot.starter.opinion.dto.table.OpinionDto>);
    java.util.Map<java.lang.Long, java.util.List<com.seeyon.boot.starter.opinion.dto.table.OpinionDto>> selectSubOpinionListByIds(java.util.List<java.lang.Long>, java.lang.String, boolean, java.util.List<com.seeyon.boot.starter.opinion.dto.table.OpinionDto>);
    com.seeyon.boot.starter.opinion.dto.table.OpinionDto selectDraftListByObjectIdAndSubObjectId(java.lang.Long, java.lang.Long, java.lang.Long);
    com.seeyon.boot.starter.opinion.dto.table.OpinionDto getUserLastOpinion(java.lang.Long, java.lang.Long);
    java.util.List<com.seeyon.boot.starter.opinion.dto.table.OpinionDto> selectOpinionGroupByActivityNode(java.lang.Long, int, int);
    java.util.List<com.seeyon.boot.starter.opinion.dto.table.OpinionDto> selectOpinionByObjectIdAndType(java.lang.Long, com.seeyon.boot.starter.opinion.enums.OpinionTypeEnum, java.lang.Long);
    java.util.List<com.seeyon.boot.starter.opinion.dto.table.OpinionDto> selectGroupByActivityNode(java.lang.Long, int, int);
    java.util.List<com.seeyon.boot.starter.opinion.dto.table.OpinionDto> getOpinionByReplyTopId(java.lang.Long);
    com.seeyon.boot.starter.opinion.dto.table.OpinionDto selectPostScriptDraft(java.lang.Long);
    java.util.List<com.seeyon.boot.starter.opinion.dto.table.OpinionDto> selectOpinionByActivityId(java.lang.Long, java.lang.Long, int, int);
    java.util.List<com.seeyon.boot.starter.opinion.dto.table.OpinionDto> selectByObjectId(java.lang.Long, int, int);
    java.util.List<com.seeyon.boot.starter.opinion.dto.table.OpinionDto> selectByObjectIdAndPermissionIds(java.lang.Long, java.util.List<java.lang.Long>, java.lang.Boolean, java.util.List<com.seeyon.boot.transport.Sort$Order>);
    com.seeyon.boot.starter.opinion.dto.table.OpinionDto selectOpinionDraft(java.lang.Long, java.lang.Long);
    com.seeyon.boot.starter.opinion.dto.table.OpinionDto selectOpinionDraft(java.lang.Long, java.lang.Long, java.lang.Long);
    java.util.Map<java.lang.String, java.lang.Long> selectOpinionAttachmentByObjectId(java.lang.Long);
    java.util.List<com.seeyon.boot.starter.opinion.dto.table.OpinionAttachmentDto> selectOpinionAttachmentListByObjectId(java.lang.Long);
    private int replayCount(java.lang.Long);
    private java.util.List<com.seeyon.boot.starter.opinion.dto.table.OpinionDto> selectPageByWrapper(com.seeyon.boot.domain.dao.Wrapper, int, int);
    private com.seeyon.boot.transport.PageData<com.seeyon.boot.starter.opinion.dto.table.OpinionDto> selectPageDataByConditions(java.util.Map<java.lang.String, java.lang.Object>, int, int, com.seeyon.boot.transport.Sort);
    private com.seeyon.boot.transport.PageData<com.seeyon.boot.starter.opinion.dto.table.OpinionDto> selectPageDataByWrapper(com.seeyon.boot.domain.dao.Wrapper, int, int);
    private com.seeyon.boot.starter.opinion.dto.table.OpinionDto opinionMappingToOpinionDto(com.seeyon.boot.starter.opinion.domain.entity.Opinion);
    java.util.List<com.seeyon.boot.starter.opinion.dto.table.OpinionDto> selectGroupByActivityNode(java.lang.Long, int, int, com.seeyon.boot.transport.Sort$Direction, java.lang.Boolean);
    com.seeyon.boot.transport.PageData<com.seeyon.boot.starter.opinion.dto.table.OpinionDto> selectPageDataGroupByActivityNode(java.lang.Long, int, int, com.seeyon.boot.transport.Sort$Direction, java.lang.Boolean);
    com.seeyon.boot.transport.PageData<com.seeyon.boot.starter.opinion.dto.table.OpinionDto> selectOpinionByObjectIdAndNodeId(java.lang.Long, java.lang.Long, int, int, com.seeyon.boot.transport.Sort$Direction);
    com.seeyon.boot.transport.PageData<com.seeyon.boot.starter.opinion.dto.table.OpinionDto> selectOpinionByObjectIdAndOpinionType(java.lang.Long, java.util.List<com.seeyon.boot.starter.opinion.enums.OpinionTypeEnum>, int, int, com.seeyon.boot.transport.Sort$Direction);
    com.seeyon.boot.transport.PageData<com.seeyon.boot.starter.opinion.dto.table.OpinionDto> selectOpinionByObjectIdAndOpinionType(java.lang.Long, java.util.List<com.seeyon.boot.starter.opinion.enums.OpinionTypeEnum>, int, int, com.seeyon.boot.transport.Sort$Direction, java.lang.Boolean, java.lang.Boolean, java.lang.Integer);
    private com.seeyon.boot.transport.PageData<com.seeyon.boot.starter.opinion.dto.table.OpinionDto> filterSubOpinion(com.seeyon.boot.transport.PageData<com.seeyon.boot.starter.opinion.dto.table.OpinionDto>, com.seeyon.boot.transport.Sort$Direction);
    com.seeyon.boot.transport.PageData<com.seeyon.boot.starter.opinion.dto.table.OpinionDto> pageQueryInformOpinion(com.seeyon.boot.starter.opinion.dto.biz.InformOpinionQueryDto);
    java.util.List<com.seeyon.boot.starter.opinion.dto.table.OpinionDto> selectOpinionByObjectIdAndOpinionTypes(java.lang.Long, java.util.List<com.seeyon.boot.starter.opinion.enums.OpinionTypeEnum>);
    boolean existOpinion(java.lang.Long, com.seeyon.boot.starter.opinion.enums.OpinionTypeEnum);
    boolean existOpinionByObjectIdAndOpinionType(java.lang.Long, com.seeyon.boot.starter.opinion.enums.OpinionTypeEnum);
    private com.seeyon.boot.domain.dao.Wrapper getOpinionWrapperByNodeDimension(java.lang.Long, java.lang.Boolean);
    java.util.List<com.seeyon.boot.starter.opinion.dto.table.OpinionDto> selectByObjectId(java.lang.Long, int, int, com.seeyon.boot.transport.Sort$Direction, java.lang.Boolean);
    com.seeyon.boot.transport.PageData<com.seeyon.boot.starter.opinion.dto.table.OpinionDto> selectPageDataByObjectId(java.lang.Long, int, int, com.seeyon.boot.transport.Sort$Direction, java.lang.Boolean);
    private com.seeyon.boot.domain.dao.Wrapper getOpinionWrapperByDateDimension(java.lang.Long, com.seeyon.boot.transport.Sort$Direction, java.lang.Boolean);
    java.util.List<com.seeyon.boot.starter.opinion.dto.table.OpinionDto> selectOptionAndSubObject(java.lang.Long, java.util.List<java.lang.Long>);
    java.lang.Integer batchCreate(java.util.List<com.seeyon.boot.starter.opinion.dto.table.OpinionDto>);
    java.lang.Integer createBatchIgnoreTime(java.util.List<com.seeyon.boot.starter.opinion.dto.table.OpinionDto>);
    private java.lang.Integer batchCreate(java.util.List<com.seeyon.boot.starter.opinion.dto.table.OpinionDto>, boolean);
    java.util.List<com.seeyon.boot.starter.opinion.dto.table.OpinionDto> selectOptionByObjectIdAndOperation(java.lang.Long, java.lang.String);
    com.seeyon.boot.starter.opinion.dto.table.OpinionDto getUserLastOpinionByOperationsAndOpinionTypes(java.lang.Long, java.lang.Long, java.util.List<com.seeyon.boot.starter.opinion.enums.OpinionTypeEnum>, java.util.List<java.lang.String>);
    java.util.List<com.seeyon.boot.starter.opinion.dto.table.OpinionDto> selectById(java.util.List<java.lang.Long>);
    int delete(java.lang.Long);
    int batchDelete(java.util.List<java.lang.Long>);
    java.util.List<com.seeyon.boot.starter.opinion.dto.table.OpinionDto> selectInformBeforeSend(java.lang.Long, java.lang.Long);
    java.util.List<com.seeyon.boot.starter.opinion.dto.biz.OpinionNodeDto> selectNodeInfoByCaseId(java.lang.Long);
    int forwardCaseOpinion(java.lang.Long, java.lang.Long, java.lang.Integer, java.lang.Boolean, java.lang.Boolean);
    java.util.List<com.seeyon.boot.starter.opinion.dto.table.OpinionDto> searchOpinionNoPage(com.seeyon.boot.starter.opinion.dto.biz.OpinionSearchRequestDto);
    void removeLocalCache(java.lang.Long);
    java.util.List<com.seeyon.boot.starter.opinion.dto.table.OpinionDto> searchOpinionNodeList(java.lang.Long);
```

### `OpinionAppService`（34 方法）

`com.seeyon.boot.starter.opinion.appservice.OpinionAppService`

```java
    com.seeyon.boot.transport.SingleResponse<java.lang.Long> createWithOpinionDto(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.opinion.dto.table.OpinionDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Long> create(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.opinion.dto.biz.OpinionEditorDataDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> update(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.opinion.dto.biz.OpinionEditorDataDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> transToOpinionDraft(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.opinion.dto.biz.OpinionTransDraftDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> deleteById(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> batchDeleteById(com.seeyon.boot.transport.SingleRequest<java.util.List<java.lang.Long>>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> deleteByObjectId(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.boot.starter.opinion.dto.table.OpinionDto> selectPostscriptList(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.boot.starter.opinion.dto.table.OpinionDto> selectById(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.PageResponse<com.seeyon.boot.starter.opinion.dto.table.OpinionDto> selectOpinionPageByObjectId(com.seeyon.boot.transport.PageRequest);
    com.seeyon.boot.transport.PageResponse<com.seeyon.boot.starter.opinion.dto.table.OpinionDto> selectOpinionPage(com.seeyon.boot.transport.PageDtoRequest<com.seeyon.boot.starter.opinion.dto.biz.OpinionRequestDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.boot.starter.opinion.dto.table.OpinionDto> selectSubOpinionListByObjectId(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.boot.starter.opinion.dto.table.OpinionDto> selectDraftListByObjectIdAndSubObjectId(java.lang.Long, java.lang.Long, java.lang.Long);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.boot.starter.opinion.dto.table.OpinionDto> getUserLastOpinion(java.lang.Long, java.lang.Long);
    com.seeyon.boot.transport.SingleResponse<java.lang.Void> transToOpinionDraftByAffairId(com.seeyon.boot.starter.opinion.dto.biz.OpinionTransDraftDto);
    com.seeyon.boot.transport.ListResponse<com.seeyon.boot.starter.opinion.dto.table.OpinionDto> selectOpinionGroupByActivityNode(java.lang.Long, int, int);
    com.seeyon.boot.transport.ListResponse<com.seeyon.boot.starter.opinion.dto.table.OpinionDto> selectGroupByActivityNode(java.lang.Long, int, int);
    com.seeyon.boot.transport.ListResponse<com.seeyon.boot.starter.opinion.dto.table.OpinionDto> selectOpinionByReplyTopId(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.boot.starter.opinion.dto.table.OpinionDto> selectPostScriptDraft(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.boot.starter.opinion.dto.table.OpinionDto> selectOpinionDraft(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.opinion.dto.biz.SelectOpinionDraftRequestDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.boot.starter.opinion.dto.table.OpinionDto> selectOpinionByActivityId(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.opinion.dto.biz.SelectByActivityIdRequestDto>);
    com.seeyon.boot.transport.SingleResponse<java.util.Map<java.lang.String, java.lang.Long>> selectOpinionAttachmentByObjectId(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.boot.starter.opinion.dto.table.OpinionAttachmentDto> selectOpinionAttachmentListByObjectId(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.boot.starter.opinion.dto.table.OpinionDto> selectByObjectId(com.seeyon.boot.transport.PageRequest);
    com.seeyon.boot.transport.ListResponse<com.seeyon.boot.starter.opinion.dto.table.OpinionDto> selectOptionAndSubObject(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.opinion.dto.biz.SelectObjectAndSubRequestDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.boot.starter.opinion.dto.table.OpinionDto> selectByIds(com.seeyon.boot.transport.SingleRequest<java.util.List<java.lang.Long>>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> createBatch(com.seeyon.boot.transport.SingleRequest<java.util.List<com.seeyon.boot.starter.opinion.dto.table.OpinionDto>>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> createBatchIgnoreTime(com.seeyon.boot.transport.SingleRequest<java.util.List<com.seeyon.boot.starter.opinion.dto.table.OpinionDto>>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.boot.starter.opinion.dto.table.OpinionDto> searchOpinionNoPage(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.opinion.dto.biz.OpinionSearchRequestDto>);
```

### `PraiseService`（32 方法）

`com.seeyon.boot.starter.opinion.domain.service.mysql.service.PraiseService`

```java
    java.lang.Integer createByCache(com.seeyon.boot.starter.opinion.dto.table.PraiseBaseDto);
    java.lang.Integer create(com.seeyon.boot.starter.opinion.dto.table.PraiseBaseDto);
    void insertDayInfo(com.seeyon.boot.starter.opinion.dto.table.PraiseBaseDto, java.lang.String);
    java.lang.Integer createBatch();
    void insertBatchPraise(java.util.Set<java.lang.String>, java.util.List<com.seeyon.boot.starter.opinion.domain.entity.Praise>);
    java.lang.Integer deleteByMainObjectIdByCache(java.lang.Long);
    java.lang.Integer deleteByMainObjectId(java.lang.Long);
    java.lang.Integer deleteByMainObjectIds(java.util.List<java.lang.Long>);
    java.util.List<java.lang.Long> selectByMainObjectId(java.lang.Long);
    java.util.Map<java.lang.Long, java.util.List<java.lang.Long>> selectByMainObjectIds1(java.util.List<java.lang.Long>);
    java.util.Map<java.lang.Long, java.util.List<java.lang.Long>> selectByMainObjectIds(java.util.List<java.lang.Long>);
    java.lang.Boolean selectByMainObjectIdAndUserId(java.lang.Long, java.lang.Long);
    java.lang.String selectPraiseSumByMainObjectId(java.lang.Long);
    java.lang.String dealWithSum(int);
    java.lang.Integer selectCountByCondition(java.lang.Long);
    void removeLocalCache(java.lang.Long);
```

### `OpinionBoxAppService`（12 方法）

`com.seeyon.boot.starter.opinion.appservice.OpinionBoxAppService`

```java
    com.seeyon.boot.transport.ListResponse<com.seeyon.boot.starter.opinion.dto.table.OpinionDto> selectOpinionBox(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.opinion.dto.biz.OpinionBoxRequestDto>);
    private java.util.List<com.seeyon.boot.starter.opinion.dto.table.OpinionDto> filterOpinion(com.seeyon.boot.starter.opinion.dto.biz.OpinionBoxRequestDto, java.util.List<com.seeyon.boot.starter.opinion.dto.table.OpinionDto>);
```

### `OpinionExtendService`（9 方法）

`com.seeyon.boot.starter.opinion.domain.service.OpinionExtendService`

```java
    java.lang.Long create(com.seeyon.boot.starter.opinion.dto.biz.OpinionEditorDataDto);
    private java.lang.Long extendSave(com.seeyon.boot.starter.opinion.dto.biz.OpinionEditorDataDto, com.seeyon.boot.starter.opinion.dto.table.OpinionDto, boolean);
    java.lang.Integer deleteById(java.lang.Long);
    java.lang.Integer extendDelete(com.seeyon.boot.starter.opinion.dto.biz.OpinionDelRequestDto);
    java.lang.Integer createPraise(com.seeyon.boot.starter.opinion.dto.table.PraiseBaseDto);
    boolean hasAdminCommentSecurity(java.lang.Long, java.lang.String);
    com.seeyon.boot.transport.PageData<com.seeyon.boot.starter.opinion.dto.biz.OpinionAtPersonDto> selectAtPersonList(com.seeyon.boot.transport.PageInfo, java.util.Map<java.lang.String, java.lang.Object>);
    java.util.Map<java.lang.String, java.lang.Integer> selectOpinionNum(java.lang.Long);
    void removeLocalCache(java.lang.Long);
```

### `OpinionExtendAppService`（7 方法）

`com.seeyon.boot.starter.opinion.appservice.OpinionExtendAppService`

```java
    com.seeyon.boot.transport.SingleResponse<java.lang.Long> create(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.opinion.dto.biz.OpinionEditorDataDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> deleteById(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> extendDelete(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.opinion.dto.biz.OpinionDelRequestDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> createPraise(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.opinion.dto.table.PraiseBaseDto>);
    com.seeyon.boot.transport.SingleResponse<java.util.Map<java.lang.String, java.lang.Integer>> selectOpinionNum(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.PageResponse<com.seeyon.boot.starter.opinion.dto.biz.OpinionAtPersonDto> selectAtPersonList(com.seeyon.boot.transport.PageRequest);
    com.seeyon.boot.transport.SingleResponse<java.lang.Boolean> hasAdminCommentSecurity(com.seeyon.boot.transport.SingleRequest<java.lang.String>);
```

### `I18nUtil`（7 方法）

`com.seeyon.boot.starter.opinion.utils.I18nUtil`

```java
    static java.lang.String getCurrentLocaleData(java.lang.String);
    static java.lang.String getDataI18n(java.lang.String, java.lang.String...);
    static java.lang.String getDataI18nStr(java.lang.String);
    static java.lang.String millis2DateDataI18n(java.lang.Long);
    static java.lang.String mergeDataI18n(java.lang.String, java.util.List<java.lang.String>);
```

### `OpinionCacheUtil`（7 方法）

`com.seeyon.boot.starter.opinion.utils.OpinionCacheUtil`

```java
    T get(java.lang.String);
    void put(java.lang.String, T);
    java.util.List<java.lang.String> getRedisHashMapKeys(java.lang.String);
    void remove(java.lang.String);
    void clear();
    void asyncPublish(java.lang.String);
```

### `PraiseAppService`（6 方法）

`com.seeyon.boot.starter.opinion.appservice.PraiseAppService`

```java
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> create(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.opinion.dto.table.PraiseBaseDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> deleteByMainObjectId(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.SingleResponse<java.util.List<java.lang.Long>> selectByMainObjectId(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.SingleResponse<java.util.Map<java.lang.Long, java.util.List<java.lang.Long>>> selectByMainObjectIds(com.seeyon.boot.transport.SingleRequest<java.util.List<java.lang.Long>>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Boolean> selectByMainObjectIdAndUserId(com.seeyon.boot.transport.SingleRequest<java.lang.Long>, com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.SingleResponse<java.lang.String> selectPraiseSumByMainObjectId(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
```

## 四、枚举（2）

- `OpinionFilterTypeEnum`（4 常量）：NORMAL, INFORM, CONSULT, SENDER_POST_SCRIPT
- `OpinionTypeEnum`（6 常量）：OPINION, INFORM_OPINION, SENDER_POST_SCRIPT, OPINION_DRAFT, POST_SCRIPT_DRAFT, SUBSTITUTE_INPUT_OPINION
