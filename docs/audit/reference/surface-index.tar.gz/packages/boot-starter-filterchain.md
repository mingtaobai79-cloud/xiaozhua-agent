# boot-starter-filterchain：接口与方法签名

> 自动生成，勿手改。`tools/core/platform/emit_package_surfaces.py` 重跑即可。
> 构件 `com.seeyon:boot-starter-filterchain`（jar `boot-starter-filterchain-5.3.600.jar`）
> 规模：8 类 / 3 接口 / 0 注解 / 0 枚举 / 0 个关键类 / 22 方法。
> 签名逐字来自 javap 原文；已去掉 `public` 前缀与 `throws` 子句。

## 一、接口（3）

### `Filter`（2 方法）

`com.seeyon.boot.starter.filterchain.Filter`

```java
    void doFilter(C, com.seeyon.boot.starter.filterchain.FilterChain<C>);
    default int getOrder();
```

### `FilterChain`（1 方法） extends BaseContext>

`com.seeyon.boot.starter.filterchain.FilterChain`

```java
    void doFilter(C);
```

### `Named`（1 方法）

`com.seeyon.boot.starter.filterchain.Named`

```java
    default java.lang.String getName();
```
