# boot-starter-dynamicloader：接口与方法签名

> 自动生成，勿手改。`tools/core/platform/emit_package_surfaces.py` 重跑即可。
> 构件 `com.seeyon:boot-starter-dynamicloader`（jar `boot-starter-dynamicloader-5.3.600.jar`）
> 规模：15 类 / 2 接口 / 0 注解 / 0 枚举 / 1 个关键类 / 109 方法。
> 签名逐字来自 javap 原文；已去掉 `public` 前缀与 `throws` 子句。

## 一、接口（2）

### `InitDataCallback`（1 方法）

`com.seeyon.boot.starter.dynamicloader.callback.InitDataCallback`

```java
    boolean initBasicData(java.lang.Long, java.lang.String);
```

### `DynamicModuleDao`（0 方法） extends CtpDynamicModule>

`com.seeyon.boot.starter.dynamicloader.domain.dao.DynamicModuleDao`

```java
```

## 二、关键类（1）

### `DynamicModuleService`（12 方法）

`com.seeyon.boot.starter.dynamicloader.domain.service.DynamicModuleService`

```java
    java.lang.Integer create(com.seeyon.boot.loader.DynamicModuleDto);
    java.util.List<com.seeyon.boot.starter.dynamicloader.domain.entity.CtpDynamicModule> queryUpdateTimeGT(java.util.Date);
    com.seeyon.boot.starter.dynamicloader.domain.entity.CtpDynamicModule getModuleLastCoordinate(java.lang.String);
    java.util.List<com.seeyon.boot.starter.dynamicloader.domain.entity.CtpDynamicModule> querySlowTopN(java.lang.Integer);
    java.lang.Integer updateStatistics(com.seeyon.boot.loader.DynamicModuleDto);
    com.seeyon.boot.transport.PageData<com.seeyon.ctp.metadata.dto.ServiceMetadataDto> selectPageByConditions(com.seeyon.boot.transport.PageInfo, java.util.Map<java.lang.String, java.lang.Object>, com.seeyon.boot.transport.Sort);
```
