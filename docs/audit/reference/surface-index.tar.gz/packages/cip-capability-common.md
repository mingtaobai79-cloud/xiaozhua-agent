# cip-capability-common：接口与方法签名

> 自动生成，勿手改。`tools/core/platform/emit_package_surfaces.py` 重跑即可。
> 构件 `com.seeyon:cip-capability-common`（jar `cip-capability-common-5.3.276.jar`）
> 规模：425 类 / 1 接口 / 3 注解 / 40 枚举 / 16 个关键类 / 5148 方法。
> 签名逐字来自 javap 原文；已去掉 `public` 前缀与 `throws` 子句。

## 一、接口（1）

### `ContractApiUrlable`（1 方法） extends Serializable

`com.seeyon.cip.provider.dto.econtracts.ContractApiUrlable`

```java
    java.lang.String apiUrl();
```

## 二、关键类（16）

### `MobilePluginPlatformConfigDto`（34 方法）

`com.seeyon.cip.provider.dto.mobileplugin.MobilePluginPlatformConfigDto`

```java
    java.lang.Long getId();
    java.lang.String getType();
    java.lang.String getCorpId();
    java.lang.String getCorpSecret();
    java.lang.String getAppId();
    java.lang.String getAppKey();
    java.lang.String getAppSecret();
    java.lang.String getJson();
    java.lang.String getTemplateId();
    java.lang.String getTemplateName();
    java.lang.String getTemplateQr();
    java.lang.String getName();
    com.seeyon.cip.provider.enums.mobileplugin.AccessModeEnum getAccessMode();
    java.lang.String getOpenCorpId();
    java.lang.Boolean getEnable();
    java.lang.Boolean getFuse();
    java.lang.String getThirdApplicationDomain();
    void setId(java.lang.Long);
    void setType(java.lang.String);
    void setCorpId(java.lang.String);
    void setCorpSecret(java.lang.String);
    void setAppId(java.lang.String);
    void setAppKey(java.lang.String);
    void setAppSecret(java.lang.String);
    void setJson(java.lang.String);
    void setTemplateId(java.lang.String);
    void setTemplateName(java.lang.String);
    void setTemplateQr(java.lang.String);
    void setName(java.lang.String);
    void setAccessMode(com.seeyon.cip.provider.enums.mobileplugin.AccessModeEnum);
    void setOpenCorpId(java.lang.String);
    void setEnable(java.lang.Boolean);
    void setFuse(java.lang.Boolean);
    void setThirdApplicationDomain(java.lang.String);
```

### `SignConfigsDto`（24 方法）

`com.seeyon.cip.provider.dto.signature.sign.SignConfigsDto`

```java
    java.lang.String getSignatureType();
    java.lang.String getSignType();
    int getEdgeScope();
    java.lang.String getPageNo();
    java.lang.String getPosX();
    java.lang.String getPosY();
    java.lang.String getSealId();
    com.seeyon.cip.provider.dto.signature.sign.KeywordInfoDto getKeywordInfo();
    java.lang.String getWidth();
    boolean isAddSignDate();
    java.lang.String getSignPosName();
    com.seeyon.cip.provider.dto.signature.sign.SealSignDatePositionInfoDto getSealSignDatePositionInfo();
    void setSignatureType(java.lang.String);
    void setSignType(java.lang.String);
    void setEdgeScope(int);
    void setPageNo(java.lang.String);
    void setPosX(java.lang.String);
    void setPosY(java.lang.String);
    void setSealId(java.lang.String);
    void setKeywordInfo(com.seeyon.cip.provider.dto.signature.sign.KeywordInfoDto);
    void setWidth(java.lang.String);
    void setAddSignDate(boolean);
    void setSignPosName(java.lang.String);
    void setSealSignDatePositionInfo(com.seeyon.cip.provider.dto.signature.sign.SealSignDatePositionInfoDto);
```

### `SignConfigDto`（22 方法）

`com.seeyon.cip.capability.dto.signature.SignConfigDto`

```java
    boolean isAddSignDate();
    java.lang.String getEdgeScope();
    java.lang.String getPageNo();
    java.lang.String getPosX();
    java.lang.String getPosY();
    java.lang.String getSealId();
    java.lang.String getSignPosName();
    java.lang.String getSignType();
    java.lang.String getSignatureType();
    void setAddSignDate(boolean);
    void setEdgeScope(java.lang.String);
    void setPageNo(java.lang.String);
    void setPosX(java.lang.String);
    void setPosY(java.lang.String);
    void setSealId(java.lang.String);
    void setSignPosName(java.lang.String);
    void setSignType(java.lang.String);
    void setSignatureType(java.lang.String);
    boolean equals(java.lang.Object);
    protected boolean canEqual(java.lang.Object);
    int hashCode();
    java.lang.String toString();
```

### `ServiceFeatureDto`（16 方法）

`com.seeyon.cip.capability.dto.ServiceFeatureDto`

```java
    java.lang.String getName();
    java.lang.String getCode();
    java.lang.Boolean getEnable();
    java.lang.String getSupport();
    java.lang.Boolean getExpend();
    java.util.List<com.seeyon.cip.capability.dto.ColumnDto> getColumns();
    java.util.List<?> getList();
    int getOrder();
    void setName(java.lang.String);
    void setCode(java.lang.String);
    void setEnable(java.lang.Boolean);
    void setSupport(java.lang.String);
    void setExpend(java.lang.Boolean);
    void setColumns(java.util.List<com.seeyon.cip.capability.dto.ColumnDto>);
    void setList(java.util.List<?>);
    void setOrder(int);
```

### `TemplateInfoDto`（16 方法）

`com.seeyon.cip.provider.dto.signature.template.TemplateInfoDto`

```java
    void setTemplateName(java.lang.String);
    void setCreateUserName(java.lang.String);
    void setCreateUserCode(java.lang.String);
    void setCreateOrganizeCode(java.lang.String);
    void setCreateOrganizeName(java.lang.String);
    void setDescription(java.lang.String);
    void setCreateTime(java.util.Date);
    void setUpdateTime(java.util.Date);
    java.lang.String getTemplateName();
    java.lang.String getCreateUserName();
    java.lang.String getCreateUserCode();
    java.lang.String getCreateOrganizeCode();
    java.lang.String getCreateOrganizeName();
    java.lang.String getDescription();
    java.util.Date getCreateTime();
    java.util.Date getUpdateTime();
```

### `SignToolsConfigCallBackNewDto`（12 方法）

`com.seeyon.cip.capability.dto.signature.SignToolsConfigCallBackNewDto`

```java
    java.lang.String getFilePreTaskId();
    java.util.List<com.seeyon.cip.capability.dto.signature.SealFilesDto> getSignFiles();
    java.util.List<com.seeyon.cip.provider.dto.signature.sign.FilePreTaskInfoDto> getSignerInfos();
    java.lang.String getEventKey();
    void setFilePreTaskId(java.lang.String);
    void setSignFiles(java.util.List<com.seeyon.cip.capability.dto.signature.SealFilesDto>);
    void setSignerInfos(java.util.List<com.seeyon.cip.provider.dto.signature.sign.FilePreTaskInfoDto>);
    void setEventKey(java.lang.String);
    boolean equals(java.lang.Object);
    protected boolean canEqual(java.lang.Object);
    int hashCode();
    java.lang.String toString();
```

### `SignAreaConfigDto`（12 方法）

`com.seeyon.cip.provider.dto.signature.sign.SignAreaConfigDto`

```java
    java.lang.String getCallbackUrl();
    java.util.List<com.seeyon.cip.provider.dto.signature.sign.FileInfoDto> getFileKeyList();
    java.util.List<com.seeyon.cip.provider.dto.signature.sign.SignerAreaDto> getSignerList();
    java.lang.String getContractId();
    void setCallbackUrl(java.lang.String);
    void setFileKeyList(java.util.List<com.seeyon.cip.provider.dto.signature.sign.FileInfoDto>);
    void setSignerList(java.util.List<com.seeyon.cip.provider.dto.signature.sign.SignerAreaDto>);
    void setContractId(java.lang.String);
    boolean equals(java.lang.Object);
    protected boolean canEqual(java.lang.Object);
    int hashCode();
    java.lang.String toString();
```

### `TemplateControlResultDto`（12 方法）

`com.seeyon.cip.provider.dto.signature.template.TemplateControlResultDto`

```java
    void setTemplateId(java.lang.String);
    void setTemplateName(java.lang.String);
    void setCreateTime(java.util.Date);
    void setUpdateTime(java.util.Date);
    void setContentsControl(java.util.List<com.seeyon.cip.provider.dto.signature.template.ContentsControlDto>);
    void setSealControl(java.util.List<com.seeyon.cip.provider.dto.signature.template.SealControlDto>);
    java.lang.String getTemplateId();
    java.lang.String getTemplateName();
    java.util.Date getCreateTime();
    java.util.Date getUpdateTime();
    java.util.List<com.seeyon.cip.provider.dto.signature.template.ContentsControlDto> getContentsControl();
    java.util.List<com.seeyon.cip.provider.dto.signature.template.SealControlDto> getSealControl();
```

### `CommonUtil`（8 方法）

`com.seeyon.cip.capability.common.CommonUtil`

```java
    static boolean isSpecialChar(java.lang.String);
    static boolean isPass(java.lang.String);
    static java.lang.String selectCurrentLocaleName(java.lang.String);
    static <T> java.util.List<java.util.List<T>> splitList(java.util.List<T>, int);
    static java.lang.Long getCloudId();
    static java.lang.String formatParaMap(java.util.Map<java.lang.String, java.lang.String>);
    static java.lang.String getContentByStream(java.io.InputStream);
    static java.lang.Long getSecondsNowToDayEnd();
```

### `SignToolsConfigCallBackDto`（8 方法）

`com.seeyon.cip.capability.dto.signature.SignToolsConfigCallBackDto`

```java
    java.util.List<com.seeyon.cip.provider.dto.signature.sign.FilePreTaskInfoDto> getFilePreTaskInfos();
    java.lang.String getEventKey();
    void setFilePreTaskInfos(java.util.List<com.seeyon.cip.provider.dto.signature.sign.FilePreTaskInfoDto>);
    void setEventKey(java.lang.String);
    boolean equals(java.lang.Object);
    protected boolean canEqual(java.lang.Object);
    int hashCode();
    java.lang.String toString();
```

### `PdfConvertHtmlUtil`（6 方法）

`com.seeyon.cip.capability.common.PdfConvertHtmlUtil`

```java
    static java.awt.image.BufferedImage pdfStreamToPng(java.io.InputStream, java.lang.Integer);
    static java.awt.image.BufferedImage combineBufferedImages(java.awt.image.BufferedImage...);
    static java.io.InputStream createHtmlByBase64(java.lang.String);
    static java.io.InputStream getStringStream(java.lang.String);
    static java.lang.String bufferedImageToBase64(java.awt.image.BufferedImage);
    static java.io.InputStream bufferedImageToInputStream(java.awt.image.BufferedImage);
```

### `TripAddressGetManagerRequestDto`（6 方法）

`com.seeyon.cip.provider.dto.trip.TripAddressGetManagerRequestDto`

```java
    java.lang.String getUserId();
    java.lang.String getItineraryId();
    java.lang.String getPhone();
    void setUserId(java.lang.String);
    void setItineraryId(java.lang.String);
    void setPhone(java.lang.String);
```

### `EncryptUtils`（4 方法）

`com.seeyon.cip.capability.common.EncryptUtils`

```java
    static java.lang.String md5Hex(java.lang.String);
    static java.lang.String sha256(java.lang.String);
    static private static byte[] digest(java.lang.String, byte[]);
    static private static java.lang.String hex(byte[]);
```

### `ImageUtil`（4 方法）

`com.seeyon.cip.provider.common.ImageUtil`

```java
    static java.lang.String getImageFormatByBytes(byte[]);
    static java.lang.String getImageFormat(javax.imageio.stream.ImageInputStream);
    static void checkImage(java.util.Map<java.lang.String, java.lang.Object>, java.lang.Long, java.lang.String);
    static void checkImageFormat(java.lang.String, java.lang.String);
```

### `SmsTemplateQueryDto`（4 方法）

`com.seeyon.cip.provider.dto.sms.SmsTemplateQueryDto`

```java
    void setCode(java.lang.String);
    void setLanguage(java.lang.String);
    java.lang.String getCode();
    java.lang.String getLanguage();
```

### `CipInterceptExceptionHandler`（4 方法）

`com.seeyon.cip.provider.exception.CipInterceptExceptionHandler`

```java
    static com.seeyon.cip.provider.exception.CipInterceptExceptionHandler AuthenticationException();
    static com.seeyon.cip.provider.exception.CipInterceptExceptionHandler RequestMessageException();
    static com.seeyon.cip.provider.exception.CipInterceptExceptionHandler HttpRequestException();
    static com.seeyon.cip.provider.exception.CipInterceptExceptionHandler UnrecognizedException();
```

## 三、注解（3）

| 注解 | 元素 |
|---|---|
| `CipDaoCondition` | alias, selectType, isI18n |
| `CipChannelRouter` | value |
| `ValidationGroup` |  |

## 四、枚举（40）

- `CipDaoSelectEnum`（6 常量）：EQ, LIKE, GT, LT, GTE, LTE
- `CapabilityEnum`（30 常量）：Routing, TestCapability, Sms, Ocr, Invoice, Video, Email, Translation, Location, Weather, Credit, Doc …
- `FeatureEnum`（157 常量）：EnterpriseInfo, JudicialRisk, OperatingRisk, BusinessInfo, IntellectualProperty, EnterpriseDevelopment, View, CompositeView, LatestPicViewUrl, Edit, Clean, TextWaterMark …
- `MobilePluginTodoPriorityEnum`（4 常量）：LOW, GENERAL, URGENT, VERY_URGENT
- `ArchiveFieldType`（14 常量）：NONE, WENBEN, DUOXINGWENBEN, ZHENGSHU, CHANGZHENGSHU, XIAOSHU, HUOBI, RIQI, SHIJIAN, RIQISHIJIAN, BUER, SHITIZUZHI …
- `EnterpriseCreditApiEnum`（2 常量）：ENTERPRISE_INFO, ENTERPRISE_BASIC_BUSINESS_INFO
- `CipClientTypeEnum`（5 常量）：WEB, PC, MOBILE, PAD, THIRD
- `FileBookMarkTypeEnum`（3 常量）：DOCUMENT, IMAGE, TEXT
- `ContractsApiEnum`（24 常量）：Token, PersonURL, PersonAuth, AddUser, DelUser, GetPersonInfo, GetCompanyUnionId, CheckAccountInfo, UploadFile, SignTask, GetSignSentUrl, GetSignUrl …
- `ContractsTaskStatusEnum`（9 常量）：TASK_SIGN_PENDING, TASK_FINISH, TASK_EXPIRED, TASK_CANCEL, TASK_REJECT, TASK_PENDING, TASK_NOT_PASS, TASK_CANCEL_APPROVAL, TASK_REJECTED
- `SealStatusEnum`（3 常量）：CHECK_UNPASS, NOT_CHECK, CHECK_PASS
- `SignDetailStatusEnum`（7 常量）：SIGN_OTHER, SIGN_SELF, SIGN_FINISH, SIGN_REJECT, SIGN_CANCEL, REPEAT, NOT_SING
- `EmailFileTypeEnum`（2 常量）：IMAGE, ATTACHMENT
- `EmailTypeEnum`（4 常量）：POP, IMAP, EXCHANGE, CUSTOM
- `InvoiceCapabilityType`（24 常量）：TaxOrdinaryInvoice, TaxOrdinaryElectronicInvoice, TaxBlockChainInvoice, TaxSpecialInvoice, TaxSpecialElectronicInvoice, TaxRollInvoice, TollOrdinaryElectronicInvoice, TaxPaymentCertificate, FerryTicket, TaxiReceipt, TrainTicket, AirTicket …
- `InvoiceCheckType`（14 常量）：SpecialVat, ElecSpecialVat, Normal, ElecNormal, RollNormal, GeneralMachinePrintedElectronicInvoice, TollElecNormal, SpecialFreightTransport, MotorVehicle, BlockChain, AllElectricSpecialPurposeInvoice, AllElectricOrdinaryInvoice …
- `InvoiceInvalidSignEnum`（6 常量）：SIGN_UNAVOIDED, SIGN_OBSOLETE, SIGN_CHONGHONG, SIGN_LOSE, SIGN_ABNORMAL, SIGN_UNKNOWN
- `InvoiceVerifyResultEnum`（30 常量）：INSPECTION_FAILED, INSPECTION_SUCCEEDED, MAXIMUM_DAY, REQUEST_ILLEGAL, INFORMATION_INCONSISTENT, INVOICE_NONEXISTENT, EXCEED_MAXIMUM, INVOICE_IRREGULAR, INSPECTION_ANOMALY, BATCH_EXPIRED, FIELD_CANNOT_EMPTY, LENGTH_INCORRECT …
- `RegionLevelEnum`（5 常量）：country, province, city, district, street
- `RegionSubEnum`（4 常量）：NO_SUB, LEVEL_ONE, LEVEL_TWO, LEVEL_THREE
- `DataExchangeTypeEnum`（2 常量）：PAGE_URL, PAGE_INTERFACE
- `DiffRuleEnum`（8 常量）：FILTER_BLANK, FILTER_PUNC, FILTER_HEADER_FOOTER, FILTER_OTHER_CHAR, FILTER_COMMENTS, FILTER_FOOTNOTE, FILTER_STAMP, OTHER
- `OfficialDocTypeEnum`（16 常量）：INSTRUCTIONS, ANNOUNCEMENT, LETTER, OPINION, BULLETIN, DECISION, RESOLUTION, COMMAND, REPORT, RESPOND, SUMMARY, MOTION …
- `TaskStatus`（4 常量）：SUCCESS, RUNNING, NOT_EXIST, FAIL
- `AccessModeEnum`（2 常量）：SELF_BUILT, REPLACE_DEVELOP
- `OcrCapabilityApiEnum`（19 常量）：IdCard, IdCardFront, IdCardBack, BankCard, BusinessCard, BusinessLicense, OrgCodeCert, TaxInvoice, TaxRollInvoice, INVOICE_VERIFICATION, TrainTicket, TaxiReceipt …
- `OfdFileTypeEnum`（3 常量）：PDF, OFD, AIP
- `SearchClientTypeEnum`（2 常量）：PC, PHONE
- `AnxinEnum`（5 常量）：KEYWORD_STAMP, RIDING_SEAM_SEAL, END_PAGE_STAMP, STAMP_ON_EACH_PAGE, POSITIONING_STAMP
- `CallBackFlowTypeEnum`（8 常量）：SIGN_FLOW_START, SIGN_FLOW_SIGNED, SIGN_FLOW_FINISH, SIGN_FLOW_OVERTIME, SIGN_FLOW_EXPIRE_REMIND, SIGN_FLOW_REFUSE, SIGN_FLOW_CANCEL, SIGNED_FLOW_SIGN_FAILED
- `ContractLockEnum`（3 常量）：ONCE, ONCE_MORE, INVALID
- `LicenseTypeEnum`（4 常量）：ID_CARD, HK_MACAO, TAIWAN, PASSPORT
- `OrgLicenseTypeEnum`（2 常量）：CREDIT_CODE, REGIST_NUMBER
- `OrgTypeEnum`（2 常量）：COMPANY, DEPARTMENT
- `LanguagesEnum`（6 常量）：CHINESE, ENGLISH, TRADITIONAL_CHINESE, JAPANESE, KOREAN, AUTO
- `VideoMeetingJoinTypeApiEnum`（2 常量）：ROOM, MEETING
- `VideoMeetingMediaTypeEnum`（5 常量）：Voice, Video, HDVideo, Telepresence, Data
- `VideoMeetingTypeApiEnum`（3 常量）：INSTANT_MEETING, APPOINTMENT_MEETING, LONG_TERM_MEETINGS
- `IntelligentAbstractStatusEnum`（4 常量）：NOT_EXIST, SUCCESS, FAIL, RUNNING
- `TaskStatusEnum`（4 常量）：QUEUING, RUNNING, SUCCESS, FAIL
