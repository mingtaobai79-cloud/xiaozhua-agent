# packages/ 索引（91 份构件接口面）

> ⚠️ **本目录 91 份全部自动生成，改任何一份都无效**——重跑就会覆盖。
> 生成器：`tools/core/platform/emit_package_surfaces.py`。
> 上级入口：`../README.md`；版本基线：`../BASELINE.md`。

## 这个目录是什么

**按「构件（Maven artifact）」一包一份导出接口与方法签名**：91 份 md，覆盖扩展工程 pom 里
声明的每一个标品依赖。回答的问题是「**我 pom 里这个依赖能干什么、里面有什么类和方法**」。

三种"接口面"目录容易混，区别如下：

| 目录 | 切法 | 回答什么 |
|---|---|---|
| `packages/`（本目录） | **按构件**一包一份 | 「这个 jar 里有什么」 |
| `../domains/` | 按业务域（bpm / 组织 / 连接器…）合并 | 「这个场景要用哪些类」 |
| `../dto-fields/` | 按 DTO | 「这个 DTO 有哪些字段」 |

`packages/` 按构件切是为了**对照 pom 声明**；找功能用 `domains/`，找字段用 `dto-fields/`。

## 一、规模（2026-11-07 逐份解析实测）

| 项 | 值 |
|---|---:|
| 文件数 | **91** |
| 合计字节 | **3,315,454**（3.17 MB） |
| 合计行 | **44,965** |
| 类 | 10,457 |
| 接口 | 1,036 |
| 注解 | 109 |
| 枚举 | 758 |
| 关键类 | 1,598 |
| 方法 | 106,335 |

（以上数字来自逐份解析每份头部的「规模：N 类 / N 接口 / …」行后再求和，非估算。）

## 二、先看这 6 份，别从 `a` 读到 `z`

| 文件 | 字节 | 行 | 占全目录 |
|---|---:|---:|---:|
| **`udc-biz.md`** | **1,081,973** | **12,041** | **33%** |
| `boot-starter-graphql.md` | 130,531 | 2,424 | 4% |
| `udc-starter-runtime.md` | 127,765 | 1,601 | 4% |
| `cip-capability-facade.md` | 120,833 | 1,389 | 4% |
| `boot-core.md` | 106,696 | 2,188 | 3% |
| `organization-facade.md` | 100,851 | 953 | 3% |

**`udc-biz.md` 一份占三分之一**——它也是 UDC 扩展最常用的一份。真要顺读，从 `udc-biz` 开始，
不要从字母序的 `boot-starter-cache.md` 开始（那份只有 50 类 / 270 方法，看完会误判整体规模）。

最小的四份各不到 1.2 KB（`boot-starter-websocket.md` 743 B、`boot-starter-filterchain.md` 916 B、
`boot-license-generator.md` 955 B、`boot-starter-lock.md` 1,132 B）——它们是**空壳 starter**，
只有少量接口，不代表抽取缺失。

## 三、20 个版本混在同一个目录里（这是一处真实陷阱）

`../BASELINE.md` 的记录：**91 个构件来自 20 个不同版本**。主力是 `5.3.600`（48 个构件），
另有 `5.3.603`（11）、`5.3.605`（6）、`5.3.517`（5），以及 16 个各自只有 1–2 个构件的零散版本。

**后果**：跨构件比较方法签名时，比的可能不是同一代平台。`BASELINE.md` 自己写了硬约束：

> 换版本 = 重抽该构件 → 重跑 emit，**不要混用两个版本的签名**。

所以引用签名做结论时，必须同时写清该构件属于哪个版本（`BASELINE.md` 的「逐构件」表可查）。

## 四、怎么重跑（唯一正确的改法）

```bash
python tools/core/platform/emit_package_surfaces.py \
    --interfaces docs/audit/artifacts/extension-surface-20261029/interfaces.json \
    --emit-dir  docs/audit/artifacts/extension-surface-20261029/packages
```

数据源是 `../interfaces.json`（`classes[].pkg` 记录来源构件）。重抽步骤在 `../BASELINE.md`：
`rebuild_surfaces.py` 重抽 → 重跑各 emit 脚本。

**同一批 emit 脚本还有三个兄弟**（`BASELINE.md` L135）：`emit_extension_points.py` /
`emit_domain_surfaces.py` / `emit_package_surfaces.py`。它们共用 `interfaces.json`，
所以**换版本要一起重跑**，只重跑一个会出现两代签名并存。

## 五、谁在读这些文件

| 消费方 | 用法 |
|---|---|
| `core/facts/standard-product/standard-product-appservice-surfaces.md` | 第 278 行按 `packages/<构件名>.md` 指路；第 301 行「问『我 pom 里这个依赖能干什么』→ `packages/`」 |
| `core/facts/standard-product/enums-and-constants.md` | 第 123 行标注「枚举节」来自 `emit_package_surfaces.py` |
| `tests/udc/test_extension_usage_assets.py` | 断言 `../batch2/_index.json` 的 `totals.packages == 84`（**另一个计数口径，见下**） |

⚠️ **两个包数不是矛盾，是两个口径**：本目录 **91 份**（= BASELINE 的 91 个构件），
`batch2/_index.json` 的 **84**（= 另一批抽取的构件数）。测试断言的是后者。
改动任一侧前先确认改的是哪个口径。

## 六、不要做的事

- **不要手改这 91 份里的任何一份**：全部自动生成，重跑即覆盖，改动手工白做。
- **不要删「看起来没用」的小文件**：`boot-starter-*.md` 的短小是**真实规模**（空壳 starter），不是抽取失败。
- **不要按字母序顺读**：见 §二，`udc-biz.md` 之后的 90 份只占 67%。
- **不要跨版本拼签名**：见 §三。
- **不要靠重跑来"清理"本目录**：emit 脚本 `mkdir(exist_ok=True)` 后**只覆盖同名文件**，不删旧文件
  （`emit_package_surfaces.py` L129–L137 无 unlink/glob 清理）。构件改名或下线的旧 md 会留在盘上，
  发现多出来的文件要人工确认，别以为是脚本 bug。

---

维护：**本文件是目录里唯一可以手写的文件**。换版本重跑后，§一 的六个规模数字、§二 的字节/行数
会变，由 `tests/udc/test_extension_surface_packages_layout.py` 守着。
