# udc-starter-dataflow：接口与方法签名

> 自动生成，勿手改。`tools/core/platform/emit_package_surfaces.py` 重跑即可。
> 构件 `com.seeyon:udc-starter-dataflow`（jar `udc-starter-dataflow-5.3.605.jar`）
> 规模：116 类 / 16 接口 / 0 注解 / 3 枚举 / 24 个关键类 / 1122 方法。
> 签名逐字来自 javap 原文；已去掉 `public` 前缀与 `throws` 子句。

## 一、接口（16）

### `DataFlowMappingAppService`（6 方法）

`com.seeyon.boot.starter.dataflow.api.DataFlowMappingAppService`

```java
    com.seeyon.boot.transport.ListResponse<com.seeyon.boot.starter.dataflow.dto.DataFlowRtMappingDto> selectOriginalMappingList(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.dataflow.dto.OriginalDataFlowMappingListQueryDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.boot.starter.dataflow.dto.DataFlowRtMappingDto> selectById(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.boot.starter.dataflow.dto.DataFlowRtEditInitialDataDto> selectMappingInitData(com.seeyon.boot.transport.SingleRequest<com.seeyon.udc.common.dto.DataFlowMappingInitQueryDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.boot.starter.dataflow.dto.DataFlowRtMappingDto> update(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.dataflow.dto.DataFlowRtMappingSaveDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.boot.starter.dataflow.dto.OperationResultDto> updateMappingState(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.dataflow.dto.DataFlowMappingStateUpdateDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.boot.starter.dataflow.dto.DataFlowRtMappingDto> selectDetailByCondition(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.dataflow.dto.DataFlowOriginalMappingQueryDto>);
```

### `DeductionRtRuleAppService`（5 方法）

`com.seeyon.boot.starter.deduction.api.DeductionRtRuleAppService`

```java
    com.seeyon.boot.transport.ListResponse<com.seeyon.boot.starter.deduction.dto.DeductionRtRuleCategoryDto> selectRtRuleVersion(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.deduction.dto.DeductionRtRuleVersionIdQueryDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.boot.starter.deduction.dto.DeductionRtRuleDto> selectById(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.boot.starter.deduction.dto.DeductionRtInitDataDto> initData(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.deduction.dto.DeductionRtRuleVersionQueryDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.boot.starter.deduction.dto.DeductionSaveRuleNewVersionRespDto> saveRuleNewVersion(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.deduction.dto.DeductionRtRuleDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Boolean> enableRule(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
```

### `RuleDetailRtService`（4 方法）

`com.seeyon.boot.starter.deduction.detail.RuleDetailRtService`

```java
    boolean match(com.seeyon.ctp.metadata.dto.EntityMetadataDto);
    boolean secondaryStatus();
    com.seeyon.udc.common.enums.DeductionFieldTypeEnum getType();
    java.util.List<com.seeyon.udc.common.dto.DeductionBillStatusInfoDto> generateTypeDataList(com.seeyon.ctp.metadata.dto.AggEntityMetadataDto);
```

### `DataFlowForBpmAppService`（2 方法）

`com.seeyon.boot.starter.dataflow.api.DataFlowForBpmAppService`

```java
    com.seeyon.boot.transport.SingleResponse<java.lang.Void> asyncTriggerFlowForBpm(com.seeyon.boot.transport.SingleRequest<com.seeyon.bpm.dto.BpmTriggerFlowUdcFinishDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Boolean> fillErrorFlowData(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.dataflow.dto.FillFlowReqDto>);
```

### `DataFlowMapAppService`（2 方法）

`com.seeyon.boot.starter.dataflow.api.DataFlowMapAppService`

```java
    com.seeyon.boot.transport.ListResponse<com.seeyon.boot.starter.dataflow.dto.DataFlowRtMapDto> selectByCondition(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.dataflow.dto.DataFlowRtMapQueryDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.boot.starter.dataflow.dto.DataFlowRtMapDto> selectById(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
```

### `DataFlowIdMappingBaseDao`（2 方法）

`com.seeyon.boot.starter.dataflow.domain.dao.DataFlowIdMappingBaseDao`

```java
    default void setDelFlagBySourcePrimaryDataId(java.lang.Long);
    default void setDelFlagByTargetPrimaryDataId(java.lang.Long);
```

### `DeductionRtMapAppService`（2 方法）

`com.seeyon.boot.starter.deduction.api.DeductionRtMapAppService`

```java
    com.seeyon.boot.transport.ListResponse<com.seeyon.boot.starter.deduction.dto.DeductionRtMapSimpleDto> selectSimpleDeductionMap(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.boot.starter.deduction.dto.DeductionRtMapDto> selectById(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
```

### `DeductionUpdateMapper`（2 方法）

`com.seeyon.boot.starter.deduction.provider.DeductionUpdateMapper`

```java
    int update4Deduction(java.util.Map<java.lang.String, java.lang.Object>);
    java.util.List<java.util.Map<java.lang.String, java.lang.Object>> select4Deduction(java.util.Map<java.lang.String, java.lang.Object>);
```

### `UdcRuleAppService`（1 方法）

`com.seeyon.boot.starter.dataflow.api.UdcRuleAppService`

```java
    default com.seeyon.boot.transport.SingleResponse<com.seeyon.udc.common.dto.QueryRuleResultDto> selectRuleByEntity(com.seeyon.boot.transport.SingleRequest<com.seeyon.udc.common.dto.QueryRuleByEntityDto>);
```

### `DeductionRtMapDao`（1 方法） extends DeductionRtMap>

`com.seeyon.boot.starter.deduction.domain.dao.DeductionRtMapDao`

```java
    java.util.List<java.lang.Long> getTotalMap();
```

### `DataFlowRtMapDao`（0 方法） extends DataFlowRtMap>

`com.seeyon.boot.starter.dataflow.domain.dao.DataFlowRtMapDao`

```java
```

### `DataFlowRtMappingDao`（0 方法） extends DataFlowRtMapping>

`com.seeyon.boot.starter.dataflow.domain.dao.DataFlowRtMappingDao`

```java
```

### `DeductionIdMappingDao`（0 方法） extends DeductionIdMapping>

`com.seeyon.boot.starter.deduction.domain.dao.DeductionIdMappingDao`

```java
```

### `DeductionRtAlgorithmDao`（0 方法） extends DeductionRtAlgorithm>

`com.seeyon.boot.starter.deduction.domain.dao.DeductionRtAlgorithmDao`

```java
```

### `DeductionRtRuleDao`（0 方法） extends DeductionRtRule>

`com.seeyon.boot.starter.deduction.domain.dao.DeductionRtRuleDao`

```java
```

### `DeductionRtRuleDetailDao`（0 方法） extends DeductionRtRuleDetail>

`com.seeyon.boot.starter.deduction.domain.dao.DeductionRtRuleDetailDao`

```java
```

## 二、关键类（24）

### `DataFlowMappingService`（82 方法）

`com.seeyon.boot.starter.dataflow.domain.service.DataFlowMappingService`

```java
    boolean existDataFlow(com.seeyon.udc.common.dto.QueryRuleByEntityDto);
    java.util.List<com.seeyon.boot.starter.dataflow.dto.DataFlowRtMappingDto> selectOriginalMappingList(com.seeyon.boot.starter.dataflow.dto.OriginalDataFlowMappingListQueryDto);
    java.lang.Long create(com.seeyon.boot.starter.dataflow.dto.DataFlowRtMappingDto);
    int createBatch(java.util.List<com.seeyon.boot.starter.dataflow.dto.DataFlowRtMappingDto>);
    int deleteByAppId(java.lang.Long);
    int deleteByDataFlowMapId(java.util.List<java.lang.Long>);
    void checkNull(java.lang.Object);
    com.seeyon.boot.starter.dataflow.dto.DataFlowRtMappingDto selectById(java.lang.Long);
    private com.seeyon.udc.common.dto.DataFlowMappingFrontendConditionAttrDto convertFrontCondition(com.seeyon.udc.common.dto.DataFlowMappingUpdateConditionDto);
    java.util.Map<java.lang.String, java.util.Set<java.lang.String>> loadOriginalMappingAreaSourceEntity(com.seeyon.boot.starter.dataflow.dto.DataFlowRtMappingDto, java.util.Map<java.lang.String, com.seeyon.udc.common.dto.DataFlowEntityDto>);
    private void addScalabilityEntity(java.util.Set<java.lang.String>, java.util.Map<java.lang.String, com.seeyon.udc.common.dto.DataFlowEntityDto>);
    com.seeyon.boot.starter.dataflow.dto.DataFlowRtEditInitialDataDto selectMappingInitData(com.seeyon.udc.common.dto.DataFlowMappingInitQueryDto);
    private void setScalabilityField(com.seeyon.udc.common.dto.DataFlowEntityDto, java.util.Map<java.lang.String, com.seeyon.udc.common.dto.DataFlowEntityDto>);
    private java.util.Map<java.lang.String, java.util.List<java.lang.String>> getTargetSourceMappings();
    void supplementExtEntity4Query(com.seeyon.boot.starter.dataflow.dto.DataFlowRtMappingDto, java.util.List<java.lang.String>, java.util.List<java.lang.String>);
    com.seeyon.boot.starter.dataflow.dto.DataFlowRtMappingDto selectOriginalMapping(com.seeyon.boot.starter.dataflow.dto.DataFlowOriginalMappingQueryDto);
    private void convertMappingInfo(com.seeyon.boot.starter.dataflow.dto.DataFlowRtMappingDto);
    private java.util.Set<java.lang.String> findSourceEntityName(java.util.List<com.seeyon.udc.common.dto.DataFlowMappingRowDto>, java.util.Set<java.lang.String>);
    private void convertFormula(com.seeyon.udc.common.dto.DataFlowMappingDetailDto);
    private void copyEntityInfo(com.seeyon.boot.starter.dataflow.dto.DataFlowRtMappingDto, java.util.Map<java.lang.String, com.seeyon.udc.common.dto.DataFlowEntityDto>);
    private void convertUpdateMappingCondition(com.seeyon.boot.starter.dataflow.dto.DataFlowRtMappingDto, java.util.Map<java.lang.String, com.seeyon.udc.common.dto.DataFlowEntityDto>);
    private java.util.List<com.seeyon.boot.starter.dynamicsql.dto.JoinAliasDto> convertJoinParam(java.util.Map<java.lang.String, com.seeyon.udc.common.dto.DataFlowEntityDto>, com.seeyon.boot.starter.dataflow.dto.DataFlowRtMappingDto, com.seeyon.udc.common.dto.DataFlowMappingAreaDto, java.util.Map<java.lang.String, java.lang.String>);
    private void recursionSourceParentJoin(com.seeyon.udc.common.dto.DataFlowEntityDto, java.util.Map<java.lang.String, java.lang.String>, java.util.Map<java.lang.String, com.seeyon.boot.starter.dynamicsql.dto.JoinAliasDto>);
    private void recursionTargetParentJoin(com.seeyon.udc.common.dto.DataFlowEntityDto, java.util.Map<java.lang.String, java.lang.String>, java.util.Map<java.lang.String, com.seeyon.boot.starter.dynamicsql.dto.JoinAliasDto>);
    private com.seeyon.boot.starter.dynamicsql.dto.JoinAliasDto newJoinParamDto(java.lang.String);
    private void orderJoinParams(com.seeyon.udc.common.dto.DataFlowEntityDto, java.util.List<com.seeyon.boot.starter.dynamicsql.dto.JoinAliasDto>, java.util.Map<java.lang.String, com.seeyon.boot.starter.dynamicsql.dto.JoinAliasDto>);
    java.util.List<java.lang.Long> dynamicJoinSelect(com.seeyon.boot.starter.dataflow.dto.DataFlowRtMappingDto, java.lang.String, boolean, java.util.List<java.lang.Long>);
    private void transferListSchema(com.seeyon.boot.starter.dataflow.dto.DataFlowRtMappingDto, com.seeyon.boot.starter.dataflow.dto.DataFlowOriginalMappingQueryDto);
    private com.seeyon.ctp.metadata.dto.ReferMetadataDto findEntityRefer(java.util.List<com.seeyon.ctp.metadata.dto.ReferMetadataDto>, java.util.Set<java.lang.String>);
    com.seeyon.boot.starter.dataflow.dto.OperationResultDto updateMappingState(com.seeyon.boot.starter.dataflow.dto.DataFlowMappingStateUpdateDto);
    com.seeyon.boot.starter.dataflow.dto.DataFlowRtMappingDto update(com.seeyon.boot.starter.dataflow.dto.DataFlowRtMappingSaveDto);
    private void mergeMappingArea(com.seeyon.udc.common.dto.DataFlowMappingAreaDto, com.seeyon.udc.common.dto.DataFlowMappingAreaDto);
```

### `DeductionRtUtil`（51 方法）

`com.seeyon.boot.starter.deduction.util.DeductionRtUtil`

```java
    static com.seeyon.boot.starter.deduction.dto.DeductionRtAlgorithmDto findAlgorithm(com.seeyon.boot.starter.deduction.dto.DeductionRtRuleDetailDto, java.util.List<com.seeyon.boot.starter.deduction.dto.DeductionRtAlgorithmDto>);
    static com.seeyon.boot.starter.deduction.dto.DeductionRtAlgorithmDto findAlgorithm(java.lang.String, java.util.List<com.seeyon.boot.starter.deduction.dto.DeductionRtAlgorithmDto>);
    static void checkAlgorithmSourceFieldNull(java.util.Map<java.lang.String, java.lang.Object>, com.seeyon.boot.starter.deduction.dto.DeductionRtAlgorithmDto);
    static void checkAlgorithmTargetFieldNull(java.util.Map<java.lang.String, java.lang.Object>, com.seeyon.boot.starter.deduction.dto.DeductionRtAlgorithmDto);
    static private static java.util.Map<java.lang.String, java.lang.String> getEntityAndAttributeFromExpressionToken(java.lang.String);
    static java.util.Map<java.lang.String, java.util.Set<java.lang.String>> getEntityAndAttributeMapFromFormula(com.seeyon.boot.starter.formula.dto.ExpressionDefinitionDto);
    static com.seeyon.udc.common.dto.DeductionFieldDto getDeductionFieldDto(com.seeyon.ctp.metadata.dto.AggEntityMetadataDto, com.seeyon.ctp.metadata.dto.EntityAttributeMetadataDto);
    static void checkResponse(com.seeyon.boot.transport.BaseResponse);
    static java.lang.String transferSearchCondition4Log(com.seeyon.boot.starter.deduction.dto.DeductionRtRuleDto);
    static boolean isSearchConditionChanged(java.lang.Object, java.lang.Object, com.seeyon.boot.starter.deduction.dto.DeductionRtRuleDto);
    static boolean isCheckRuleChanged(java.lang.Object, java.lang.Object, java.lang.String, com.seeyon.boot.starter.deduction.dto.DeductionRtAlgorithmDto);
    static boolean isSourceAlgorithmFieldChanged(java.lang.Object, java.lang.Object, java.lang.String, com.seeyon.boot.starter.deduction.dto.DeductionRtAlgorithmDto);
    static private static boolean isValueHasChanged(java.lang.Object, java.lang.Object, java.util.Set<java.lang.String>);
    static java.lang.String getSelectSql(com.seeyon.udc.common.dto.DeductionSqlStatementDto);
    static java.lang.String getUpdateSql(com.seeyon.udc.common.dto.DeductionSqlStatementDto, boolean);
    static com.seeyon.boot.starter.dynamicsql.dto.ProxyJoinParamDto getProxyParamDto(com.seeyon.boot.starter.deduction.dto.DeductionUpdateParamDto, java.util.Map<java.lang.String, java.lang.Object>);
    static private static void addAlgorithmTargetField2Map(java.util.Map<java.lang.String, java.util.Set<java.lang.String>>, com.seeyon.boot.starter.deduction.dto.DeductionUpdateParamDto);
    static java.util.List<com.seeyon.boot.starter.dynamicsql.dto.JoinParamDto> getJoinParamDtoList(com.seeyon.boot.starter.deduction.dto.DeductionUpdateParamDto$EntityDesc);
    static void getJoinParamDtoList(com.seeyon.boot.starter.deduction.dto.DeductionUpdateParamDto$EntityDesc, com.seeyon.boot.starter.deduction.dto.DeductionUpdateParamDto$EntityDesc, java.util.List<com.seeyon.boot.starter.dynamicsql.dto.JoinParamDto>);
    static java.util.Map<java.lang.String, java.util.Set<java.lang.String>> getFieldMap(com.seeyon.udc.common.dto.DeductionSqlStatementDto, java.util.List<java.lang.String>);
    static private static java.util.List<java.lang.String> getEntityFullNameList(com.seeyon.boot.starter.deduction.dto.DeductionUpdateParamDto$EntityDesc);
    static private static java.util.List<java.lang.String> getEntityNameList(com.seeyon.boot.starter.deduction.dto.DeductionUpdateParamDto$EntityDesc);
    static com.seeyon.boot.starter.dynamicsql.dto.DynamicConditionDto getDynamicConditionDto(com.seeyon.boot.starter.deduction.dto.DeductionUpdateParamDto, java.util.Map<java.lang.String, java.lang.Object>);
    static void fillCondition(com.seeyon.boot.starter.deduction.dto.DeductionUpdateParamDto, java.util.Map<java.lang.String, java.lang.Object>, java.util.List<java.util.Map<java.lang.String, java.lang.Object>>);
    static java.lang.Object parseValue(java.lang.String, java.util.Map<java.lang.String, java.lang.Object>);
    static private static java.lang.Object parseValue(java.lang.Object);
    static java.lang.String underlineToCamel(java.lang.String);
```

### `DeductionRtRuleService`（42 方法）

`com.seeyon.boot.starter.deduction.domain.service.DeductionRtRuleService`

```java
    com.seeyon.boot.starter.deduction.dto.DeductionRtRuleDto selectEffectiveRuleInfoByOriginalId(java.lang.Long);
    private com.seeyon.boot.starter.deduction.dto.DeductionRtRuleDto fillDto(com.seeyon.boot.starter.deduction.domain.entity.DeductionRtRule);
    static com.seeyon.boot.starter.deduction.dto.DeductionRtRuleDto entityToDto(com.seeyon.boot.starter.deduction.domain.entity.DeductionRtRule);
    com.seeyon.boot.starter.deduction.dto.DeductionRtRuleDto selectReferencedRule(java.lang.Long, java.lang.Long);
    com.seeyon.boot.starter.deduction.dto.DeductionRtRuleDto selectDetailById(java.lang.Long);
    java.util.List<com.seeyon.boot.starter.deduction.dto.DeductionRtRuleDto> selectByIds(java.util.List<java.lang.Long>);
    com.seeyon.boot.starter.deduction.dto.DeductionRtRuleDto selectById(java.lang.Long);
    private java.util.List<com.seeyon.boot.starter.deduction.dto.DeductionRtRuleDto> convertToDtoList(java.util.List<com.seeyon.boot.starter.deduction.domain.entity.DeductionRtRule>);
    static java.util.List<com.seeyon.boot.starter.deduction.dto.DeductionRtRuleDetailDto> unionDescartes(java.util.List<com.seeyon.boot.starter.deduction.dto.DeductionRtRuleDetailDto>, java.util.List<com.seeyon.boot.starter.deduction.dto.DeductionRtRuleDetailDto>, java.util.function.BiPredicate<com.seeyon.boot.starter.deduction.dto.DeductionRtRuleDetailDto, com.seeyon.boot.starter.deduction.dto.DeductionRtRuleDetailDto>);
    java.util.List<com.seeyon.boot.starter.deduction.dto.DeductionRtRuleCategoryDto> selectRtRuleVersion(com.seeyon.boot.starter.deduction.dto.DeductionRtRuleVersionIdQueryDto);
    com.seeyon.boot.starter.deduction.dto.DeductionRtInitDataDto initData(com.seeyon.boot.starter.deduction.dto.DeductionRtRuleVersionQueryDto);
    com.seeyon.boot.starter.deduction.dto.DeductionSaveRuleNewVersionRespDto saveRuleNewVersion(com.seeyon.boot.starter.deduction.dto.DeductionRtRuleDto);
    private java.lang.String getLatestVersionNumber(java.lang.Long);
    private java.lang.String getVersionNumber(java.lang.String);
    boolean enableRule(java.lang.Long);
    java.lang.Long getRuleIdFromAlgorithmId(java.lang.Long);
    private boolean isSameVersion(java.lang.String, java.lang.String);
    private com.seeyon.udc.common.dto.DataFlowEntityDto category(com.seeyon.udc.common.dto.DataFlowEntityDto, java.util.Map<java.lang.Long, com.seeyon.udc.common.dto.DataFlowEntityDto>);
    private void loadSourceNumberAttrEntityMap(java.util.Map<java.lang.String, com.seeyon.udc.common.dto.DataFlowEntityDto>, java.util.List<com.seeyon.udc.common.dto.DataFlowEntityDto>);
    private void loadTargetNumberAttrEntityMap(java.util.Map<java.lang.String, com.seeyon.udc.common.dto.DataFlowEntityDto>, java.util.List<com.seeyon.udc.common.dto.DataFlowEntityDto>);
    private java.util.Map<java.lang.String, com.seeyon.udc.common.dto.DataFlowAttributeDto> getIncludeNumberAttribute(java.util.Collection<com.seeyon.udc.common.dto.DataFlowAttributeDto>);
    private java.util.function.Predicate<com.seeyon.udc.common.dto.DataFlowAttributeDto> filterAttributeDto();
    private boolean isNumericDataType(com.seeyon.udc.common.dto.DataFlowAttributeDto);
    private void resetBaseEntity(com.seeyon.boot.domain.entity.BaseEntity);
    java.util.List<com.seeyon.boot.starter.deduction.domain.entity.DeductionRtRule> selectAllEffectiveRule();
    java.lang.String getEffectiveRuleCacheName(java.lang.Long);
    boolean existDeduction(com.seeyon.udc.common.dto.QueryRuleByEntityDto);
```

### `DataFlowBaseDataService`（30 方法）

`com.seeyon.boot.starter.dataflow.domain.service.DataFlowBaseDataService`

```java
    java.util.Map<java.lang.String, com.seeyon.udc.common.dto.DataFlowEntityDto> selectEntityMapByMappingDto(com.seeyon.boot.starter.dataflow.dto.DataFlowRtMappingDto, boolean, boolean, boolean, boolean);
    java.util.List<com.seeyon.udc.common.dto.DataFlowEntityDto> selectEntityListByAggEntityFullNames(com.seeyon.udc.common.dto.SearchEntityByFullNamesDto);
    java.util.List<com.seeyon.udc.common.dto.DataFlowEntityDto> selectEntityListByAggEntityFullNames(com.seeyon.udc.common.dto.SearchEntityByFullNamesDto, boolean);
    java.util.List<com.seeyon.udc.common.dto.DataFlowEntityDto> loadEntity(java.util.List<com.seeyon.ctp.metadata.dto.AggEntityMetadataDto>, com.seeyon.udc.common.dto.LoadEntityParamDto, boolean);
    private void loadChildrenEntity(com.seeyon.ctp.metadata.dto.AggEntityMetadataDto, com.seeyon.udc.common.dto.DataFlowEntityDto, java.util.List<com.seeyon.udc.common.dto.DataFlowEntityDto>, com.seeyon.udc.common.dto.LoadEntityParamDto, boolean);
    private com.seeyon.udc.common.dto.DataFlowEntityDto convert2EntityDto(com.seeyon.ctp.metadata.dto.AggEntityMetadataDto, com.seeyon.udc.common.dto.LoadEntityParamDto, boolean);
    private void setCustomAttribute(com.seeyon.udc.common.dto.DataFlowAttributeDto, java.util.Map<java.lang.String, java.lang.Object>);
    java.util.Map<java.lang.String, java.util.List<com.seeyon.ctp.metadata.dto.ReferMetadataDto>> selectReferMetadataByEntity(com.seeyon.ctp.metadata.dto.request.SearchByFullNamesDto);
    java.util.List<com.seeyon.udc.common.dto.DataFlowEnumDto> selectJavaEnumByFullNames(java.lang.String, java.util.List<java.lang.String>);
    private com.seeyon.udc.common.dto.DataFlowEnumDto convertJavaEnum(com.seeyon.ctp.metadata.dto.EnumMetadataDto);
    java.util.Map<java.lang.String, java.util.List<com.seeyon.boot.starter.enums.dto.CtpEnumItemDto>> selectCtpEnumItem(java.lang.String, java.util.Map<java.lang.String, java.util.Set<java.lang.String>>);
```

### `DataFlowRuntimeEntityParamExprServiceImpl`（28 方法）

`com.seeyon.boot.starter.dataflow.domain.service.DataFlowRuntimeEntityParamExprServiceImpl`

```java
    java.util.List<com.seeyon.boot.starter.formula.dto.variable.SchemaStructureDto> loadParamSchemaInfo(com.seeyon.boot.starter.formula.dto.variable.VariableSchemaLoadDto);
    private void getFilterEntity(java.util.List<com.seeyon.udc.common.dto.DataFlowEntityDto>, java.util.Set<java.lang.String>, java.lang.String, java.lang.String);
    private java.util.Map<java.lang.String, com.seeyon.udc.common.dto.DataFlowEnumDto> selectJavaEnum(java.util.List<com.seeyon.udc.common.dto.DataFlowEntityDto>, java.util.Set<java.lang.String>);
    private void recursionFindJavaEnum(java.util.Map<java.lang.String, java.util.Set<java.lang.String>>, java.util.List<com.seeyon.udc.common.dto.DataFlowEntityDto>, java.util.Set<java.lang.String>);
    void getSchemaStructureDtoByEntity(java.util.List<com.seeyon.boot.starter.formula.dto.variable.SchemaStructureDto>, java.util.List<com.seeyon.udc.common.dto.DataFlowEntityDto>, java.util.Set<java.lang.String>);
    private void recursionBuildSchemaStruct(java.util.List<com.seeyon.boot.starter.formula.dto.variable.SchemaStructureDto>, com.seeyon.udc.common.dto.DataFlowEntityDto, java.util.Set<java.lang.String>, java.util.Map<java.lang.String, com.seeyon.udc.common.dto.DataFlowEnumDto>);
    private void assembleSchema(com.seeyon.boot.starter.formula.dto.variable.SchemaStructureDto, com.seeyon.udc.common.dto.DataFlowEntityDto, java.util.Map<java.lang.String, com.seeyon.udc.common.dto.DataFlowEnumDto>);
    private void convertProperties(com.seeyon.udc.common.dto.DataFlowEntityDto, java.util.List<com.seeyon.boot.starter.formula.dto.variable.SchemaStructureDto>, java.util.Map<java.lang.String, com.seeyon.udc.common.dto.DataFlowEnumDto>);
```

### `DataFlowRtUtil`（22 方法）

`com.seeyon.boot.starter.dataflow.util.DataFlowRtUtil`

```java
    static <T, k> java.util.List<T> cacheData(java.util.List<T>, java.util.List<T>, java.util.function.Function<T, k>);
    static java.util.Map<java.util.Map<java.lang.String, java.lang.Object>, java.util.List<java.util.Map<java.lang.String, java.lang.Object>>> getGroupData(com.seeyon.boot.starter.dataflow.dto.DataFlowRtMappingDto, java.lang.String, java.util.List<java.util.Map<java.lang.String, java.lang.Object>>);
    static java.util.Map<java.util.Map<java.lang.String, java.lang.Object>, java.util.List<java.util.Map<java.lang.String, java.lang.Object>>> groupFlatDataByField(java.util.List<java.util.Map<java.lang.String, java.lang.Object>>, java.lang.String[]);
    static private static <T> void removeDtoByIds(java.util.List<T>, java.util.Set<java.lang.String>, java.util.List<java.util.Map<java.lang.String, java.lang.Object>>, java.lang.String);
    static <T> void filterSourceSubDto(java.util.List<T>, com.seeyon.udc.common.dto.SourceDataDto, java.util.Set<java.lang.String>);
    static com.seeyon.udc.common.dto.DataFlowExecuteParamDto getDataFlowExecuteParamDto(java.util.List<java.lang.Long>, java.lang.String);
    static void dynamicAssignmentByMappingRow(com.seeyon.boot.starter.dataflow.dto.DataFlowRtMappingDto, java.lang.String, java.lang.Object, java.util.Map<java.lang.String, java.lang.Object>, java.util.List<java.util.Map<java.lang.String, java.lang.Object>>, com.seeyon.udc.common.dto.DynamicExecuteExtendDto);
    static void dynamicCopyValueByMappingRow(com.seeyon.boot.starter.dataflow.dto.DataFlowRtMappingDto, java.lang.String, java.lang.Object, java.lang.Object);
    static void recalculateMappingRow(com.seeyon.boot.starter.dataflow.dto.DataFlowRtMappingDto, java.lang.String, java.lang.Object, java.util.Map<java.lang.String, java.lang.Object>, com.seeyon.udc.common.dto.DynamicExecuteExtendDto);
    static void dynamicIdMappingUpdate(java.util.Map<java.lang.Long, java.util.List<com.seeyon.udc.common.dto.DataFlowIdMappingBaseDto>>, java.util.Map<java.lang.Long, java.util.List<com.seeyon.udc.common.dto.DataFlowIdMappingBaseDto>>, java.util.Set<java.lang.Long>, com.seeyon.boot.starter.dataflow.dto.DataFlowRtMappingDto, java.lang.String, com.seeyon.udc.common.dto.BaseEntityActionDto, com.seeyon.udc.common.dto.BaseEntityActionDto, com.seeyon.udc.common.dto.BaseEntityActionDto);
    static boolean isValid(java.lang.Long);
    static <T extends com.seeyon.udc.common.dto.BaseEntityActionDto> void addEmptyFields(T, java.lang.String, java.lang.Object);
```

### `DataFlowRtCheckUtil`（14 方法）

`com.seeyon.boot.starter.dataflow.util.DataFlowRtCheckUtil`

```java
    static void checkResponse(com.seeyon.boot.transport.BaseResponse);
    static void assertMetadataNull(java.lang.Object, java.lang.String);
    static void assertNull(java.lang.Object, java.lang.String);
    static void dataCheckBeforeMerge(com.seeyon.boot.starter.dataflow.dto.DataFlowRtMappingDto, java.util.List<com.seeyon.udc.common.dto.DataFlowMappingAreaDto>, java.util.Map<java.lang.String, com.seeyon.udc.common.dto.DataFlowEntityDto>, java.util.Map<java.lang.String, java.util.List<java.lang.String>>);
    static void dataCheckAfterMerge(java.util.Map<java.lang.String, com.seeyon.udc.common.dto.DataFlowEntityDto>, com.seeyon.boot.starter.dataflow.dto.DataFlowRtMappingDto);
    static private static void dataCheck4KeyAttribute(com.seeyon.udc.common.dto.DataFlowMappingRuleDto, java.util.Map<java.lang.String, com.seeyon.udc.common.dto.DataFlowEntityDto>, com.seeyon.boot.starter.dataflow.dto.DataFlowRtMappingDto);
    static private static void dataCheck4Field(com.seeyon.udc.common.dto.DataFlowMappingFieldDto, java.util.Map<java.lang.String, com.seeyon.udc.common.dto.DataFlowEntityDto>, com.seeyon.udc.common.dto.DataFlowEntityDto);
    static private static void dataCheck4MappingMode(com.seeyon.udc.common.dto.DataFlowMappingRowDto, com.seeyon.udc.common.dto.DataFlowMappingRuleDto, java.util.Map<java.lang.String, com.seeyon.udc.common.dto.DataFlowEntityDto>, java.util.Map<java.lang.String, java.util.List<java.lang.String>>);
    static private static com.seeyon.boot.starter.i18n.MessageRepository getMessageRepository();
```

### `DeductionIdMappingService`（12 方法）

`com.seeyon.boot.starter.deduction.domain.service.DeductionIdMappingService`

```java
    int operatorIdMapping(java.util.List<com.seeyon.boot.starter.deduction.dto.DeductionIdMappingDto>, java.util.List<com.seeyon.boot.starter.deduction.dto.DeductionIdMappingDto>);
    java.util.List<java.lang.Long> createBatch(java.util.List<com.seeyon.boot.starter.deduction.dto.DeductionIdMappingDto>);
    int updateBatch(java.util.List<com.seeyon.boot.starter.deduction.dto.DeductionIdMappingDto>);
    int deleteByIds(java.util.List<java.lang.Long>);
    int deleteByTargetIdList(java.util.List<java.lang.Long>);
    int deleteByTargetPrimaryDataId(java.lang.Long);
    java.util.List<com.seeyon.boot.starter.deduction.dto.DeductionIdMappingDto> selectByQueryDto(com.seeyon.boot.starter.deduction.dto.DeductionIdMappingQueryDto);
    java.util.List<com.seeyon.boot.starter.deduction.dto.DeductionIdMappingDto> selectByTargetPrimaryDataId(java.lang.Long);
    java.util.List<com.seeyon.boot.starter.deduction.dto.DeductionIdMappingDto> selectListByWrapper(com.seeyon.boot.domain.dao.Wrapper);
```

### `DataFlowMapService`（10 方法）

`com.seeyon.boot.starter.dataflow.domain.service.DataFlowMapService`

```java
    java.util.List<com.seeyon.boot.starter.dataflow.dto.DataFlowRtMapDto> selectByCondition(com.seeyon.boot.starter.dataflow.dto.DataFlowRtMapQueryDto);
    com.seeyon.boot.starter.dataflow.dto.DataFlowRtMapDto selectById(java.lang.Long);
    private void checkNull(com.seeyon.boot.starter.dataflow.domain.entity.DataFlowRtMap);
    java.lang.Long create(com.seeyon.boot.starter.dataflow.dto.DataFlowRtMapDto);
    int createBatch(java.util.List<com.seeyon.boot.starter.dataflow.dto.DataFlowRtMapDto>);
    int deleteById(java.lang.Long);
    int deleteByIds(java.util.List<java.lang.Long>);
    int deleteByAppId(java.lang.Long);
```

### `DataFlowBaseService`（9 方法）

`com.seeyon.boot.starter.dataflow.domain.service.DataFlowBaseService`

```java
    <T extends com.seeyon.udc.common.dto.BaseRootDto> java.util.List<T> cacheRootData(java.util.List<T>, java.util.List<T>);
    <T extends com.seeyon.udc.common.dto.BaseRootDto> T cacheRootData(java.util.List<T>, T);
    java.util.Map<java.lang.String, java.lang.Object> toParameterMap(java.util.Map<java.lang.String, java.lang.Object>);
    <T extends com.seeyon.udc.common.dto.BaseDetailDto> java.util.List<T> toMapList(java.util.List<T>, java.lang.Class<T>);
```

### `DataFlowIdMappingBaseService`（9 方法）

`com.seeyon.boot.starter.dataflow.domain.service.DataFlowIdMappingBaseService`

```java
    void create(com.seeyon.boot.starter.dataflow.dto.DataFlowIdMappingBaseDto);
    int deleteByIds(java.util.List<java.lang.Long>);
    java.util.List<java.lang.Long> createBatch(java.util.List<com.seeyon.boot.starter.dataflow.dto.DataFlowIdMappingBaseDto>);
    java.util.List<java.lang.Long> createBatch(java.util.List<com.seeyon.boot.starter.dataflow.dto.DataFlowIdMappingBaseDto>, boolean);
    java.util.List<com.seeyon.boot.starter.dataflow.dto.DataFlowIdMappingBaseDto> selectByTargetPrimaryDataId(java.lang.Long);
    java.util.List<T> selectBySourceAndTargetDataId(java.util.List<com.seeyon.boot.starter.dataflow.dto.DataFlowIdMappingBaseDto>);
    java.util.Map<java.lang.Long, java.util.List<com.seeyon.boot.starter.dataflow.dto.DataFlowIdMappingBaseDto>> groupBySourcePrimaryDataId(java.util.List<com.seeyon.boot.starter.dataflow.dto.DataFlowIdMappingBaseDto>);
```

### `DeductionRtAlgorithmService`（9 方法）

`com.seeyon.boot.starter.deduction.domain.service.DeductionRtAlgorithmService`

```java
    java.util.List<com.seeyon.boot.starter.deduction.dto.DeductionRtAlgorithmSimpleDto> selectSimpleAlgorithmByDeductionRuleIds(java.util.List<java.lang.Long>);
    java.util.List<com.seeyon.boot.starter.deduction.dto.DeductionRtAlgorithmDto> selectByIds(java.util.List<java.lang.Long>);
    java.util.List<com.seeyon.boot.starter.deduction.dto.DeductionRtAlgorithmDto> selectByRuleId(java.lang.Long);
    java.util.List<com.seeyon.boot.starter.deduction.dto.DeductionRtAlgorithmDto> selectPropertiesByRuleId(java.lang.Long);
    java.util.List<com.seeyon.boot.starter.deduction.dto.DeductionRtAlgorithmDto> selectByRuleIds(java.util.List<java.lang.Long>);
    java.util.List<com.seeyon.boot.starter.deduction.dto.DeductionRtAlgorithmDto> selectListBycConditions(java.util.Map<java.lang.String, java.lang.Object>, com.seeyon.boot.transport.Sort);
    private java.util.List<com.seeyon.boot.starter.deduction.dto.DeductionRtAlgorithmDto> selectListPropertiesByConditions(java.util.Map<java.lang.String, java.lang.Object>, com.seeyon.boot.transport.Sort);
    static com.seeyon.boot.starter.deduction.dto.DeductionRtAlgorithmDto entityToDto(com.seeyon.boot.starter.deduction.domain.entity.DeductionRtAlgorithm);
```

### `DataFlowIdMappingNewBaseService`（8 方法）

`com.seeyon.boot.starter.dataflow.domain.service.DataFlowIdMappingNewBaseService`

```java
    void create(com.seeyon.udc.common.dto.DataFlowIdMappingBaseDto);
    int deleteByIds(java.util.List<java.lang.Long>);
    java.util.List<java.lang.Long> createBatch(java.util.List<com.seeyon.udc.common.dto.DataFlowIdMappingBaseDto>);
    java.util.List<java.lang.Long> createBatch(java.util.List<com.seeyon.udc.common.dto.DataFlowIdMappingBaseDto>, boolean);
    java.util.List<com.seeyon.udc.common.dto.DataFlowIdMappingBaseDto> selectByTargetPrimaryDataId(java.lang.Long);
    java.util.List<T> selectBySourceAndTargetDataId(java.util.List<com.seeyon.udc.common.dto.DataFlowIdMappingBaseDto>);
```

### `MessageInterfaceService`（8 方法）

`com.seeyon.boot.starter.dataflow.domain.service.MessageInterfaceService`

```java
    boolean invokeBpmFailAndNoPending(java.lang.String);
    java.util.Map<java.lang.Long, com.seeyon.organization.dto.core.OrgMemberCoreDto> selectMemberByIds(java.util.List<java.lang.Long>);
    com.seeyon.ctp.message.dto.MessageSendDto buildMessageDto(com.seeyon.bpm.dto.approval.BpmTriggerFlowUdcResponseDto, java.util.Map<java.lang.Long, com.seeyon.organization.dto.core.OrgMemberCoreDto>, java.util.Map<java.lang.Long, java.lang.Long>, java.util.Map<java.lang.String, java.lang.Object>);
    com.seeyon.ctp.message.dto.MessageSendDto buildMessageDto(com.seeyon.bpm.dto.approval.BpmTriggerFlowUdcResponseDto, java.util.Map<java.lang.Long, com.seeyon.organization.dto.core.OrgMemberCoreDto>, java.util.Map<java.lang.String, java.lang.Object>);
    java.util.List<java.lang.String> sendMessage(java.util.List<com.seeyon.ctp.message.dto.MessageSendDto>);
    void sendMessage(com.seeyon.boot.starter.dataflow.dto.DataFlow4BpmReqDto);
    void batchSentMessage(java.util.List<com.seeyon.boot.starter.dataflow.dto.DataFlow4BpmReqDto>);
```

### `DataFlowMappingAppServiceImpl`（6 方法）

`com.seeyon.boot.starter.dataflow.appservice.DataFlowMappingAppServiceImpl`

```java
    com.seeyon.boot.transport.ListResponse<com.seeyon.boot.starter.dataflow.dto.DataFlowRtMappingDto> selectOriginalMappingList(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.dataflow.dto.OriginalDataFlowMappingListQueryDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.boot.starter.dataflow.dto.DataFlowRtMappingDto> selectById(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.boot.starter.dataflow.dto.DataFlowRtEditInitialDataDto> selectMappingInitData(com.seeyon.boot.transport.SingleRequest<com.seeyon.udc.common.dto.DataFlowMappingInitQueryDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.boot.starter.dataflow.dto.DataFlowRtMappingDto> update(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.dataflow.dto.DataFlowRtMappingSaveDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.boot.starter.dataflow.dto.OperationResultDto> updateMappingState(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.dataflow.dto.DataFlowMappingStateUpdateDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.boot.starter.dataflow.dto.DataFlowRtMappingDto> selectDetailByCondition(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.dataflow.dto.DataFlowOriginalMappingQueryDto>);
```

### `DeductionRtRuleDetailService`（6 方法）

`com.seeyon.boot.starter.deduction.domain.service.DeductionRtRuleDetailService`

```java
    java.util.List<com.seeyon.boot.starter.deduction.dto.DeductionRtRuleDetailDto> selectByRuleIds(java.util.List<java.lang.Long>);
    java.util.List<com.seeyon.boot.starter.deduction.dto.DeductionRtRuleDetailDto> selectPropertiesByRuleId(java.lang.Long);
    private java.util.List<com.seeyon.boot.starter.deduction.dto.DeductionRtRuleDetailDto> selectListPropertiesByConditions(java.util.Map<java.lang.String, java.lang.Object>, com.seeyon.boot.transport.Sort);
    java.util.List<com.seeyon.boot.starter.deduction.dto.DeductionRtRuleDetailDto> selectListByConditions(java.util.Map<java.lang.String, java.lang.Object>, com.seeyon.boot.transport.Sort);
    static com.seeyon.boot.starter.deduction.dto.DeductionRtRuleDetailDto entityToDto(com.seeyon.boot.starter.deduction.domain.entity.DeductionRtRuleDetail);
```

### `DeductionRtRuleAppServiceImpl`（5 方法）

`com.seeyon.boot.starter.deduction.appservice.DeductionRtRuleAppServiceImpl`

```java
    com.seeyon.boot.transport.ListResponse<com.seeyon.boot.starter.deduction.dto.DeductionRtRuleCategoryDto> selectRtRuleVersion(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.deduction.dto.DeductionRtRuleVersionIdQueryDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.boot.starter.deduction.dto.DeductionRtRuleDto> selectById(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.boot.starter.deduction.dto.DeductionRtInitDataDto> initData(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.deduction.dto.DeductionRtRuleVersionQueryDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.boot.starter.deduction.dto.DeductionSaveRuleNewVersionRespDto> saveRuleNewVersion(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.deduction.dto.DeductionRtRuleDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Boolean> enableRule(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
```

### `BillStatusRuleDetailRtServiceImpl`（4 方法）

`com.seeyon.boot.starter.deduction.detail.BillStatusRuleDetailRtServiceImpl`

```java
    boolean match(com.seeyon.ctp.metadata.dto.EntityMetadataDto);
    boolean secondaryStatus();
    com.seeyon.udc.common.enums.DeductionFieldTypeEnum getType();
    java.util.List<com.seeyon.udc.common.dto.DeductionBillStatusInfoDto> generateTypeDataList(com.seeyon.ctp.metadata.dto.AggEntityMetadataDto);
```

### `SecondaryFieldInvalidRtServiceImpl`（4 方法）

`com.seeyon.boot.starter.deduction.detail.SecondaryFieldInvalidRtServiceImpl`

```java
    boolean match(com.seeyon.ctp.metadata.dto.EntityMetadataDto);
    boolean secondaryStatus();
    com.seeyon.udc.common.enums.DeductionFieldTypeEnum getType();
    java.util.List<com.seeyon.udc.common.dto.DeductionBillStatusInfoDto> generateTypeDataList(com.seeyon.ctp.metadata.dto.AggEntityMetadataDto);
```

### `SecondaryFieldSuspendRtServiceImpl`（4 方法）

`com.seeyon.boot.starter.deduction.detail.SecondaryFieldSuspendRtServiceImpl`

```java
    boolean match(com.seeyon.ctp.metadata.dto.EntityMetadataDto);
    boolean secondaryStatus();
    com.seeyon.udc.common.enums.DeductionFieldTypeEnum getType();
    java.util.List<com.seeyon.udc.common.dto.DeductionBillStatusInfoDto> generateTypeDataList(com.seeyon.ctp.metadata.dto.AggEntityMetadataDto);
```

### `SecondaryFieldTerminateRtServiceImpl`（4 方法）

`com.seeyon.boot.starter.deduction.detail.SecondaryFieldTerminateRtServiceImpl`

```java
    boolean match(com.seeyon.ctp.metadata.dto.EntityMetadataDto);
    boolean secondaryStatus();
    com.seeyon.udc.common.enums.DeductionFieldTypeEnum getType();
    java.util.List<com.seeyon.udc.common.dto.DeductionBillStatusInfoDto> generateTypeDataList(com.seeyon.ctp.metadata.dto.AggEntityMetadataDto);
```

### `RuleDescartesRtService`（4 方法）

`com.seeyon.boot.starter.deduction.domain.service.RuleDescartesRtService`

```java
    java.util.List<com.seeyon.boot.starter.deduction.dto.DeductionRtRuleDetailDto> generateDeductionRuleDetail(java.lang.String, java.lang.Long, java.lang.String);
    private com.seeyon.ctp.metadata.dto.AggEntityMetadataDto getEntityMetadataDto(java.lang.String, java.lang.String);
    void setApplicationContext(org.springframework.context.ApplicationContext)
    private void init();
```

### `BpmInterfaceService`（3 方法）

`com.seeyon.boot.starter.dataflow.domain.service.BpmInterfaceService`

```java
    com.seeyon.boot.transport.ListResponse<com.seeyon.bpm.dto.approval.BpmTriggerFlowUdcResponseDto> triggerFlowForUdc(com.seeyon.boot.transport.SingleRequest<java.util.List<com.seeyon.bpm.dto.approval.BpmTriggerFlowUdcRequestDto>>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Void> deleteCaseByIdForUdc(com.seeyon.boot.transport.SingleRequest<java.lang.Long>, com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    boolean asyncTriggerFlowForUdc(com.seeyon.bpm.dto.approval.BpmAsyncTriggerFlowUdcRequestDto);
```

### `DeductionUpgradeAppService`（3 方法）

`com.seeyon.boot.starter.deduction.upgrade.DeductionUpgradeAppService`

```java
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> upgradeDeductionMapAppId();
    private void upgradeDeductionRule(java.util.Map<java.lang.String, java.lang.Object>);
    private void upgradeDeductionMap(java.util.Map<java.lang.String, java.lang.Object>);
```

## 四、枚举（3）

- `SourceHandleTypeEnum`（2 常量）：MERGE, ONEBYONE
- `CombinationAttributeStateEnum`（2 常量）：ON, OFF
- `DeductionIdMappingStatusEnum`（2 常量）：JOIN_DEDUCTION, NOT_JOIN_DEDUCTION
