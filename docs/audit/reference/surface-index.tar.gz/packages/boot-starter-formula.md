# boot-starter-formula：接口与方法签名

> 自动生成，勿手改。`tools/core/platform/emit_package_surfaces.py` 重跑即可。
> 构件 `com.seeyon:boot-starter-formula`（jar `boot-starter-formula-5.3.603.jar`）
> 规模：202 类 / 10 接口 / 3 注解 / 8 枚举 / 25 个关键类 / 1245 方法。
> 签名逐字来自 javap 原文；已去掉 `public` 前缀与 `throws` 子句。

## 一、接口（10）

### `ScriptBuilderInterceptor`（3 方法）

`com.seeyon.boot.starter.formula.parser.scriptbuilder.ScriptBuilderInterceptor`

```java
    default void before(com.seeyon.boot.starter.formula.parser.ast.ASTNode, com.seeyon.boot.starter.formula.parser.scriptbuilder.ScriptBuildContext);
    default void after(com.seeyon.boot.starter.formula.parser.ast.ASTNode, com.seeyon.boot.starter.formula.parser.scriptbuilder.ScriptBuildContext);
    com.seeyon.boot.starter.formula.parser.ast.ASTNodeType getNodeType();
```

### `CallerSemanticAnalyzer`（3 方法）

`com.seeyon.boot.starter.formula.parser.semantic.caller.CallerSemanticAnalyzer`

```java
    com.seeyon.boot.starter.formula.dto.ExpressionDataType analyze(com.seeyon.boot.starter.formula.parser.ast.ASTNode, com.seeyon.boot.starter.formula.parser.semantic.SemanticAnalyzer);
    java.lang.String getOperatorName();
    default com.seeyon.boot.starter.formula.enums.CallerAnalyzeStrategy getAnalyzeStrategy();
```

### `ExprConsistencyValidator`（2 方法）

`com.seeyon.boot.starter.formula.domain.validation.ExprConsistencyValidator`

```java
    com.seeyon.boot.starter.formula.dto.consistency.ConsistencyValidateResult validateConsistency(com.seeyon.boot.starter.formula.dto.ExpressionDefinitionDto);
    com.seeyon.boot.starter.formula.dto.consistency.ConsistencyValidateResult validateConsistency(com.seeyon.boot.starter.formula.dto.consistency.ConsistencyValidateConfig);
```

### `ControlDataResolver`（1 方法）

`com.seeyon.boot.starter.formula.domain.controldata.ControlDataResolver`

```java
    void resolveControlData(com.seeyon.boot.starter.formula.dto.ExpressionToken, java.lang.StringBuilder, com.seeyon.boot.starter.formula.dto.ExpressionSaveDto);
```

### `ExprOutsideService`（1 方法）

`com.seeyon.boot.starter.formula.domain.service.param.ExprOutsideService`

```java
    java.util.List<com.seeyon.boot.starter.formula.dto.variable.SchemaStructureDto> loadParamSchemaInfo(com.seeyon.boot.starter.formula.dto.variable.VariableSchemaLoadDto);
```

### `ExpressionValidationFilter`（1 方法）

`com.seeyon.boot.starter.formula.domain.validation.filter.ExpressionValidationFilter`

```java
    void doFilter(com.seeyon.boot.starter.formula.dto.ExpressionSaveDto, com.seeyon.boot.starter.formula.domain.validation.filter.FilterChain);
```

### `ExprHOF`（1 方法）

`com.seeyon.boot.starter.formula.parser.ExprHOF`

```java
    com.seeyon.boot.starter.formula.parser.ast.ASTNode hoc()
```

### `ExpressionScriptBuilder`（1 方法）

`com.seeyon.boot.starter.formula.parser.scriptbuilder.ExpressionScriptBuilder`

```java
    java.lang.String build(com.seeyon.boot.starter.formula.parser.ast.ASTNode, com.seeyon.boot.starter.formula.parser.scriptbuilder.ScriptBuildContext);
```

### `FunctionSemanticAnalyzer`（1 方法）

`com.seeyon.boot.starter.formula.parser.semantic.function.FunctionSemanticAnalyzer`

```java
    com.seeyon.boot.starter.formula.dto.ExpressionDataType analyze(com.seeyon.boot.starter.formula.parser.ast.ASTNode, com.seeyon.boot.starter.formula.parser.semantic.SemanticAnalyzer);
```

### `ExtensionFunctionScriptBuilder`（0 方法） extends ExpressionScriptBuilder

`com.seeyon.boot.starter.formula.parser.scriptbuilder.ExtensionFunctionScriptBuilder`

```java
```

## 二、关键类（25）

### `ExpressionCommonUtil`（41 方法）

`com.seeyon.boot.starter.formula.utils.ExpressionCommonUtil`

```java
    static com.seeyon.boot.starter.formula.dto.variable.SchemaStructureDto getPreSchema(com.seeyon.boot.starter.formula.dto.ExpressionToken, java.util.Map<java.lang.String, com.seeyon.boot.starter.formula.dto.variable.SchemaStructureDto>);
    static com.seeyon.boot.starter.formula.dto.variable.SchemaStructureDto getPreSchema(java.lang.String, java.util.Map<java.lang.String, com.seeyon.boot.starter.formula.dto.variable.SchemaStructureDto>);
    static java.lang.String[] getVariableArray(java.lang.String);
    static java.lang.String getSystemVaribleFunction(java.lang.String);
    static java.util.Map<java.lang.String, com.seeyon.boot.starter.formula.dto.variable.SchemaStructureDto> getSchemaMap(java.util.List<com.seeyon.boot.starter.formula.dto.variable.SchemaStructureDto>);
    static com.seeyon.boot.starter.formula.dto.variable.SchemaStructureDto getCurrentSchema(com.seeyon.boot.starter.formula.dto.ExpressionToken, com.seeyon.boot.starter.formula.dto.variable.SchemaStructureDto);
    static com.seeyon.boot.starter.formula.dto.variable.SchemaStructureDto getCurrentSchema(java.lang.String, com.seeyon.boot.starter.formula.dto.variable.SchemaStructureDto);
    static com.seeyon.boot.starter.formula.dto.variable.SchemaStructureDto getCurrentSchema(java.lang.String[], com.seeyon.boot.starter.formula.dto.variable.SchemaStructureDto);
    static com.seeyon.boot.starter.formula.dto.variable.SchemaStructureDto getCurrentSchema(com.seeyon.boot.starter.formula.dto.ExpressionToken, java.util.Map<java.lang.String, com.seeyon.boot.starter.formula.dto.variable.SchemaStructureDto>);
    static com.seeyon.boot.starter.formula.dto.variable.SchemaStructureDto getCurrentSchema(java.lang.String, java.util.Map<java.lang.String, com.seeyon.boot.starter.formula.dto.variable.SchemaStructureDto>);
    static com.seeyon.boot.starter.formula.dto.variable.SchemaStructureDto getCurrentSchema(java.lang.String, java.util.List<com.seeyon.boot.starter.formula.dto.variable.SchemaStructureDto>);
    static java.lang.String getTokenRootName(com.seeyon.boot.starter.formula.dto.ExpressionToken);
    static java.lang.String getTokenRootName(java.lang.String);
    static java.util.List<com.seeyon.boot.starter.formula.dto.ExpressionToken> getVariableTokens(java.util.List<com.seeyon.boot.starter.formula.dto.ExpressionToken>);
    static java.util.List<com.seeyon.boot.starter.formula.dto.ExpressionToken> getVariableTokensIgnoreAppParam(java.util.List<com.seeyon.boot.starter.formula.dto.ExpressionToken>, java.util.List<com.seeyon.boot.starter.formula.dto.variable.SchemaStructureDto>);
    static java.util.List<com.seeyon.boot.starter.formula.dto.ExpressionToken> getAllAppParamTokens(java.util.List<com.seeyon.boot.starter.formula.dto.ExpressionToken>, java.util.List<com.seeyon.boot.starter.formula.dto.variable.SchemaStructureDto>);
    static private static void getAppParameterTokens(java.util.List<com.seeyon.boot.starter.formula.dto.ExpressionToken>, java.util.List<com.seeyon.boot.starter.formula.dto.ExpressionToken>, java.util.Map<java.lang.String, com.seeyon.boot.starter.formula.dto.variable.SchemaStructureDto>);
    static java.util.Map<java.lang.String, com.seeyon.boot.starter.formula.engine.dto.FunctionDto> getFunctionMap();
    static java.util.List<com.seeyon.boot.starter.formula.dto.variable.SchemaStructureDto> getSimpleSchemas(java.util.List<com.seeyon.boot.starter.formula.dto.ExpressionToken>, java.util.List<com.seeyon.boot.starter.formula.dto.variable.SchemaStructureDto>);
    static java.util.List<com.seeyon.boot.starter.formula.dto.ExpressionToken> getUdcEnumConstantTokens(java.util.List<com.seeyon.boot.starter.formula.dto.ExpressionToken>);
    static java.util.List<com.seeyon.boot.starter.formula.dto.ExpressionToken> getAllConstantTokens(java.util.List<com.seeyon.boot.starter.formula.dto.ExpressionToken>);
    static private static void markTreeNode(com.seeyon.boot.starter.formula.dto.variable.SchemaStructureDto, java.lang.String[]);
    static private static void clearUnMarkedNode(com.seeyon.boot.starter.formula.dto.variable.SchemaStructureDto);
    static private static void getVariableTokens(java.util.List<com.seeyon.boot.starter.formula.dto.ExpressionToken>, java.util.List<com.seeyon.boot.starter.formula.dto.ExpressionToken>);
    static private static void getVariableTokensIgnoreAppParam(java.util.List<com.seeyon.boot.starter.formula.dto.ExpressionToken>, java.util.List<com.seeyon.boot.starter.formula.dto.ExpressionToken>, java.util.Map<java.lang.String, com.seeyon.boot.starter.formula.dto.variable.SchemaStructureDto>);
    static private static boolean isParameter(com.seeyon.boot.starter.formula.dto.variable.SchemaStructureDto);
    static java.lang.String getI18nValueBySystemDefault(java.lang.String);
    static boolean isDefaultValueNullFunctionToken(com.seeyon.boot.starter.formula.dto.ExpressionToken, java.util.Map<java.lang.String, com.seeyon.boot.starter.formula.dto.variable.SchemaStructureDto>);
    static boolean isDefaultValueNullFunctionToken(com.seeyon.boot.starter.formula.parser.ast.ASTNode, java.util.Map<java.lang.String, com.seeyon.boot.starter.formula.dto.variable.SchemaStructureDto>);
    static java.lang.String getExecutableExpression(com.seeyon.boot.starter.formula.dto.ExpressionSaveDto, com.seeyon.boot.starter.formula.parser.ast.ASTNode, java.util.Map<java.lang.String, com.seeyon.boot.starter.formula.dto.variable.SchemaStructureDto>);
    static java.lang.String getConstantCtpEnumFullName(com.seeyon.boot.starter.formula.dto.ExpressionToken);
    static java.lang.String getVariableCtpEnumFullName(com.seeyon.boot.starter.formula.dto.variable.SchemaStructureDto);
    static java.lang.String getConstantEntityFullName(com.seeyon.boot.starter.formula.dto.ExpressionToken);
    static java.lang.String getVariableEntityFullName(com.seeyon.boot.starter.formula.dto.variable.SchemaStructureDto);
    static private static java.lang.String getCtpEnumUniqueFullName(com.seeyon.boot.starter.formula.dto.ControlData);
    static private static java.lang.String getEntityUniqueFullName(com.seeyon.boot.starter.formula.dto.ControlData);
    static private static boolean isI18nJsonString(java.lang.String);
    static private static void getUdcEnumConstantTokens(java.util.List<com.seeyon.boot.starter.formula.dto.ExpressionToken>, java.util.List<com.seeyon.boot.starter.formula.dto.ExpressionToken>);
    static private static void getAllConstantTokens(java.util.List<com.seeyon.boot.starter.formula.dto.ExpressionToken>, java.util.List<com.seeyon.boot.starter.formula.dto.ExpressionToken>);
```

### `ExpressionService`（37 方法）

`com.seeyon.boot.starter.formula.domain.service.ExpressionService`

```java
    com.seeyon.boot.starter.formula.dto.operator.QuickSymbolDto getQuickSymbols();
    com.seeyon.boot.starter.formula.dto.preset.PresetInfoDto loadSystemPresetVariable();
    com.seeyon.boot.starter.formula.dto.preset.PresetInfoDto loadSystemPresetVariableByCondition(com.seeyon.boot.starter.formula.dto.preset.PresetLoadConditionDto);
    com.seeyon.boot.starter.formula.dto.preset.SystemPresetVariableDto loadSystemVariable(java.lang.String);
    java.util.List<com.seeyon.boot.starter.formula.dto.preset.FunctionCategoryDto> loadFunctionInfo(com.seeyon.boot.starter.formula.dto.preset.PresetLoadConditionDto);
    private void setParamType(com.seeyon.boot.starter.formula.dto.preset.FunctionExtension, com.seeyon.boot.starter.formula.engine.dto.FunctionDto);
    private java.util.Map<java.lang.String, com.seeyon.boot.starter.formula.dto.preset.SystemVariableItems> getSystemFunctionName();
    java.util.List<com.seeyon.boot.starter.formula.dto.variable.SchemaStructureDto> selectSchemaByParamType(com.seeyon.boot.starter.formula.dto.variable.VariableSchemaLoadDto);
    com.seeyon.boot.starter.formula.dto.ExpressionDefinitionDto transform(com.seeyon.boot.starter.formula.dto.ExpressionSaveDto);
    java.lang.Boolean check(com.seeyon.boot.starter.formula.dto.ExpressionSaveDto);
    private java.lang.String getExprTranslation(java.util.List<com.seeyon.boot.starter.formula.dto.ExpressionToken>);
    private java.lang.String translateFunctionToken(com.seeyon.boot.starter.formula.dto.ExpressionToken);
    private java.lang.String getRuledFunctionTranslation(com.seeyon.boot.starter.formula.dto.ExpressionToken, com.seeyon.boot.starter.formula.engine.dto.FunctionDto);
    private void buildFunctionParamTranslation(com.seeyon.boot.starter.formula.dto.ExpressionToken, java.lang.StringBuilder);
    protected com.seeyon.boot.starter.formula.dto.runtime.ExprParamResult getExpressionStatement(com.seeyon.boot.starter.formula.dto.ExpressionSaveDto, com.seeyon.boot.starter.formula.parser.ast.ASTNode);
    java.util.Map<java.lang.String, java.lang.Object> getSystemVariableResult(java.lang.String);
    java.util.Map<java.lang.String, java.lang.Object> getSystemVariableResult();
    java.lang.Object getSystemVariableResultByName(java.lang.String);
    java.util.List<com.seeyon.boot.starter.formula.dto.preset.SystemPresetVariableDto> listSystemVariable();
    java.util.List<com.seeyon.boot.starter.formula.dto.preset.SystemPresetVariableDto> listSystemVariableByCondition(java.util.Map<java.lang.String, java.lang.Object>);
    private com.seeyon.boot.starter.formula.dto.ExpressionDesignDataDto copyToDesignDataDto(com.seeyon.boot.starter.formula.dto.ExpressionSaveDto);
    private com.seeyon.boot.starter.formula.dto.runtime.ExprParamResult getRuntimeParam(com.seeyon.boot.starter.formula.dto.ExpressionSaveDto);
    private boolean isControlDataOperator(com.seeyon.boot.starter.formula.dto.ExpressionToken);
    private boolean functionJumpable(com.seeyon.boot.starter.formula.engine.dto.FunctionDto, com.seeyon.boot.starter.formula.dto.preset.PresetLoadConditionDto);
    private java.lang.String getI18nValueByKey(java.lang.String);
    private java.util.List<com.seeyon.boot.starter.formula.dto.preset.SystemPresetVariableDto> getI18nSystemVariables();
    private java.util.Map<java.lang.String, com.seeyon.boot.starter.formula.dto.preset.FunctionDetailsDto> getFunctionMap(java.util.List<com.seeyon.boot.starter.formula.dto.preset.FunctionCategoryDto>);
```

### `ExprDateUtil`（17 方法）

`com.seeyon.boot.starter.formula.utils.ExprDateUtil`

```java
    static java.lang.String getFirstDateOfWeek();
    static java.lang.String getLastDateOfWeek();
    static java.lang.String getNextFirstDateOfWeek();
    static java.lang.String getNextLastDateOfWeek();
    static java.lang.String getPreFirstDateOfWeek();
    static java.lang.String getPreLastDateOfWeek();
    static java.time.LocalDateTime getLocalDateTime(java.util.Date);
    static void check(java.util.Date);
    static boolean isNullDate(java.util.Date);
    static boolean isDatePattern(java.lang.String);
    static boolean isDateTimePattern(java.lang.String);
    static boolean isTimePattern(java.lang.String);
    static boolean isTimeWithSecondPattern(java.lang.String);
    static boolean isTimeWithoutSecondPattern(java.lang.String);
    static boolean isLegalDatePattern(java.lang.String);
    static java.util.Date getNullDate();
    static java.lang.Long getSecondsOfTime(java.lang.String);
```

### `ListFunctionUtil`（16 方法）

`com.seeyon.boot.starter.formula.utils.ListFunctionUtil`

```java
    static java.lang.String buildListFunction(com.seeyon.boot.starter.formula.dto.ExpressionToken, java.util.Map<java.lang.String, com.seeyon.boot.starter.formula.dto.variable.SchemaStructureDto>, com.seeyon.boot.starter.formula.dto.ExpressionSaveDto);
    static private static java.lang.String buildNormalAggFunction(java.lang.String, java.lang.String, java.lang.String);
    static private static java.lang.String buildLineMatchFunction(java.lang.String, java.lang.String, java.lang.String, java.lang.String);
    static private static java.lang.String buildConditionAggFunction(java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String);
    static private static java.lang.String buildListCountFunction(java.lang.String, java.lang.String, java.lang.String, java.lang.String);
    static private static java.lang.String buildConditionExpression(com.seeyon.boot.starter.formula.dto.ExpressionToken, java.lang.String, java.lang.String, java.util.Map<java.lang.String, com.seeyon.boot.starter.formula.dto.variable.SchemaStructureDto>, com.seeyon.boot.starter.formula.dto.ExpressionSaveDto);
    static private static void buildVariable(java.lang.StringBuilder, com.seeyon.boot.starter.formula.dto.ExpressionToken, java.lang.String, java.lang.String, java.util.Map<java.lang.String, com.seeyon.boot.starter.formula.dto.variable.SchemaStructureDto>);
    static java.lang.String getFunctionExprStr(com.seeyon.boot.starter.formula.dto.ExpressionToken, java.lang.String, java.lang.String, java.util.Map<java.lang.String, com.seeyon.boot.starter.formula.dto.variable.SchemaStructureDto>, com.seeyon.boot.starter.formula.dto.ExpressionSaveDto);
    static java.lang.String getAggPropertyName(com.seeyon.boot.starter.formula.dto.ExpressionToken, com.seeyon.boot.starter.formula.dto.preset.FunctionExtension);
    static java.lang.String getListTableName(java.util.List<java.util.List<com.seeyon.boot.starter.formula.dto.ExpressionToken>>, java.lang.Integer, java.util.Map<java.lang.String, com.seeyon.boot.starter.formula.dto.variable.SchemaStructureDto>);
    static private static java.lang.String getListTableName(java.util.List<com.seeyon.boot.starter.formula.dto.ExpressionToken>, java.util.Map<java.lang.String, com.seeyon.boot.starter.formula.dto.variable.SchemaStructureDto>);
    static java.lang.String getConditionExpression(com.seeyon.boot.starter.formula.dto.ExpressionToken, int, java.lang.String, java.lang.String, java.util.Map<java.lang.String, com.seeyon.boot.starter.formula.dto.variable.SchemaStructureDto>, com.seeyon.boot.starter.formula.dto.ExpressionSaveDto);
    static java.lang.String getListVariableName(java.util.List<java.util.List<com.seeyon.boot.starter.formula.dto.ExpressionToken>>, java.lang.Integer);
    static private static java.lang.String getListVariableName(java.util.List<com.seeyon.boot.starter.formula.dto.ExpressionToken>);
    static private static java.lang.String getAggPropertyParamKey(com.seeyon.boot.starter.formula.dto.ExpressionToken);
    static private static java.lang.String getDefaultNullFunction(com.seeyon.boot.starter.formula.dto.ExpressionToken, java.lang.String, java.lang.String, java.util.Map<java.lang.String, com.seeyon.boot.starter.formula.dto.variable.SchemaStructureDto>);
```

### `CallerDataTypeHelper`（12 方法）

`com.seeyon.boot.starter.formula.caller.CallerDataTypeHelper`

```java
    static java.lang.Integer getNumberTypeByObject(java.lang.Object);
    static java.lang.Integer getNumberTypeBiggerPriority(java.lang.Integer, java.lang.Integer);
    static boolean isNumberType(java.lang.Object);
    static java.lang.String getNumberStringValue(java.lang.Object);
    static boolean isZero(java.lang.Object);
    static int compareTo(java.lang.Object, java.lang.Object);
    static boolean isNumberTypeByString(java.lang.String);
    static boolean isFloat(java.lang.String);
    static boolean isInteger(java.lang.String);
    static boolean isNormalInteger(java.lang.String);
    static boolean isExceedInteger(java.lang.String);
    static boolean isExceedLong(java.lang.String);
```

### `ExpressionAppService`（11 方法）

`com.seeyon.boot.starter.formula.appservice.ExpressionAppService`

```java
    com.seeyon.boot.transport.SingleResponse<com.seeyon.boot.starter.formula.dto.operator.QuickSymbolDto> getQuickSymbols();
    com.seeyon.boot.transport.SingleResponse<com.seeyon.boot.starter.formula.dto.ExpressionDefinitionDto> transform(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.formula.dto.ExpressionSaveDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Boolean> check(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.formula.dto.ExpressionSaveDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.boot.starter.formula.dto.preset.PresetInfoDto> loadSystemPresetVariableByCondition(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.formula.dto.preset.PresetLoadConditionDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.boot.starter.formula.dto.preset.SystemPresetVariableDto> loadSystemVariable(com.seeyon.boot.transport.SingleRequest<java.lang.String>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.boot.starter.formula.dto.variable.SchemaStructureDto> selectSchemaByParamType(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.formula.dto.variable.VariableSchemaLoadDto>);
    com.seeyon.boot.transport.SingleResponse<java.util.Map<java.lang.String, java.lang.Object>> getSystemVariableResult(com.seeyon.boot.transport.SingleRequest<java.lang.String>);
    com.seeyon.boot.transport.SingleResponse<java.util.Map<java.lang.String, java.lang.Object>> getSystemVariableResult();
    com.seeyon.boot.transport.SingleResponse<java.lang.Object> getSystemVariableResultBySystemFunctionName(com.seeyon.boot.transport.SingleRequest<java.lang.String>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.boot.starter.formula.dto.preset.SystemPresetVariableDto> listSystemVariable();
    com.seeyon.boot.transport.ListResponse<com.seeyon.boot.starter.formula.dto.preset.SystemPresetVariableDto> listSystemVariableByCondition(com.seeyon.boot.transport.SingleRequest<java.util.Map<java.lang.String, java.lang.Object>>);
```

### `ExprSchemaReplaceUtil`（10 方法）

`com.seeyon.boot.starter.formula.utils.ExprSchemaReplaceUtil`

```java
    static com.seeyon.boot.starter.formula.dto.ExpressionDefinitionDto replaceForBpm(com.seeyon.boot.starter.formula.dto.ExpressionDefinitionDto, java.lang.String, java.lang.String);
    static void batchReplaceBpmRuntimeCtpEnumId(java.util.Map<java.lang.String, com.seeyon.boot.starter.formula.dto.ExpressionDefinitionDto>, java.lang.String);
    static void replaceBpmRuntimeExpressionCtpEnumId(com.seeyon.boot.starter.formula.dto.ExpressionDefinitionDto, java.lang.String);
    static private static com.seeyon.boot.starter.formula.dto.ExpressionDefinitionDto replaceExpressionCtpEnumId(com.seeyon.boot.starter.formula.dto.ExpressionDefinitionDto, java.util.Map<java.lang.String, java.lang.Object>, java.lang.String);
    static private static void replaceCtpEnumToken(java.lang.String, java.util.Map<java.lang.String, java.lang.Object>, com.seeyon.boot.starter.formula.dto.ExpressionToken);
    static private static java.util.Map<java.lang.String, java.lang.Object> getCtpEnumItemIdsRuntimeMetadata(java.lang.String);
    static java.lang.String replaceSingleCtpEnumItemId(java.lang.String, java.util.Map<java.lang.String, java.lang.Object>);
    static java.lang.String replaceMultiCtpEnumItemId(java.lang.String, java.util.Map<java.lang.String, java.lang.Object>);
```

### `ExprSchemaUtil`（10 方法）

`com.seeyon.boot.starter.formula.utils.ExprSchemaUtil`

```java
    static java.lang.String buildReferenceProperties(java.lang.String, java.lang.String, boolean);
    static java.lang.String buildInnerReferenceProperties(java.lang.Long, java.lang.String, boolean);
    static java.lang.String buildJavaEnumProperties(java.util.List<com.seeyon.boot.starter.formula.utils.ExprSchemaUtil$JavaEnumItem>, boolean);
    static java.lang.String buildJavaEnumProperties(java.util.List<com.seeyon.boot.starter.formula.utils.ExprSchemaUtil$JavaEnumItem>, boolean, java.lang.String);
    static java.lang.String buildCtpEnumProperties(java.lang.Long, java.lang.String, java.lang.String, java.lang.Long, boolean);
    static boolean isSingleReference(com.seeyon.boot.starter.formula.dto.variable.SchemaStructureDto);
    static boolean isSingleJavaEnum(com.seeyon.boot.starter.formula.dto.variable.SchemaStructureDto);
    static boolean isSingleCtpEnum(com.seeyon.boot.starter.formula.dto.variable.SchemaStructureDto);
    static boolean isDateOrDatetimeSchema(com.seeyon.boot.starter.formula.dto.variable.SchemaStructureDto);
    static private static boolean hasControlData(com.seeyon.boot.starter.formula.dto.variable.SchemaStructureDto);
```

### `ListFunctionParamUtil`（8 方法）

`com.seeyon.boot.starter.formula.parser.util.ListFunctionParamUtil`

```java
    static java.lang.String getConditionExpression4ListFunction(java.util.List<com.seeyon.boot.starter.formula.dto.ExpressionToken>, com.seeyon.boot.starter.formula.parser.ast.ASTNode, java.util.Map<java.lang.String, com.seeyon.boot.starter.formula.dto.variable.SchemaStructureDto>, java.lang.String, com.seeyon.boot.starter.formula.dto.ExpressionSaveDto);
    static java.lang.String getFieldPathByListableName(com.seeyon.boot.starter.formula.dto.ExpressionToken, java.lang.String);
    static java.lang.String getListTableVariableNameFromParam(com.seeyon.boot.starter.formula.dto.ExpressionToken, java.util.Map<java.lang.String, com.seeyon.boot.starter.formula.dto.variable.SchemaStructureDto>);
    static java.lang.String getListTableNameFromAggPropertyParam(com.seeyon.boot.starter.formula.parser.ast.ASTNode, java.util.Map<java.lang.String, com.seeyon.boot.starter.formula.dto.variable.SchemaStructureDto>);
    static java.lang.String getListTableNameByVariableName(java.lang.String);
    static boolean isAttributeOfListable(com.seeyon.boot.starter.formula.parser.ast.ASTNode, java.util.Map<java.lang.String, com.seeyon.boot.starter.formula.dto.variable.SchemaStructureDto>);
    static private static boolean isListTableVariable(com.seeyon.boot.starter.formula.dto.variable.SchemaStructureDto);
    static private static boolean isListTable(com.seeyon.boot.starter.formula.dto.variable.SchemaStructureDto);
```

### `ConsistencyValidateConfig`（7 方法）

`com.seeyon.boot.starter.formula.dto.consistency.ConsistencyValidateConfig`

```java
    static com.seeyon.boot.starter.formula.dto.consistency.ConsistencyValidateConfig$ConsistencyValidateConfigBuilder builder();
    com.seeyon.boot.starter.formula.dto.ExpressionDefinitionDto getExpressionDefinitionDto();
    java.lang.Long getAppId();
    java.lang.String getResultType();
    void setExpressionDefinitionDto(com.seeyon.boot.starter.formula.dto.ExpressionDefinitionDto);
    void setAppId(java.lang.Long);
    void setResultType(java.lang.String);
```

### `BinaryExpressionScriptBuilder`（7 方法）

`com.seeyon.boot.starter.formula.parser.scriptbuilder.builders.BinaryExpressionScriptBuilder`

```java
    protected java.lang.String doScriptBuild(com.seeyon.boot.starter.formula.parser.ast.ASTNode, com.seeyon.boot.starter.formula.parser.scriptbuilder.ScriptBuildContext);
    private java.lang.String buildFourOperation(com.seeyon.boot.starter.formula.parser.ast.ASTNode, com.seeyon.boot.starter.formula.parser.ast.ASTNode, java.lang.String, com.seeyon.boot.starter.formula.parser.ast.ASTNode, com.seeyon.boot.starter.formula.parser.scriptbuilder.ScriptBuildContext);
    private boolean isFourOperations(com.seeyon.boot.starter.formula.parser.ast.ASTNode);
    private boolean isAddExpr(com.seeyon.boot.starter.formula.parser.ast.ASTNode);
    private boolean isSubtractExpr(com.seeyon.boot.starter.formula.parser.ast.ASTNode);
    protected boolean isMultiplyExpr(com.seeyon.boot.starter.formula.parser.ast.ASTNode);
    protected boolean isDivideExpr(com.seeyon.boot.starter.formula.parser.ast.ASTNode);
```

### `ScriptBuilderInterceptConfig`（6 方法）

`com.seeyon.boot.starter.formula.parser.scriptbuilder.ScriptBuilderInterceptConfig`

```java
    boolean isVariableOfListFunctionConditionExpressionParam();
    void setVariableOfListFunctionConditionExpressionParam(boolean);
    boolean equals(java.lang.Object);
    protected boolean canEqual(java.lang.Object);
    int hashCode();
    java.lang.String toString();
```

### `FunctionBeanUseService`（5 方法）

`com.seeyon.boot.starter.formula.domain.service.FunctionBeanUseService`

```java
    com.seeyon.ctp.metadata.api.MetadataQueryAppService getMetadataQueryAppService();
    com.seeyon.boot.starter.proxy.appservice.AppServiceReliableInvoker getAppServiceReliableInvoker();
    com.seeyon.boot.starter.parameter.domain.service.CtpParameterDefinitionService getCtpParameterDefinitionService();
    com.seeyon.boot.starter.parameter.domain.service.CtpParameterService getCtpParameterService();
    com.seeyon.ctp.metadata.api.LoadJarResourceAppService getLoadJarResourceAppService();
```

### `ParamSchemaStrategyService`（5 方法）

`com.seeyon.boot.starter.formula.domain.service.param.ParamSchemaStrategyService`

```java
    java.util.List<com.seeyon.boot.starter.formula.dto.variable.SchemaStructureDto> loadParamSchemaInfo(com.seeyon.boot.starter.formula.dto.variable.VariableSchemaLoadDto);
    private com.seeyon.boot.starter.formula.domain.service.param.ExprOutsideService getService(java.lang.String, java.lang.String);
    private com.seeyon.boot.starter.formula.domain.service.param.ExprOutsideService findAdaptorByServerName(java.util.List<com.seeyon.boot.starter.formula.domain.service.param.ExprOutsideService>, java.lang.String);
```

### `AbstractExpressionScriptBuilder`（4 方法）

`com.seeyon.boot.starter.formula.parser.scriptbuilder.AbstractExpressionScriptBuilder`

```java
    final java.lang.String build(com.seeyon.boot.starter.formula.parser.ast.ASTNode, com.seeyon.boot.starter.formula.parser.scriptbuilder.ScriptBuildContext);
    protected abstract java.lang.String doScriptBuild(com.seeyon.boot.starter.formula.parser.ast.ASTNode, com.seeyon.boot.starter.formula.parser.scriptbuilder.ScriptBuildContext);
    private void doBefore(com.seeyon.boot.starter.formula.parser.ast.ASTNode, com.seeyon.boot.starter.formula.parser.scriptbuilder.ScriptBuildContext);
    private void doAfter(com.seeyon.boot.starter.formula.parser.ast.ASTNode, com.seeyon.boot.starter.formula.parser.scriptbuilder.ScriptBuildContext);
```

### `VariableExpressionScriptBuilder`（4 方法）

`com.seeyon.boot.starter.formula.parser.scriptbuilder.builders.VariableExpressionScriptBuilder`

```java
    protected java.lang.String doScriptBuild(com.seeyon.boot.starter.formula.parser.ast.ASTNode, com.seeyon.boot.starter.formula.parser.scriptbuilder.ScriptBuildContext);
    private java.lang.String getVariablePath(com.seeyon.boot.starter.formula.parser.ast.ASTNode, com.seeyon.boot.starter.formula.parser.scriptbuilder.ScriptBuildContext);
    static private static boolean isParameter(com.seeyon.boot.starter.formula.dto.variable.SchemaStructureDto);
    static private static java.lang.String buildAppParamVariable(com.seeyon.boot.starter.formula.dto.variable.SchemaStructureDto);
```

### `ParameterModuleContextServiceImpl`（3 方法）

`com.seeyon.boot.starter.formula.domain.service.param.ParameterModuleContextServiceImpl`

```java
    java.util.List<com.seeyon.boot.starter.formula.dto.variable.SchemaStructureDto> loadParamSchemaInfo(com.seeyon.boot.starter.formula.dto.variable.VariableSchemaLoadDto);
    void setApplicationContext(org.springframework.context.ApplicationContext)
    private void init();
```

### `ExtensionFunctionScriptBuilderFactory`（3 方法）

`com.seeyon.boot.starter.formula.init.ExtensionFunctionScriptBuilderFactory`

```java
    static com.seeyon.boot.starter.formula.parser.scriptbuilder.ExtensionFunctionScriptBuilder getBuilderInstance(java.lang.String);
    static protected static void init()
```

### `FunctionSemanticAnalyzerFactory`（3 方法）

`com.seeyon.boot.starter.formula.init.FunctionSemanticAnalyzerFactory`

```java
    static com.seeyon.boot.starter.formula.parser.semantic.function.FunctionSemanticAnalyzer getAnalyzerInstance(java.lang.String);
    static protected static void init();
```

### `CallerImplementFactory`（3 方法）

`com.seeyon.boot.starter.formula.listener.CallerImplementFactory`

```java
    static com.seeyon.boot.starter.formula.caller.BaseOperatorReloadCaller getCallerByOperator(java.lang.String);
    static protected static void init();
```

### `FunctionExpressionScriptBuilder`（3 方法）

`com.seeyon.boot.starter.formula.parser.scriptbuilder.builders.FunctionExpressionScriptBuilder`

```java
    protected java.lang.String doScriptBuild(com.seeyon.boot.starter.formula.parser.ast.ASTNode, com.seeyon.boot.starter.formula.parser.scriptbuilder.ScriptBuildContext);
    private java.lang.String buildDefaultValueNullFunction(com.seeyon.boot.starter.formula.parser.ast.ASTNode, com.seeyon.boot.starter.formula.parser.scriptbuilder.ScriptBuildContext);
    private java.lang.String buildNormalFunction(com.seeyon.boot.starter.formula.parser.ast.ASTNode, com.seeyon.boot.starter.formula.parser.scriptbuilder.ScriptBuildContext);
```

### `ListFunctionSemanticUtil`（3 方法）

`com.seeyon.boot.starter.formula.parser.util.ListFunctionSemanticUtil`

```java
    static void checkConditionNodeOfListFunction(com.seeyon.boot.starter.formula.parser.ast.ASTNode, com.seeyon.boot.starter.formula.parser.ast.ASTNode, com.seeyon.boot.starter.formula.parser.semantic.SemanticAnalyzer, java.util.Set<java.lang.String>);
    static private static void collectVariableTokensInParam(com.seeyon.boot.starter.formula.parser.ast.ASTNode, java.util.List<com.seeyon.boot.starter.formula.dto.ExpressionToken>);
    static void collectListTable(com.seeyon.boot.starter.formula.dto.ExpressionToken, java.util.Map<java.lang.String, com.seeyon.boot.starter.formula.dto.variable.SchemaStructureDto>, java.util.Set<java.lang.String>);
```

### `ExprStringUtil`（3 方法）

`com.seeyon.boot.starter.formula.utils.ExprStringUtil`

```java
    static java.lang.String joinArrayWithIndex(java.lang.String[], int, int, java.lang.String);
    static boolean isMultiCtpEnumOrEntityString(java.lang.Object);
    static java.util.List<java.lang.String> splitMultiDataStringToList(java.lang.String);
```

### `ExpressionConfigUtil`（3 方法）

`com.seeyon.boot.starter.formula.utils.ExpressionConfigUtil`

```java
    static void initProperties(com.seeyon.boot.starter.formula.ExpressionProperties);
    static java.lang.String getMode();
    static java.lang.String getCtpEnumIdReplaceJsonChangeTopic();
```

### `NumToRMBUtil`（3 方法）

`com.seeyon.boot.starter.formula.utils.NumToRMBUtil`

```java
    static java.lang.String getRMBLowerCase(java.lang.String, boolean);
    static private static java.lang.String convertIntegerPart(java.lang.String, boolean);
    static private static java.lang.String convertDecimalPart(java.lang.String, boolean);
```

## 三、注解（3）

| 注解 | 元素 |
|---|---|
| `ExpressionFilter` | order |
| `ParamLoadService` | type, useCustom |
| `FunctionSupporter` | functions |

## 四、枚举（8）

- `CallerAnalyzeStrategy`（2 常量）：APPEND, OVERRIDE
- `ConsistencyMessageLevelEnum`（2 常量）：WARRING, ERROR
- `ExprDataTypeEnum`（16 常量）：INTEGER, BIGINTEGER, BIGDECIMAL, STRING, MULTILINESTRING, ATTACHMENT, BOOLEAN, DATE, DATE_TIME, TIME, ENUM, CTP_ENUM …
- `ExprParamTypeEnum`（5 常量）：ENTITY, BPM, BPMAUTO, PARAM_CONFIG, EVENT_ATTR
- `OpTypeEnum`（5 常量）：ARITHMETIC, LOGIC, COMPARE, SYMBOL, BOOLEAN
- `OperatorEnum`（19 常量）：ADD, SUBSTRACT, MULTIPLY, DIVISION, MOD, AND, OR, NOT, EQ, NE, GT, LT …
- `TokenTypeEnum`（5 常量）：CONSTANT, VARIABLE, SYSTEM, FUNCTION, OPERATOR
- `ASTNodeType`（6 常量）：BINARY_EXPR, UNARY_EXPR, CALL_EXPR, VARIABLE, SCALAR, SYSTEM
