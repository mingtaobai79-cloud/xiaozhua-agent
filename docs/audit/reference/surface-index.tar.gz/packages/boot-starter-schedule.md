# boot-starter-schedule：接口与方法签名

> 自动生成，勿手改。`tools/core/platform/emit_package_surfaces.py` 重跑即可。
> 构件 `com.seeyon:boot-starter-schedule`（jar `boot-starter-schedule-5.3.600.jar`）
> 规模：50 类 / 7 接口 / 1 注解 / 1 枚举 / 4 个关键类 / 364 方法。
> 签名逐字来自 javap 原文；已去掉 `public` 前缀与 `throws` 子句。

## 一、接口（7）

### `SeeyonJob`（1 方法）

`com.seeyon.boot.starter.schedule.api.SeeyonJob`

```java
    com.seeyon.boot.transport.SingleResponse<?> exec();
```

### `CtpJobLogDao`（1 方法） extends CtpJobLog>

`com.seeyon.boot.starter.schedule.domain.dao.CtpJobLogDao`

```java
    java.util.List<com.seeyon.boot.starter.schedule.dto.CleanJobDto> selectJobCount();
```

### `EveryConstant`（0 方法）

`com.seeyon.boot.starter.schedule.common.EveryConstant`

```java
```

### `CtpJobCronDao`（0 方法） extends CtpJobCron>

`com.seeyon.boot.starter.schedule.domain.dao.CtpJobCronDao`

```java
```

### `CtpJobInfoDao`（0 方法） extends CtpJobInfo>

`com.seeyon.boot.starter.schedule.domain.dao.CtpJobInfoDao`

```java
```

### `CtpJobSimpleDao`（0 方法） extends CtpJobSimple>

`com.seeyon.boot.starter.schedule.domain.dao.CtpJobSimpleDao`

```java
```

### `ScheduleErrorCode`（0 方法）

`com.seeyon.boot.starter.schedule.exception.ScheduleErrorCode`

```java
```

## 二、关键类（4）

### `CtpJobInfoService`（27 方法）

`com.seeyon.boot.starter.schedule.domain.service.CtpJobInfoService`

```java
    java.lang.Long create(com.seeyon.boot.starter.schedule.dto.CtpJobInfoDto);
    private void createDetail(com.seeyon.boot.starter.schedule.domain.entity.CtpJobInfo, com.seeyon.boot.starter.schedule.dto.CtpJobInfoDto);
    com.seeyon.boot.transport.PageData<com.seeyon.boot.starter.schedule.dto.CtpJobInfoDto> selectPageByConditions(com.seeyon.boot.transport.PageInfo, java.util.Map<java.lang.String, java.lang.Object>);
    java.util.List<com.seeyon.boot.starter.schedule.dto.CtpJobLogDto> selectLogByConditions(java.lang.String);
    com.seeyon.boot.starter.schedule.dto.CtpJobInfoDto selectDetail(java.lang.Long);
    java.lang.Integer update(com.seeyon.boot.starter.schedule.dto.CtpJobInfoDto);
    java.lang.Integer updateStatus(java.lang.Long, java.lang.Boolean);
    java.lang.Integer delete(java.lang.Long);
    private void deleteSimple(java.lang.Long);
    private void deleteCron(java.lang.Long);
    com.seeyon.boot.starter.schedule.domain.entity.CtpJobInfo selectById(java.lang.Long);
    com.seeyon.boot.starter.schedule.domain.entity.CtpJobInfo selectByJobName(java.lang.String);
    void executeOnetime(java.lang.Long);
    void initJobInfo(java.util.List<java.lang.Object>, java.util.Map<java.lang.String, java.lang.Runnable>);
```

### `CtpJobSyncService`（9 方法）

`com.seeyon.boot.starter.schedule.domain.service.CtpJobSyncService`

```java
    void syncToRedis();
    void onApplicationEvent(com.seeyon.boot.event.SystemStartedEvent);
    void onApplicationEvent(org.springframework.context.ApplicationEvent);
```

### `ScheduleBeanConfiguration`（3 方法）

`com.seeyon.boot.starter.schedule.ScheduleBeanConfiguration`

```java
    com.seeyon.boot.starter.schedule.ack.ScheduleAckThread scheduleAckThread();
    org.springframework.scheduling.concurrent.ThreadPoolTaskScheduler taskScheduler();
```

### `CtpJobLogTaskService`（3 方法）

`com.seeyon.boot.starter.schedule.clean.CtpJobLogTaskService`

```java
    com.seeyon.boot.transport.SingleResponse<?> exec();
```

## 三、注解（1）

| 注解 | 元素 |
|---|---|
| `CtpSchedule` | systemTenant, isSingle, jobName, cron, description, fixedDelay |

## 四、枚举（1）

- `JobExecutionStatus`（2 常量）：FAILED, SKIPPED
