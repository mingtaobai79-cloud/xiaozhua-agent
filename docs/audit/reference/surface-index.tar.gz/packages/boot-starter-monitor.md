# boot-starter-monitor：接口与方法签名

> 自动生成，勿手改。`tools/core/platform/emit_package_surfaces.py` 重跑即可。
> 构件 `com.seeyon:boot-starter-monitor`（jar `boot-starter-monitor-5.3.600.jar`）
> 规模：15 类 / 0 接口 / 0 注解 / 0 枚举 / 4 个关键类 / 151 方法。
> 签名逐字来自 javap 原文；已去掉 `public` 前缀与 `throws` 子句。

## 一、接口（0）

（本构件没有接口）

## 二、关键类（4）

### `MonitorInfoService`（15 方法）

`com.seeyon.boot.starter.monitor.service.MonitorInfoService`

```java
    private boolean logPathCheck();
    com.seeyon.boot.transport.SingleResponse<java.util.Map<java.lang.String, java.lang.Object>> monitor(com.seeyon.boot.transport.SingleRequest<java.lang.String>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Boolean> processInitErrorLog();
    private void updateAppStarterInitDetail();
    static private static void setFieldValue(java.lang.Object, java.lang.String, java.lang.Object)
    private java.util.List<java.util.Map<java.lang.String, java.lang.Object>> getEntityDataByCondition(java.lang.String, java.util.Set<java.lang.String>, com.seeyon.boot.transport.PageInfo, java.util.Map<java.lang.String, java.lang.Object>, com.seeyon.boot.transport.Sort);
    private com.seeyon.boot.domain.dao.BaseDao getBaseDao(java.lang.String);
    private java.lang.String getSystemVerion();
    private boolean metadataCheck();
    private java.util.List<java.util.Map<java.lang.String, java.lang.Object>> dataConvert(java.util.List<java.lang.Object>, java.lang.String, java.util.Set<java.lang.String>);
    private java.lang.String[] getFrontendVersion(java.lang.String);
    static private static java.lang.String getV(java.lang.String);
    static private static java.lang.String getT(java.lang.String);
    private java.util.List<java.lang.Integer> getThreadInfo();
```

### `DbMonitorDashboardService`（9 方法）

`com.seeyon.boot.starter.monitor.service.DbMonitorDashboardService`

```java
    java.lang.String getDashboardHtml();
    private java.lang.String getHostInfo();
    private double getCounterValue(java.lang.String);
    private double getCounterValueByTag(java.lang.String, java.lang.String, java.lang.String);
    private double getGaugeValue(java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String);
    private java.lang.String getHtmlTemplate();
```

### `DubboInvokeService`（8 方法）

`com.seeyon.boot.starter.monitor.service.DubboInvokeService`

```java
    java.util.Map<java.lang.String, java.lang.Object> calculateDubboInvokeInfo(java.lang.String);
    private void processTxt(java.io.File, com.seeyon.boot.starter.monitor.dto.InvokeLogDetail);
    private void processLogLine(java.lang.String, com.seeyon.boot.starter.monitor.dto.InvokeLogDetail);
    private void buildResult(java.util.Map<java.lang.String, java.lang.Object>, com.seeyon.boot.starter.monitor.dto.InvokeLogDetail);
```

### `MonitorFileService`（3 方法）

`com.seeyon.boot.starter.monitor.service.MonitorFileService`

```java
    void upload(java.util.List<java.lang.String>, java.lang.String, java.lang.Long)
    java.util.List<java.io.File> getLogFiles(java.lang.String, java.lang.String);
```
