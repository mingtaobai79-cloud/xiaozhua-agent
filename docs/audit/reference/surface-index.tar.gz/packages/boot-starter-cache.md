# boot-starter-cache：接口与方法签名

> 自动生成，勿手改。`tools/core/platform/emit_package_surfaces.py` 重跑即可。
> 构件 `com.seeyon:boot-starter-cache`（jar `boot-starter-cache-5.3.600.jar`）
> 规模：50 类 / 3 接口 / 0 注解 / 2 枚举 / 11 个关键类 / 270 方法。
> 签名逐字来自 javap 原文；已去掉 `public` 前缀与 `throws` 子句。

## 一、接口（3）

### `Redis`（4 方法）

`com.seeyon.boot.starter.cache.redis.embedded.Redis`

```java
    boolean isActive();
    void start()
    void stop()
    java.util.List<java.lang.Integer> ports();
```

### `RateChecker`（1 方法）

`com.seeyon.boot.starter.cache.limit.RateChecker`

```java
    boolean check(java.lang.String, java.lang.Integer, java.lang.Long);
```

### `PortProvider`（1 方法）

`com.seeyon.boot.starter.cache.redis.embedded.PortProvider`

```java
    int next();
```

## 二、关键类（11）

### `RedisClusterBuilder`（18 方法）

`com.seeyon.boot.starter.cache.redis.embedded.RedisClusterBuilder`

```java
    com.seeyon.boot.starter.cache.redis.embedded.RedisClusterBuilder withSentinelBuilder(com.seeyon.boot.starter.cache.redis.embedded.RedisSentinelBuilder);
    com.seeyon.boot.starter.cache.redis.embedded.RedisClusterBuilder withServerBuilder(com.seeyon.boot.starter.cache.redis.embedded.RedisServerBuilder);
    com.seeyon.boot.starter.cache.redis.embedded.RedisClusterBuilder sentinelPorts(java.util.Collection<java.lang.Integer>);
    com.seeyon.boot.starter.cache.redis.embedded.RedisClusterBuilder serverPorts(java.util.Collection<java.lang.Integer>);
    com.seeyon.boot.starter.cache.redis.embedded.RedisClusterBuilder ephemeralSentinels();
    com.seeyon.boot.starter.cache.redis.embedded.RedisClusterBuilder ephemeralServers();
    com.seeyon.boot.starter.cache.redis.embedded.RedisClusterBuilder ephemeral();
    com.seeyon.boot.starter.cache.redis.embedded.RedisClusterBuilder sentinelCount(int);
    com.seeyon.boot.starter.cache.redis.embedded.RedisClusterBuilder sentinelStartingPort(int);
    com.seeyon.boot.starter.cache.redis.embedded.RedisClusterBuilder quorumSize(int);
    com.seeyon.boot.starter.cache.redis.embedded.RedisClusterBuilder replicationGroup(java.lang.String, int);
    com.seeyon.boot.starter.cache.redis.embedded.RedisCluster build();
    private java.util.List<com.seeyon.boot.starter.cache.redis.embedded.Redis> buildServers();
    private void buildSlaves(java.util.List<com.seeyon.boot.starter.cache.redis.embedded.Redis>, com.seeyon.boot.starter.cache.redis.embedded.RedisClusterBuilder$ReplicationGroup);
    private com.seeyon.boot.starter.cache.redis.embedded.Redis buildMaster(com.seeyon.boot.starter.cache.redis.embedded.RedisClusterBuilder$ReplicationGroup);
    private java.util.List<com.seeyon.boot.starter.cache.redis.embedded.Redis> buildSentinels();
    private com.seeyon.boot.starter.cache.redis.embedded.Redis buildSentinel();
    private int nextSentinelPort();
```

### `RedisSentinelBuilder`（17 方法）

`com.seeyon.boot.starter.cache.redis.embedded.RedisSentinelBuilder`

```java
    com.seeyon.boot.starter.cache.redis.embedded.RedisSentinelBuilder redisExecProvider(com.seeyon.boot.starter.cache.redis.embedded.RedisExecProvider);
    com.seeyon.boot.starter.cache.redis.embedded.RedisSentinelBuilder port(java.lang.Integer);
    com.seeyon.boot.starter.cache.redis.embedded.RedisSentinelBuilder masterPort(java.lang.Integer);
    com.seeyon.boot.starter.cache.redis.embedded.RedisSentinelBuilder masterName(java.lang.String);
    com.seeyon.boot.starter.cache.redis.embedded.RedisSentinelBuilder quorumSize(int);
    com.seeyon.boot.starter.cache.redis.embedded.RedisSentinelBuilder downAfterMilliseconds(java.lang.Long);
    com.seeyon.boot.starter.cache.redis.embedded.RedisSentinelBuilder failoverTimeout(java.lang.Long);
    com.seeyon.boot.starter.cache.redis.embedded.RedisSentinelBuilder parallelSyncs(int);
    com.seeyon.boot.starter.cache.redis.embedded.RedisSentinelBuilder configFile(java.lang.String);
    com.seeyon.boot.starter.cache.redis.embedded.RedisSentinelBuilder setting(java.lang.String);
    com.seeyon.boot.starter.cache.redis.embedded.RedisSentinel build();
    private void tryResolveConfAndExec();
    void reset();
    void addDefaultReplicationGroup();
    private void resolveSentinelConf()
    private java.lang.String resolveConfigName();
    private java.util.List<java.lang.String> buildCommandArgs();
```

### `RedisServerBuilder`（12 方法）

`com.seeyon.boot.starter.cache.redis.embedded.RedisServerBuilder`

```java
    com.seeyon.boot.starter.cache.redis.embedded.RedisServerBuilder redisExecProvider(com.seeyon.boot.starter.cache.redis.embedded.RedisExecProvider);
    com.seeyon.boot.starter.cache.redis.embedded.RedisServerBuilder port(int);
    com.seeyon.boot.starter.cache.redis.embedded.RedisServerBuilder slaveOf(java.lang.String, int);
    com.seeyon.boot.starter.cache.redis.embedded.RedisServerBuilder slaveOf(java.net.InetSocketAddress);
    com.seeyon.boot.starter.cache.redis.embedded.RedisServerBuilder configFile(java.lang.String);
    com.seeyon.boot.starter.cache.redis.embedded.RedisServerBuilder setting(java.lang.String);
    com.seeyon.boot.starter.cache.redis.embedded.RedisServer build();
    void reset();
    private void tryResolveConfAndExec();
    private void resolveConfAndExec()
    private java.lang.String resolveConfigName();
    private java.util.List<java.lang.String> buildCommandArgs();
```

### `CacheAutoConfiguration`（11 方法）

`com.seeyon.boot.starter.cache.CacheAutoConfiguration`

```java
    protected void redisConnectionCheckTask();
    com.seeyon.boot.starter.cache.DefaultRedisSerializer defaultRedisSerializer();
    com.seeyon.boot.starter.cache.JacksonRedisSerializer jacksonRedisSerializer();
    com.seeyon.boot.starter.cache.DefaultKeySerializer defaultKeySerializer();
    org.springframework.data.redis.core.RedisTemplate redisTemplate(org.springframework.data.redis.connection.RedisConnectionFactory, com.seeyon.boot.starter.cache.DefaultKeySerializer, com.seeyon.boot.starter.cache.DefaultRedisSerializer, com.seeyon.boot.starter.cache.JacksonRedisSerializer);
    com.seeyon.boot.starter.cache.declarative.RedisInfoChecker checkRedisVersion(org.springframework.data.redis.core.RedisTemplate);
    org.springframework.cache.annotation.CachingConfigurer cachingConfigurer(org.springframework.data.redis.core.RedisTemplate, com.seeyon.boot.starter.cache.CacheProperties);
    com.seeyon.boot.starter.cache.limit.RateChecker redisRateChecker();
    org.springframework.cache.CacheManager cacheManager(org.springframework.cache.annotation.CachingConfigurer);
    org.springframework.cache.CacheManager ctpLocalCacheManager(org.springframework.data.redis.core.RedisTemplate, com.seeyon.boot.starter.cache.CacheProperties);
```

### `RedisUtils`（10 方法）

`com.seeyon.boot.starter.cache.util.RedisUtils`

```java
    static boolean expire(java.lang.String, long);
    static boolean expire(java.lang.String, long, java.util.concurrent.TimeUnit);
    static boolean hasKey(java.lang.String);
    static java.lang.Object getKey(java.lang.String);
    static void del(java.lang.String...);
    static void del(java.util.List<java.lang.String>);
    static void del(java.util.Set<java.lang.String>);
    static boolean set(java.lang.String, java.lang.Object);
    static boolean set(java.lang.String, java.lang.Object, long);
    static private static void initRedisTemplateIfNecessary();
```

### `RedisExecProvider`（6 方法）

`com.seeyon.boot.starter.cache.redis.embedded.RedisExecProvider`

```java
    static com.seeyon.boot.starter.cache.redis.embedded.RedisExecProvider defaultProvider();
    private void initExecutables();
    com.seeyon.boot.starter.cache.redis.embedded.RedisExecProvider override(com.seeyon.boot.starter.cache.redis.embedded.util.OS, java.lang.String);
    com.seeyon.boot.starter.cache.redis.embedded.RedisExecProvider override(com.seeyon.boot.starter.cache.redis.embedded.util.OS, com.seeyon.boot.starter.cache.redis.embedded.util.Architecture, java.lang.String);
    java.io.File get()
    private boolean fileExists(java.lang.String);
```

### `CacheUtils`（5 方法）

`com.seeyon.boot.starter.cache.util.CacheUtils`

```java
    static java.lang.String getCompleteCacheKey(java.lang.String, java.lang.String);
    static java.lang.String getCompleteCacheKeyWithBuildVersion(java.lang.String, java.lang.String, java.lang.String);
    static java.lang.String getCompleteCacheKeyWithoutTenantId(java.lang.String, java.lang.String);
    static java.lang.String getCompleteCacheKeyWithoutAppName(java.lang.String, java.lang.String);
    static java.lang.String getCacheKeyWithoutTenantIdAndAppName(java.lang.String, java.lang.String);
```

### `RedisLogUtils`（5 方法）

`com.seeyon.boot.starter.cache.util.RedisLogUtils`

```java
    static void begin(java.lang.String, java.lang.Object);
    static void log(java.lang.String, java.lang.Object);
    static <T> java.util.List<T> get(java.lang.String);
    static private static java.lang.String key(java.lang.String);
    static private static void init();
```

### `TenantUtils`（5 方法）

`com.seeyon.boot.starter.cache.util.TenantUtils`

```java
    static private static org.springframework.data.redis.core.RedisTemplate getRedisTemplate();
    static java.lang.Long getTenantIdByName(java.lang.String);
    static com.seeyon.boot.context.model.TenantInfo getTenantInfo();
    static com.seeyon.boot.context.model.TenantInfo getTenantInfo(java.lang.Long);
    static java.util.List<com.seeyon.boot.context.model.TenantInfo> getAllActiveTenant();
```

### `DefaultCacheErrorHandler`（4 方法）

`com.seeyon.boot.starter.cache.declarative.DefaultCacheErrorHandler`

```java
    void handleCacheGetError(java.lang.RuntimeException, org.springframework.cache.Cache, java.lang.Object);
    void handleCachePutError(java.lang.RuntimeException, org.springframework.cache.Cache, java.lang.Object, java.lang.Object);
    void handleCacheEvictError(java.lang.RuntimeException, org.springframework.cache.Cache, java.lang.Object);
    void handleCacheClearError(java.lang.RuntimeException, org.springframework.cache.Cache);
```

### `DefaultCachingConfigurer`（4 方法）

`com.seeyon.boot.starter.cache.declarative.DefaultCachingConfigurer`

```java
    org.springframework.cache.CacheManager cacheManager();
    org.springframework.cache.interceptor.CacheResolver cacheResolver();
    org.springframework.cache.interceptor.KeyGenerator keyGenerator();
    org.springframework.cache.interceptor.CacheErrorHandler errorHandler();
```

## 四、枚举（2）

- `Architecture`（2 常量）：x86, x86_64
- `OS`（3 常量）：WINDOWS, UNIX, MAC_OS_X
