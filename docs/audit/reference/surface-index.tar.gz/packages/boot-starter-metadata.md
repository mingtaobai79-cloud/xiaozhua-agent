# boot-starter-metadata：接口与方法签名

> 自动生成，勿手改。`tools/core/platform/emit_package_surfaces.py` 重跑即可。
> 构件 `com.seeyon:boot-starter-metadata`（jar `boot-starter-metadata-5.3.600.jar`）
> 规模：81 类 / 1 接口 / 0 注解 / 2 枚举 / 13 个关键类 / 1160 方法。
> 签名逐字来自 javap 原文；已去掉 `public` 前缀与 `throws` 子句。

## 一、接口（1）

### `LoadJarResourceAppService`（2 方法）

`com.seeyon.ctp.metadata.api.LoadJarResourceAppService`

```java
    com.seeyon.boot.transport.SingleResponse<java.lang.String> getJsonMetadataData(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.metadata.dto.request.SearchJsonMetadataDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.String> getRuntimeJsonData(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.metadata.dto.request.SearchJsonMetadataDto>);
```

## 二、关键类（13）

### `MetadataService`（154 方法）

`com.seeyon.ctp.metadata.domain.service.MetadataService`

```java
    boolean removeMetadataByAppName(java.lang.String);
    boolean removeMetadataByType(java.lang.String, java.lang.String, com.seeyon.ctp.metadata.enums.MetadataTypeEnum);
    private boolean removeMetadata(java.lang.String, java.lang.String, com.seeyon.ctp.metadata.enums.MetadataTypeEnum);
    boolean removeTenantMetadataByFullNames(java.lang.String, com.seeyon.ctp.metadata.enums.MetadataTypeEnum, java.util.List<java.lang.String>);
    boolean createStarterMetadata(java.util.Map<java.lang.String, com.seeyon.ctp.metadata.dto.StarterMetadataDto>);
    boolean createStarterMetadataOnlyMultiVersion(com.seeyon.ctp.metadata.dto.StarterMetadataDto);
    com.seeyon.ctp.metadata.dto.StarterMetadataDto downgradeStarterMetadata(java.lang.String, java.lang.String);
    boolean downgradeServiceMetadata(java.lang.String, boolean);
    private void createMultiVersionStaterMetadata(com.seeyon.ctp.metadata.dto.StarterMetadataDto);
    private boolean needUpdate(com.seeyon.ctp.metadata.dto.StarterMetadataDto, com.seeyon.ctp.metadata.dto.StarterMetadataDto);
    private boolean needUpdate(com.seeyon.ctp.metadata.dto.ServiceMetadataDto, com.seeyon.ctp.metadata.dto.ServiceMetadataDto);
    boolean createJsonMetadata(java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.io.InputStream);
    boolean createMultiVersionJsonMetadata(java.lang.String, java.lang.String, java.lang.String, java.io.InputStream);
    boolean createJsonMetadata(java.lang.String, java.lang.String, java.lang.String, java.lang.String, boolean, java.io.InputStream);
    boolean createMetadata(com.seeyon.ctp.metadata.enums.MetadataTypeEnum, java.lang.String, java.lang.String, java.util.Map, boolean);
    boolean storageExist(java.lang.String, java.lang.String);
    boolean storageExistForStarter(java.lang.String, java.lang.String);
    boolean createMetadata(com.seeyon.ctp.metadata.enums.MetadataTypeEnum, java.lang.String, java.lang.String, java.util.Map, boolean, boolean);
    void createMultiVersionMetadata(com.seeyon.ctp.metadata.enums.MetadataTypeEnum, java.lang.String, java.lang.String, java.util.Map, java.lang.String);
    boolean createServiceMetadata(com.seeyon.ctp.metadata.dto.ServiceMetadataDto);
    boolean createServiceMetadata(com.seeyon.ctp.metadata.dto.ServiceMetadataDto, boolean);
    void createMultiVersionServiceMetadata(com.seeyon.ctp.metadata.dto.ServiceMetadataDto);
    java.lang.String selectJsonMetadata(java.lang.String, java.lang.String, java.lang.String);
    java.util.Map selectOrigMetadataMap(com.seeyon.ctp.metadata.enums.MetadataTypeEnum, java.lang.String);
    <T> java.util.List<T> select(com.seeyon.ctp.metadata.enums.MetadataTypeEnum, com.seeyon.ctp.metadata.dto.request.SearchMetadataDto);
    private <T> java.util.List<T> select(com.seeyon.ctp.metadata.enums.MetadataTypeEnum, java.lang.String, java.lang.String, boolean, boolean);
    <T> java.util.List<T> selectByFullNames(com.seeyon.ctp.metadata.enums.MetadataTypeEnum, com.seeyon.ctp.metadata.dto.request.SearchByFullNamesDto);
    private <T> java.util.List<T> selectByFullNames(com.seeyon.ctp.metadata.enums.MetadataTypeEnum, java.lang.String, java.lang.String, java.util.List<java.lang.String>, boolean, boolean);
    <T> T selectByFullName(com.seeyon.ctp.metadata.enums.MetadataTypeEnum, com.seeyon.ctp.metadata.dto.request.SearchByFullNameDto);
    private <T> T selectByFullName(com.seeyon.ctp.metadata.enums.MetadataTypeEnum, java.lang.String, java.lang.String, java.lang.String, boolean, boolean);
    java.lang.String selectMetadataMd5(com.seeyon.ctp.metadata.dto.request.SearchMd5Dto);
    java.util.List<java.lang.String> selectMultiMetadataMd5(com.seeyon.ctp.metadata.dto.request.MultiSearchMd5Dto);
    private java.lang.String localeCacheKey(java.lang.String, java.lang.String);
    void clearI18nCache(com.seeyon.boot.starter.i18n.dto.BundleChangeMessageDto);
    private java.lang.String getAppName(java.lang.String);
    java.util.Map selectForMap(com.seeyon.ctp.metadata.enums.MetadataTypeEnum, com.seeyon.ctp.metadata.dto.request.SearchMetadataDto);
    private java.util.Map selectForMap(com.seeyon.ctp.metadata.enums.MetadataTypeEnum, java.lang.String, java.lang.String, boolean, boolean);
    private boolean isSystemAdmin();
    private void mergeModifyAttributes(com.seeyon.ctp.metadata.enums.MetadataTypeEnum, java.lang.String, java.util.Map);
    private java.util.Map selectTenantMetadataForMap(com.seeyon.ctp.metadata.enums.MetadataTypeEnum, java.lang.String);
    java.util.List<com.seeyon.ctp.metadata.dto.DtoMetadataDto> selectEntityRelationDtoMetadata(com.seeyon.ctp.metadata.dto.request.SearchMetadataDto);
    java.util.List<com.seeyon.ctp.metadata.dto.DtoMetadataDto> selectDtoMetadataByEntity(com.seeyon.ctp.metadata.dto.request.SearchByFullNamesDto);
    private java.util.List<com.seeyon.ctp.metadata.dto.DtoMetadataDto> selectDtoMetadataByEntity(java.lang.String, java.lang.String, java.util.List<java.lang.String>, boolean, boolean);
    com.seeyon.ctp.metadata.dto.DtoMetadataDto selectDtoMetadataByEntity(com.seeyon.ctp.metadata.dto.request.SearchByFullNameDto);
    private com.seeyon.ctp.metadata.dto.DtoMetadataDto selectDtoMetadataByEntity(java.lang.String, java.lang.String, java.lang.String, boolean, boolean);
    java.util.List<com.seeyon.ctp.metadata.dto.ReferMetadataDto> selectReferMetadataByEntity(com.seeyon.ctp.metadata.dto.request.SearchByFullNameDto);
    java.util.List<com.seeyon.ctp.metadata.dto.ReferMetadataDto> selectReferMetadataByEntity(com.seeyon.ctp.metadata.dto.request.SearchReferByFullNamesDto);
    boolean checkServiceVersion(java.util.Map<java.lang.String, java.lang.String>);
    private int checkMavenInfo(com.seeyon.ctp.metadata.dto.model.MavenInfoDto, com.seeyon.ctp.metadata.dto.model.MavenInfoDto);
    com.seeyon.ctp.metadata.dto.ServiceMetadataDto selectServiceMetadataByName(java.lang.String);
    private com.seeyon.ctp.metadata.dto.ServiceMetadataDto selectServiceMetadataByName(java.lang.String, boolean);
    java.util.List<com.seeyon.ctp.metadata.dto.ServiceMetadataDto> selectServiceMetadataByAppNames(java.util.List<java.lang.String>);
    com.seeyon.ctp.metadata.dto.StarterMetadataDto selectStarterMetadataByName(java.lang.String);
    private com.seeyon.ctp.metadata.dto.StarterMetadataDto getNewVersionStarterFromStorage(java.lang.String);
    private java.lang.String getNewVersion(java.util.Set<java.lang.String>);
    private java.lang.String getNearVersion(java.util.Set<java.lang.String>, java.lang.String);
    private com.seeyon.ctp.metadata.dto.ServiceMetadataDto getNewVersionServiceFromStorage(java.lang.String);
    private com.seeyon.ctp.metadata.dto.ServiceMetadataDto getNewVersionServiceFromStorage(java.util.Map<java.lang.String, com.seeyon.ctp.metadata.dto.ServiceMetadataDto>);
    java.util.List<com.seeyon.ctp.metadata.dto.StarterMetadataDto> selectStarterMetadataByNames(java.util.List<java.lang.String>);
    java.util.List<com.seeyon.ctp.metadata.dto.ServiceMetadataDto> selectServiceMetadataList();
    java.util.Map<java.lang.String, com.seeyon.ctp.metadata.dto.ServiceMetadataDto> selectServiceMetadataFromRedis();
    java.util.Map<java.lang.String, com.seeyon.ctp.metadata.dto.ServiceMetadataDto> selectOldServiceMetadataFromStorage();
    private java.util.Map<java.lang.String, com.seeyon.ctp.metadata.dto.ServiceMetadataDto> selectServiceMetadataMap();
    private java.util.Map<java.lang.String, com.seeyon.ctp.metadata.dto.ServiceMetadataDto> getServiceMetadataCache();
    java.util.List<com.seeyon.ctp.metadata.dto.StarterMetadataDto> selectStarterMetadataList();
    java.util.List<com.seeyon.ctp.metadata.dto.StarterMetadataDto> selectMultiVersionStarterMetadataList(java.lang.String);
    private java.util.Map<java.lang.String, com.seeyon.ctp.metadata.dto.StarterMetadataDto> selectStarterMetadataMap();
    java.util.List<com.seeyon.ctp.metadata.dto.ServiceMetadataDto> selectMultiVersionServiceMetadataList(java.lang.String);
    com.seeyon.ctp.metadata.dto.ServiceMetadataDto selectServiceByVersion(java.lang.String, java.lang.String);
    private java.util.Map<java.lang.String, com.seeyon.ctp.metadata.dto.ServiceMetadataDto> selectMultiVersionServiceMetadataMap(java.lang.String);
    private java.util.Map<java.lang.String, com.seeyon.ctp.metadata.dto.StarterMetadataDto> selectMultiVersionStarterMetadataMap(java.lang.String);
    com.seeyon.ctp.metadata.dto.StarterMetadataDto selectStarterByVersion(java.lang.String, java.lang.String);
    boolean modifyEntityAttribute(com.seeyon.ctp.metadata.dto.request.EntityAttributeModifyDto);
    boolean coverAllModifyEntityAttribute(java.util.List<com.seeyon.ctp.metadata.dto.request.EntityAttributeModifyDto>);
    java.util.Map<java.lang.String, com.seeyon.ctp.metadata.dto.request.EntityAttributeModifyDto> selectModifiedEntityAttributes(java.lang.String);
    java.util.List<com.seeyon.ctp.metadata.dto.AggDtoMetadataDto> selectAggDtoMetadatas(com.seeyon.ctp.metadata.dto.request.SearchByFullNamesDto);
    com.seeyon.ctp.metadata.dto.AggDtoMetadataDto selectAggDtoMetadata(com.seeyon.ctp.metadata.dto.request.SearchByFullNameDto);
    private void createAggMetadata(java.lang.String, java.lang.String, java.util.Map<java.lang.String, com.seeyon.ctp.metadata.dto.EntityMetadataDto>);
    java.util.List<com.seeyon.ctp.metadata.dto.AggEntityMetadataDto> selectAggEntityMetadataByAppName(com.seeyon.ctp.metadata.dto.request.SearchMetadataDto);
    com.seeyon.ctp.metadata.dto.AggEntityMetadataDto selectAggEntityMetadataByFullName(com.seeyon.ctp.metadata.dto.request.SearchByFullNameDto);
    java.util.List<com.seeyon.ctp.metadata.dto.AggEntityMetadataDto> selectAggEntityMetadataByFullNames(com.seeyon.ctp.metadata.dto.request.SearchByFullNamesDto);
    java.util.List<com.seeyon.ctp.metadata.dto.EntityMetadataDto> selectEntityListByAgg(com.seeyon.ctp.metadata.dto.request.SearchByFullNameDto);
    void onChange(java.lang.String, java.lang.String, com.seeyon.ctp.metadata.enums.MetadataTypeEnum, java.lang.String, java.util.Map);
    private boolean useLocalCache(java.lang.String, java.lang.String);
    private java.lang.String redisKeyToStorageKey(java.lang.String);
    private boolean needSaveStorage(java.lang.String);
    private void syncSave2Storage(java.lang.String, java.util.Map);
    private void syncSave2Storage(java.lang.String, java.lang.String);
    private void syncSave2Storage(java.lang.String, java.io.InputStream);
    private void redis2storage(java.lang.String);
    private void asyncSave2Storage(java.lang.String, java.util.Map);
    com.seeyon.ctp.metadata.dto.ServiceMetadataDto currentService();
    void refresh(java.lang.String);
    void downgrade();
    private void scan(boolean);
    boolean ignoreCheckServiceMetadata();
    private void updateServiceListCache();
    void task();
    private void deleteFromStorage(java.util.List<java.lang.String>);
    void saveServiceMetadataToStorage(java.util.Map<java.lang.String, com.seeyon.ctp.metadata.dto.ServiceMetadataDto>);
    java.util.Map<java.lang.String, java.util.Map<java.lang.String, com.seeyon.ctp.metadata.dto.ServiceMetadataDto>> getServiceMetadataFromStorage();
    private java.util.Map loadStarterMetadataFromStorage();
    private java.lang.String downloadStr(java.lang.String);
    private java.lang.String getOldVersionJsonMetadata(java.lang.String, java.lang.String, java.lang.String);
    private java.lang.String getMetadataStrFromStorage(java.lang.String);
    private java.util.Map loadMetadataFromStorage(java.lang.String, boolean);
    void started();
    void upgradeByAppName(java.lang.String, java.util.List<java.lang.String>);
    void asyncUpgrade();
    void upgrade();
    private void multiVersionServiceUpgrade(java.lang.String);
    private void multiVersionStarterUpgrade(java.lang.String);
    private void upgrade(java.lang.String, java.util.List<java.lang.String>);
    private void upgrade(java.util.Map<java.lang.String, java.lang.String>, java.util.List<java.lang.String>);
    private void upgradeKey(java.lang.String, java.lang.String, java.util.List<java.lang.String>);
    private java.lang.Object callServer(java.lang.String, java.lang.Object);
    boolean addIncrementalMetadata(com.seeyon.ctp.metadata.enums.MetadataTypeEnum, java.lang.String, java.util.Map);
    <T> java.util.List<T> select(com.seeyon.ctp.metadata.enums.MetadataTypeEnum, java.lang.String);
    <T> java.util.List<T> select(com.seeyon.ctp.metadata.enums.MetadataTypeEnum, java.lang.String, java.lang.String);
    <T> java.util.List<T> select(com.seeyon.ctp.metadata.enums.MetadataTypeEnum, java.lang.String, java.lang.String, boolean);
    java.util.Map selectForMap(com.seeyon.ctp.metadata.enums.MetadataTypeEnum, java.lang.String);
    java.util.Map selectForMap(com.seeyon.ctp.metadata.enums.MetadataTypeEnum, java.lang.String, java.lang.String);
    java.util.Map selectForMap(com.seeyon.ctp.metadata.enums.MetadataTypeEnum, java.lang.String, java.lang.String, boolean);
    <T> java.util.List<T> selectByFullNames(com.seeyon.ctp.metadata.enums.MetadataTypeEnum, java.lang.String, java.lang.String, java.util.List<java.lang.String>);
    <T> java.util.List<T> selectByFullNames(com.seeyon.ctp.metadata.enums.MetadataTypeEnum, java.lang.String, java.lang.String, java.util.List<java.lang.String>, boolean);
    <T> T selectByFullName(com.seeyon.ctp.metadata.enums.MetadataTypeEnum, java.lang.String, java.lang.String, java.lang.String);
    <T> T selectByFullName(com.seeyon.ctp.metadata.enums.MetadataTypeEnum, java.lang.String, java.lang.String, java.lang.String, boolean);
    java.util.List<com.seeyon.ctp.metadata.dto.EntityMetadataDto> selectEntityListByAgg(java.lang.String, java.lang.String, java.lang.String);
    java.util.List<com.seeyon.ctp.metadata.dto.ReferMetadataDto> selectReferMetadataByEntity(java.lang.String, java.lang.String, java.lang.String);
    java.util.List<com.seeyon.ctp.metadata.dto.ReferMetadataDto> selectReferMetadataByEntity(java.lang.String, java.lang.String, java.lang.String, java.util.List<java.lang.String>);
    java.util.List<com.seeyon.ctp.metadata.dto.DtoMetadataDto> selectEntityRelationDtoMetadata(java.lang.String, java.lang.String);
    java.util.List<com.seeyon.ctp.metadata.dto.DtoMetadataDto> selectDtoMetadataByEntity(java.lang.String, java.lang.String, java.util.List<java.lang.String>);
    com.seeyon.ctp.metadata.dto.DtoMetadataDto selectDtoMetadataByEntity(java.lang.String, java.lang.String, java.lang.String);
    java.util.List<com.seeyon.ctp.metadata.dto.AggDtoMetadataDto> selectAggDtoMetadatas(java.lang.String, java.lang.String, java.util.List<java.lang.String>);
    com.seeyon.ctp.metadata.dto.AggDtoMetadataDto selectAggDtoMetadata(java.lang.String, java.lang.String, java.lang.String);
    java.util.List<com.seeyon.ctp.metadata.dto.AggDtoMetadataDto> selectAggDtoMetadatas(java.lang.String, java.lang.String, java.util.List<java.lang.String>, boolean);
    com.seeyon.ctp.metadata.dto.AggDtoMetadataDto selectAggDtoMetadata(java.lang.String, java.lang.String, java.lang.String, boolean);
    java.util.List<com.seeyon.ctp.metadata.dto.AggEntityMetadataDto> selectAggEntityMetadataByAppName(java.lang.String, java.lang.String);
    com.seeyon.ctp.metadata.dto.AggEntityMetadataDto selectAggEntityMetadataByFullName(java.lang.String, java.lang.String, java.lang.String);
    java.util.List<com.seeyon.ctp.metadata.dto.AggEntityMetadataDto> selectAggEntityMetadataByFullNames(java.lang.String, java.lang.String, java.util.List<java.lang.String>);
```

### `MetadataQueryAppService`（124 方法）

`com.seeyon.ctp.metadata.api.MetadataQueryAppService`

```java
    com.seeyon.boot.transport.SingleResponse<java.lang.String> selectMetadataMd5(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.metadata.dto.request.SearchMd5Dto>);
    com.seeyon.boot.transport.ListResponse<java.lang.String> selectMultiMetadataMd5(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.metadata.dto.request.MultiSearchMd5Dto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Boolean> checkServiceVersion(com.seeyon.boot.transport.SingleRequest<java.util.Map<java.lang.String, java.lang.String>>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.ctp.metadata.dto.ServiceMetadataDto> selectServiceMetadataList();
    com.seeyon.boot.transport.ListResponse<com.seeyon.ctp.metadata.dto.ServiceMetadataDto> selectServiceMetadataByNames(com.seeyon.boot.transport.SingleRequest<java.util.List<java.lang.String>>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.ctp.metadata.dto.ServiceMetadataDto> selectServiceMetadataByName(com.seeyon.boot.transport.SingleRequest<java.lang.String>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.ctp.metadata.dto.ServiceMetadataDto> selectMultiVersionServiceMetadataByName(com.seeyon.boot.transport.SingleRequest<java.lang.String>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.ctp.metadata.dto.ServiceMetadataDto> selectSubServiceMetadataList(com.seeyon.boot.transport.SingleRequest<java.lang.String>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.ctp.metadata.dto.ServiceMetadataDto> selectNormalServiceMetadataList();
    com.seeyon.boot.transport.ListResponse<com.seeyon.ctp.metadata.dto.ServiceMetadataDto> selectDevelopmentServiceMetadataList();
    com.seeyon.boot.transport.ListResponse<com.seeyon.ctp.metadata.dto.ServiceMetadataDto> selectOnlineServiceMetadataList();
    com.seeyon.boot.transport.ListResponse<com.seeyon.ctp.metadata.dto.RestApiMetadataDto> selectRestApiMetadata(com.seeyon.boot.transport.SingleRequest<java.lang.String>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.ctp.metadata.dto.RestApiMetadataDto> selectRestApiMetadataList(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.metadata.dto.request.SearchMetadataDto>);
    com.seeyon.boot.transport.PageResponse<com.seeyon.ctp.metadata.dto.RestApiMetadataDto> selectRestApiMetadataForPage(com.seeyon.boot.transport.PageDtoRequest<com.seeyon.ctp.metadata.dto.request.SearchPageDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.ctp.metadata.dto.RestApiMetadataDto> selectRestApiMetadataByFullNames(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.metadata.dto.request.SearchByFullNamesDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.ctp.metadata.dto.RestApiMetadataDto> selectRestApiMetadataByFullName(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.metadata.dto.request.SearchByFullNameDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.ctp.metadata.dto.RestApiMetadataDto> selectRestApiMetadataExcludeBoot(com.seeyon.boot.transport.SingleRequest<java.lang.String>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.ctp.metadata.dto.RestApiMetadataDto> selectRestApiMetadataListExcludeBoot(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.metadata.dto.request.SearchMetadataDto>);
    com.seeyon.boot.transport.PageResponse<com.seeyon.ctp.metadata.dto.RestApiMetadataDto> selectRestApiMetadataExcludeBootForPage(com.seeyon.boot.transport.PageDtoRequest<com.seeyon.ctp.metadata.dto.request.SearchPageDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.ctp.metadata.dto.DtoMetadataDto> selectDtoMetadata(com.seeyon.boot.transport.SingleRequest<java.lang.String>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.ctp.metadata.dto.DtoMetadataDto> selectDtoMetadataList(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.metadata.dto.request.SearchMetadataDto>);
    com.seeyon.boot.transport.PageResponse<com.seeyon.ctp.metadata.dto.DtoMetadataDto> selectDtoMetadataForPage(com.seeyon.boot.transport.PageDtoRequest<com.seeyon.ctp.metadata.dto.request.SearchPageDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.ctp.metadata.dto.DtoMetadataDto> selectDtoMetadataByFullNames(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.metadata.dto.request.SearchByFullNamesDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.ctp.metadata.dto.DtoMetadataDto> selectDtoMetadataByFullName(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.metadata.dto.request.SearchByFullNameDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.ctp.metadata.dto.DtoMetadataDto> selectDtoMetadataExcludeBoot(com.seeyon.boot.transport.SingleRequest<java.lang.String>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.ctp.metadata.dto.DtoMetadataDto> selectDtoMetadataListExcludeBoot(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.metadata.dto.request.SearchMetadataDto>);
    com.seeyon.boot.transport.PageResponse<com.seeyon.ctp.metadata.dto.DtoMetadataDto> selectDtoMetadataExcludeBootForPage(com.seeyon.boot.transport.PageDtoRequest<com.seeyon.ctp.metadata.dto.request.SearchPageDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.ctp.metadata.dto.DtoMetadataDto> selectPublicDtoMetadataList(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.metadata.dto.request.SearchMetadataDto>);
    com.seeyon.boot.transport.PageResponse<com.seeyon.ctp.metadata.dto.DtoMetadataDto> selectPublicDtoMetadataForPage(com.seeyon.boot.transport.PageDtoRequest<com.seeyon.ctp.metadata.dto.request.SearchPageDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.ctp.metadata.dto.EnumMetadataDto> selectEnumMetadata(com.seeyon.boot.transport.SingleRequest<java.lang.String>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.ctp.metadata.dto.EnumMetadataDto> selectEnumMetadataList(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.metadata.dto.request.SearchMetadataDto>);
    com.seeyon.boot.transport.PageResponse<com.seeyon.ctp.metadata.dto.EnumMetadataDto> selectEnumMetadataForPage(com.seeyon.boot.transport.PageDtoRequest<com.seeyon.ctp.metadata.dto.request.SearchPageDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.ctp.metadata.dto.EnumMetadataDto> selectEnumMetadataByFullNames(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.metadata.dto.request.SearchByFullNamesDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.ctp.metadata.dto.EnumMetadataDto> selectEnumMetadataByFullName(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.metadata.dto.request.SearchByFullNameDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.ctp.metadata.dto.EnumMetadataDto> selectPublicEnumMetadataList(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.metadata.dto.request.SearchMetadataDto>);
    com.seeyon.boot.transport.PageResponse<com.seeyon.ctp.metadata.dto.EnumMetadataDto> selectPublicEnumMetadataForPage(com.seeyon.boot.transport.PageDtoRequest<com.seeyon.ctp.metadata.dto.request.SearchPageDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.ctp.metadata.dto.EntityMetadataDto> selectEntityMetadata(com.seeyon.boot.transport.SingleRequest<java.lang.String>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.ctp.metadata.dto.EntityMetadataDto> selectEntityMetadataList(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.metadata.dto.request.SearchMetadataDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.ctp.metadata.dto.EntityMetadataDto> selectPublicEntityMetadataList(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.metadata.dto.request.SearchMetadataDto>);
    com.seeyon.boot.transport.PageResponse<com.seeyon.ctp.metadata.dto.EntityMetadataDto> selectEntityMetadataForPage(com.seeyon.boot.transport.PageDtoRequest<com.seeyon.ctp.metadata.dto.request.SearchPageDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.ctp.metadata.dto.EntityMetadataDto> selectEntityMetadataByFullNames(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.metadata.dto.request.SearchByFullNamesDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.ctp.metadata.dto.EntityMetadataDto> selectEntityMetadataByFullName(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.metadata.dto.request.SearchByFullNameDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.ctp.metadata.dto.EntityMetadataDto> selectEntityListByAgg(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.metadata.dto.request.SearchByFullNameDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.ctp.metadata.dto.EntityMetadataDto> selectEntityMetadataExcludeBoot(com.seeyon.boot.transport.SingleRequest<java.lang.String>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.ctp.metadata.dto.EntityMetadataDto> selectEntityMetadataListExcludeBoot(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.metadata.dto.request.SearchMetadataDto>);
    com.seeyon.boot.transport.PageResponse<com.seeyon.ctp.metadata.dto.EntityMetadataDto> selectEntityMetadataExcludeBootForPage(com.seeyon.boot.transport.PageDtoRequest<com.seeyon.ctp.metadata.dto.request.SearchPageDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.ctp.metadata.dto.OpenApiMetadataDto> selectOpenApiMetadata(com.seeyon.boot.transport.SingleRequest<java.lang.String>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.ctp.metadata.dto.OpenApiMetadataDto> selectOpenApiMetadataList(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.metadata.dto.request.SearchMetadataDto>);
    com.seeyon.boot.transport.PageResponse<com.seeyon.ctp.metadata.dto.OpenApiMetadataDto> selectOpenApiMetadataForPage(com.seeyon.boot.transport.PageDtoRequest<com.seeyon.ctp.metadata.dto.request.SearchPageDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.ctp.metadata.dto.OpenApiMetadataDto> selectOpenApiMetadataByFullNames(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.metadata.dto.request.SearchByFullNamesDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.ctp.metadata.dto.OpenApiMetadataDto> selectOpenApiMetadataByFullName(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.metadata.dto.request.SearchByFullNameDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.ctp.metadata.dto.AppServiceMetadataDto> selectAppServiceMetadata(com.seeyon.boot.transport.SingleRequest<java.lang.String>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.ctp.metadata.dto.AppServiceMetadataDto> selectAppServiceMetadataList(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.metadata.dto.request.SearchMetadataDto>);
    com.seeyon.boot.transport.PageResponse<com.seeyon.ctp.metadata.dto.AppServiceMetadataDto> selectAppServiceMetadataForPage(com.seeyon.boot.transport.PageDtoRequest<com.seeyon.ctp.metadata.dto.request.SearchPageDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.ctp.metadata.dto.AppServiceMetadataDto> selectPublicAppServiceMetadata(com.seeyon.boot.transport.SingleRequest<java.lang.String>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.ctp.metadata.dto.AppServiceMetadataDto> selectPublicAppServiceMetadataList(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.metadata.dto.request.SearchMetadataDto>);
    private java.util.List<com.seeyon.ctp.metadata.dto.AppServiceMetadataDto> screenPublicAppService(java.util.List<com.seeyon.ctp.metadata.dto.AppServiceMetadataDto>);
    com.seeyon.boot.transport.PageResponse<com.seeyon.ctp.metadata.dto.AppServiceMetadataDto> selectPublicAppServiceMetadataForPage(com.seeyon.boot.transport.PageDtoRequest<com.seeyon.ctp.metadata.dto.request.SearchPageDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.ctp.metadata.dto.AppServiceMetadataDto> selectAppServiceMetadataExcludeBoot(com.seeyon.boot.transport.SingleRequest<java.lang.String>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.ctp.metadata.dto.AppServiceMetadataDto> selectAppServiceMetadataListExcludeBoot(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.metadata.dto.request.SearchMetadataDto>);
    com.seeyon.boot.transport.PageResponse<com.seeyon.ctp.metadata.dto.AppServiceMetadataDto> selectAppServiceMetadataExcludeBootForPage(com.seeyon.boot.transport.PageDtoRequest<com.seeyon.ctp.metadata.dto.request.SearchPageDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.ctp.metadata.dto.AppServiceMetadataDto> selectAppServiceMetadataByFullNames(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.metadata.dto.request.SearchByFullNamesDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.ctp.metadata.dto.AppServiceMetadataDto> selectAppServiceMetadataByFullName(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.metadata.dto.request.SearchByFullNameDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.ctp.metadata.dto.MqMetadataDto> selectMqMetadata(com.seeyon.boot.transport.SingleRequest<java.lang.String>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.ctp.metadata.dto.MqMetadataDto> selectMqMetadataList(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.metadata.dto.request.SearchMetadataDto>);
    com.seeyon.boot.transport.PageResponse<com.seeyon.ctp.metadata.dto.MqMetadataDto> selectMqMetadataForPage(com.seeyon.boot.transport.PageDtoRequest<com.seeyon.ctp.metadata.dto.request.SearchPageDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.ctp.metadata.dto.MqMetadataDto> selectMqMetadataByFullNames(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.metadata.dto.request.SearchByFullNamesDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.ctp.metadata.dto.MqMetadataDto> selectMqMetadataByFullName(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.metadata.dto.request.SearchByFullNameDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.ctp.metadata.dto.MqMetadataDto> selectMqMetadataExcludeBoot(com.seeyon.boot.transport.SingleRequest<java.lang.String>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.ctp.metadata.dto.MqMetadataDto> selectMqMetadataListExcludeBoot(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.metadata.dto.request.SearchMetadataDto>);
    com.seeyon.boot.transport.PageResponse<com.seeyon.ctp.metadata.dto.MqMetadataDto> selectMqMetadataExcludeBootForPage(com.seeyon.boot.transport.PageDtoRequest<com.seeyon.ctp.metadata.dto.request.SearchPageDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.ctp.metadata.dto.MqMetadataDto> selectPublicMqMetadataList(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.metadata.dto.request.SearchMetadataDto>);
    com.seeyon.boot.transport.PageResponse<com.seeyon.ctp.metadata.dto.MqMetadataDto> selectPublicMqMetadataForPage(com.seeyon.boot.transport.PageDtoRequest<com.seeyon.ctp.metadata.dto.request.SearchPageDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.ctp.metadata.dto.DtoMetadataDto> selectEntityRelationDtoMetadata(com.seeyon.boot.transport.SingleRequest<java.lang.String>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.ctp.metadata.dto.DtoMetadataDto> selectEntityRelationDtoMetadataList(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.metadata.dto.request.SearchMetadataDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.ctp.metadata.dto.DtoMetadataDto> selectEntityRelationDtoMetadataExcludeBoot(com.seeyon.boot.transport.SingleRequest<java.lang.String>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.ctp.metadata.dto.DtoMetadataDto> selectEntityRelationDtoMetadataListExcludeBoot(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.metadata.dto.request.SearchMetadataDto>);
    com.seeyon.boot.transport.PageResponse<com.seeyon.ctp.metadata.dto.DtoMetadataDto> selectEntityRelationDtoMetadataExcludeBootForPage(com.seeyon.boot.transport.PageDtoRequest<com.seeyon.ctp.metadata.dto.request.SearchPageDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.ctp.metadata.dto.DtoMetadataDto> selectDtoMetadataByEntityFullNames(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.metadata.dto.request.SearchByFullNamesDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.ctp.metadata.dto.DtoMetadataDto> selectDtoMetadataByEntityFullName(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.metadata.dto.request.SearchByFullNameDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.ctp.metadata.dto.AggMetadataDto> selectAggMetadata(com.seeyon.boot.transport.SingleRequest<java.lang.String>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.ctp.metadata.dto.AggMetadataDto> selectAggMetadataList(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.metadata.dto.request.SearchMetadataDto>);
    com.seeyon.boot.transport.PageResponse<com.seeyon.ctp.metadata.dto.AggMetadataDto> selectAggMetadataForPage(com.seeyon.boot.transport.PageDtoRequest<com.seeyon.ctp.metadata.dto.request.SearchPageDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.ctp.metadata.dto.AggMetadataDto> selectAggMetadataByFullNames(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.metadata.dto.request.SearchByFullNamesDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.ctp.metadata.dto.AggMetadataDto> selectAggMetadataByFullName(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.metadata.dto.request.SearchByFullNameDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.ctp.metadata.dto.AggMetadataDto> selectAggMetadataExcludeBoot(com.seeyon.boot.transport.SingleRequest<java.lang.String>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.ctp.metadata.dto.AggMetadataDto> selectAggMetadataListExcludeBoot(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.metadata.dto.request.SearchMetadataDto>);
    com.seeyon.boot.transport.PageResponse<com.seeyon.ctp.metadata.dto.AggMetadataDto> selectAggMetadataExcludeBootForPage(com.seeyon.boot.transport.PageDtoRequest<com.seeyon.ctp.metadata.dto.request.SearchPageDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.ctp.metadata.dto.AggEntityMetadataDto> selectAggEntityMetadata(com.seeyon.boot.transport.SingleRequest<java.lang.String>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.ctp.metadata.dto.AggEntityMetadataDto> selectAggEntityMetadataList(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.metadata.dto.request.SearchMetadataDto>);
    com.seeyon.boot.transport.PageResponse<com.seeyon.ctp.metadata.dto.AggEntityMetadataDto> selectAggEntityMetadataForPage(com.seeyon.boot.transport.PageDtoRequest<com.seeyon.ctp.metadata.dto.request.SearchPageDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.ctp.metadata.dto.AggEntityMetadataDto> selectAggEntityMetadataExcludeBoot(com.seeyon.boot.transport.SingleRequest<java.lang.String>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.ctp.metadata.dto.AggEntityMetadataDto> selectAggEntityMetadataListExcludeBoot(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.metadata.dto.request.SearchMetadataDto>);
    com.seeyon.boot.transport.PageResponse<com.seeyon.ctp.metadata.dto.AggEntityMetadataDto> selectAggEntityMetadataExcludeBootForPage(com.seeyon.boot.transport.PageDtoRequest<com.seeyon.ctp.metadata.dto.request.SearchPageDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.ctp.metadata.dto.AggEntityMetadataDto> selectAggEntityMetadataByFullNames(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.metadata.dto.request.SearchByFullNamesDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.ctp.metadata.dto.AggEntityMetadataDto> selectAggEntityMetadataByFullName(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.metadata.dto.request.SearchByFullNameDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.ctp.metadata.dto.ReferMetadataDto> selectReferMetadataByEntity(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.metadata.dto.request.SearchByFullNameDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.ctp.metadata.dto.ReferMetadataDto> selectReferMetadataByEntityAndRefer(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.metadata.dto.request.SearchReferByFullNamesDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.ctp.metadata.dto.ReferAndAppMetadataDto> selectReferAndAppMetadataByEntity(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.metadata.dto.request.SearchByFullNameDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.ctp.metadata.dto.AggDtoMetadataDto> selectAggDtoMetadataByFullNames(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.metadata.dto.request.SearchByFullNamesDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.ctp.metadata.dto.AggDtoMetadataDto> selectAggDtoMetadataByFullName(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.metadata.dto.request.SearchByFullNameDto>);
    com.seeyon.boot.transport.SingleResponse<java.util.Map<java.lang.String, com.seeyon.ctp.metadata.dto.request.EntityAttributeModifyDto>> selectModifiedEntityAttributes(com.seeyon.boot.transport.SingleRequest<java.lang.String>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.ctp.metadata.dto.CtpEnumMetadataDto> selectCtpEnumMetadata(com.seeyon.boot.transport.SingleRequest<java.lang.String>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.ctp.metadata.dto.CtpEnumMetadataDto> selectCtpEnumMetadataList(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.metadata.dto.request.SearchMetadataDto>);
    com.seeyon.boot.transport.PageResponse<com.seeyon.ctp.metadata.dto.CtpEnumMetadataDto> selectCtpEnumMetadataForPage(com.seeyon.boot.transport.PageDtoRequest<com.seeyon.ctp.metadata.dto.request.SearchPageDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.ctp.metadata.dto.CtpEnumMetadataDto> selectCtpEnumMetadataByFullNames(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.metadata.dto.request.SearchByFullNamesDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.ctp.metadata.dto.CtpEnumMetadataDto> selectCtpEnumMetadataByFullName(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.metadata.dto.request.SearchByFullNameDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.ctp.metadata.dto.PageMetadataDto> selectPageMetadataList(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.metadata.dto.request.SearchMetadataDto>);
    com.seeyon.boot.transport.PageResponse<com.seeyon.ctp.metadata.dto.PageMetadataDto> selectPageMetadataForPage(com.seeyon.boot.transport.PageDtoRequest<com.seeyon.ctp.metadata.dto.request.SearchPageDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.ctp.metadata.dto.PageMetadataDto> selectPageMetadataByFullNames(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.metadata.dto.request.SearchByFullNamesDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.ctp.metadata.dto.PageMetadataDto> selectPageMetadataByFullName(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.metadata.dto.request.SearchByFullNameDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.ctp.metadata.dto.CtpEnumItemMetadataDto> selectCtpEnumItemMetadataList(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.metadata.dto.request.SearchMetadataDto>);
    com.seeyon.boot.transport.PageResponse<com.seeyon.ctp.metadata.dto.CtpEnumItemMetadataDto> selectCtpEnumItemMetadataForPage(com.seeyon.boot.transport.PageDtoRequest<com.seeyon.ctp.metadata.dto.request.SearchPageDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.ctp.metadata.dto.CtpEnumItemMetadataDto> selectCtpEnumItemMetadataByFullNames(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.metadata.dto.request.SearchByFullNamesDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.ctp.metadata.dto.CtpEnumItemMetadataDto> selectCtpEnumItemMetadataByFullName(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.metadata.dto.request.SearchByFullNameDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.ctp.metadata.dto.StarterMetadataDto> selectStarterMetadataList();
    com.seeyon.boot.transport.ListResponse<com.seeyon.ctp.metadata.dto.StarterMetadataDto> selectMultiVersionStarterMetadataByName(com.seeyon.boot.transport.SingleRequest<java.lang.String>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.ctp.metadata.dto.StarterMetadataDto> selectStarterMetadataByNames(com.seeyon.boot.transport.SingleRequest<java.util.List<java.lang.String>>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.ctp.metadata.dto.StarterMetadataDto> selectStarterMetadataByName(com.seeyon.boot.transport.SingleRequest<java.lang.String>);
    com.seeyon.boot.transport.SingleResponse<java.lang.String> selectJsonMetadata(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.metadata.dto.request.SearchJsonMetadataDto>);
    private void sortEntityList(java.util.List<com.seeyon.ctp.metadata.dto.EntityMetadataDto>);
    private <T> com.seeyon.boot.transport.PageResponse<T> queryPage(com.seeyon.ctp.metadata.enums.MetadataTypeEnum, com.seeyon.boot.transport.PageDtoRequest<com.seeyon.ctp.metadata.dto.request.SearchPageDto>);
    private void sortList(java.util.List, com.seeyon.boot.transport.Sort);
    private boolean isStarterFullName(java.lang.String);
```

### `ServiceMetadataDto`（32 方法）

`com.seeyon.ctp.metadata.dto.ServiceMetadataDto`

```java
    java.lang.String getAppName();
    com.seeyon.ctp.metadata.dto.model.MavenInfoDto getMavenInfo();
    boolean isDynamicService();
    java.lang.String getDynamicModuleGroup();
    java.lang.String getDynamicFeatureType();
    java.lang.String getHostAppName();
    java.lang.String getTenantId();
    java.lang.String getUdcDesignVersion();
    boolean isUdcApp();
    boolean isEnableGraphql();
    java.lang.String getStatus();
    java.lang.String getAppVersion();
    java.lang.String getCaption();
    java.lang.String getDescription();
    java.lang.String getMd5();
    java.util.List<com.seeyon.boot.context.model.BuildInfo> getDepends();
    void setAppName(java.lang.String);
    void setMavenInfo(com.seeyon.ctp.metadata.dto.model.MavenInfoDto);
    void setDynamicService(boolean);
    void setDynamicModuleGroup(java.lang.String);
    void setDynamicFeatureType(java.lang.String);
    void setHostAppName(java.lang.String);
    void setTenantId(java.lang.String);
    void setUdcDesignVersion(java.lang.String);
    void setUdcApp(boolean);
    void setEnableGraphql(boolean);
    void setStatus(java.lang.String);
    void setAppVersion(java.lang.String);
    void setCaption(java.lang.String);
    void setDescription(java.lang.String);
    void setMd5(java.lang.String);
    void setDepends(java.util.List<com.seeyon.boot.context.model.BuildInfo>);
```

### `AppServiceMethodMetadataDto`（22 方法）

`com.seeyon.ctp.metadata.dto.AppServiceMethodMetadataDto`

```java
    java.lang.String getDescription();
    boolean isDubbo();
    java.lang.String getDubboVersion();
    java.lang.String getInterfaceClass();
    java.lang.String getImplClass();
    java.lang.String getGroup();
    java.lang.String getPlugins();
    boolean isPublic();
    com.seeyon.ctp.metadata.dto.model.ParameterDto getParameter();
    com.seeyon.ctp.metadata.dto.model.ReturnValueDto getReturnValue();
    java.util.Map<java.lang.String, java.lang.Object> getCustoms();
    void setDescription(java.lang.String);
    void setDubbo(boolean);
    void setDubboVersion(java.lang.String);
    void setInterfaceClass(java.lang.String);
    void setImplClass(java.lang.String);
    void setGroup(java.lang.String);
    void setPlugins(java.lang.String);
    void setPublic(boolean);
    void setParameter(com.seeyon.ctp.metadata.dto.model.ParameterDto);
    void setReturnValue(com.seeyon.ctp.metadata.dto.model.ReturnValueDto);
    void setCustoms(java.util.Map<java.lang.String, java.lang.Object>);
```

### `MetadataRedisKeyUtils`（20 方法）

`com.seeyon.ctp.metadata.domain.util.MetadataRedisKeyUtils`

```java
    static java.lang.String serviceMetadataChangeRedisKey();
    static java.lang.String serviceMetadataRedisKey();
    static java.lang.String starterMetadataRedisKey();
    static java.lang.String metadataTaskRedisKey();
    static java.lang.String storageFailRedisKey();
    static java.lang.String serviceMultiVersionRedisKey(java.lang.String);
    static java.lang.String starterMultiVersionRedisKey(java.lang.String);
    static java.lang.String getMetadataRedisKey(com.seeyon.ctp.metadata.enums.MetadataTypeEnum, java.lang.String, java.lang.String);
    static java.lang.String getMetadataMd5RedisKey(com.seeyon.ctp.metadata.enums.MetadataTypeEnum, java.lang.String, java.lang.String);
    static java.lang.String metadataRedisKey(com.seeyon.ctp.metadata.enums.MetadataTypeEnum, java.lang.String);
    static java.lang.String jsonMetadataStorageKey(java.lang.String, java.lang.String);
    static java.lang.String multiVersionJsonMetadataStorageKey(java.lang.String, java.lang.String, java.lang.String, boolean);
    static java.lang.String multiVersionMetadataRedisKey(com.seeyon.ctp.metadata.enums.MetadataTypeEnum, java.lang.String, java.lang.String);
    static java.lang.String md5Rediskey(com.seeyon.ctp.metadata.enums.MetadataTypeEnum, java.lang.String);
    static java.lang.String jsonMetadataVersionRediskey(java.lang.String, java.lang.String);
    static java.lang.String multiVersionMd5Rediskey(com.seeyon.ctp.metadata.enums.MetadataTypeEnum, java.lang.String, java.lang.String);
    static java.lang.String tenantMetadataRedisKey(com.seeyon.ctp.metadata.enums.MetadataTypeEnum, java.lang.String);
    static java.lang.String tenantMD5RedisKey(com.seeyon.ctp.metadata.enums.MetadataTypeEnum, java.lang.String);
    static java.lang.String entityAttributeModifyRedisKey(java.lang.String);
    static java.lang.String entityAttributeModifyHashKey(com.seeyon.ctp.metadata.dto.request.EntityAttributeModifyDto);
```

### `MetadataBuildUtils`（18 方法）

`com.seeyon.ctp.metadata.domain.util.MetadataBuildUtils`

```java
    static boolean enableGraphql(java.lang.String);
    static java.util.Set<java.lang.String> artifactIds1(java.lang.String);
    static java.util.Map<java.lang.String, com.seeyon.ctp.metadata.dto.StarterMetadataDto> scanStarterInfoMetadata1(java.lang.String);
    static com.seeyon.ctp.metadata.dto.AggDtoMetadataDto buildAggDtoMetadata(com.seeyon.ctp.metadata.dto.DtoMetadataDto, java.util.Map<java.lang.String, com.seeyon.ctp.metadata.dto.DtoMetadataDto>);
    static private static void copyAggDtoAttributeMetadataDto(com.seeyon.ctp.metadata.dto.DtoAttributeMetadataDto, com.seeyon.ctp.metadata.dto.AggDtoAttributeMetadataDto);
    static private static void copyAggDtoMetadataDto(com.seeyon.ctp.metadata.dto.DtoMetadataDto, com.seeyon.ctp.metadata.dto.AggDtoMetadataDto);
    static private static com.seeyon.ctp.metadata.dto.AggDtoMetadataDto buildAggDtoMetadata(com.seeyon.ctp.metadata.dto.DtoMetadataDto, java.util.Map<java.lang.String, com.seeyon.ctp.metadata.dto.DtoMetadataDto>, int);
    static void buildAggDtoAttribute(com.seeyon.ctp.metadata.dto.AggDtoAttributeMetadataDto, com.seeyon.ctp.metadata.dto.model.ItemDto, java.util.Map<java.lang.String, com.seeyon.ctp.metadata.dto.DtoMetadataDto>, int);
    static void buildAggItemDto(com.seeyon.ctp.metadata.dto.model.DtoAttributeItemDto, com.seeyon.ctp.metadata.dto.model.ItemDto, java.util.Map<java.lang.String, com.seeyon.ctp.metadata.dto.DtoMetadataDto>, int);
    static java.util.Map<java.lang.String, com.seeyon.ctp.metadata.dto.AggMetadataDto> buildAggMetadata(java.util.Map<java.lang.String, com.seeyon.ctp.metadata.dto.EntityMetadataDto>);
    static void buildAggLevel(com.seeyon.ctp.metadata.dto.AggMetadataDto, java.util.Map<java.lang.String, java.util.Map<java.lang.String, java.lang.String>>, java.util.Map<java.lang.String, com.seeyon.ctp.metadata.dto.EntityMetadataDto>, int);
    static java.util.Map<java.lang.String, com.seeyon.ctp.metadata.dto.AggEntityMetadataDto> buildAggEntityMap(java.lang.String, java.util.Map<java.lang.String, com.seeyon.ctp.metadata.dto.EntityMetadataDto>, java.util.Map<java.lang.String, com.seeyon.ctp.metadata.dto.AggMetadataDto>);
    static void buildSubEntityList(java.util.Map<java.lang.String, com.seeyon.ctp.metadata.dto.EntityMetadataDto>, java.util.Map<java.lang.String, com.seeyon.ctp.metadata.dto.EntityMetadataDto>, com.seeyon.ctp.metadata.dto.AggMetadataDto, int);
    static void buildSubEntityList(com.seeyon.ctp.metadata.dto.AggEntityMetadataDto, java.util.Map<java.lang.String, com.seeyon.ctp.metadata.dto.EntityMetadataDto>, com.seeyon.ctp.metadata.dto.AggMetadataDto, int);
    static com.seeyon.ctp.metadata.dto.model.MavenInfoDto getMavenInfo();
    static java.lang.String md5(java.lang.Object);
    static java.util.List<com.seeyon.boot.context.model.BuildInfo> getDependApps();
```

### `TenantMetadataQueryAppService`（17 方法）

`com.seeyon.ctp.metadata.api.TenantMetadataQueryAppService`

```java
    com.seeyon.boot.transport.ListResponse<com.seeyon.ctp.metadata.dto.DtoMetadataDto> selectDtoMetadataList(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.metadata.dto.request.SearchMetadataDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.ctp.metadata.dto.DtoMetadataDto> selectDtoMetadataByFullNames(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.metadata.dto.request.SearchByFullNamesDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.ctp.metadata.dto.DtoMetadataDto> selectDtoMetadataByFullName(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.metadata.dto.request.SearchByFullNameDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.ctp.metadata.dto.AggDtoMetadataDto> selectAggDtoMetadataByFullNames(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.metadata.dto.request.SearchByFullNamesDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.ctp.metadata.dto.AggDtoMetadataDto> selectAggDtoMetadataByFullName(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.metadata.dto.request.SearchByFullNameDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.ctp.metadata.dto.EnumMetadataDto> selectEnumMetadataList(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.metadata.dto.request.SearchMetadataDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.ctp.metadata.dto.EnumMetadataDto> selectEnumMetadataByFullNames(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.metadata.dto.request.SearchByFullNamesDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.ctp.metadata.dto.EnumMetadataDto> selectEnumMetadataByFullName(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.metadata.dto.request.SearchByFullNameDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.ctp.metadata.dto.OpenApiMetadataDto> selectOpenApiMetadataList(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.metadata.dto.request.SearchMetadataDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.ctp.metadata.dto.OpenApiMetadataDto> selectOpenApiMetadataByFullNames(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.metadata.dto.request.SearchByFullNamesDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.ctp.metadata.dto.OpenApiMetadataDto> selectOpenApiMetadataByFullName(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.metadata.dto.request.SearchByFullNameDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.ctp.metadata.dto.AppServiceMetadataDto> selectAppServiceMetadataList(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.metadata.dto.request.SearchMetadataDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.ctp.metadata.dto.AppServiceMetadataDto> selectAppServiceMetadataByFullNames(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.metadata.dto.request.SearchByFullNamesDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.ctp.metadata.dto.AppServiceMetadataDto> selectAppServiceMetadataByFullName(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.metadata.dto.request.SearchByFullNameDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.ctp.metadata.dto.MqMetadataDto> selectMqMetadataList(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.metadata.dto.request.SearchMetadataDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.ctp.metadata.dto.MqMetadataDto> selectMqMetadataByFullNames(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.metadata.dto.request.SearchByFullNamesDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.ctp.metadata.dto.MqMetadataDto> selectMqMetadataByFullName(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.metadata.dto.request.SearchByFullNameDto>);
```

### `MetadataCreateAppService`（16 方法）

`com.seeyon.ctp.metadata.api.MetadataCreateAppService`

```java
    com.seeyon.boot.transport.SingleResponse<java.lang.Boolean> createServiceMetadata(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.metadata.dto.ServiceMetadataDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Boolean> createAllRestApiMetadata(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.metadata.dto.request.ServiceRestApiMetadataDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Boolean> createAllDtoMetadata(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.metadata.dto.request.ServiceDtoMetadataDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Boolean> createAllEnumMetadata(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.metadata.dto.request.ServiceEnumMetadataDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Boolean> createAllEntityMetadata(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.metadata.dto.request.ServiceEntityMetadataDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Boolean> createAllAppServiceMetadata(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.metadata.dto.request.ServiceAppServiceMetadataDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Boolean> createAllOpenApiMetadata(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.metadata.dto.request.ServiceOpenApiMetadataDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Boolean> createAllCtpEnumMetadata(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.metadata.dto.request.ServiceCtpEnumMetadataDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Boolean> createAllPageMetadata(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.metadata.dto.request.ServicePageMetadataDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Boolean> createJSONMetadata(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.metadata.dto.request.ServiceJsonMetadataDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Boolean> createAllMqMetadata(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.metadata.dto.request.ServiceMqMetadataDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Boolean> createTenantAppServiceMetadata(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.metadata.dto.request.ServiceAppServiceMetadataDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Boolean> createTenantDtoMetadata(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.metadata.dto.request.ServiceDtoMetadataDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Boolean> createTenantMqMetadata(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.metadata.dto.request.ServiceMqMetadataDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Boolean> createTenantEnumMetadata(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.metadata.dto.request.ServiceEnumMetadataDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Boolean> createTenantOpenApiMetadata(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.metadata.dto.request.ServiceOpenApiMetadataDto>);
```

### `MetadataI18nUtils`（10 方法）

`com.seeyon.ctp.metadata.domain.util.MetadataI18nUtils`

```java
    static void setI18n(java.lang.String, com.seeyon.ctp.metadata.dto.BaseI18nMetadataDto);
    static void setI18n(com.seeyon.ctp.metadata.dto.StarterMetadataDto);
    static private static boolean isEnableI18n();
    static void setI18n(java.util.Collection);
    static void setI18n(java.lang.String, java.util.Collection);
    static void setI18n(java.util.Map);
    static void setI18n(java.lang.String, java.util.Map);
    static java.lang.String getEntityCaption(java.lang.String, java.lang.String, java.lang.String);
    static java.lang.String getEnumCaption(java.lang.String, boolean, java.lang.String, java.lang.String);
    static java.lang.String getStarterCaption(java.lang.String, java.lang.String);
```

### `AppServiceMetadataDto`（8 方法）

`com.seeyon.ctp.metadata.dto.AppServiceMetadataDto`

```java
    boolean isPublic();
    java.lang.String getDescription();
    java.util.List<com.seeyon.ctp.metadata.dto.AppServiceMethodMetadataDto> getMethods();
    java.util.Map<java.lang.String, java.lang.Object> getCustoms();
    void setPublic(boolean);
    void setDescription(java.lang.String);
    void setMethods(java.util.List<com.seeyon.ctp.metadata.dto.AppServiceMethodMetadataDto>);
    void setCustoms(java.util.Map<java.lang.String, java.lang.Object>);
```

### `ServiceJsonMetadataDto`（6 方法）

`com.seeyon.ctp.metadata.dto.request.ServiceJsonMetadataDto`

```java
    java.io.InputStream getJsonStream();
    java.lang.String getJsonFileName();
    java.lang.String getJsonVersion();
    void setJsonStream(java.io.InputStream);
    void setJsonFileName(java.lang.String);
    void setJsonVersion(java.lang.String);
```

### `MetadataMD5Utils`（4 方法）

`com.seeyon.ctp.metadata.domain.util.MetadataMD5Utils`

```java
    static private static java.lang.String md5(java.util.List<java.lang.String>);
    static private static java.util.List<java.lang.String> sortMd5(java.util.Map);
    static java.lang.String dataMd5(java.util.Map);
```

### `ServiceBaseDto`（4 方法）

`com.seeyon.ctp.metadata.dto.request.ServiceBaseDto`

```java
    java.lang.String getAppName();
    java.lang.String getAppVersion();
    void setAppName(java.lang.String);
    void setAppVersion(java.lang.String);
```

## 四、枚举（2）

- `MetadataTypeEnum`（14 常量）：Service, Entity, Agg, Enum, RestApi, OpenApi, Mq, Dto, AppService, CtpEnum, Page, Starter …
- `ServiceStatusEnum`（2 常量）：PUBLISHED, UNPUBLISHED
