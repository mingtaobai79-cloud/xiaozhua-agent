# boot-starter-extmetadata：接口与方法签名

> 自动生成，勿手改。`tools/core/platform/emit_package_surfaces.py` 重跑即可。
> 构件 `com.seeyon:boot-starter-extmetadata`（jar `boot-starter-extmetadata-5.3.603.jar`）
> 规模：106 类 / 2 接口 / 0 注解 / 12 枚举 / 23 个关键类 / 1223 方法。
> 签名逐字来自 javap 原文；已去掉 `public` 前缀与 `throws` 子句。

## 一、接口（2）

### `HostAppFunctionInterface`（2 方法）

`com.seeyon.boot.starter.extmetadata.api.HostAppFunctionInterface`

```java
    com.seeyon.boot.transport.ListResponse<com.seeyon.boot.starter.extmetadata.dto.UdcApplicationMetaDataDto> selectDependentApplicationByHostAppName(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.extmetadata.dto.request.UdcMetaDataSearchDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.boot.starter.extmetadata.dto.UdcApplicationMetaDataDto> getHostAppName();
```

### `UdcDynamicResourceService`（2 方法）

`com.seeyon.boot.starter.extmetadata.domain.resource.UdcDynamicResourceService`

```java
    java.net.URL getAssembleUrl(java.lang.String, java.lang.String);
    java.net.URL getAssembleUrl(java.net.URLClassLoader, java.lang.String, java.lang.String);
```

## 二、关键类（23）

### `UdcEntityMetaDataService`（73 方法）

`com.seeyon.boot.starter.extmetadata.domain.UdcEntityMetaDataService`

```java
    java.util.List<com.seeyon.boot.starter.extmetadata.dto.UdcAggMetadataDto> selectSimpleAggMetadata(com.seeyon.boot.starter.extmetadata.dto.request.UdcSimpleEntityMetaDataSearchDto);
    java.util.Map<java.lang.String, com.seeyon.boot.starter.extmetadata.dto.UdcEntityMetaDataDto> selectAllSimpleAggEntityByEntityName(com.seeyon.boot.starter.extmetadata.dto.request.UdcEntityMetaDataSearchDto);
    java.util.Map<java.lang.String, com.seeyon.boot.starter.extmetadata.dto.UdcEntityMetaDataDto> selectAllSimpleAggEntityIncludeAssociation(com.seeyon.boot.starter.extmetadata.dto.request.UdcEntityMetaDataSearchDto);
    java.util.List<com.seeyon.boot.starter.extmetadata.dto.UdcSimpleEntityMetaDataDto> selectAllSimpleEntityByAppName(com.seeyon.boot.starter.extmetadata.dto.request.UdcMetaDataSearchDto);
    java.util.List<com.seeyon.boot.starter.extmetadata.dto.UdcEntityMetaDataDto> selectEntityByAppName(com.seeyon.boot.starter.extmetadata.dto.request.UdcMetaDataSearchDto);
    java.util.List<com.seeyon.boot.starter.extmetadata.dto.UdcEntityMetaDataDto> selectEntity2DtoByAppName(com.seeyon.boot.starter.extmetadata.dto.request.UdcMetaDataSearchDto);
    com.seeyon.boot.starter.extmetadata.dto.UdcEntityMetaDataDto selectEntity(com.seeyon.boot.starter.extmetadata.dto.request.UdcEntityMetaDataSearchDto);
    java.util.List<com.seeyon.boot.starter.extmetadata.dto.UdcEntityMetaDataDto> selectAggEntity(com.seeyon.boot.starter.extmetadata.dto.request.UdcEntityMetaDataSearchDto);
    java.util.List<com.seeyon.boot.starter.extmetadata.dto.UdcEntityMetaDataDto> selectAggEntity(com.seeyon.boot.starter.extmetadata.dto.request.UdcEntitiesMetaDataSearchDto);
    private java.util.Map<java.lang.String, com.seeyon.boot.starter.extmetadata.dto.UdcEntityMetaDataDto> selectAggEntitiesMap(com.seeyon.boot.starter.extmetadata.dto.request.UdcEntitiesMetaDataSearchDto);
    java.util.List<com.seeyon.boot.starter.extmetadata.dto.UdcEntityMetaDataDto> selectAggEntityIncludeAssociation(com.seeyon.boot.starter.extmetadata.dto.request.UdcEntityMetaDataSearchDto);
    java.util.Map<java.lang.String, com.seeyon.boot.starter.extmetadata.dto.UdcEntityMetaDataDto> selectAggEntitiesMapIncludeAssociation(com.seeyon.boot.starter.extmetadata.dto.request.UdcEntitiesMetaDataSearchDto);
    java.util.Map<java.lang.String, java.util.List<com.seeyon.boot.starter.extmetadata.enums.EntityActionEnum>> selectActionListByEntityFullName(com.seeyon.boot.starter.extmetadata.dto.request.UdcEntitiesMetaDataSearchDto);
    java.util.Map<java.lang.String, com.seeyon.boot.starter.extmetadata.dto.UdcEntityMetaDataDto> selectAggEntityMapIncludeAssociation(com.seeyon.boot.starter.extmetadata.dto.request.UdcEntityMetaDataSearchDto);
    java.util.Map<java.lang.String, java.util.List<com.seeyon.boot.starter.extmetadata.dto.UdcAttributeMetaDataDto>> getAttributeMetadataGroupByDataType(java.util.Map<java.lang.String, com.seeyon.boot.starter.extmetadata.dto.UdcEntityMetaDataDto>);
    private java.util.Map<java.lang.String, com.seeyon.boot.starter.extmetadata.dto.UdcEntityMetaDataDto> setAssEntity(java.lang.String, java.util.List<com.seeyon.boot.starter.extmetadata.dto.UdcAttributeMetaDataDto>);
    private java.util.Map<java.lang.String, com.seeyon.boot.starter.extmetadata.dto.UdcEntityMetaDataDto> selectAggEntities2Udc(com.seeyon.boot.starter.extmetadata.dto.request.UdcEntitiesMetaDataSearchDto);
    private java.util.Map<java.lang.String, com.seeyon.boot.starter.extmetadata.dto.UdcEntityMetaDataDto> selectAssAggEntities2Udc(com.seeyon.boot.starter.extmetadata.dto.request.UdcEntitiesMetaDataSearchDto);
    private java.util.List<com.seeyon.ctp.metadata.dto.EntityMetadataDto> selectEntityMetadataList(com.seeyon.boot.starter.extmetadata.dto.request.UdcMetaDataSearchDto);
    private java.util.List<com.seeyon.ctp.metadata.dto.AggEntityMetadataDto> selectAggEntityMetadataList(com.seeyon.boot.starter.extmetadata.dto.request.UdcMetaDataSearchDto);
    private boolean isStarterSearch(com.seeyon.boot.starter.extmetadata.dto.request.UdcMetaDataSearchDto);
    private java.util.List<com.seeyon.ctp.metadata.dto.AggEntityMetadataDto> getAggEntityMetadataByFullName(java.util.List<com.seeyon.ctp.metadata.dto.AggEntityMetadataDto>, java.util.List<java.lang.String>);
    private boolean aggEntityIncludeEntity(com.seeyon.ctp.metadata.dto.AggEntityMetadataDto, java.util.List<java.lang.String>);
    private void setAssEnum(java.lang.String, java.util.List<com.seeyon.boot.starter.extmetadata.dto.UdcAttributeMetaDataDto>);
    private void setAssCtpEnum(java.lang.String, java.util.List<com.seeyon.boot.starter.extmetadata.dto.UdcAttributeMetaDataDto>, java.util.Map<java.lang.String, com.seeyon.boot.starter.extmetadata.dto.UdcEntityMetaDataDto>);
    private java.util.Map<java.lang.String, java.util.List<com.seeyon.boot.starter.extmetadata.dto.UdcAttributeMetaDataDto>> getAttributeMetadata2Map(com.seeyon.boot.starter.extmetadata.dto.UdcEntityMetaDataDto);
    private boolean inRoot(com.seeyon.ctp.metadata.dto.AggEntityMetadataDto, java.lang.String);
    private com.seeyon.boot.starter.extmetadata.dto.request.UdcEntitiesMetaDataSearchDto changeSearchMetadataDtoSingle2List(com.seeyon.boot.starter.extmetadata.dto.request.UdcEntityMetaDataSearchDto);
    private void mergeExtensionPlanMetadata(com.seeyon.boot.starter.extmetadata.dto.request.UdcMetaDataSearchDto, java.util.List<com.seeyon.ctp.metadata.dto.EntityMetadataDto>);
    private void mergeAggExtensionPlanMetadata(com.seeyon.boot.starter.extmetadata.dto.request.UdcMetaDataSearchDto, java.util.List<com.seeyon.ctp.metadata.dto.AggEntityMetadataDto>);
    private java.util.Map<java.lang.String, com.seeyon.ctp.metadata.dto.AggEntityMetadataDto> getDefaultExtensionPlanEntity(java.util.Map<java.lang.String, com.seeyon.ctp.metadata.dto.AggEntityMetadataDto>);
    java.util.List<com.seeyon.ctp.metadata.dto.AggEntityMetadataDto> selectExtensionPlanMetadataList(com.seeyon.boot.starter.extmetadata.dto.request.UdcMetaDataSearchDto);
```

### `MetadataConvertUtil`（54 方法）

`com.seeyon.boot.starter.extmetadata.utils.MetadataConvertUtil`

```java
    static java.util.List<com.seeyon.boot.starter.extmetadata.dto.UdcAggEntityMetaDataDto> aggMedata2UdcAgg(com.seeyon.boot.starter.extmetadata.dto.request.UdcMetaDataSearchDto, java.util.List<com.seeyon.ctp.metadata.dto.AggEntityMetadataDto>);
    static java.util.List<com.seeyon.boot.starter.extmetadata.dto.UdcEntityMetaDataDto> aggResolveMetadata(com.seeyon.boot.starter.extmetadata.dto.request.UdcMetaDataSearchDto, java.util.List<com.seeyon.ctp.metadata.dto.AggEntityMetadataDto>);
    static java.util.List<com.seeyon.ctp.metadata.dto.AggEntityMetadataDto> resolveAgg2FlatList(java.util.List<com.seeyon.ctp.metadata.dto.AggEntityMetadataDto>);
    static private static void resolveAggMetadata(java.util.List<com.seeyon.ctp.metadata.dto.AggEntityMetadataDto>, com.seeyon.ctp.metadata.dto.AggEntityMetadataDto);
    static java.util.List<com.seeyon.boot.starter.extmetadata.dto.UdcEntityMetaDataDto> assAggResolveMetadata(com.seeyon.boot.starter.extmetadata.dto.request.UdcMetaDataSearchDto, java.util.List<com.seeyon.ctp.metadata.dto.AggEntityMetadataDto>);
    static private static void aggEntityMetaData2UdcList(com.seeyon.boot.starter.extmetadata.dto.request.UdcMetaDataSearchDto, java.lang.String, boolean, com.seeyon.ctp.metadata.dto.AggEntityMetadataDto, java.util.List<com.seeyon.boot.starter.extmetadata.dto.UdcEntityMetaDataDto>);
    static private static com.seeyon.boot.starter.extmetadata.dto.UdcAggEntityMetaDataDto aggEntityMetaData2UdcAggList(com.seeyon.boot.starter.extmetadata.dto.request.UdcMetaDataSearchDto, java.lang.String, com.seeyon.ctp.metadata.dto.AggEntityMetadataDto);
    static com.seeyon.boot.starter.extmetadata.dto.UdcAggEntityMetaDataDto aggEntityMetaData2Udc(com.seeyon.boot.starter.extmetadata.dto.request.UdcMetaDataSearchDto, com.seeyon.ctp.metadata.dto.AggEntityMetadataDto);
    static com.seeyon.boot.starter.extmetadata.dto.UdcAttributeMetaDataDto attributeMetaData2Udc(com.seeyon.boot.starter.extmetadata.dto.request.UdcMetaDataSearchDto, com.seeyon.ctp.metadata.dto.EntityAttributeMetadataDto);
    static private static com.seeyon.boot.starter.extmetadata.dto.UdcAttributeMetaDataDto childrenEntity2Attribute(com.seeyon.boot.starter.extmetadata.dto.request.UdcMetaDataSearchDto, java.lang.String, com.seeyon.ctp.metadata.dto.AggEntityMetadataDto);
    static com.seeyon.boot.starter.extmetadata.dto.UdcAggMetadataDto aggEntityMetaDataDto2Udc(com.seeyon.ctp.metadata.dto.EntityMetadataDto);
    static <T extends com.seeyon.boot.starter.extmetadata.dto.UdcSimpleEntityMetaDataDto> T entityMetaDataDto2UdcExcludeAttribute(com.seeyon.boot.starter.extmetadata.dto.request.UdcMetaDataSearchDto, com.seeyon.ctp.metadata.dto.EntityMetadataDto, java.lang.Class<T>);
    static <T extends com.seeyon.boot.starter.extmetadata.dto.UdcEntityMetaDataDto> T entityMetaDataDto2UdcIncludeAttribute(com.seeyon.boot.starter.extmetadata.dto.request.UdcMetaDataSearchDto, com.seeyon.ctp.metadata.dto.EntityMetadataDto, java.lang.Class<T>);
    static private static <T extends com.seeyon.boot.starter.extmetadata.dto.UdcSimpleEntityMetaDataDto> void dealMultiplicity(com.seeyon.ctp.metadata.dto.EntityMetadataDto, java.util.Map<java.lang.String, com.seeyon.ctp.metadata.dto.EntityAttributeMetadataDto>, T);
    static com.seeyon.boot.starter.extmetadata.dto.UdcCtpEnumDto ctpMetaEnumDto2UdcCtpEnum(java.lang.String, com.seeyon.ctp.metadata.dto.CtpEnumMetadataDto);
    static com.seeyon.boot.starter.enums.dto.CtpEnumDto ctpMetaEnumDto2CtpEnum(com.seeyon.ctp.metadata.dto.CtpEnumMetadataDto);
    static com.seeyon.boot.starter.extmetadata.dto.UdcJavaEnumMetaDataDto enumMetaDto2UdcJavaEnum(java.lang.String, com.seeyon.ctp.metadata.dto.EnumMetadataDto, boolean);
    static com.seeyon.boot.starter.extmetadata.dto.UdcJavaEnumMetaDataDto enumMetaDto2UdcJavaEnum(java.lang.String, com.seeyon.ctp.metadata.dto.EnumMetadataDto);
    static com.seeyon.boot.starter.extmetadata.dto.UdcJavaEnumItemMetaDataDto enumItemMetaDto2UdcJavaItemEnum(java.lang.String, com.seeyon.ctp.metadata.dto.model.JavaEnumItemDto);
    static com.seeyon.boot.starter.extmetadata.dto.UdcPageMetadataV2Dto pageMetadata2Udc(com.seeyon.ctp.metadata.dto.PageMetadataDto);
    static boolean isRelationObj(com.seeyon.boot.starter.extmetadata.dto.UdcAttributeMetaDataDto);
    static java.lang.String handleOneToManyEntityName4Dto(java.lang.String, java.lang.String);
    static java.lang.String getEntityNameByFullName(java.lang.String);
    static boolean isUdcOuterTreeEntity(java.lang.String, java.lang.String);
    static private static <T extends com.seeyon.boot.starter.extmetadata.dto.UdcSimpleEntityMetaDataDto> T changeToUdcEntityMetaData(com.seeyon.boot.starter.extmetadata.dto.request.UdcMetaDataSearchDto, com.seeyon.ctp.metadata.dto.EntityMetadataDto, java.lang.Class<T>);
    static boolean isPublicAttribute(com.seeyon.ctp.metadata.dto.EntityAttributeMetadataDto);
    static private static java.util.Map<java.lang.String, java.lang.Object> getValidation(com.seeyon.ctp.metadata.dto.EntityAttributeMetadataDto);
    static private static java.lang.String getParentEnumAttributeFullName(java.util.Map<java.lang.String, java.lang.Object>);
    static private static java.lang.String getWidgetConfig(java.util.Map<java.lang.String, java.lang.Object>);
    static private static java.lang.String getNameByFullName(java.lang.String);
    static java.util.Map<java.lang.String, com.seeyon.boot.starter.extmetadata.dto.UdcAppServiceMetaDataDto> convertAppServiceMetadataDto2UdcAppServiceMetaDataDto(java.util.List<com.seeyon.ctp.metadata.dto.AppServiceMetadataDto>, java.util.List<java.lang.String>);
    static com.seeyon.ctp.metadata.dto.AppServiceMetadataDto findAppService(java.lang.String, java.util.List<com.seeyon.ctp.metadata.dto.AppServiceMetadataDto>);
    static com.seeyon.boot.starter.extmetadata.dto.UdcAppServiceMetaDataDto convertAppServiceMetadataDto(com.seeyon.ctp.metadata.dto.AppServiceMetadataDto);
    static com.seeyon.boot.starter.extmetadata.dto.UdcAppServiceMethodMetadataDto convertUdcAppServiceMetaDataDto(com.seeyon.ctp.metadata.dto.AppServiceMethodMetadataDto);
    static java.lang.String getAppServiceRefFullName(com.seeyon.ctp.metadata.dto.AppServiceMetadataDto);
```

### `UdcReferMetaDataService`（37 方法）

`com.seeyon.boot.starter.extmetadata.domain.UdcReferMetaDataService`

```java
    java.util.List<com.seeyon.boot.starter.extmetadata.dto.UdcReferMetaDataDto> selectReferMetaData(com.seeyon.boot.starter.extmetadata.dto.request.UdcMetaDataSearchDto);
    java.util.List<com.seeyon.boot.starter.extmetadata.dto.UdcReferMetaDataDto> selectReferMetaDataByEntity(com.seeyon.boot.starter.extmetadata.dto.request.UdcReferMetaDataSearchDto);
    com.seeyon.boot.starter.extmetadata.dto.UdcReferAndAppMetaDataDto selectReferAndAppMetadataByEntity(com.seeyon.boot.starter.extmetadata.dto.request.UdcReferMetaDataSearchDto);
    com.seeyon.boot.starter.extmetadata.dto.UdcReferAndMetaDataDto selectReferAndMetadata(com.seeyon.boot.starter.extmetadata.dto.request.UdcReferMetaDataSearchDto);
    private java.util.List<com.seeyon.ctp.metadata.dto.ReferMetadataDto> getReferMetadataInAgg(java.lang.String, com.seeyon.ctp.metadata.dto.AggEntityMetadataDto);
    java.util.Map<java.lang.String, java.util.Map<java.lang.String, java.util.List<java.lang.String>>> getParsedEntityPathDtoList(com.seeyon.boot.starter.extmetadata.dto.UdcReferMetaDataDto);
    private java.util.List<com.seeyon.boot.starter.extmetadata.dto.EntityPathDto> parseAttrData4WhereCond(java.lang.String, java.util.List<com.seeyon.boot.starter.condition.dto.ConditionInfoDto>);
    private com.seeyon.boot.starter.extmetadata.dto.UdcReferAndAppMetaDataDto changeUdcReferAndAppMetadata2Udc(java.lang.String, java.lang.String, java.lang.String, com.seeyon.ctp.metadata.dto.ReferAndAppMetadataDto);
    com.seeyon.boot.starter.extmetadata.dto.UdcBaseApplicationMetaDataDto getBaseApplicationMetaDataDto(com.seeyon.ctp.metadata.dto.ServiceMetadataDto);
    java.util.List<com.seeyon.boot.starter.extmetadata.dto.UdcReferMetaDataDto> convert2UdcReferMetadata(java.lang.String, java.lang.String, java.lang.String, java.util.List<com.seeyon.ctp.metadata.dto.ReferMetadataDto>);
    private java.util.Map<java.lang.String, java.lang.Object> getOrganizationRefExend(java.lang.String, java.lang.String);
    private void handlerOrganizationRefExtend(java.lang.String, com.seeyon.boot.starter.extmetadata.dto.UdcReferMetaDataDto, java.util.Map<java.lang.String, java.lang.Object>);
```

### `UdcCtpEnumItemMetaDataService`（21 方法）

`com.seeyon.boot.starter.extmetadata.domain.UdcCtpEnumItemMetaDataService`

```java
    java.util.List<com.seeyon.boot.starter.extmetadata.dto.UdcCtpEnumItemDto> selectByAppName(com.seeyon.boot.starter.extmetadata.dto.request.UdcMetaDataSearchDto);
    com.seeyon.boot.starter.extmetadata.dto.UdcCtpEnumItemDto selectById(com.seeyon.boot.starter.extmetadata.dto.request.UdcCtpEnumItemMetaDataSearchDto);
    java.util.List<com.seeyon.boot.starter.extmetadata.dto.UdcCtpEnumItemTreeDto> selectByEnumCode(com.seeyon.boot.starter.extmetadata.dto.request.UdcCtpEnumItemMetaDataSearchDto);
    java.util.List<com.seeyon.boot.starter.extmetadata.dto.UdcCtpEnumItemDto> selectCascadeTreeByEnumCode(com.seeyon.boot.starter.extmetadata.dto.request.UdcCtpEnumItemMetaDataSearchDto);
    java.util.List<com.seeyon.boot.starter.extmetadata.dto.UdcCtpEnumItemDto> selectByEnumCodes(com.seeyon.boot.starter.extmetadata.dto.request.UdcCtpEnumItemsMetaDataSearchDto);
    private java.util.List<com.seeyon.ctp.metadata.dto.CtpEnumItemMetadataDto> getCtpEnumItemMetadataDto(com.seeyon.boot.starter.extmetadata.dto.request.UdcMetaDataSearchDto);
    private com.seeyon.ctp.metadata.dto.CtpEnumMetadataDto getCtpEnumMetadataDto(com.seeyon.boot.starter.extmetadata.dto.request.UdcCtpEnumsMetaDataSearchDto);
    private java.util.List<com.seeyon.ctp.metadata.dto.CtpEnumMetadataDto> getCtpEnumsMetadataDto(com.seeyon.boot.starter.extmetadata.dto.request.UdcMetaDataSearchDto);
    private java.util.List<com.seeyon.ctp.metadata.dto.CtpEnumMetadataDto> getUpCtpEnumsMetadataDtoByCode(com.seeyon.boot.starter.extmetadata.dto.request.UdcCtpEnumsMetaDataSearchDto);
    private com.seeyon.boot.starter.extmetadata.dto.UdcCtpEnumItemTreeDto changeTreeItem(com.seeyon.ctp.metadata.dto.CtpEnumItemMetadataDto);
    private void getParentCtpEnumItem(java.util.Map<java.lang.String, com.seeyon.ctp.metadata.dto.CtpEnumItemMetadataDto>, java.util.List<com.seeyon.ctp.metadata.dto.CtpEnumItemMetadataDto>, java.util.Map<java.lang.String, com.seeyon.ctp.metadata.dto.CtpEnumItemMetadataDto>);
```

### `UdcMetaDataAppV2Service`（18 方法）

`com.seeyon.boot.starter.extmetadata.appservice.UdcMetaDataAppV2Service`

```java
    com.seeyon.boot.transport.ListResponse<com.seeyon.boot.starter.extmetadata.dto.UdcAggMetadataDto> selectAllSimpleAggEntityByAppName(com.seeyon.boot.transport.SingleRequest<java.lang.String>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.boot.starter.extmetadata.dto.UdcSimpleEntityMetaDataDto> selectAllSimpleEntityByAppName(com.seeyon.boot.transport.SingleRequest<java.lang.String>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.boot.starter.extmetadata.dto.UdcPageMetadataV2Dto> selectPageLayoutInfoListMetaData(com.seeyon.boot.transport.SingleRequest<java.lang.String>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.boot.starter.extmetadata.dto.UdcSimpleEntityMetaDataDto> selectEntityMapToTable(com.seeyon.boot.transport.SingleRequest<java.lang.String>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.boot.starter.extmetadata.dto.UdcEntityMetaDataDto> selectAggEntityIncludeAssociation(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.extmetadata.dto.request.UdcEntityMetaDataSearchDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.boot.starter.extmetadata.dto.UdcEntityMetaDataDto> selectEntity(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.extmetadata.dto.request.UdcEntityMetaDataSearchDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.boot.starter.extmetadata.dto.UdcEntityMetaDataDto> selectEntityByAppName(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.extmetadata.dto.request.UdcEntityMetaDataSearchDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.boot.starter.extmetadata.dto.UdcReferMetaDataDto> selectReferMetaDataByEntity(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.extmetadata.dto.request.UdcReferMetaDataSearchDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.boot.starter.extmetadata.dto.UdcReferAndAppMetaDataDto> selectReferAndAppMetadataByEntity(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.extmetadata.dto.request.UdcReferMetaDataSearchDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.boot.starter.extmetadata.dto.UdcReferAndMetaDataDto> selectReferAndMetadata(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.extmetadata.dto.request.UdcReferMetaDataSearchDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.boot.starter.extmetadata.dto.UdcPageMetadataV2Dto> selectPageInfoListByAppName(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.extmetadata.dto.request.UdcMetaDataSearchDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.boot.starter.extmetadata.dto.UdcPageMetadataV2Dto> selectPageMetaData(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.extmetadata.dto.request.UdcPageInfoSearchV2Dto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.boot.starter.extmetadata.dto.UdcPageMetadataV2Dto> selectMultiplePageMetaData(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.extmetadata.dto.UdcPageInfoSearchListDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.boot.starter.extmetadata.dto.UdcPageMetadataV2Dto> selectPageLayoutInfoMetaData(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.extmetadata.dto.request.UdcPageInfoSearchV2Dto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.boot.starter.extmetadata.dto.UdcPageMetadataV2Dto> selectPageLayoutMetaData(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.extmetadata.dto.request.UdcPageInfoSearchV2Dto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.boot.starter.extmetadata.dto.UdcPageMetadataV2Dto> selectAllPageLayoutMetaDataByApp(com.seeyon.boot.transport.SingleRequest<java.util.List<com.seeyon.boot.starter.extmetadata.dto.request.UdcPageInfoSearchV2Dto>>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.boot.starter.extmetadata.dto.UdcApplicationMetaDataDto> selectHostAppPageLayoutInfoMetaData(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.extmetadata.dto.request.UdcMetaDataSearchDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.boot.starter.extmetadata.dto.UdcApplicationMetaDataDto> checkAppIncludeUrl(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.extmetadata.dto.UdcCheckAppIncludeUrlDto>);
```

### `UdcPageMetadata4OssService`（17 方法）

`com.seeyon.boot.starter.extmetadata.domain.oss.UdcPageMetadata4OssService`

```java
    com.seeyon.boot.starter.extmetadata.dto.UdcPageMetadataV2Dto selectPageMetaData(com.seeyon.boot.starter.extmetadata.dto.request.UdcPageInfoSearchV2Dto);
    java.util.List<com.seeyon.boot.starter.extmetadata.dto.UdcPageMetadataV2Dto> selectPageMetaDatList(java.util.List<com.seeyon.boot.starter.extmetadata.dto.request.UdcPageInfoSearchV2Dto>);
    com.seeyon.boot.starter.extmetadata.dto.UdcPageMetadataV2Dto selectPageLayoutMetaData(com.seeyon.boot.starter.extmetadata.dto.request.UdcPageInfoSearchV2Dto);
    java.util.List<com.seeyon.boot.starter.extmetadata.dto.UdcPageMetadataV2Dto> selectPageLayoutMetaDataList(java.util.List<com.seeyon.boot.starter.extmetadata.dto.request.UdcPageInfoSearchV2Dto>);
    java.util.List<com.seeyon.boot.starter.extmetadata.dto.UdcPageMetadataV2Dto> getPageInfoListByAppNameWithoutSchema(java.lang.String);
    private java.util.List<com.seeyon.boot.starter.extmetadata.dto.PageInfoItemOssDto> getPageInfo4Oss(java.util.List<com.seeyon.boot.starter.extmetadata.dto.request.UdcPageInfoSearchV2Dto>);
    private java.util.List<com.seeyon.boot.starter.extmetadata.dto.PageInfoItemOssDto> getPageLayout4Oss(java.util.List<com.seeyon.boot.starter.extmetadata.dto.request.UdcPageInfoSearchV2Dto>);
    com.seeyon.boot.starter.extmetadata.dto.UdcPageMetadataV2Dto selectSchema(java.lang.String, java.lang.String, java.lang.Long, com.seeyon.boot.starter.extmetadata.dto.PageInfoItemOssDto);
    java.lang.String selectSchema(java.lang.String, java.lang.String, java.lang.Long);
    private void checkParam(java.util.List<com.seeyon.boot.starter.extmetadata.dto.request.UdcPageInfoSearchV2Dto>);
    private java.util.List<com.seeyon.boot.starter.extmetadata.dto.PageInfoItemOssDto> getPageInfoItemOssDtoList(java.util.List<com.seeyon.boot.starter.extmetadata.dto.request.UdcPageInfoSearchV2Dto>, com.seeyon.ctp.metadata.dto.request.SearchJsonMetadataDto);
    private java.util.List<com.seeyon.boot.starter.extmetadata.dto.PageInfoItemOssDto> toPageInfoItemOssDtoList(java.lang.String, java.lang.String);
```

### `UdcCtpEnumMetaDataService`（16 方法）

`com.seeyon.boot.starter.extmetadata.domain.UdcCtpEnumMetaDataService`

```java
    java.util.List<com.seeyon.boot.starter.extmetadata.dto.UdcCtpEnumDto> selectCtpEnumByAppName(com.seeyon.boot.starter.extmetadata.dto.request.UdcMetaDataSearchDto);
    java.util.List<com.seeyon.boot.starter.extmetadata.dto.UdcCtpEnumDto> selectCtpEnumByAppNameNoLevel(com.seeyon.boot.starter.extmetadata.dto.request.UdcMetaDataSearchDto);
    com.seeyon.boot.starter.enums.dto.CtpEnumDto selectParentEnumByCode(com.seeyon.boot.starter.extmetadata.dto.request.UdcCtpEnumMetaDataSearchDto);
    java.util.List<com.seeyon.boot.starter.extmetadata.dto.UdcCtpEnumDto> selectCtpEnumByFullNames(com.seeyon.boot.starter.extmetadata.dto.request.UdcCtpEnumsMetaDataSearchDto);
    java.util.List<com.seeyon.boot.starter.extmetadata.dto.UdcCtpEnumDto> selectTiledCtpEnumByFullNames(com.seeyon.boot.starter.extmetadata.dto.request.UdcCtpEnumsMetaDataSearchDto);
    private java.util.List<com.seeyon.ctp.metadata.dto.CtpEnumMetadataDto> getCtpEnumMetadataDto(com.seeyon.boot.starter.extmetadata.dto.request.UdcCtpEnumsMetaDataSearchDto);
    private java.util.List<com.seeyon.ctp.metadata.dto.CtpEnumMetadataDto> getCtpEnumMetadataDto(com.seeyon.boot.starter.extmetadata.dto.request.UdcMetaDataSearchDto);
    private java.util.List<com.seeyon.boot.starter.extmetadata.dto.UdcCtpEnumDto> changeCtpMetadata2UdcNoLevel(java.lang.String, java.util.List<com.seeyon.ctp.metadata.dto.CtpEnumMetadataDto>);
    private java.util.List<com.seeyon.boot.starter.extmetadata.dto.UdcCtpEnumDto> changeCtpMetadata2Udc(java.lang.String, java.util.List<com.seeyon.ctp.metadata.dto.CtpEnumMetadataDto>);
```

### `UdcLoadResourceService`（16 方法）

`com.seeyon.boot.starter.extmetadata.domain.resource.UdcLoadResourceService`

```java
    java.lang.String getJsonMetadataData(java.lang.String, java.lang.String);
    java.lang.String getRuntimeJsonData(java.lang.String, java.lang.String);
    java.lang.String getRootJsonData(java.lang.String, java.lang.String);
    java.lang.String getRuntimeJsonData(java.net.URLClassLoader, java.lang.String, java.lang.String);
    void clearCacheByAppName(java.lang.String);
    private java.lang.String getCache(java.lang.String, java.util.concurrent.Callable<java.lang.String>);
    private java.lang.String getRootJsonData(java.lang.String, java.lang.String, boolean, java.lang.String);
    private java.lang.String getRuntimeJsonData(java.lang.String, java.lang.String, boolean, java.lang.String);
    private java.lang.String getJsonMetadata(java.lang.String, java.lang.String, boolean, java.lang.String);
    private java.lang.String readRootJsonFile(java.lang.String, java.lang.String, boolean, java.lang.String)
    private java.lang.String readJsonFile(java.lang.String, java.lang.String, boolean, java.lang.String, java.lang.String)
    private java.net.URL getAssembleJarUrl(java.lang.String, java.lang.String);
```

### `UdcPageInfoMetaDataService`（14 方法）

`com.seeyon.boot.starter.extmetadata.domain.UdcPageInfoMetaDataService`

```java
    com.seeyon.boot.starter.extmetadata.dto.UdcPageMetadataV2Dto selectPageInfo(com.seeyon.boot.starter.extmetadata.dto.request.UdcObjectMetaDataSearchDto);
    com.seeyon.boot.starter.extmetadata.dto.UdcPageMetadataV2Dto selectPageInfoBySearchDto(com.seeyon.boot.starter.extmetadata.dto.UdcPageMetaDataSearchDto);
    java.util.List<com.seeyon.boot.starter.extmetadata.dto.UdcPageMetadataV2Dto> selectPageInfoList(com.seeyon.boot.starter.extmetadata.dto.request.UdcPagesMetaDataSearchDto);
    java.util.List<com.seeyon.boot.starter.extmetadata.dto.UdcApplicationMetaDataDto> selectApplicationAndPageLayout4HostAppName(com.seeyon.boot.starter.extmetadata.dto.request.UdcMetaDataSearchDto);
    com.seeyon.boot.starter.extmetadata.dto.UdcApplicationMetaDataDto checkAppIncludeUrl(com.seeyon.boot.starter.extmetadata.dto.UdcCheckAppIncludeUrlDto);
    java.util.List<com.seeyon.boot.starter.extmetadata.dto.UdcPageMetadataV2Dto> selectPageInfoListByAppName(com.seeyon.boot.starter.extmetadata.dto.request.UdcMetaDataSearchDto);
    private boolean filterBySearchParam(com.seeyon.ctp.metadata.dto.PageMetadataDto, com.seeyon.boot.starter.extmetadata.dto.request.UdcPagesMetaDataSearchDto);
```

### `UdcAppServiceMethodMetadataDto`（14 方法）

`com.seeyon.boot.starter.extmetadata.dto.UdcAppServiceMethodMetadataDto`

```java
    java.lang.String getMethodName();
    java.lang.String getCaption();
    java.lang.String getInterfaceClass();
    java.lang.String getImplClass();
    boolean isDubbo();
    com.seeyon.ctp.metadata.dto.model.ParameterDto getParameter();
    com.seeyon.ctp.metadata.dto.model.ReturnValueDto getReturnValue();
    void setMethodName(java.lang.String);
    void setCaption(java.lang.String);
    void setInterfaceClass(java.lang.String);
    void setImplClass(java.lang.String);
    void setDubbo(boolean);
    void setParameter(com.seeyon.ctp.metadata.dto.model.ParameterDto);
    void setReturnValue(com.seeyon.ctp.metadata.dto.model.ReturnValueDto);
```

### `UdcServiceMetadataService`（12 方法）

`com.seeyon.boot.starter.extmetadata.domain.UdcServiceMetadataService`

```java
    com.seeyon.boot.starter.extmetadata.dto.UdcApplicationMetaDataDto selectServiceMetadataByName(java.lang.String);
    com.seeyon.boot.starter.extmetadata.dto.UdcApplicationMetaDataDto selectStarterMetadataByName(java.lang.String);
    com.seeyon.boot.starter.extmetadata.dto.UdcApplicationMetaDataDto selectServiceMetadataByName(com.seeyon.boot.starter.extmetadata.dto.request.UdcMetaDataSearchDto);
    com.seeyon.boot.starter.extmetadata.dto.UdcApplicationMetaDataDto selectServiceMetadata(com.seeyon.boot.starter.extmetadata.dto.request.UdcApplicationMetaDataSearchDto);
    java.util.List<com.seeyon.boot.starter.extmetadata.dto.UdcApplicationMetaDataDto> selectServiceMetadataByNames(java.util.List<java.lang.String>);
    private com.seeyon.boot.starter.extmetadata.dto.UdcApplicationMetaDataDto throwNotFoundError(com.seeyon.boot.starter.extmetadata.dto.request.UdcApplicationMetaDataSearchDto);
    private com.seeyon.boot.starter.extmetadata.dto.UdcApplicationMetaDataDto change(com.seeyon.ctp.metadata.dto.ServiceMetadataDto);
    private com.seeyon.boot.starter.extmetadata.dto.UdcApplicationMetaDataDto changeStarterMetadataDto(com.seeyon.ctp.metadata.dto.StarterMetadataDto);
    private java.lang.String getSearchDtoMasterVersion(com.seeyon.boot.starter.extmetadata.dto.request.UdcMetaDataSearchDto);
    private java.lang.String[] splitVersion(java.lang.String, java.lang.String);
```

### `UdcEnumMetaDataService`（10 方法）

`com.seeyon.boot.starter.extmetadata.domain.UdcEnumMetaDataService`

```java
    java.util.List<com.seeyon.boot.starter.extmetadata.dto.UdcJavaEnumMetaDataDto> selectEnumByAppName(com.seeyon.boot.starter.extmetadata.dto.request.UdcMetaDataSearchDto);
    java.util.List<com.seeyon.boot.starter.extmetadata.dto.UdcJavaEnumMetaDataDto> selectEnumByFullNames(com.seeyon.boot.starter.extmetadata.dto.request.UdcJavaEnumsMetaDataSearchDto);
    com.seeyon.boot.starter.extmetadata.dto.UdcJavaEnumCategoryAndItemDto selectEnumCategoryByAppName(com.seeyon.boot.starter.extmetadata.dto.request.UdcMetaDataSearchDto);
    java.util.List<com.seeyon.boot.starter.extmetadata.dto.UdcJavaEnumItemMetaDataDto> selectEnumItem4Metadata(com.seeyon.boot.starter.extmetadata.dto.request.UdcJavaEnumMetaDataSearchDto);
    private com.seeyon.ctp.metadata.dto.request.SearchByFullNameDto getSearchByFullNameDto4Udc(com.seeyon.boot.starter.extmetadata.dto.request.UdcJavaEnumMetaDataSearchDto);
    private com.seeyon.ctp.metadata.dto.request.SearchByFullNamesDto getSearchByFullNamesDto4Udc(com.seeyon.boot.starter.extmetadata.dto.request.UdcJavaEnumsMetaDataSearchDto);
    private boolean isIntegrationApp(java.lang.String);
```

### `UdcAppServiceMetaDataDto`（10 方法）

`com.seeyon.boot.starter.extmetadata.dto.UdcAppServiceMetaDataDto`

```java
    java.lang.String getInterfaceClass();
    java.lang.String getRefFullName();
    java.lang.String getEntityFullName();
    boolean isPublic();
    java.util.List<com.seeyon.boot.starter.extmetadata.dto.UdcAppServiceMethodMetadataDto> getMethods();
    void setInterfaceClass(java.lang.String);
    void setRefFullName(java.lang.String);
    void setEntityFullName(java.lang.String);
    void setPublic(boolean);
    void setMethods(java.util.List<com.seeyon.boot.starter.extmetadata.dto.UdcAppServiceMethodMetadataDto>);
```

### `ResponseUtils`（10 方法）

`com.seeyon.boot.starter.extmetadata.utils.ResponseUtils`

```java
    static <T> java.util.Optional<T> ofNullable(com.seeyon.boot.transport.SingleResponse<T>);
    static <T, X extends java.lang.Throwable> T requireNonNull(com.seeyon.boot.transport.SingleResponse<T>, java.util.function.Supplier<? extends X>)
    static <T> java.util.Optional<java.util.List<T>> ofNullable(com.seeyon.boot.transport.ListResponse<T>);
    static <T, X extends java.lang.Throwable> java.util.List<T> requireNonNull(com.seeyon.boot.transport.ListResponse<T>, java.util.function.Supplier<? extends X>)
    static <T> java.util.Optional<com.seeyon.boot.transport.PageData<T>> ofNullable(com.seeyon.boot.transport.PageResponse<T>);
    static <T, X extends java.lang.Throwable> com.seeyon.boot.transport.PageData<T> requireNonNull(com.seeyon.boot.transport.PageResponse<T>, java.util.function.Supplier<? extends X>)
    static <T> T responseResolve(com.seeyon.boot.transport.SingleResponse<T>, java.lang.String);
    static <T> java.util.List<T> listResponseResolve(com.seeyon.boot.transport.ListResponse<T>, java.lang.String);
    static <T> java.util.List<T> pageResponseResolve(com.seeyon.boot.transport.PageResponse<T>, java.lang.String);
    static com.seeyon.boot.transport.BaseResponse checkResponse(com.seeyon.boot.transport.BaseResponse, java.lang.String);
```

### `MetadataJsonPathHelper`（7 方法）

`com.seeyon.boot.starter.extmetadata.utils.MetadataJsonPathHelper`

```java
    void run(org.springframework.boot.ApplicationArguments)
    static <T> T readPath(java.lang.String, java.lang.String, T, com.jayway.jsonpath.Predicate...);
    static <T> T readPath(com.jayway.jsonpath.DocumentContext, java.lang.String, T, com.jayway.jsonpath.Predicate...);
    static <T> T readPath(java.lang.String, java.lang.String, java.lang.Class<T>, T, com.jayway.jsonpath.Predicate...);
    static <T> T readPath(com.jayway.jsonpath.DocumentContext, java.lang.String, java.lang.Class<T>, T, com.jayway.jsonpath.Predicate...);
    static <T> T readPath(java.lang.String, java.lang.String, com.jayway.jsonpath.TypeRef<T>, T);
    static <T> T readPath(com.jayway.jsonpath.DocumentContext, java.lang.String, com.jayway.jsonpath.TypeRef<T>, T);
```

### `UdeMetadataCheckUtil`（7 方法）

`com.seeyon.boot.starter.extmetadata.utils.UdeMetadataCheckUtil`

```java
    static void checkMetaDataSearchParams(com.seeyon.boot.starter.extmetadata.dto.request.UdcMetaDataSearchDto);
    static com.seeyon.ctp.metadata.dto.request.SearchMetadataDto getSearchMetadataDto4Udc(com.seeyon.boot.starter.extmetadata.dto.request.UdcMetaDataSearchDto);
    static com.seeyon.ctp.metadata.dto.request.SearchByFullNameDto getSearchByFullNameDto4Udc(com.seeyon.boot.starter.extmetadata.dto.request.UdcObjectMetaDataSearchDto);
    static com.seeyon.ctp.metadata.dto.request.SearchByFullNameDto getSearchByFullNameDto4Udc(com.seeyon.boot.starter.extmetadata.dto.request.UdcObjectsMetaDataSearchDto);
    static com.seeyon.ctp.metadata.dto.request.SearchByFullNamesDto getSearchByFullNamesDto4Udc(com.seeyon.boot.starter.extmetadata.dto.request.UdcObjectMetaDataSearchDto);
    static com.seeyon.ctp.metadata.dto.request.SearchByFullNamesDto getSearchByFullNamesDto4Udc(com.seeyon.boot.starter.extmetadata.dto.request.UdcObjectsMetaDataSearchDto);
    static private static void handlerVersion(com.seeyon.ctp.metadata.dto.request.SearchMetadataDto, com.seeyon.boot.starter.extmetadata.dto.request.UdcMetaDataSearchDto);
```

### `UdcLoadJarResourceAppService`（6 方法）

`com.seeyon.boot.starter.extmetadata.appservice.UdcLoadJarResourceAppService`

```java
    com.seeyon.boot.transport.SingleResponse<java.lang.String> getJsonMetadataData(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.metadata.dto.request.SearchJsonMetadataDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.String> getRuntimeJsonData(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.metadata.dto.request.SearchJsonMetadataDto>);
    private java.lang.String searchJsonString(com.seeyon.boot.starter.extmetadata.appservice.UdcLoadJarResourceAppService$WrapSearchJsonMetadataDto, java.util.function.Function<com.seeyon.ctp.metadata.dto.request.SearchJsonMetadataDto, java.lang.String>, java.util.function.Function<com.seeyon.boot.starter.extmetadata.appservice.UdcLoadJarResourceAppService$WrapSearchJsonMetadataDto, java.lang.String>);
    java.lang.String invokeAppServiceReturnSingle(com.seeyon.boot.starter.extmetadata.appservice.UdcLoadJarResourceAppService$WrapSearchJsonMetadataDto);
```

### `UdcDtoMetaDataService`（5 方法）

`com.seeyon.boot.starter.extmetadata.domain.UdcDtoMetaDataService`

```java
    java.util.List<com.seeyon.boot.starter.extmetadata.dto.UdcDtoMetadataDto> selectSimpleByAppName(com.seeyon.boot.starter.extmetadata.dto.request.UdcMetaDataSearchDto);
    java.util.List<com.seeyon.boot.starter.extmetadata.dto.UdcDtoMetadataDto> selectSimpleByEntityFullNames(com.seeyon.boot.starter.extmetadata.dto.request.UdcDtoListMetaDataSearchDto);
```

### `UdcFrontendResourceService`（5 方法）

`com.seeyon.boot.starter.extmetadata.domain.resource.UdcFrontendResourceService`

```java
    java.lang.String readFrontResourceJson(java.lang.String);
    private java.lang.String readJsonFromStorage(java.lang.String);
    private java.lang.String readJsonByHttp(java.lang.String, java.lang.String);
    private java.lang.String readJsonByFile(java.lang.String, java.lang.String);
    private java.lang.String readJsonForMonolithic(java.lang.String);
```

### `UdcI18nUtils`（4 方法）

`com.seeyon.boot.starter.extmetadata.utils.UdcI18nUtils`

```java
    static private static void init();
    static java.lang.String getEnumItemMessage(java.lang.String, java.lang.String);
    static java.lang.String getMetadataMessage(java.lang.String, java.lang.String);
    static java.lang.String getMetadataMessage(java.lang.String, java.lang.String, java.lang.String);
```

### `HostAppFunctionHandlerFacade`（3 方法）

`com.seeyon.boot.starter.extmetadata.appservice.HostAppFunctionHandlerFacade`

```java
    com.seeyon.boot.transport.ListResponse<com.seeyon.boot.starter.extmetadata.dto.UdcApplicationMetaDataDto> selectDependentApplicationByHostAppName(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.extmetadata.dto.request.UdcMetaDataSearchDto>);
    private com.seeyon.boot.starter.extmetadata.api.HostAppFunctionInterface getHostAppFunctionInterface(java.lang.String);
```

### `UdcIdFullNameMetadata4OssService`（3 方法）

`com.seeyon.boot.starter.extmetadata.domain.oss.UdcIdFullNameMetadata4OssService`

```java
    java.util.Map<java.lang.String, java.lang.String> selectIdFullNameMap(java.lang.String);
    java.util.Map<java.lang.String, java.lang.String> selectReferIdFullNameMap(java.lang.String);
    java.util.List<java.lang.Long> selectCtpEnumDesignOriginalId(java.lang.String);
```

### `UdcMethod2ActionUtil`（3 方法）

`com.seeyon.boot.starter.extmetadata.utils.UdcMethod2ActionUtil`

```java
    static java.util.List<com.seeyon.boot.starter.extmetadata.enums.EntityActionEnum> getActionEnumByAppServiceMetadata(com.seeyon.boot.starter.extmetadata.dto.UdcAppServiceMetaDataDto);
```

## 四、枚举（12）

- `AttributeCalculateEnum`（3 常量）：NORMAL, COMPUTE, AGGREGATION
- `AttributeSourceTypeEnum`（5 常量）：ENTITY, ATTRIBUTESET, SYSTEM_ATTRIBUTE_SET, SYSTEM, EXT
- `DependentAppTypeEnum`（5 常量）：SERVICE, STARTER, FROM, FRONTEND, PLATFORM
- `DynamicDependencyTypeEnum`（3 常量）：NONE, FORM_NORMAL, INTEGRATION
- `EntityActionEnum`（27 常量）：ENTITY_SELECT_SINGLE, ENTITY_SELECT_LIST, ENTITY_SAVE_DRAFT, ENTITY_SAVE, ENTITY_SUBMIT, ENTITY_WITHDRAW, ENTITY_REFRESH, ENTITY_DELETE, ENTITY_SAVE_NEW, ENTITY_IMPORT, ENTITY_EXPORT, ENTITY_PRINT …
- `EntityCategoryEnum`（6 常量）：ENTITY, EXT, EXT_GLOBAL, THIRD, COMPONENT_ENTITY, BASIC_DATA
- `EntityRelationMultiplicityEnum`（2 常量）：ONE2ONE, ONE2MANY
- `FrontendPackageTypeEnum`（3 常量）：NONE, CONTROL, ACTION
- `MedaDataPageTypeEnum`（14 常量）：PORTAL, WELCOME, REPORT_FORM, DETAIL, LIST, APPROVAL, PORTLET, SEARCH_LIST, EDIT_LIST, LIST_DETAIL, ASSIST_INFO, OTHER …
- `OpenWayEnum`（2 常量）：REFRESH, NEW_PAGE
- `PageSourceTypeEnum`（4 常量）：DESIGNER, PRESET, COPY, TEMPLATE
- `PageUrlTypeEnum`（2 常量）：PC, MOBILE
