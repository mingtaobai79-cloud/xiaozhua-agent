# boot-starter-sharding：接口与方法签名

> 自动生成，勿手改。`tools/core/platform/emit_package_surfaces.py` 重跑即可。
> 构件 `com.seeyon:boot-starter-sharding`（jar `boot-starter-sharding-5.3.600.jar`）
> 规模：61 类 / 5 接口 / 0 注解 / 4 枚举 / 8 个关键类 / 463 方法。
> 签名逐字来自 javap 原文；已去掉 `public` 前缀与 `throws` 子句。

## 一、接口（5）

### `ShardingAppServiceInterface`（6 方法）

`com.seeyon.boot.starter.sharding.appservice.ShardingAppServiceInterface`

```java
    com.seeyon.boot.transport.SingleResponse<java.lang.Long> createTenantSharding(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.sharding.dto.CtpTenantShardingDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> batchCreateTenantSharding(com.seeyon.boot.transport.SingleRequest<java.util.List<com.seeyon.boot.starter.sharding.dto.CtpTenantShardingDto>>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> updateTenantSharding(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.sharding.dto.CtpTenantShardingDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> deleteTenantShardingByIds(com.seeyon.boot.transport.SingleRequest<java.util.List<java.lang.Long>>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> deleteTenantShardingById(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.boot.starter.sharding.dto.CtpTenantShardingDto> selectTenantShardingByTenantId(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
```

### `CtpOBSChecker`（1 方法）

`com.seeyon.boot.starter.sharding.CtpOBSChecker`

```java
    boolean check(com.seeyon.boot.starter.sharding.dto.CtpOBSInfoDto);
```

### `CtpDBInfoDao`（0 方法） extends CtpDBInfo>

`com.seeyon.boot.starter.sharding.domain.dao.CtpDBInfoDao`

```java
```

### `CtpOBSInfoDao`（0 方法） extends CtpOBSInfo>

`com.seeyon.boot.starter.sharding.domain.dao.CtpOBSInfoDao`

```java
```

### `CtpTenantShardingDao`（0 方法） extends CtpTenantSharding>

`com.seeyon.boot.starter.sharding.domain.dao.CtpTenantShardingDao`

```java
```

## 二、关键类（8）

### `ShardingAppService`（46 方法）

`com.seeyon.boot.starter.sharding.appservice.ShardingAppService`

```java
    com.seeyon.boot.transport.SingleResponse<java.lang.Long> createDBInfo(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.sharding.dto.CtpDBInfoDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Boolean> checkDBInfo(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.sharding.dto.CtpDBInfoDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> updateDBInfo(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.sharding.dto.CtpDBInfoDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> deleteDBInfoByIds(com.seeyon.boot.transport.SingleRequest<java.util.List<java.lang.Long>>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> deleteDBInfoById(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.boot.starter.sharding.dto.CtpDBInfoDto> selectDBInfoById(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.boot.starter.sharding.dto.CtpDBInfoDto> selectDBInfoByIds(com.seeyon.boot.transport.SingleRequest<java.util.List<java.lang.Long>>);
    com.seeyon.boot.transport.PageResponse<com.seeyon.boot.starter.sharding.dto.CtpDBInfoDto> selectDBInfoPageByConditions(com.seeyon.boot.transport.PageRequest);
    com.seeyon.boot.transport.ListResponse<com.seeyon.boot.starter.sharding.dto.CtpDBInfoDto> selectDBInfoListByConditions(com.seeyon.boot.transport.ListRequest);
    com.seeyon.boot.transport.ListResponse<com.seeyon.boot.starter.sharding.dto.CtpDBInfoDto> selectAllDBInfo();
    com.seeyon.boot.transport.SingleResponse<java.lang.Long> createOBSInfo(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.sharding.dto.CtpOBSInfoDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Boolean> checkOBSInfo(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.sharding.dto.CtpOBSInfoDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> updateOBSInfo(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.sharding.dto.CtpOBSInfoDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> deleteOBSInfoByIds(com.seeyon.boot.transport.SingleRequest<java.util.List<java.lang.Long>>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> deleteOBSInfoById(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.boot.starter.sharding.dto.CtpOBSInfoDto> selectOBSInfoById(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.boot.starter.sharding.dto.CtpOBSInfoDto> selectOBSInfoByIds(com.seeyon.boot.transport.SingleRequest<java.util.List<java.lang.Long>>);
    com.seeyon.boot.transport.PageResponse<com.seeyon.boot.starter.sharding.dto.CtpOBSInfoDto> selectOBSInfoPageByConditions(com.seeyon.boot.transport.PageRequest);
    com.seeyon.boot.transport.ListResponse<com.seeyon.boot.starter.sharding.dto.CtpOBSInfoDto> selectOBSInfoListByConditions(com.seeyon.boot.transport.ListRequest);
    com.seeyon.boot.transport.ListResponse<com.seeyon.boot.starter.sharding.dto.CtpOBSInfoDto> selectAllOBSInfo();
    com.seeyon.boot.transport.SingleResponse<java.lang.Long> createTenantSharding(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.sharding.dto.CtpTenantShardingDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> batchCreateTenantSharding(com.seeyon.boot.transport.SingleRequest<java.util.List<com.seeyon.boot.starter.sharding.dto.CtpTenantShardingDto>>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> updateTenantSharding(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.sharding.dto.CtpTenantShardingDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> deleteTenantShardingByIds(com.seeyon.boot.transport.SingleRequest<java.util.List<java.lang.Long>>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> deleteTenantShardingById(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.boot.starter.sharding.dto.CtpTenantShardingDto> selectTenantShardingById(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.boot.starter.sharding.dto.CtpTenantShardingDto> selectTenantShardingByTenantId(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.boot.starter.sharding.dto.CtpTenantShardingDto> selectTenantShardingByTenantId(java.lang.Long, com.seeyon.boot.starter.sharding.enums.DataStorageType);
    com.seeyon.boot.transport.SingleResponse<java.lang.Long> createOrUpdateTenantSharding(java.lang.Long, com.seeyon.boot.starter.sharding.enums.DataStorageType, java.lang.Long);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.boot.starter.sharding.dto.ShardingDetailDto> selectTenantShardingDetailByTenantId(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.boot.starter.sharding.dto.ShardingDetailDto> selectTenantShardingDetailByTenantId(java.lang.Long, com.seeyon.boot.starter.sharding.enums.DataStorageType);
    com.seeyon.boot.transport.ListResponse<com.seeyon.boot.starter.sharding.dto.CtpTenantShardingDto> selectShardingByIds(com.seeyon.boot.transport.SingleRequest<java.util.List<java.lang.Long>>);
    com.seeyon.boot.transport.PageResponse<com.seeyon.boot.starter.sharding.dto.CtpTenantShardingDto> selectTenantShardingPageByConditions(com.seeyon.boot.transport.PageRequest);
    com.seeyon.boot.transport.ListResponse<com.seeyon.boot.starter.sharding.dto.CtpTenantShardingDto> selectTenantShardingListByConditions(com.seeyon.boot.transport.ListRequest);
    com.seeyon.boot.transport.ListResponse<com.seeyon.boot.starter.sharding.dto.CtpTenantShardingDto> selectAllTenantSharding();
    com.seeyon.boot.context.model.TenantInfo selectTenantInfo(java.lang.Long);
    private com.seeyon.boot.starter.dubbo.api.AppServiceProxy getUserAppServiceProxy();
    private void afterTenantShardingCreated(com.seeyon.boot.starter.sharding.dto.CtpTenantShardingDto);
    private void updateResourceIsUsed(com.seeyon.boot.starter.sharding.enums.DataStorageType, java.lang.Long, boolean);
    private void checkEnableExclusive();
    private void checkDatabaseType(com.seeyon.boot.domain.dao.support.DatabaseType);
    private void checkDbaDatabaseWithPg(com.seeyon.boot.starter.sharding.dto.CtpDBInfoDto);
    private void checkTablespaceWithDm(com.seeyon.boot.starter.sharding.dto.CtpDBInfoDto);
    private java.sql.Connection getConnection(java.lang.String, java.lang.String, java.lang.String)
    private void closeResource(java.lang.AutoCloseable);
```

### `CtpTenantShardingService`（13 方法）

`com.seeyon.boot.starter.sharding.domain.service.CtpTenantShardingService`

```java
    java.lang.Long create(com.seeyon.boot.starter.sharding.dto.CtpTenantShardingDto);
    int createBatch(java.util.List<com.seeyon.boot.starter.sharding.dto.CtpTenantShardingDto>);
    java.lang.Long createOrUpdate(com.seeyon.boot.starter.sharding.dto.CtpTenantShardingDto);
    java.lang.Integer update(com.seeyon.boot.starter.sharding.dto.CtpTenantShardingDto);
    int deleteById(java.lang.Long);
    int deleteByIds(java.util.List<java.lang.Long>);
    com.seeyon.boot.starter.sharding.dto.CtpTenantShardingDto selectById(java.lang.Long);
    java.util.List<com.seeyon.boot.starter.sharding.dto.CtpTenantShardingDto> selectByTenantId(java.lang.Long);
    com.seeyon.boot.starter.sharding.dto.CtpTenantShardingDto selectByTenantIdAndStorageType(java.lang.Long, com.seeyon.boot.starter.sharding.enums.DataStorageType);
    java.util.List<com.seeyon.boot.starter.sharding.dto.CtpTenantShardingDto> selectByIds(java.util.List<java.lang.Long>);
    com.seeyon.boot.transport.PageData<com.seeyon.boot.starter.sharding.dto.CtpTenantShardingDto> selectPageByConditions(com.seeyon.boot.transport.PageInfo, java.util.Map<java.lang.String, java.lang.Object>, com.seeyon.boot.transport.Sort);
    java.util.List<com.seeyon.boot.starter.sharding.dto.CtpTenantShardingDto> selectListByConditions(java.util.Map<java.lang.String, java.lang.Object>, com.seeyon.boot.transport.Sort);
    java.util.List<com.seeyon.boot.starter.sharding.dto.CtpTenantShardingDto> selectAll();
```

### `CtpDBInfoService`（10 方法）

`com.seeyon.boot.starter.sharding.domain.service.CtpDBInfoService`

```java
    java.lang.Long create(com.seeyon.boot.starter.sharding.dto.CtpDBInfoDto);
    java.lang.Integer update(com.seeyon.boot.starter.sharding.dto.CtpDBInfoDto);
    int deleteById(java.lang.Long);
    int deleteByIds(java.util.List<java.lang.Long>);
    com.seeyon.boot.starter.sharding.dto.CtpDBInfoDto selectById(java.lang.Long);
    java.util.List<com.seeyon.boot.starter.sharding.dto.CtpDBInfoDto> selectByIds(java.util.List<java.lang.Long>);
    com.seeyon.boot.transport.PageData<com.seeyon.boot.starter.sharding.dto.CtpDBInfoDto> selectPageByConditions(com.seeyon.boot.transport.PageInfo, java.util.Map<java.lang.String, java.lang.Object>, com.seeyon.boot.transport.Sort);
    java.util.List<com.seeyon.boot.starter.sharding.dto.CtpDBInfoDto> selectListByConditions(java.util.Map<java.lang.String, java.lang.Object>, com.seeyon.boot.transport.Sort);
    java.util.List<com.seeyon.boot.starter.sharding.dto.CtpDBInfoDto> selectAll();
    private void checkDefaultConflict(java.lang.String, java.lang.Integer);
```

### `CtpOBSInfoService`（9 方法）

`com.seeyon.boot.starter.sharding.domain.service.CtpOBSInfoService`

```java
    java.lang.Long create(com.seeyon.boot.starter.sharding.dto.CtpOBSInfoDto);
    java.lang.Integer update(com.seeyon.boot.starter.sharding.dto.CtpOBSInfoDto);
    int deleteById(java.lang.Long);
    int deleteByIds(java.util.List<java.lang.Long>);
    com.seeyon.boot.starter.sharding.dto.CtpOBSInfoDto selectById(java.lang.Long);
    java.util.List<com.seeyon.boot.starter.sharding.dto.CtpOBSInfoDto> selectByIds(java.util.List<java.lang.Long>);
    com.seeyon.boot.transport.PageData<com.seeyon.boot.starter.sharding.dto.CtpOBSInfoDto> selectPageByConditions(com.seeyon.boot.transport.PageInfo, java.util.Map<java.lang.String, java.lang.Object>, com.seeyon.boot.transport.Sort);
    java.util.List<com.seeyon.boot.starter.sharding.dto.CtpOBSInfoDto> selectListByConditions(java.util.Map<java.lang.String, java.lang.Object>, com.seeyon.boot.transport.Sort);
    java.util.List<com.seeyon.boot.starter.sharding.dto.CtpOBSInfoDto> selectAll();
```

### `TenantObsConfig`（7 方法）

`com.seeyon.boot.starter.sharding.cache.TenantObsConfig`

```java
    void addOBS(java.lang.Long, com.seeyon.boot.starter.sharding.dto.CtpOBSInfoDto);
    void addOBS(java.lang.String, com.seeyon.boot.starter.sharding.dto.CtpOBSInfoDto);
    com.seeyon.boot.starter.sharding.dto.CtpOBSInfoDto getOBS(java.lang.Long);
    com.seeyon.boot.starter.sharding.dto.CtpOBSInfoDto getOBS(com.seeyon.boot.starter.sharding.enums.ObsUseType);
    com.seeyon.boot.starter.sharding.dto.CtpOBSInfoDto getOBS(java.lang.Long, com.seeyon.boot.starter.sharding.enums.ObsUseType);
    java.util.Map<java.lang.String, com.seeyon.boot.starter.sharding.dto.CtpOBSInfoDto> getInitializedObs();
    java.util.Map<java.lang.Long, java.util.Set<com.seeyon.boot.starter.sharding.dto.CtpOBSInfoDto>> getTenantObs();
```

### `AbstractSQLBuilder`（6 方法）

`org.apache.shardingsphere.underlying.rewrite.sql.impl.AbstractSQLBuilder`

```java
    final java.lang.String toSQL();
    protected abstract java.lang.String getSQLTokenText(org.apache.shardingsphere.underlying.rewrite.sql.token.pojo.SQLToken);
    private java.lang.String getConjunctionText(org.apache.shardingsphere.underlying.rewrite.sql.token.pojo.SQLToken);
    private int getStartIndex(org.apache.shardingsphere.underlying.rewrite.sql.token.pojo.SQLToken);
    private int getStopIndex(org.apache.shardingsphere.underlying.rewrite.sql.token.pojo.SQLToken);
    org.apache.shardingsphere.underlying.rewrite.context.SQLRewriteContext getContext();
```

### `ExclusiveDataSourceAutoConfiguration`（5 方法）

`com.seeyon.boot.starter.sharding.ExclusiveDataSourceAutoConfiguration`

```java
    javax.sql.DataSource exclusiveDataSource(org.springframework.data.redis.core.RedisTemplate, com.seeyon.boot.starter.eventbus.EventBus, org.springframework.data.redis.connection.RedisConnectionFactory);
    com.seeyon.boot.starter.sharding.TableExclusiveProcessor exclusiveTableProcessor();
    com.seeyon.boot.starter.sharding.ExclusiveDataSourceProcessor exclusiveDataSourceProcessor(org.springframework.data.redis.core.RedisTemplate, com.seeyon.boot.starter.eventbus.EventBus);
    org.springframework.transaction.PlatformTransactionManager transactionManager(org.springframework.beans.factory.ObjectProvider<org.springframework.boot.autoconfigure.transaction.TransactionManagerCustomizers>, org.springframework.data.redis.core.RedisTemplate, com.seeyon.boot.starter.eventbus.EventBus, org.springframework.data.redis.connection.RedisConnectionFactory)
    void afterPropertiesSet();
```

### `ShardingRouteEngineFactory`（5 方法）

`org.apache.shardingsphere.sharding.route.engine.type.ShardingRouteEngineFactory`

```java
    static org.apache.shardingsphere.sharding.route.engine.type.ShardingRouteEngine newInstance(org.apache.shardingsphere.core.rule.ShardingRule, org.apache.shardingsphere.underlying.common.metadata.ShardingSphereMetaData, org.apache.shardingsphere.sql.parser.binder.statement.SQLStatementContext, org.apache.shardingsphere.sharding.route.engine.condition.ShardingConditions, org.apache.shardingsphere.underlying.common.config.properties.ConfigurationProperties);
    static private static org.apache.shardingsphere.sharding.route.engine.type.ShardingRouteEngine getDALRoutingEngine(org.apache.shardingsphere.core.rule.ShardingRule, org.apache.shardingsphere.sql.parser.sql.statement.SQLStatement, java.util.Collection<java.lang.String>);
    static private static org.apache.shardingsphere.sharding.route.engine.type.ShardingRouteEngine getDCLRoutingEngine(org.apache.shardingsphere.sql.parser.binder.statement.SQLStatementContext, org.apache.shardingsphere.underlying.common.metadata.ShardingSphereMetaData);
    static private static boolean isDCLForSingleTable(org.apache.shardingsphere.sql.parser.binder.statement.SQLStatementContext);
    static private static org.apache.shardingsphere.sharding.route.engine.type.ShardingRouteEngine getShardingRoutingEngine(org.apache.shardingsphere.core.rule.ShardingRule, org.apache.shardingsphere.sql.parser.binder.statement.SQLStatementContext, org.apache.shardingsphere.sharding.route.engine.condition.ShardingConditions, java.util.Collection<java.lang.String>, org.apache.shardingsphere.underlying.common.config.properties.ConfigurationProperties);
```

## 四、枚举（4）

- `DBDeployType`（2 常量）：SINGLE, CLUSTER
- `DataStorageType`（4 常量）：DATABASE, OBS, ELASTICSEARCH, CLICKHOUSE
- `OBSType`（3 常量）：OBS, OSS, MINIO
- `ObsUseType`（2 常量）：SYS, RUNTIME
