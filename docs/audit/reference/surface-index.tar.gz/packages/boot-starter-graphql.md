# boot-starter-graphql：接口与方法签名

> 自动生成，勿手改。`tools/core/platform/emit_package_surfaces.py` 重跑即可。
> 构件 `com.seeyon:boot-starter-graphql`（jar `boot-starter-graphql-5.3.600.jar`）
> 规模：772 类 / 119 接口 / 7 注解 / 12 枚举 / 54 个关键类 / 7104 方法。
> 签名逐字来自 javap 原文；已去掉 `public` 前缀与 `throws` 子句。

## 一、接口（119）

### `GraphqlListener`（150 方法） extends ParseTreeListener

`graphql.parser.antlr.GraphqlListener`

```java
    void enterDocument(graphql.parser.antlr.GraphqlParser$DocumentContext);
    void exitDocument(graphql.parser.antlr.GraphqlParser$DocumentContext);
    void enterDefinition(graphql.parser.antlr.GraphqlParser$DefinitionContext);
    void exitDefinition(graphql.parser.antlr.GraphqlParser$DefinitionContext);
    void enterTypeSystemDefinition(graphql.parser.antlr.GraphqlParser$TypeSystemDefinitionContext);
    void exitTypeSystemDefinition(graphql.parser.antlr.GraphqlParser$TypeSystemDefinitionContext);
    void enterTypeSystemExtension(graphql.parser.antlr.GraphqlParser$TypeSystemExtensionContext);
    void exitTypeSystemExtension(graphql.parser.antlr.GraphqlParser$TypeSystemExtensionContext);
    void enterSchemaDefinition(graphql.parser.antlr.GraphqlParser$SchemaDefinitionContext);
    void exitSchemaDefinition(graphql.parser.antlr.GraphqlParser$SchemaDefinitionContext);
    void enterSchemaExtension(graphql.parser.antlr.GraphqlParser$SchemaExtensionContext);
    void exitSchemaExtension(graphql.parser.antlr.GraphqlParser$SchemaExtensionContext);
    void enterOperationTypeDefinition(graphql.parser.antlr.GraphqlParser$OperationTypeDefinitionContext);
    void exitOperationTypeDefinition(graphql.parser.antlr.GraphqlParser$OperationTypeDefinitionContext);
    void enterTypeDefinition(graphql.parser.antlr.GraphqlParser$TypeDefinitionContext);
    void exitTypeDefinition(graphql.parser.antlr.GraphqlParser$TypeDefinitionContext);
    void enterTypeExtension(graphql.parser.antlr.GraphqlParser$TypeExtensionContext);
    void exitTypeExtension(graphql.parser.antlr.GraphqlParser$TypeExtensionContext);
    void enterEmptyParentheses(graphql.parser.antlr.GraphqlParser$EmptyParenthesesContext);
    void exitEmptyParentheses(graphql.parser.antlr.GraphqlParser$EmptyParenthesesContext);
    void enterScalarTypeDefinition(graphql.parser.antlr.GraphqlParser$ScalarTypeDefinitionContext);
    void exitScalarTypeDefinition(graphql.parser.antlr.GraphqlParser$ScalarTypeDefinitionContext);
    void enterScalarTypeExtensionDefinition(graphql.parser.antlr.GraphqlParser$ScalarTypeExtensionDefinitionContext);
    void exitScalarTypeExtensionDefinition(graphql.parser.antlr.GraphqlParser$ScalarTypeExtensionDefinitionContext);
    void enterObjectTypeDefinition(graphql.parser.antlr.GraphqlParser$ObjectTypeDefinitionContext);
    void exitObjectTypeDefinition(graphql.parser.antlr.GraphqlParser$ObjectTypeDefinitionContext);
    void enterObjectTypeExtensionDefinition(graphql.parser.antlr.GraphqlParser$ObjectTypeExtensionDefinitionContext);
    void exitObjectTypeExtensionDefinition(graphql.parser.antlr.GraphqlParser$ObjectTypeExtensionDefinitionContext);
    void enterImplementsInterfaces(graphql.parser.antlr.GraphqlParser$ImplementsInterfacesContext);
    void exitImplementsInterfaces(graphql.parser.antlr.GraphqlParser$ImplementsInterfacesContext);
    void enterFieldsDefinition(graphql.parser.antlr.GraphqlParser$FieldsDefinitionContext);
    void exitFieldsDefinition(graphql.parser.antlr.GraphqlParser$FieldsDefinitionContext);
    void enterExtensionFieldsDefinition(graphql.parser.antlr.GraphqlParser$ExtensionFieldsDefinitionContext);
    void exitExtensionFieldsDefinition(graphql.parser.antlr.GraphqlParser$ExtensionFieldsDefinitionContext);
    void enterFieldDefinition(graphql.parser.antlr.GraphqlParser$FieldDefinitionContext);
    void exitFieldDefinition(graphql.parser.antlr.GraphqlParser$FieldDefinitionContext);
    void enterArgumentsDefinition(graphql.parser.antlr.GraphqlParser$ArgumentsDefinitionContext);
    void exitArgumentsDefinition(graphql.parser.antlr.GraphqlParser$ArgumentsDefinitionContext);
    void enterInputValueDefinition(graphql.parser.antlr.GraphqlParser$InputValueDefinitionContext);
    void exitInputValueDefinition(graphql.parser.antlr.GraphqlParser$InputValueDefinitionContext);
    void enterInterfaceTypeDefinition(graphql.parser.antlr.GraphqlParser$InterfaceTypeDefinitionContext);
    void exitInterfaceTypeDefinition(graphql.parser.antlr.GraphqlParser$InterfaceTypeDefinitionContext);
    void enterInterfaceTypeExtensionDefinition(graphql.parser.antlr.GraphqlParser$InterfaceTypeExtensionDefinitionContext);
    void exitInterfaceTypeExtensionDefinition(graphql.parser.antlr.GraphqlParser$InterfaceTypeExtensionDefinitionContext);
    void enterUnionTypeDefinition(graphql.parser.antlr.GraphqlParser$UnionTypeDefinitionContext);
    void exitUnionTypeDefinition(graphql.parser.antlr.GraphqlParser$UnionTypeDefinitionContext);
    void enterUnionTypeExtensionDefinition(graphql.parser.antlr.GraphqlParser$UnionTypeExtensionDefinitionContext);
    void exitUnionTypeExtensionDefinition(graphql.parser.antlr.GraphqlParser$UnionTypeExtensionDefinitionContext);
    void enterUnionMembership(graphql.parser.antlr.GraphqlParser$UnionMembershipContext);
    void exitUnionMembership(graphql.parser.antlr.GraphqlParser$UnionMembershipContext);
    void enterUnionMembers(graphql.parser.antlr.GraphqlParser$UnionMembersContext);
    void exitUnionMembers(graphql.parser.antlr.GraphqlParser$UnionMembersContext);
    void enterEnumTypeDefinition(graphql.parser.antlr.GraphqlParser$EnumTypeDefinitionContext);
    void exitEnumTypeDefinition(graphql.parser.antlr.GraphqlParser$EnumTypeDefinitionContext);
    void enterEnumTypeExtensionDefinition(graphql.parser.antlr.GraphqlParser$EnumTypeExtensionDefinitionContext);
    void exitEnumTypeExtensionDefinition(graphql.parser.antlr.GraphqlParser$EnumTypeExtensionDefinitionContext);
    void enterEnumValueDefinitions(graphql.parser.antlr.GraphqlParser$EnumValueDefinitionsContext);
    void exitEnumValueDefinitions(graphql.parser.antlr.GraphqlParser$EnumValueDefinitionsContext);
    void enterExtensionEnumValueDefinitions(graphql.parser.antlr.GraphqlParser$ExtensionEnumValueDefinitionsContext);
    void exitExtensionEnumValueDefinitions(graphql.parser.antlr.GraphqlParser$ExtensionEnumValueDefinitionsContext);
    void enterEnumValueDefinition(graphql.parser.antlr.GraphqlParser$EnumValueDefinitionContext);
    void exitEnumValueDefinition(graphql.parser.antlr.GraphqlParser$EnumValueDefinitionContext);
    void enterInputObjectTypeDefinition(graphql.parser.antlr.GraphqlParser$InputObjectTypeDefinitionContext);
    void exitInputObjectTypeDefinition(graphql.parser.antlr.GraphqlParser$InputObjectTypeDefinitionContext);
    void enterInputObjectTypeExtensionDefinition(graphql.parser.antlr.GraphqlParser$InputObjectTypeExtensionDefinitionContext);
    void exitInputObjectTypeExtensionDefinition(graphql.parser.antlr.GraphqlParser$InputObjectTypeExtensionDefinitionContext);
    void enterInputObjectValueDefinitions(graphql.parser.antlr.GraphqlParser$InputObjectValueDefinitionsContext);
    void exitInputObjectValueDefinitions(graphql.parser.antlr.GraphqlParser$InputObjectValueDefinitionsContext);
    void enterExtensionInputObjectValueDefinitions(graphql.parser.antlr.GraphqlParser$ExtensionInputObjectValueDefinitionsContext);
    void exitExtensionInputObjectValueDefinitions(graphql.parser.antlr.GraphqlParser$ExtensionInputObjectValueDefinitionsContext);
    void enterDirectiveDefinition(graphql.parser.antlr.GraphqlParser$DirectiveDefinitionContext);
    void exitDirectiveDefinition(graphql.parser.antlr.GraphqlParser$DirectiveDefinitionContext);
    void enterDirectiveLocation(graphql.parser.antlr.GraphqlParser$DirectiveLocationContext);
    void exitDirectiveLocation(graphql.parser.antlr.GraphqlParser$DirectiveLocationContext);
    void enterDirectiveLocations(graphql.parser.antlr.GraphqlParser$DirectiveLocationsContext);
    void exitDirectiveLocations(graphql.parser.antlr.GraphqlParser$DirectiveLocationsContext);
    void enterOperationType(graphql.parser.antlr.GraphqlParser$OperationTypeContext);
    void exitOperationType(graphql.parser.antlr.GraphqlParser$OperationTypeContext);
    void enterDescription(graphql.parser.antlr.GraphqlParser$DescriptionContext);
    void exitDescription(graphql.parser.antlr.GraphqlParser$DescriptionContext);
    void enterEnumValue(graphql.parser.antlr.GraphqlParser$EnumValueContext);
    void exitEnumValue(graphql.parser.antlr.GraphqlParser$EnumValueContext);
    void enterArrayValue(graphql.parser.antlr.GraphqlParser$ArrayValueContext);
    void exitArrayValue(graphql.parser.antlr.GraphqlParser$ArrayValueContext);
    void enterArrayValueWithVariable(graphql.parser.antlr.GraphqlParser$ArrayValueWithVariableContext);
    void exitArrayValueWithVariable(graphql.parser.antlr.GraphqlParser$ArrayValueWithVariableContext);
    void enterObjectValue(graphql.parser.antlr.GraphqlParser$ObjectValueContext);
    void exitObjectValue(graphql.parser.antlr.GraphqlParser$ObjectValueContext);
    void enterObjectValueWithVariable(graphql.parser.antlr.GraphqlParser$ObjectValueWithVariableContext);
    void exitObjectValueWithVariable(graphql.parser.antlr.GraphqlParser$ObjectValueWithVariableContext);
    void enterObjectField(graphql.parser.antlr.GraphqlParser$ObjectFieldContext);
    void exitObjectField(graphql.parser.antlr.GraphqlParser$ObjectFieldContext);
    void enterObjectFieldWithVariable(graphql.parser.antlr.GraphqlParser$ObjectFieldWithVariableContext);
    void exitObjectFieldWithVariable(graphql.parser.antlr.GraphqlParser$ObjectFieldWithVariableContext);
    void enterDirectives(graphql.parser.antlr.GraphqlParser$DirectivesContext);
    void exitDirectives(graphql.parser.antlr.GraphqlParser$DirectivesContext);
    void enterDirective(graphql.parser.antlr.GraphqlParser$DirectiveContext);
    void exitDirective(graphql.parser.antlr.GraphqlParser$DirectiveContext);
    void enterArguments(graphql.parser.antlr.GraphqlParser$ArgumentsContext);
    void exitArguments(graphql.parser.antlr.GraphqlParser$ArgumentsContext);
    void enterArgument(graphql.parser.antlr.GraphqlParser$ArgumentContext);
    void exitArgument(graphql.parser.antlr.GraphqlParser$ArgumentContext);
    void enterBaseName(graphql.parser.antlr.GraphqlParser$BaseNameContext);
    void exitBaseName(graphql.parser.antlr.GraphqlParser$BaseNameContext);
    void enterFragmentName(graphql.parser.antlr.GraphqlParser$FragmentNameContext);
    void exitFragmentName(graphql.parser.antlr.GraphqlParser$FragmentNameContext);
    void enterEnumValueName(graphql.parser.antlr.GraphqlParser$EnumValueNameContext);
    void exitEnumValueName(graphql.parser.antlr.GraphqlParser$EnumValueNameContext);
    void enterName(graphql.parser.antlr.GraphqlParser$NameContext);
    void exitName(graphql.parser.antlr.GraphqlParser$NameContext);
    void enterValue(graphql.parser.antlr.GraphqlParser$ValueContext);
    void exitValue(graphql.parser.antlr.GraphqlParser$ValueContext);
    void enterValueWithVariable(graphql.parser.antlr.GraphqlParser$ValueWithVariableContext);
    void exitValueWithVariable(graphql.parser.antlr.GraphqlParser$ValueWithVariableContext);
    void enterVariable(graphql.parser.antlr.GraphqlParser$VariableContext);
    void exitVariable(graphql.parser.antlr.GraphqlParser$VariableContext);
    void enterDefaultValue(graphql.parser.antlr.GraphqlParser$DefaultValueContext);
    void exitDefaultValue(graphql.parser.antlr.GraphqlParser$DefaultValueContext);
    void enterStringValue(graphql.parser.antlr.GraphqlParser$StringValueContext);
    void exitStringValue(graphql.parser.antlr.GraphqlParser$StringValueContext);
    void enterType(graphql.parser.antlr.GraphqlParser$TypeContext);
    void exitType(graphql.parser.antlr.GraphqlParser$TypeContext);
    void enterTypeName(graphql.parser.antlr.GraphqlParser$TypeNameContext);
    void exitTypeName(graphql.parser.antlr.GraphqlParser$TypeNameContext);
    void enterListType(graphql.parser.antlr.GraphqlParser$ListTypeContext);
    void exitListType(graphql.parser.antlr.GraphqlParser$ListTypeContext);
    void enterNonNullType(graphql.parser.antlr.GraphqlParser$NonNullTypeContext);
    void exitNonNullType(graphql.parser.antlr.GraphqlParser$NonNullTypeContext);
    void enterOperationDefinition(graphql.parser.antlr.GraphqlParser$OperationDefinitionContext);
    void exitOperationDefinition(graphql.parser.antlr.GraphqlParser$OperationDefinitionContext);
    void enterVariableDefinitions(graphql.parser.antlr.GraphqlParser$VariableDefinitionsContext);
    void exitVariableDefinitions(graphql.parser.antlr.GraphqlParser$VariableDefinitionsContext);
    void enterVariableDefinition(graphql.parser.antlr.GraphqlParser$VariableDefinitionContext);
    void exitVariableDefinition(graphql.parser.antlr.GraphqlParser$VariableDefinitionContext);
    void enterSelectionSet(graphql.parser.antlr.GraphqlParser$SelectionSetContext);
    void exitSelectionSet(graphql.parser.antlr.GraphqlParser$SelectionSetContext);
    void enterSelection(graphql.parser.antlr.GraphqlParser$SelectionContext);
    void exitSelection(graphql.parser.antlr.GraphqlParser$SelectionContext);
    void enterField(graphql.parser.antlr.GraphqlParser$FieldContext);
    void exitField(graphql.parser.antlr.GraphqlParser$FieldContext);
    void enterAlias(graphql.parser.antlr.GraphqlParser$AliasContext);
    void exitAlias(graphql.parser.antlr.GraphqlParser$AliasContext);
    void enterFragmentSpread(graphql.parser.antlr.GraphqlParser$FragmentSpreadContext);
    void exitFragmentSpread(graphql.parser.antlr.GraphqlParser$FragmentSpreadContext);
    void enterInlineFragment(graphql.parser.antlr.GraphqlParser$InlineFragmentContext);
    void exitInlineFragment(graphql.parser.antlr.GraphqlParser$InlineFragmentContext);
    void enterFragmentDefinition(graphql.parser.antlr.GraphqlParser$FragmentDefinitionContext);
    void exitFragmentDefinition(graphql.parser.antlr.GraphqlParser$FragmentDefinitionContext);
    void enterTypeCondition(graphql.parser.antlr.GraphqlParser$TypeConditionContext);
    void exitTypeCondition(graphql.parser.antlr.GraphqlParser$TypeConditionContext);
```

### `GraphqlVisitor`（75 方法） extends ParseTreeVisitor<T>

`graphql.parser.antlr.GraphqlVisitor`

```java
    T visitDocument(graphql.parser.antlr.GraphqlParser$DocumentContext);
    T visitDefinition(graphql.parser.antlr.GraphqlParser$DefinitionContext);
    T visitTypeSystemDefinition(graphql.parser.antlr.GraphqlParser$TypeSystemDefinitionContext);
    T visitTypeSystemExtension(graphql.parser.antlr.GraphqlParser$TypeSystemExtensionContext);
    T visitSchemaDefinition(graphql.parser.antlr.GraphqlParser$SchemaDefinitionContext);
    T visitSchemaExtension(graphql.parser.antlr.GraphqlParser$SchemaExtensionContext);
    T visitOperationTypeDefinition(graphql.parser.antlr.GraphqlParser$OperationTypeDefinitionContext);
    T visitTypeDefinition(graphql.parser.antlr.GraphqlParser$TypeDefinitionContext);
    T visitTypeExtension(graphql.parser.antlr.GraphqlParser$TypeExtensionContext);
    T visitEmptyParentheses(graphql.parser.antlr.GraphqlParser$EmptyParenthesesContext);
    T visitScalarTypeDefinition(graphql.parser.antlr.GraphqlParser$ScalarTypeDefinitionContext);
    T visitScalarTypeExtensionDefinition(graphql.parser.antlr.GraphqlParser$ScalarTypeExtensionDefinitionContext);
    T visitObjectTypeDefinition(graphql.parser.antlr.GraphqlParser$ObjectTypeDefinitionContext);
    T visitObjectTypeExtensionDefinition(graphql.parser.antlr.GraphqlParser$ObjectTypeExtensionDefinitionContext);
    T visitImplementsInterfaces(graphql.parser.antlr.GraphqlParser$ImplementsInterfacesContext);
    T visitFieldsDefinition(graphql.parser.antlr.GraphqlParser$FieldsDefinitionContext);
    T visitExtensionFieldsDefinition(graphql.parser.antlr.GraphqlParser$ExtensionFieldsDefinitionContext);
    T visitFieldDefinition(graphql.parser.antlr.GraphqlParser$FieldDefinitionContext);
    T visitArgumentsDefinition(graphql.parser.antlr.GraphqlParser$ArgumentsDefinitionContext);
    T visitInputValueDefinition(graphql.parser.antlr.GraphqlParser$InputValueDefinitionContext);
    T visitInterfaceTypeDefinition(graphql.parser.antlr.GraphqlParser$InterfaceTypeDefinitionContext);
    T visitInterfaceTypeExtensionDefinition(graphql.parser.antlr.GraphqlParser$InterfaceTypeExtensionDefinitionContext);
    T visitUnionTypeDefinition(graphql.parser.antlr.GraphqlParser$UnionTypeDefinitionContext);
    T visitUnionTypeExtensionDefinition(graphql.parser.antlr.GraphqlParser$UnionTypeExtensionDefinitionContext);
    T visitUnionMembership(graphql.parser.antlr.GraphqlParser$UnionMembershipContext);
    T visitUnionMembers(graphql.parser.antlr.GraphqlParser$UnionMembersContext);
    T visitEnumTypeDefinition(graphql.parser.antlr.GraphqlParser$EnumTypeDefinitionContext);
    T visitEnumTypeExtensionDefinition(graphql.parser.antlr.GraphqlParser$EnumTypeExtensionDefinitionContext);
    T visitEnumValueDefinitions(graphql.parser.antlr.GraphqlParser$EnumValueDefinitionsContext);
    T visitExtensionEnumValueDefinitions(graphql.parser.antlr.GraphqlParser$ExtensionEnumValueDefinitionsContext);
    T visitEnumValueDefinition(graphql.parser.antlr.GraphqlParser$EnumValueDefinitionContext);
    T visitInputObjectTypeDefinition(graphql.parser.antlr.GraphqlParser$InputObjectTypeDefinitionContext);
    T visitInputObjectTypeExtensionDefinition(graphql.parser.antlr.GraphqlParser$InputObjectTypeExtensionDefinitionContext);
    T visitInputObjectValueDefinitions(graphql.parser.antlr.GraphqlParser$InputObjectValueDefinitionsContext);
    T visitExtensionInputObjectValueDefinitions(graphql.parser.antlr.GraphqlParser$ExtensionInputObjectValueDefinitionsContext);
    T visitDirectiveDefinition(graphql.parser.antlr.GraphqlParser$DirectiveDefinitionContext);
    T visitDirectiveLocation(graphql.parser.antlr.GraphqlParser$DirectiveLocationContext);
    T visitDirectiveLocations(graphql.parser.antlr.GraphqlParser$DirectiveLocationsContext);
    T visitOperationType(graphql.parser.antlr.GraphqlParser$OperationTypeContext);
    T visitDescription(graphql.parser.antlr.GraphqlParser$DescriptionContext);
    T visitEnumValue(graphql.parser.antlr.GraphqlParser$EnumValueContext);
    T visitArrayValue(graphql.parser.antlr.GraphqlParser$ArrayValueContext);
    T visitArrayValueWithVariable(graphql.parser.antlr.GraphqlParser$ArrayValueWithVariableContext);
    T visitObjectValue(graphql.parser.antlr.GraphqlParser$ObjectValueContext);
    T visitObjectValueWithVariable(graphql.parser.antlr.GraphqlParser$ObjectValueWithVariableContext);
    T visitObjectField(graphql.parser.antlr.GraphqlParser$ObjectFieldContext);
    T visitObjectFieldWithVariable(graphql.parser.antlr.GraphqlParser$ObjectFieldWithVariableContext);
    T visitDirectives(graphql.parser.antlr.GraphqlParser$DirectivesContext);
    T visitDirective(graphql.parser.antlr.GraphqlParser$DirectiveContext);
    T visitArguments(graphql.parser.antlr.GraphqlParser$ArgumentsContext);
    T visitArgument(graphql.parser.antlr.GraphqlParser$ArgumentContext);
    T visitBaseName(graphql.parser.antlr.GraphqlParser$BaseNameContext);
    T visitFragmentName(graphql.parser.antlr.GraphqlParser$FragmentNameContext);
    T visitEnumValueName(graphql.parser.antlr.GraphqlParser$EnumValueNameContext);
    T visitName(graphql.parser.antlr.GraphqlParser$NameContext);
    T visitValue(graphql.parser.antlr.GraphqlParser$ValueContext);
    T visitValueWithVariable(graphql.parser.antlr.GraphqlParser$ValueWithVariableContext);
    T visitVariable(graphql.parser.antlr.GraphqlParser$VariableContext);
    T visitDefaultValue(graphql.parser.antlr.GraphqlParser$DefaultValueContext);
    T visitStringValue(graphql.parser.antlr.GraphqlParser$StringValueContext);
    T visitType(graphql.parser.antlr.GraphqlParser$TypeContext);
    T visitTypeName(graphql.parser.antlr.GraphqlParser$TypeNameContext);
    T visitListType(graphql.parser.antlr.GraphqlParser$ListTypeContext);
    T visitNonNullType(graphql.parser.antlr.GraphqlParser$NonNullTypeContext);
    T visitOperationDefinition(graphql.parser.antlr.GraphqlParser$OperationDefinitionContext);
    T visitVariableDefinitions(graphql.parser.antlr.GraphqlParser$VariableDefinitionsContext);
    T visitVariableDefinition(graphql.parser.antlr.GraphqlParser$VariableDefinitionContext);
    T visitSelectionSet(graphql.parser.antlr.GraphqlParser$SelectionSetContext);
    T visitSelection(graphql.parser.antlr.GraphqlParser$SelectionContext);
    T visitField(graphql.parser.antlr.GraphqlParser$FieldContext);
    T visitAlias(graphql.parser.antlr.GraphqlParser$AliasContext);
    T visitFragmentSpread(graphql.parser.antlr.GraphqlParser$FragmentSpreadContext);
    T visitInlineFragment(graphql.parser.antlr.GraphqlParser$InlineFragmentContext);
    T visitFragmentDefinition(graphql.parser.antlr.GraphqlParser$FragmentDefinitionContext);
    T visitTypeCondition(graphql.parser.antlr.GraphqlParser$TypeConditionContext);
```

### `NodeVisitor`（36 方法）

`graphql.language.NodeVisitor`

```java
    graphql.util.TraversalControl visitArgument(graphql.language.Argument, graphql.util.TraverserContext<graphql.language.Node>);
    graphql.util.TraversalControl visitArrayValue(graphql.language.ArrayValue, graphql.util.TraverserContext<graphql.language.Node>);
    graphql.util.TraversalControl visitBooleanValue(graphql.language.BooleanValue, graphql.util.TraverserContext<graphql.language.Node>);
    graphql.util.TraversalControl visitDirective(graphql.language.Directive, graphql.util.TraverserContext<graphql.language.Node>);
    graphql.util.TraversalControl visitDirectiveDefinition(graphql.language.DirectiveDefinition, graphql.util.TraverserContext<graphql.language.Node>);
    graphql.util.TraversalControl visitDirectiveLocation(graphql.language.DirectiveLocation, graphql.util.TraverserContext<graphql.language.Node>);
    graphql.util.TraversalControl visitDocument(graphql.language.Document, graphql.util.TraverserContext<graphql.language.Node>);
    graphql.util.TraversalControl visitEnumTypeDefinition(graphql.language.EnumTypeDefinition, graphql.util.TraverserContext<graphql.language.Node>);
    graphql.util.TraversalControl visitEnumValue(graphql.language.EnumValue, graphql.util.TraverserContext<graphql.language.Node>);
    graphql.util.TraversalControl visitEnumValueDefinition(graphql.language.EnumValueDefinition, graphql.util.TraverserContext<graphql.language.Node>);
    graphql.util.TraversalControl visitField(graphql.language.Field, graphql.util.TraverserContext<graphql.language.Node>);
    graphql.util.TraversalControl visitFieldDefinition(graphql.language.FieldDefinition, graphql.util.TraverserContext<graphql.language.Node>);
    graphql.util.TraversalControl visitFloatValue(graphql.language.FloatValue, graphql.util.TraverserContext<graphql.language.Node>);
    graphql.util.TraversalControl visitFragmentDefinition(graphql.language.FragmentDefinition, graphql.util.TraverserContext<graphql.language.Node>);
    graphql.util.TraversalControl visitFragmentSpread(graphql.language.FragmentSpread, graphql.util.TraverserContext<graphql.language.Node>);
    graphql.util.TraversalControl visitInlineFragment(graphql.language.InlineFragment, graphql.util.TraverserContext<graphql.language.Node>);
    graphql.util.TraversalControl visitInputObjectTypeDefinition(graphql.language.InputObjectTypeDefinition, graphql.util.TraverserContext<graphql.language.Node>);
    graphql.util.TraversalControl visitInputValueDefinition(graphql.language.InputValueDefinition, graphql.util.TraverserContext<graphql.language.Node>);
    graphql.util.TraversalControl visitIntValue(graphql.language.IntValue, graphql.util.TraverserContext<graphql.language.Node>);
    graphql.util.TraversalControl visitInterfaceTypeDefinition(graphql.language.InterfaceTypeDefinition, graphql.util.TraverserContext<graphql.language.Node>);
    graphql.util.TraversalControl visitListType(graphql.language.ListType, graphql.util.TraverserContext<graphql.language.Node>);
    graphql.util.TraversalControl visitNonNullType(graphql.language.NonNullType, graphql.util.TraverserContext<graphql.language.Node>);
    graphql.util.TraversalControl visitNullValue(graphql.language.NullValue, graphql.util.TraverserContext<graphql.language.Node>);
    graphql.util.TraversalControl visitObjectField(graphql.language.ObjectField, graphql.util.TraverserContext<graphql.language.Node>);
    graphql.util.TraversalControl visitObjectTypeDefinition(graphql.language.ObjectTypeDefinition, graphql.util.TraverserContext<graphql.language.Node>);
    graphql.util.TraversalControl visitObjectValue(graphql.language.ObjectValue, graphql.util.TraverserContext<graphql.language.Node>);
    graphql.util.TraversalControl visitOperationDefinition(graphql.language.OperationDefinition, graphql.util.TraverserContext<graphql.language.Node>);
    graphql.util.TraversalControl visitOperationTypeDefinition(graphql.language.OperationTypeDefinition, graphql.util.TraverserContext<graphql.language.Node>);
    graphql.util.TraversalControl visitScalarTypeDefinition(graphql.language.ScalarTypeDefinition, graphql.util.TraverserContext<graphql.language.Node>);
    graphql.util.TraversalControl visitSchemaDefinition(graphql.language.SchemaDefinition, graphql.util.TraverserContext<graphql.language.Node>);
    graphql.util.TraversalControl visitSelectionSet(graphql.language.SelectionSet, graphql.util.TraverserContext<graphql.language.Node>);
    graphql.util.TraversalControl visitStringValue(graphql.language.StringValue, graphql.util.TraverserContext<graphql.language.Node>);
    graphql.util.TraversalControl visitTypeName(graphql.language.TypeName, graphql.util.TraverserContext<graphql.language.Node>);
    graphql.util.TraversalControl visitUnionTypeDefinition(graphql.language.UnionTypeDefinition, graphql.util.TraverserContext<graphql.language.Node>);
    graphql.util.TraversalControl visitVariableDefinition(graphql.language.VariableDefinition, graphql.util.TraverserContext<graphql.language.Node>);
    graphql.util.TraversalControl visitVariableReference(graphql.language.VariableReference, graphql.util.TraverserContext<graphql.language.Node>);
```

### `DataFetchingEnvironment`（27 方法）

`graphql.schema.DataFetchingEnvironment`

```java
    <T> T getSource();
    java.util.Map<java.lang.String, java.lang.Object> getArguments();
    boolean containsArgument(java.lang.String);
    <T> T getArgument(java.lang.String);
    <T> T getArgumentOrDefault(java.lang.String, T);
    <T> T getContext();
    <T> T getLocalContext();
    <T> T getRoot();
    graphql.schema.GraphQLFieldDefinition getFieldDefinition();
    java.util.List<graphql.language.Field> getFields();
    graphql.execution.MergedField getMergedField();
    graphql.language.Field getField();
    graphql.schema.GraphQLOutputType getFieldType();
    graphql.execution.ExecutionStepInfo getExecutionStepInfo();
    graphql.schema.GraphQLType getParentType();
    graphql.schema.GraphQLSchema getGraphQLSchema();
    java.util.Map<java.lang.String, graphql.language.FragmentDefinition> getFragmentsByName();
    graphql.execution.ExecutionId getExecutionId();
    graphql.schema.DataFetchingFieldSelectionSet getSelectionSet();
    graphql.execution.directives.QueryDirectives getQueryDirectives();
    <K, V> org.dataloader.DataLoader<K, V> getDataLoader(java.lang.String);
    org.dataloader.DataLoaderRegistry getDataLoaderRegistry();
    graphql.cachecontrol.CacheControl getCacheControl();
    java.util.Locale getLocale();
    graphql.language.OperationDefinition getOperationDefinition();
    graphql.language.Document getDocument();
    java.util.Map<java.lang.String, java.lang.Object> getVariables();
```

### `GraphQLTypeVisitor`（24 方法）

`graphql.schema.GraphQLTypeVisitor`

```java
    graphql.util.TraversalControl visitGraphQLArgument(graphql.schema.GraphQLArgument, graphql.util.TraverserContext<graphql.schema.GraphQLSchemaElement>);
    graphql.util.TraversalControl visitGraphQLInterfaceType(graphql.schema.GraphQLInterfaceType, graphql.util.TraverserContext<graphql.schema.GraphQLSchemaElement>);
    graphql.util.TraversalControl visitGraphQLEnumType(graphql.schema.GraphQLEnumType, graphql.util.TraverserContext<graphql.schema.GraphQLSchemaElement>);
    graphql.util.TraversalControl visitGraphQLEnumValueDefinition(graphql.schema.GraphQLEnumValueDefinition, graphql.util.TraverserContext<graphql.schema.GraphQLSchemaElement>);
    graphql.util.TraversalControl visitGraphQLFieldDefinition(graphql.schema.GraphQLFieldDefinition, graphql.util.TraverserContext<graphql.schema.GraphQLSchemaElement>);
    graphql.util.TraversalControl visitGraphQLDirective(graphql.schema.GraphQLDirective, graphql.util.TraverserContext<graphql.schema.GraphQLSchemaElement>);
    graphql.util.TraversalControl visitGraphQLInputObjectField(graphql.schema.GraphQLInputObjectField, graphql.util.TraverserContext<graphql.schema.GraphQLSchemaElement>);
    graphql.util.TraversalControl visitGraphQLInputObjectType(graphql.schema.GraphQLInputObjectType, graphql.util.TraverserContext<graphql.schema.GraphQLSchemaElement>);
    graphql.util.TraversalControl visitGraphQLList(graphql.schema.GraphQLList, graphql.util.TraverserContext<graphql.schema.GraphQLSchemaElement>);
    graphql.util.TraversalControl visitGraphQLNonNull(graphql.schema.GraphQLNonNull, graphql.util.TraverserContext<graphql.schema.GraphQLSchemaElement>);
    graphql.util.TraversalControl visitGraphQLObjectType(graphql.schema.GraphQLObjectType, graphql.util.TraverserContext<graphql.schema.GraphQLSchemaElement>);
    graphql.util.TraversalControl visitGraphQLScalarType(graphql.schema.GraphQLScalarType, graphql.util.TraverserContext<graphql.schema.GraphQLSchemaElement>);
    graphql.util.TraversalControl visitGraphQLTypeReference(graphql.schema.GraphQLTypeReference, graphql.util.TraverserContext<graphql.schema.GraphQLSchemaElement>);
    graphql.util.TraversalControl visitGraphQLUnionType(graphql.schema.GraphQLUnionType, graphql.util.TraverserContext<graphql.schema.GraphQLSchemaElement>);
    default graphql.util.TraversalControl visitBackRef(graphql.util.TraverserContext<graphql.schema.GraphQLSchemaElement>);
    default graphql.util.TraversalControl visitGraphQLModifiedType(graphql.schema.GraphQLModifiedType, graphql.util.TraverserContext<graphql.schema.GraphQLSchemaElement>);
    default graphql.util.TraversalControl visitGraphQLCompositeType(graphql.schema.GraphQLCompositeType, graphql.util.TraverserContext<graphql.schema.GraphQLSchemaElement>);
    default graphql.util.TraversalControl visitGraphQLDirectiveContainer(graphql.schema.GraphQLDirectiveContainer, graphql.util.TraverserContext<graphql.schema.GraphQLSchemaElement>);
    default graphql.util.TraversalControl visitGraphQLFieldsContainer(graphql.schema.GraphQLFieldsContainer, graphql.util.TraverserContext<graphql.schema.GraphQLSchemaElement>);
    default graphql.util.TraversalControl visitGraphQLInputFieldsContainer(graphql.schema.GraphQLInputFieldsContainer, graphql.util.TraverserContext<graphql.schema.GraphQLSchemaElement>);
    default graphql.util.TraversalControl visitGraphQLInputType(graphql.schema.GraphQLInputType, graphql.util.TraverserContext<graphql.schema.GraphQLSchemaElement>);
    default graphql.util.TraversalControl visitGraphQLNullableType(graphql.schema.GraphQLNullableType, graphql.util.TraverserContext<graphql.schema.GraphQLSchemaElement>);
    default graphql.util.TraversalControl visitGraphQLOutputType(graphql.schema.GraphQLOutputType, graphql.util.TraverserContext<graphql.schema.GraphQLSchemaElement>);
    default graphql.util.TraversalControl visitGraphQLUnmodifiedType(graphql.schema.GraphQLUnmodifiedType, graphql.util.TraverserContext<graphql.schema.GraphQLSchemaElement>);
```

### `TraverserContext`（24 方法）

`graphql.util.TraverserContext`

```java
    T thisNode();
    T originalThisNode();
    void changeNode(T);
    void deleteNode();
    boolean isDeleted();
    boolean isChanged();
    graphql.util.TraverserContext<T> getParentContext();
    java.util.List<T> getParentNodes();
    T getParentNode();
    java.util.List<graphql.util.Breadcrumb<T>> getBreadcrumbs();
    graphql.util.NodeLocation getLocation();
    boolean isVisited();
    java.util.Set<T> visitedNodes();
    <S> S getVar(java.lang.Class<? super S>);
    <S> S getVarFromParents(java.lang.Class<? super S>);
    <S> graphql.util.TraverserContext<T> setVar(java.lang.Class<? super S>, S);
    void setAccumulate(java.lang.Object);
    <U> U getNewAccumulate();
    <U> U getCurrentAccumulate();
    <U> U getSharedContextData();
    boolean isRootContext();
    java.util.Map<java.lang.String, java.util.List<graphql.util.TraverserContext<T>>> getChildrenContexts();
    graphql.util.TraverserContext$Phase getPhase();
    boolean isParallel();
```

### `Instrumentation`（19 方法）

`graphql.execution.instrumentation.Instrumentation`

```java
    default graphql.execution.instrumentation.InstrumentationState createState();
    default graphql.execution.instrumentation.InstrumentationState createState(graphql.execution.instrumentation.parameters.InstrumentationCreateStateParameters);
    graphql.execution.instrumentation.InstrumentationContext<graphql.ExecutionResult> beginExecution(graphql.execution.instrumentation.parameters.InstrumentationExecutionParameters);
    graphql.execution.instrumentation.InstrumentationContext<graphql.language.Document> beginParse(graphql.execution.instrumentation.parameters.InstrumentationExecutionParameters);
    graphql.execution.instrumentation.InstrumentationContext<java.util.List<graphql.validation.ValidationError>> beginValidation(graphql.execution.instrumentation.parameters.InstrumentationValidationParameters);
    graphql.execution.instrumentation.InstrumentationContext<graphql.ExecutionResult> beginExecuteOperation(graphql.execution.instrumentation.parameters.InstrumentationExecuteOperationParameters);
    graphql.execution.instrumentation.ExecutionStrategyInstrumentationContext beginExecutionStrategy(graphql.execution.instrumentation.parameters.InstrumentationExecutionStrategyParameters);
    graphql.execution.instrumentation.DeferredFieldInstrumentationContext beginDeferredField(graphql.execution.instrumentation.parameters.InstrumentationDeferredFieldParameters);
    default graphql.execution.instrumentation.InstrumentationContext<graphql.ExecutionResult> beginSubscribedFieldEvent(graphql.execution.instrumentation.parameters.InstrumentationFieldParameters);
    graphql.execution.instrumentation.InstrumentationContext<graphql.ExecutionResult> beginField(graphql.execution.instrumentation.parameters.InstrumentationFieldParameters);
    graphql.execution.instrumentation.InstrumentationContext<java.lang.Object> beginFieldFetch(graphql.execution.instrumentation.parameters.InstrumentationFieldFetchParameters);
    default graphql.execution.instrumentation.InstrumentationContext<graphql.ExecutionResult> beginFieldComplete(graphql.execution.instrumentation.parameters.InstrumentationFieldCompleteParameters);
    default graphql.execution.instrumentation.InstrumentationContext<graphql.ExecutionResult> beginFieldListComplete(graphql.execution.instrumentation.parameters.InstrumentationFieldCompleteParameters);
    default graphql.ExecutionInput instrumentExecutionInput(graphql.ExecutionInput, graphql.execution.instrumentation.parameters.InstrumentationExecutionParameters);
    default graphql.execution.instrumentation.DocumentAndVariables instrumentDocumentAndVariables(graphql.execution.instrumentation.DocumentAndVariables, graphql.execution.instrumentation.parameters.InstrumentationExecutionParameters);
    default graphql.schema.GraphQLSchema instrumentSchema(graphql.schema.GraphQLSchema, graphql.execution.instrumentation.parameters.InstrumentationExecutionParameters);
    default graphql.execution.ExecutionContext instrumentExecutionContext(graphql.execution.ExecutionContext, graphql.execution.instrumentation.parameters.InstrumentationExecutionParameters);
    default graphql.schema.DataFetcher<?> instrumentDataFetcher(graphql.schema.DataFetcher<?>, graphql.execution.instrumentation.parameters.InstrumentationFieldFetchParameters);
    default java.util.concurrent.CompletableFuture<graphql.ExecutionResult> instrumentExecutionResult(graphql.ExecutionResult, graphql.execution.instrumentation.parameters.InstrumentationExecutionParameters);
```

### `SchemaDirectiveWiringEnvironment`（14 方法） extends GraphQLDirectiveContainer>

`graphql.schema.idl.SchemaDirectiveWiringEnvironment`

```java
    T getElement();
    graphql.schema.GraphQLDirective getDirective();
    java.util.Map<java.lang.String, graphql.schema.GraphQLDirective> getDirectives();
    graphql.schema.GraphQLDirective getDirective(java.lang.String);
    boolean containsDirective(java.lang.String);
    graphql.language.NodeParentTree<graphql.language.NamedNode> getNodeParentTree();
    graphql.schema.GraphqlElementParentTree getElementParentTree();
    graphql.schema.idl.TypeDefinitionRegistry getRegistry();
    java.util.Map<java.lang.String, java.lang.Object> getBuildContext();
    graphql.schema.GraphQLCodeRegistry$Builder getCodeRegistry();
    graphql.schema.GraphQLFieldsContainer getFieldsContainer();
    graphql.schema.GraphQLFieldDefinition getFieldDefinition();
    graphql.schema.DataFetcher getFieldDataFetcher();
    graphql.schema.GraphQLFieldDefinition setFieldDataFetcher(graphql.schema.DataFetcher);
```

### `IntSet`（13 方法）

`antlr.v4.runtime.misc.IntSet`

```java
    void add(int);
    antlr.v4.runtime.misc.IntSet addAll(antlr.v4.runtime.misc.IntSet);
    antlr.v4.runtime.misc.IntSet and(antlr.v4.runtime.misc.IntSet);
    antlr.v4.runtime.misc.IntSet complement(antlr.v4.runtime.misc.IntSet);
    antlr.v4.runtime.misc.IntSet or(antlr.v4.runtime.misc.IntSet);
    antlr.v4.runtime.misc.IntSet subtract(antlr.v4.runtime.misc.IntSet);
    int size();
    boolean isNil();
    boolean equals(java.lang.Object);
    boolean contains(int);
    void remove(int);
    java.util.List<java.lang.Integer> toList();
    java.lang.String toString();
```

### `WiringFactory`（13 方法）

`graphql.schema.idl.WiringFactory`

```java
    default boolean providesScalar(graphql.schema.idl.ScalarWiringEnvironment);
    default graphql.schema.GraphQLScalarType getScalar(graphql.schema.idl.ScalarWiringEnvironment);
    default boolean providesTypeResolver(graphql.schema.idl.InterfaceWiringEnvironment);
    default graphql.schema.TypeResolver getTypeResolver(graphql.schema.idl.InterfaceWiringEnvironment);
    default boolean providesTypeResolver(graphql.schema.idl.UnionWiringEnvironment);
    default graphql.schema.TypeResolver getTypeResolver(graphql.schema.idl.UnionWiringEnvironment);
    default boolean providesDataFetcherFactory(graphql.schema.idl.FieldWiringEnvironment);
    default <T> graphql.schema.DataFetcherFactory<T> getDataFetcherFactory(graphql.schema.idl.FieldWiringEnvironment);
    default boolean providesSchemaDirectiveWiring(graphql.schema.idl.SchemaDirectiveWiringEnvironment);
    default graphql.schema.idl.SchemaDirectiveWiring getSchemaDirectiveWiring(graphql.schema.idl.SchemaDirectiveWiringEnvironment);
    default boolean providesDataFetcher(graphql.schema.idl.FieldWiringEnvironment);
    default graphql.schema.DataFetcher getDataFetcher(graphql.schema.idl.FieldWiringEnvironment);
    default graphql.schema.DataFetcher getDefaultDataFetcher(graphql.schema.idl.FieldWiringEnvironment);
```

### `Token`（10 方法）

`antlr.v4.runtime.Token`

```java
    java.lang.String getText();
    int getType();
    int getLine();
    int getCharPositionInLine();
    int getChannel();
    int getTokenIndex();
    int getStartIndex();
    int getStopIndex();
    antlr.v4.runtime.TokenSource getTokenSource();
    antlr.v4.runtime.CharStream getInputStream();
```

### `QueryVisitorFieldEnvironment`（10 方法）

`graphql.analysis.QueryVisitorFieldEnvironment`

```java
    graphql.schema.GraphQLSchema getSchema();
    boolean isTypeNameIntrospectionField();
    graphql.language.Field getField();
    graphql.schema.GraphQLFieldDefinition getFieldDefinition();
    graphql.schema.GraphQLOutputType getParentType();
    graphql.schema.GraphQLFieldsContainer getFieldsContainer();
    graphql.analysis.QueryVisitorFieldEnvironment getParentEnvironment();
    java.util.Map<java.lang.String, java.lang.Object> getArguments();
    graphql.language.SelectionSetContainer getSelectionSetContainer();
    graphql.util.TraverserContext<graphql.language.Node> getTraverserContext();
```

### `Node`（10 方法） extends Serializable

`graphql.language.Node`

```java
    java.util.List<graphql.language.Node> getChildren();
    graphql.language.NodeChildrenContainer getNamedChildren();
    T withNewChildren(graphql.language.NodeChildrenContainer);
    graphql.language.SourceLocation getSourceLocation();
    java.util.List<graphql.language.Comment> getComments();
    graphql.language.IgnoredChars getIgnoredChars();
    java.util.Map<java.lang.String, java.lang.String> getAdditionalData();
    boolean isEqualTo(graphql.language.Node);
    T deepCopy();
    graphql.util.TraversalControl accept(graphql.util.TraverserContext<graphql.language.Node>, graphql.language.NodeVisitor);
```

### `DataFetchingFieldSelectionSet`（10 方法） extends MergedSelectionSet>

`graphql.schema.DataFetchingFieldSelectionSet`

```java
    graphql.execution.MergedSelectionSet get();
    java.util.Map<java.lang.String, java.util.Map<java.lang.String, java.lang.Object>> getArguments();
    java.util.Map<java.lang.String, graphql.schema.GraphQLFieldDefinition> getDefinitions();
    boolean contains(java.lang.String);
    boolean containsAnyOf(java.lang.String, java.lang.String...);
    boolean containsAllOf(java.lang.String, java.lang.String...);
    java.util.List<graphql.schema.SelectedField> getFields();
    java.util.List<graphql.schema.SelectedField> getFields(java.lang.String);
    graphql.schema.SelectedField getField(java.lang.String);
    default java.lang.Object get();
```

### `SchemaDirectiveWiring`（10 方法）

`graphql.schema.idl.SchemaDirectiveWiring`

```java
    default graphql.schema.GraphQLObjectType onObject(graphql.schema.idl.SchemaDirectiveWiringEnvironment<graphql.schema.GraphQLObjectType>);
    default graphql.schema.GraphQLFieldDefinition onField(graphql.schema.idl.SchemaDirectiveWiringEnvironment<graphql.schema.GraphQLFieldDefinition>);
    default graphql.schema.GraphQLArgument onArgument(graphql.schema.idl.SchemaDirectiveWiringEnvironment<graphql.schema.GraphQLArgument>);
    default graphql.schema.GraphQLInterfaceType onInterface(graphql.schema.idl.SchemaDirectiveWiringEnvironment<graphql.schema.GraphQLInterfaceType>);
    default graphql.schema.GraphQLUnionType onUnion(graphql.schema.idl.SchemaDirectiveWiringEnvironment<graphql.schema.GraphQLUnionType>);
    default graphql.schema.GraphQLEnumType onEnum(graphql.schema.idl.SchemaDirectiveWiringEnvironment<graphql.schema.GraphQLEnumType>);
    default graphql.schema.GraphQLEnumValueDefinition onEnumValue(graphql.schema.idl.SchemaDirectiveWiringEnvironment<graphql.schema.GraphQLEnumValueDefinition>);
    default graphql.schema.GraphQLScalarType onScalar(graphql.schema.idl.SchemaDirectiveWiringEnvironment<graphql.schema.GraphQLScalarType>);
    default graphql.schema.GraphQLInputObjectType onInputObjectType(graphql.schema.idl.SchemaDirectiveWiringEnvironment<graphql.schema.GraphQLInputObjectType>);
    default graphql.schema.GraphQLInputObjectField onInputObjectField(graphql.schema.idl.SchemaDirectiveWiringEnvironment<graphql.schema.GraphQLInputObjectField>);
```

### `IntStream`（8 方法）

`antlr.v4.runtime.IntStream`

```java
    void consume();
    int LA(int);
    int mark();
    void release(int);
    int index();
    void seek(int);
    int size();
    java.lang.String getSourceName();
```

### `ParseTree`（8 方法） extends SyntaxTree

`antlr.v4.runtime.tree.ParseTree`

```java
    antlr.v4.runtime.tree.ParseTree getParent();
    antlr.v4.runtime.tree.ParseTree getChild(int);
    void setParent(antlr.v4.runtime.RuleContext);
    <T> T accept(antlr.v4.runtime.tree.ParseTreeVisitor<? extends T>);
    java.lang.String getText();
    java.lang.String toStringTree(antlr.v4.runtime.Parser);
    default antlr.v4.runtime.tree.Tree getChild(int);
    default antlr.v4.runtime.tree.Tree getParent();
```

### `QueryVisitorFieldArgumentEnvironment`（8 方法）

`graphql.analysis.QueryVisitorFieldArgumentEnvironment`

```java
    graphql.schema.GraphQLSchema getSchema();
    graphql.schema.GraphQLFieldDefinition getFieldDefinition();
    graphql.schema.GraphQLArgument getGraphQLArgument();
    graphql.language.Argument getArgument();
    java.lang.Object getArgumentValue();
    java.util.Map<java.lang.String, java.lang.Object> getVariables();
    graphql.analysis.QueryVisitorFieldEnvironment getParentEnvironment();
    graphql.util.TraverserContext<graphql.language.Node> getTraverserContext();
```

### `Instrumentation`（8 方法）

`graphql.execution.instrumentation.nextgen.Instrumentation`

```java
    default graphql.execution.instrumentation.InstrumentationState createState(graphql.execution.instrumentation.nextgen.InstrumentationCreateStateParameters);
    default graphql.ExecutionInput instrumentExecutionInput(graphql.ExecutionInput, graphql.execution.instrumentation.nextgen.InstrumentationExecutionParameters);
    default graphql.execution.instrumentation.DocumentAndVariables instrumentDocumentAndVariables(graphql.execution.instrumentation.DocumentAndVariables, graphql.execution.instrumentation.nextgen.InstrumentationExecutionParameters);
    default graphql.schema.GraphQLSchema instrumentSchema(graphql.schema.GraphQLSchema, graphql.execution.instrumentation.nextgen.InstrumentationExecutionParameters);
    default graphql.ExecutionResult instrumentExecutionResult(graphql.ExecutionResult, graphql.execution.instrumentation.nextgen.InstrumentationExecutionParameters);
    default graphql.execution.instrumentation.InstrumentationContext<graphql.ExecutionResult> beginExecution(graphql.execution.instrumentation.nextgen.InstrumentationExecutionParameters);
    default graphql.execution.instrumentation.InstrumentationContext<graphql.language.Document> beginParse(graphql.execution.instrumentation.nextgen.InstrumentationExecutionParameters);
    default graphql.execution.instrumentation.InstrumentationContext<java.util.List<graphql.validation.ValidationError>> beginValidation(graphql.execution.instrumentation.nextgen.InstrumentationValidationParameters);
```

### `ANTLRErrorStrategy`（7 方法）

`antlr.v4.runtime.ANTLRErrorStrategy`

```java
    void reset(antlr.v4.runtime.Parser);
    antlr.v4.runtime.Token recoverInline(antlr.v4.runtime.Parser)
    void recover(antlr.v4.runtime.Parser, antlr.v4.runtime.RecognitionException)
    void sync(antlr.v4.runtime.Parser)
    boolean inErrorRecoveryMode(antlr.v4.runtime.Parser);
    void reportMatch(antlr.v4.runtime.Parser);
    void reportError(antlr.v4.runtime.Parser, antlr.v4.runtime.RecognitionException);
```

### `TokenSource`（7 方法）

`antlr.v4.runtime.TokenSource`

```java
    antlr.v4.runtime.Token nextToken();
    int getLine();
    int getCharPositionInLine();
    antlr.v4.runtime.CharStream getInputStream();
    java.lang.String getSourceName();
    void setTokenFactory(antlr.v4.runtime.TokenFactory<?>);
    antlr.v4.runtime.TokenFactory<?> getTokenFactory();
```

### `TokenStream`（7 方法） extends IntStream

`antlr.v4.runtime.TokenStream`

```java
    antlr.v4.runtime.Token LT(int);
    antlr.v4.runtime.Token get(int);
    antlr.v4.runtime.TokenSource getTokenSource();
    java.lang.String getText(antlr.v4.runtime.misc.Interval);
    java.lang.String getText();
    java.lang.String getText(antlr.v4.runtime.RuleContext);
    java.lang.String getText(antlr.v4.runtime.Token, antlr.v4.runtime.Token);
```

### `QueryVisitor`（7 方法）

`graphql.analysis.QueryVisitor`

```java
    void visitField(graphql.analysis.QueryVisitorFieldEnvironment);
    default graphql.util.TraversalControl visitFieldWithControl(graphql.analysis.QueryVisitorFieldEnvironment);
    void visitInlineFragment(graphql.analysis.QueryVisitorInlineFragmentEnvironment);
    void visitFragmentSpread(graphql.analysis.QueryVisitorFragmentSpreadEnvironment);
    default void visitFragmentDefinition(graphql.analysis.QueryVisitorFragmentDefinitionEnvironment);
    default graphql.util.TraversalControl visitArgument(graphql.analysis.QueryVisitorFieldArgumentEnvironment);
    default graphql.util.TraversalControl visitArgumentValue(graphql.analysis.QueryVisitorFieldArgumentValueEnvironment);
```

### `FieldAndArguments`（7 方法）

`graphql.execution.instrumentation.fieldvalidation.FieldAndArguments`

```java
    graphql.language.Field getField();
    graphql.schema.GraphQLFieldDefinition getFieldDefinition();
    graphql.schema.GraphQLCompositeType getParentType();
    graphql.execution.instrumentation.fieldvalidation.FieldAndArguments getParentFieldAndArguments();
    graphql.execution.ExecutionPath getPath();
    java.util.Map<java.lang.String, java.lang.Object> getArgumentValuesByName();
    <T> T getArgumentValue(java.lang.String);
```

### `WritableToken`（6 方法） extends Token

`antlr.v4.runtime.WritableToken`

```java
    void setText(java.lang.String);
    void setType(int);
    void setLine(int);
    void setCharPositionInLine(int);
    void setChannel(int);
    void setTokenIndex(int);
```

### `GraphQLError`（6 方法） extends Serializable

`graphql.GraphQLError`

```java
    java.lang.String getMessage();
    java.util.List<graphql.language.SourceLocation> getLocations();
    graphql.ErrorClassification getErrorType();
    default java.util.List<java.lang.Object> getPath();
    default java.util.Map<java.lang.String, java.lang.Object> toSpecification();
    default java.util.Map<java.lang.String, java.lang.Object> getExtensions();
```

### `QueryVisitorFieldArgumentValueEnvironment`（6 方法）

`graphql.analysis.QueryVisitorFieldArgumentValueEnvironment`

```java
    graphql.schema.GraphQLSchema getSchema();
    graphql.schema.GraphQLFieldDefinition getFieldDefinition();
    graphql.schema.GraphQLArgument getGraphQLArgument();
    graphql.analysis.QueryVisitorFieldArgumentInputValue getArgumentInputValue();
    java.util.Map<java.lang.String, java.lang.Object> getVariables();
    graphql.util.TraverserContext<graphql.language.Node> getTraverserContext();
```

### `Tree`（5 方法）

`antlr.v4.runtime.tree.Tree`

```java
    antlr.v4.runtime.tree.Tree getParent();
    java.lang.Object getPayload();
    antlr.v4.runtime.tree.Tree getChild(int);
    int getChildCount();
    java.lang.String toStringTree();
```

### `ExecutionResult`（5 方法）

`graphql.ExecutionResult`

```java
    java.util.List<graphql.GraphQLError> getErrors();
    <T> T getData();
    boolean isDataPresent();
    java.util.Map<java.lang.Object, java.lang.Object> getExtensions();
    java.util.Map<java.lang.String, java.lang.Object> toSpecification();
```

### `QueryVisitorFieldArgumentInputValue`（5 方法）

`graphql.analysis.QueryVisitorFieldArgumentInputValue`

```java
    graphql.analysis.QueryVisitorFieldArgumentInputValue getParent();
    graphql.schema.GraphQLInputValueDefinition getInputValueDefinition();
    java.lang.String getName();
    graphql.schema.GraphQLInputType getInputType();
    graphql.language.Value getValue();
```

### `FieldValidationEnvironment`（5 方法）

`graphql.execution.instrumentation.fieldvalidation.FieldValidationEnvironment`

```java
    graphql.execution.ExecutionContext getExecutionContext();
    java.util.List<graphql.execution.instrumentation.fieldvalidation.FieldAndArguments> getFields();
    java.util.Map<graphql.execution.ExecutionPath, java.util.List<graphql.execution.instrumentation.fieldvalidation.FieldAndArguments>> getFieldsByPath();
    graphql.GraphQLError mkError(java.lang.String);
    graphql.GraphQLError mkError(java.lang.String, graphql.execution.instrumentation.fieldvalidation.FieldAndArguments);
```

### `NodeBuilder`（5 方法）

`graphql.language.NodeBuilder`

```java
    graphql.language.NodeBuilder sourceLocation(graphql.language.SourceLocation);
    graphql.language.NodeBuilder comments(java.util.List<graphql.language.Comment>);
    graphql.language.NodeBuilder ignoredChars(graphql.language.IgnoredChars);
    graphql.language.NodeBuilder additionalData(java.util.Map<java.lang.String, java.lang.String>);
    graphql.language.NodeBuilder additionalData(java.lang.String, java.lang.String);
```

### `SelectedField`（5 方法）

`graphql.schema.SelectedField`

```java
    java.lang.String getName();
    java.lang.String getQualifiedName();
    graphql.schema.GraphQLFieldDefinition getFieldDefinition();
    java.util.Map<java.lang.String, java.lang.Object> getArguments();
    graphql.schema.DataFetchingFieldSelectionSet getSelectionSet();
```

### `ANTLRErrorListener`（4 方法）

`antlr.v4.runtime.ANTLRErrorListener`

```java
    void syntaxError(antlr.v4.runtime.Recognizer<?, ?>, java.lang.Object, int, int, java.lang.String, antlr.v4.runtime.RecognitionException);
    void reportAmbiguity(antlr.v4.runtime.Parser, antlr.v4.runtime.dfa.DFA, int, int, boolean, java.util.BitSet, antlr.v4.runtime.atn.ATNConfigSet);
    void reportAttemptingFullContext(antlr.v4.runtime.Parser, antlr.v4.runtime.dfa.DFA, int, int, java.util.BitSet, antlr.v4.runtime.atn.ATNConfigSet);
    void reportContextSensitivity(antlr.v4.runtime.Parser, antlr.v4.runtime.dfa.DFA, int, int, int, antlr.v4.runtime.atn.ATNConfigSet);
```

### `Vocabulary`（4 方法）

`antlr.v4.runtime.Vocabulary`

```java
    int getMaxTokenType();
    java.lang.String getLiteralName(int);
    java.lang.String getSymbolicName(int);
    java.lang.String getDisplayName(int);
```

### `ParseTreeListener`（4 方法）

`antlr.v4.runtime.tree.ParseTreeListener`

```java
    void visitTerminal(antlr.v4.runtime.tree.TerminalNode);
    void visitErrorNode(antlr.v4.runtime.tree.ErrorNode);
    void enterEveryRule(antlr.v4.runtime.ParserRuleContext);
    void exitEveryRule(antlr.v4.runtime.ParserRuleContext);
```

### `ParseTreeVisitor`（4 方法）

`antlr.v4.runtime.tree.ParseTreeVisitor`

```java
    T visit(antlr.v4.runtime.tree.ParseTree);
    T visitChildren(antlr.v4.runtime.tree.RuleNode);
    T visitTerminal(antlr.v4.runtime.tree.TerminalNode);
    T visitErrorNode(antlr.v4.runtime.tree.ErrorNode);
```

### `QueryVisitorFragmentSpreadEnvironment`（4 方法）

`graphql.analysis.QueryVisitorFragmentSpreadEnvironment`

```java
    graphql.schema.GraphQLSchema getSchema();
    graphql.language.FragmentSpread getFragmentSpread();
    graphql.language.FragmentDefinition getFragmentDefinition();
    graphql.util.TraverserContext<graphql.language.Node> getTraverserContext();
```

### `PageInfo`（4 方法）

`graphql.relay.PageInfo`

```java
    graphql.relay.ConnectionCursor getStartCursor();
    graphql.relay.ConnectionCursor getEndCursor();
    boolean isHasPreviousPage();
    boolean isHasNextPage();
```

### `Coercing`（4 方法）

`graphql.schema.Coercing`

```java
    O serialize(java.lang.Object)
    I parseValue(java.lang.Object)
    I parseLiteral(java.lang.Object)
    default I parseLiteral(java.lang.Object, java.util.Map<java.lang.String, java.lang.Object>)
```

### `GraphQLSchemaElement`（4 方法）

`graphql.schema.GraphQLSchemaElement`

```java
    default java.util.List<graphql.schema.GraphQLSchemaElement> getChildren();
    default graphql.schema.SchemaElementChildrenContainer getChildrenWithTypeReferences();
    default graphql.schema.GraphQLSchemaElement withNewChildren(graphql.schema.SchemaElementChildrenContainer);
    graphql.util.TraversalControl accept(graphql.util.TraverserContext<graphql.schema.GraphQLSchemaElement>, graphql.schema.GraphQLTypeVisitor);
```

### `GraphqlFieldVisibility`（4 方法）

`graphql.schema.visibility.GraphqlFieldVisibility`

```java
    java.util.List<graphql.schema.GraphQLFieldDefinition> getFieldDefinitions(graphql.schema.GraphQLFieldsContainer);
    graphql.schema.GraphQLFieldDefinition getFieldDefinition(graphql.schema.GraphQLFieldsContainer, java.lang.String);
    default java.util.List<graphql.schema.GraphQLInputObjectField> getFieldDefinitions(graphql.schema.GraphQLInputFieldsContainer);
    default graphql.schema.GraphQLInputObjectField getFieldDefinition(graphql.schema.GraphQLInputFieldsContainer, java.lang.String);
```

### `LexerAction`（3 方法）

`antlr.v4.runtime.atn.LexerAction`

```java
    antlr.v4.runtime.atn.LexerActionType getActionType();
    boolean isPositionDependent();
    void execute(antlr.v4.runtime.Lexer);
```

### `QueryVisitorFragmentDefinitionEnvironment`（3 方法）

`graphql.analysis.QueryVisitorFragmentDefinitionEnvironment`

```java
    graphql.schema.GraphQLSchema getSchema();
    graphql.language.FragmentDefinition getFragmentDefinition();
    graphql.util.TraverserContext<graphql.language.Node> getTraverserContext();
```

### `QueryVisitorInlineFragmentEnvironment`（3 方法）

`graphql.analysis.QueryVisitorInlineFragmentEnvironment`

```java
    graphql.schema.GraphQLSchema getSchema();
    graphql.language.InlineFragment getInlineFragment();
    graphql.util.TraverserContext<graphql.language.Node> getTraverserContext();
```

### `QueryDirectives`（3 方法）

`graphql.execution.directives.QueryDirectives`

```java
    java.util.Map<java.lang.String, java.util.List<graphql.schema.GraphQLDirective>> getImmediateDirectivesByName();
    java.util.List<graphql.schema.GraphQLDirective> getImmediateDirective(java.lang.String);
    java.util.Map<graphql.language.Field, java.util.List<graphql.schema.GraphQLDirective>> getImmediateDirectivesByField();
```

### `DirectivesContainer`（3 方法） extends Node<T>

`graphql.language.DirectivesContainer`

```java
    java.util.List<graphql.language.Directive> getDirectives();
    default java.util.Map<java.lang.String, graphql.language.Directive> getDirectivesByName();
    default graphql.language.Directive getDirective(java.lang.String);
```

### `GraphQLDirectiveContainer`（3 方法） extends GraphQLNamedSchemaElement

`graphql.schema.GraphQLDirectiveContainer`

```java
    java.util.List<graphql.schema.GraphQLDirective> getDirectives();
    default java.util.Map<java.lang.String, graphql.schema.GraphQLDirective> getDirectivesByName();
    default graphql.schema.GraphQLDirective getDirective(java.lang.String);
```

### `GraphQLNamedSchemaElement`（3 方法） extends GraphQLSchemaElement

`graphql.schema.GraphQLNamedSchemaElement`

```java
    java.lang.String getName();
    java.lang.String getDescription();
    graphql.language.Node getDefinition();
```

### `NodeAdapter`（3 方法）

`graphql.util.NodeAdapter`

```java
    java.util.Map<java.lang.String, java.util.List<T>> getNamedChildren(T);
    T withNewChildren(T, java.util.Map<java.lang.String, java.util.List<T>>);
    T removeChild(T, graphql.util.NodeLocation);
```

### `TraverserVisitor`（3 方法）

`graphql.util.TraverserVisitor`

```java
    graphql.util.TraversalControl enter(graphql.util.TraverserContext<T>);
    graphql.util.TraversalControl leave(graphql.util.TraverserContext<T>);
    default graphql.util.TraversalControl backRef(graphql.util.TraverserContext<T>);
```

### `TokenFactory`（2 方法） extends Token>

`antlr.v4.runtime.TokenFactory`

```java
    Symbol create(antlr.v4.runtime.misc.Pair<antlr.v4.runtime.TokenSource, antlr.v4.runtime.CharStream>, int, java.lang.String, int, int, int, int, int);
    Symbol create(int, java.lang.String);
```

### `EqualityComparator`（2 方法）

`antlr.v4.runtime.misc.EqualityComparator`

```java
    int hashCode(T);
    boolean equals(T, T);
```

### `ExecutionIdProvider`（2 方法）

`graphql.execution.ExecutionIdProvider`

```java
    graphql.execution.ExecutionId provide(java.lang.String, java.lang.String, java.lang.Object);
```

### `ExecutionStrategyInstrumentationContext`（2 方法） extends ExecutionResult>

`graphql.execution.instrumentation.ExecutionStrategyInstrumentationContext`

```java
    default void onFieldValuesInfo(java.util.List<graphql.execution.FieldValueInfo>);
    default void onDeferredField(graphql.execution.MergedField);
```

### `InstrumentationContext`（2 方法）

`graphql.execution.instrumentation.InstrumentationContext`

```java
    void onDispatched(java.util.concurrent.CompletableFuture<T>);
    void onCompleted(T, java.lang.Throwable);
```

### `ImplementingTypeDefinition`（2 方法） extends TypeDefinition<T>

`graphql.language.ImplementingTypeDefinition`

```java
    java.util.List<graphql.language.Type> getImplements();
    java.util.List<graphql.language.FieldDefinition> getFieldDefinitions();
```

### `Connection`（2 方法）

`graphql.relay.Connection`

```java
    java.util.List<graphql.relay.Edge<T>> getEdges();
    graphql.relay.PageInfo getPageInfo();
```

### `Edge`（2 方法）

`graphql.relay.Edge`

```java
    T getNode();
    graphql.relay.ConnectionCursor getCursor();
```

### `GraphQLFieldsContainer`（2 方法） extends GraphQLCompositeType

`graphql.schema.GraphQLFieldsContainer`

```java
    graphql.schema.GraphQLFieldDefinition getFieldDefinition(java.lang.String);
    java.util.List<graphql.schema.GraphQLFieldDefinition> getFieldDefinitions();
```

### `GraphQLInputFieldsContainer`（2 方法） extends GraphQLNamedType

`graphql.schema.GraphQLInputFieldsContainer`

```java
    graphql.schema.GraphQLInputObjectField getFieldDefinition(java.lang.String);
    java.util.List<graphql.schema.GraphQLInputObjectField> getFieldDefinitions();
```

### `DifferenceReporter`（2 方法）

`graphql.schema.diff.reporting.DifferenceReporter`

```java
    void report(graphql.schema.diff.DiffEvent);
    void onEnd();
```

### `VisibleFieldPredicateEnvironment`（2 方法）

`graphql.schema.transform.VisibleFieldPredicateEnvironment`

```java
    graphql.schema.GraphQLNamedSchemaElement getSchemaElement();
    graphql.schema.GraphQLSchemaElement getParentElement();
```

### `SchemaValidationRule`（2 方法）

`graphql.schema.validation.SchemaValidationRule`

```java
    void check(graphql.schema.GraphQLFieldDefinition, graphql.schema.validation.SchemaValidationErrorCollector);
    void check(graphql.schema.GraphQLType, graphql.schema.validation.SchemaValidationErrorCollector);
```

### `DocumentVisitor`（2 方法）

`graphql.validation.DocumentVisitor`

```java
    void enter(graphql.language.Node, java.util.List<graphql.language.Node>);
    void leave(graphql.language.Node, java.util.List<graphql.language.Node>);
```

### `CharStream`（1 方法） extends IntStream

`antlr.v4.runtime.CharStream`

```java
    java.lang.String getText(antlr.v4.runtime.misc.Interval);
```

### `Predicate`（1 方法）

`antlr.v4.runtime.misc.Predicate`

```java
    boolean test(T);
```

### `RuleNode`（1 方法） extends ParseTree

`antlr.v4.runtime.tree.RuleNode`

```java
    antlr.v4.runtime.RuleContext getRuleContext();
```

### `SyntaxTree`（1 方法） extends Tree

`antlr.v4.runtime.tree.SyntaxTree`

```java
    antlr.v4.runtime.misc.Interval getSourceInterval();
```

### `TerminalNode`（1 方法） extends ParseTree

`antlr.v4.runtime.tree.TerminalNode`

```java
    antlr.v4.runtime.Token getSymbol();
```

### `DynamicSelectByIdsMapper`（1 方法）

`com.seeyon.boot.starter.graphql.domain.mapper.DynamicSelectByIdsMapper`

```java
    java.util.List<java.util.Map<java.lang.String, java.lang.Object>> dynamicSelectByIds(java.lang.String, java.util.Map<java.lang.String, java.lang.Object>);
```

### `DeferredExecutionResult`（1 方法） extends ExecutionResult

`graphql.DeferredExecutionResult`

```java
    java.util.List<java.lang.Object> getPath();
```

### `ErrorClassification`（1 方法）

`graphql.ErrorClassification`

```java
    default java.lang.Object toSpecification(graphql.GraphQLError);
```

### `FieldComplexityCalculator`（1 方法）

`graphql.analysis.FieldComplexityCalculator`

```java
    int calculate(graphql.analysis.FieldComplexityEnvironment, int);
```

### `QueryReducer`（1 方法）

`graphql.analysis.QueryReducer`

```java
    T reduceField(graphql.analysis.QueryVisitorFieldEnvironment, T);
```

### `DataFetcherExceptionHandler`（1 方法）

`graphql.execution.DataFetcherExceptionHandler`

```java
    graphql.execution.DataFetcherExceptionHandlerResult onException(graphql.execution.DataFetcherExceptionHandlerParameters);
```

### `ValueUnboxer`（1 方法）

`graphql.execution.ValueUnboxer`

```java
    java.lang.Object unbox(java.lang.Object);
```

### `DeferredFieldInstrumentationContext`（1 方法） extends ExecutionResult>

`graphql.execution.instrumentation.DeferredFieldInstrumentationContext`

```java
    default void onFieldValueInfo(graphql.execution.FieldValueInfo);
```

### `FieldValidation`（1 方法）

`graphql.execution.instrumentation.fieldvalidation.FieldValidation`

```java
    java.util.List<graphql.GraphQLError> validateFields(graphql.execution.instrumentation.fieldvalidation.FieldValidationEnvironment);
```

### `ExecutionStrategy`（1 方法）

`graphql.execution.nextgen.ExecutionStrategy`

```java
    java.util.concurrent.CompletableFuture<graphql.execution.nextgen.result.RootExecutionResultNode> execute(graphql.execution.ExecutionContext, graphql.execution.nextgen.FieldSubSelection);
```

### `PreparsedDocumentProvider`（1 方法）

`graphql.execution.preparsed.PreparsedDocumentProvider`

```java
    graphql.execution.preparsed.PreparsedDocumentEntry getDocument(graphql.ExecutionInput, java.util.function.Function<graphql.ExecutionInput, graphql.execution.preparsed.PreparsedDocumentEntry>);
```

### `DescribedNode`（1 方法） extends Node<T>

`graphql.language.DescribedNode`

```java
    graphql.language.Description getDescription();
```

### `NamedNode`（1 方法） extends Node<T>

`graphql.language.NamedNode`

```java
    java.lang.String getName();
```

### `NodeDirectivesBuilder`（1 方法） extends NodeBuilder

`graphql.language.NodeDirectivesBuilder`

```java
    graphql.language.NodeDirectivesBuilder directives(java.util.List<graphql.language.Directive>);
```

### `SelectionSetContainer`（1 方法） extends Node<T>

`graphql.language.SelectionSetContainer`

```java
    graphql.language.SelectionSet getSelectionSet();
```

### `ConnectionCursor`（1 方法）

`graphql.relay.ConnectionCursor`

```java
    java.lang.String getValue();
```

### `DataFetcher`（1 方法）

`graphql.schema.DataFetcher`

```java
    T get(graphql.schema.DataFetchingEnvironment)
```

### `DataFetcherFactory`（1 方法）

`graphql.schema.DataFetcherFactory`

```java
    graphql.schema.DataFetcher<T> get(graphql.schema.DataFetcherFactoryEnvironment);
```

### `GraphQLImplementingType`（1 方法） extends GraphQLFieldsContainer

`graphql.schema.GraphQLImplementingType`

```java
    java.util.List<graphql.schema.GraphQLNamedOutputType> getInterfaces();
```

### `GraphQLInputValueDefinition`（1 方法） extends GraphQLDirectiveContainer

`graphql.schema.GraphQLInputValueDefinition`

```java
    <T extends graphql.schema.GraphQLInputType> T getType();
```

### `GraphQLModifiedType`（1 方法） extends GraphQLType

`graphql.schema.GraphQLModifiedType`

```java
    graphql.schema.GraphQLType getWrappedType();
```

### `GraphqlTypeComparatorRegistry`（1 方法）

`graphql.schema.GraphqlTypeComparatorRegistry`

```java
    <T extends graphql.schema.GraphQLSchemaElement> java.util.Comparator<? super T> getComparator(graphql.schema.GraphqlTypeComparatorEnvironment);
```

### `TypeResolver`（1 方法）

`graphql.schema.TypeResolver`

```java
    graphql.schema.GraphQLObjectType getType(graphql.TypeResolutionEnvironment);
```

### `EnumValuesProvider`（1 方法）

`graphql.schema.idl.EnumValuesProvider`

```java
    java.lang.Object getValue(java.lang.String);
```

### `SchemaGeneratorPostProcessing`（1 方法）

`graphql.schema.idl.SchemaGeneratorPostProcessing`

```java
    graphql.schema.GraphQLSchema process(graphql.schema.GraphQLSchema);
```

### `VisibleFieldPredicate`（1 方法）

`graphql.schema.transform.VisibleFieldPredicate`

```java
    boolean isVisible(graphql.schema.transform.VisibleFieldPredicateEnvironment);
```

### `ErrorNode`（0 方法） extends TerminalNode

`antlr.v4.runtime.tree.ErrorNode`

```java
```

### `DynamicSelectByIdsDao`（0 方法）

`com.seeyon.boot.starter.graphql.domain.dao.DynamicSelectByIdsDao`

```java
```

### `TrivialDataFetcher`（0 方法） extends DataFetcher<T>

`graphql.TrivialDataFetcher`

```java
```

### `BatchedDataFetcher`（0 方法） extends DataFetcher

`graphql.execution.batched.BatchedDataFetcher`

```java
```

### `InstrumentationState`（0 方法）

`graphql.execution.instrumentation.InstrumentationState`

```java
```

### `BatchedDataFetcher`（0 方法） extends DataFetcher<T>

`graphql.execution.nextgen.BatchedDataFetcher`

```java
```

### `IntrospectionQuery`（0 方法）

`graphql.introspection.IntrospectionQuery`

```java
```

### `Definition`（0 方法） extends Node<T>

`graphql.language.Definition`

```java
```

### `SDLDefinition`（0 方法） extends Definition<T>

`graphql.language.SDLDefinition`

```java
```

### `ScalarValue`（0 方法） extends Value<T>

`graphql.language.ScalarValue`

```java
```

### `Selection`（0 方法） extends Node<T>

`graphql.language.Selection`

```java
```

### `Type`（0 方法） extends Node<T>

`graphql.language.Type`

```java
```

### `TypeDefinition`（0 方法）

`graphql.language.TypeDefinition`

```java
```

### `Value`（0 方法） extends Node<T>

`graphql.language.Value`

```java
```

### `GraphQLCompositeType`（0 方法） extends GraphQLNamedOutputType

`graphql.schema.GraphQLCompositeType`

```java
```

### `GraphQLInputType`（0 方法） extends GraphQLType

`graphql.schema.GraphQLInputType`

```java
```

### `GraphQLNamedInputType`（0 方法） extends GraphQLInputType, GraphQLNamedType

`graphql.schema.GraphQLNamedInputType`

```java
```

### `GraphQLNamedOutputType`（0 方法） extends GraphQLOutputType, GraphQLNamedType

`graphql.schema.GraphQLNamedOutputType`

```java
```

### `GraphQLNamedType`（0 方法） extends GraphQLType, GraphQLNamedSchemaElement

`graphql.schema.GraphQLNamedType`

```java
```

### `GraphQLNullableType`（0 方法） extends GraphQLType

`graphql.schema.GraphQLNullableType`

```java
```

### `GraphQLOutputType`（0 方法） extends GraphQLType

`graphql.schema.GraphQLOutputType`

```java
```

### `GraphQLType`（0 方法） extends GraphQLSchemaElement

`graphql.schema.GraphQLType`

```java
```

### `GraphQLUnmodifiedType`（0 方法） extends GraphQLNamedType

`graphql.schema.GraphQLUnmodifiedType`

```java
```

## 二、关键类（54）

### `SchemaGeneratorDirectiveHelper`（37 方法）

`graphql.schema.idl.SchemaGeneratorDirectiveHelper`

```java
    private graphql.language.NodeParentTree<graphql.language.NamedNode> buildAstTree(graphql.language.NamedNode...);
    private graphql.schema.GraphqlElementParentTree buildRuntimeTree(graphql.schema.GraphQLSchemaElement...);
    private java.util.List<graphql.schema.GraphQLArgument> wireArguments(graphql.schema.GraphQLFieldDefinition, graphql.schema.GraphQLFieldsContainer, graphql.language.NamedNode, graphql.schema.idl.SchemaGeneratorDirectiveHelper$Parameters, graphql.schema.GraphQLFieldDefinition);
    private java.util.List<graphql.schema.GraphQLFieldDefinition> wireFields(graphql.schema.GraphQLFieldsContainer, graphql.language.NamedNode, graphql.schema.idl.SchemaGeneratorDirectiveHelper$Parameters);
    graphql.schema.GraphQLObjectType onObject(graphql.schema.GraphQLObjectType, graphql.schema.idl.SchemaGeneratorDirectiveHelper$Parameters);
    graphql.schema.GraphQLInterfaceType onInterface(graphql.schema.GraphQLInterfaceType, graphql.schema.idl.SchemaGeneratorDirectiveHelper$Parameters);
    graphql.schema.GraphQLEnumType onEnum(graphql.schema.GraphQLEnumType, graphql.schema.idl.SchemaGeneratorDirectiveHelper$Parameters);
    graphql.schema.GraphQLInputObjectType onInputObjectType(graphql.schema.GraphQLInputObjectType, graphql.schema.idl.SchemaGeneratorDirectiveHelper$Parameters);
    graphql.schema.GraphQLUnionType onUnion(graphql.schema.GraphQLUnionType, graphql.schema.idl.SchemaGeneratorDirectiveHelper$Parameters);
    graphql.schema.GraphQLScalarType onScalar(graphql.schema.GraphQLScalarType, graphql.schema.idl.SchemaGeneratorDirectiveHelper$Parameters);
    private graphql.schema.GraphQLFieldDefinition onField(graphql.schema.GraphQLFieldDefinition, graphql.schema.idl.SchemaGeneratorDirectiveHelper$Parameters);
    private graphql.schema.GraphQLInputObjectField onInputObjectField(graphql.schema.GraphQLInputObjectField, graphql.schema.idl.SchemaGeneratorDirectiveHelper$Parameters);
    private graphql.schema.GraphQLEnumValueDefinition onEnumValue(graphql.schema.GraphQLEnumValueDefinition, graphql.schema.idl.SchemaGeneratorDirectiveHelper$Parameters);
    private graphql.schema.GraphQLArgument onArgument(graphql.schema.GraphQLArgument, graphql.schema.idl.SchemaGeneratorDirectiveHelper$Parameters);
    private <T extends graphql.schema.GraphQLDirectiveContainer> T wireDirectives(graphql.schema.idl.SchemaGeneratorDirectiveHelper$Parameters, T, java.util.List<graphql.schema.GraphQLDirective>, graphql.schema.idl.SchemaGeneratorDirectiveHelper$EnvBuilder<T>, graphql.schema.idl.SchemaGeneratorDirectiveHelper$EnvInvoker<T>);
    private <T extends graphql.schema.GraphQLDirectiveContainer> T invokeWiring(T, graphql.schema.idl.SchemaGeneratorDirectiveHelper$EnvInvoker<T>, graphql.schema.idl.SchemaDirectiveWiring, graphql.schema.idl.SchemaDirectiveWiringEnvironment<T>);
```

### `ATNConfigSet`（28 方法）

`antlr.v4.runtime.atn.ATNConfigSet`

```java
    boolean add(antlr.v4.runtime.atn.ATNConfig);
    boolean add(antlr.v4.runtime.atn.ATNConfig, antlr.v4.runtime.misc.DoubleKeyMap<antlr.v4.runtime.atn.PredictionContext, antlr.v4.runtime.atn.PredictionContext, antlr.v4.runtime.atn.PredictionContext>);
    java.util.List<antlr.v4.runtime.atn.ATNConfig> elements();
    java.util.Set<antlr.v4.runtime.atn.ATNState> getStates();
    java.util.BitSet getAlts();
    java.util.List<antlr.v4.runtime.atn.SemanticContext> getPredicates();
    antlr.v4.runtime.atn.ATNConfig get(int);
    void optimizeConfigs(antlr.v4.runtime.atn.ATNSimulator);
    boolean addAll(java.util.Collection<? extends antlr.v4.runtime.atn.ATNConfig>);
    boolean equals(java.lang.Object);
    int hashCode();
    int size();
    boolean isEmpty();
    boolean contains(java.lang.Object);
    boolean containsFast(antlr.v4.runtime.atn.ATNConfig);
    java.util.Iterator<antlr.v4.runtime.atn.ATNConfig> iterator();
    void clear();
    boolean isReadonly();
    void setReadonly(boolean);
    java.lang.String toString();
    antlr.v4.runtime.atn.ATNConfig[] toArray();
    <T> T[] toArray(T[]);
    boolean remove(java.lang.Object);
    boolean containsAll(java.util.Collection<?>);
    boolean retainAll(java.util.Collection<?>);
    boolean removeAll(java.util.Collection<?>);
    boolean add(java.lang.Object);
    java.lang.Object[] toArray();
```

### `ExecutionContextBuilder`（24 方法）

`graphql.execution.ExecutionContextBuilder`

```java
    static graphql.execution.ExecutionContextBuilder newExecutionContextBuilder();
    static graphql.execution.ExecutionContextBuilder newExecutionContextBuilder(graphql.execution.ExecutionContext);
    graphql.execution.ExecutionContextBuilder instrumentation(graphql.execution.instrumentation.Instrumentation);
    graphql.execution.ExecutionContextBuilder instrumentationState(graphql.execution.instrumentation.InstrumentationState);
    graphql.execution.ExecutionContextBuilder executionId(graphql.execution.ExecutionId);
    graphql.execution.ExecutionContextBuilder graphQLSchema(graphql.schema.GraphQLSchema);
    graphql.execution.ExecutionContextBuilder queryStrategy(graphql.execution.ExecutionStrategy);
    graphql.execution.ExecutionContextBuilder mutationStrategy(graphql.execution.ExecutionStrategy);
    graphql.execution.ExecutionContextBuilder subscriptionStrategy(graphql.execution.ExecutionStrategy);
    graphql.execution.ExecutionContextBuilder context(java.lang.Object);
    graphql.execution.ExecutionContextBuilder localContext(java.lang.Object);
    graphql.execution.ExecutionContextBuilder root(java.lang.Object);
    graphql.execution.ExecutionContextBuilder variables(java.util.Map<java.lang.String, java.lang.Object>);
    graphql.execution.ExecutionContextBuilder fragmentsByName(java.util.Map<java.lang.String, graphql.language.FragmentDefinition>);
    graphql.execution.ExecutionContextBuilder document(graphql.language.Document);
    graphql.execution.ExecutionContextBuilder operationDefinition(graphql.language.OperationDefinition);
    graphql.execution.ExecutionContextBuilder dataLoaderRegistry(org.dataloader.DataLoaderRegistry);
    graphql.execution.ExecutionContextBuilder cacheControl(graphql.cachecontrol.CacheControl);
    graphql.execution.ExecutionContextBuilder locale(java.util.Locale);
    graphql.execution.ExecutionContextBuilder valueUnboxer(graphql.execution.ValueUnboxer);
    graphql.execution.ExecutionContextBuilder executionInput(graphql.ExecutionInput);
    graphql.execution.ExecutionContextBuilder resetErrors();
    graphql.execution.ExecutionContext build();
```

### `SchemaGeneratorHelper`（23 方法）

`graphql.schema.idl.SchemaGeneratorHelper`

```java
    static private static graphql.language.Description createDescription(java.lang.String);
    java.lang.Object buildValue(graphql.language.Value, graphql.schema.GraphQLType);
    private java.lang.Object parseLiteral(graphql.language.Value, graphql.schema.GraphQLScalarType);
    java.lang.Object buildArrayValue(graphql.schema.GraphQLType, graphql.language.ArrayValue);
    java.lang.Object buildObjectValue(graphql.language.ObjectValue, graphql.schema.GraphQLInputObjectType);
    java.lang.String buildDescription(graphql.language.Node<?>, graphql.language.Description);
    java.lang.String buildDeprecationReason(java.util.List<graphql.language.Directive>);
    void addDirectivesIncludedByDefault(graphql.schema.idl.TypeDefinitionRegistry);
    graphql.schema.GraphQLDirective buildDirective(graphql.language.Directive, java.util.Set<graphql.schema.GraphQLDirective>, graphql.introspection.Introspection$DirectiveLocation, graphql.schema.GraphqlTypeComparatorRegistry);
    private graphql.schema.GraphQLArgument buildDirectiveArgument(graphql.language.Argument, graphql.schema.GraphQLDirective);
    private java.util.List<graphql.schema.GraphQLArgument> transferMissingArguments(java.util.List<graphql.schema.GraphQLArgument>, graphql.schema.GraphQLDirective);
    graphql.schema.GraphQLDirective buildDirectiveFromDefinition(graphql.language.DirectiveDefinition, java.util.function.Function<graphql.language.Type, graphql.schema.GraphQLInputType>);
    private graphql.schema.GraphQLArgument buildDirectiveArgumentFromDefinition(graphql.language.InputValueDefinition, java.util.function.Function<graphql.language.Type, graphql.schema.GraphQLInputType>);
    private java.util.List<graphql.introspection.Introspection$DirectiveLocation> buildLocations(graphql.language.DirectiveDefinition);
```

### `GraphQLObjectTypeService`（22 方法）

`com.seeyon.boot.starter.graphql.GraphQLObjectTypeService`

```java
    org.dataloader.DataLoaderRegistry getRegistry(java.lang.String);
    void clearMetadataCache(java.lang.String);
    void clearMetadataCache();
    void addMethod(com.seeyon.boot.starter.graphql.dto.DocDto, graphql.schema.GraphQLSchema$Builder, graphql.schema.GraphQLFieldDefinition$Builder, com.seeyon.ctp.metadata.dto.RestMethodMetadataDto, java.lang.String, java.lang.String)
    boolean uniqueRestCheck(java.lang.String, java.lang.String);
    void restNameCacheAdd(java.lang.String, java.lang.String);
    void clearRestNameCache(java.lang.String);
    boolean uniqueCheck(java.lang.String, java.lang.String);
    void typeNameCacheAdd(java.lang.String, java.lang.String);
    void clearTypeNameCache();
    void clearDataloaderCache(java.lang.String);
    boolean dataloaderCached(java.lang.String, java.lang.String);
    void dataloaderCacheAdd(java.lang.String, java.lang.String);
    void refreshDtoCache(java.lang.String, com.seeyon.boot.transport.ListResponse<com.seeyon.ctp.metadata.dto.RestApiMetadataDto>, com.seeyon.boot.transport.ListResponse<com.seeyon.ctp.metadata.dto.DtoMetadataDto>);
    void setAppCache(java.lang.String);
    void clearAppCache();
    void clearCacheMapping();
    void clearDataloaderRegistryCache(java.lang.String);
```

### `PropertyDataFetcherHelper`（22 方法）

`graphql.schema.PropertyDataFetcherHelper`

```java
    static java.lang.Object getPropertyValue(java.lang.String, java.lang.Object, graphql.schema.GraphQLType);
    static java.lang.Object getPropertyValue(java.lang.String, java.lang.Object, graphql.schema.GraphQLType, graphql.schema.DataFetchingEnvironment);
    static private static boolean isNegativelyCached(java.lang.String);
    static private static void putInNegativeCache(java.lang.String);
    static private static java.lang.Object getPropertyViaGetterMethod(java.lang.Object, java.lang.String, graphql.schema.GraphQLType, graphql.schema.PropertyDataFetcherHelper$MethodFinder, graphql.schema.DataFetchingEnvironment)
    static private static java.lang.Object getPropertyViaGetterUsingPrefix(java.lang.Object, java.lang.String, java.lang.String, graphql.schema.PropertyDataFetcherHelper$MethodFinder, graphql.schema.DataFetchingEnvironment)
    static private static java.lang.reflect.Method findPubliclyAccessibleMethod(java.lang.String, java.lang.Class<?>, java.lang.String, boolean)
    static private static java.lang.reflect.Method findViaSetAccessible(java.lang.String, java.lang.Class<?>, java.lang.String, boolean)
    static private static boolean isBooleanProperty(graphql.schema.GraphQLType);
    static void clearReflectionCache();
    static boolean setUseSetAccessible(boolean);
    static boolean setUseNegativeCache(boolean);
    static private static java.lang.String mkKey(java.lang.Object, java.lang.String);
    static private static java.lang.String mkKey(java.lang.Class<?>, java.lang.String);
    static private static boolean hasZeroArgs(java.lang.reflect.Method);
    static private static boolean takesDataFetcherEnvironmentAsOnlyArgument(java.lang.reflect.Method);
    static private static java.util.Comparator<? super java.lang.reflect.Method> mostMethodArgsFirst();
```

### `DataLoaderHelper`（22 方法）

`org.dataloader.DataLoaderHelper`

```java
    java.util.Optional<java.util.concurrent.CompletableFuture<V>> getIfPresent(K);
    java.util.Optional<java.util.concurrent.CompletableFuture<V>> getIfCompleted(K);
    java.util.concurrent.CompletableFuture<V> load(K, java.lang.Object);
    java.lang.Object getCacheKey(K);
    java.util.concurrent.CompletableFuture<java.util.List<V>> dispatch();
    private java.util.concurrent.CompletableFuture<java.util.List<V>> sliceIntoBatchesOfBatches(java.util.List<K>, java.util.List<java.util.concurrent.CompletableFuture<V>>, java.util.List<java.lang.Object>, int);
    private java.util.concurrent.CompletableFuture<java.util.List<V>> dispatchQueueBatch(java.util.List<K>, java.util.List<java.lang.Object>, java.util.List<java.util.concurrent.CompletableFuture<V>>);
    private void assertResultSize(java.util.List<K>, java.util.List<V>);
    private void possiblyClearCacheEntriesOnExceptions(java.util.List<K>);
    java.util.concurrent.CompletableFuture<V> invokeLoaderImmediately(K, java.lang.Object);
    java.util.concurrent.CompletionStage<java.util.List<V>> invokeLoader(java.util.List<K>, java.util.List<java.lang.Object>);
    private java.util.concurrent.CompletionStage<java.util.List<V>> invokeListBatchLoader(java.util.List<K>, org.dataloader.BatchLoaderEnvironment);
    private java.util.concurrent.CompletionStage<java.util.List<V>> invokeMapBatchLoader(java.util.List<K>, org.dataloader.BatchLoaderEnvironment);
    private boolean isMapLoader();
    int dispatchDepth();
```

### `GraphQLProvider`（21 方法）

`com.seeyon.boot.starter.graphql.GraphQLProvider`

```java
    graphql.GraphQL graphQL();
    graphql.GraphQL graphQL(java.lang.String);
    void run(com.seeyon.boot.transport.ListResponse<com.seeyon.ctp.metadata.dto.RestApiMetadataDto>, com.seeyon.boot.transport.ListResponse<com.seeyon.ctp.metadata.dto.DtoMetadataDto>);
    void run(com.seeyon.boot.transport.ListResponse<com.seeyon.ctp.metadata.dto.RestApiMetadataDto>, com.seeyon.boot.transport.ListResponse<com.seeyon.ctp.metadata.dto.DtoMetadataDto>, com.seeyon.boot.transport.ListResponse<com.seeyon.ctp.metadata.dto.EntityMetadataDto>, com.seeyon.boot.transport.SingleResponse<com.seeyon.ctp.metadata.dto.ServiceMetadataDto>);
    void run(java.lang.String, com.seeyon.boot.transport.ListResponse<com.seeyon.ctp.metadata.dto.RestApiMetadataDto>, com.seeyon.boot.transport.ListResponse<com.seeyon.ctp.metadata.dto.DtoMetadataDto>);
    void run(java.lang.String, com.seeyon.boot.transport.ListResponse<com.seeyon.ctp.metadata.dto.RestApiMetadataDto>, com.seeyon.boot.transport.ListResponse<com.seeyon.ctp.metadata.dto.DtoMetadataDto>, com.seeyon.boot.transport.ListResponse<com.seeyon.ctp.metadata.dto.EntityMetadataDto>, com.seeyon.boot.transport.SingleResponse<com.seeyon.ctp.metadata.dto.ServiceMetadataDto>);
    void removeApp(java.lang.String);
    java.lang.Object refresh(java.lang.String, java.lang.String);
    java.lang.Object getDoc(java.lang.String, java.lang.String);
    private synchronized void loadMetaData(java.lang.String, com.seeyon.boot.transport.ListResponse<com.seeyon.ctp.metadata.dto.RestApiMetadataDto>, com.seeyon.boot.transport.ListResponse<com.seeyon.ctp.metadata.dto.DtoMetadataDto>);
    private void addMethod(graphql.schema.GraphQLSchema$Builder, java.lang.String, com.seeyon.boot.transport.ListResponse<com.seeyon.ctp.metadata.dto.RestApiMetadataDto>, com.seeyon.boot.transport.ListResponse<com.seeyon.ctp.metadata.dto.DtoMetadataDto>);
    private void queryBuild(com.seeyon.boot.starter.graphql.dto.DocDto, graphql.schema.GraphQLSchema$Builder, graphql.schema.GraphQLObjectType$Builder, com.seeyon.ctp.metadata.dto.RestMethodMetadataDto, java.lang.String)
    private void queryBuild(com.seeyon.boot.starter.graphql.dto.DocDto, graphql.schema.GraphQLSchema$Builder, graphql.schema.GraphQLObjectType$Builder, graphql.schema.GraphQLObjectType$Builder, com.seeyon.ctp.metadata.dto.RestMethodMetadataDto, java.lang.String)
    private void seeyonRest(com.seeyon.ctp.metadata.dto.RestMethodMetadataDto, java.lang.String, java.lang.String);
    private graphql.schema.DataFetcher<?> creatDataFetcher(com.seeyon.ctp.metadata.dto.RestMethodMetadataDto, java.lang.String);
    static private static java.lang.String pathToCamel(java.lang.String);
    static java.lang.String toCamelCase(java.lang.String, boolean, char...);
    static private static java.util.Set<java.lang.Integer> generateDelimiterSet(char[]);
    void cleanDocCache(java.lang.String);
```

### `GraphQLObjectTypeNReturnService`（20 方法）

`com.seeyon.boot.starter.graphql.GraphQLObjectTypeNReturnService`

```java
    void addMethodReturn(graphql.schema.GraphQLSchema$Builder, graphql.schema.GraphQLFieldDefinition$Builder, com.seeyon.ctp.metadata.dto.RestMethodMetadataDto, java.lang.String, java.lang.String)
    private java.lang.String getContentType(graphql.schema.GraphQLSchema$Builder, java.lang.String, java.lang.String, java.lang.String, com.seeyon.ctp.metadata.dto.model.ReturnValueDto)
    private java.lang.String getReturnType(graphql.schema.GraphQLSchema$Builder, java.lang.String, java.lang.String, com.seeyon.ctp.metadata.dto.model.ReturnValueDto)
    private java.lang.String getReturnTypeForList(graphql.schema.GraphQLSchema$Builder, java.lang.String, com.seeyon.ctp.metadata.dto.model.ReturnValueDto)
    private java.lang.String getReturnTypeMapping(graphql.schema.GraphQLSchema$Builder, java.lang.String, java.lang.String, com.seeyon.ctp.metadata.dto.model.ReturnValueDto)
    private java.lang.String getReturnTypeMappingList(graphql.schema.GraphQLSchema$Builder, java.lang.String, com.seeyon.ctp.metadata.dto.model.ReturnValueDto)
    private void scanDtoByFullName(graphql.schema.GraphQLSchema$Builder, java.lang.String, java.lang.String, java.util.List<com.seeyon.ctp.metadata.dto.DtoMetadataDto>)
    void createDtoType(graphql.schema.GraphQLSchema$Builder, com.seeyon.ctp.metadata.dto.DtoMetadataDto, java.util.List<com.seeyon.ctp.metadata.dto.DtoMetadataDto>, java.lang.String)
    private void touchChildrenData(graphql.schema.GraphQLSchema$Builder, graphql.schema.GraphQLObjectType$Builder, com.seeyon.ctp.metadata.dto.DtoMetadataDto, com.seeyon.ctp.metadata.dto.DtoAttributeMetadataDto, java.lang.String, java.lang.String)
    private java.lang.String getRefDtoType(graphql.schema.GraphQLSchema$Builder, java.lang.String, java.lang.String, java.util.List<com.seeyon.ctp.metadata.dto.DtoMetadataDto>)
    private graphql.schema.DataFetcher<?> creatDataFetcher(java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String, boolean, java.lang.String, java.lang.String);
    private void createDataloader(java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String);
    private boolean isThirdEntity(java.lang.String, java.lang.String, java.lang.String);
    private boolean isMultiSelect(java.lang.String, java.lang.String, java.lang.String);
    private java.lang.String getAttributeDtoMapping(graphql.schema.GraphQLSchema$Builder, java.lang.String, com.seeyon.ctp.metadata.dto.DtoAttributeMetadataDto, java.util.List<com.seeyon.ctp.metadata.dto.DtoMetadataDto>)
    private java.lang.String getAttributeDtoMappingForList(graphql.schema.GraphQLSchema$Builder, java.lang.String, com.seeyon.ctp.metadata.dto.DtoAttributeMetadataDto, java.util.List<com.seeyon.ctp.metadata.dto.DtoMetadataDto>)
    private boolean isCacheMapping(java.lang.String, java.lang.String, boolean);
    private void setTypeCacheMapping(java.lang.String, java.lang.String, java.lang.String, boolean);
    private void removeTypeCacheMapping(java.lang.String, java.lang.String, boolean);
    private java.lang.String getTypeCacheMapping(java.lang.String, java.lang.String, boolean);
```

### `ValidationUtil`（20 方法）

`graphql.validation.ValidationUtil`

```java
    graphql.language.TypeName getUnmodifiedType(graphql.language.Type<?>);
    protected void handleNullError(graphql.language.Value<?>, graphql.schema.GraphQLType);
    protected void handleScalarError(graphql.language.Value<?>, graphql.schema.GraphQLScalarType, graphql.GraphQLError);
    protected void handleEnumError(graphql.language.Value<?>, graphql.schema.GraphQLEnumType, graphql.GraphQLError);
    protected void handleNotObjectError(graphql.language.Value<?>, graphql.schema.GraphQLInputObjectType);
    protected void handleMissingFieldsError(graphql.language.Value<?>, graphql.schema.GraphQLInputObjectType, java.util.Set<java.lang.String>);
    protected void handleExtraFieldError(graphql.language.Value<?>, graphql.schema.GraphQLInputObjectType, graphql.language.ObjectField);
    protected void handleFieldNotValidError(graphql.language.ObjectField, graphql.schema.GraphQLInputObjectType);
    protected void handleFieldNotValidError(graphql.language.Value<?>, graphql.schema.GraphQLType, int);
    boolean isValidLiteralValue(graphql.language.Value<?>, graphql.schema.GraphQLType, graphql.schema.GraphQLSchema);
    private java.util.Optional<graphql.GraphQLError> parseLiteralEnum(graphql.language.Value<?>, graphql.schema.GraphQLEnumType);
    private java.util.Optional<graphql.GraphQLError> parseLiteral(graphql.language.Value<?>, graphql.schema.Coercing<?, ?>);
    private boolean isValidLiteralValue(graphql.language.Value<?>, graphql.schema.GraphQLInputObjectType, graphql.schema.GraphQLSchema);
    private java.util.Set<java.lang.String> getMissingFields(graphql.schema.GraphQLInputObjectType, java.util.Map<java.lang.String, graphql.language.ObjectField>, graphql.schema.visibility.GraphqlFieldVisibility);
    private java.util.Map<java.lang.String, graphql.language.ObjectField> fieldMap(graphql.language.ObjectValue);
    private boolean isValidLiteralValue(graphql.language.Value<?>, graphql.schema.GraphQLList, graphql.schema.GraphQLSchema);
```

### `Utils`（17 方法）

`antlr.v4.runtime.misc.Utils`

```java
    static <T> java.lang.String join(java.util.Iterator<T>, java.lang.String);
    static <T> java.lang.String join(T[], java.lang.String);
    static int numNonnull(java.lang.Object[]);
    static <T> void removeAllElements(java.util.Collection<T>, T);
    static java.lang.String escapeWhitespace(java.lang.String, boolean);
    static void writeFile(java.lang.String, java.lang.String)
    static void writeFile(java.lang.String, java.lang.String, java.lang.String)
    static char[] readFile(java.lang.String)
    static char[] readFile(java.lang.String, java.lang.String)
    static java.util.Map<java.lang.String, java.lang.Integer> toMap(java.lang.String[]);
    static char[] toCharArray(antlr.v4.runtime.misc.IntegerList);
    static antlr.v4.runtime.misc.IntervalSet toSet(java.util.BitSet);
    static java.lang.String expandTabs(java.lang.String, int);
    static java.lang.String spaces(int);
    static java.lang.String newlines(int);
    static java.lang.String sequence(int, java.lang.String);
    static int count(java.lang.String, char);
```

### `ResultNodesUtil`（15 方法）

`graphql.execution.nextgen.result.ResultNodesUtil`

```java
    static graphql.ExecutionResult toExecutionResult(graphql.execution.nextgen.result.RootExecutionResultNode);
    static private static graphql.execution.nextgen.result.ResultNodesUtil$ExecutionResultData data(java.lang.Object, graphql.execution.nextgen.result.ExecutionResultNode);
    static private static graphql.execution.nextgen.result.ResultNodesUtil$ExecutionResultData data(java.lang.Object, java.util.List<graphql.GraphQLError>);
    static private static graphql.execution.nextgen.result.ResultNodesUtil$ExecutionResultData data(java.lang.Object, graphql.execution.NonNullableFieldWasNullException);
    static private static graphql.execution.nextgen.result.ResultNodesUtil$ExecutionResultData toDataImpl(graphql.execution.nextgen.result.ExecutionResultNode);
    static java.util.Optional<graphql.execution.NonNullableFieldWasNullException> getFirstNonNullableException(java.util.Collection<graphql.execution.nextgen.result.ExecutionResultNode>);
    static graphql.execution.NonNullableFieldWasNullException newNullableException(graphql.execution.ExecutionStepInfo, java.util.List<graphql.execution.nextgen.result.NamedResultNode>);
    static java.util.Map<java.lang.String, graphql.execution.nextgen.result.ExecutionResultNode> namedNodesToMap(java.util.List<graphql.execution.nextgen.result.NamedResultNode>);
    static graphql.execution.NonNullableFieldWasNullException newNullableException(graphql.execution.ExecutionStepInfo, java.util.Collection<graphql.execution.nextgen.result.ExecutionResultNode>);
    static java.util.List<graphql.util.NodeZipper<graphql.execution.nextgen.result.ExecutionResultNode>> getUnresolvedNodes(java.util.Collection<graphql.execution.nextgen.result.ExecutionResultNode>);
    static graphql.util.NodeMultiZipper<graphql.execution.nextgen.result.ExecutionResultNode> getUnresolvedNodes(graphql.execution.nextgen.result.ExecutionResultNode);
    static graphql.util.NodeLocation key(java.lang.String);
    static graphql.util.NodeLocation index(int);
```

### `GraphQLTypeUtil`（15 方法）

`graphql.schema.GraphQLTypeUtil`

```java
    static java.lang.String simplePrint(graphql.schema.GraphQLType);
    static java.lang.String simplePrint(graphql.schema.GraphQLSchemaElement);
    static boolean isNonNull(graphql.schema.GraphQLType);
    static boolean isNullable(graphql.schema.GraphQLType);
    static boolean isList(graphql.schema.GraphQLType);
    static boolean isWrapped(graphql.schema.GraphQLType);
    static boolean isNotWrapped(graphql.schema.GraphQLType);
    static boolean isScalar(graphql.schema.GraphQLType);
    static boolean isEnum(graphql.schema.GraphQLType);
    static boolean isLeaf(graphql.schema.GraphQLType);
    static boolean isInput(graphql.schema.GraphQLType);
    static graphql.schema.GraphQLType unwrapOne(graphql.schema.GraphQLType);
    static graphql.schema.GraphQLUnmodifiedType unwrapAll(graphql.schema.GraphQLType);
    static graphql.schema.GraphQLType unwrapNonNull(graphql.schema.GraphQLType);
    static java.util.Stack<graphql.schema.GraphQLType> unwrapType(graphql.schema.GraphQLType);
```

### `EchoingWiringFactory`（15 方法）

`graphql.schema.idl.EchoingWiringFactory`

```java
    static graphql.schema.idl.RuntimeWiring newEchoingWiring();
    static graphql.schema.idl.RuntimeWiring newEchoingWiring(java.util.function.Consumer<graphql.schema.idl.RuntimeWiring$Builder>);
    boolean providesTypeResolver(graphql.schema.idl.InterfaceWiringEnvironment);
    graphql.schema.TypeResolver getTypeResolver(graphql.schema.idl.InterfaceWiringEnvironment);
    boolean providesTypeResolver(graphql.schema.idl.UnionWiringEnvironment);
    graphql.schema.TypeResolver getTypeResolver(graphql.schema.idl.UnionWiringEnvironment);
    graphql.schema.DataFetcher getDefaultDataFetcher(graphql.schema.idl.FieldWiringEnvironment);
    static private static java.lang.Object fakeObjectValue(graphql.schema.GraphQLObjectType);
    static private static java.lang.Object fakeScalarValue(java.lang.String, graphql.schema.GraphQLScalarType);
    static graphql.schema.GraphQLScalarType fakeScalar(java.lang.String);
```

### `GraphQLObjectTypeParamsService`（14 方法）

`com.seeyon.boot.starter.graphql.GraphQLObjectTypeParamsService`

```java
    void addMethodParamList(com.seeyon.boot.starter.graphql.dto.DocDto, graphql.schema.GraphQLSchema$Builder, graphql.schema.GraphQLFieldDefinition$Builder, com.seeyon.ctp.metadata.dto.RestMethodMetadataDto, java.lang.String, java.lang.String)
    private void handleQuery(graphql.schema.GraphQLSchema$Builder, graphql.schema.GraphQLInputObjectType$Builder, com.seeyon.ctp.metadata.dto.RestParamMetadataDto, java.lang.String, java.lang.String)
    private void handleQueryField(graphql.schema.GraphQLSchema$Builder, graphql.schema.GraphQLInputObjectType$Builder, java.util.Map<java.lang.String, com.seeyon.ctp.metadata.dto.DtoAttributeMetadataDto>, java.lang.String)
    private java.lang.String getAttributeDtoMapping(graphql.schema.GraphQLSchema$Builder, java.lang.String, com.seeyon.ctp.metadata.dto.DtoAttributeMetadataDto, java.util.List<com.seeyon.ctp.metadata.dto.DtoMetadataDto>, boolean)
    private java.lang.String getAttributeDtoMappingForList(graphql.schema.GraphQLSchema$Builder, java.lang.String, com.seeyon.ctp.metadata.dto.DtoAttributeMetadataDto, java.util.List<com.seeyon.ctp.metadata.dto.DtoMetadataDto>, boolean)
    private java.lang.String getParamDtoType(graphql.schema.GraphQLSchema$Builder, java.lang.String, java.lang.String, boolean)
    private void scanDtoByFullName(graphql.schema.GraphQLSchema$Builder, java.lang.String, java.lang.String, java.util.List<com.seeyon.ctp.metadata.dto.DtoMetadataDto>)
    void createDtoType(graphql.schema.GraphQLSchema$Builder, com.seeyon.ctp.metadata.dto.DtoMetadataDto, java.util.List<com.seeyon.ctp.metadata.dto.DtoMetadataDto>, java.lang.String)
    private void childrenMock(graphql.schema.GraphQLInputObjectType$Builder, com.seeyon.ctp.metadata.dto.DtoAttributeMetadataDto, java.lang.String);
    private boolean isCacheMapping(java.lang.String, boolean);
    private void setTypeCacheMapping(java.lang.String, java.lang.String, boolean);
    private void removeTypeCacheMapping(java.lang.String, boolean);
    private java.lang.String getTypeCacheMapping(java.lang.String, boolean);
```

### `CombinedWiringFactory`（14 方法）

`graphql.schema.idl.CombinedWiringFactory`

```java
    boolean providesTypeResolver(graphql.schema.idl.InterfaceWiringEnvironment);
    graphql.schema.TypeResolver getTypeResolver(graphql.schema.idl.InterfaceWiringEnvironment);
    boolean providesTypeResolver(graphql.schema.idl.UnionWiringEnvironment);
    graphql.schema.TypeResolver getTypeResolver(graphql.schema.idl.UnionWiringEnvironment);
    boolean providesDataFetcherFactory(graphql.schema.idl.FieldWiringEnvironment);
    <T> graphql.schema.DataFetcherFactory<T> getDataFetcherFactory(graphql.schema.idl.FieldWiringEnvironment);
    boolean providesDataFetcher(graphql.schema.idl.FieldWiringEnvironment);
    graphql.schema.DataFetcher getDataFetcher(graphql.schema.idl.FieldWiringEnvironment);
    boolean providesScalar(graphql.schema.idl.ScalarWiringEnvironment);
    graphql.schema.GraphQLScalarType getScalar(graphql.schema.idl.ScalarWiringEnvironment);
    boolean providesSchemaDirectiveWiring(graphql.schema.idl.SchemaDirectiveWiringEnvironment);
    graphql.schema.idl.SchemaDirectiveWiring getSchemaDirectiveWiring(graphql.schema.idl.SchemaDirectiveWiringEnvironment);
    graphql.schema.DataFetcher getDefaultDataFetcher(graphql.schema.idl.FieldWiringEnvironment);
```

### `MetadataProxyService`（12 方法）

`com.seeyon.boot.starter.graphql.proxy.MetadataProxyService`

```java
    void clearCache();
    void setCache(com.seeyon.boot.transport.ListResponse<com.seeyon.ctp.metadata.dto.RestApiMetadataDto>, com.seeyon.boot.transport.ListResponse<com.seeyon.ctp.metadata.dto.DtoMetadataDto>, com.seeyon.boot.transport.ListResponse<com.seeyon.ctp.metadata.dto.EntityMetadataDto>, com.seeyon.boot.transport.SingleResponse<com.seeyon.ctp.metadata.dto.ServiceMetadataDto>);
    java.util.List<com.seeyon.ctp.metadata.dto.RestApiMetadataDto> selectRestApiMetadata(java.lang.String);
    java.util.List<com.seeyon.ctp.metadata.dto.DtoMetadataDto> selectDtoMetadata(java.lang.String);
    java.util.List<com.seeyon.ctp.metadata.dto.EntityMetadataDto> selectEntityMetadata(java.lang.String);
    com.seeyon.ctp.metadata.dto.ServiceMetadataDto selectServiceMetadataByName(java.lang.String);
    com.seeyon.ctp.metadata.dto.DtoMetadataDto selectDtoMetadataByFullName(java.lang.String, java.lang.String);
    com.seeyon.ctp.metadata.dto.AppServiceMetadataDto selectAppServiceMetadataByEntityFullName(java.lang.String, java.lang.String);
```

### `GraphqlErrorBuilder`（12 方法）

`graphql.GraphqlErrorBuilder`

```java
    static graphql.GraphqlErrorBuilder newError();
    static graphql.GraphqlErrorBuilder newError(graphql.schema.DataFetchingEnvironment);
    graphql.GraphqlErrorBuilder message(java.lang.String, java.lang.Object...);
    graphql.GraphqlErrorBuilder locations(java.util.List<graphql.language.SourceLocation>);
    graphql.GraphqlErrorBuilder location(graphql.language.SourceLocation);
    graphql.GraphqlErrorBuilder path(graphql.execution.ExecutionPath);
    graphql.GraphqlErrorBuilder path(java.util.List<java.lang.Object>);
    graphql.GraphqlErrorBuilder errorType(graphql.ErrorClassification);
    graphql.GraphqlErrorBuilder extensions(java.util.Map<java.lang.String, java.lang.Object>);
    graphql.GraphQLError build();
    graphql.execution.DataFetcherResult toResult();
```

### `AppHostService`（11 方法）

`com.seeyon.boot.starter.graphql.AppHostService`

```java
    void addApp(java.lang.String);
    void removeApp(java.lang.String);
    java.lang.String getHost(java.lang.String)
    boolean isLocal(java.lang.String);
    private java.lang.String getNacos(java.lang.String)
    private void refresh(java.lang.String);
    private synchronized void getLockNacos(java.lang.String)
    void subscribe(java.lang.String)
    void fixedRefresh();
    private boolean compare(java.util.List<java.lang.String>, java.util.List<java.lang.String>);
```

### `DynamicSelectByIdsService`（11 方法）

`com.seeyon.boot.starter.graphql.appservice.DynamicSelectByIdsService`

```java
    com.seeyon.boot.transport.ListResponse<? extends java.lang.Object> appServiceDynamicSelectByIds(java.lang.String, java.lang.String, java.util.List<java.lang.String>);
    com.seeyon.boot.transport.ListResponse<? extends java.lang.Object> appServiceDynamicSelectByIds(java.lang.String, java.lang.String, java.util.List<java.lang.String>, java.util.List<java.lang.String>);
    com.seeyon.boot.transport.SingleResponse<? extends java.lang.Object> appServiceDynamicSelectById(java.lang.String, java.lang.String, java.lang.String);
    com.seeyon.boot.transport.SingleResponse<? extends java.lang.Object> appServiceDynamicSelectById(java.lang.String, java.lang.String, java.lang.String, java.util.List<java.lang.String>);
    private java.lang.String getAppServiceName(java.lang.String, java.lang.String);
    com.seeyon.boot.transport.ListResponse<? extends java.lang.Object> dynamicSelectByIds(java.lang.String, java.lang.String, java.util.List<java.lang.String>, java.util.Set<java.lang.String>);
    com.seeyon.boot.transport.SingleResponse<? extends java.lang.Object> dynamicSelectById(java.lang.String, java.lang.String, java.lang.String, java.util.Set<java.lang.String>);
    void onApplicationEvent(com.seeyon.boot.event.ModuleUnloadEvent);
    private java.lang.Object getAppServiceFromModuleBean(java.lang.String, java.lang.String);
    private void loadDynamicModuleIfNecessary(java.lang.String);
    void onApplicationEvent(org.springframework.context.ApplicationEvent);
```

### `ExecutionStrategyUtil`（11 方法）

`graphql.execution.nextgen.ExecutionStrategyUtil`

```java
    java.util.List<java.util.concurrent.CompletableFuture<graphql.execution.nextgen.result.ExecutionResultNode>> fetchSubSelection(graphql.execution.ExecutionContext, graphql.execution.nextgen.FieldSubSelection);
    private java.util.List<java.util.concurrent.CompletableFuture<graphql.execution.nextgen.FetchedValueAnalysis>> fetchAndAnalyze(graphql.execution.ExecutionContext, graphql.execution.nextgen.FieldSubSelection);
    private java.util.concurrent.CompletableFuture<graphql.execution.nextgen.FetchedValueAnalysis> fetchAndAnalyzeField(graphql.execution.ExecutionContext, java.lang.Object, java.lang.Object, graphql.execution.MergedField, graphql.execution.ExecutionStepInfo);
    private java.util.List<java.util.concurrent.CompletableFuture<graphql.execution.nextgen.result.ExecutionResultNode>> fetchedValueAnalysisToNodesAsync(java.util.List<java.util.concurrent.CompletableFuture<graphql.execution.nextgen.FetchedValueAnalysis>>);
    java.util.List<graphql.execution.nextgen.result.ExecutionResultNode> fetchedValueAnalysisToNodes(java.util.List<graphql.execution.nextgen.FetchedValueAnalysis>);
    private graphql.execution.nextgen.FetchedValueAnalysis analyseValue(graphql.execution.ExecutionContext, graphql.execution.FetchedValue, graphql.execution.ExecutionStepInfo);
    graphql.execution.nextgen.FieldSubSelection createFieldSubSelection(graphql.execution.ExecutionContext, graphql.execution.ExecutionStepInfo, graphql.execution.nextgen.result.ResolvedValue);
```

### `AppServiceDisplayNameIdProDto`（10 方法）

`com.seeyon.boot.starter.graphql.dto.AppServiceDisplayNameIdProDto`

```java
    void setAppName(java.lang.String);
    void setIsUdcApp(java.lang.Boolean);
    void setEntityFullName(java.lang.String);
    void setId(java.lang.String);
    void setFieldSet(java.util.List<java.lang.String>);
    java.lang.String getAppName();
    java.lang.Boolean getIsUdcApp();
    java.lang.String getEntityFullName();
    java.lang.String getId();
    java.util.List<java.lang.String> getFieldSet();
```

### `AppServiceDisplayNameIdsProDto`（10 方法）

`com.seeyon.boot.starter.graphql.dto.AppServiceDisplayNameIdsProDto`

```java
    void setAppName(java.lang.String);
    void setIsUdcApp(java.lang.Boolean);
    void setEntityFullName(java.lang.String);
    void setIds(java.util.List<java.lang.String>);
    void setFieldSet(java.util.List<java.lang.String>);
    java.lang.String getAppName();
    java.lang.Boolean getIsUdcApp();
    java.lang.String getEntityFullName();
    java.util.List<java.lang.String> getIds();
    java.util.List<java.lang.String> getFieldSet();
```

### `ArgumentValidationUtil`（10 方法）

`graphql.validation.ArgumentValidationUtil`

```java
    protected void handleNullError(graphql.language.Value<?>, graphql.schema.GraphQLType);
    protected void handleScalarError(graphql.language.Value<?>, graphql.schema.GraphQLScalarType, graphql.GraphQLError);
    protected void handleEnumError(graphql.language.Value<?>, graphql.schema.GraphQLEnumType, graphql.GraphQLError);
    protected void handleNotObjectError(graphql.language.Value<?>, graphql.schema.GraphQLInputObjectType);
    protected void handleMissingFieldsError(graphql.language.Value<?>, graphql.schema.GraphQLInputObjectType, java.util.Set<java.lang.String>);
    protected void handleExtraFieldError(graphql.language.Value<?>, graphql.schema.GraphQLInputObjectType, graphql.language.ObjectField);
    protected void handleFieldNotValidError(graphql.language.ObjectField, graphql.schema.GraphQLInputObjectType);
    protected void handleFieldNotValidError(graphql.language.Value<?>, graphql.schema.GraphQLType, int);
    java.lang.String getMessage();
    java.util.Map<java.lang.String, java.lang.Object> getErrorExtensions();
```

### `AstValueHelper`（9 方法）

`graphql.language.AstValueHelper`

```java
    static graphql.language.Value<?> astFromValue(java.lang.Object, graphql.schema.GraphQLType);
    static private static graphql.language.Value<?> handleInputObject(java.lang.Object, graphql.schema.GraphQLInputObjectType);
    static private static graphql.language.Value<?> handleNumber(java.lang.String);
    static private static graphql.language.Value<?> handleList(java.lang.Object, graphql.schema.GraphQLList);
    static private static graphql.language.Value<?> handleNonNull(java.lang.Object, graphql.schema.GraphQLNonNull);
    static private static java.lang.Object serialize(graphql.schema.GraphQLType, java.lang.Object);
    static private static boolean isNullish(java.lang.Object);
    static graphql.language.Value<?> valueFromAst(java.lang.String);
```

### `NoopWiringFactory`（9 方法）

`graphql.schema.idl.NoopWiringFactory`

```java
    boolean providesScalar(graphql.schema.idl.ScalarWiringEnvironment);
    graphql.schema.GraphQLScalarType getScalar(graphql.schema.idl.ScalarWiringEnvironment);
    boolean providesTypeResolver(graphql.schema.idl.InterfaceWiringEnvironment);
    graphql.schema.TypeResolver getTypeResolver(graphql.schema.idl.InterfaceWiringEnvironment);
    boolean providesTypeResolver(graphql.schema.idl.UnionWiringEnvironment);
    graphql.schema.TypeResolver getTypeResolver(graphql.schema.idl.UnionWiringEnvironment);
    boolean providesDataFetcher(graphql.schema.idl.FieldWiringEnvironment);
    graphql.schema.DataFetcher getDataFetcher(graphql.schema.idl.FieldWiringEnvironment);
    graphql.schema.DataFetcher getDefaultDataFetcher(graphql.schema.idl.FieldWiringEnvironment);
```

### `ATNConfig`（8 方法）

`antlr.v4.runtime.atn.ATNConfig`

```java
    final int getOuterContextDepth();
    final boolean isPrecedenceFilterSuppressed();
    final void setPrecedenceFilterSuppressed(boolean);
    boolean equals(java.lang.Object);
    boolean equals(antlr.v4.runtime.atn.ATNConfig);
    int hashCode();
    java.lang.String toString();
    java.lang.String toString(antlr.v4.runtime.Recognizer<?, ?>, boolean);
```

### `AppServiceDisplayNameIdDto`（8 方法）

`com.seeyon.boot.starter.graphql.dto.AppServiceDisplayNameIdDto`

```java
    void setAppName(java.lang.String);
    void setIsUdcApp(java.lang.Boolean);
    void setEntityFullName(java.lang.String);
    void setId(java.lang.String);
    java.lang.String getAppName();
    java.lang.Boolean getIsUdcApp();
    java.lang.String getEntityFullName();
    java.lang.String getId();
```

### `AppServiceDisplayNameIdsDto`（8 方法）

`com.seeyon.boot.starter.graphql.dto.AppServiceDisplayNameIdsDto`

```java
    void setAppName(java.lang.String);
    void setIsUdcApp(java.lang.Boolean);
    void setEntityFullName(java.lang.String);
    void setIds(java.util.List<java.lang.String>);
    java.lang.String getAppName();
    java.lang.Boolean getIsUdcApp();
    java.lang.String getEntityFullName();
    java.util.List<java.lang.String> getIds();
```

### `HttpAsyncUtil`（8 方法）

`com.seeyon.boot.starter.graphql.util.HttpAsyncUtil`

```java
    static java.util.Map<java.lang.String, java.lang.Object> doGet(java.lang.String, java.util.Map<java.lang.String, java.lang.Object>, java.util.Map<java.lang.String, java.lang.Object>)
    static java.util.concurrent.CompletableFuture<java.lang.String> doPost(java.lang.String, java.util.Map<java.lang.String, java.lang.String>, java.util.Map<java.lang.String, java.lang.String>);
    static java.util.Map<java.lang.String, java.lang.Object> doPostJson(java.lang.String, java.lang.String, java.util.Map<java.lang.String, java.lang.Object>)
    static private static java.lang.String encode(java.lang.String);
```

### `DataFetcherExceptionHandlerParameters`（8 方法）

`graphql.execution.DataFetcherExceptionHandlerParameters`

```java
    java.lang.Throwable getException();
    graphql.execution.ExecutionPath getPath();
    graphql.schema.DataFetchingEnvironment getDataFetchingEnvironment();
    graphql.execution.MergedField getField();
    graphql.schema.GraphQLFieldDefinition getFieldDefinition();
    java.util.Map<java.lang.String, java.lang.Object> getArgumentValues();
    graphql.language.SourceLocation getSourceLocation();
    static graphql.execution.DataFetcherExceptionHandlerParameters$Builder newExceptionParameters();
```

### `NodeUtil`（8 方法）

`graphql.language.NodeUtil`

```java
    static boolean isEqualTo(java.lang.String, java.lang.String);
    static java.util.Map<java.lang.String, graphql.language.Directive> directivesByName(java.util.List<graphql.language.Directive>);
    static java.util.Map<java.lang.String, graphql.language.Argument> argumentsByName(java.util.List<graphql.language.Argument>);
    static java.util.Map<java.lang.String, graphql.language.FragmentDefinition> getFragmentsByName(graphql.language.Document);
    static graphql.language.NodeUtil$GetOperationResult getOperation(graphql.language.Document, java.lang.String);
    static void assertNewChildrenAreEmpty(graphql.language.NodeChildrenContainer);
    static graphql.language.Node removeChild(graphql.language.Node, graphql.util.NodeLocation);
```

### `SchemaUtil`（8 方法）

`graphql.schema.SchemaUtil`

```java
    java.util.Map<java.lang.String, graphql.schema.GraphQLNamedType> allTypes(graphql.schema.GraphQLSchema, java.util.Set<graphql.schema.GraphQLType>, boolean);
    java.util.Map<java.lang.String, java.util.List<graphql.schema.GraphQLObjectType>> groupImplementations(graphql.schema.GraphQLSchema);
    java.util.List<graphql.schema.GraphQLObjectType> findImplementations(graphql.schema.GraphQLSchema, graphql.schema.GraphQLInterfaceType);
    void replaceTypeReferences(graphql.schema.GraphQLSchema);
    void extractCodeFromTypes(graphql.schema.GraphQLCodeRegistry$Builder, graphql.schema.GraphQLSchema);
```

### `DisplayNameService`（7 方法）

`com.seeyon.boot.starter.graphql.appservice.DisplayNameService`

```java
    com.seeyon.boot.transport.ListResponse<? extends java.lang.Object> appServiceDynamicSelectByIds(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.graphql.dto.AppServiceDisplayNameIdsDto>);
    com.seeyon.boot.transport.ListResponse<? extends java.lang.Object> appServiceDynamicSelectByIdsDisplayName(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.graphql.dto.AppServiceDisplayNameIdsProDto>);
    com.seeyon.boot.transport.SingleResponse<? extends java.lang.Object> appServiceDynamicSelectById(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.graphql.dto.AppServiceDisplayNameIdDto>);
    com.seeyon.boot.transport.SingleResponse<? extends java.lang.Object> appServiceDynamicSelectByIdDisplayName(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.graphql.dto.AppServiceDisplayNameIdProDto>);
    com.seeyon.boot.transport.ListResponse<? extends java.lang.Object> dynamicSelectByIds(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.graphql.dto.DisplayNameIdsDto>);
    com.seeyon.boot.transport.SingleResponse<? extends java.lang.Object> dynamicSelectById(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.graphql.dto.DisplayNameIdDto>);
    private int generateRandomNumber();
```

### `GraphqlTypeBuilder`（7 方法）

`graphql.schema.GraphqlTypeBuilder`

```java
    graphql.schema.GraphqlTypeBuilder name(java.lang.String);
    graphql.schema.GraphqlTypeBuilder description(java.lang.String);
    graphql.schema.GraphqlTypeBuilder comparatorRegistry(graphql.schema.GraphqlTypeComparatorRegistry);
    <T extends graphql.schema.GraphQLSchemaElement> java.util.List<T> sort(java.util.Map<java.lang.String, T>, java.lang.Class<? extends graphql.schema.GraphQLSchemaElement>, java.lang.Class<? extends graphql.schema.GraphQLSchemaElement>);
    <T extends graphql.schema.GraphQLSchemaElement> java.util.List<T> sort(java.util.List<T>, java.lang.Class<? extends graphql.schema.GraphQLSchemaElement>, java.lang.Class<? extends graphql.schema.GraphQLSchemaElement>);
    java.util.Comparator<? super graphql.schema.GraphQLSchemaElement> getComparator(java.lang.Class<? extends graphql.schema.GraphQLSchemaElement>, java.lang.Class<? extends graphql.schema.GraphQLNamedSchemaElement>);
    static private static java.util.Comparator<? super graphql.schema.GraphQLSchemaElement> getComparatorImpl(graphql.schema.GraphqlTypeComparatorRegistry, java.lang.Class<? extends graphql.schema.GraphQLSchemaElement>, java.lang.Class<? extends graphql.schema.GraphQLSchemaElement>);
```

### `TreeTransformerUtil`（7 方法）

`graphql.util.TreeTransformerUtil`

```java
    static <T> graphql.util.TraversalControl changeNode(graphql.util.TraverserContext<T>, T);
    static private static <T> void replaceZipperForNode(java.util.List<graphql.util.NodeZipper<T>>, T, T);
    static <T> graphql.util.TraversalControl deleteNode(graphql.util.TraverserContext<T>);
    static <T> graphql.util.TraversalControl insertAfter(graphql.util.TraverserContext<T>, T);
    static <T> graphql.util.TraversalControl insertBefore(graphql.util.TraverserContext<T>, T);
```

### `LexerActionExecutor`（6 方法）

`antlr.v4.runtime.atn.LexerActionExecutor`

```java
    static antlr.v4.runtime.atn.LexerActionExecutor append(antlr.v4.runtime.atn.LexerActionExecutor, antlr.v4.runtime.atn.LexerAction);
    antlr.v4.runtime.atn.LexerActionExecutor fixOffsetBeforeMatch(int);
    antlr.v4.runtime.atn.LexerAction[] getLexerActions();
    void execute(antlr.v4.runtime.Lexer, antlr.v4.runtime.CharStream, int);
    int hashCode();
    boolean equals(java.lang.Object);
```

### `LogManager`（6 方法）

`antlr.v4.runtime.misc.LogManager`

```java
    void log(java.lang.String, java.lang.String);
    void log(java.lang.String);
    void save(java.lang.String)
    java.lang.String save()
    java.lang.String toString();
    static void main(java.lang.String[])
```

### `ThreadLocalUtil`（6 方法）

`com.seeyon.boot.starter.graphql.util.ThreadLocalUtil`

```java
    static <T> T get(java.lang.String);
    static <T> T get(java.lang.String, T);
    static void set(java.lang.String, java.lang.Object);
    static void remove();
```

### `LexerATNConfig`（5 方法）

`antlr.v4.runtime.atn.LexerATNConfig`

```java
    final antlr.v4.runtime.atn.LexerActionExecutor getLexerActionExecutor();
    final boolean hasPassedThroughNonGreedyDecision();
    int hashCode();
    boolean equals(antlr.v4.runtime.atn.ATNConfig);
    static private static boolean checkNonGreedyDecision(antlr.v4.runtime.atn.LexerATNConfig, antlr.v4.runtime.atn.ATNState);
```

### `GraphQLJsonUtils`（5 方法）

`com.seeyon.boot.starter.graphql.util.GraphQLJsonUtils`

```java
    static byte[] toByte(java.lang.Object);
    static java.lang.String toJson(java.lang.Object);
    static java.lang.String innerToJson(java.lang.Object);
    static <K, V> java.util.Map<K, V> toMap(java.lang.String, java.lang.Class<K>, java.lang.Class<V>);
    static java.lang.String subString(java.lang.String, int);
```

### `GraphqlErrorHelper`（5 方法）

`graphql.GraphqlErrorHelper`

```java
    static java.util.Map<java.lang.String, java.lang.Object> toSpecification(graphql.GraphQLError);
    static java.lang.Object locations(java.util.List<graphql.language.SourceLocation>);
    static java.lang.Object location(graphql.language.SourceLocation);
    static int hashCode(graphql.GraphQLError);
    static boolean equals(graphql.GraphQLError, java.lang.Object);
```

### `NonBlockingMutexExecutor`（5 方法）

`graphql.execution.reactive.NonBlockingMutexExecutor`

```java
    void execute(java.lang.Runnable);
    private void reportFailure(java.lang.Thread, java.lang.Throwable);
    private void run(graphql.execution.reactive.NonBlockingMutexExecutor$RunNode);
    private void runAll(graphql.execution.reactive.NonBlockingMutexExecutor$RunNode);
```

### `CommonTokenFactory`（4 方法）

`antlr.v4.runtime.CommonTokenFactory`

```java
    antlr.v4.runtime.CommonToken create(antlr.v4.runtime.misc.Pair<antlr.v4.runtime.TokenSource, antlr.v4.runtime.CharStream>, int, java.lang.String, int, int, int, int, int);
    antlr.v4.runtime.CommonToken create(int, java.lang.String);
    antlr.v4.runtime.Token create(int, java.lang.String);
    antlr.v4.runtime.Token create(antlr.v4.runtime.misc.Pair, int, java.lang.String, int, int, int, int, int);
```

### `SeeyonExeUtilForModel`（4 方法）

`com.seeyon.boot.starter.graphql.execution.SeeyonExeUtilForModel`

```java
    java.util.Map<java.lang.Object, java.lang.Object> model(java.util.Map<java.lang.Object, java.lang.Object>, java.util.Map<java.lang.String, java.util.Set<java.lang.String>>, java.util.Map<java.lang.Object, java.lang.Object>, java.lang.String, java.lang.String, java.util.Map<java.lang.String, java.lang.Object>)
    private java.util.Map<java.lang.Object, java.lang.Object> model(java.util.Map<java.lang.Object, java.lang.Object>, java.util.Map<java.lang.Object, java.lang.Object>, java.lang.String, java.lang.String, java.lang.String, java.util.Map<java.lang.String, java.lang.Object>)
    private void getDisplayNameObj(java.lang.String, java.lang.String, java.util.Map<java.lang.String, java.lang.Object>, java.util.Map<java.lang.Object, java.lang.Object>, java.util.Map<java.lang.String, java.util.Set<java.lang.String>>)
    java.util.Map<java.lang.Object, java.lang.Object> model(java.util.Map<java.lang.Object, java.lang.Object>, java.util.Map<java.lang.Object, java.lang.Object>, java.lang.String, java.util.Map<java.lang.String, java.lang.Object>)
```

### `ExecutionStepInfoFactory`（4 方法）

`graphql.execution.ExecutionStepInfoFactory`

```java
    graphql.execution.ExecutionStepInfo newExecutionStepInfoForSubField(graphql.execution.ExecutionContext, graphql.execution.MergedField, graphql.execution.ExecutionStepInfo);
    graphql.execution.ExecutionStepInfo newExecutionStepInfoForListElement(graphql.execution.ExecutionStepInfo, int);
```

### `I18nParserService`（3 方法）

`com.seeyon.boot.starter.graphql.execution.I18nParserService`

```java
    java.util.Set<java.lang.String> getFieldFromDto(java.lang.String, java.lang.String);
    void onApplicationEvent(com.seeyon.boot.event.ModuleUnloadEvent);
    void onApplicationEvent(org.springframework.context.ApplicationEvent);
```

### `ScheduledService`（3 方法）

`com.seeyon.boot.starter.graphql.task.ScheduledService`

```java
    void flashApp(java.lang.String);
    void fixedFlash();
    void fixedUpdate();
```

### `GraphQLTypeNameUtil`（3 方法）

`com.seeyon.boot.starter.graphql.util.GraphQLTypeNameUtil`

```java
    static java.lang.String touchName(java.lang.String, java.lang.String, boolean);
    static private static java.lang.String appNameToCamel(java.lang.String);
    static private static java.lang.String getSimpleNameFromFullName(java.lang.String);
```

### `GraphqlHttpUtils`（3 方法）

`com.seeyon.boot.starter.graphql.util.GraphqlHttpUtils`

```java
    static java.util.Map<java.lang.String, java.lang.Object> byId(java.lang.String, com.seeyon.boot.util.http.common.HttpHeader);
    static java.util.Map<java.lang.String, java.lang.Object> byIds(java.lang.String, java.lang.String, com.seeyon.boot.util.http.common.HttpHeader);
    static private static java.lang.String decompressGzip(java.io.InputStream)
```

### `HttpAsyncClient`（3 方法）

`com.seeyon.boot.starter.graphql.util.HttpAsyncClient`

```java
    static org.asynchttpclient.AsyncHttpClient getInstance();
    static private static org.asynchttpclient.AsyncHttpClientConfig initConfig();
    static void shutdown();
```

### `DataFetcherExceptionHandlerResult`（3 方法）

`graphql.execution.DataFetcherExceptionHandlerResult`

```java
    java.util.List<graphql.GraphQLError> getErrors();
    static graphql.execution.DataFetcherExceptionHandlerResult$Builder newResult();
    static graphql.execution.DataFetcherExceptionHandlerResult$Builder newResult(graphql.GraphQLError);
```

### `ExecutorServiceExecutionStrategy`（3 方法）

`graphql.execution.ExecutorServiceExecutionStrategy`

```java
    java.util.concurrent.CompletableFuture<graphql.ExecutionResult> execute(graphql.execution.ExecutionContext, graphql.execution.ExecutionStrategyParameters);
```

### `AntlrHelper`（3 方法）

`graphql.parser.AntlrHelper`

```java
    static graphql.language.SourceLocation createSourceLocation(graphql.parser.MultiSourceReader, int, int);
    static graphql.language.SourceLocation createSourceLocation(graphql.parser.MultiSourceReader, antlr.v4.runtime.Token);
    static java.lang.String createPreview(graphql.parser.MultiSourceReader, int);
```

## 三、注解（7）

| 注解 | 元素 |
|---|---|
| `NotNull` |  |
| `Internal` |  |
| `PublicApi` |  |
| `PublicSpi` |  |
| `ThreadSafe` |  |
| `VisibleForTesting` |  |
| `Batched` |  |

## 四、枚举（12）

- `ATNType`（2 常量）：LEXER, PARSER
- `LexerActionType`（8 常量）：CHANNEL, CUSTOM, MODE, MORE, POP_MODE, PUSH_MODE, SKIP, TYPE
- `PredictionMode`（3 常量）：SLL, LL, LL_EXACT_AMBIG_DETECTION
- `HttpStatus`（62 常量）：CONTINUE, SWITCHING_PROTOCOLS, PROCESSING, OK, CREATED, ACCEPTED, NON_AUTHORITATIVE_INFORMATION, NO_CONTENT, RESET_CONTENT, PARTIAL_CONTENT, MULTI_STATUS, ALREADY_REPORTED …
- `ErrorType`（6 常量）：InvalidSyntax, ValidationError, DataFetchingException, NullValueInNonNullableField, OperationNotSupported, ExecutionAborted
- `TypeKind`（7 常量）：Operation, Object, Interface, Union, Enum, Scalar, InputObject
- `DiffCategory`（7 常量）：MISSING, STRICTER, INVALID, ADDITION, DIFFERENT, DEPRECATION_ADDED, DEPRECATION_REMOVED
- `DiffLevel`（3 常量）：INFO, BREAKING, DANGEROUS
- `NaturalEnumValuesProvider`（0 常量）
- `SchemaValidationErrorType`（2 常量）：UnbrokenInputCycle, ObjectDoesNotImplementItsInterfaces
- `TraversalControl`（3 常量）：CONTINUE, QUIT, ABORT
- `ValidationErrorType`（34 常量）：DefaultForNonNullArgument, WrongType, UnknownType, SubSelectionRequired, SubSelectionNotAllowed, InvalidSyntax, BadValueForDefaultArg, FieldUndefined, InlineFragmentTypeConditionInvalid, FragmentTypeConditionInvalid, UnknownArgument, UndefinedFragment …
