# boot-starter-eventbus：接口与方法签名

> 自动生成，勿手改。`tools/core/platform/emit_package_surfaces.py` 重跑即可。
> 构件 `com.seeyon:boot-starter-eventbus`（jar `boot-starter-eventbus-5.3.600.jar`）
> 规模：24 类 / 2 接口 / 2 注解 / 1 枚举 / 3 个关键类 / 190 方法。
> 签名逐字来自 javap 原文；已去掉 `public` 前缀与 `throws` 子句。

## 一、接口（2）

### `SubscriberExceptionHandler`（1 方法）

`com.seeyon.boot.starter.eventbus.core.SubscriberExceptionHandler`

```java
    void handleException(java.lang.Throwable, com.seeyon.boot.starter.eventbus.core.SubscriberExceptionContext);
```

### `GenericEvent`（1 方法）

`com.seeyon.boot.starter.eventbus.interfaces.GenericEvent`

```java
    java.lang.Class<?> getGenericClass();
```

## 二、关键类（3）

### `AbstractPlatformTransactionManager`（52 方法）

`org.springframework.transaction.support.AbstractPlatformTransactionManager`

```java
    final void setTransactionSynchronizationName(java.lang.String);
    final void setTransactionSynchronization(int);
    final int getTransactionSynchronization();
    final void setDefaultTimeout(int);
    final int getDefaultTimeout();
    final void setNestedTransactionAllowed(boolean);
    final boolean isNestedTransactionAllowed();
    final void setValidateExistingTransaction(boolean);
    final boolean isValidateExistingTransaction();
    final void setGlobalRollbackOnParticipationFailure(boolean);
    final boolean isGlobalRollbackOnParticipationFailure();
    final void setFailEarlyOnGlobalRollbackOnly(boolean);
    final boolean isFailEarlyOnGlobalRollbackOnly();
    final void setRollbackOnCommitFailure(boolean);
    final boolean isRollbackOnCommitFailure();
    final org.springframework.transaction.TransactionStatus getTransaction(org.springframework.transaction.TransactionDefinition)
    private org.springframework.transaction.TransactionStatus startTransaction(org.springframework.transaction.TransactionDefinition, java.lang.Object, boolean, org.springframework.transaction.support.AbstractPlatformTransactionManager$SuspendedResourcesHolder);
    private org.springframework.transaction.TransactionStatus handleExistingTransaction(org.springframework.transaction.TransactionDefinition, java.lang.Object, boolean)
    protected final org.springframework.transaction.support.DefaultTransactionStatus prepareTransactionStatus(org.springframework.transaction.TransactionDefinition, java.lang.Object, boolean, boolean, boolean, java.lang.Object);
    protected org.springframework.transaction.support.DefaultTransactionStatus newTransactionStatus(org.springframework.transaction.TransactionDefinition, java.lang.Object, boolean, boolean, boolean, java.lang.Object);
    protected void prepareSynchronization(org.springframework.transaction.support.DefaultTransactionStatus, org.springframework.transaction.TransactionDefinition);
    protected int determineTimeout(org.springframework.transaction.TransactionDefinition);
    protected final org.springframework.transaction.support.AbstractPlatformTransactionManager$SuspendedResourcesHolder suspend(java.lang.Object)
    protected final void resume(java.lang.Object, org.springframework.transaction.support.AbstractPlatformTransactionManager$SuspendedResourcesHolder)
    private void resumeAfterBeginException(java.lang.Object, org.springframework.transaction.support.AbstractPlatformTransactionManager$SuspendedResourcesHolder, java.lang.Throwable);
    private java.util.List<org.springframework.transaction.support.TransactionSynchronization> doSuspendSynchronization();
    private void doResumeSynchronization(java.util.List<org.springframework.transaction.support.TransactionSynchronization>);
    final void commit(org.springframework.transaction.TransactionStatus)
    private void processCommit(org.springframework.transaction.support.DefaultTransactionStatus)
    final void rollback(org.springframework.transaction.TransactionStatus)
    private void processRollback(org.springframework.transaction.support.DefaultTransactionStatus, boolean);
    private void doRollbackOnCommitException(org.springframework.transaction.support.DefaultTransactionStatus, java.lang.Throwable)
    protected final void triggerBeforeCommit(org.springframework.transaction.support.DefaultTransactionStatus);
    protected final void triggerBeforeCompletion(org.springframework.transaction.support.DefaultTransactionStatus);
    private void triggerAfterCommit(org.springframework.transaction.support.DefaultTransactionStatus);
    private void triggerAfterCompletion(org.springframework.transaction.support.DefaultTransactionStatus, int);
    protected final void invokeAfterCompletion(java.util.List<org.springframework.transaction.support.TransactionSynchronization>, int);
    private void cleanupAfterCompletion(org.springframework.transaction.support.DefaultTransactionStatus);
    protected abstract java.lang.Object doGetTransaction()
    protected boolean isExistingTransaction(java.lang.Object)
    protected boolean useSavepointForNestedTransaction();
    protected abstract void doBegin(java.lang.Object, org.springframework.transaction.TransactionDefinition)
    protected java.lang.Object doSuspend(java.lang.Object)
    protected void doResume(java.lang.Object, java.lang.Object)
    protected boolean shouldCommitOnGlobalRollbackOnly();
    protected void prepareForCommit(org.springframework.transaction.support.DefaultTransactionStatus);
    protected abstract void doCommit(org.springframework.transaction.support.DefaultTransactionStatus)
    protected abstract void doRollback(org.springframework.transaction.support.DefaultTransactionStatus)
    protected void doSetRollbackOnly(org.springframework.transaction.support.DefaultTransactionStatus)
    protected void registerAfterCompletionWithExistingTransaction(java.lang.Object, java.util.List<org.springframework.transaction.support.TransactionSynchronization>)
    protected void doCleanupAfterCompletion(java.lang.Object);
    private void readObject(java.io.ObjectInputStream)
```

### `EventBusAutoConfiguration`（3 方法）

`com.seeyon.boot.starter.eventbus.EventBusAutoConfiguration`

```java
    com.seeyon.boot.starter.eventbus.EventBus eventBus();
    void setIsolatorExecutorService(com.seeyon.boot.starter.threadpool.isolator.IsolatorExecutorService);
    void setPlatformTransactionManager(org.springframework.transaction.PlatformTransactionManager);
```

### `DynamicSubscribeProxyService`（3 方法）

`com.seeyon.boot.starter.eventbus.domain.service.DynamicSubscribeProxyService`

```java
    void merge(java.util.List<java.util.Map<java.lang.String, java.lang.Object>>, java.lang.String, java.lang.String);
    void diff(com.seeyon.boot.starter.eventbus.ModuleDiffEvent);
    void moduleRegister(com.seeyon.boot.starter.eventbus.ModuleAllCallbackEvent);
```

## 三、注解（2）

| 注解 | 元素 |
|---|---|
| `EventHandler` |  |
| `EventSubscribe` | threadModel, order |

## 四、枚举（1）

- `ThreadModel`（2 常量）：SYNC, ASYNC
