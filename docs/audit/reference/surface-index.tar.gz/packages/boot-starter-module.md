# boot-starter-module：接口与方法签名

> 自动生成，勿手改。`tools/core/platform/emit_package_surfaces.py` 重跑即可。
> 构件 `com.seeyon:boot-starter-module`（jar `boot-starter-module-5.3.600.jar`）
> 规模：40 类 / 1 接口 / 1 注解 / 2 枚举 / 10 个关键类 / 216 方法。
> 签名逐字来自 javap 原文；已去掉 `public` 前缀与 `throws` 子句。

## 一、接口（1）

### `ModuleEnhanceFilter`（0 方法） extends ModuleEnhanceContext>

`com.seeyon.boot.starter.module.filter.ModuleEnhanceFilter`

```java
```

## 二、关键类（10）

### `ModuleRequestHandler`（20 方法）

`com.seeyon.boot.starter.module.web.ModuleRequestHandler`

```java
    void addParameterInfo(com.seeyon.boot.starter.module.web.ParameterInfo);
    void doProcess(java.lang.String, javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse);
    private java.lang.Object convertParameter(java.lang.String, java.lang.Class<?>, java.lang.Class<?>)
    private java.lang.Object convertType(java.lang.Class, java.lang.String);
    int getParamSize();
    private java.lang.String getBodyData(javax.servlet.http.HttpServletRequest);
    void setController(java.lang.Object);
    void setMethod(java.lang.reflect.Method);
    void setPath(java.lang.String);
    void setRequestMethod(java.lang.String);
    void setPathParams(java.util.List<com.seeyon.boot.starter.module.web.ParameterInfo>);
    void setRequestBodyParam(com.seeyon.boot.starter.module.web.ParameterInfo);
    void setMultiBodyParam(java.util.List<com.seeyon.boot.starter.module.web.ParameterInfo>);
    java.lang.Object getController();
    java.lang.reflect.Method getMethod();
    java.lang.String getPath();
    java.lang.String getRequestMethod();
    java.util.List<com.seeyon.boot.starter.module.web.ParameterInfo> getPathParams();
    com.seeyon.boot.starter.module.web.ParameterInfo getRequestBodyParam();
    java.util.List<com.seeyon.boot.starter.module.web.ParameterInfo> getMultiBodyParam();
```

### `ModuleAppLoadEventHandler`（10 方法）

`com.seeyon.boot.starter.module.event.handler.ModuleAppLoadEventHandler`

```java
    void onModuleAppUnloaded(com.seeyon.boot.loader.ModuleAppLoadEvent);
    void clearValidatorClassCache(com.seeyon.boot.loader.ModuleAppClassLoader);
    java.lang.reflect.Field getField(java.lang.Class<?>, java.lang.String)
    private void clearCachedProviderByClassLoader(javax.persistence.spi.PersistenceProviderResolver, java.lang.ClassLoader);
    private void clearSkyWalkingCache(com.seeyon.boot.loader.ModuleAppClassLoader);
    private synchronized void initSkyWalkingCacheObj();
    void clearDubboClassCache(com.seeyon.boot.loader.ModuleAppClassLoader);
    void afterPropertiesSet()
```

### `ModuleBeanFactory`（9 方法）

`com.seeyon.boot.starter.module.ModuleBeanFactory`

```java
    java.lang.Object getBean(java.lang.String);
    <T> T getBean(java.lang.Class<T>);
    <T> java.util.Map<java.lang.String, T> getBeansOfType(java.lang.Class<T>)
    void registerBean(java.lang.String, java.lang.String, java.lang.Object);
    java.lang.Object[] preInstanceBean(java.lang.String, java.lang.String, java.lang.String, java.lang.Class);
    void populateBean(java.lang.String);
    <T> T getBeanByType(org.springframework.core.ResolvableType);
    void clearModuleAppCache(java.lang.String);
```

### `ModuleDomainServiceMethodInterceptor`（6 方法）

`com.seeyon.boot.starter.module.interceptor.ModuleDomainServiceMethodInterceptor`

```java
    java.lang.Object intercept(java.lang.Object, java.lang.reflect.Method, java.lang.Object[], net.sf.cglib.proxy.MethodProxy)
    private java.lang.String getMethodKey(java.lang.reflect.Method);
    private void scanMethodAndProcess(java.lang.Object);
    private void parseCacheableAnnotation(com.seeyon.boot.starter.module.cache.CacheOperation, org.springframework.cache.annotation.Cacheable, java.lang.reflect.Parameter[]);
    private void parseCachePutAnnotation(com.seeyon.boot.starter.module.cache.CacheOperation, org.springframework.cache.annotation.CachePut, java.lang.reflect.Parameter[]);
    private void parseCacheEvictAnnotation(com.seeyon.boot.starter.module.cache.CacheOperation, org.springframework.cache.annotation.CacheEvict, java.lang.reflect.Parameter[]);
```

### `ModuleUtils`（6 方法）

`com.seeyon.boot.starter.module.util.ModuleUtils`

```java
    static boolean isController(java.lang.Class);
    static boolean isComponent(java.lang.Class);
    static boolean isController(java.lang.Object);
    static org.springframework.beans.factory.config.BeanDefinition buildBeanDefinition(java.lang.Class);
    static java.lang.String buildBeanName(java.lang.Class, boolean);
    static java.lang.String prettyStopWatchInfo(org.springframework.util.StopWatch);
```

### `ModuleLockUtils`（4 方法）

`com.seeyon.boot.starter.module.util.ModuleLockUtils`

```java
    static void lock(java.lang.String);
    static void unlock(java.lang.String);
    static boolean isLocked(java.lang.String);
    static int getQueueLength(java.lang.String);
```

### `ModuleDependencyManager`（3 方法）

`com.seeyon.boot.starter.module.ModuleDependencyManager`

```java
    static synchronized void register(java.lang.String, java.lang.String);
    static synchronized void unregister(java.lang.String, java.lang.String);
    static java.util.Set<java.lang.String> getDependencyApps(java.lang.String);
```

### `ModuleAppServiceMethodInterceptor`（3 方法）

`com.seeyon.boot.starter.module.interceptor.ModuleAppServiceMethodInterceptor`

```java
    java.lang.Object intercept(java.lang.Object, java.lang.reflect.Method, java.lang.Object[], net.sf.cglib.proxy.MethodProxy)
    private java.lang.String getMethodKey(java.lang.reflect.Method);
    private void scanMethodAndProcess(java.lang.Object);
```

### `ModuleProcessorHandler`（3 方法）

`com.seeyon.boot.starter.module.processor.ModuleProcessorHandler`

```java
    void initialize(com.seeyon.boot.loader.ModuleAppClassLoader);
    void destroy(java.lang.String);
```

### `ModuleRequestHandlerMappping`（3 方法）

`com.seeyon.boot.starter.module.web.ModuleRequestHandlerMappping`

```java
    void registerHandler(java.lang.String, com.seeyon.boot.starter.module.web.ModuleRequestHandler);
    com.seeyon.boot.starter.module.web.ModuleRequestHandler detectHandler(java.lang.String, java.lang.String);
    void clearCache(java.lang.String);
```

## 三、注解（1）

| 注解 | 元素 |
|---|---|
| `ModuleEnhance` |  |

## 四、枚举（2）

- `CacheOperationType`（3 常量）：CACHEABLE, PUT, EVICT
- `ParameterType`（3 常量）：MULTI_BODY, REQUEST_BODY, PATH_VARIABLE
