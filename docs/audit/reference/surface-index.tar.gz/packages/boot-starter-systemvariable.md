# boot-starter-systemvariable：接口与方法签名

> 自动生成，勿手改。`tools/core/platform/emit_package_surfaces.py` 重跑即可。
> 构件 `com.seeyon:boot-starter-systemvariable`（jar `boot-starter-systemvariable-5.3.603.jar`）
> 规模：4 类 / 0 接口 / 0 注解 / 1 枚举 / 2 个关键类 / 147 方法。
> 签名逐字来自 javap 原文；已去掉 `public` 前缀与 `throws` 子句。

## 一、接口（0）

（本构件没有接口）

## 二、关键类（2）

### `SystemVariableUtils`（126 方法）

`com.seeyon.boot.starter.systemvariable.util.SystemVariableUtils`

```java
    static private static synchronized com.seeyon.boot.starter.systemvariable.service.SystemVariableService getSystemVariableService();
    static java.lang.Long currentUserId();
    static java.lang.Long rootInstitutionId();
    static java.lang.String rootInstitutionName();
    static java.lang.String rootInstitutionCode();
    static java.lang.String currentUserName();
    static java.lang.String currentUserType();
    static java.lang.String currentUserCode();
    static java.lang.String currentUserLoginName();
    static java.lang.Long currentOrgId();
    static private static <T> java.util.List<T> getCurrentMultiOrgInfo(java.lang.String);
    static java.util.List<java.lang.Long> currentMultiOrgId();
    static java.util.List<java.lang.String> currentMultiOrgCode();
    static java.util.List<java.lang.String> currentMultiOrgName();
    static java.util.List<java.lang.Long> currentMultiOrgDepartmentId();
    static java.util.List<java.lang.String> currentMultiOrgDepartmentCode();
    static java.util.List<java.lang.String> currentMultiOrgDepartmentName();
    static java.util.List<java.lang.Long> currentMultiOrgDepartmentParentId();
    static java.util.List<java.lang.String> currentMultiOrgDepartmentParentCode();
    static java.util.List<java.lang.String> currentMultiOrgDepartmentParentName();
    static java.util.List<java.lang.Long> currentMultiOrgDepartmentFirstId();
    static java.util.List<java.lang.String> currentMultiOrgDepartmentFirstCode();
    static java.util.List<java.lang.String> currentMultiOrgDepartmentFirstName();
    static java.util.List<java.lang.Long> currentMultiOrgDepartmentResponsibleId();
    static java.util.List<java.lang.String> currentMultiOrgDepartmentResponsibleCode();
    static java.util.List<java.lang.String> currentMultiOrgDepartmentResponsibleName();
    static java.util.List<java.lang.Long> currentMultiOrgDepartmentDivideId();
    static java.util.List<java.lang.String> currentMultiOrgDepartmentDivideCode();
    static java.util.List<java.lang.String> currentMultiOrgDepartmentDivideName();
    static java.util.List<java.lang.Long> currentMultiOrgDepartmentResponsibleDepartmentId();
    static java.util.List<java.lang.String> currentMultiOrgDepartmentResponsibleDepartmentCode();
    static java.util.List<java.lang.String> currentMultiOrgDepartmentResponsibleDepartmentName();
    static java.util.List<java.lang.Long> currentMultiOrgDepartmentDivideDepartmentId();
    static java.util.List<java.lang.String> currentMultiOrgDepartmentDivideDepartmentCode();
    static java.util.List<java.lang.String> currentMultiOrgDepartmentDivideDepartmentName();
    static java.lang.String currentOrgName();
    static java.lang.String currentOrgCode();
    static java.lang.Long currentFirstLevelOrgId();
    static java.lang.String currentFirstLevelOrgName();
    static java.lang.String currentFirstLevelOrgCode();
    static private static <T> java.util.List<T> getCurrentOrgInfo(java.lang.String);
    static java.util.List<java.lang.Long> currentAllParentOrgId();
    static java.util.List<java.lang.String> currentAllParentOrgName();
    static java.util.List<java.lang.String> currentAllParentOrgCode();
    static java.lang.Long currentParentOrgId();
    static java.lang.String currentParentOrgName();
    static java.lang.String currentParentOrgCode();
    static java.util.List<java.lang.Long> currentMemberPostOrgIds();
    static java.util.List<java.lang.String> currentMemberPostOrgNames();
    static java.util.List<java.lang.String> currentMemberPostOrgCodes();
    static java.util.List<java.lang.Long> currentMemberPostPartTimeOrgIds();
    static java.util.List<java.lang.String> currentMemberPostPartTimeOrgNames();
    static java.util.List<java.lang.String> currentMemberPostPartTimeOrgCodes();
    static java.util.List<java.lang.Long> currentMemberPostInstitutionIds();
    static java.util.List<java.lang.String> currentMemberPostInstitutionNames();
    static java.util.List<java.lang.String> currentMemberPostInstitutionCodes();
    static java.util.List<java.lang.Long> currentMemberPostPartTimeInstitutionIds();
    static java.util.List<java.lang.String> currentMemberPostPartTimeInstitutionNames();
    static java.util.List<java.lang.String> currentMemberPostPartTimeInstitutionCodes();
    static java.util.List<java.lang.Long> currentManagerDepartmentIds();
    static java.util.List<java.lang.String> currentManagerDepartmentNames();
    static java.util.List<java.lang.String> currentManagerDepartmentCodes();
    static java.util.List<java.lang.Long> currentLeaderDepartmentIds();
    static java.util.List<java.lang.String> currentLeaderDepartmentNames();
    static java.util.List<java.lang.String> currentLeaderDepartmentCodes();
    static java.util.List<java.lang.Long> currentManagerInstitutionIds();
    static java.util.List<java.lang.String> currentManagerInstitutionNames();
    static java.util.List<java.lang.String> currentManagerInstitutionCodes();
    static java.util.List<java.lang.Long> currentLeaderInstitutionIds();
    static java.util.List<java.lang.String> currentLeaderInstitutionNames();
    static java.util.List<java.lang.String> currentLeaderInstitutionCodes();
    static java.lang.Long currentLegalOrgId();
    static java.lang.Long currentPostId();
    static java.lang.String currentPostName();
    static java.lang.String currentPostCode();
    static java.lang.Long currentJobId();
    static java.lang.String currentJobName();
    static java.lang.String currentJobCode();
    static java.lang.Long currentLevelId();
    static java.lang.String currentLevelName();
    static java.lang.String currentLevelCode();
    static java.lang.Long currentInstitutionId();
    static java.lang.String currentInstitutionName();
    static java.lang.String currentInstitutionCode();
    static java.lang.String currentInstitutionLogo();
    static java.util.List<java.lang.Long> currentInstitutionPath();
    static java.util.List<java.lang.Long> currentParentInstitutionIds();
    static java.util.List<java.lang.String> currentParentInstitutionNames();
    static java.util.List<java.lang.String> currentParentInstitutionCodes();
    static java.lang.Integer currentSecretLevel();
    static java.lang.Long currentSecretLevelId();
    static java.lang.Long currentMemberPostId();
    static java.lang.Long loginMemberPostId();
    static java.util.List<java.lang.Long> currentPostIds();
    static java.util.List<java.lang.String> currentPostCodes();
    static java.util.List<java.lang.String> currentPostNames();
    static java.util.List<java.lang.Long> currentPartTimePostIds();
    static java.util.List<java.lang.String> currentPartTimePostCodes();
    static java.util.List<java.lang.String> currentPartTimePostNames();
    static java.util.List<java.lang.Long> currentMemberOrgRoleIds();
    static java.util.List<java.lang.String> currentMemberOrgRoleCodes();
    static java.util.Map<java.lang.String, java.lang.Object> loginMemberPost();
    static java.lang.Long loginDepartmentId();
    static java.lang.String loginDepartmentCode();
    static java.lang.String loginDepartmentName();
    static java.lang.Long loginPostId();
    static java.lang.String loginPostCode();
    static java.lang.String loginPostName();
    static java.lang.Long loginJobId();
    static java.lang.String loginJobCode();
    static java.lang.String loginJobName();
    static java.lang.Long loginLevelId();
    static java.lang.String loginLevelCode();
    static java.lang.String loginLevelName();
    static java.lang.Long loginInstitutionId();
    static java.lang.String loginInstitutionCode();
    static java.lang.String loginInstitutionLogo();
    static java.lang.String loginInstitutionName();
    static java.lang.Long loginFirstLevelDepartmentId();
    static java.lang.String loginFirstLevelDepartmentCode();
    static java.lang.String loginFirstLevelDepartmentName();
    static java.lang.Long loginParentDepartmentId();
    static java.lang.String loginParentDepartmentCode();
    static java.lang.String loginParentDepartmentName();
    static java.lang.Long loginCurrentMemberIdInfo(java.lang.String);
    static private static java.lang.String loginCurrentMemberInfo(java.lang.String);
```

### `SystemVariableService`（13 方法）

`com.seeyon.boot.starter.systemvariable.service.SystemVariableService`

```java
    java.lang.Long getCurrentUserId();
    java.lang.Long getCurrentOrgId();
    java.util.Map<java.lang.String, java.lang.Object> getUserInfo();
    java.util.Map<java.lang.String, java.lang.Object> getMemberMultiDimOrgInfo();
    java.util.Map<java.lang.String, java.lang.Object> getMemberInfo();
    java.util.Map<java.lang.String, java.lang.Object> getMemberExtendInfo();
    private java.util.Map<java.lang.String, java.lang.Object> getSimulationInfo();
    java.util.Map<java.lang.String, java.lang.Object> getCurrentOrgInfo();
    java.util.Map<java.lang.Long, java.util.Map<java.lang.String, java.util.List>> getCurrentDepartmentMemberInfo();
    java.util.Map<java.lang.Long, java.util.Map<java.lang.String, java.util.List>> getCurrentInstitutionMemberInfo();
    java.lang.Long getCurrentLegalOrgId();
    java.util.List<java.lang.Long> getOrgPath();
```

## 四、枚举（1）

- `SystemVariableKeyEnum`（9 常量）：CURRENT_MULTI_ORG, CURRENT_MULTI_ORG_DEPARTMENT, CURRENT_MULTI_ORG_DEPARTMENT_PARENT, CURRENT_MULTI_ORG_DEPARTMENT_FIRST, CURRENT_MULTI_ORG_RESPONSIBLE, CURRENT_MULTI_ORG_DIVIDE, CURRENT_MULTI_ORG_RESPONSIBLE_DEPARTMENT, CURRENT_MULTI_ORG_DIVIDE_DEPARTMENT, CURRENT_ALL_PARENT_ORG
