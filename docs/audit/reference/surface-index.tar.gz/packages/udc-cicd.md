# udc-cicd：接口与方法签名

> 自动生成，勿手改。`tools/core/platform/emit_package_surfaces.py` 重跑即可。
> 构件 `com.seeyon:udc-cicd`（jar `udc-cicd-5.3.517.jar`）
> 规模：65 类 / 8 接口 / 2 注解 / 4 枚举 / 20 个关键类 / 635 方法。
> 签名逐字来自 javap 原文；已去掉 `public` 前缀与 `throws` 子句。

## 一、接口（8）

### `DeployService`（12 方法）

`com.seeyon.udc.pipeline.DeployService`

```java
    com.seeyon.udc.common.enums.ApplicationSourceEnum getAppType();
    void start(com.seeyon.udc.pipeline.context.PipeLineContext);
    boolean doCreateRecord(com.seeyon.udc.pipeline.context.PipeLineContext);
    boolean doCheck(com.seeyon.udc.pipeline.context.PipeLineContext);
    boolean doGenerateCode(com.seeyon.udc.pipeline.context.PipeLineContext);
    com.seeyon.devops.starter.pipeline.dto.BuildParamDto doHandleParam(com.seeyon.udc.pipeline.context.PipeLineContext);
    void doDeploy(com.seeyon.udc.pipeline.context.PipeLineContext);
    void doDeltaDeploy(com.seeyon.udc.pipeline.context.PipeLineContext);
    boolean doOnline(com.seeyon.udc.pipeline.context.PipeLineContext);
    void doDefaultException(com.seeyon.udc.pipeline.context.PipeLineContext, java.lang.Throwable);
    void handlingException(com.seeyon.udc.pipeline.context.PipeLineContext, java.lang.Exception);
    void doParallel(com.seeyon.udc.pipeline.context.PipeLineContext);
```

### `QueryAppService`（4 方法）

`com.seeyon.udc.query.QueryAppService`

```java
    java.util.List<com.seeyon.udc.common.dto.ApplicationDto> selectByIds(java.util.List<java.lang.Long>);
    com.seeyon.udc.common.dto.ApplicationDto selectById(java.lang.Long);
    com.seeyon.udc.common.dto.AppVersionDto selectByAppIdAndDeployType(java.lang.Long, com.seeyon.udc.common.enums.DeployTypeEnum);
    boolean updateApplication(com.seeyon.udc.common.dto.ApplicationDto);
```

### `PipeLineService`（3 方法）

`com.seeyon.udc.pipeline.PipeLineService`

```java
    java.util.concurrent.CompletableFuture<com.seeyon.udc.pipeline.context.PipeLineContext> startPipeline(com.seeyon.udc.pipeline.context.PipeLineContext);
    java.util.concurrent.CompletableFuture<com.seeyon.udc.pipeline.context.PipeLineContext> startDeltaPipeline(com.seeyon.udc.pipeline.context.PipeLineContext);
    java.util.concurrent.CompletableFuture<com.seeyon.udc.pipeline.context.PipeLineContext> startOnlinePipeline(com.seeyon.udc.pipeline.context.PipeLineContext);
```

### `LogService`（2 方法）

`com.seeyon.udc.log.LogService`

```java
    com.seeyon.udc.deploy.enums.LogTypeEnum getLogType();
    java.util.List<java.lang.String> getLogs(java.lang.String, int, long, long, java.lang.String);
```

### `ChannelPlugin`（1 方法）

`com.seeyon.udc.pipeline.ChannelPlugin`

```java
    R execute(com.seeyon.udc.pipeline.context.PipeLineContext);
```

### `MigrateCallback`（1 方法）

`com.seeyon.udc.repo.MigrateCallback`

```java
    boolean extendFilesHandle(java.util.Collection<java.io.File>);
```

### `TaskCallable`（1 方法）

`com.seeyon.udc.task.TaskCallable`

```java
    void call(T);
```

### `DeployRecordDao`（0 方法） extends DeployRecord>

`com.seeyon.udc.deploy.domain.dao.DeployRecordDao`

```java
```

## 二、关键类（20）

### `DeployRecordService`（54 方法）

`com.seeyon.udc.deploy.domain.service.DeployRecordService`

```java
    java.lang.Long create(com.seeyon.udc.common.dto.DeployRecordDto);
    boolean createBatch(java.util.List<com.seeyon.udc.common.dto.DeployRecordDto>);
    java.util.List<com.seeyon.udc.common.dto.DeployRecordDto> searchStatus(java.lang.Long);
    int count(java.lang.Long, com.seeyon.udc.common.enums.DeployTypeEnum);
    com.seeyon.udc.deploy.domain.entity.DeployRecord getLastSuccessRecord(java.lang.Long, com.seeyon.udc.common.enums.DeployTypeEnum);
    java.lang.Long getExpectedBuildTime(java.lang.Long, com.seeyon.udc.common.enums.DeployTypeEnum);
    java.util.Map<java.lang.String, java.lang.Object> statistics(java.lang.Long);
    com.seeyon.udc.common.dto.DeployRecordDto getLastSchemaRecord(java.lang.Long);
    com.seeyon.udc.common.dto.DeployRecordDto getLastSchemaRecord(com.seeyon.udc.common.dto.ApplicationDto);
    private com.seeyon.udc.common.dto.DeployRecordDto getLastSchemaRecord(java.lang.Long, java.lang.String);
    com.seeyon.udc.common.dto.DeployRecordDto buildDeployRecord(com.seeyon.udc.pipeline.context.PipeLineContext);
    com.seeyon.udc.deploy.domain.entity.DeployRecord selectLastSchemaRecordByAppVersoinModeOss(java.lang.Long, java.lang.String);
    private com.seeyon.udc.deploy.domain.entity.DeployRecord getDeployRecordByAppVersionSort(com.seeyon.boot.domain.dao.Wrapper);
    com.seeyon.udc.deploy.domain.entity.DeployRecord selectLastSuccessRecord(long, com.seeyon.udc.common.enums.DeployTypeEnum);
    java.util.List<com.seeyon.udc.deploy.domain.entity.DeployRecord> selectRecordByCreateTime(long);
    java.util.Optional<com.seeyon.udc.deploy.domain.entity.DeployRecord> selectLatestRecordByCreateTime(java.lang.Long, java.util.Date);
    java.lang.Integer countCurrentVersionDeployTimes(java.lang.Long, java.lang.String);
    com.seeyon.udc.common.dto.DeployVersionDto getNextVersion(com.seeyon.udc.common.dto.ApplicationDto);
    private java.lang.String computeNextVersion(com.seeyon.udc.common.dto.ApplicationDto, java.lang.Integer);
    java.util.List<com.seeyon.udc.deploy.domain.entity.DeployRecord> selectLastNRecordByAppId(long, com.seeyon.udc.common.enums.DeployTypeEnum, int);
    java.util.List<com.seeyon.udc.deploy.domain.entity.DeployRecord> selectClearRecordByAppId(long, com.seeyon.udc.common.enums.DeployTypeEnum, int);
    com.seeyon.udc.deploy.domain.entity.DeployRecord selectByDeployId(long);
    java.util.List<com.seeyon.udc.deploy.domain.entity.DeployRecord> selectByDeployIdNoCache(long);
    java.lang.Long selectLatestDeployId(long, java.lang.String, com.seeyon.udc.common.enums.DeployTypeEnum);
    com.seeyon.udc.common.dto.DeployRecordDto selectRecordDtoByDeployId(long);
    private com.seeyon.boot.domain.dao.Wrapper getDeployIdWrapper(java.lang.Long);
    boolean updateStorageKey(com.seeyon.udc.common.dto.DeployRecordDto);
    boolean updateSqlStorageKey(com.seeyon.udc.common.dto.DeployRecordDto);
    java.util.List<com.seeyon.udc.deploy.domain.entity.DeployRecord> selectListByConditions(java.util.Map);
    com.seeyon.udc.deploy.domain.entity.DeployRecord selectPageByConditions(java.lang.String, java.lang.String, com.seeyon.udc.common.enums.DeployTypeEnum);
    boolean updateTag(com.seeyon.udc.deploy.domain.entity.DeployRecord);
    boolean updateState(java.util.List<com.seeyon.udc.deploy.domain.entity.DeployRecord>);
    void updateState(com.seeyon.udc.common.dto.DeployRecordDto);
    private void setDeployRecordMessage(com.seeyon.udc.common.dto.DeployRecordDto, com.seeyon.udc.deploy.domain.entity.DeployRecord);
    java.lang.Integer updateTagAndSchemaMd5(com.seeyon.udc.common.dto.DeployRecordDto);
    void deleteById(java.lang.Long);
    int deleteByAppId(java.lang.Long);
    int deleteByDeployId(java.lang.Long);
    java.util.List<com.seeyon.udc.deploy.domain.entity.DeployRecord> selectLessThanTime(java.util.Date, com.seeyon.udc.common.enums.ApplicationSourceEnum, com.seeyon.udc.common.enums.DeployBusinessTypeEnum, java.util.List<com.seeyon.udc.common.enums.DeployStateEnum>);
    com.seeyon.boot.transport.PageData<com.seeyon.udc.common.dto.DeployRecordDto> selectPageByConditions(com.seeyon.boot.transport.PageInfo, java.util.Map<java.lang.String, java.lang.Object>, com.seeyon.boot.transport.Sort);
    java.util.List<com.seeyon.udc.deploy.domain.entity.DeployRecord> selectDeployRecordByGuid(java.lang.Long, java.lang.String);
    void updateNodeVersionValue(java.lang.Long, java.lang.String);
```

### `UdcRepoManager`（27 方法）

`com.seeyon.udc.repo.UdcRepoManager`

```java
    com.seeyon.devops.starter.repo.RepoService getRepoService();
    java.lang.String getBaseLocalPath();
    java.lang.String buildLocalPath(java.lang.Long, com.seeyon.udc.common.enums.ProjectTypeEnum);
    java.lang.String buildLocalPathMore(java.lang.String, java.lang.String...);
    java.lang.String buildHostAppJarPath(java.lang.String);
    boolean initRepository(java.lang.String, com.seeyon.udc.common.dto.DeployInfoDto);
    boolean initExtendRepository(java.lang.String, com.seeyon.udc.common.dto.DeployInfoDto);
    boolean initRemoteRepo(com.seeyon.udc.common.dto.DeployInfoDto);
    boolean existRemoteRepo(com.seeyon.udc.common.dto.DeployInfoDto);
    boolean pullRepository(java.lang.String, com.seeyon.udc.common.dto.DeployInfoDto);
    boolean pushRepository(java.lang.String, com.seeyon.udc.common.dto.DeployInfoDto)
    boolean createRemoteBranch(java.lang.String, java.lang.String, java.lang.String);
    boolean deleteRepository(com.seeyon.udc.common.dto.DeployInfoDto);
    boolean refreshLocalRepoFiles(com.seeyon.udc.common.dto.ApplicationDto, java.lang.String, com.seeyon.udc.common.enums.ProjectTypeEnum);
    boolean clearLocalAllFiles(java.lang.String);
    byte[] getSchemaFile(java.lang.Long)
    boolean getSqlFile(java.lang.String, com.seeyon.udc.common.dto.DeploySchemeInfoDto, com.seeyon.udc.common.enums.ProjectTypeEnum, com.seeyon.udc.common.dto.ApplicationDto);
    private java.lang.String getLocalSchemaMd5(java.lang.String, com.seeyon.udc.common.dto.DeployInfoDto);
    boolean migrateAppReop(com.seeyon.udc.common.dto.ApplicationDto, com.seeyon.udc.common.dto.ApplicationDto, com.seeyon.udc.repo.MigrateCallback);
    java.util.Collection<java.io.File> pullExtendCodeFromRepo(com.seeyon.udc.common.dto.ApplicationDto, java.lang.String, com.seeyon.udc.common.enums.ProjectTypeEnum);
    boolean pushExtendCode2Repo(com.seeyon.udc.common.dto.ApplicationDto, java.lang.String);
    com.seeyon.devops.starter.repo.dto.AppInfoDto buildAppInfo(com.seeyon.udc.common.dto.DeployInfoDto);
```

### `PipeLineManager`（20 方法）

`com.seeyon.udc.pipeline.PipeLineManager`

```java
    com.seeyon.udc.deploy.config.DeployProperties getDeployProperties();
    void afterSingletonsInstantiated();
    void deployPipeline(com.seeyon.udc.pipeline.context.PipeLineContext);
    java.util.concurrent.CompletableFuture<com.seeyon.udc.pipeline.context.PipeLineContext> deployPipeline(com.seeyon.udc.pipeline.context.PipeLineContext, boolean);
    java.util.concurrent.CompletableFuture<com.seeyon.udc.pipeline.context.PipeLineContext> deployAsync(com.seeyon.udc.pipeline.context.PipeLineContext);
    com.seeyon.udc.pipeline.context.PipeLineContext buildContext(com.seeyon.udc.common.dto.ApplicationDto, com.seeyon.udc.common.dto.DeployInfoDto);
    com.seeyon.udc.common.dto.AppDeployInfo buildAppDeltaDeployInfo(com.seeyon.udc.common.dto.ApplicationDto, com.seeyon.udc.common.dto.DeployInfoDto);
    com.seeyon.udc.common.dto.AppDeployInfo buildAppLastDeployInfo(com.seeyon.udc.common.dto.ApplicationDto, com.seeyon.udc.common.dto.DeployInfoDto);
    com.seeyon.udc.common.dto.AppDeployInfo buildAppDeployInfo(com.seeyon.udc.common.dto.ApplicationDto, com.seeyon.udc.common.dto.DeployInfoDto);
    java.lang.String getMetadataUrl(java.lang.String, java.lang.String);
    private void doInterceptParam(com.seeyon.udc.pipeline.context.PipeLineContext);
    java.util.concurrent.CompletableFuture<com.seeyon.udc.pipeline.context.PipeLineContext> startPipeline(com.seeyon.udc.pipeline.context.PipeLineContext);
    java.util.concurrent.CompletableFuture<com.seeyon.udc.pipeline.context.PipeLineContext> startOnlinePipeline(com.seeyon.udc.pipeline.context.PipeLineContext);
    java.util.concurrent.CompletableFuture<com.seeyon.udc.pipeline.context.PipeLineContext> startDeltaPipeline(com.seeyon.udc.pipeline.context.PipeLineContext);
    private void checkFormDeployNum(com.seeyon.udc.common.dto.ApplicationDto);
```

### `AbstractDeployService`（18 方法）

`com.seeyon.udc.pipeline.AbstractDeployService`

```java
    void refreshedContext(com.seeyon.udc.pipeline.context.PipeLineContext, com.seeyon.udc.common.dto.ApplicationDto);
    void refreshedContextWithListener(com.seeyon.udc.pipeline.context.PipeLineContext, com.seeyon.udc.common.dto.ApplicationDto);
    boolean doCreateRecord(com.seeyon.udc.pipeline.context.PipeLineContext);
    boolean doDefaultCheck(com.seeyon.udc.pipeline.context.PipeLineContext);
    com.seeyon.devops.starter.pipeline.dto.BuildParamDto buildDefaultParam(com.seeyon.udc.pipeline.context.PipeLineContext);
    java.lang.String uploadMetadata2Obs(java.lang.String, java.lang.String);
    java.lang.String uploadDetlaMetadata2Obs(java.lang.String, java.lang.String, java.lang.String);
    java.lang.String zipMetadataUpload(java.lang.String, java.lang.String, java.lang.String);
    java.lang.String getMetadataUrl(java.lang.String, java.lang.String);
    void doParallel(com.seeyon.udc.pipeline.context.PipeLineContext);
    void doDefaultException(com.seeyon.udc.pipeline.context.PipeLineContext, java.lang.Throwable);
    private void stopDeployEvent(com.seeyon.udc.common.dto.ApplicationDto, java.lang.String);
    <T> T callLogWrapper(com.seeyon.udc.pipeline.context.PipeLineContext, com.seeyon.devops.starter.pipeline.enums.PipelineTestStepEnum, java.util.concurrent.Callable<T>);
    static private static java.lang.Object $deserializeLambda$(java.lang.invoke.SerializedLambda);
```

### `NormalDeployService`（16 方法）

`com.seeyon.udc.pipeline.impl.NormalDeployService`

```java
    com.seeyon.udc.common.enums.ApplicationSourceEnum getAppType();
    void start(com.seeyon.udc.pipeline.context.PipeLineContext);
    boolean doCheck(com.seeyon.udc.pipeline.context.PipeLineContext);
    boolean doGenerateCode(com.seeyon.udc.pipeline.context.PipeLineContext);
    com.seeyon.devops.starter.pipeline.dto.BuildParamDto doHandleParam(com.seeyon.udc.pipeline.context.PipeLineContext);
    void doDeploy(com.seeyon.udc.pipeline.context.PipeLineContext);
    void doDeltaDeploy(com.seeyon.udc.pipeline.context.PipeLineContext);
    private com.seeyon.devops.starter.pipeline.dto.BuildParamDto doHandleDeltaParam(com.seeyon.udc.pipeline.context.PipeLineContext);
    boolean doOnline(com.seeyon.udc.pipeline.context.PipeLineContext);
    void handlingException(com.seeyon.udc.pipeline.context.PipeLineContext, java.lang.Exception);
```

### `FormDeployService`（13 方法）

`com.seeyon.udc.pipeline.impl.FormDeployService`

```java
    com.seeyon.udc.common.enums.ApplicationSourceEnum getAppType();
    void start(com.seeyon.udc.pipeline.context.PipeLineContext);
    boolean doCheck(com.seeyon.udc.pipeline.context.PipeLineContext);
    boolean doGenerateCode(com.seeyon.udc.pipeline.context.PipeLineContext);
    com.seeyon.devops.starter.pipeline.dto.BuildParamDto doHandleParam(com.seeyon.udc.pipeline.context.PipeLineContext);
    void doDeploy(com.seeyon.udc.pipeline.context.PipeLineContext);
    void doDeltaDeploy(com.seeyon.udc.pipeline.context.PipeLineContext);
    boolean doOnline(com.seeyon.udc.pipeline.context.PipeLineContext);
    void handlingException(com.seeyon.udc.pipeline.context.PipeLineContext, java.lang.Exception);
```

### `SchemaSqlService`（13 方法）

`com.seeyon.udc.repo.SchemaSqlService`

```java
    java.lang.String getBaseDir();
    private java.lang.String uploadSchema(java.lang.String, com.seeyon.udc.common.dto.DeployInfoDto);
    byte[] getSchemaFile(com.seeyon.udc.common.dto.DeployRecordDto)
    private java.lang.String uploadSql(java.lang.String, com.seeyon.udc.common.dto.DeployInfoDto);
    boolean getSqlFile(java.lang.String, java.lang.String, com.seeyon.udc.common.dto.ApplicationDto)
    boolean uploadStorageKey(java.lang.String, com.seeyon.udc.common.dto.DeployInfoDto);
    void updateNodeVersionValue(java.lang.Long, java.lang.String);
```

### `ClearRecordService`（9 方法）

`com.seeyon.udc.deploy.ClearRecordService`

```java
    boolean callback(com.seeyon.udc.dto.DeployCallbackDto);
    private void clearRecord(com.seeyon.udc.common.dto.ApplicationDto);
    private void deleteImage(java.lang.String);
    private void deleteStorageKey(com.seeyon.udc.deploy.domain.entity.DeployRecord, java.util.List<java.lang.String>);
```

### `TransportExtCodeHandler`（9 方法）

`com.seeyon.udc.repo.extcode.TransportExtCodeHandler`

```java
    void transport(com.seeyon.udc.common.dto.ExtCodeReplaceParamDto, java.io.File);
    private void transportFrontendExtCode(com.seeyon.udc.common.dto.ExtCodeReplaceParamDto, java.io.File);
    private void transportBackendExtCode(com.seeyon.udc.common.dto.ExtCodeReplaceParamDto, java.io.File);
    private org.apache.commons.lang3.tuple.MutablePair<java.lang.String[], java.lang.String[]> prepareReplacement(com.seeyon.udc.common.dto.ExtCodeReplaceParamDto);
    private java.io.File replace(java.io.File, java.lang.String[], java.lang.String[]);
    private void replaceCodeFile(java.io.File, java.lang.String[], java.lang.String[]);
    private java.lang.String ifReplacePom(java.lang.String, java.lang.String);
    private void renameDir(java.io.File, java.lang.String[], java.lang.String[]);
```

### `ExtCodeRepositoryService`（8 方法）

`com.seeyon.udc.repo.extcode.ExtCodeRepositoryService`

```java
    void initAndPushFrontendExtRepository(com.seeyon.udc.common.dto.ExtCodeReplaceParamDto, java.lang.String);
    void initAndPushBackendExtRepository(com.seeyon.udc.common.dto.ExtCodeReplaceParamDto, java.lang.String);
    private void checkExtCodeBranch(com.seeyon.udc.common.dto.DeployInfoDto);
    private com.seeyon.udc.common.dto.DeployInfoDto buildDeployInfo(com.seeyon.udc.common.enums.ProjectTypeEnum, com.seeyon.udc.common.dto.ExtCodeReplaceParamDto);
    private void pushRepository(java.lang.String, com.seeyon.udc.common.dto.DeployInfoDto)
    java.lang.String pushRepositoryInternal(java.lang.String, com.seeyon.udc.common.dto.DeployInfoDto)
```

### `DeployAppService`（7 方法）

`com.seeyon.udc.deploy.appservice.DeployAppService`

```java
    com.seeyon.boot.transport.ListResponse<com.seeyon.udc.common.dto.DeployRecordDto> searchStatus(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.PageResponse<com.seeyon.udc.common.dto.DeployRecordDto> selectPageByConditions(com.seeyon.boot.transport.PageInfo, java.util.Map<java.lang.String, java.lang.Object>, com.seeyon.boot.transport.Sort);
    com.seeyon.boot.transport.SingleResponse<java.lang.Boolean> deployStop(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.udc.common.dto.DeployRecordDto> selectPageByAppName(com.seeyon.boot.transport.SingleRequest<java.lang.String>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Boolean> registerJarFromRemoteMaven(com.seeyon.boot.transport.SingleRequest<com.seeyon.devops.starter.artifact.dto.ArtifactDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Long> expectDeployTime(com.seeyon.boot.transport.SingleRequest<com.seeyon.udc.common.dto.DeployParamDto>);
    com.seeyon.boot.transport.SingleResponse<java.util.Map<java.lang.String, java.lang.Object>> statistics(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
```

### `DataAwareService`（6 方法）

`com.seeyon.udc.dataaware.DataAwareService`

```java
    void updateChange(java.lang.Object, java.util.Date);
    java.util.Date searchChange(java.lang.Long);
    java.util.List<java.util.Date> multiGet(java.util.List<java.lang.Long>);
    java.util.Map<java.lang.String, java.util.Date> multiGetAll();
    void delete(java.lang.String);
    void putAll(java.util.Map<java.lang.String, java.util.Date>);
```

### `CustomService`（5 方法）

`com.seeyon.udc.flow.custom.CustomService`

```java
    boolean deploy(com.seeyon.udc.pipeline.context.PipeLineContext);
    java.lang.Long deploy(com.seeyon.udc.flow.dto.CustomFlowParamDto);
```

### `SLSService`（4 方法）

`com.seeyon.udc.log.sls.SLSService`

```java
    com.seeyon.udc.deploy.enums.LogTypeEnum getLogType();
    java.util.List<java.lang.String> getLogs(java.lang.String, int, long, long, java.lang.String);
    private void init();
```

### `UnZipUtils`（4 方法）

`com.seeyon.udc.utils.UnZipUtils`

```java
    static java.io.File unZipToDir(java.io.InputStream, java.lang.String, java.lang.String);
    static java.io.File unzip(java.util.zip.ZipInputStream, java.io.File)
    static void read(java.util.zip.ZipInputStream, java.util.function.Consumer<java.util.zip.ZipEntry>);
```

### `LogManager`（3 方法）

`com.seeyon.udc.log.LogManager`

```java
    java.util.List<java.lang.String> getLogs(com.seeyon.udc.log.dto.LogPullDto);
    void afterPropertiesSet()
```

### `TransferExtCodeHandler`（3 方法）

`com.seeyon.udc.repo.extcode.TransferExtCodeHandler`

```java
    void transfer(java.io.File, com.seeyon.udc.common.dto.ExtCodeReplaceParamDto);
    private void transferFrontendExtCode(java.io.File, com.seeyon.udc.common.dto.ExtCodeReplaceParamDto);
    private void transferBackendExtCode(java.io.File, com.seeyon.udc.common.dto.ExtCodeReplaceParamDto);
```

### `TaskCallableManager`（3 方法）

`com.seeyon.udc.task.TaskCallableManager`

```java
    void setApplicationContext(org.springframework.context.ApplicationContext)
    java.util.Map<java.lang.String, com.seeyon.udc.task.TaskCallable> getMap();
    com.seeyon.udc.task.TaskCallable getService(java.lang.String);
```

### `DeployCacheUtils`（3 方法）

`com.seeyon.udc.utils.DeployCacheUtils`

```java
    static java.lang.String getDeployKey(java.lang.String, com.seeyon.udc.common.enums.DeployTypeEnum);
    static java.lang.String getDeployRecordKey(java.lang.String);
    static org.apache.commons.lang3.tuple.MutablePair<java.lang.String, java.lang.Long> getPublishingKeyValue(java.lang.String);
```

### `FilePathUtils`（3 方法）

`com.seeyon.udc.utils.FilePathUtils`

```java
    static java.lang.String getSchemaRelativePath(java.lang.String);
    static java.lang.String getResourcesRelativePath(java.lang.String);
    static java.lang.String getMetadataKey(java.lang.String, java.lang.String);
```

## 三、注解（2）

| 注解 | 元素 |
|---|---|
| `AppIdRef` | obtainType, index |
| `DataChangeAware` | appIdRef |

## 四、枚举（4）

- `ObtainType`（2 常量）：INPUT, OUTPUT
- `ExecuteStatusEnum`（4 常量）：jumpOver, executing, fail, success
- `LogTypeEnum`（2 常量）：sls, lts
- `StepTypeEnum`（12 常量）：START, DETECTION, CODE_GENERATION, GENERATION_METADATA, PUSH_CODE, COMPILE_BUILD, UNIT_TEST, IMAGE_GENERATION, SANDBOX_START, PUBLISH, END, UNKNOWN
