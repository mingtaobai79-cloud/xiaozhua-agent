# boot-starter-mybatis：接口与方法签名

> 自动生成，勿手改。`tools/core/platform/emit_package_surfaces.py` 重跑即可。
> 构件 `com.seeyon:boot-starter-mybatis`（jar `boot-starter-mybatis-5.3.600.jar`）
> 规模：140 类 / 43 接口 / 1 注解 / 1 枚举 / 33 个关键类 / 901 方法。
> 签名逐字来自 javap 原文；已去掉 `public` 前缀与 `throws` 子句。

## 一、接口（43）

### `AllInOneBaseDao`（41 方法） extends BaseDao<T>

`com.seeyon.boot.starter.mybatis.inone.dao.AllInOneBaseDao`

```java
    int create(T);
    int createBatch(java.util.List<T>);
    int update(T);
    int versionNoUpdateIgnoreVersion(T);
    int updateColumns(T, java.util.Set<java.lang.String>);
    int updateColumnsIgnoreVersion(T, java.util.Set<java.lang.String>);
    int updateBatch(java.util.List<T>);
    int versionNoUpdateBatchIgnoreVersion(java.util.List<T>);
    int deleteById(java.lang.Long);
    int deleteByIds(java.util.List<java.lang.Long>);
    int deleteByCondition(java.lang.String, java.lang.Object);
    int deleteByConditions(java.util.Map<java.lang.String, java.lang.Object>);
    T selectById(java.lang.Long);
    java.util.List<T> selectByIds(java.util.List<java.lang.Long>);
    T selectOneByCondition(java.lang.String, java.lang.Object);
    T selectOneByConditions(java.util.Map<java.lang.String, java.lang.Object>);
    int selectCountByCondition(java.lang.String, java.lang.Object);
    int selectCountByConditions(java.util.Map<java.lang.String, java.lang.Object>);
    java.util.List<T> selectListByCondition(java.lang.String, java.lang.Object, com.seeyon.boot.transport.Sort);
    java.util.List<T> selectListByConditions(java.util.Map<java.lang.String, java.lang.Object>, com.seeyon.boot.transport.Sort);
    java.util.List<T> selectListPropertiesByConditions(java.lang.String[], java.util.Map<java.lang.String, java.lang.Object>, com.seeyon.boot.transport.Sort);
    java.util.List<T> selectListExcludeByConditions(java.lang.String[], java.util.Map<java.lang.String, java.lang.Object>, com.seeyon.boot.transport.Sort);
    com.seeyon.boot.transport.PageData<T> selectPageByCondition(com.seeyon.boot.transport.PageInfo, java.lang.String, java.lang.Object, com.seeyon.boot.transport.Sort);
    com.seeyon.boot.transport.PageData<T> selectPageByConditions(com.seeyon.boot.transport.PageInfo, java.util.Map<java.lang.String, java.lang.Object>, com.seeyon.boot.transport.Sort);
    com.seeyon.boot.transport.PageData<T> selectPagePropertiesByConditions(com.seeyon.boot.transport.PageInfo, java.lang.String[], java.util.Map<java.lang.String, java.lang.Object>, com.seeyon.boot.transport.Sort);
    com.seeyon.boot.transport.PageData<T> selectPageExcludeByConditions(com.seeyon.boot.transport.PageInfo, java.lang.String[], java.util.Map<java.lang.String, java.lang.Object>, com.seeyon.boot.transport.Sort);
    int selectCountByComplexConditions(java.util.LinkedHashMap<java.lang.String, java.lang.Object>);
    java.util.List<T> selectListByComplexConditions(java.util.LinkedHashMap<java.lang.String, java.lang.Object>, com.seeyon.boot.transport.Sort);
    com.seeyon.boot.transport.PageData<T> selectPageByComplexConditions(com.seeyon.boot.transport.PageInfo, java.util.LinkedHashMap<java.lang.String, java.lang.Object>, com.seeyon.boot.transport.Sort);
    java.lang.String selectListFuncByComplexConditions(java.util.LinkedHashMap<java.lang.String, java.lang.Object>, com.seeyon.boot.transport.Sort, java.lang.String, java.util.List<java.lang.String>);
    int deleteByComplexConditions(java.util.Map<java.lang.String, java.lang.Object>);
    int selectCountByDynamicConditions(java.util.LinkedHashMap<java.lang.String, java.lang.Object>);
    java.util.List<T> selectListByDynamicConditions(java.util.LinkedHashMap<java.lang.String, java.lang.Object>, com.seeyon.boot.transport.Sort);
    com.seeyon.boot.transport.PageData<T> selectPageByDynamicConditions(com.seeyon.boot.transport.PageInfo, java.util.LinkedHashMap<java.lang.String, java.lang.Object>, com.seeyon.boot.transport.Sort);
    java.lang.String selectListFuncByDynamicConditions(java.util.LinkedHashMap<java.lang.String, java.lang.Object>, com.seeyon.boot.transport.Sort, java.lang.String, java.util.List<java.lang.String>);
    int deleteByDynamicConditions(java.util.Map<java.lang.String, java.lang.Object>);
    int selectCountByDynamicConditions(java.util.List<com.seeyon.boot.starter.mybatis.util.SeeyonKeyMap>);
    java.util.List<T> selectListByDynamicConditions(java.util.List<com.seeyon.boot.starter.mybatis.util.SeeyonKeyMap>, com.seeyon.boot.transport.Sort);
    com.seeyon.boot.transport.PageData<T> selectPageByDynamicConditions(com.seeyon.boot.transport.PageInfo, java.util.List<com.seeyon.boot.starter.mybatis.util.SeeyonKeyMap>, com.seeyon.boot.transport.Sort);
    java.lang.String selectListFuncByDynamicConditions(java.util.List<com.seeyon.boot.starter.mybatis.util.SeeyonKeyMap>, com.seeyon.boot.transport.Sort, java.lang.String, java.util.List<java.lang.String>);
    int deleteByDynamicConditions(java.util.List<com.seeyon.boot.starter.mybatis.util.SeeyonKeyMap>);
```

### `BaseMybatisDao`（16 方法）

`com.seeyon.boot.starter.mybatis.BaseMybatisDao`

```java
    default int updateBatch(java.util.List<T>);
    default int updateBatchIgnoreTime(java.util.List<T>);
    default int updateBatchIgnoreVersion(java.util.List<T>);
    default int versionNoUpdateBatchIgnoreVersion(java.util.List<T>);
    default int createBatch(java.util.List<T>);
    default int createBatchNoClob(java.util.List<T>);
    default int createBatchIgnoreTime(java.util.List<T>);
    default int getFieldCount(java.util.List);
    default int deleteByIds(java.util.List<java.lang.Long>);
    default int deleteByCondition(java.lang.String, java.lang.Object);
    default T selectOneByCondition(java.lang.String, java.lang.Object);
    default T selectOneByConditions(java.util.Map<java.lang.String, java.lang.Object>);
    default int selectCountByCondition(java.lang.String, java.lang.Object);
    default java.util.List<T> selectListByCondition(java.lang.String, java.lang.Object, com.seeyon.boot.transport.Sort);
    default com.seeyon.boot.transport.PageData<T> selectPageByCondition(com.seeyon.boot.transport.PageInfo, java.lang.String, java.lang.Object, com.seeyon.boot.transport.Sort);
    default T selectOneByWrapper(com.seeyon.boot.domain.dao.Wrapper);
```

### `AllInOneSelectByConditionMapper`（7 方法）

`com.seeyon.boot.starter.mybatis.inone.mapper.AllInOneSelectByConditionMapper`

```java
    int inOneSelectCountByConditions(java.util.Map<java.lang.String, java.lang.Object>);
    java.util.List<T> inOneSelectListByConditions(java.util.Map<java.lang.String, java.lang.Object>, com.seeyon.boot.transport.Sort);
    java.util.List<T> inOneSelectListPropertiesByConditions(java.lang.String[], java.util.Map<java.lang.String, java.lang.Object>, com.seeyon.boot.transport.Sort);
    java.util.List<T> inOneSelectListExcludeByConditions(java.lang.String[], java.util.Map<java.lang.String, java.lang.Object>, com.seeyon.boot.transport.Sort);
    com.seeyon.boot.transport.PageData<T> inOneSelectPageByConditions(com.seeyon.boot.transport.PageInfo, java.util.Map<java.lang.String, java.lang.Object>, com.seeyon.boot.transport.Sort);
    com.seeyon.boot.transport.PageData<T> inOneSelectPagePropertiesByConditions(com.seeyon.boot.transport.PageInfo, java.lang.String[], java.util.Map<java.lang.String, java.lang.Object>, com.seeyon.boot.transport.Sort);
    com.seeyon.boot.transport.PageData<T> inOneSelectPageExcludeByConditions(com.seeyon.boot.transport.PageInfo, java.lang.String[], java.util.Map<java.lang.String, java.lang.Object>, com.seeyon.boot.transport.Sort);
```

### `SelectByConditionMapper`（7 方法）

`com.seeyon.boot.starter.mybatis.mapper.SelectByConditionMapper`

```java
    int selectCountByConditions(java.util.Map<java.lang.String, java.lang.Object>);
    java.util.List<T> selectListByConditions(java.util.Map<java.lang.String, java.lang.Object>, com.seeyon.boot.transport.Sort);
    java.util.List<T> selectListPropertiesByConditions(java.lang.String[], java.util.Map<java.lang.String, java.lang.Object>, com.seeyon.boot.transport.Sort);
    java.util.List<T> selectListExcludeByConditions(java.lang.String[], java.util.Map<java.lang.String, java.lang.Object>, com.seeyon.boot.transport.Sort);
    com.seeyon.boot.transport.PageData<T> selectPageByConditions(com.seeyon.boot.transport.PageInfo, java.util.Map<java.lang.String, java.lang.Object>, com.seeyon.boot.transport.Sort);
    com.seeyon.boot.transport.PageData<T> selectPagePropertiesByConditions(com.seeyon.boot.transport.PageInfo, java.lang.String[], java.util.Map<java.lang.String, java.lang.Object>, com.seeyon.boot.transport.Sort);
    com.seeyon.boot.transport.PageData<T> selectPageExcludeByConditions(com.seeyon.boot.transport.PageInfo, java.lang.String[], java.util.Map<java.lang.String, java.lang.Object>, com.seeyon.boot.transport.Sort);
```

### `UpdateMapper`（4 方法）

`com.seeyon.boot.starter.mybatis.mapper.UpdateMapper`

```java
    int update(T);
    int updateIgnoreTime(T);
    int updateColumns(T, java.util.Set<java.lang.String>);
    int updateColumnsIgnoreVersion(T, java.util.Set<java.lang.String>);
```

### `AllInOneSelectByComplexConditionMapper`（3 方法）

`com.seeyon.boot.starter.mybatis.inone.mapper.AllInOneSelectByComplexConditionMapper`

```java
    java.lang.Integer inOneSelectCountByComplexConditions(java.util.Map<java.lang.String, java.lang.Object>);
    java.util.List<T> inOneSelectListByComplexConditions(java.util.LinkedHashMap<java.lang.String, java.lang.Object>, com.seeyon.boot.transport.Sort);
    com.seeyon.boot.transport.PageData<T> inOneSelectPageByComplexConditions(com.seeyon.boot.transport.PageInfo, java.util.LinkedHashMap<java.lang.String, java.lang.Object>, com.seeyon.boot.transport.Sort);
```

### `AllInOneSelectByDynamicConditionMapper`（3 方法）

`com.seeyon.boot.starter.mybatis.inone.mapper.AllInOneSelectByDynamicConditionMapper`

```java
    int inOneSelectCountByDynamicConditions(java.util.LinkedHashMap<java.lang.String, java.lang.Object>);
    java.util.List<T> inOneSelectListByDynamicConditions(java.util.LinkedHashMap<java.lang.String, java.lang.Object>, com.seeyon.boot.transport.Sort);
    com.seeyon.boot.transport.PageData<T> inOneSelectPageByDynamicConditions(com.seeyon.boot.transport.PageInfo, java.util.LinkedHashMap<java.lang.String, java.lang.Object>, com.seeyon.boot.transport.Sort);
```

### `SelectByComplexConditionMapper`（3 方法）

`com.seeyon.boot.starter.mybatis.mapper.SelectByComplexConditionMapper`

```java
    int selectCountByComplexConditions(java.util.Map<java.lang.String, java.lang.Object>);
    java.util.List<T> selectListByComplexConditions(java.util.LinkedHashMap<java.lang.String, java.lang.Object>, com.seeyon.boot.transport.Sort);
    com.seeyon.boot.transport.PageData<T> selectPageByComplexConditions(com.seeyon.boot.transport.PageInfo, java.util.LinkedHashMap<java.lang.String, java.lang.Object>, com.seeyon.boot.transport.Sort);
```

### `SelectByDynamicConditionMapper`（3 方法）

`com.seeyon.boot.starter.mybatis.mapper.SelectByDynamicConditionMapper`

```java
    int selectCountByDynamicConditions(java.util.LinkedHashMap<java.lang.String, java.lang.Object>);
    java.util.List<T> selectListByDynamicConditions(java.util.LinkedHashMap<java.lang.String, java.lang.Object>, com.seeyon.boot.transport.Sort);
    com.seeyon.boot.transport.PageData<T> selectPageByDynamicConditions(com.seeyon.boot.transport.PageInfo, java.util.LinkedHashMap<java.lang.String, java.lang.Object>, com.seeyon.boot.transport.Sort);
```

### `SelectByWrapperMapper`（3 方法）

`com.seeyon.boot.starter.mybatis.mapper.SelectByWrapperMapper`

```java
    int selectCountByWrapper(com.seeyon.boot.domain.dao.Wrapper);
    java.util.List<T> selectListByWrapper(com.seeyon.boot.domain.dao.Wrapper);
    com.seeyon.boot.transport.PageData<T> selectPageByWrapper(com.seeyon.boot.transport.PageInfo, com.seeyon.boot.domain.dao.Wrapper);
```

### `UpdateBatchMapper`（3 方法）

`com.seeyon.boot.starter.mybatis.mapper.UpdateBatchMapper`

```java
    int updateBatchInternal(java.util.List<T>);
    int updateBatchInternalIgnoreTime(java.util.List<T>);
    int updateColumnsBatch(java.util.List<T>, java.util.Set<java.lang.String>);
```

### `DatabaseDialect`（2 方法）

`com.seeyon.boot.starter.mybatis.dialect.DatabaseDialect`

```java
    java.lang.String pageSql(com.seeyon.boot.transport.PageInfo, java.lang.String);
    com.seeyon.boot.domain.dao.support.DatabaseType getDatabaseType();
```

### `AllInOneDeleteByIdMapper`（2 方法）

`com.seeyon.boot.starter.mybatis.inone.mapper.AllInOneDeleteByIdMapper`

```java
    int inOneDeleteById(java.lang.Long);
    int inOneDeleteByIds(java.util.List<java.lang.Long>);
```

### `AllInOneSelectByIdMapper`（2 方法）

`com.seeyon.boot.starter.mybatis.inone.mapper.AllInOneSelectByIdMapper`

```java
    T inOneSelectById(java.lang.Long);
    java.util.List<T> inOneSelectByIds(java.util.List<java.lang.Long>);
```

### `AllInOneUpdateBatchMapper`（2 方法）

`com.seeyon.boot.starter.mybatis.inone.mapper.AllInOneUpdateBatchMapper`

```java
    int inOneUpdateBatchInternal(java.util.List<T>);
    int inOneVersionNoUpdateBatchInternalIgnoreVersion(java.util.List<T>);
```

### `AllInOneUpdateIgnoreVersionMapper`（2 方法）

`com.seeyon.boot.starter.mybatis.inone.mapper.AllInOneUpdateIgnoreVersionMapper`

```java
    int inOneUpdateIgnoreVersion(java.lang.Object);
    int inOneVersionNoUpdateIgnoreVersion(java.lang.Object);
```

### `AllInOneUpdateMapper`（2 方法）

`com.seeyon.boot.starter.mybatis.inone.mapper.AllInOneUpdateMapper`

```java
    int inOneUpdate(java.lang.Object);
    int inOneUpdateColumns(java.lang.Object, java.util.Set<java.lang.String>);
```

### `CreateBatchMapper`（2 方法）

`com.seeyon.boot.starter.mybatis.mapper.CreateBatchMapper`

```java
    int createBatchInternal(java.util.List<T>);
    int createBatchInternalIgnoreTime(java.util.List<T>);
```

### `CreateMapper`（2 方法）

`com.seeyon.boot.starter.mybatis.mapper.CreateMapper`

```java
    int create(T);
    int createIgnoreTime(T);
```

### `DeleteByIdMapper`（2 方法）

`com.seeyon.boot.starter.mybatis.mapper.DeleteByIdMapper`

```java
    int deleteById(java.lang.Long);
    int deleteByIdsInternal(java.util.List<java.lang.Long>);
```

### `SelectByIdMapper`（2 方法）

`com.seeyon.boot.starter.mybatis.mapper.SelectByIdMapper`

```java
    T selectById(java.lang.Long);
    java.util.List<T> selectByIds(java.util.List<java.lang.Long>);
```

### `UpdateBatchIgnoreVersionMapper`（2 方法）

`com.seeyon.boot.starter.mybatis.mapper.UpdateBatchIgnoreVersionMapper`

```java
    int updateBatchInternalIgnoreVersion(java.util.List<T>);
    int versionNoUpdateBatchInternalIgnoreVersion(java.util.List<T>);
```

### `UpdateByWrapperMapper`（2 方法）

`com.seeyon.boot.starter.mybatis.mapper.UpdateByWrapperMapper`

```java
    int updateByWrapper(T, java.lang.Object);
    int updateByWrapperSelective(T, java.lang.Object);
```

### `UpdateIgnoreVersionMapper`（2 方法）

`com.seeyon.boot.starter.mybatis.mapper.UpdateIgnoreVersionMapper`

```java
    int updateIgnoreVersion(T);
    int versionNoUpdateIgnoreVersion(T);
```

### `DataPermissionCheck`（1 方法）

`com.seeyon.boot.starter.mybatis.DataPermissionCheck`

```java
    java.util.List<java.util.Map<java.lang.String, java.lang.String>> check(java.lang.String);
```

### `AllInOneCreateBatchMapper`（1 方法）

`com.seeyon.boot.starter.mybatis.inone.mapper.AllInOneCreateBatchMapper`

```java
    int inOneCreateBatchInternal(java.util.List<T>);
```

### `AllInOneCreateMapper`（1 方法）

`com.seeyon.boot.starter.mybatis.inone.mapper.AllInOneCreateMapper`

```java
    int inOneCreate(java.lang.Object);
```

### `AllInOneDeleteByComplexConditionMapper`（1 方法）

`com.seeyon.boot.starter.mybatis.inone.mapper.AllInOneDeleteByComplexConditionMapper`

```java
    int inOneDeleteByComplexConditions(java.util.Map<java.lang.String, java.lang.Object>);
```

### `AllInOneDeleteByConditionMapper`（1 方法）

`com.seeyon.boot.starter.mybatis.inone.mapper.AllInOneDeleteByConditionMapper`

```java
    int inOneDeleteByConditions(java.util.Map<java.lang.String, java.lang.Object>);
```

### `AllInOneDeleteByDynamicConditionMapper`（1 方法）

`com.seeyon.boot.starter.mybatis.inone.mapper.AllInOneDeleteByDynamicConditionMapper`

```java
    int inOneDeleteByDynamicConditions(java.util.Map<java.lang.String, java.lang.Object>);
```

### `AllInOneSelectFuncByComplexConditionMapper`（1 方法）

`com.seeyon.boot.starter.mybatis.inone.mapper.AllInOneSelectFuncByComplexConditionMapper`

```java
    java.lang.String inOneSelectListFuncByComplexConditions(java.util.LinkedHashMap<java.lang.String, java.lang.Object>, com.seeyon.boot.transport.Sort, java.lang.String, java.util.List<java.lang.String>);
```

### `AllInOneSelectFuncByDynamicConditionMapper`（1 方法）

`com.seeyon.boot.starter.mybatis.inone.mapper.AllInOneSelectFuncByDynamicConditionMapper`

```java
    java.lang.String inOneSelectListFuncByDynamicConditions(java.util.LinkedHashMap<java.lang.String, java.lang.Object>, com.seeyon.boot.transport.Sort, java.lang.String, java.util.List<java.lang.String>);
```

### `DeleteByComplexConditionMapper`（1 方法）

`com.seeyon.boot.starter.mybatis.mapper.DeleteByComplexConditionMapper`

```java
    int deleteByComplexConditions(java.util.Map<java.lang.String, java.lang.Object>);
```

### `DeleteByConditionMapper`（1 方法）

`com.seeyon.boot.starter.mybatis.mapper.DeleteByConditionMapper`

```java
    int deleteByConditions(java.util.Map<java.lang.String, java.lang.Object>);
```

### `DeleteByDynamicConditionMapper`（1 方法）

`com.seeyon.boot.starter.mybatis.mapper.DeleteByDynamicConditionMapper`

```java
    int deleteByDynamicConditions(java.util.Map<java.lang.String, java.lang.Object>);
```

### `DeleteByWrapperMapper`（1 方法）

`com.seeyon.boot.starter.mybatis.mapper.DeleteByWrapperMapper`

```java
    int deleteByWrapper(com.seeyon.boot.domain.dao.Wrapper);
```

### `SelectFuncByComplexConditionMapper`（1 方法）

`com.seeyon.boot.starter.mybatis.mapper.SelectFuncByComplexConditionMapper`

```java
    java.lang.String selectListFuncByComplexConditions(java.util.LinkedHashMap<java.lang.String, java.lang.Object>, com.seeyon.boot.transport.Sort, java.lang.String, java.util.List<java.lang.String>);
```

### `SelectFuncByConditionMapper`（1 方法）

`com.seeyon.boot.starter.mybatis.mapper.SelectFuncByConditionMapper`

```java
    java.lang.String selectFuncByConditions(java.util.Map<java.lang.String, java.lang.Object>, com.seeyon.boot.transport.Sort, java.lang.String, java.util.List<java.lang.String>);
```

### `SelectFuncByDynamicConditionMapper`（1 方法）

`com.seeyon.boot.starter.mybatis.mapper.SelectFuncByDynamicConditionMapper`

```java
    java.lang.String selectListFuncByDynamicConditions(java.util.LinkedHashMap<java.lang.String, java.lang.Object>, com.seeyon.boot.transport.Sort, java.lang.String, java.util.List<java.lang.String>);
```

### `UpdateByConditionMapper`（1 方法）

`com.seeyon.boot.starter.mybatis.mapper.UpdateByConditionMapper`

```java
    int updateByConditions(T, java.util.Set<java.lang.String>, java.util.Map<java.lang.String, java.lang.Object>);
```

### `SeeyonSensitive`（1 方法）

`com.seeyon.boot.starter.mybatis.sensitive.SeeyonSensitive`

```java
    java.lang.String sensitiveProcess(java.lang.String);
```

### `DateParser`（1 方法）

`com.seeyon.boot.starter.mybatis.util.DateParser`

```java
    default java.lang.Object parser(java.lang.Object);
```

### `AllInOneBaseMybatisDao`（0 方法）

`com.seeyon.boot.starter.mybatis.inone.dao.AllInOneBaseMybatisDao`

```java
```

## 二、关键类（33）

### `AbstractAllInOneBaseDao`（55 方法）

`com.seeyon.boot.starter.mybatis.AbstractAllInOneBaseDao`

```java
    static private static void notSupportedException();
    private void putThreadContext();
    private java.lang.Class<T> getT();
    private void removeThreadContext();
    int create(java.lang.Object);
    int createBatch(java.util.List);
    int createBatchNoClob(java.util.List);
    int createBatchIgnoreTime(java.util.List);
    int update(java.lang.Object);
    int versionNoUpdateIgnoreVersion(java.lang.Object);
    int updateColumns(java.lang.Object, java.util.Set);
    int updateColumnsIgnoreVersion(java.lang.Object, java.util.Set);
    int updateBatch(java.util.List);
    int updateBatchIgnoreTime(java.util.List);
    int updateBatchIgnoreVersion(java.util.List);
    int versionNoUpdateBatchIgnoreVersion(java.util.List);
    int deleteById(java.lang.Long);
    int deleteByIds(java.util.List);
    int deleteByConditions(java.util.Map);
    int deleteByCondition(java.lang.String, java.lang.Object);
    int deleteByWrapper(com.seeyon.boot.domain.dao.Wrapper);
    T selectById(java.lang.Long);
    java.util.List selectByIds(java.util.List);
    T selectOneByCondition(java.lang.String, java.lang.Object);
    T selectOneByConditions(java.util.Map);
    int selectCountByCondition(java.lang.String, java.lang.Object);
    int selectCountByConditions(java.util.Map);
    java.util.List selectListByCondition(java.lang.String, java.lang.Object, com.seeyon.boot.transport.Sort);
    java.util.List selectListByConditions(java.util.Map, com.seeyon.boot.transport.Sort);
    com.seeyon.boot.transport.PageData selectPageByCondition(com.seeyon.boot.transport.PageInfo, java.lang.String, java.lang.Object, com.seeyon.boot.transport.Sort);
    java.lang.Object selectOneByWrapper(com.seeyon.boot.domain.dao.Wrapper);
    int selectCountByWrapper(com.seeyon.boot.domain.dao.Wrapper);
    java.util.List selectListByWrapper(com.seeyon.boot.domain.dao.Wrapper);
    com.seeyon.boot.transport.PageData selectPageByWrapper(com.seeyon.boot.transport.PageInfo, com.seeyon.boot.domain.dao.Wrapper);
    com.seeyon.boot.transport.PageData selectPageByConditions(com.seeyon.boot.transport.PageInfo, java.util.Map, com.seeyon.boot.transport.Sort);
    com.seeyon.boot.transport.PageData selectPageExcludeByConditions(com.seeyon.boot.transport.PageInfo, java.lang.String[], java.util.Map, com.seeyon.boot.transport.Sort);
    com.seeyon.boot.transport.PageData selectPagePropertiesByConditions(com.seeyon.boot.transport.PageInfo, java.lang.String[], java.util.Map, com.seeyon.boot.transport.Sort);
    java.util.List selectListExcludeByConditions(java.lang.String[], java.util.Map, com.seeyon.boot.transport.Sort);
    java.util.List selectListPropertiesByConditions(java.lang.String[], java.util.Map, com.seeyon.boot.transport.Sort);
    int selectCountByComplexConditions(java.util.LinkedHashMap);
    java.util.List selectListByComplexConditions(java.util.LinkedHashMap, com.seeyon.boot.transport.Sort);
    com.seeyon.boot.transport.PageData selectPageByComplexConditions(com.seeyon.boot.transport.PageInfo, java.util.LinkedHashMap, com.seeyon.boot.transport.Sort);
    java.lang.String selectListFuncByComplexConditions(java.util.LinkedHashMap, com.seeyon.boot.transport.Sort, java.lang.String, java.util.List);
    int deleteByComplexConditions(java.util.Map);
    int selectCountByDynamicConditions(java.util.LinkedHashMap);
    java.util.List selectListByDynamicConditions(java.util.LinkedHashMap, com.seeyon.boot.transport.Sort);
    com.seeyon.boot.transport.PageData selectPageByDynamicConditions(com.seeyon.boot.transport.PageInfo, java.util.LinkedHashMap, com.seeyon.boot.transport.Sort);
    java.lang.String selectListFuncByDynamicConditions(java.util.LinkedHashMap, com.seeyon.boot.transport.Sort, java.lang.String, java.util.List);
    int deleteByDynamicConditions(java.util.Map);
    private int getFieldCount(java.util.List);
    int selectCountByDynamicConditions(java.util.List);
    java.util.List selectListByDynamicConditions(java.util.List, com.seeyon.boot.transport.Sort);
    com.seeyon.boot.transport.PageData selectPageByDynamicConditions(com.seeyon.boot.transport.PageInfo, java.util.List, com.seeyon.boot.transport.Sort);
    java.lang.String selectListFuncByDynamicConditions(java.util.List, com.seeyon.boot.transport.Sort, java.lang.String, java.util.List);
    int deleteByDynamicConditions(java.util.List);
```

### `DynamicAllInOneDaoService`（44 方法）

`com.seeyon.boot.starter.mybatis.service.DynamicAllInOneDaoService`

```java
    void onApplicationEvent(com.seeyon.boot.event.ModuleUnloadEvent);
    java.lang.Class<?> getT(java.lang.String, java.lang.String);
    int create(java.lang.Object, java.lang.String, java.lang.String);
    int createBatch(java.util.List, java.lang.String, java.lang.String);
    int update(java.lang.Object, java.lang.String, java.lang.String);
    int versionNoUpdateIgnoreVersion(java.lang.Object, java.lang.String, java.lang.String);
    int updateColumns(java.lang.Object, java.util.Set, java.lang.String, java.lang.String);
    int updateBatch(java.util.List, java.lang.String, java.lang.String);
    int versionNoUpdateBatchIgnoreVersion(java.util.List, java.lang.String, java.lang.String);
    int deleteById(java.lang.Long, java.lang.String, java.lang.String);
    int deleteByIds(java.util.List, java.lang.String, java.lang.String);
    int deleteByConditions(java.util.Map, java.lang.String, java.lang.String);
    int deleteByCondition(java.lang.String, java.lang.Object, java.lang.String, java.lang.String);
    java.lang.Object selectById(java.lang.Long, java.lang.String, java.lang.String);
    java.util.List selectByIds(java.util.List, java.lang.String, java.lang.String);
    java.lang.Object selectOneByCondition(java.lang.String, java.lang.Object, java.lang.String, java.lang.String);
    java.lang.Object selectOneByConditions(java.util.Map, java.lang.String, java.lang.String);
    int selectCountByCondition(java.lang.String, java.lang.Object, java.lang.String, java.lang.String);
    int selectCountByConditions(java.util.Map, java.lang.String, java.lang.String);
    java.util.List selectListByCondition(java.lang.String, java.lang.Object, com.seeyon.boot.transport.Sort, java.lang.String, java.lang.String);
    java.util.List selectListByConditions(java.util.Map, com.seeyon.boot.transport.Sort, java.lang.String, java.lang.String);
    com.seeyon.boot.transport.PageData selectPageByCondition(com.seeyon.boot.transport.PageInfo, java.lang.String, java.lang.Object, com.seeyon.boot.transport.Sort, java.lang.String, java.lang.String);
    com.seeyon.boot.transport.PageData selectPageByConditions(com.seeyon.boot.transport.PageInfo, java.util.Map, com.seeyon.boot.transport.Sort, java.lang.String, java.lang.String);
    com.seeyon.boot.transport.PageData selectPageExcludeByConditions(com.seeyon.boot.transport.PageInfo, java.lang.String[], java.util.Map, com.seeyon.boot.transport.Sort, java.lang.String, java.lang.String);
    com.seeyon.boot.transport.PageData selectPagePropertiesByConditions(com.seeyon.boot.transport.PageInfo, java.lang.String[], java.util.Map, com.seeyon.boot.transport.Sort, java.lang.String, java.lang.String);
    java.util.List selectListExcludeByConditions(java.lang.String[], java.util.Map, com.seeyon.boot.transport.Sort, java.lang.String, java.lang.String);
    java.util.List selectListPropertiesByConditions(java.lang.String[], java.util.Map, com.seeyon.boot.transport.Sort, java.lang.String, java.lang.String);
    int selectCountByComplexConditions(java.util.LinkedHashMap, java.lang.String, java.lang.String);
    java.util.List selectListByComplexConditions(java.util.LinkedHashMap, com.seeyon.boot.transport.Sort, java.lang.String, java.lang.String);
    java.lang.String selectListFuncByComplexConditions(java.util.LinkedHashMap, com.seeyon.boot.transport.Sort, java.lang.String, java.util.List, java.lang.String, java.lang.String);
    com.seeyon.boot.transport.PageData selectPageByComplexConditions(com.seeyon.boot.transport.PageInfo, java.util.LinkedHashMap, com.seeyon.boot.transport.Sort, java.lang.String, java.lang.String);
    int deleteByComplexConditions(java.util.Map, java.lang.String, java.lang.String);
    int selectCountByDynamicConditions(java.util.LinkedHashMap, java.lang.String, java.lang.String);
    java.util.List selectListByDynamicConditions(java.util.LinkedHashMap, com.seeyon.boot.transport.Sort, java.lang.String, java.lang.String);
    com.seeyon.boot.transport.PageData selectPageByDynamicConditions(com.seeyon.boot.transport.PageInfo, java.util.LinkedHashMap, com.seeyon.boot.transport.Sort, java.lang.String, java.lang.String);
    java.lang.String selectListFuncByDynamicConditions(java.util.LinkedHashMap, com.seeyon.boot.transport.Sort, java.lang.String, java.util.List, java.lang.String, java.lang.String);
    int deleteByDynamicConditions(java.util.Map, java.lang.String, java.lang.String);
    int selectCountByDynamicConditions(java.util.List, java.lang.String, java.lang.String);
    java.util.List selectListByDynamicConditions(java.util.List, com.seeyon.boot.transport.Sort, java.lang.String, java.lang.String);
    com.seeyon.boot.transport.PageData selectPageByDynamicConditions(com.seeyon.boot.transport.PageInfo, java.util.List, com.seeyon.boot.transport.Sort, java.lang.String, java.lang.String);
    java.lang.String selectListFuncByDynamicConditions(java.util.List, com.seeyon.boot.transport.Sort, java.lang.String, java.util.List, java.lang.String, java.lang.String);
    int deleteByDynamicConditions(java.util.List, java.lang.String, java.lang.String);
    private int getFieldCount(java.util.List);
    void onApplicationEvent(org.springframework.context.ApplicationEvent);
```

### `AllInOneJdbcDao`（43 方法）

`com.seeyon.boot.starter.mybatis.service.AllInOneJdbcDao`

```java
    int create(java.lang.Object, java.lang.Class<?>);
    int createBatch(java.util.List, java.lang.Class<?>);
    int update(java.lang.Object, java.lang.Class<?>);
    int updateColumns(java.lang.Object, java.util.Set, java.lang.Class<?>);
    int updateColumnsIgnoreVersion(java.lang.Object, java.util.Set, java.lang.Class<?>);
    int versionNoUpdateIgnoreVersion(java.lang.Object, java.lang.Class<?>);
    int updateBatch(java.util.List, java.lang.Class<?>);
    int versionNoUpdateBatchIgnoreVersion(java.util.List, java.lang.Class<?>);
    int deleteById(java.lang.Long, java.lang.Class<?>);
    int deleteByCondition(java.lang.String, java.lang.Object, java.lang.Class<?>);
    int deleteByConditions(java.util.Map<java.lang.String, java.lang.Object>, java.lang.Class<?>);
    int deleteByIds(java.util.List, java.lang.Class<?>);
    java.lang.Object selectById(java.lang.Long, java.lang.Class<?>);
    java.lang.Object selectOneByCondition(java.lang.String, java.lang.Object, java.lang.Class<?>);
    int selectCountByCondition(java.lang.String, java.lang.Object, java.lang.Class<?>);
    java.util.List selectListByCondition(java.lang.String, java.lang.Object, com.seeyon.boot.transport.Sort, java.lang.Class<?>);
    com.seeyon.boot.transport.PageData selectPageByCondition(com.seeyon.boot.transport.PageInfo, java.lang.String, java.lang.Object, com.seeyon.boot.transport.Sort, java.lang.Class<?>);
    com.seeyon.boot.transport.PageData selectPageExcludeByConditions(com.seeyon.boot.transport.PageInfo, java.lang.String[], java.util.Map, com.seeyon.boot.transport.Sort, java.lang.Class<?>);
    com.seeyon.boot.transport.PageData selectPagePropertiesByConditions(com.seeyon.boot.transport.PageInfo, java.lang.String[], java.util.Map, com.seeyon.boot.transport.Sort, java.lang.Class<?>);
    com.seeyon.boot.transport.PageData selectPageByConditions(com.seeyon.boot.transport.PageInfo, java.util.Map, com.seeyon.boot.transport.Sort, java.lang.Class<?>);
    java.util.List selectListExcludeByConditions(java.lang.String[], java.util.Map, com.seeyon.boot.transport.Sort, java.lang.Class<?>);
    java.util.List selectListPropertiesByConditions(java.lang.String[], java.util.Map, com.seeyon.boot.transport.Sort, java.lang.Class<?>);
    java.util.List selectListByConditions(java.util.Map, com.seeyon.boot.transport.Sort, java.lang.Class<?>);
    int selectCountByConditions(java.util.Map, java.lang.Class<?>);
    java.lang.Object selectOneByConditions(java.util.Map, java.lang.Class<?>);
    java.util.List selectByIds(java.util.List, java.lang.Class<?>);
    int selectCountByComplexConditions(java.util.LinkedHashMap, java.lang.Class<?>);
    java.util.List selectListByComplexConditions(java.util.LinkedHashMap, com.seeyon.boot.transport.Sort, java.lang.Class<?>);
    com.seeyon.boot.transport.PageData selectPageByComplexConditions(com.seeyon.boot.transport.PageInfo, java.util.LinkedHashMap, com.seeyon.boot.transport.Sort, java.lang.Class<?>);
    java.lang.String selectListFuncByComplexConditions(java.util.LinkedHashMap, com.seeyon.boot.transport.Sort, java.lang.String, java.util.List, java.lang.Class<?>);
    int deleteByComplexConditions(java.util.Map, java.lang.Class<?>);
    int selectCountByDynamicConditions(java.util.LinkedHashMap, java.lang.Class<?>);
    java.util.List selectListByDynamicConditions(java.util.LinkedHashMap, com.seeyon.boot.transport.Sort, java.lang.Class<?>);
    com.seeyon.boot.transport.PageData selectPageByDynamicConditions(com.seeyon.boot.transport.PageInfo, java.util.LinkedHashMap, com.seeyon.boot.transport.Sort, java.lang.Class<?>);
    java.lang.String selectListFuncByDynamicConditions(java.util.LinkedHashMap, com.seeyon.boot.transport.Sort, java.lang.String, java.util.List, java.lang.Class<?>);
    int deleteByDynamicConditions(java.util.Map, java.lang.Class<?>);
    int selectCountByDynamicConditions(java.util.List<com.seeyon.boot.starter.mybatis.util.SeeyonKeyMap>, java.lang.Class<?>);
    java.util.List selectListByDynamicConditions(java.util.List<com.seeyon.boot.starter.mybatis.util.SeeyonKeyMap>, com.seeyon.boot.transport.Sort, java.lang.Class<?>);
    com.seeyon.boot.transport.PageData selectPageByDynamicConditions(com.seeyon.boot.transport.PageInfo, java.util.List<com.seeyon.boot.starter.mybatis.util.SeeyonKeyMap>, com.seeyon.boot.transport.Sort, java.lang.Class<?>);
    java.lang.String selectListFuncByDynamicConditions(java.util.List<com.seeyon.boot.starter.mybatis.util.SeeyonKeyMap>, com.seeyon.boot.transport.Sort, java.lang.String, java.util.List, java.lang.Class<?>);
    int deleteByDynamicConditions(java.util.List<com.seeyon.boot.starter.mybatis.util.SeeyonKeyMap>, java.lang.Class<?>);
    private java.lang.String[] excludeColumns(java.lang.String[], java.util.Map<java.lang.String, java.lang.String>);
    private void secretCheck(java.lang.Object);
```

### `AllInOneDBUtil`（22 方法）

`com.seeyon.boot.starter.mybatis.service.AllInOneDBUtil`

```java
    int insertBatch(java.util.List, java.lang.Class<?>, java.lang.Boolean);
    int updateBatchByIds(java.util.List, java.util.Set<java.lang.String>, java.lang.Boolean, java.lang.Boolean, java.lang.Class<?>);
    int delete(java.util.Map<java.lang.String, java.lang.Object>, java.lang.Boolean, java.lang.Class<?>);
    int deleteIds(java.util.List<java.lang.Long>, java.lang.Class<?>);
    java.util.List<java.util.Map<java.lang.String, java.lang.Object>> selectSql(com.seeyon.boot.transport.PageInfo, java.lang.String, java.util.Map<java.lang.String, java.lang.Object>);
    java.util.List<java.lang.Object> selectBatch(java.lang.String[], java.util.Map<java.lang.String, java.lang.Object>, java.lang.Boolean, com.seeyon.boot.transport.PageInfo, com.seeyon.boot.transport.Sort, java.lang.Class<?>);
    java.util.List<java.lang.Object> selectBatch(java.lang.String[], java.util.Map<java.lang.String, java.lang.Object>, java.lang.Boolean, com.seeyon.boot.transport.PageInfo, com.seeyon.boot.transport.Sort, java.lang.Class<?>, java.lang.String);
    java.util.List<java.lang.Object> selectBatchAsync(java.lang.String[], java.util.Map<java.lang.String, java.lang.Object>, com.seeyon.boot.transport.PageInfo, com.seeyon.boot.transport.Sort, java.lang.Class<?>, java.lang.String);
    private java.util.List<java.lang.String> getSqlSplitList(java.lang.String);
    int selectCount(java.util.Map<java.lang.String, java.lang.Object>, java.lang.Boolean, java.lang.Class<?>);
    private void jdbcCondition(java.lang.StringBuilder, java.util.Map<java.lang.String, java.lang.Object>, java.util.Map<java.lang.String, java.lang.Object>, java.lang.Class<?>);
    private java.lang.String whereMatcher(java.lang.String);
    private java.lang.String buildQueryString(java.lang.String, java.lang.String[], java.util.Map<java.lang.String, java.lang.String>, java.lang.String, com.seeyon.boot.transport.PageInfo, com.seeyon.boot.transport.Sort, java.lang.Class<?>);
    private java.lang.String buildCountQueryString(java.lang.String, java.lang.String);
    private void getSortSql(com.seeyon.boot.transport.Sort, java.lang.StringBuilder, java.lang.Class<?>);
    private java.lang.String getPageSql(com.seeyon.boot.transport.PageInfo, java.lang.String);
    private void appendClause(java.lang.StringBuilder, java.lang.String);
    private void appendColumns(java.lang.StringBuilder, java.lang.String[], java.util.Map<java.lang.String, java.lang.String>);
    private void appendColumns(java.lang.StringBuilder, java.util.Map<java.lang.String, java.lang.String>);
    private void copyMap(java.util.Map<java.lang.String, java.lang.Object>, java.util.Map<java.lang.String, java.lang.Object>, java.util.Map<java.lang.String, java.lang.String>);
```

### `BooleanValueHandler`（16 方法）

`com.seeyon.boot.starter.mybatis.type.BooleanValueHandler`

```java
    java.lang.Boolean getResult(java.sql.ResultSet, java.lang.String)
    java.lang.Boolean getResult(java.sql.ResultSet, int)
    java.lang.Boolean getResult(java.sql.CallableStatement, int)
    void setNonNullParameter(java.sql.PreparedStatement, int, java.lang.Boolean, org.apache.ibatis.type.JdbcType)
    java.lang.Boolean getNullableResult(java.sql.ResultSet, java.lang.String)
    java.lang.Boolean getNullableResult(java.sql.ResultSet, int)
    java.lang.Boolean getNullableResult(java.sql.CallableStatement, int)
    void setParameter(java.sql.PreparedStatement, int, java.lang.Boolean, org.apache.ibatis.type.JdbcType)
    java.lang.Object getNullableResult(java.sql.CallableStatement, int)
    java.lang.Object getNullableResult(java.sql.ResultSet, int)
    java.lang.Object getNullableResult(java.sql.ResultSet, java.lang.String)
    void setNonNullParameter(java.sql.PreparedStatement, int, java.lang.Object, org.apache.ibatis.type.JdbcType)
    java.lang.Object getResult(java.sql.CallableStatement, int)
    java.lang.Object getResult(java.sql.ResultSet, int)
    java.lang.Object getResult(java.sql.ResultSet, java.lang.String)
    void setParameter(java.sql.PreparedStatement, int, java.lang.Object, org.apache.ibatis.type.JdbcType)
```

### `NullValueHandler`（16 方法）

`com.seeyon.boot.starter.mybatis.type.NullValueHandler`

```java
    java.lang.String getResult(java.sql.ResultSet, java.lang.String)
    java.lang.String getResult(java.sql.ResultSet, int)
    java.lang.String getResult(java.sql.CallableStatement, int)
    void setNonNullParameter(java.sql.PreparedStatement, int, java.lang.String, org.apache.ibatis.type.JdbcType)
    java.lang.String getNullableResult(java.sql.ResultSet, java.lang.String)
    java.lang.String getNullableResult(java.sql.ResultSet, int)
    java.lang.String getNullableResult(java.sql.CallableStatement, int)
    void setParameter(java.sql.PreparedStatement, int, java.lang.String, org.apache.ibatis.type.JdbcType)
    java.lang.Object getNullableResult(java.sql.CallableStatement, int)
    java.lang.Object getNullableResult(java.sql.ResultSet, int)
    java.lang.Object getNullableResult(java.sql.ResultSet, java.lang.String)
    void setNonNullParameter(java.sql.PreparedStatement, int, java.lang.Object, org.apache.ibatis.type.JdbcType)
    java.lang.Object getResult(java.sql.CallableStatement, int)
    java.lang.Object getResult(java.sql.ResultSet, int)
    java.lang.Object getResult(java.sql.ResultSet, java.lang.String)
    void setParameter(java.sql.PreparedStatement, int, java.lang.Object, org.apache.ibatis.type.JdbcType)
```

### `SeeyonScriptUtils`（16 方法）

`com.seeyon.boot.starter.mybatis.util.SeeyonScriptUtils`

```java
    static void executeSqlScript(java.sql.Connection, org.springframework.core.io.Resource)
    static void executeSqlScript(java.sql.Connection, org.springframework.core.io.support.EncodedResource)
    static java.util.List<java.util.Map<java.lang.String, java.lang.String>> executeSqlScript(java.sql.Connection, org.springframework.core.io.support.EncodedResource, boolean)
    static java.util.List<java.util.Map<java.lang.String, java.lang.String>> executeSqlScript(java.sql.Connection, org.springframework.core.io.support.EncodedResource, boolean, boolean, boolean, java.lang.String, java.lang.String, java.lang.String, java.lang.String)
    static java.util.List<java.util.Map<java.lang.String, java.lang.String>> executeSqlScript(java.sql.Connection, org.springframework.core.io.support.EncodedResource, boolean, boolean, boolean, java.lang.String[], java.lang.String, java.lang.String, java.lang.String)
    static java.lang.String readScript(org.springframework.core.io.support.EncodedResource, java.lang.String, java.lang.String[], java.lang.String)
    static java.lang.String readScript(java.io.LineNumberReader, java.lang.String, java.lang.String, java.lang.String)
    static java.lang.String readScript(java.io.LineNumberReader, java.lang.String[], java.lang.String, java.lang.String)
    static private static void appendSeparatorToScriptIfNecessary(java.lang.StringBuilder, java.lang.String);
    static boolean containsSqlScriptDelimiters(java.lang.String, java.lang.String);
    static private static boolean containsStatementSeparator(org.springframework.core.io.support.EncodedResource, java.lang.String, java.lang.String, java.lang.String[], java.lang.String, java.lang.String)
    static void splitSqlScript(java.lang.String, char, java.util.List<java.lang.String>)
    static void splitSqlScript(java.lang.String, java.lang.String, java.util.List<java.lang.String>)
    static void splitSqlScript(org.springframework.core.io.support.EncodedResource, java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.util.List<java.lang.String>)
    static void splitSqlScript(org.springframework.core.io.support.EncodedResource, java.lang.String, java.lang.String, java.lang.String[], java.lang.String, java.lang.String, java.util.List<java.lang.String>)
    static private static boolean startsWithAny(java.lang.String, java.lang.String[], int);
```

### `AllInOneDBComplexUtil`（15 方法）

`com.seeyon.boot.starter.mybatis.service.AllInOneDBComplexUtil`

```java
    java.util.List<java.lang.Object> selectComplex(java.lang.String[], java.util.Map<java.lang.String, java.lang.Object>, java.lang.Boolean, com.seeyon.boot.transport.PageInfo, com.seeyon.boot.transport.Sort, java.lang.Class<?>);
    int selectComplexCount(java.util.Map<java.lang.String, java.lang.Object>, java.lang.Boolean, com.seeyon.boot.transport.PageInfo, com.seeyon.boot.transport.Sort, java.lang.Class<?>);
    java.lang.String selectComplexFunc(java.util.Map<java.lang.String, java.lang.Object>, java.lang.Boolean, com.seeyon.boot.transport.PageInfo, com.seeyon.boot.transport.Sort, java.lang.String, java.util.List, java.lang.Class<?>);
    int deleteComplex(java.util.Map<java.lang.String, java.lang.Object>, java.lang.Boolean, java.lang.Class<?>);
    private void tenantAdd(java.util.Map<java.lang.String, java.lang.Object>, java.lang.Boolean);
    private void jdbcComplexCondition(java.lang.StringBuilder, java.util.Map<java.lang.String, java.lang.Object>, java.util.Map<java.lang.String, java.lang.Object>, java.lang.Class<?>);
    private java.lang.String whereMatcher(java.lang.String);
    private java.lang.String buildQueryString(java.lang.String, java.lang.String[], java.util.Map<java.lang.String, java.lang.String>, java.lang.String, com.seeyon.boot.transport.PageInfo, com.seeyon.boot.transport.Sort, java.lang.Class<?>);
    private java.lang.String buildFuncQueryString(java.lang.String, java.lang.String, com.seeyon.boot.transport.PageInfo, com.seeyon.boot.transport.Sort, java.lang.String, java.util.List, java.lang.Class<?>);
    private java.lang.String buildCountQueryString(java.lang.String, java.lang.String, com.seeyon.boot.transport.PageInfo, com.seeyon.boot.transport.Sort, java.lang.Class<?>);
    private void getSortSql(com.seeyon.boot.transport.Sort, java.lang.StringBuilder, java.lang.Class<?>);
    private java.lang.String getPageSql(com.seeyon.boot.transport.PageInfo, java.lang.String);
    private void appendClause(java.lang.StringBuilder, java.lang.String);
    private void appendColumns(java.lang.StringBuilder, java.lang.String[], java.util.Map<java.lang.String, java.lang.String>);
    private void appendColumns(java.lang.StringBuilder, java.util.Map<java.lang.String, java.lang.String>);
```

### `AllInOneDBDynamicSeeyonKeyMapUtil`（15 方法）

`com.seeyon.boot.starter.mybatis.service.AllInOneDBDynamicSeeyonKeyMapUtil`

```java
    java.util.List<java.lang.Object> selectDynamic(java.lang.String[], java.util.List<com.seeyon.boot.starter.mybatis.util.SeeyonKeyMap>, java.lang.Boolean, com.seeyon.boot.transport.PageInfo, com.seeyon.boot.transport.Sort, java.lang.Class<?>);
    int selectDynamicCount(java.util.List<com.seeyon.boot.starter.mybatis.util.SeeyonKeyMap>, java.lang.Boolean, com.seeyon.boot.transport.PageInfo, com.seeyon.boot.transport.Sort, java.lang.Class<?>);
    java.lang.String selectDynamicFunc(java.util.List<com.seeyon.boot.starter.mybatis.util.SeeyonKeyMap>, java.lang.Boolean, com.seeyon.boot.transport.PageInfo, com.seeyon.boot.transport.Sort, java.lang.String, java.util.List, java.lang.Class<?>);
    int deleteDynamic(java.util.List<com.seeyon.boot.starter.mybatis.util.SeeyonKeyMap>, java.lang.Boolean, java.lang.Class<?>);
    private void tenantAdd(java.util.List<com.seeyon.boot.starter.mybatis.util.SeeyonKeyMap>, java.lang.Boolean);
    private void jdbcDynamicCondition(java.lang.StringBuilder, java.util.List<com.seeyon.boot.starter.mybatis.util.SeeyonKeyMap>, java.util.Map<java.lang.String, java.lang.Object>, java.lang.Class<?>, com.seeyon.boot.starter.mybatis.util.SeeyonInteger);
    private java.lang.String whereMatcher(java.lang.String);
    private java.lang.String buildQueryString(java.lang.String, java.lang.String[], java.util.Map<java.lang.String, java.lang.String>, java.lang.String, com.seeyon.boot.transport.PageInfo, com.seeyon.boot.transport.Sort, java.lang.Class<?>);
    private java.lang.String buildFuncQueryString(java.lang.String, java.lang.String, com.seeyon.boot.transport.PageInfo, com.seeyon.boot.transport.Sort, java.lang.String, java.util.List, java.lang.Class<?>);
    private java.lang.String buildCountQueryString(java.lang.String, java.lang.String, com.seeyon.boot.transport.PageInfo, com.seeyon.boot.transport.Sort, java.lang.Class<?>);
    private void getSortSql(com.seeyon.boot.transport.Sort, java.lang.StringBuilder, java.lang.Class<?>);
    private java.lang.String getPageSql(com.seeyon.boot.transport.PageInfo, java.lang.String);
    private void appendClause(java.lang.StringBuilder, java.lang.String);
    private void appendColumns(java.lang.StringBuilder, java.lang.String[], java.util.Map<java.lang.String, java.lang.String>);
    private void appendColumns(java.lang.StringBuilder, java.util.Map<java.lang.String, java.lang.String>);
```

### `AllInOneDBDynamicUtil`（15 方法）

`com.seeyon.boot.starter.mybatis.service.AllInOneDBDynamicUtil`

```java
    java.util.List<java.lang.Object> selectDynamic(java.lang.String[], java.util.Map<java.lang.String, java.lang.Object>, java.lang.Boolean, com.seeyon.boot.transport.PageInfo, com.seeyon.boot.transport.Sort, java.lang.Class<?>);
    int selectDynamicCount(java.util.Map<java.lang.String, java.lang.Object>, java.lang.Boolean, com.seeyon.boot.transport.PageInfo, com.seeyon.boot.transport.Sort, java.lang.Class<?>);
    java.lang.String selectDynamicFunc(java.util.Map<java.lang.String, java.lang.Object>, java.lang.Boolean, com.seeyon.boot.transport.PageInfo, com.seeyon.boot.transport.Sort, java.lang.String, java.util.List, java.lang.Class<?>);
    int deleteDynamic(java.util.Map<java.lang.String, java.lang.Object>, java.lang.Boolean, java.lang.Class<?>);
    private void tenantAdd(java.util.Map<java.lang.String, java.lang.Object>, java.lang.Boolean);
    private void jdbcDynamicCondition(java.lang.StringBuilder, java.util.Map<java.lang.String, java.lang.Object>, java.util.Map<java.lang.String, java.lang.Object>, java.lang.Class<?>, com.seeyon.boot.starter.mybatis.util.SeeyonInteger);
    private java.lang.String whereMatcher(java.lang.String);
    private java.lang.String buildQueryString(java.lang.String, java.lang.String[], java.util.Map<java.lang.String, java.lang.String>, java.lang.String, com.seeyon.boot.transport.PageInfo, com.seeyon.boot.transport.Sort, java.lang.Class<?>);
    private java.lang.String buildFuncQueryString(java.lang.String, java.lang.String, com.seeyon.boot.transport.PageInfo, com.seeyon.boot.transport.Sort, java.lang.String, java.util.List, java.lang.Class<?>);
    private java.lang.String buildCountQueryString(java.lang.String, java.lang.String, com.seeyon.boot.transport.PageInfo, com.seeyon.boot.transport.Sort, java.lang.Class<?>);
    private void getSortSql(com.seeyon.boot.transport.Sort, java.lang.StringBuilder, java.lang.Class<?>);
    private java.lang.String getPageSql(com.seeyon.boot.transport.PageInfo, java.lang.String);
    private void appendClause(java.lang.StringBuilder, java.lang.String);
    private void appendColumns(java.lang.StringBuilder, java.lang.String[], java.util.Map<java.lang.String, java.lang.String>);
    private void appendColumns(java.lang.StringBuilder, java.util.Map<java.lang.String, java.lang.String>);
```

### `MybatisAutoConfiguration`（14 方法）

`com.seeyon.boot.starter.mybatis.MybatisAutoConfiguration`

```java
    org.apache.ibatis.session.SqlSessionFactory sqlSessionFactory(javax.sql.DataSource, com.seeyon.boot.starter.mybatis.MybatisProperties);
    private void customConfig(org.apache.ibatis.session.Configuration, com.seeyon.boot.starter.mybatis.MybatisProperties);
    org.apache.ibatis.mapping.DatabaseIdProvider getDatabaseIdProvider();
    void setDatabaseIdProvider(org.apache.ibatis.mapping.DatabaseIdProvider);
    org.springframework.core.io.ResourceLoader getResourceLoader();
    void setResourceLoader(org.springframework.core.io.ResourceLoader);
    com.seeyon.boot.starter.mybatis.interceptor.QueryInterceptor queryInterceptor();
    com.seeyon.boot.starter.mybatis.interceptor.AggregationInterceptor aggregationInterceptor();
    com.seeyon.boot.starter.mybatis.interceptor.UpdateInterceptor updateInterceptor();
    com.seeyon.boot.starter.mybatis.interceptor.DataAuditInterceptor dataAuditInterceptor();
    com.seeyon.boot.starter.mybatis.interceptor.DtoDesensitizationInterceptor dataDesensitizationInterceptor();
    void scanAndProcessEntityClasses(java.lang.String);
```

### `PermissionCheckUtil`（11 方法）

`com.seeyon.boot.starter.mybatis.util.PermissionCheckUtil`

```java
    static protected static boolean sqlValidate(java.lang.String);
    static java.lang.String convertSql(java.lang.String, java.lang.String, java.lang.String);
    static private static java.lang.String buildSqlConditionItem(java.lang.Object, java.lang.String, java.lang.String);
    static private static java.lang.String buildSqlForOrAnd(java.lang.Object, java.lang.String, java.lang.String, java.lang.String);
    static private static java.lang.String buildSqlForOrAndGetItemKey(java.lang.Object);
    static private static java.lang.Object buildSqlForOrAndGetItemValue(java.lang.Object);
    static private static java.lang.String buildSqlForAttribute(java.lang.String, java.lang.String, java.lang.String, java.lang.String);
    static java.lang.Object dateParser(java.lang.Class<?>, java.lang.String, java.lang.String);
    static private static java.lang.Class<?> getTableColumnType(java.lang.String, java.lang.String);
    static private static java.lang.String getTableColumnName(java.lang.String, java.lang.String);
```

### `DataSignRuleService`（10 方法）

`com.seeyon.boot.starter.mybatis.service.DataSignRuleService`

```java
    com.seeyon.boot.starter.mybatis.model.DataSignRuleMessageModel getMessageRule(java.lang.String);
    java.lang.String getRule();
    java.util.LinkedList<java.lang.String> getSignField(java.lang.String);
    java.lang.Boolean enable();
    void update();
    void run()
    void ruleCacheUpdate();
    void enableCacheUpdate();
    private java.lang.String getEnableKey();
    private java.lang.String getRuleKey();
```

### `EnumArrayCodeTypeHandler`（10 方法）

`com.seeyon.boot.starter.mybatis.type.EnumArrayCodeTypeHandler`

```java
    void setParameter(java.sql.PreparedStatement, int, java.util.List<com.seeyon.boot.enums.Messageable>, org.apache.ibatis.type.JdbcType)
    void setNonNullParameter(java.sql.PreparedStatement, int, java.util.List<com.seeyon.boot.enums.Messageable>, org.apache.ibatis.type.JdbcType)
    java.util.List<com.seeyon.boot.enums.Messageable> getNullableResult(java.sql.ResultSet, java.lang.String)
    java.util.List<com.seeyon.boot.enums.Messageable> getNullableResult(java.sql.ResultSet, int)
    java.util.List<com.seeyon.boot.enums.Messageable> getNullableResult(java.sql.CallableStatement, int)
    java.lang.Object getNullableResult(java.sql.CallableStatement, int)
    java.lang.Object getNullableResult(java.sql.ResultSet, int)
    java.lang.Object getNullableResult(java.sql.ResultSet, java.lang.String)
    void setNonNullParameter(java.sql.PreparedStatement, int, java.lang.Object, org.apache.ibatis.type.JdbcType)
    void setParameter(java.sql.PreparedStatement, int, java.lang.Object, org.apache.ibatis.type.JdbcType)
```

### `ExSqlHelper`（10 方法）

`com.seeyon.boot.starter.mybatis.util.ExSqlHelper`

```java
    static java.lang.String wherePKColumns(java.lang.Class<?>, java.lang.String, boolean);
    static java.lang.String whereVersion(java.lang.Class<?>, java.lang.String);
    static java.lang.String exampleSelectColumns(java.lang.Class<?>);
    static java.lang.String exampleCountColumn(java.lang.Class<?>);
    static java.lang.String exampleOrderBy(java.lang.Class<?>);
    static java.lang.String exampleOrderBy(java.lang.String, java.lang.Class<?>);
    static java.lang.String exampleForUpdate();
    static java.lang.String exampleCheck(java.lang.Class<?>);
    static java.lang.String exampleWhereClause();
    static java.lang.String updateByExampleWhereClause();
```

### `MapperConfig`（9 方法）

`com.seeyon.boot.starter.mybatis.MapperConfig`

```java
    void processConfig();
    void processConfigForModuleClassloader(com.seeyon.boot.loader.ModuleClassLoader);
    void clearCacheForModuleClassloader(com.seeyon.boot.loader.ModuleClassLoader);
    private void initMappedStatementIfNecessary();
    void processConfigByPrefix(java.lang.String);
    void reProcessLeakMappedStatements();
    private void processCurAppConfiguration(tk.mybatis.mapper.mapperhelper.MapperHelper, org.apache.ibatis.session.Configuration, java.lang.String);
```

### `EnumCodeTypeHandler`（9 方法）

`com.seeyon.boot.starter.mybatis.type.EnumCodeTypeHandler`

```java
    java.lang.Class getType();
    void setNonNullParameter(java.sql.PreparedStatement, int, com.seeyon.boot.enums.Messageable, org.apache.ibatis.type.JdbcType)
    E getNullableResult(java.sql.ResultSet, java.lang.String)
    E getNullableResult(java.sql.ResultSet, int)
    E getNullableResult(java.sql.CallableStatement, int)
    java.lang.Object getNullableResult(java.sql.CallableStatement, int)
    java.lang.Object getNullableResult(java.sql.ResultSet, int)
    java.lang.Object getNullableResult(java.sql.ResultSet, java.lang.String)
    void setNonNullParameter(java.sql.PreparedStatement, int, java.lang.Object, org.apache.ibatis.type.JdbcType)
```

### `SeeyonDateTypeHandler`（8 方法）

`com.seeyon.boot.starter.mybatis.type.SeeyonDateTypeHandler`

```java
    void setNonNullParameter(java.sql.PreparedStatement, int, java.util.Date, org.apache.ibatis.type.JdbcType)
    java.util.Date getNullableResult(java.sql.ResultSet, java.lang.String)
    java.util.Date getNullableResult(java.sql.ResultSet, int)
    java.util.Date getNullableResult(java.sql.CallableStatement, int)
    java.lang.Object getNullableResult(java.sql.CallableStatement, int)
    java.lang.Object getNullableResult(java.sql.ResultSet, int)
    java.lang.Object getNullableResult(java.sql.ResultSet, java.lang.String)
    void setNonNullParameter(java.sql.PreparedStatement, int, java.lang.Object, org.apache.ibatis.type.JdbcType)
```

### `AllInOneDataParseUtil`（7 方法）

`com.seeyon.boot.starter.mybatis.service.AllInOneDataParseUtil`

```java
    java.util.List<java.lang.Object> parseData(java.util.List<java.util.Map<java.lang.String, java.lang.Object>>, java.lang.Class<?>, java.util.Map<java.lang.String, java.lang.reflect.Field>);
    private void process(java.lang.Object, java.util.List<com.seeyon.boot.starter.mybatis.support.SafeField>);
    private void reversibleDecrypt(com.seeyon.boot.starter.mybatis.support.SafeField, java.lang.Object);
    java.lang.Object fieldParse(java.lang.Object, java.lang.Class<?>, java.lang.String, java.util.Map<java.lang.String, java.lang.reflect.Field>);
    private java.lang.Object dataParser(java.lang.Class<?>, java.lang.Object, java.lang.String, java.lang.Class<?>);
    private java.lang.Object parseIntegerField(java.lang.Class, java.lang.Object);
```

### `SeeyonSqlHelper`（7 方法）

`com.seeyon.boot.starter.mybatis.util.SeeyonSqlHelper`

```java
    static java.lang.Object valueParser(java.lang.Object, tk.mybatis.mapper.entity.EntityColumn);
    static java.lang.Object valueParser(java.lang.Object, java.lang.Class<?>);
    static java.lang.String updateSetColumns(java.lang.Class<?>, java.lang.String, boolean, boolean);
    static java.lang.String updateSetColumns(java.lang.Class<?>, java.lang.String, boolean, boolean, java.util.Set<java.lang.String>);
    static java.lang.String getIfNotNull(java.lang.String, tk.mybatis.mapper.entity.EntityColumn, java.lang.String, boolean);
    static java.lang.String logicDeleteColumnEqualsValue(tk.mybatis.mapper.entity.EntityColumn, boolean);
    static int getLogicDeletedValue(tk.mybatis.mapper.entity.EntityColumn, boolean);
```

### `SeeyonEntityHelper`（7 方法）

`tk.mybatis.mapper.mapperhelper.SeeyonEntityHelper`

```java
    static void setResolve();
    static tk.mybatis.mapper.mapperhelper.SeeyonEntityColumns getEntityColumns(java.lang.Class<?>);
    static boolean contains(java.lang.Class<?>);
    static void initEntity(java.lang.Class<?>);
    static private static void _getFields(java.lang.Class<?>, tk.mybatis.mapper.mapperhelper.SeeyonEntityColumns);
    static void clear(java.lang.Class<?>);
```

### `DataSignService`（6 方法）

`com.seeyon.boot.starter.mybatis.encrypt.DataSignService`

```java
    java.lang.Boolean envEnable();
    java.util.Map<java.lang.String, java.lang.String> SignatureList(java.util.List<java.lang.String>);
    java.lang.String Signature(java.lang.String);
    java.lang.Boolean Verify(java.lang.String, java.lang.String);
    java.util.Map<java.lang.String, java.lang.Boolean> VerifyList(java.util.Map<java.lang.String, java.lang.String>);
    void setDataSignExecution(com.seeyon.boot.spi.DataSignExecution);
```

### `ObjToMapUtil`（6 方法）

`com.seeyon.boot.starter.mybatis.util.ObjToMapUtil`

```java
    static void remove(java.lang.Class);
    static java.util.Map<java.lang.String, java.lang.Object> objectToMap(java.lang.Object);
    static private static java.lang.String lowerFirst(java.lang.String);
    static java.util.Map<java.lang.String, java.lang.Object> objectToMap(java.lang.Object, java.lang.Boolean);
    static <T> T mapToObject(java.util.Map<java.lang.String, java.lang.Object>, java.lang.Class<T>);
    static private static <T> void setFieldValue(T, java.lang.String, java.lang.Object)
```

### `SQLWildcardUtil`（6 方法）

`com.seeyon.boot.starter.mybatis.util.SQLWildcardUtil`

```java
    static private static void initEscape();
    static java.lang.String escape(java.lang.String);
    static boolean requireEscape(java.lang.String);
    static java.lang.String setEscapeCharacter();
    static java.lang.String likeLowerCase(java.lang.String);
    static java.lang.String chineseOrderBy(java.lang.String);
```

### `ThreadLocalUtil`（6 方法）

`com.seeyon.boot.starter.mybatis.util.ThreadLocalUtil`

```java
    static <T> T get(java.lang.String);
    static <T> T get(java.lang.String, T);
    static void set(java.lang.String, java.lang.Object);
    static void remove();
```

### `DataSignMybatisService`（5 方法）

`com.seeyon.boot.starter.mybatis.encrypt.DataSignMybatisService`

```java
    java.lang.String sign(java.lang.Object);
    void verify(java.util.List);
    private void sendMessage(java.lang.Object);
    private java.lang.String getSignStr(java.lang.Object);
    private boolean enable();
```

### `AllDbService`（4 方法）

`com.seeyon.boot.starter.mybatis.service.AllDbService`

```java
    <T> java.util.List<T> selectListByConditionsAllDatabase(java.lang.Class<T>, java.util.Map<java.lang.String, java.lang.Object>, com.seeyon.boot.transport.Sort);
    <T> java.util.List<T> selectListByConditionsAllDatabase(java.util.Set<java.lang.String>, java.lang.Class<T>, java.util.Map<java.lang.String, java.lang.Object>, com.seeyon.boot.transport.Sort);
    <T> T selectOneByConditionsAllDatabase(java.lang.Class<T>, java.util.Map<java.lang.String, java.lang.Object>, com.seeyon.boot.transport.Sort);
    private void check(java.lang.Class<?>);
```

### `SecretEnumUpdateService`（4 方法）

`com.seeyon.boot.starter.mybatis.service.SecretEnumUpdateService`

```java
    java.lang.Integer getSecretOrder(java.lang.Long, java.lang.Long);
    void update();
    private void updateCache(java.lang.Long);
    java.lang.String getCompleteCacheKeyWithoutAppName(java.lang.Long);
```

### `DbAdapterUtil`（4 方法）

`com.seeyon.boot.starter.mybatis.util.DbAdapterUtil`

```java
    static org.springframework.core.io.Resource dbAdapter(org.springframework.core.io.Resource, javax.sql.DataSource)
    static org.springframework.core.io.Resource dbAdapter(org.springframework.core.io.Resource, java.sql.Connection)
    static java.lang.String dbAdapter(java.lang.String, javax.sql.DataSource)
    static java.lang.String dbAdapter(java.lang.String, java.sql.Connection)
```

### `EntityEncryptionService`（3 方法）

`com.seeyon.boot.starter.mybatis.encrypt.EntityEncryptionService`

```java
    java.lang.String encrypt(java.lang.String);
    java.lang.Object decrypt(java.lang.Object, com.seeyon.boot.annotation.enums.EncryptionType);
    void spiInit(com.seeyon.boot.spi.EntityEncryption);
```

### `StringToDateConverter`（3 方法）

`com.seeyon.boot.starter.mybatis.support.StringToDateConverter`

```java
    java.util.Date convert(java.lang.String);
    private void addDefaultFormats();
    java.lang.Object convert(java.lang.Object);
```

### `SeeyonConditionHelper`（3 方法）

`com.seeyon.boot.starter.mybatis.util.SeeyonConditionHelper`

```java
    static void dynamicCondition(java.lang.StringBuilder, java.util.Map<java.lang.String, java.lang.Object>, java.util.Map<java.lang.String, java.lang.Object>, java.util.Map<java.lang.String, tk.mybatis.mapper.entity.EntityColumn>, java.lang.Class<?>, com.seeyon.boot.starter.mybatis.util.SeeyonInteger);
    static void complexCondition(java.lang.StringBuilder, java.util.Map<java.lang.String, java.lang.Object>, java.util.Map<java.lang.String, java.lang.Object>, java.util.Map<java.lang.String, tk.mybatis.mapper.entity.EntityColumn>, java.lang.Class<?>);
    static void condition(java.lang.StringBuilder, java.util.Map<java.lang.String, java.lang.Object>, java.util.Map<java.lang.String, java.lang.Object>, java.util.Map<java.lang.String, tk.mybatis.mapper.entity.EntityColumn>, java.lang.Class<?>);
```

### `SeeyonSqlParserUtils`（3 方法）

`com.seeyon.boot.starter.mybatis.util.SeeyonSqlParserUtils`

```java
    static com.alibaba.druid.sql.parser.SQLStatementParser createSQLStatementParser(java.lang.String, com.seeyon.boot.domain.dao.support.DatabaseType);
    static com.alibaba.druid.sql.parser.SQLExprParser createExprParser(java.lang.String, com.seeyon.boot.domain.dao.support.DatabaseType);
    static com.alibaba.druid.sql.parser.SQLExprParser createExprParser(java.lang.String, com.seeyon.boot.domain.dao.support.DatabaseType, com.alibaba.druid.sql.parser.SQLParserFeature...);
```

## 三、注解（1）

| 注解 | 元素 |
|---|---|
| `CountSql` | value |

## 四、枚举（1）

- `AllInOneDBType`（3 常量）：INSERT, UPDATE, DELETE
