# boot-starter-ganttchart：接口与方法签名

> 自动生成，勿手改。`tools/core/platform/emit_package_surfaces.py` 重跑即可。
> 构件 `com.seeyon:boot-starter-ganttchart`（jar `boot-starter-ganttchart-5.3.600.jar`）
> 规模：50 类 / 1 接口 / 0 注解 / 1 枚举 / 8 个关键类 / 572 方法。
> 签名逐字来自 javap 原文；已去掉 `public` 前缀与 `throws` 子句。

## 一、接口（1）

### `GanttChartSchemaDao`（0 方法） extends GanttChartSchema>

`com.seeyon.boot.starter.ganttchart.domain.dao.GanttChartSchemaDao`

```java
```

## 二、关键类（8）

### `GanttChartUtil`（36 方法）

`com.seeyon.boot.starter.ganttchart.utils.GanttChartUtil`

```java
    static com.seeyon.boot.starter.ganttchart.dto.GanttChartDefinitionDto findTargetDefine(com.seeyon.boot.starter.ganttchart.dto.GanttChartDto, com.seeyon.boot.starter.ganttchart.enums.GanttChartTypeEnum);
    static void ganttToFormData(java.lang.Object, java.lang.Object, com.seeyon.boot.starter.ganttchart.dto.GanttChartDefinitionDto, boolean, java.util.Map<java.lang.String, java.util.Map<java.lang.String, com.seeyon.ctp.metadata.dto.model.JavaEnumItemDto>>, java.util.Map<java.lang.String, java.lang.Object>);
    static void setFieldValue(java.lang.Object, java.lang.String, java.lang.Object);
    static void copyProcessFormData(java.util.List<java.lang.Object>, java.lang.String, java.lang.Long, boolean);
    static void getTaskIdMap(java.util.List<java.lang.Object>, java.util.Map<java.lang.Long, java.lang.Long>);
    static void replaceTaskUid(java.util.List<java.lang.Object>, java.lang.String, java.util.Map<java.lang.Long, java.lang.Long>);
    static void replaceActionType(java.util.List<java.lang.Object>, com.seeyon.boot.enums.ActionType);
    static com.seeyon.boot.starter.ganttchart.dto.GanttChartFieldMappingDto findTargetDefineField(com.seeyon.boot.starter.ganttchart.dto.GanttChartDefinitionDto, java.lang.String);
    static java.lang.String findTargetDefineFieldToSingleName(com.seeyon.boot.starter.ganttchart.dto.GanttChartDefinitionDto, java.lang.String);
    java.lang.Long invokeInsertDynamicMethod(java.lang.String, java.lang.Object, java.lang.Boolean);
    static private static java.lang.String getInterfaceNameByEntityFullName(java.lang.String, java.lang.String);
    static private static java.lang.String fullNameToAppName(java.lang.String);
    static java.lang.String entityToAppServiceByName(java.lang.String);
    static java.lang.Object getEntityAppServiceByName(java.lang.String);
    java.util.List<java.lang.Object> invokeSelectListByConditionsDynamicMethod(java.lang.String, com.seeyon.boot.transport.ListRequest);
    java.lang.Integer invokeUpdateDynamicMethod(java.lang.String, java.lang.Object);
    java.lang.Integer invokeUpdateDynamicMethod(java.lang.String, java.lang.Object, java.lang.Boolean);
    java.lang.Integer invokeDeleteDynamicMethod(java.lang.String, java.util.List<java.lang.Long>);
    java.lang.Integer invokeOperateRootBatchDynamicMethod(java.lang.String, java.lang.Object);
    java.util.List<java.lang.Object> invokeSelectListDynamicMethod(java.lang.String, com.seeyon.boot.transport.ListRequest);
    java.lang.Object invokeSelectByIdDynamicMethod(java.lang.String, java.lang.Long);
    static java.lang.String getEntityAppServiceName(java.lang.String);
    static java.lang.String entityToAppServiceName(java.lang.String);
    static java.lang.Object classNameToObject(java.lang.String)
    static java.lang.String transFirstCharToLowerCase(java.lang.String);
    static java.lang.String entityFullNameToDtoFullName(java.lang.String);
    static java.lang.String entityFullNameToAppServiceFullName(java.lang.String);
    static java.lang.String entityFullNameToDtoList(java.lang.String);
    static java.lang.String fullNameToSingleName(java.lang.String);
    static java.lang.String fullNameExcSingleName(java.lang.String);
    static void saveAuditLog(java.lang.String, java.lang.String);
```

### `GanttChartService`（22 方法）

`com.seeyon.boot.starter.ganttchart.domain.service.GanttChartService`

```java
    java.lang.Long saveProject(com.seeyon.boot.starter.ganttchart.dto.wbs.ProjectDto, com.seeyon.boot.starter.ganttchart.dto.GanttChartDto);
    private java.lang.Integer saveOrUpdateTaskParticipant(com.seeyon.boot.starter.ganttchart.dto.wbs.ProjectDto, com.seeyon.boot.starter.ganttchart.dto.GanttChartDefinitionDto, com.seeyon.boot.starter.ganttchart.dto.wbs.DeleteIdGroupDto);
    private java.lang.Integer saveOrUpdateOccupiedResources(com.seeyon.boot.starter.ganttchart.dto.wbs.ProjectDto, com.seeyon.boot.starter.ganttchart.dto.GanttChartDefinitionDto, com.seeyon.boot.starter.ganttchart.dto.wbs.DeleteIdGroupDto);
    private java.lang.Integer saveOrUpdatePredecessor(com.seeyon.boot.starter.ganttchart.dto.wbs.ProjectDto, com.seeyon.boot.starter.ganttchart.dto.GanttChartDefinitionDto, com.seeyon.boot.starter.ganttchart.dto.wbs.DeleteIdGroupDto);
    private void saveOrUpdateTask(com.seeyon.boot.starter.ganttchart.dto.wbs.ProjectDto, com.seeyon.boot.starter.ganttchart.dto.GanttChartDto);
    private void buildSubTaskParticipant(com.seeyon.boot.starter.ganttchart.dto.wbs.DeleteIdGroupDto, java.lang.Object, com.seeyon.boot.starter.ganttchart.dto.wbs.TaskDto, com.seeyon.boot.starter.ganttchart.dto.GanttChartDefinitionDto, java.util.Map<java.lang.String, java.util.Map<java.lang.String, com.seeyon.ctp.metadata.dto.model.JavaEnumItemDto>>);
    private void buildSubOccupiedResources(com.seeyon.boot.starter.ganttchart.dto.wbs.DeleteIdGroupDto, java.lang.Object, com.seeyon.boot.starter.ganttchart.dto.wbs.TaskDto, com.seeyon.boot.starter.ganttchart.dto.GanttChartDefinitionDto, java.util.Map<java.lang.String, java.util.Map<java.lang.String, com.seeyon.ctp.metadata.dto.model.JavaEnumItemDto>>);
    private void buildSubPredecessor(com.seeyon.boot.starter.ganttchart.dto.wbs.DeleteIdGroupDto, java.lang.Object, com.seeyon.boot.starter.ganttchart.dto.wbs.TaskDto, com.seeyon.boot.starter.ganttchart.dto.GanttChartDefinitionDto, java.util.Map<java.lang.String, java.util.Map<java.lang.String, com.seeyon.ctp.metadata.dto.model.JavaEnumItemDto>>);
    private java.lang.Long saveOrUpdateProject(com.seeyon.boot.starter.ganttchart.dto.wbs.ProjectDto, com.seeyon.boot.starter.ganttchart.dto.GanttChartDto);
    java.lang.Object buildObjectData(java.lang.Object, com.seeyon.boot.starter.ganttchart.dto.GanttChartDefinitionDto, java.lang.Long, java.lang.String, java.util.Map<java.lang.String, java.util.Map<java.lang.String, com.seeyon.ctp.metadata.dto.model.JavaEnumItemDto>>, java.util.Map<java.lang.String, java.lang.Object>);
    com.seeyon.ctp.metadata.dto.AggEntityMetadataDto selectAggEntityMetadataByFullName(java.lang.String, java.lang.String);
    java.util.Map<java.lang.String, java.util.Map<java.lang.String, com.seeyon.ctp.metadata.dto.model.JavaEnumItemDto>> getEnumMap(java.lang.String);
    java.lang.Long copyWbs(java.lang.Long, java.lang.Long, com.seeyon.boot.starter.ganttchart.dto.GanttChartDto);
    java.util.List<java.lang.Object> processData(com.seeyon.boot.starter.ganttchart.dto.GanttChartDefinitionDto, java.lang.Long, java.lang.Long, java.lang.Long, boolean);
    void deleteByWbsId(java.lang.Long, java.lang.Long, com.seeyon.boot.starter.ganttchart.dto.GanttChartDto);
```

### `GanttChartSchemaService`（14 方法）

`com.seeyon.boot.starter.ganttchart.domain.service.GanttChartSchemaService`

```java
    java.lang.Long create(com.seeyon.boot.starter.ganttchart.dto.setting.GanttChartSchemaDto);
    java.lang.Integer update(com.seeyon.boot.starter.ganttchart.dto.setting.GanttChartSchemaDto);
    com.seeyon.boot.starter.ganttchart.dto.setting.GanttChartSchemaDto selectById(java.lang.Long);
    java.util.List<com.seeyon.boot.starter.ganttchart.dto.setting.GanttChartSchemaDto> selectListByConditions(java.util.Map<java.lang.String, java.lang.Object>, com.seeyon.boot.transport.Sort);
    com.seeyon.boot.transport.PageData<com.seeyon.boot.starter.ganttchart.dto.setting.GanttChartSchemaDto> selectPageByConditions(com.seeyon.boot.transport.PageInfo, java.util.Map<java.lang.String, java.lang.Object>, com.seeyon.boot.transport.Sort);
    java.lang.Integer updateActive(com.seeyon.boot.starter.ganttchart.dto.setting.GanttChartSchemaUpdateActiveDto);
    java.lang.Integer deleteByIds(java.util.List<java.lang.Long>);
    java.lang.Long copyById(java.lang.Long);
    private void copyCode(com.seeyon.boot.starter.ganttchart.domain.entity.GanttChartSchema);
    private void copyName(com.seeyon.boot.starter.ganttchart.domain.entity.GanttChartSchema);
    com.seeyon.boot.starter.ganttchart.dto.setting.GanttChartSchemaDto selectByCode(java.lang.String);
```

### `GanttChartAppService`（13 方法）

`com.seeyon.boot.starter.ganttchart.appservice.GanttChartAppService`

```java
    com.seeyon.boot.transport.SingleResponse<java.lang.Long> copyWbs(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.ganttchart.dto.GanttChartCopyDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> deleteByWbsId(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.ganttchart.dto.GanttChartCopyDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Long> saveProject(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.ganttchart.dto.wbs.WbsSaveDto>);
    private java.util.List<com.seeyon.boot.starter.ganttchart.dto.wbs.TaskDto> flatProcessTask(com.seeyon.boot.starter.ganttchart.dto.wbs.TaskDto, java.util.List<com.seeyon.boot.starter.ganttchart.dto.wbs.TaskDto>);
    com.seeyon.boot.transport.ListResponse<java.lang.Object> dynamicSelectByEntity(com.seeyon.boot.transport.ListRequest);
    com.seeyon.boot.transport.SingleResponse<java.util.Map<java.lang.String, java.lang.Object>> importWbs(com.seeyon.boot.transport.SingleRequest<java.lang.String>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.boot.starter.file.dto.FileDto> exportWbs(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.ganttchart.dto.wbs.WbsSaveDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.String> print(com.seeyon.boot.transport.SingleRequest<java.lang.String>);
    java.lang.String createImg(java.lang.String, java.lang.String)
    void savePage(java.lang.String, java.lang.String)
    static private static boolean is64Linux();
    static private static boolean is32Linux();
    static private static boolean isWindows();
```

### `GanttChartSchemaAppService`（9 方法）

`com.seeyon.boot.starter.ganttchart.appservice.GanttChartSchemaAppService`

```java
    com.seeyon.boot.transport.SingleResponse<java.lang.Long> create(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.ganttchart.dto.setting.GanttChartSchemaDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> update(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.ganttchart.dto.setting.GanttChartSchemaDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.boot.starter.ganttchart.dto.setting.GanttChartSchemaDto> selectListByConditions(com.seeyon.boot.transport.ListRequest);
    com.seeyon.boot.transport.PageResponse<com.seeyon.boot.starter.ganttchart.dto.setting.GanttChartSchemaDto> selectPageByConditions(com.seeyon.boot.transport.PageRequest);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> deleteByIds(com.seeyon.boot.transport.SingleRequest<java.util.List<java.lang.Long>>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Long> copyById(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.boot.starter.ganttchart.dto.setting.GanttChartSchemaDto> selectById(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.boot.starter.ganttchart.dto.setting.GanttChartSchemaDto> selectByCode(com.seeyon.boot.transport.SingleRequest<java.lang.String>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> updateActive(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.ganttchart.dto.setting.GanttChartSchemaUpdateActiveDto>);
```

### `GanttMetaDataAppServiceProxy`（7 方法）

`com.seeyon.boot.starter.ganttchart.utils.GanttMetaDataAppServiceProxy`

```java
    com.seeyon.ctp.metadata.dto.AggEntityMetadataDto selectAggEntityMetadataByFullName(java.lang.String, java.lang.String);
    java.util.List<com.seeyon.ctp.metadata.dto.DtoMetadataDto> selectPublicDtoMetadataList(java.lang.String);
    com.seeyon.boot.transport.SingleResponse<java.lang.Object> invokeAppService(java.lang.String, java.lang.String, java.lang.String, java.lang.Object, java.lang.String);
    com.seeyon.boot.transport.SingleResponse<java.lang.Object> invokeAppServiceOperateRootBatch(java.lang.String, java.lang.String, java.lang.String, java.lang.Object, java.lang.String, java.lang.String);
    com.seeyon.boot.transport.ListResponse<java.lang.Object> invokeAppServiceForList(java.lang.String, java.lang.String, java.lang.String, java.lang.Object);
    java.lang.String replaceAppName(java.lang.String, java.lang.String);
    java.lang.String getAppNameByFullName(java.lang.String);
```

### `StringUtil`（5 方法）

`com.seeyon.boot.starter.ganttchart.utils.StringUtil`

```java
    static boolean isNullOrEmpty(java.lang.Object);
    static java.lang.String toString(java.lang.Object);
    static int toInt(java.lang.String);
    static boolean isInteger(java.lang.String);
    static java.lang.String join(java.util.Collection, java.lang.String);
```

### `FileHelper`（3 方法）

`com.seeyon.boot.starter.ganttchart.utils.FileHelper`

```java
    static java.lang.String read(java.lang.String);
    static void write(java.lang.String, java.lang.String);
    static java.lang.String getFileName(java.lang.String);
```

## 四、枚举（1）

- `GanttChartTypeEnum`（9 常量）：PROJECT, RESOURCE, PROJECT_MEMBER, WBS, TASK, PREDECESSORS, OCCUPIED_RESOURCES, TASK_PARTICIPANT, ROLE_AUTHORIZATION
