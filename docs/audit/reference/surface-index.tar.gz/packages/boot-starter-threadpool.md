# boot-starter-threadpool：接口与方法签名

> 自动生成，勿手改。`tools/core/platform/emit_package_surfaces.py` 重跑即可。
> 构件 `com.seeyon:boot-starter-threadpool`（jar `boot-starter-threadpool-5.3.600.jar`）
> 规模：14 类 / 0 接口 / 1 注解 / 1 枚举 / 5 个关键类 / 113 方法。
> 签名逐字来自 javap 原文；已去掉 `public` 前缀与 `throws` 子句。

## 一、接口（0）

（本构件没有接口）

## 二、关键类（5）

### `SeeyonExecutorService`（24 方法）

`com.seeyon.boot.starter.threadpool.SeeyonExecutorService`

```java
    void shutdown();
    java.util.List<java.lang.Runnable> shutdownNow();
    boolean isShutdown();
    boolean isTerminated();
    boolean awaitTermination(long, java.util.concurrent.TimeUnit)
    <T> java.util.concurrent.Future<T> submit(java.util.concurrent.Callable<T>);
    <T> java.util.concurrent.Future<T> submitMiddle(java.util.concurrent.Callable<T>);
    <T> java.util.concurrent.Future<T> submitHigh(java.util.concurrent.Callable<T>);
    <T> java.util.concurrent.Future<T> submit(java.lang.Runnable, T);
    java.util.concurrent.Future<?> submit(java.lang.Runnable);
    java.util.concurrent.Future<?> submitMiddle(java.lang.Runnable);
    java.util.concurrent.Future<?> submitHigh(java.lang.Runnable);
    <T> java.util.List<java.util.concurrent.Future<T>> invokeAll(java.util.Collection<? extends java.util.concurrent.Callable<T>>)
    <T> java.util.List<java.util.concurrent.Future<T>> invokeAll(java.util.Collection<? extends java.util.concurrent.Callable<T>>, long, java.util.concurrent.TimeUnit)
    <T> T invokeAny(java.util.Collection<? extends java.util.concurrent.Callable<T>>)
    <T> T invokeAny(java.util.Collection<? extends java.util.concurrent.Callable<T>>, long, java.util.concurrent.TimeUnit)
    void execute(java.lang.Runnable);
    void executeMiddle(java.lang.Runnable);
    void executeHigh(java.lang.Runnable);
    private org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor getMiddleExecuter();
    private org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor getHighExecuter();
    org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor getDefaultExecutor();
    org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor getMiddleExecutor();
    org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor getHighExecutor();
```

### `IsolatorConfigItem`（15 方法）

`com.seeyon.boot.starter.threadpool.isolator.model.IsolatorConfigItem`

```java
    java.lang.String getThreadName();
    int getCoreSize();
    int getMaxSize();
    int getQueueSize();
    java.lang.String getName();
    com.seeyon.boot.starter.threadpool.isolator.consts.RejectionPolicyEnum getRejectionPolicy();
    void setCoreSize(int);
    void setMaxSize(int);
    void setQueueSize(int);
    void setName(java.lang.String);
    void setRejectionPolicy(com.seeyon.boot.starter.threadpool.isolator.consts.RejectionPolicyEnum);
    boolean equals(java.lang.Object);
    protected boolean canEqual(java.lang.Object);
    int hashCode();
    java.lang.String toString();
```

### `IsolatorExecutorService`（10 方法）

`com.seeyon.boot.starter.threadpool.isolator.IsolatorExecutorService`

```java
    void init()
    void registerExecutor(java.lang.String, org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor);
    java.util.concurrent.Future<?> submit(java.lang.Runnable, java.lang.String);
    <T> java.util.concurrent.Future<T> submit(java.util.concurrent.Callable<T>);
    <T> java.util.concurrent.Future<T> submit(java.util.concurrent.Callable<T>, java.lang.String);
    java.util.concurrent.Future<?> submit(java.lang.Runnable);
    void execute(java.lang.Runnable, java.lang.String);
    void execute(java.lang.Runnable);
    org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor getThreadPoolExecutor(java.lang.String);
    java.util.Map<java.lang.String, org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor> getIsolatorExecutors();
```

### `ThreadPoolAutoConfiguration`（3 方法）

`com.seeyon.boot.starter.threadpool.ThreadPoolAutoConfiguration`

```java
    java.util.concurrent.ExecutorService executorService(com.seeyon.boot.starter.threadpool.ThreadPoolProperties, com.seeyon.boot.starter.threadpool.ThreadPoolMiddleProperties, com.seeyon.boot.starter.threadpool.ThreadPoolHighProperties);
    private org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor taskExecutor(com.seeyon.boot.starter.threadpool.ThreadPoolBaseProperties);
```

### `IsolatorExecutorAspect`（3 方法）

`com.seeyon.boot.starter.threadpool.isolator.aspect.IsolatorExecutorAspect`

```java
    java.lang.Object aroundIsolatedMethod(org.aspectj.lang.ProceedingJoinPoint, com.seeyon.boot.starter.threadpool.isolator.annotation.IsolatorExecutor)
    private void initExecutor(com.seeyon.boot.starter.threadpool.isolator.annotation.IsolatorExecutor);
```

## 三、注解（1）

| 注解 | 元素 |
|---|---|
| `IsolatorExecutor` | isolatorName, coreSize, maxSize, queueSize, rejectionPolicy |

## 四、枚举（1）

- `RejectionPolicyEnum`（4 常量）：AbortPolicy, CallerRunsPolicy, DiscardPolicy, DiscardOldestPolicy
