# app-approval-facade：接口与方法签名

> 自动生成，勿手改。`tools/core/platform/emit_package_surfaces.py` 重跑即可。
> 构件 `com.seeyon:app-approval-facade`（jar `app-approval-facade-5.3.295.jar`）
> 规模：25 类 / 2 接口 / 0 注解 / 0 枚举 / 3 个关键类 / 257 方法。
> 签名逐字来自 javap 原文；已去掉 `public` 前缀与 `throws` 子句。

## 一、接口（2）

### `ApprovalAppService`（4 方法）

`com.seeyon.app.approval.api.ApprovalAppService`

```java
    default com.seeyon.boot.transport.SingleResponse<com.seeyon.app.approval.dto.ApprovalPageSchemaAndPermissionDto> getApprovalPageSchemaAndPermissionByAffairId(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    default com.seeyon.boot.transport.SingleResponse<java.lang.String> getFormDataByGraphql(com.seeyon.boot.transport.SingleRequest<com.seeyon.app.approval.dto.ApprovalGraphqlRequestDto>);
    default com.seeyon.boot.transport.SingleResponse<com.seeyon.app.approval.dto.auto.AutoGenerateResponseDto> autoGenerateApplication(com.seeyon.boot.transport.SingleRequest<com.seeyon.app.approval.dto.auto.AutoApplicationDto>);
    default com.seeyon.boot.transport.SingleResponse<java.lang.Void> deleteByAppIdList(com.seeyon.boot.transport.SingleRequest<java.util.List<java.lang.Long>>);
```

### `ApprovalFrameApiTransportAppService`（1 方法）

`com.seeyon.app.approval.api.ApprovalFrameApiTransportAppService`

```java
    com.seeyon.boot.transport.SingleResponse<java.lang.String> exportApprovalFrameInfo(com.seeyon.boot.transport.SingleRequest<com.seeyon.app.approval.dto.ApprovalFrameParamDto>);
```

## 二、关键类（3）

### `ApprovalApiTemplateListResponseDto`（24 方法）

`com.seeyon.app.approval.dto.ApprovalApiTemplateListResponseDto`

```java
    java.lang.Long getTemplateId();
    java.lang.Long getApplicationId();
    java.lang.String getSubject();
    java.lang.String getShortName();
    java.lang.Long getCreateAccountId();
    java.lang.String getCreateAccountName();
    java.lang.Long getCreateUserId();
    java.lang.String getCreateUserName();
    java.lang.String getCategoryName();
    boolean isFavorite();
    java.util.Date getCreateTime();
    java.lang.String getDescription();
    void setTemplateId(java.lang.Long);
    void setApplicationId(java.lang.Long);
    void setSubject(java.lang.String);
    void setShortName(java.lang.String);
    void setCreateAccountId(java.lang.Long);
    void setCreateAccountName(java.lang.String);
    void setCreateUserId(java.lang.Long);
    void setCreateUserName(java.lang.String);
    void setCategoryName(java.lang.String);
    void setFavorite(boolean);
    void setCreateTime(java.util.Date);
    void setDescription(java.lang.String);
```

### `AutoTemplateDto`（22 方法）

`com.seeyon.app.approval.dto.auto.AutoTemplateDto`

```java
    void setName(java.lang.String);
    void setCode(java.lang.String);
    void setEntityId(java.lang.Long);
    void setStartNodePermission(java.lang.Long);
    void setStartFormPermission(java.lang.Long);
    void setPcPage(java.lang.Long);
    void setMobilePage(java.lang.Long);
    void setDynamicTile(java.lang.String);
    void setProcessOverTimes(java.util.List<com.seeyon.app.approval.dto.auto.AutoProcessOverTimeDto>);
    void setProcesses(java.util.List<com.seeyon.app.approval.dto.auto.AutoProcessDto>);
    void setFormPermissions(java.util.List<com.seeyon.app.approval.dto.auto.AutoFormPermissionDto>);
    java.lang.String getName();
    java.lang.String getCode();
    java.lang.Long getEntityId();
    java.lang.Long getStartNodePermission();
    java.lang.Long getStartFormPermission();
    java.lang.Long getPcPage();
    java.lang.Long getMobilePage();
    java.lang.String getDynamicTile();
    java.util.List<com.seeyon.app.approval.dto.auto.AutoProcessOverTimeDto> getProcessOverTimes();
    java.util.List<com.seeyon.app.approval.dto.auto.AutoProcessDto> getProcesses();
    java.util.List<com.seeyon.app.approval.dto.auto.AutoFormPermissionDto> getFormPermissions();
```

### `ApprovalApiTemplateListRequestDto`（10 方法）

`com.seeyon.app.approval.dto.ApprovalApiTemplateListRequestDto`

```java
    java.lang.Long getUserId();
    java.lang.String getKeywords();
    com.seeyon.boot.transport.PageInfo getPageInfo();
    com.seeyon.boot.transport.Sort getSort();
    java.lang.String getCategoryCode();
    void setUserId(java.lang.Long);
    void setKeywords(java.lang.String);
    void setPageInfo(com.seeyon.boot.transport.PageInfo);
    void setSort(com.seeyon.boot.transport.Sort);
    void setCategoryCode(java.lang.String);
```
