# m5-facade：接口与方法签名

> 自动生成，勿手改。`tools/core/platform/emit_package_surfaces.py` 重跑即可。
> 构件 `com.seeyon:m5-facade`（jar `m5-facade-5.3.265.jar`）
> 规模：55 类 / 6 接口 / 0 注解 / 6 枚举 / 0 个关键类 / 504 方法。
> 签名逐字来自 javap 原文；已去掉 `public` 前缀与 `throws` 子句。

## 一、接口（6）

### `TeamworkCoreAppService`（13 方法）

`com.seeyon.m5.api.TeamworkCoreAppService`

```java
    com.seeyon.boot.transport.SingleResponse<java.lang.Long> launch(com.seeyon.boot.transport.SingleRequest<com.seeyon.m5.dto.group.TeamworkGroupCreateDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> dismiss(com.seeyon.boot.transport.SingleRequest<com.seeyon.m5.dto.group.TeamworkGroupDismissDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> join(com.seeyon.boot.transport.SingleRequest<com.seeyon.m5.dto.group.TeamworkGroupJoinDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> quit(com.seeyon.boot.transport.SingleRequest<com.seeyon.m5.dto.group.TeamworkGroupQuitDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> rename(com.seeyon.boot.transport.SingleRequest<com.seeyon.m5.dto.group.TeamworkGroupRenameDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> unbind(com.seeyon.boot.transport.SingleRequest<com.seeyon.m5.dto.group.TeamworkGroupUnbindDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.m5.dto.group.TeamworkGroupInfoDto> obtain(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.m5.dto.group.TeamworkGroupInfoDto> batchObtain(com.seeyon.boot.transport.SingleRequest<java.util.List<java.lang.Long>>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.m5.dto.group.TeamworkGroupInfoNumExtDto> batchObtainExt(com.seeyon.boot.transport.SingleRequest<java.util.List<java.lang.Long>>);
    com.seeyon.boot.transport.PageResponse<com.seeyon.m5.dto.group.TeamworkMemberInfoDto> obtainMemberPageListByCondition(com.seeyon.boot.transport.PageRequest);
    com.seeyon.boot.transport.ListResponse<com.seeyon.m5.dto.group.TeamworkMemberInfoDto> obtainAllMemberList(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.m5.dto.group.TeamworkMemberInfoDto> obtainMemberListRequiredFields(com.seeyon.boot.transport.SingleRequest<com.seeyon.m5.dto.group.TeamworkMemberRequiredFieldDto>);
    com.seeyon.boot.transport.ListResponse<java.lang.Long> obtainGroupIdListByUserId(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
```

### `EnterpriseCoreAppSerivce`（6 方法）

`com.seeyon.m5.api.enterprise.EnterpriseCoreAppSerivce`

```java
    com.seeyon.boot.transport.SingleResponse<java.lang.Long> createEnterprise(com.seeyon.boot.transport.SingleRequest<com.seeyon.m5.dto.enterprise.EnterpriseCreateDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> updateEnterprise(com.seeyon.boot.transport.SingleRequest<com.seeyon.m5.dto.enterprise.EnterpriseUpdateDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> deleteEnterprise(com.seeyon.boot.transport.SingleRequest<com.seeyon.m5.dto.enterprise.EnterpriseDeleteDto>);
    com.seeyon.boot.transport.PageResponse<com.seeyon.m5.dto.enterprise.EnterpriseDto> selectEnterprise(com.seeyon.boot.transport.PageRequest);
    com.seeyon.boot.transport.PageResponse<com.seeyon.m5.dto.enterprise.EnterpriseDto> selectsEnterprise(com.seeyon.boot.transport.PageRequest);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.m5.dto.enterprise.EnterpriseDto> selectByEnterpriseName(com.seeyon.boot.transport.SingleRequest<java.lang.String>);
```

### `TeamworkTabAppService`（5 方法）

`com.seeyon.m5.api.TeamworkTabAppService`

```java
    com.seeyon.boot.transport.SingleResponse<java.lang.Long> createTab(com.seeyon.boot.transport.SingleRequest<com.seeyon.m5.dto.grouptab.TeamworkGroupTabCreateDto>);
    com.seeyon.boot.transport.ListResponse<java.lang.Long> createTabs(com.seeyon.boot.transport.SingleRequest<java.util.List<com.seeyon.m5.dto.grouptab.TeamworkGroupTabCreateDto>>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> updateTab(com.seeyon.boot.transport.SingleRequest<com.seeyon.m5.dto.grouptab.TeamworkGroupTabUpdateDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> updateTabs(com.seeyon.boot.transport.SingleRequest<java.util.List<com.seeyon.m5.dto.grouptab.TeamworkGroupTabUpdateDto>>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> deleteTab(com.seeyon.boot.transport.SingleRequest<com.seeyon.m5.dto.grouptab.TeamworkGroupTabDeleteDto>);
```

### `AppManageCoreAppService`（3 方法）

`com.seeyon.m5.api.app.AppManageCoreAppService`

```java
    com.seeyon.boot.transport.SingleResponse<com.seeyon.m5.dto.app.AppCheckDto> check(com.seeyon.boot.transport.SingleRequest<com.seeyon.m5.dto.app.AppCheckRequestDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.String> getLatestDownloadUrl(com.seeyon.boot.transport.SingleRequest<java.lang.String>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.m5.dto.app.AppDto> getLatestApp(com.seeyon.boot.transport.SingleRequest<java.lang.String>);
```

### `TeamworkMessageAppService`（2 方法）

`com.seeyon.m5.api.TeamworkMessageAppService`

```java
    com.seeyon.boot.transport.SingleResponse<java.lang.Void> sendCard(com.seeyon.boot.transport.SingleRequest<com.seeyon.m5.dto.message.TeamworkCardMessageDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Long> createNotification(com.seeyon.boot.transport.SingleRequest<com.seeyon.m5.dto.message.TeamworkNotificationMessageDto>);
```

### `TeamworkTabGeneralizeAppService`（1 方法）

`com.seeyon.m5.api.TeamworkTabGeneralizeAppService`

```java
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> deleteTabs(com.seeyon.boot.transport.SingleRequest<com.seeyon.m5.dto.grouptab.TeamworkGroupTabListDto>);
```

## 四、枚举（6）

- `AppTypeEnum`（8 常量）：IOS, ANDROID, MAC_OS, WINDOWS, LINUX, LINUX_LONG_ARCH, LINUX_ARM, WINDOWS_32
- `AppUpdateTypeEnum`（3 常量）：OPTION_NOT_SILENT, FORCE, OPTION_SILENT
- `GroupRoleEnum`（4 常量）：OWNER, ADMIN, MEMBER, VISITOR
- `TabTypeEnum`（5 常量）：FILE, WEBSITE, APPLICATION, GROUP_FILE, MENU_PORTAL
- `GroupTypeEnum`（2 常量）：USUAL, APP
- `NotificationIntervalTypeEnum`（8 常量）：SINGLE, EVERY_DAY, TWO_DAY, THREE_DAY, FOUR_DAY, FIVE_DAY, SIX_DAY, WEEK
