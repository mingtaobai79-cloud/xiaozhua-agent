# boot-starter-nacos：接口与方法签名

> 自动生成，勿手改。`tools/core/platform/emit_package_surfaces.py` 重跑即可。
> 构件 `com.seeyon:boot-starter-nacos`（jar `boot-starter-nacos-5.3.600.jar`）
> 规模：26 类 / 4 接口 / 0 注解 / 1 枚举 / 10 个关键类 / 240 方法。
> 签名逐字来自 javap 原文；已去掉 `public` 前缀与 `throws` 子句。

## 一、接口（4）

### `RegisterServiceSPI`（10 方法）

`com.seeyon.boot.starter.nacos.spi.RegisterServiceSPI`

```java
    void registerInstance();
    void registerInstance(com.seeyon.boot.starter.nacos.dto.AppInstanceDto);
    void deregisterInstance();
    void deregisterInstance(java.lang.String);
    default void deregisterInstance(java.lang.String, java.lang.String);
    java.util.List<com.seeyon.boot.starter.nacos.dto.AppInstanceDto> getInstances(java.lang.String);
    com.seeyon.boot.starter.nacos.dto.AppInstanceDto getOneHealthyInstance(java.lang.String);
    java.util.List<java.lang.String> selectAllServices();
    void subscribe(java.lang.String, com.seeyon.boot.starter.nacos.service.process.AppChangeProcess);
    java.lang.String getEngineName();
```

### `ConfigServiceSPI`（9 方法）

`com.seeyon.boot.starter.nacos.spi.ConfigServiceSPI`

```java
    java.lang.String getAppConfigStr();
    java.lang.String getGlobalConfigStr();
    java.lang.String getConfigStr(java.lang.String);
    default boolean publishConfig(java.lang.String, java.lang.String);
    default boolean publishAppConfig(java.lang.String);
    default void addAppConfigChangeListener(com.seeyon.boot.starter.nacos.service.process.ConfigChangeProcess);
    default void addGlobalConfigChangeListener(com.seeyon.boot.starter.nacos.service.process.ConfigChangeProcess);
    default void addConfigChangeListener(java.lang.String, com.seeyon.boot.starter.nacos.service.process.ConfigChangeProcess);
    java.lang.String getEngineName();
```

### `AppChangeProcess`（2 方法）

`com.seeyon.boot.starter.nacos.service.process.AppChangeProcess`

```java
    void process();
    default void process(com.seeyon.boot.starter.nacos.service.process.AppChangeEvent);
```

### `ConfigChangeProcess`（1 方法）

`com.seeyon.boot.starter.nacos.service.process.ConfigChangeProcess`

```java
    void process(java.lang.String);
```

## 二、关键类（10）

### `SeeyonClientWorker`（39 方法）

`com.alibaba.nacos.client.config.impl.SeeyonClientWorker`

```java
    void addListeners(java.lang.String, java.lang.String, java.util.List<? extends com.alibaba.nacos.api.config.listener.Listener>)
    void addTenantListeners(java.lang.String, java.lang.String, java.util.List<? extends com.alibaba.nacos.api.config.listener.Listener>)
    void addTenantListenersWithContent(java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.util.List<? extends com.alibaba.nacos.api.config.listener.Listener>)
    void removeListener(java.lang.String, java.lang.String, com.alibaba.nacos.api.config.listener.Listener);
    void removeTenantListener(java.lang.String, java.lang.String, com.alibaba.nacos.api.config.listener.Listener);
    void removeCache(java.lang.String, java.lang.String, java.lang.String);
    boolean removeConfig(java.lang.String, java.lang.String, java.lang.String, java.lang.String)
    boolean publishConfig(java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String)
    com.alibaba.nacos.client.config.impl.CacheData addCacheDataIfAbsent(java.lang.String, java.lang.String);
    com.alibaba.nacos.client.config.impl.CacheData addCacheDataIfAbsent(java.lang.String, java.lang.String, java.lang.String)
    private void putCache(java.lang.String, com.alibaba.nacos.client.config.impl.CacheData);
    private void increaseTaskIdCount(int);
    private void decreaseTaskIdCount(int);
    private int calculateTaskId();
    com.alibaba.nacos.client.config.impl.CacheData getCache(java.lang.String, java.lang.String);
    com.alibaba.nacos.client.config.impl.CacheData getCache(java.lang.String, java.lang.String, java.lang.String);
    com.alibaba.nacos.client.config.filter.impl.ConfigResponse getServerConfig(java.lang.String, java.lang.String, java.lang.String, long, boolean)
    private java.lang.String blank2defaultGroup(java.lang.String);
    void initAppLabels(java.util.Properties);
    private int initWorkerThreadCount(com.alibaba.nacos.client.env.NacosClientProperties);
    private void init(com.alibaba.nacos.client.env.NacosClientProperties);
    java.util.Map<java.lang.String, java.lang.Object> getMetrics(java.util.List<com.alibaba.nacos.api.config.remote.request.ClientConfigMetricRequest$MetricsKey>);
    private java.util.Map<com.alibaba.nacos.api.config.remote.request.ClientConfigMetricRequest$MetricsKey, java.lang.Object> getMetricsValue(java.util.List<com.alibaba.nacos.api.config.remote.request.ClientConfigMetricRequest$MetricsKey>);
    void shutdown()
    boolean isHealthServer();
    java.lang.String getAgentName();
    com.alibaba.nacos.client.config.impl.ConfigTransportClient getAgent();
```

### `ConfigCenterProperties`（24 方法）

`com.seeyon.boot.starter.nacos.ConfigCenterProperties`

```java
    java.lang.String getEngine();
    boolean isEnable();
    java.lang.String getServerAddr();
    java.lang.String getUsername();
    java.lang.String getPassword();
    java.lang.String getDubboNamespace();
    java.lang.String getConfigNamespace();
    boolean isAutoRefresh();
    java.lang.String getAccessKey();
    java.lang.String getSecretKey();
    void setEngine(java.lang.String);
    void setEnable(boolean);
    void setServerAddr(java.lang.String);
    void setUsername(java.lang.String);
    void setPassword(java.lang.String);
    void setDubboNamespace(java.lang.String);
    void setConfigNamespace(java.lang.String);
    void setAutoRefresh(boolean);
    void setAccessKey(java.lang.String);
    void setSecretKey(java.lang.String);
    boolean equals(java.lang.Object);
    protected boolean canEqual(java.lang.Object);
    int hashCode();
    java.lang.String toString();
```

### `ConfigLoader`（21 方法）

`com.seeyon.boot.starter.nacos.loader.ConfigLoader`

```java
    static com.seeyon.boot.starter.nacos.loader.ConfigLoader getInstance();
    private java.lang.String getPropertyName(java.lang.String);
    void refreshConfig(java.lang.String, java.lang.String);
    private java.util.Map<java.lang.String, com.seeyon.boot.starter.nacos.event.ChangeItem> buildChangeData(org.springframework.core.env.PropertySource<?>, org.springframework.core.env.PropertySource<?>);
    private org.springframework.core.env.PropertySource buildProperty(java.lang.String, java.lang.String, java.lang.String);
    private void setConfig2Environment(java.lang.String, java.lang.String)
    private java.lang.String decrypt(java.lang.String, java.lang.String);
    private java.io.File getApplicationYamlFile();
    private void loadSingleConfig();
    private void startApplicationYamlFileListener(long);
    private void loadConfig();
    private java.lang.String publishUdcAppConfig(java.lang.String, java.lang.String);
    void loadConfig(org.springframework.core.env.ConfigurableEnvironment);
    private void setLocalDefaultConfig();
```

### `SeeyonNacosConfigService`（17 方法）

`com.alibaba.nacos.client.config.SeeyonNacosConfigService`

```java
    private void initNamespace(com.alibaba.nacos.client.env.NacosClientProperties);
    java.lang.String getConfig(java.lang.String, java.lang.String, long)
    java.lang.String getConfigAndSignListener(java.lang.String, java.lang.String, long, com.alibaba.nacos.api.config.listener.Listener)
    void addListener(java.lang.String, java.lang.String, com.alibaba.nacos.api.config.listener.Listener)
    boolean publishConfig(java.lang.String, java.lang.String, java.lang.String)
    boolean publishConfig(java.lang.String, java.lang.String, java.lang.String, java.lang.String)
    boolean publishConfigCas(java.lang.String, java.lang.String, java.lang.String, java.lang.String)
    boolean publishConfigCas(java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String)
    boolean removeConfig(java.lang.String, java.lang.String)
    void removeListener(java.lang.String, java.lang.String, com.alibaba.nacos.api.config.listener.Listener);
    private java.lang.String getConfigInner(java.lang.String, java.lang.String, java.lang.String, long)
    private java.lang.String blank2defaultGroup(java.lang.String);
    private boolean removeConfigInner(java.lang.String, java.lang.String, java.lang.String, java.lang.String)
    private boolean publishConfigInner(java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String)
    java.lang.String getServerStatus();
    void addConfigFilter(com.alibaba.nacos.api.config.filter.IConfigFilter);
    void shutDown()
```

### `ConfigCenterService`（12 方法）

`com.seeyon.boot.starter.nacos.service.ConfigCenterService`

```java
    static com.seeyon.boot.starter.nacos.service.ConfigCenterService getInstance();
    java.lang.String getConfigStr(java.lang.String, java.lang.String);
    java.lang.String getConfigStr(java.lang.String);
    java.lang.String getAppConfigStr();
    java.lang.String getGlobalConfigStr();
    boolean publishAppConfig(java.lang.String);
    boolean publishConfig(java.lang.String, java.lang.String);
    void addAppConfigChangeListener(com.seeyon.boot.starter.nacos.service.process.ConfigChangeProcess);
    void addGlobalConfigChangeListener(com.seeyon.boot.starter.nacos.service.process.ConfigChangeProcess);
    void addConfigChangeListener(java.lang.String, com.seeyon.boot.starter.nacos.service.process.ConfigChangeProcess);
    java.lang.String getEngineName();
    java.lang.String enforceUseDataId();
```

### `NacosConfigImpl`（10 方法）

`com.seeyon.boot.starter.nacos.spi.nacos.NacosConfigImpl`

```java
    java.lang.String getAppConfigStr();
    java.lang.String getGlobalConfigStr();
    boolean publishAppConfig(java.lang.String);
    boolean publishConfig(java.lang.String, java.lang.String);
    void addAppConfigChangeListener(com.seeyon.boot.starter.nacos.service.process.ConfigChangeProcess);
    void addGlobalConfigChangeListener(com.seeyon.boot.starter.nacos.service.process.ConfigChangeProcess);
    void addConfigChangeListener(java.lang.String, com.seeyon.boot.starter.nacos.service.process.ConfigChangeProcess);
    java.lang.String getEngineName();
    java.lang.String getConfigStr(java.lang.String);
```

### `RegisterCenterService`（9 方法）

`com.seeyon.boot.starter.nacos.service.RegisterCenterService`

```java
    static com.seeyon.boot.starter.nacos.service.RegisterCenterService getInstance();
    java.util.List<com.seeyon.boot.starter.nacos.dto.AppInstanceDto> getInstances(java.lang.String);
    com.seeyon.boot.starter.nacos.dto.AppInstanceDto getOneHealthyInstance(java.lang.String);
    void registerInstance();
    void registerInstance(com.seeyon.boot.starter.nacos.dto.AppInstanceDto);
    void deregisterInstance();
    void deregisterInstance(java.lang.String);
    java.util.List<java.lang.String> selectAllServices();
    void subscribe(java.lang.String, com.seeyon.boot.starter.nacos.service.process.AppChangeProcess);
```

### `NacosService`（7 方法）

`com.seeyon.boot.starter.nacos.spi.nacos.NacosService`

```java
    static synchronized com.alibaba.nacos.api.config.ConfigService getNacosConfigService();
    static synchronized com.alibaba.nacos.api.naming.NamingService getConfigNamingService();
    static synchronized com.alibaba.nacos.api.naming.NamingService getDubboNamingService();
    static private static java.util.Properties getConfigProperties(boolean);
```

### `ConfigCenterApplicationRunListener`（4 方法）

`com.seeyon.boot.starter.nacos.ConfigCenterApplicationRunListener`

```java
    int getOrder();
    void environmentPrepared(org.springframework.boot.ConfigurableBootstrapContext, org.springframework.core.env.ConfigurableEnvironment);
    private void initNacosConfig();
    private void dealSpecialContainerConfig(org.springframework.core.env.ConfigurableEnvironment);
```

### `SingleConfigImpl`（4 方法）

`com.seeyon.boot.starter.nacos.spi.single.SingleConfigImpl`

```java
    java.lang.String getAppConfigStr();
    java.lang.String getGlobalConfigStr();
    java.lang.String getEngineName();
    java.lang.String getConfigStr(java.lang.String);
```

## 四、枚举（1）

- `ChangeTypeEnum`（3 常量）：ADDED, MODIFIED, DELETED
