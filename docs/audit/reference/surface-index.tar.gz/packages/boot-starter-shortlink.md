# boot-starter-shortlink：接口与方法签名

> 自动生成，勿手改。`tools/core/platform/emit_package_surfaces.py` 重跑即可。
> 构件 `com.seeyon:boot-starter-shortlink`（jar `boot-starter-shortlink-5.3.600.jar`）
> 规模：5 类 / 2 接口 / 0 注解 / 0 枚举 / 1 个关键类 / 15 方法。
> 签名逐字来自 javap 原文；已去掉 `public` 前缀与 `throws` 子句。

## 一、接口（2）

### `ShortLinkConstant`（0 方法）

`com.seeyon.boot.starter.shortlink.common.ShortLinkConstant`

```java
```

### `CtpShortLinkDao`（0 方法） extends CtpShortLink>

`com.seeyon.boot.starter.shortlink.domain.dao.CtpShortLinkDao`

```java
```

## 二、关键类（1）

### `CtpShortLinkService`（7 方法）

`com.seeyon.boot.starter.shortlink.domain.service.CtpShortLinkService`

```java
    java.lang.String getShortLink(java.lang.String, java.lang.String);
    java.lang.String getShortLink(java.lang.String);
    java.lang.String createShortLink(java.lang.String);
    java.lang.String createShortLink(java.lang.String, java.lang.String);
    static private static java.lang.String shortUrl(java.lang.String);
```
