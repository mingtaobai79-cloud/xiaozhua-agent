# boot-starter-attachment：接口与方法签名

> 自动生成，勿手改。`tools/core/platform/emit_package_surfaces.py` 重跑即可。
> 构件 `com.seeyon:boot-starter-attachment`（jar `boot-starter-attachment-5.3.290.jar`）
> 规模：15 类 / 1 接口 / 0 注解 / 2 枚举 / 2 个关键类 / 151 方法。
> 签名逐字来自 javap 原文；已去掉 `public` 前缀与 `throws` 子句。

## 一、接口（1）

### `AttachmentExtendApi`（2 方法）

`com.seeyon.boot.starter.attachment.api.AttachmentExtendApi`

```java
    default java.util.List<com.seeyon.boot.starter.attachment.dto.AttachmentDto> getAttachmentList(com.seeyon.boot.starter.attachment.dto.AttachmentQueryDto);
    default com.seeyon.boot.transport.ListResponse<com.seeyon.boot.starter.attachment.dto.AttachmentDto> getAttachmentList(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.attachment.dto.AttachmentQueryDto>);
```

## 二、关键类（2）

### `AttachmentService`（29 方法）

`com.seeyon.boot.starter.attachment.domain.service.AttachmentService`

```java
    java.util.List<com.seeyon.boot.starter.attachment.dto.AttachmentDto> selectListByConditions(com.seeyon.boot.starter.attachment.dto.AttachmentQueryDto);
    boolean fileDisableDownloadClients(java.lang.String);
    java.util.List<com.seeyon.boot.starter.attachment.dto.AttachmentDto> obtainStorageKeyEntity(com.seeyon.boot.starter.attachment.dto.AttachmentQueryDto);
    java.util.List<java.lang.String> obtainStorageKeyOpinion(com.seeyon.boot.starter.attachment.dto.AttachmentQueryDto, boolean);
    void obtainOpinionStorageList(java.lang.String, java.lang.Long, java.util.List<java.lang.String>, java.util.List<java.lang.String>);
    java.lang.Object invokeResult(java.lang.Object, java.lang.String, java.lang.String, java.lang.String, boolean);
    private com.seeyon.boot.transport.ListResponse<java.lang.Object> invokeForList(java.lang.String, java.lang.String, java.lang.String, java.lang.Object, java.lang.String);
    java.util.Map<java.lang.String, com.seeyon.boot.starter.attachment.dto.AttachmentDto> getAttachmentHanleMap(com.seeyon.boot.starter.attachment.dto.AttachmentQueryDto);
    com.seeyon.boot.starter.attachment.enums.AttachmentHandleType dealwithDownloadOrPreviewStatus(java.lang.String, com.seeyon.boot.starter.attachment.dto.AttachmentDto);
    static void dealwithSelectCascadeByIdAttachment(java.lang.Object, java.util.Map<java.lang.String, java.util.List<java.lang.Object>>);
    static java.util.Set<java.lang.String> getAllSubEntity(com.seeyon.ctp.metadata.dto.AggMetadataDto, java.util.Set<java.lang.String>);
    java.util.List<com.seeyon.boot.starter.attachment.dto.AttachmentFileDto> fileAppServiceInfo(java.util.List<java.lang.String>, java.lang.String);
    com.seeyon.boot.starter.attachment.enums.AttachmentHandleType dealwithStatus(java.lang.String);
    void bulidTextAreaAttachmentDtos(java.util.List<com.seeyon.boot.starter.attachment.dto.AttachmentDto>, java.util.List<com.seeyon.boot.starter.attachment.dto.AttachmentFileDto>, java.util.List<com.seeyon.boot.starter.attachment.dto.AttachmentDto>);
    void bulidAttachmentDtos(java.util.List<com.seeyon.boot.starter.attachment.dto.AttachmentDto>, java.util.List<com.seeyon.boot.starter.attachment.dto.AttachmentFileDto>, com.seeyon.boot.starter.attachment.enums.AttachmentSourceType, com.seeyon.boot.starter.attachment.enums.AttachmentHandleType);
    java.lang.String getRealAppName(com.seeyon.boot.starter.attachment.dto.AttachmentQueryDto);
    java.lang.String uploadZipFile(com.seeyon.boot.starter.attachment.dto.DownLoadZipDto);
    java.lang.String copyFile(java.lang.String);
    void singleDownload(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse);
```

### `AttachmentAppService`（3 方法）

`com.seeyon.boot.starter.attachment.appservice.AttachmentAppService`

```java
    com.seeyon.boot.transport.ListResponse<com.seeyon.boot.starter.attachment.dto.AttachmentDto> selectListByConditions(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.attachment.dto.AttachmentQueryDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.String> uploadZipFile(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.attachment.dto.DownLoadZipDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.String> copyFile(com.seeyon.boot.transport.SingleRequest<java.lang.String>);
```

## 四、枚举（2）

- `AttachmentHandleType`（3 常量）：NORMAL, READ_ONLY, HIDE
- `AttachmentSourceType`（4 常量）：TEXT_AREA, OPINION_AREA, POSTSCRIPT_AREA, OTHER
