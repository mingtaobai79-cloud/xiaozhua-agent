# boot-starter-dubbo：接口与方法签名

> 自动生成，勿手改。`tools/core/platform/emit_package_surfaces.py` 重跑即可。
> 构件 `com.seeyon:boot-starter-dubbo`（jar `boot-starter-dubbo-5.3.600.jar`）
> 规模：55 类 / 3 接口 / 1 注解 / 0 枚举 / 13 个关键类 / 395 方法。
> 签名逐字来自 javap 原文；已去掉 `public` 前缀与 `throws` 子句。

## 一、接口（3）

### `DubboFactory`（5 方法）

`com.seeyon.boot.starter.dubbo.DubboFactory`

```java
    <T> T getProxy(java.lang.Class<T>, java.lang.String, java.lang.String, int);
    <T> T getProxy(java.lang.Class<T>, java.lang.String, java.lang.String);
    <T> T getProxy(java.lang.Class<T>, java.lang.String, int);
    <T> T getProxy(java.lang.Class<T>, java.lang.String);
    <T> T getProxy(java.lang.Class<T>);
```

### `AppServiceProxy`（4 方法）

`com.seeyon.boot.starter.dubbo.api.AppServiceProxy`

```java
    com.seeyon.boot.transport.SingleResponse<java.lang.Object> invokeAppService(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.dubbo.dto.AppServiceInvokeDto>);
    default com.seeyon.boot.transport.ListResponse<java.lang.Object> invokeAppServiceForList(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.dubbo.dto.AppServiceInvokeDto>);
    default com.seeyon.boot.transport.PageResponse<java.lang.Object> invokeAppServiceForPage(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.dubbo.dto.AppServiceInvokeDto>);
    <T> com.seeyon.boot.transport.SingleResponse reliableInvokeAppService(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.dubbo.dto.AppServiceReliableInvokeDto<T>>);
```

### `AppServiceProxyCallback`（1 方法）

`com.seeyon.boot.starter.dubbo.api.AppServiceProxyCallback`

```java
    com.seeyon.boot.transport.SingleResponse<java.lang.String> callback(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.dubbo.dto.CommandCallbackDto>);
```

## 二、关键类（13）

### `ServiceConfig`（56 方法）

`org.apache.dubbo.config.ServiceConfig`

```java
    protected void postProcessAfterScopeModelChanged(org.apache.dubbo.rpc.model.ScopeModel, org.apache.dubbo.rpc.model.ScopeModel);
    boolean isExported();
    boolean isUnexported();
    synchronized void unexport();
    private void waitForIdle();
    void init();
    void export(org.apache.dubbo.common.constants.RegisterTypeEnum);
    void register(boolean);
    protected void doDelayExport();
    protected void exported();
    protected void mapServiceName(org.apache.dubbo.common.URL, org.apache.dubbo.metadata.ServiceNameMapping, java.util.concurrent.ScheduledExecutorService);
    private void scheduleToMapping(java.util.concurrent.ScheduledExecutorService, org.apache.dubbo.metadata.ServiceNameMapping, org.apache.dubbo.common.URL);
    private void checkAndUpdateSubConfigs();
    protected void postProcessRefresh();
    protected synchronized void doExport(org.apache.dubbo.common.constants.RegisterTypeEnum);
    private void doExportUrls(org.apache.dubbo.common.constants.RegisterTypeEnum);
    private void doExportUrlsFor1Protocol(org.apache.dubbo.config.ProtocolConfig, java.util.List<org.apache.dubbo.common.URL>, org.apache.dubbo.common.constants.RegisterTypeEnum);
    private void initServiceMethodMetrics(org.apache.dubbo.common.URL);
    private void processServiceExecutor(org.apache.dubbo.common.URL);
    private java.util.Map<java.lang.String, java.lang.String> buildAttributes(org.apache.dubbo.config.ProtocolConfig);
    private void appendParametersWithMethod(org.apache.dubbo.config.MethodConfig, java.util.Map<java.lang.String, java.lang.String>);
    private java.lang.reflect.Method findMatchedMethod(org.apache.dubbo.config.MethodConfig);
    private void appendArgumentConfig(org.apache.dubbo.config.ArgumentConfig, java.lang.reflect.Method, java.util.Map<java.lang.String, java.lang.String>);
    private boolean hasIndex(org.apache.dubbo.config.ArgumentConfig);
    private boolean isTypeMatched(java.lang.String, java.lang.Integer, java.lang.Class<?>[]);
    private java.lang.Integer findArgumentIndexIndexWithGivenType(org.apache.dubbo.config.ArgumentConfig, java.lang.reflect.Method);
    private org.apache.dubbo.common.URL buildUrl(org.apache.dubbo.config.ProtocolConfig, java.util.Map<java.lang.String, java.lang.String>);
    private void exportUrl(org.apache.dubbo.common.URL, java.util.List<org.apache.dubbo.common.URL>, org.apache.dubbo.common.constants.RegisterTypeEnum);
    private org.apache.dubbo.common.URL exportRemote(org.apache.dubbo.common.URL, java.util.List<org.apache.dubbo.common.URL>, org.apache.dubbo.common.constants.RegisterTypeEnum);
    private void doExportUrl(org.apache.dubbo.common.URL, boolean, org.apache.dubbo.common.constants.RegisterTypeEnum);
    private void exportLocal(org.apache.dubbo.common.URL);
    private boolean isOnlyInJvm();
    private void postProcessConfig();
    void addServiceListener(org.apache.dubbo.config.ServiceListener);
    protected void onExported();
    protected void onUnexpoted();
    static private static java.lang.String findConfiguredHosts(org.apache.dubbo.config.ProtocolConfig, org.apache.dubbo.config.ProviderConfig, java.util.Map<java.lang.String, java.lang.String>);
    static private static synchronized java.lang.Integer findConfiguredPort(org.apache.dubbo.config.ProtocolConfig, org.apache.dubbo.config.ProviderConfig, org.apache.dubbo.common.extension.ExtensionLoader<org.apache.dubbo.rpc.Protocol>, java.lang.String, java.util.Map<java.lang.String, java.lang.String>);
    static private static java.lang.Integer parsePort(java.lang.String);
    static private static java.lang.String getValueFromConfig(org.apache.dubbo.config.ProtocolConfig, java.lang.String);
    static private static java.lang.Integer getRandomPort(java.lang.String);
    static private static void putRandomPort(java.lang.String, java.lang.Integer);
    java.lang.Runnable getDestroyRunner();
```

### `HeaderExchangeClient`（33 方法）

`org.apache.dubbo.remoting.exchange.support.header.HeaderExchangeClient`

```java
    java.util.concurrent.CompletableFuture<java.lang.Object> request(java.lang.Object)
    org.apache.dubbo.common.URL getUrl();
    java.net.InetSocketAddress getRemoteAddress();
    java.util.concurrent.CompletableFuture<java.lang.Object> request(java.lang.Object, int)
    java.util.concurrent.CompletableFuture<java.lang.Object> request(java.lang.Object, java.util.concurrent.ExecutorService)
    java.util.concurrent.CompletableFuture<java.lang.Object> request(java.lang.Object, int, java.util.concurrent.ExecutorService)
    org.apache.dubbo.remoting.ChannelHandler getChannelHandler();
    boolean isConnected();
    java.net.InetSocketAddress getLocalAddress();
    org.apache.dubbo.remoting.exchange.ExchangeHandler getExchangeHandler();
    void send(java.lang.Object)
    void send(java.lang.Object, boolean)
    boolean isClosed();
    synchronized void close();
    void close(int);
    void startClose();
    void reset(org.apache.dubbo.common.URL);
    void reset(org.apache.dubbo.common.Parameters);
    void reconnect()
    java.lang.Object getAttribute(java.lang.String);
    void setAttribute(java.lang.String, java.lang.Object);
    void removeAttribute(java.lang.String);
    boolean hasAttribute(java.lang.String);
    private void startHeartBeatTask(org.apache.dubbo.common.URL);
    private void startReconnectTask(org.apache.dubbo.common.URL);
    private void doClose();
    private long calculateLeastDuration(int);
    private long calculateReconnectDuration(org.apache.dubbo.common.URL, long);
    protected boolean shouldReconnect(org.apache.dubbo.common.URL);
    java.lang.String toString();
```

### `SerializerFactory`（24 方法）

`com.alibaba.com.caucho.hessian.io.SerializerFactory`

```java
    java.lang.Class<?> loadSerializedClass(java.lang.String)
    com.alibaba.com.caucho.hessian.io.ClassFactory getClassFactory();
    static private static void addBasic(java.lang.Class, java.lang.String, int);
    java.lang.ClassLoader getClassLoader();
    void setSendCollectionType(boolean);
    void addFactory(com.alibaba.com.caucho.hessian.io.AbstractSerializerFactory);
    boolean isAllowNonSerializable();
    void setAllowNonSerializable(boolean);
    com.alibaba.com.caucho.hessian.io.Serializer getSerializer(java.lang.Class)
    protected com.alibaba.com.caucho.hessian.io.Serializer getDefaultSerializer(java.lang.Class);
    com.alibaba.com.caucho.hessian.io.Deserializer getDeserializer(java.lang.Class)
    protected com.alibaba.com.caucho.hessian.io.Deserializer getDefaultDeserializer(java.lang.Class);
    java.lang.Object readList(com.alibaba.com.caucho.hessian.io.AbstractHessianInput, int, java.lang.String)
    java.lang.Object readMap(com.alibaba.com.caucho.hessian.io.AbstractHessianInput, java.lang.String)
    java.lang.Object readMap(com.alibaba.com.caucho.hessian.io.AbstractHessianInput, java.lang.String, java.lang.Class<?>, java.lang.Class<?>)
    java.lang.Object readObject(com.alibaba.com.caucho.hessian.io.AbstractHessianInput, java.lang.String, java.lang.String[])
    com.alibaba.com.caucho.hessian.io.Deserializer getObjectDeserializer(java.lang.String, java.lang.Class)
    com.alibaba.com.caucho.hessian.io.Deserializer getObjectDeserializer(java.lang.String)
    com.alibaba.com.caucho.hessian.io.Deserializer getListDeserializer(java.lang.String, java.lang.Class)
    com.alibaba.com.caucho.hessian.io.Deserializer getListDeserializer(java.lang.String)
    com.alibaba.com.caucho.hessian.io.Deserializer getDeserializer(java.lang.String)
    static private static boolean isZoneId(java.lang.Class);
    static private static boolean isEnumSet(java.lang.Class);
    static private static boolean isJava8();
```

### `AppServiceInvokeDto`（18 方法）

`com.seeyon.boot.starter.dubbo.dto.AppServiceInvokeDto`

```java
    java.lang.String getInterfaceName();
    java.lang.String getMethodName();
    java.lang.String getParamType();
    java.lang.String getGenericType();
    java.lang.String getSubGenericType();
    java.lang.String getParamJson();
    java.lang.String getBeanName();
    java.lang.Boolean getReturnJson();
    java.lang.Boolean getBodyZip();
    void setInterfaceName(java.lang.String);
    void setMethodName(java.lang.String);
    void setParamType(java.lang.String);
    void setGenericType(java.lang.String);
    void setSubGenericType(java.lang.String);
    void setParamJson(java.lang.String);
    void setBeanName(java.lang.String);
    void setReturnJson(java.lang.Boolean);
    void setBodyZip(java.lang.Boolean);
```

### `AppServiceAsyncInvokeDto`（10 方法）

`com.seeyon.boot.starter.dubbo.dto.AppServiceAsyncInvokeDto`

```java
    java.lang.String getNotifyDubboGroup();
    java.lang.String getNotifyDubboVersion();
    java.lang.Long getParamConvertId();
    java.lang.String getCallBackUrl();
    java.util.Map<java.lang.String, java.lang.Object> getExtendParams();
    void setNotifyDubboGroup(java.lang.String);
    void setNotifyDubboVersion(java.lang.String);
    void setParamConvertId(java.lang.Long);
    void setCallBackUrl(java.lang.String);
    void setExtendParams(java.util.Map<java.lang.String, java.lang.Object>);
```

### `SeeyonEagerThreadPoolExecutor`（9 方法）

`com.seeyon.boot.starter.dubbo.threadpool.SeeyonEagerThreadPoolExecutor`

```java
    java.util.TreeSet<com.seeyon.boot.starter.dubbo.threadpool.SeeyonEagerThreadPoolExecutor$TaskPrint> getRunningTasks();
    protected void beforeExecute(java.lang.Thread, java.lang.Runnable);
    protected void afterExecute(java.lang.Runnable, java.lang.Throwable);
    void execute(java.lang.Runnable);
    private java.util.TreeSet<com.seeyon.boot.starter.dubbo.threadpool.SeeyonEagerThreadPoolExecutor$TaskPrint> getRunningTasks(java.util.List<java.lang.Object>);
    private void printQueue(java.lang.String, java.util.List<java.lang.Object>);
    private java.lang.String runnableToString(java.lang.Object);
```

### `ClassFactory`（8 方法）

`com.alibaba.com.caucho.hessian.io.ClassFactory`

```java
    java.lang.Class<?> load(java.lang.String)
    private boolean isAllow(java.lang.String);
    void setWhitelist(boolean);
    void allow(java.lang.String);
    void deny(java.lang.String);
    static private static java.lang.String toPattern(java.lang.String);
    private void initAllow();
    static java.lang.String[] readLines(java.io.InputStream)
```

### `AppServiceReliableInvokeDto`（8 方法）

`com.seeyon.boot.starter.dubbo.dto.AppServiceReliableInvokeDto`

```java
    java.lang.String getInterfaceName();
    java.lang.String getMethodName();
    java.lang.String getParamType();
    T getParam();
    void setInterfaceName(java.lang.String);
    void setMethodName(java.lang.String);
    void setParamType(java.lang.String);
    void setParam(T);
```

### `DubboAutoConfiguration`（7 方法）

`com.seeyon.boot.starter.dubbo.DubboAutoConfiguration`

```java
    com.seeyon.boot.starter.dubbo.ProxyServiceBeanPostProcessor openServiceBeanPostProcessor();
    org.apache.dubbo.config.ApplicationConfig applicationConfig();
    org.apache.dubbo.config.RegistryConfig registryConfig();
    org.apache.dubbo.config.ConsumerConfig consumerConfig();
    com.seeyon.boot.starter.dubbo.mock.DubboMockBeanPostProcessor dubboMockBeanPostProcessor();
    void afterPropertiesSet()
    com.seeyon.boot.starter.dubbo.DubboFactory dubboFactory(org.apache.dubbo.config.ConsumerConfig, org.apache.dubbo.config.ProviderConfig);
```

### `DubboFactoryImpl`（7 方法）

`com.seeyon.boot.starter.dubbo.DubboFactoryImpl`

```java
    void setApplicationContext(org.springframework.context.ApplicationContext)
    <T> T getProxy(java.lang.Class<T>, java.lang.String, java.lang.String, int);
    <T> T getProxy(java.lang.Class<T>, java.lang.String, int);
    <T> T getProxy(java.lang.Class<T>, java.lang.String, java.lang.String);
    <T> T getProxy(java.lang.Class<T>, java.lang.String);
    <T> T getProxy(java.lang.Class<T>);
    void destroy();
```

### `ProxyServiceBeanPostProcessor`（6 方法）

`com.seeyon.boot.starter.dubbo.ProxyServiceBeanPostProcessor`

```java
    java.lang.Object postProcessAfterInitialization(java.lang.Object, java.lang.String)
    void afterPropertiesSet()
    com.seeyon.boot.starter.dubbo.api.AppServiceProxy getAppServiceProxy();
    java.util.Set<java.lang.Class<?>> getClassesDubboComponent();
    void setAppServiceProxy(com.seeyon.boot.starter.dubbo.api.AppServiceProxy);
    void setClassesDubboComponent(java.util.Set<java.lang.Class<?>>);
```

### `ProviderLogFilter`（3 方法）

`com.seeyon.boot.starter.dubbo.ProviderLogFilter`

```java
    org.apache.dubbo.rpc.Result invoke(org.apache.dubbo.rpc.Invoker<?>, org.apache.dubbo.rpc.Invocation)
    static java.lang.String formatMethodGroup(org.apache.dubbo.rpc.Invoker<?>, org.apache.dubbo.rpc.Invocation);
    static java.lang.String formatMethodGroup(java.lang.String, java.lang.String, java.lang.String);
```

### `ServiceBeanPostProcessor`（3 方法）

`com.seeyon.boot.starter.dubbo.ServiceBeanPostProcessor`

```java
    java.lang.Object postProcessBeforeInitialization(java.lang.Object, java.lang.String)
    java.lang.Object postProcessAfterInitialization(java.lang.Object, java.lang.String)
    protected void processGrayTag(org.apache.dubbo.config.ServiceConfig);
```

## 三、注解（1）

| 注解 | 元素 |
|---|---|
| `DubboComponent` |  |
