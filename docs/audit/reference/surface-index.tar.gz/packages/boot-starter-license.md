# boot-starter-license：接口与方法签名

> 自动生成，勿手改。`tools/core/platform/emit_package_surfaces.py` 重跑即可。
> 构件 `com.seeyon:boot-starter-license`（jar `boot-starter-license-5.3.600.jar`）
> 规模：17 类 / 2 接口 / 0 注解 / 0 枚举 / 3 个关键类 / 168 方法。
> 签名逐字来自 javap 原文；已去掉 `public` 前缀与 `throws` 子句。

## 一、接口（2）

### `LicenseProcessor`（27 方法） extends LicensePlugin

`com.seeyon.boot.starter.license.LicenseProcessor`

```java
    boolean init();
    boolean isTenantMode();
    java.util.Set<java.lang.String> getPlugins();
    java.util.Map<java.lang.String, java.util.List> getAppPlugins();
    java.lang.String getProductInfo();
    boolean hasApp(java.lang.String);
    int getOrganNum();
    int getUserNum();
    int getIMNum();
    int getOnlineNum();
    java.lang.String getClientName();
    boolean isExpired();
    long getRemainDate();
    java.lang.String getExpirationDate();
    boolean isExpired(java.lang.String);
    long getRemainDate(java.lang.String);
    java.lang.String getExpirationDate(java.lang.String);
    int getLimit(java.lang.String);
    java.util.Map<java.lang.String, java.lang.String> getExpireDateMap(java.lang.String);
    int getTenantNum();
    void refreshTenantLicense(java.lang.Long, com.seeyon.boot.starter.license.LicenseDto);
    boolean isSupportNationalization();
    java.lang.String getProductNo();
    java.util.Map<java.lang.String, java.lang.String> getExtendedInfo(java.lang.String);
    default boolean hasAnyPlugin(java.util.Set<java.lang.String>);
    default boolean hasAllPlugin(java.util.Set<java.lang.String>);
    default boolean verifyPlugin(java.lang.String);
```

### `LicenseInfoDao`（0 方法） extends LicenseInfo>

`com.seeyon.boot.starter.license.domain.dao.LicenseInfoDao`

```java
```

## 二、关键类（3）

### `LicenseInfoService`（14 方法）

`com.seeyon.boot.starter.license.domain.service.LicenseInfoService`

```java
    java.lang.String createOrUpdate(com.seeyon.boot.starter.license.dto.LicenseInfoDto);
    private boolean isValidLicense(java.lang.String);
    java.lang.Long create(com.seeyon.boot.starter.license.dto.LicenseInfoDto);
    java.lang.Long update(com.seeyon.boot.starter.license.dto.LicenseInfoDto);
    com.seeyon.boot.starter.license.dto.LicenseInfoDto getLicenseInfo(java.lang.Long);
    com.seeyon.boot.starter.license.dto.LicenseInfoDto getLicenseInfoFromDB(java.lang.Long);
    java.util.List<com.seeyon.boot.starter.license.dto.LicenseInfoDto> getAllLicenseInfo();
    private void loadAllLicenseInfo();
    private void cacheLicenseInfo(com.seeyon.boot.starter.license.dto.LicenseInfoDto);
    private java.lang.String getLicenseCacheKey(java.lang.Long);
    void setLicenseProcessor(com.seeyon.boot.starter.license.LicenseProcessor);
    void updateAllTenantLicense();
    com.seeyon.boot.transport.SingleResponse<?> exec();
```

### `LicenseUtil`（9 方法）

`com.seeyon.boot.starter.license.LicenseUtil`

```java
    static private static void appPluginsToAllPlugins(java.lang.String);
    static boolean checkLicenseValid(java.lang.String, com.seeyon.boot.starter.license.LicenseDto);
    static com.seeyon.boot.starter.license.LicenseDto generateLicenseDto(java.lang.String);
    static com.seeyon.boot.starter.license.LicenseDto generateLicenseDto(java.lang.String, java.lang.String);
    static com.seeyon.boot.starter.license.LicenseDto analysisLicenseDto(com.seeyon.boot.starter.license.LicenseDto);
    static private static java.lang.String generateCheckSum(com.seeyon.boot.starter.license.LicenseDto);
    static boolean isIgnorePlugin(java.lang.String);
    static boolean isUdcAppPlugin(java.lang.String);
```

### `LicenseAutoConfiguration`（3 方法）

`com.seeyon.boot.starter.license.LicenseAutoConfiguration`

```java
    com.seeyon.boot.starter.license.LicenseProcessor licenseProcessor();
    com.seeyon.boot.starter.license.listener.LicenseChangeListener licenseChangeListener();
    void afterPropertiesSet();
```
