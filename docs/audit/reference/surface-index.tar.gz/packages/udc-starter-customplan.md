# udc-starter-customplan：接口与方法签名

> 自动生成，勿手改。`tools/core/platform/emit_package_surfaces.py` 重跑即可。
> 构件 `com.seeyon:udc-starter-customplan`（jar `udc-starter-customplan-5.3.605.jar`）
> 规模：78 类 / 12 接口 / 0 注解 / 9 枚举 / 20 个关键类 / 1001 方法。
> 签名逐字来自 javap 原文；已去掉 `public` 前缀与 `throws` 子句。

## 一、接口（12）

### `ScalabilityFieldAppService`（7 方法）

`com.seeyon.boot.starter.customplan.api.ScalabilityFieldAppService`

```java
    com.seeyon.boot.transport.ListResponse<com.seeyon.boot.starter.customplan.dto.EntityRuntimeTreeDto> selectMetadataExtEntityTree(com.seeyon.boot.transport.SingleRequest<java.lang.String>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.boot.starter.customplan.dto.ScalabilityFieldDto> listExtFileds(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.customplan.dto.ScalabilityFieldQueryDto>);
    com.seeyon.boot.transport.ListResponse<java.lang.String> selectAvailableDatatype(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.customplan.dto.ScalabilityFieldQueryDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.boot.starter.customplan.dto.ScalabilityFieldDto> selectAttribute(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.customplan.dto.ScalabilityFieldQueryDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> updateBatch(com.seeyon.boot.transport.SingleRequest<java.util.List<com.seeyon.boot.starter.customplan.dto.ScalabilityFieldDto>>);
    com.seeyon.boot.transport.SingleResponse<java.lang.String> compensateScalabilityFieldMetadata(com.seeyon.boot.transport.SingleRequest<java.lang.Void>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> transportIn(com.seeyon.boot.transport.SingleRequest<java.util.List<com.seeyon.boot.starter.customplan.dto.ScalabilityFieldDto>>);
```

### `PersonalPlanAppService`（5 方法）

`com.seeyon.boot.starter.customplan.api.PersonalPlanAppService`

```java
    com.seeyon.boot.transport.SingleResponse<com.seeyon.boot.starter.customplan.dto.PersonalPlanDto> selectByCondition(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.customplan.dto.PersonalQueryDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.boot.starter.customplan.dto.PersonalPlanDto> selectListByCondition(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.customplan.dto.PersonalQueryDto>);
    com.seeyon.boot.transport.SingleResponse<java.util.List<java.lang.Long>> createRedirectBatch(com.seeyon.boot.transport.SingleRequest<java.util.List<com.seeyon.boot.starter.customplan.dto.PersonalPlanDto>>);
    com.seeyon.boot.transport.PageResponse<com.seeyon.boot.starter.customplan.dto.PersonalPlanDto> selectPageByCondition(com.seeyon.boot.transport.PageRequest);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> deleteByIds(com.seeyon.boot.transport.SingleRequest<java.util.List<java.lang.Long>>);
```

### `UdcPageProcessEventService`（3 方法）

`com.seeyon.boot.starter.customplan.api.UdcPageProcessEventService`

```java
    com.seeyon.boot.transport.ListResponse<com.seeyon.udc.dto.page.PageProcessEventDto> selectProcessEventListByCondition(com.seeyon.boot.transport.SingleRequest<com.seeyon.udc.dto.page.PageProcessEventSearchDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.udc.dto.page.PageProcessEventDto> selectProcessEventList(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.customplan.dto.CBpmNodePermissionRequestDto>);
    void clearCacheByAppName(com.seeyon.boot.transport.SingleRequest<java.lang.String>);
```

### `CustomPlanAppService`（2 方法）

`com.seeyon.boot.starter.customplan.api.CustomPlanAppService`

```java
    com.seeyon.boot.transport.ListResponse<com.seeyon.boot.starter.customplan.dto.CustomPlanDto> selectBySourceIds(com.seeyon.boot.transport.SingleRequest<java.util.List<java.lang.String>>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.boot.starter.customplan.dto.CustomPlanDto> selectByComplexCondition(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.customplan.dto.CustomPlanSearchDto>);
```

### `CustomPlanContentDao`（0 方法） extends CustomPlanContent>

`com.seeyon.boot.starter.customplan.domain.dao.CustomPlanContentDao`

```java
```

### `CustomPlanDao`（0 方法） extends CustomPlan>

`com.seeyon.boot.starter.customplan.domain.dao.CustomPlanDao`

```java
```

### `FilterPlanDao`（0 方法） extends FilterPlan>

`com.seeyon.boot.starter.customplan.domain.dao.FilterPlanDao`

```java
```

### `FilterPlanFormalDao`（0 方法） extends FilterPlanFormal>

`com.seeyon.boot.starter.customplan.domain.dao.FilterPlanFormalDao`

```java
```

### `FilterPlanRtDao`（0 方法） extends FilterPlanRt>

`com.seeyon.boot.starter.customplan.domain.dao.FilterPlanRtDao`

```java
```

### `PersonalPlanDao`（0 方法） extends PersonalPlan>

`com.seeyon.boot.starter.customplan.domain.dao.PersonalPlanDao`

```java
```

### `ScalabilityFieldDao`（0 方法） extends ScalabilityField>

`com.seeyon.boot.starter.customplan.domain.dao.ScalabilityFieldDao`

```java
```

### `UdcRuntimeHistoryMetaDataDao`（0 方法） extends UdcHistoryMetaData>

`com.seeyon.boot.starter.customplan.domain.dao.UdcRuntimeHistoryMetaDataDao`

```java
```

## 二、关键类（20）

### `FormPermissionAuthService`（65 方法）

`com.seeyon.boot.starter.customplan.domain.service.FormPermissionAuthService`

```java
    <T extends com.seeyon.udc.common.dto.BaseEntityActionDto> java.util.Set<java.lang.String> readonlyValidate(com.seeyon.boot.starter.customplan.dto.BpmFromPermissionCheckDto<T>);
    <T extends com.seeyon.boot.transport.BaseDto> T buildInitialValue(com.seeyon.boot.starter.customplan.dto.BpmFromPermissionCheckDto<T>);
    <T extends com.seeyon.boot.transport.BaseDto> void buildInitialValue(T, java.util.Map<java.lang.String, com.seeyon.bpm.dto.BpmFormPermissionContentDto>, java.util.Map<java.lang.String, java.lang.Class<?>>, java.util.Map<java.lang.String, java.lang.Object>);
    static private static <T extends com.seeyon.boot.transport.BaseDto> java.util.function.Consumer<cn.hutool.core.lang.Pair<java.lang.String, cn.hutool.core.lang.Pair<com.seeyon.boot.enums.DataType, java.lang.Object>>> setPropertyConsumer(T);
    <T extends com.seeyon.udc.common.dto.BaseEntityActionDto> java.util.Set<java.lang.String> requiredValidate(com.seeyon.boot.starter.customplan.dto.BpmFromPermissionCheckDto<T>);
    private <T extends com.seeyon.boot.transport.BaseDto> java.util.Map<java.lang.String, com.seeyon.bpm.dto.BpmFormPermissionContentDto> getFromPermissionContent(com.seeyon.boot.starter.customplan.dto.BpmFromPermissionCheckDto<T>);
    private <T extends com.seeyon.udc.common.dto.BaseEntityActionDto> boolean checkValueIsEqual(T, T, java.lang.String);
    private <T extends com.seeyon.boot.transport.BaseDto> boolean equals(T, T, java.lang.String);
    private <T extends com.seeyon.udc.common.dto.BaseEntityActionDto> boolean checkValueIsNull(java.util.Map<java.lang.String, java.lang.Class<?>>, T, java.lang.String, java.lang.String)
    private java.lang.String lowerFirstFieldPath(java.lang.String);
    private boolean checkNoneNullValueIsNull(java.util.Map<java.lang.String, java.lang.Class<?>>, java.lang.String, java.lang.Object);
    private boolean checkNoneNullValueIsNull(com.seeyon.boot.annotation.EntityAttribute, java.lang.String, java.lang.String, java.lang.Object);
    private boolean checkNoneNullValueIsZero(com.seeyon.boot.annotation.EntityAttribute, java.lang.String, java.lang.String, java.lang.Object);
    private <T extends com.seeyon.boot.transport.BaseDto> java.util.Map<java.lang.String, java.lang.Object> getFormulaParams(com.seeyon.boot.starter.customplan.dto.BpmFromPermissionCheckDto<T>);
    private <T extends com.seeyon.boot.transport.BaseDto> java.lang.String getEntityFullName(T);
    private <T extends com.seeyon.boot.transport.BaseDto> java.util.function.Function<java.util.Map$Entry<java.lang.String, com.seeyon.bpm.dto.BpmFormPermissionContentDto>, cn.hutool.core.lang.Pair<com.seeyon.bpm.dto.BpmFormPermissionContentDto, java.lang.Boolean>> getProNameReadonlyPairFunction(T, java.util.Map<java.lang.String, java.lang.Object>);
    private java.lang.String parseConditionExpression(java.util.Map<java.lang.String, java.lang.Object>, cn.hutool.json.JSONArray);
    private <T extends com.seeyon.boot.transport.BaseDto> java.util.function.Function<java.util.Map$Entry<java.lang.String, com.seeyon.bpm.dto.BpmFormPermissionContentDto>, cn.hutool.core.lang.Pair<com.seeyon.bpm.dto.BpmFormPermissionContentDto, java.lang.Boolean>> getProNameRequiredPairFunction(T, java.util.Map<java.lang.String, java.lang.Object>);
    private <T extends com.seeyon.boot.transport.BaseDto> java.util.function.Function<java.util.Map$Entry<java.lang.String, com.seeyon.bpm.dto.BpmFormPermissionContentDto>, cn.hutool.core.lang.Pair<java.lang.String, cn.hutool.core.lang.Pair<com.seeyon.boot.enums.DataType, java.lang.Object>>> getProNameValuePairFunction(java.util.Map<java.lang.String, java.lang.Class<?>>, T, java.lang.String, java.util.Map<java.lang.String, java.lang.Object>);
    private <T extends com.seeyon.boot.transport.BaseDto> cn.hutool.core.lang.Pair<java.lang.String, cn.hutool.core.lang.Pair<com.seeyon.boot.enums.DataType, java.lang.Object>> getProNameValuePair(T, java.util.Map<java.lang.String, java.lang.Object>, com.seeyon.boot.enums.DataType, java.util.Map$Entry<java.lang.String, com.seeyon.bpm.dto.BpmFormPermissionContentDto>, java.lang.String);
    private <T extends com.seeyon.boot.transport.BaseDto> java.lang.reflect.Field getFieldByKey(T, java.lang.String);
    private boolean objectNonNull(cn.hutool.core.lang.Pair<java.lang.String, cn.hutool.core.lang.Pair<com.seeyon.boot.enums.DataType, java.lang.Object>>);
    <T> T getByPath(java.lang.String, java.lang.Object, java.lang.Class<T>);
```

### `FilterPlanService`（58 方法）

`com.seeyon.boot.starter.customplan.domain.service.FilterPlanService`

```java
    com.seeyon.boot.starter.customplan.dto.FilterPlanDto create(com.seeyon.boot.starter.customplan.dto.FilterPlanDto);
    com.seeyon.boot.starter.customplan.dto.FilterPlanDto createUpgrade(com.seeyon.boot.starter.customplan.dto.FilterPlanDto);
    com.seeyon.boot.starter.customplan.dto.FilterPlanDto createNew(com.seeyon.boot.starter.customplan.dto.FilterPlanDto);
    int createBatch(java.util.List<com.seeyon.boot.starter.customplan.dto.FilterPlanDto>);
    java.util.List<com.seeyon.boot.starter.customplan.dto.FilterPlanDto> saveOrUpdate4Page(java.util.List<com.seeyon.boot.starter.customplan.dto.FilterPlanDto>, java.lang.Long);
    void cleanEntities(java.lang.Long, java.util.List<java.lang.Long>);
    int deleteByIds(java.util.List<java.lang.Long>);
    int deleteById(java.lang.Long);
    int deleteByGuid(java.lang.Long);
    int deleteByGuids(java.util.List<java.lang.Long>);
    int deleteBySourceId(java.lang.String);
    int deleteBySourcedIds(java.util.List<java.lang.String>);
    int deleteByPageIdAndSourcedIds(java.lang.Long, java.util.List<java.lang.String>);
    int deleteByPageId(java.lang.Long);
    int deleteByPageIds(java.util.List<java.lang.Long>);
    int deleteByAppId(java.lang.Long);
    int deleteByAppIds(java.util.List<java.lang.Long>);
    int update(com.seeyon.boot.starter.customplan.dto.FilterPlanDto);
    int updateBatch(java.util.List<com.seeyon.boot.starter.customplan.dto.FilterPlanDto>);
    private void checkContent(com.seeyon.boot.starter.customplan.dto.FilterPlanDto);
    private java.util.List<com.seeyon.boot.starter.customplan.domain.entity.FilterPlan> checkAndGetFilterPlans(java.util.List<com.seeyon.boot.starter.customplan.dto.FilterPlanDto>);
    com.seeyon.boot.starter.customplan.dto.FilterPlanDto selectById(java.lang.Long);
    com.seeyon.boot.starter.customplan.dto.FilterPlanDto selectByGuid(java.lang.Long);
    java.util.List<com.seeyon.boot.starter.customplan.dto.FilterPlanDto> selectByGuids(java.util.List<java.lang.Long>);
    java.util.List<com.seeyon.boot.starter.customplan.dto.FilterPlanDto> selectDefaultPlansByPageIds(java.util.List<java.lang.Long>);
    java.util.List<com.seeyon.boot.starter.customplan.dto.FilterPlanDto> selectByCombination(com.seeyon.boot.starter.customplan.dto.FilterPlanCombinationSelectDto);
    java.util.List<com.seeyon.boot.starter.customplan.dto.FilterPlanDto> selectBySourceId(java.lang.String, long);
    java.util.List<com.seeyon.boot.starter.customplan.dto.FilterPlanDto> selectBySourceIds(java.util.List<java.lang.String>, long);
    java.util.List<com.seeyon.boot.starter.customplan.dto.FilterPlanDto> selectByPageIds(java.util.List<java.lang.Long>);
    java.util.List<com.seeyon.boot.starter.customplan.dto.FilterPlanDto> selectByAppId(java.lang.Long);
    java.util.Map<java.lang.String, java.lang.Object> getDynamicSelectSetting(com.seeyon.boot.starter.customplan.dto.FilterPlanDto, com.seeyon.boot.starter.condition.dto.dynamicsearch.DynamicSearchParamDto);
    com.seeyon.boot.starter.customplan.dto.FilterPlanDto selectDefaultPlanBySourceId(java.lang.String);
    java.util.List<com.seeyon.boot.starter.customplan.dto.FilterPlanDto> selectByPageInfo(com.seeyon.boot.transport.PageInfo);
    private com.seeyon.boot.starter.dynamicsql.dto.DynamicConditionDto getDynamicCondition(java.util.Map<java.lang.String, java.lang.Object>, java.util.Map<java.lang.String, java.util.List<java.util.Map<java.lang.String, java.lang.Object>>>);
    private com.seeyon.boot.transport.Sort getSortFromFilterPlan(java.util.Map<java.lang.String, java.lang.Object>, java.lang.String);
    private com.seeyon.boot.transport.Sort getSortFromFrontend(java.util.List<java.util.Map<java.lang.String, java.lang.Object>>);
    void buildSearchParam(com.seeyon.boot.starter.dynamicsql.dto.DynamicConditionDto, com.seeyon.boot.starter.condition.dto.dynamicsearch.DynamicSearchParamDto);
    void revertFilterPlan(java.lang.Long, java.util.List<com.seeyon.boot.starter.customplan.dto.FilterPlanDto>, java.util.List<com.seeyon.boot.starter.customplan.dto.FilterPlanDto>);
    com.seeyon.boot.starter.customplan.dto.FilterPlanDto getCache(java.lang.Long);
    void setCache(com.seeyon.boot.starter.customplan.dto.FilterPlanDto);
    void evictCache(java.lang.Long);
    private void checkSupportMethod();
    private void checkSupportOperate(java.util.List<com.seeyon.boot.starter.customplan.domain.entity.FilterPlan>);
    java.util.List<com.seeyon.boot.starter.customplan.dto.FilterPlanDto> selectListByCondition(java.util.Map<java.lang.String, java.lang.Object>, com.seeyon.boot.transport.Sort);
    private void checkCondition(java.util.Map<java.lang.String, java.lang.Object>);
    void upgradeTextOverflowAttribute(java.lang.Long, java.util.concurrent.atomic.AtomicInteger);
```

### `ScalabilityFieldService`（51 方法）

`com.seeyon.boot.starter.customplan.domain.service.ScalabilityFieldService`

```java
    java.util.List<com.seeyon.boot.starter.customplan.dto.EntityRuntimeTreeDto> selectMetadataExtEntityTree(java.lang.String);
    private java.util.List<com.seeyon.boot.starter.customplan.dto.EntityRuntimeTreeDto> entity2Tree(java.util.List<com.seeyon.boot.starter.customplan.dto.EntityRuntimeTreeDto>, com.seeyon.ctp.metadata.dto.AggEntityMetadataDto, java.lang.String);
    int createBatch(java.util.List<com.seeyon.boot.starter.customplan.dto.ScalabilityFieldDto>);
    java.util.List<com.seeyon.boot.starter.customplan.dto.ScalabilityFieldDto> listExtFileds(com.seeyon.boot.starter.customplan.dto.ScalabilityFieldQueryDto);
    private java.util.List<com.seeyon.boot.starter.customplan.dto.ScalabilityFieldDto> selectByWraper(com.seeyon.boot.domain.dao.Wrapper);
    com.seeyon.boot.starter.customplan.dto.ScalabilityFieldDto selectAttribute(com.seeyon.boot.starter.customplan.dto.ScalabilityFieldQueryDto);
    java.util.List<com.seeyon.boot.starter.customplan.dto.ScalabilityFieldDto> selectOnAttributeByEntityFullName(java.lang.String);
    java.util.List<com.seeyon.boot.starter.customplan.dto.ScalabilityFieldDto> selectOnAttribute(com.seeyon.boot.starter.customplan.dto.ScalabilityFieldQueryDto);
    java.util.List<java.lang.String> selectAvailableDatatype(com.seeyon.boot.starter.customplan.dto.ScalabilityFieldQueryDto);
    java.lang.Integer updateBatch(com.seeyon.boot.starter.customplan.dto.ScalabilityFieldDto);
    java.lang.Integer updateBatch(java.util.List<com.seeyon.boot.starter.customplan.dto.ScalabilityFieldDto>);
    java.lang.Integer deleteByIds(java.util.List<java.lang.Long>);
    private void modifyEnumName(com.seeyon.boot.starter.customplan.dto.ScalabilityFieldDto, java.lang.String);
    private boolean modifyEntityAttribute(com.seeyon.boot.starter.customplan.domain.entity.ScalabilityField);
    private void fieldStatusChangeEvent(com.seeyon.boot.starter.customplan.dto.ScalabilityFieldDto);
    private boolean modifyEntitySystemAttribute(com.seeyon.boot.starter.customplan.domain.entity.ScalabilityField, com.seeyon.udc.common.enums.UsageStateEnum);
    void initScalabilityField(com.seeyon.udc.common.dto.AppInfoDto);
    void compensateScalabilityFieldMetadata(com.seeyon.udc.common.dto.AppInfoDto);
    java.lang.Integer transportIn(java.util.List<com.seeyon.boot.starter.customplan.dto.ScalabilityFieldDto>);
    private java.lang.Integer batchNoScalabilityField(java.util.List<com.seeyon.boot.starter.customplan.domain.entity.ScalabilityField>);
```

### `FilterPlanAnalyzeService`（43 方法）

`com.seeyon.boot.starter.customplan.domain.service.FilterPlanAnalyzeService`

```java
    com.seeyon.boot.starter.dynamicsql.dto.ProxyJoinParamDto getDynamicSelectProxyParam(com.seeyon.boot.starter.customplan.dto.FilterPlanDto, com.seeyon.boot.starter.condition.dto.dynamicsearch.DynamicSearchParamDto, com.seeyon.boot.transport.PageInfo, java.lang.String, boolean);
    com.seeyon.boot.starter.dynamicsql.dto.ProxyJoinParamDto getDynamicSelectProxyParam(java.lang.String, java.lang.String, java.lang.String, com.seeyon.boot.starter.condition.dto.dynamicsearch.DynamicSearchParamDto, com.seeyon.boot.transport.PageInfo, boolean);
    com.seeyon.boot.starter.dynamicsql.dto.ProxyJoinParamDto getDynamicSelectProxyParam(java.lang.String, java.lang.String, java.lang.String, com.seeyon.boot.starter.condition.dto.dynamicsearch.DynamicSearchParamDto, com.seeyon.boot.transport.PageInfo, boolean, java.util.Map<java.lang.String, com.seeyon.boot.starter.extmetadata.dto.UdcEntityMetaDataDto>);
    private void setDistinctList(com.seeyon.boot.starter.dynamicsql.dto.ProxyJoinParamDto, java.lang.String, java.util.Map<java.lang.String, java.util.Set<java.lang.String>>, java.util.List<com.seeyon.boot.starter.extmetadata.dto.UdcEntityMetaDataDto>);
    private java.util.List<java.lang.String> getSelectEntityList(java.lang.String, java.util.List<com.seeyon.boot.starter.dynamicsql.dto.JoinParamDto>, java.util.List<com.seeyon.boot.starter.extmetadata.dto.UdcEntityMetaDataDto>);
    java.lang.String getDistinctEntity(com.seeyon.boot.starter.dynamicsql.dto.ProxyJoinParamDto, java.util.Map<java.lang.String, java.lang.Object>, java.lang.String, java.lang.String, java.util.List<com.seeyon.boot.starter.extmetadata.dto.UdcEntityMetaDataDto>);
    private java.util.Map<java.lang.String, java.util.Set<java.lang.String>> getSelectFieldMap(java.util.Map<java.lang.String, java.lang.Object>, com.seeyon.boot.starter.condition.dto.dynamicsearch.DynamicSearchParamDto, java.lang.String, java.lang.String, java.util.List<com.seeyon.boot.starter.extmetadata.dto.UdcEntityMetaDataDto>, java.util.List<com.seeyon.boot.starter.dynamicsql.dto.JoinParamDto>);
    private void addSelectFieldsFromShowSetting(java.lang.String, java.util.List<com.seeyon.boot.starter.extmetadata.dto.UdcEntityMetaDataDto>, java.util.Map<java.lang.String, java.util.Set<java.lang.String>>, java.lang.String, java.util.Map<java.lang.String, com.seeyon.boot.starter.extmetadata.dto.UdcEntityMetaDataDto>, java.util.List<java.util.List<java.util.Map<java.lang.String, java.lang.Object>>>);
    static void addSelectFieldsAllOfDrivenEntity(java.util.Map<java.lang.String, java.util.Set<java.lang.String>>, java.lang.String, java.util.Map<java.lang.String, com.seeyon.boot.starter.extmetadata.dto.UdcEntityMetaDataDto>);
    private void addSelectFieldsFromOne2OneRelations(java.util.List<com.seeyon.boot.starter.extmetadata.dto.UdcEntityMetaDataDto>, java.util.Map<java.lang.String, java.util.Set<java.lang.String>>, java.lang.String, java.util.Map<java.lang.String, com.seeyon.boot.starter.extmetadata.dto.UdcEntityMetaDataDto>, java.util.List<com.seeyon.boot.starter.condition.dto.dynamicsearch.One2OneEntityRelationV2Dto>);
    private void addSelectFieldsFromDynamicSearchFieldOfRefer(java.util.List<com.seeyon.boot.starter.extmetadata.dto.UdcEntityMetaDataDto>, java.util.Map<java.lang.String, java.util.Set<java.lang.String>>, java.lang.String, java.util.Map<java.lang.String, com.seeyon.boot.starter.extmetadata.dto.UdcEntityMetaDataDto>, java.util.List<java.util.Map<java.lang.String, java.lang.Object>>);
    private boolean hasParentId(java.lang.String, java.util.List<com.seeyon.boot.starter.extmetadata.dto.UdcEntityMetaDataDto>);
    com.seeyon.boot.starter.dynamicsql.dto.DynamicConditionDto getConditions(java.util.List<com.seeyon.boot.starter.condition.dto.ConditionInfoDto>, com.seeyon.boot.starter.condition.dto.dynamicsearch.DynamicSearchParamDto);
    private com.seeyon.boot.starter.dynamicsql.dto.DynamicConditionDto getConditions(java.util.Map<java.lang.String, java.lang.Object>, com.seeyon.boot.starter.condition.dto.dynamicsearch.DynamicSearchParamDto);
    private com.seeyon.boot.transport.Sort getSort(java.util.Map<java.lang.String, java.lang.Object>, com.seeyon.boot.starter.condition.dto.dynamicsearch.DynamicSearchParamDto, java.lang.String);
    private java.util.List<com.seeyon.boot.starter.dynamicsql.dto.JoinParamDto> reOrderJoinParams(java.util.List<com.seeyon.boot.starter.dynamicsql.dto.JoinParamDto>, java.lang.String, java.util.List<com.seeyon.boot.starter.extmetadata.dto.UdcEntityMetaDataDto>);
    static private static void reorderDownward(java.util.List<com.seeyon.boot.starter.extmetadata.dto.UdcEntityMetaDataDto>, java.util.Map<java.lang.String, com.seeyon.boot.starter.dynamicsql.dto.JoinParamDto>, com.seeyon.boot.starter.extmetadata.dto.UdcEntityMetaDataDto, java.util.List<com.seeyon.boot.starter.dynamicsql.dto.JoinParamDto>);
    static private static void reorderUpward(java.util.List<com.seeyon.boot.starter.extmetadata.dto.UdcEntityMetaDataDto>, java.util.Map<java.lang.String, com.seeyon.boot.starter.dynamicsql.dto.JoinParamDto>, com.seeyon.boot.starter.extmetadata.dto.UdcEntityMetaDataDto, java.util.List<com.seeyon.boot.starter.dynamicsql.dto.JoinParamDto>);
    private void addSelectFieldUpwardFromCurrentEntityToTargetEntity(java.lang.String, java.lang.String, java.util.Map<java.lang.String, com.seeyon.boot.starter.extmetadata.dto.UdcEntityMetaDataDto>, java.util.List<com.seeyon.boot.starter.extmetadata.dto.UdcEntityMetaDataDto>, java.util.Map<java.lang.String, java.util.Set<java.lang.String>>);
    private java.util.List<com.seeyon.boot.starter.extmetadata.dto.UdcEntityMetaDataDto> selectOne2OneEntityByEntityFullName(java.util.Map<java.lang.String, com.seeyon.boot.starter.extmetadata.dto.UdcEntityMetaDataDto>, java.lang.String);
    private com.seeyon.boot.transport.Sort$Direction getDirectionEnumByName(java.lang.String);
```

### `FilterPlanUtil`（35 方法）

`com.seeyon.boot.starter.customplan.utils.FilterPlanUtil`

```java
    static java.lang.String getEntitySimpleNameByDtoSimpleName(java.lang.String);
    static java.lang.String getFieldNameByFiledFullName(java.lang.String);
    static java.util.Map<java.lang.String, com.seeyon.boot.starter.extmetadata.dto.UdcEntityMetaDataDto> getEntitySimpleNameMap(java.util.List<com.seeyon.boot.starter.extmetadata.dto.UdcEntityMetaDataDto>);
    static java.util.List<com.seeyon.boot.starter.condition.dto.ConditionInfoDto> getConditionsFromContent(java.util.Map<java.lang.String, java.lang.Object>);
    static java.util.List<java.util.Map<java.lang.String, java.lang.Object>> getSortSettingFromContent(java.util.Map<java.lang.String, java.lang.Object>);
    static java.util.List<java.util.List<java.util.Map<java.lang.String, java.lang.Object>>> getShowSettingPaths(java.util.Map<java.lang.String, java.lang.Object>);
    static java.lang.String getEntitySimpleNameFromPath(java.util.Map<java.lang.String, java.lang.Object>, java.lang.String);
    static java.lang.String getFieldNameSimpleNameFromPath(java.util.Map<java.lang.String, java.lang.Object>, java.lang.String);
    static boolean isDescendantOfTargetEntity(java.lang.String, java.lang.String, java.util.List<com.seeyon.boot.starter.extmetadata.dto.UdcEntityMetaDataDto>);
    static boolean isAncestorsOfTargetEntity(java.lang.String, java.lang.String, java.util.List<com.seeyon.boot.starter.extmetadata.dto.UdcEntityMetaDataDto>);
    static boolean isOne2OneAncestorsOfTargetEntity(java.lang.String, java.lang.String, java.util.List<com.seeyon.boot.starter.extmetadata.dto.UdcEntityMetaDataDto>);
    static com.seeyon.boot.starter.extmetadata.dto.UdcEntityMetaDataDto findOne2OneChildEntityByEntitySimpleName(java.util.List<com.seeyon.boot.starter.extmetadata.dto.UdcEntityMetaDataDto>, com.seeyon.boot.starter.extmetadata.dto.UdcEntityMetaDataDto, java.lang.String);
    static void setInConditionOfAllAttributes(java.util.Map<java.lang.String, com.seeyon.boot.starter.extmetadata.dto.UdcEntityMetaDataDto>);
    static java.util.List<com.seeyon.boot.starter.customplan.dto.FilterPlanDto> getNeedCleanIdFilterPlanDtos(java.util.List<java.lang.Long>, java.util.List<com.seeyon.boot.starter.customplan.dto.FilterPlanDto>);
```

### `FilterPlanRtService`（29 方法）

`com.seeyon.boot.starter.customplan.domain.service.FilterPlanRtService`

```java
    int deleteByIds(java.util.List<java.lang.Long>);
    int deleteById(java.lang.Long);
    int deleteByGuid(java.lang.Long);
    int deleteByGuids(java.util.List<java.lang.Long>);
    com.seeyon.boot.starter.customplan.dto.FilterPlanDto selectById(java.lang.Long);
    com.seeyon.boot.starter.customplan.dto.FilterPlanDto selectByGuid(java.lang.Long);
    java.util.List<com.seeyon.boot.starter.customplan.dto.FilterPlanDto> selectByGuids(java.util.List<java.lang.Long>);
    java.util.Map<java.lang.String, java.lang.Object> getDynamicSelectSetting(com.seeyon.boot.starter.customplan.dto.FilterPlanDto, com.seeyon.boot.starter.condition.dto.dynamicsearch.DynamicSearchParamDto);
    com.seeyon.boot.starter.customplan.dto.FilterPlanDto selectDefaultPlanBySourceId(java.lang.String);
    com.seeyon.boot.starter.customplan.dto.FilterPlanDto selectListDefaultPlanBySourceIdRt(java.lang.String);
    private com.seeyon.boot.starter.dynamicsql.dto.DynamicConditionDto getDynamicCondition(java.util.Map<java.lang.String, java.lang.Object>, java.util.Map<java.lang.String, java.util.List<java.util.Map<java.lang.String, java.lang.Object>>>);
    private com.seeyon.boot.transport.Sort getSortFromFilterPlan(java.util.Map<java.lang.String, java.lang.Object>, java.lang.String);
    private com.seeyon.boot.transport.Sort getSortFromFrontend(java.util.List<java.util.Map<java.lang.String, java.lang.Object>>);
    void buildSearchParam(com.seeyon.boot.starter.dynamicsql.dto.DynamicConditionDto, com.seeyon.boot.starter.condition.dto.dynamicsearch.DynamicSearchParamDto);
    com.seeyon.boot.starter.customplan.dto.FilterPlanDto getCache(java.lang.Long);
    void setCache(com.seeyon.boot.starter.customplan.dto.FilterPlanDto);
    void evictCache(java.lang.Long);
    void evictLocalCacheAll();
    void clearCacheByApp(java.lang.String);
    java.util.List<com.seeyon.boot.starter.customplan.dto.FilterPlanDto> selectFilterPlanListFromJar(java.lang.String, java.lang.String);
    com.seeyon.boot.starter.customplan.dto.FilterPlanDto selectDefaultPlanBySourceIdFromJar(java.lang.String, java.lang.String, java.lang.String);
    com.seeyon.boot.starter.customplan.dto.FilterPlanDto selectDefaultListPlanBySourceIdFromJar(java.lang.String, java.lang.String, java.lang.String);
    com.seeyon.boot.starter.customplan.dto.FilterPlanDto selectByGuidFromJar(java.lang.Long, java.lang.String, java.lang.String);
```

### `FilterPlanAppService`（27 方法）

`com.seeyon.boot.starter.customplan.appservice.FilterPlanAppService`

```java
    com.seeyon.boot.transport.SingleResponse<com.seeyon.boot.starter.customplan.dto.FilterPlanDto> create(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.customplan.dto.FilterPlanDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.boot.starter.customplan.dto.FilterPlanDto> createUpgrade(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.customplan.dto.FilterPlanDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.boot.starter.customplan.dto.FilterPlanDto> createNew(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.customplan.dto.FilterPlanDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> deleteById(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> deleteByIds(com.seeyon.boot.transport.SingleRequest<java.util.List<java.lang.Long>>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> deleteByGuid(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> deleteByGuids(com.seeyon.boot.transport.SingleRequest<java.util.List<java.lang.Long>>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> deleteBySourcedId(com.seeyon.boot.transport.SingleRequest<java.lang.String>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> update(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.customplan.dto.FilterPlanDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> updateBatch(com.seeyon.boot.transport.SingleRequest<java.util.List<com.seeyon.boot.starter.customplan.dto.FilterPlanDto>>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.boot.starter.customplan.dto.FilterPlanDto> selectById(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.boot.starter.customplan.dto.FilterPlanDto> selectByGuid(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.boot.starter.customplan.dto.FilterPlanDto> selectByGuids(com.seeyon.boot.transport.SingleRequest<java.util.List<java.lang.Long>>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.boot.starter.customplan.dto.FilterPlanDto> selectByCombination(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.customplan.dto.FilterPlanCombinationSelectDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.boot.starter.customplan.dto.FilterPlanDto> selectBySourceId(com.seeyon.boot.transport.SingleRequest<java.lang.String>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.boot.starter.customplan.dto.FilterPlanDto> selectDefaultPlanBySourceId(com.seeyon.boot.transport.SingleRequest<java.lang.String>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.boot.starter.customplan.dto.FilterPlanDto> selectByAppId(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    private void fillEntityMedata(java.util.List<com.seeyon.boot.starter.customplan.dto.FilterPlanDto>);
    java.util.List<com.seeyon.boot.starter.customplan.dto.FilterPlanDto> selectListByCondition(com.seeyon.boot.transport.ListRequest);
    java.util.List<com.seeyon.boot.starter.customplan.dto.FilterPlanDto> selectFromalListByCondition(com.seeyon.boot.transport.ListRequest);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.boot.starter.customplan.dto.FilterPlanDto> selectByIdRt(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.boot.starter.customplan.dto.FilterPlanDto> selectByGuidRt(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> deleteByIdRt(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> deleteByGuidRt(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.boot.starter.customplan.dto.FilterPlanDto> selectDefaultPlanBySourceIdRt(com.seeyon.boot.transport.SingleRequest<java.lang.String>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.boot.starter.customplan.dto.FilterPlanDto> selectListDefaultPlanBySourceIdRt(com.seeyon.boot.transport.SingleRequest<java.lang.String>);
    java.util.List<com.seeyon.boot.starter.customplan.dto.FilterPlanDto> selectRtFilterPlanFromJar(com.seeyon.boot.transport.SingleRequest<java.lang.String>);
```

### `PersonalPlanService`（27 方法）

`com.seeyon.boot.starter.customplan.domain.service.PersonalPlanService`

```java
    com.seeyon.boot.starter.customplan.dto.PersonalPlanDto selectByCondition(com.seeyon.boot.starter.customplan.dto.PersonalQueryDto);
    java.util.List<com.seeyon.boot.starter.customplan.dto.PersonalPlanDto> selectListByCondition(com.seeyon.boot.starter.customplan.dto.PersonalQueryDto);
    private com.seeyon.boot.starter.customplan.dto.PersonalPlanDto getPersonalPlanDto(java.lang.Long, java.lang.String, java.util.Map<java.lang.String, java.lang.Object>);
    private com.seeyon.boot.starter.customplan.domain.entity.PersonalPlan doGetPersonalPlane(java.util.Map<java.lang.String, java.lang.Object>, java.lang.String, java.lang.Long, com.seeyon.boot.starter.customplan.enums.AuthTypeEnum);
    private com.seeyon.boot.starter.customplan.domain.entity.PersonalPlan matchPermission(java.lang.String, java.lang.Long, com.seeyon.boot.starter.customplan.enums.AuthTypeEnum, java.util.List<com.seeyon.boot.starter.customplan.domain.entity.PersonalPlan>, org.springframework.util.StopWatch);
    java.util.List<java.lang.String> selectUserResourceCode(com.seeyon.ctp.user.dto.CtpUserResourceSearchDto);
    java.util.List<java.lang.Long> createRedirectBatch(java.util.List<com.seeyon.boot.starter.customplan.dto.PersonalPlanDto>);
    int createOrUpdateBatch(java.util.List<com.seeyon.boot.starter.customplan.dto.PersonalPlanDto>);
    private com.seeyon.boot.starter.customplan.domain.entity.PersonalPlan getCache(java.lang.String);
    private java.util.List<com.seeyon.boot.starter.customplan.domain.entity.PersonalPlan> getCacheBatch(java.lang.String);
    private void setCache(com.seeyon.boot.starter.customplan.domain.entity.PersonalPlan, java.lang.String, java.lang.String);
    private void setCacheBatch(java.util.List<com.seeyon.boot.starter.customplan.domain.entity.PersonalPlan>, java.lang.String);
    private void evictCache(java.util.List<com.seeyon.boot.starter.customplan.domain.entity.PersonalPlan>);
    private java.lang.String getCompleteCacheKey(java.lang.String, java.lang.Long, com.seeyon.boot.starter.customplan.enums.AuthTypeEnum, java.lang.Long);
    private java.lang.String buildCompleteCacheKey4AppName(java.lang.String, com.seeyon.udc.common.enums.PageUrlTypeEnum);
    com.seeyon.boot.transport.PageData<com.seeyon.boot.starter.customplan.dto.PersonalPlanDto> selectPageByCondition(com.seeyon.boot.transport.PageInfo, java.util.Map<java.lang.String, java.lang.Object>, com.seeyon.boot.transport.Sort);
    int deleteByIds(java.util.List<java.lang.Long>);
```

### `PageSchemaUtils`（24 方法）

`com.seeyon.boot.starter.customplan.common.util.PageSchemaUtils`

```java
    static java.util.Map<java.lang.String, com.fasterxml.jackson.databind.node.ObjectNode> parseNodeContainDs(com.seeyon.udc.common.dto.PageSchemaDto);
    static java.util.Map<java.lang.String, com.fasterxml.jackson.databind.node.ObjectNode> parseNodeContainEvents(com.seeyon.udc.common.dto.PageSchemaDto);
    static java.util.Map<java.lang.String, com.fasterxml.jackson.databind.node.ObjectNode> parsePreDetectedNode4Report(com.seeyon.udc.common.dto.PageSchemaDto);
    static java.util.Map<java.lang.String, java.util.Map<cn.hutool.core.lang.Pair<java.lang.String, java.lang.String>, cn.hutool.core.lang.Pair<java.lang.String, java.lang.String>>> parseInParams(com.seeyon.udc.common.dto.PageSchemaDto);
    static java.util.Map<java.lang.String, cn.hutool.core.lang.Pair<java.lang.String, java.util.Set<java.lang.String>>> parseNodes4ContainNotExistWidget(com.seeyon.udc.common.dto.PageSchemaDto);
    static java.util.Map<java.lang.String, com.fasterxml.jackson.databind.node.ObjectNode> parseNodes(com.seeyon.udc.common.dto.PageSchemaDto, java.lang.String);
    static java.util.Map<java.lang.String, com.fasterxml.jackson.databind.node.ObjectNode> parseNodeByWidGetType(com.seeyon.udc.common.dto.PageSchemaDto, java.util.Set<java.lang.String>);
    static java.lang.Object getByPath(java.lang.String, java.lang.String);
    static private static java.lang.String containNotExistWidgetPath(java.util.Set<java.lang.String>, com.fasterxml.jackson.databind.node.ObjectNode, java.lang.String);
    static java.util.Map<java.lang.String, com.fasterxml.jackson.databind.node.ObjectNode> parsePreDetectedNode(java.util.Map<java.lang.String, com.fasterxml.jackson.databind.node.ObjectNode>, java.lang.String);
    static java.util.Map<java.lang.String, com.fasterxml.jackson.databind.node.ObjectNode> parsePreDetectedNode4Columns(java.util.Map<java.lang.String, com.fasterxml.jackson.databind.node.ObjectNode>);
    static java.util.Map<java.lang.String, com.fasterxml.jackson.databind.node.ObjectNode> parsePreDetectedNode4Refer(java.util.Map<java.lang.String, com.fasterxml.jackson.databind.node.ObjectNode>);
    static java.lang.String writeSchema(com.fasterxml.jackson.databind.JsonNode);
    static com.fasterxml.jackson.databind.JsonNode parseSchema(java.lang.String);
    static <T> T getNode(com.fasterxml.jackson.databind.JsonNode, java.lang.String);
    static java.lang.String getTextValue(com.fasterxml.jackson.databind.JsonNode, java.lang.String);
    static private static java.util.function.Predicate<java.util.Map$Entry<java.lang.String, com.fasterxml.jackson.databind.node.ObjectNode>> findObjectNodePredicate(java.lang.String);
    static private static java.util.function.Predicate<java.util.Map$Entry<java.lang.String, com.fasterxml.jackson.databind.node.ObjectNode>> findObjectNodePredicateBySettingsPro(java.lang.String);
    static private static java.util.function.Predicate<java.util.Map$Entry<java.lang.String, com.fasterxml.jackson.databind.node.ObjectNode>> findObjectNodePredicateForColumns();
```

### `FilterPlanFormalService`（24 方法）

`com.seeyon.boot.starter.customplan.domain.service.FilterPlanFormalService`

```java
    com.seeyon.boot.starter.customplan.dto.FilterPlanDto create(com.seeyon.boot.starter.customplan.dto.FilterPlanDto);
    int createBatch(java.util.List<com.seeyon.boot.starter.customplan.dto.FilterPlanDto>);
    void cleanEntities(java.lang.Long, java.util.List<java.lang.Long>);
    int deleteById(java.lang.Long);
    int deleteByIds(java.util.List<java.lang.Long>);
    int deleteByGuid(java.lang.Long);
    int deleteByGuids(java.util.List<java.lang.Long>);
    int deleteByPageId(java.lang.Long);
    int deleteByPageIdAndSourceIds(java.lang.Long, java.util.List<java.lang.String>);
    int deleteByPageIds(java.util.List<java.lang.Long>);
    int deleteByAppId(java.lang.Long);
    int deleteByAppIds(java.util.List<java.lang.Long>);
    int update(com.seeyon.boot.starter.customplan.dto.FilterPlanDto);
    int updateBatch(java.util.List<com.seeyon.boot.starter.customplan.dto.FilterPlanDto>);
    com.seeyon.boot.starter.customplan.dto.FilterPlanDto selectById(java.lang.Long);
    com.seeyon.boot.starter.customplan.dto.FilterPlanDto selectByGuid(java.lang.Long);
    java.util.List<com.seeyon.boot.starter.customplan.dto.FilterPlanDto> selectByGuids(java.util.List<java.lang.Long>);
    java.util.List<com.seeyon.boot.starter.customplan.dto.FilterPlanDto> selectByPageIds(java.util.List<java.lang.Long>);
    java.util.List<com.seeyon.boot.starter.customplan.dto.FilterPlanDto> selectByAppId(java.lang.Long);
    java.util.List<com.seeyon.boot.starter.customplan.dto.FilterPlanDto> selectListByCondition(java.util.Map<java.lang.String, java.lang.Object>, com.seeyon.boot.transport.Sort);
    private void checkCondition(java.util.Map<java.lang.String, java.lang.Object>);
    void upgradeTextOverflowAttribute(java.lang.Long, java.util.concurrent.atomic.AtomicInteger);
```

### `FilterPlanJoinUtil`（24 方法）

`com.seeyon.boot.starter.customplan.utils.FilterPlanJoinUtil`

```java
    static java.util.List<com.seeyon.boot.starter.dynamicsql.dto.JoinParamDto> getJoinParams(java.lang.String, com.seeyon.boot.starter.condition.dto.dynamicsearch.DynamicSearchParamDto, java.lang.String, java.util.List<com.seeyon.boot.starter.extmetadata.dto.UdcEntityMetaDataDto>, java.util.Map<java.lang.String, java.lang.Object>);
    static private static void addJoinParamsFromConditions(java.util.List<com.seeyon.boot.starter.dynamicsql.dto.JoinParamDto>, java.lang.String, java.util.List<com.seeyon.boot.starter.condition.dto.ConditionInfoDto>, java.util.Set<java.lang.String>, java.util.Map<java.lang.String, com.seeyon.boot.starter.extmetadata.dto.UdcEntityMetaDataDto>, java.util.List<com.seeyon.boot.starter.extmetadata.dto.UdcEntityMetaDataDto>);
    static private static void addJoinParamsFromSearchParam(java.util.List<com.seeyon.boot.starter.dynamicsql.dto.JoinParamDto>, java.lang.String, java.util.Map<java.lang.String, java.lang.Object>, java.util.Set<java.lang.String>, java.util.Map<java.lang.String, com.seeyon.boot.starter.extmetadata.dto.UdcEntityMetaDataDto>, java.util.List<com.seeyon.boot.starter.extmetadata.dto.UdcEntityMetaDataDto>);
    static private static void addJoinParamsFromSortSetting(java.util.List<java.util.Map<java.lang.String, java.lang.Object>>, java.util.List<java.util.Map<java.lang.String, java.lang.Object>>, java.util.List<com.seeyon.boot.starter.dynamicsql.dto.JoinParamDto>, java.lang.String, java.util.Set<java.lang.String>, java.util.Map<java.lang.String, com.seeyon.boot.starter.extmetadata.dto.UdcEntityMetaDataDto>, java.util.List<com.seeyon.boot.starter.extmetadata.dto.UdcEntityMetaDataDto>, java.lang.String);
    static private static void addJoinParamsFromShowSetting(java.util.List<java.util.List<java.util.Map<java.lang.String, java.lang.Object>>>, java.util.List<com.seeyon.boot.starter.dynamicsql.dto.JoinParamDto>, java.lang.String, java.lang.String, java.util.Set<java.lang.String>, java.util.Map<java.lang.String, com.seeyon.boot.starter.extmetadata.dto.UdcEntityMetaDataDto>, java.util.List<com.seeyon.boot.starter.extmetadata.dto.UdcEntityMetaDataDto>);
    static private static void addJoinParamsFromDynamicSearchField(java.util.List<java.util.Map<java.lang.String, java.lang.Object>>, java.util.List<com.seeyon.boot.starter.dynamicsql.dto.JoinParamDto>, java.lang.String, java.util.Set<java.lang.String>, java.util.Map<java.lang.String, com.seeyon.boot.starter.extmetadata.dto.UdcEntityMetaDataDto>, java.util.List<com.seeyon.boot.starter.extmetadata.dto.UdcEntityMetaDataDto>);
    static private static void addJoinParamsFromOne2OneRelationEntities(java.util.List<com.seeyon.boot.starter.condition.dto.dynamicsearch.One2OneEntityRelationV2Dto>, java.util.List<com.seeyon.boot.starter.dynamicsql.dto.JoinParamDto>, java.lang.String, java.util.Set<java.lang.String>, java.util.Map<java.lang.String, com.seeyon.boot.starter.extmetadata.dto.UdcEntityMetaDataDto>, java.util.List<com.seeyon.boot.starter.extmetadata.dto.UdcEntityMetaDataDto>);
    static private static void buildJoinParamUpward(java.lang.String, java.lang.String, java.util.List<com.seeyon.boot.starter.dynamicsql.dto.JoinParamDto>, java.util.List<com.seeyon.boot.starter.extmetadata.dto.UdcEntityMetaDataDto>, java.util.Map<java.lang.String, com.seeyon.boot.starter.extmetadata.dto.UdcEntityMetaDataDto>, java.util.Set<java.lang.String>);
    static private static void buildJoinParamUpwardOne2One(java.lang.String, java.lang.String, java.util.List<com.seeyon.boot.starter.dynamicsql.dto.JoinParamDto>, java.util.List<com.seeyon.boot.starter.extmetadata.dto.UdcEntityMetaDataDto>, java.util.Map<java.lang.String, com.seeyon.boot.starter.extmetadata.dto.UdcEntityMetaDataDto>, java.util.Set<java.lang.String>);
    static private static void buildJoinParamDownward(java.lang.String, java.lang.String, java.util.List<com.seeyon.boot.starter.dynamicsql.dto.JoinParamDto>, java.util.List<com.seeyon.boot.starter.extmetadata.dto.UdcEntityMetaDataDto>, java.util.Map<java.lang.String, com.seeyon.boot.starter.extmetadata.dto.UdcEntityMetaDataDto>, java.util.Set<java.lang.String>);
    static private static com.seeyon.boot.starter.customplan.dto.BiLinkedList<com.seeyon.boot.starter.extmetadata.dto.UdcEntityMetaDataDto> getUpwardList(java.lang.String, java.lang.String, java.util.List<com.seeyon.boot.starter.extmetadata.dto.UdcEntityMetaDataDto>, java.util.Map<java.lang.String, com.seeyon.boot.starter.extmetadata.dto.UdcEntityMetaDataDto>);
    static private static com.seeyon.boot.starter.customplan.dto.BiLinkedList<com.seeyon.boot.starter.extmetadata.dto.UdcEntityMetaDataDto> getDownwardList(java.lang.String, java.lang.String, java.util.List<com.seeyon.boot.starter.extmetadata.dto.UdcEntityMetaDataDto>, java.util.Map<java.lang.String, com.seeyon.boot.starter.extmetadata.dto.UdcEntityMetaDataDto>);
    static void adapterDb(com.seeyon.boot.starter.dynamicsql.dto.ProxyJoinParamDto);
    static void handlerDistinctSet(com.seeyon.boot.starter.dynamicsql.dto.ProxyJoinParamDto, java.util.List<com.seeyon.boot.starter.extmetadata.dto.UdcEntityMetaDataDto>);
    static void handlerSearchFiled(com.seeyon.boot.starter.dynamicsql.dto.ProxyJoinParamDto, java.util.List<com.seeyon.boot.starter.extmetadata.dto.UdcEntityMetaDataDto>);
    static private static java.util.List<com.seeyon.boot.starter.condition.dto.SingleConditionDto$RightParamDto> getEntityFieldRightParams(com.seeyon.boot.starter.condition.dto.ConditionInfoDto);
```

### `BpmNodeInfoAppService`（18 方法）

`com.seeyon.boot.starter.customplan.appservice.BpmNodeInfoAppService`

```java
    com.seeyon.boot.transport.SingleResponse<com.seeyon.bpm.dto.BpmNodePermission4PageDto> selectByComplexCondition(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.customplan.dto.CBpmNodePermissionRequestDto>);
    private java.util.List<com.seeyon.udc.dto.page.PageProcessEventDto> getPageProcessEventDtos(com.seeyon.boot.starter.customplan.dto.CBpmNodePermissionRequestDto);
    private java.util.List<com.seeyon.bpm.dto.BpmFormPermissionContentDto> changeBpmNodeOperate2Page(java.util.List<com.seeyon.udc.dto.page.PageProcessEventDto>, java.util.List<com.seeyon.bpm.dto.approval.BpmNodePermissionResponseDto>);
    private java.util.List<com.seeyon.bpm.dto.BpmFormPermissionContentDto> invisibleBpmButton(java.util.List<com.seeyon.udc.dto.page.PageProcessEventDto>);
    private java.util.List<com.seeyon.bpm.dto.BpmFormPermissionContentDto> mergeCustomPlanContent(java.util.List<com.seeyon.bpm.dto.BpmFormPermissionContentDto>, java.util.List<com.seeyon.bpm.dto.BpmFormPermissionContentDto>);
    private boolean checkPermission(java.util.List<com.seeyon.bpm.dto.approval.BpmNodePermissionResponseDto>, java.lang.String);
    private java.lang.String getPlanContent(java.lang.String, java.lang.String, java.lang.String);
```

### `CustomPlanAppServiceImpl`（18 方法）

`com.seeyon.boot.starter.customplan.appservice.CustomPlanAppServiceImpl`

```java
    com.seeyon.boot.transport.ListResponse<com.seeyon.boot.starter.customplan.dto.CustomPlanDto> selectBySourceIds(com.seeyon.boot.transport.SingleRequest<java.util.List<java.lang.String>>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.boot.starter.customplan.dto.CustomPlanDto> selectByComplexCondition(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.customplan.dto.CustomPlanSearchDto>);
    private java.util.List<com.seeyon.udc.dto.page.PageProcessEventDto> getPageProcessEventDtos(java.lang.String, java.lang.Long);
    private java.util.List<com.seeyon.boot.starter.customplan.dto.CustomPlanContentDto> invisibleBpmButton(java.util.List<com.seeyon.udc.dto.page.PageProcessEventDto>);
    private java.util.List<com.seeyon.boot.starter.customplan.dto.CustomPlanContentDto> changeBpmNodeOperate2Page(java.util.List<com.seeyon.udc.dto.page.PageProcessEventDto>, java.util.List<com.seeyon.bpm.dto.approval.BpmNodePermissionResponseDto>);
    private java.util.List<com.seeyon.boot.starter.customplan.dto.CustomPlanContentDto> mergeCustomPlanContent(java.util.List<com.seeyon.boot.starter.customplan.dto.CustomPlanContentDto>, java.util.List<com.seeyon.boot.starter.customplan.dto.CustomPlanContentDto>);
    private boolean checkPermission(java.util.List<com.seeyon.bpm.dto.approval.BpmNodePermissionResponseDto>, java.lang.String);
    private java.lang.String getPlanContent(java.lang.String, java.lang.String);
```

### `UdcRuntimeHistoryMetaDataService`（16 方法）

`com.seeyon.boot.starter.customplan.domain.service.UdcRuntimeHistoryMetaDataService`

```java
    static private static com.seeyon.boot.domain.dao.Wrapper newWrapper(com.seeyon.udc.common.dto.AppInfoDto);
    int createBatch(java.util.List<com.seeyon.boot.starter.customplan.dto.UdcHistoryMetaDataDto>);
    int deleteBatch(java.util.List<com.seeyon.boot.starter.customplan.dto.UdcHistoryMetaDataDto>);
    int updateBatch(java.util.List<com.seeyon.boot.starter.customplan.dto.UdcHistoryMetaDataDto>);
    java.util.List<com.seeyon.boot.starter.customplan.dto.UdcHistoryMetaDataDto> selectByCondition(java.util.Map<java.lang.String, java.lang.Object>);
    void refreshAppCurrentVersionMetaData(com.seeyon.udc.common.dto.AppInfoDto, com.seeyon.boot.starter.customplan.dto.UdcHistoryMetadataCollectionDto);
    com.seeyon.boot.starter.customplan.dto.UdcHistoryMetadataCollectionDto collectionRuntimeAppMetadataByCurrentVersion(com.seeyon.udc.common.dto.AppInfoDto);
    private java.util.List<com.seeyon.udc.common.dto.EntityDto> getEntityListFromJar(com.seeyon.udc.common.dto.AppInfoDto);
    private java.util.List<com.seeyon.udc.common.dto.AttributeDto> getAttributeListFromJar(java.util.Map<java.lang.Long, com.seeyon.udc.common.dto.EntityDto>, com.seeyon.udc.common.dto.AppInfoDto);
    private java.util.List<com.seeyon.udc.common.dto.IndexDto> getIndexListFromJar(java.util.Map<java.lang.Long, com.seeyon.udc.common.dto.EntityDto>, com.seeyon.udc.common.dto.AppInfoDto);
    private void check(java.util.List<com.seeyon.boot.starter.customplan.dto.UdcHistoryMetaDataDto>);
    private void createNewAppRunningMetadata(com.seeyon.udc.common.dto.AppInfoDto, com.seeyon.boot.starter.customplan.dto.UdcHistoryMetadataCollectionDto);
```

### `UdcPageProcessEventServiceImpl`（15 方法）

`com.seeyon.boot.starter.customplan.appservice.UdcPageProcessEventServiceImpl`

```java
    com.seeyon.boot.transport.ListResponse<com.seeyon.udc.dto.page.PageProcessEventDto> selectProcessEventListByCondition(com.seeyon.boot.transport.SingleRequest<com.seeyon.udc.dto.page.PageProcessEventSearchDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.udc.dto.page.PageProcessEventDto> selectProcessEventList(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.customplan.dto.CBpmNodePermissionRequestDto>);
    void clearCacheByAppName(com.seeyon.boot.transport.SingleRequest<java.lang.String>);
    private java.util.List<com.seeyon.udc.dto.page.PageProcessEventDto> selectProcessEventListFromCache(com.seeyon.udc.dto.page.PageProcessEventSearchDto);
    private java.util.List<com.seeyon.udc.dto.page.PageProcessEventDto> loadPageProcessEventList(com.seeyon.udc.dto.page.PageProcessEventSearchDto);
    private java.util.List<com.seeyon.udc.dto.page.PageProcessEventDto> parseProcessEventByWidGetType(com.seeyon.udc.common.dto.PageSchemaDto);
    private java.util.List<com.seeyon.udc.dto.page.PageProcessEventDto> parseProcessEventByEvent(com.seeyon.udc.common.dto.PageSchemaDto);
    private java.util.List<java.lang.String> getUIModelControlledPropsKey(com.fasterxml.jackson.databind.node.ObjectNode);
    private java.util.List<com.seeyon.udc.dto.page.PageProcessEventSearchDto> getSearchList(com.seeyon.boot.starter.customplan.dto.CBpmNodePermissionRequestDto);
    private com.seeyon.udc.dto.page.PageProcessEventSearchDto getPageSearchList(com.seeyon.boot.starter.customplan.enums.PageBpmEventSearchTypeEnum, java.lang.String, java.lang.Long, java.lang.String, com.seeyon.bpm.enums.PageTypeEnum);
    private java.lang.String getAppBuildTime(java.lang.String);
```

### `ScalabilityFieldAppServiceImpl`（7 方法）

`com.seeyon.boot.starter.customplan.appservice.ScalabilityFieldAppServiceImpl`

```java
    com.seeyon.boot.transport.ListResponse<com.seeyon.boot.starter.customplan.dto.EntityRuntimeTreeDto> selectMetadataExtEntityTree(com.seeyon.boot.transport.SingleRequest<java.lang.String>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.boot.starter.customplan.dto.ScalabilityFieldDto> listExtFileds(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.customplan.dto.ScalabilityFieldQueryDto>);
    com.seeyon.boot.transport.ListResponse<java.lang.String> selectAvailableDatatype(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.customplan.dto.ScalabilityFieldQueryDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.boot.starter.customplan.dto.ScalabilityFieldDto> selectAttribute(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.customplan.dto.ScalabilityFieldQueryDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> updateBatch(com.seeyon.boot.transport.SingleRequest<java.util.List<com.seeyon.boot.starter.customplan.dto.ScalabilityFieldDto>>);
    com.seeyon.boot.transport.SingleResponse<java.lang.String> compensateScalabilityFieldMetadata(com.seeyon.boot.transport.SingleRequest<java.lang.Void>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> transportIn(com.seeyon.boot.transport.SingleRequest<java.util.List<com.seeyon.boot.starter.customplan.dto.ScalabilityFieldDto>>);
```

### `PersonalPlanAppServiceImpl`（5 方法）

`com.seeyon.boot.starter.customplan.appservice.PersonalPlanAppServiceImpl`

```java
    com.seeyon.boot.transport.SingleResponse<com.seeyon.boot.starter.customplan.dto.PersonalPlanDto> selectByCondition(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.customplan.dto.PersonalQueryDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.boot.starter.customplan.dto.PersonalPlanDto> selectListByCondition(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.customplan.dto.PersonalQueryDto>);
    com.seeyon.boot.transport.SingleResponse<java.util.List<java.lang.Long>> createRedirectBatch(com.seeyon.boot.transport.SingleRequest<java.util.List<com.seeyon.boot.starter.customplan.dto.PersonalPlanDto>>);
    com.seeyon.boot.transport.PageResponse<com.seeyon.boot.starter.customplan.dto.PersonalPlanDto> selectPageByCondition(com.seeyon.boot.transport.PageRequest);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> deleteByIds(com.seeyon.boot.transport.SingleRequest<java.util.List<java.lang.Long>>);
```

### `SearchCondUtils`（5 方法）

`com.seeyon.boot.starter.customplan.common.util.SearchCondUtils`

```java
    static void buildSearchCondMap(java.util.Map$Entry<java.lang.String, java.lang.Object>, java.util.Map<java.lang.String, java.lang.Object>, java.lang.String);
    static private static void doBuildSearchCondMap(java.util.Map$Entry<java.lang.String, java.lang.Object>, java.util.Map<java.lang.String, java.lang.Object>, java.lang.String, java.lang.String, java.lang.String, java.lang.String);
    static private static java.lang.String getOperate(java.lang.String);
    static private static java.lang.String replaceMulitKey(java.lang.String, java.lang.String, java.lang.String);
    static java.lang.String replaceSearchKey(java.lang.String);
```

### `TreeReferUtil`（4 方法）

`com.seeyon.boot.starter.customplan.utils.TreeReferUtil`

```java
    static void addDefaultDisplayFields(java.lang.Class, com.seeyon.boot.starter.dynamicsql.dto.ProxyJoinParamDto);
    static void addDefaultDisplayFields(java.lang.String, com.seeyon.boot.starter.dynamicsql.dto.ProxyJoinParamDto);
```

### `CustomPlanService`（3 方法）

`com.seeyon.boot.starter.customplan.domain.service.CustomPlanService`

```java
    java.util.List<com.seeyon.boot.starter.customplan.dto.CustomPlanDto> selectBySourceIds(java.util.List<java.lang.String>);
    private java.util.List<com.seeyon.boot.starter.customplan.dto.CustomPlanContentDto> findCustomPlanContentByPlanIds(java.util.List<java.lang.Long>);
```

## 四、枚举（9）

- `AuthTypeEnum`（3 常量）：SYSTEM, ORG, MEMBER
- `CustomPlanContentTypeEnum`（3 常量）：WIDGET, FIELD, INNER_CONTROLLER
- `CustomPlanSourceTypeEnum`（2 常量）：SYSTEM, CUSTOM
- `CustomPlanTypeEnum`（6 常量）：LIST, PAGE, AUTH, REFER, TOOLBAR, DATA_FLOW
- `FilterPlanTypeEnum`（4 常量）：FILTER, REFERENCE, LIST, DATA_FLOW
- `PageBpmEventSearchTypeEnum`（3 常量）：ALL, PAGE, LAYOUT
- `ScalabilityTypeEnum`（2 常量）：NONE, SCALABILITY
- `UdcRuntimeMetaDataTypeEnum`（4 常量）：NONE, ENTITY, ATTRIBUTE, INDEX
- `WidgetDeviceTypeEnum`（2 常量）：PC, MOBILE
