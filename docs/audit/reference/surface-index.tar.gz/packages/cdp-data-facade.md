# cdp-data-facade：接口与方法签名

> 自动生成，勿手改。`tools/core/platform/emit_package_surfaces.py` 重跑即可。
> 构件 `com.seeyon:cdp-data-facade`（jar `cdp-data-facade-5.3.279.jar`）
> 规模：127 类 / 10 接口 / 0 注解 / 12 枚举 / 0 个关键类 / 863 方法。
> 签名逐字来自 javap 原文；已去掉 `public` 前缀与 `throws` 子句。

## 一、接口（10）

### `CdpBiz4UdcAppService`（17 方法）

`com.seeyon.cdp.common.api.CdpBiz4UdcAppService`

```java
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cdp.common.dto.publish.PublishResultDto> deploy(com.seeyon.boot.transport.SingleRequest<com.seeyon.cdp.common.dto.publish.PublishParamsDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cdp.common.dto.validation.CdpDetectionDto> detectionV2(com.seeyon.boot.transport.SingleRequest<com.seeyon.cdp.common.dto.validation.ValidationParamsDto>);
    default com.seeyon.boot.transport.SingleResponse<java.lang.String> transportOut(com.seeyon.boot.transport.SingleRequest<com.seeyon.cdp.common.dto.transport.TransportOutRequestDto>);
    default com.seeyon.boot.transport.SingleResponse<java.lang.String> transportOutV2(com.seeyon.boot.transport.SingleRequest<com.seeyon.cdp.common.dto.transport.TransportOutRequestDto>);
    default com.seeyon.boot.transport.SingleResponse<java.lang.Boolean> transportIn(com.seeyon.boot.transport.SingleRequest<java.lang.String>);
    default com.seeyon.boot.transport.SingleResponse<java.lang.Boolean> transportInV2(com.seeyon.boot.transport.SingleRequest<java.lang.String>);
    default com.seeyon.boot.transport.ListResponse<com.seeyon.cdp.common.dto.report.UdcReportDto> getReportList(com.seeyon.boot.transport.SingleRequest<com.seeyon.cdp.common.dto.report.UdcReportRequestDto>);
    default com.seeyon.boot.transport.ListResponse<java.lang.String> getCdpDataIdList();
    default com.seeyon.boot.transport.SingleResponse<java.lang.Boolean> deleteApp(com.seeyon.boot.transport.SingleRequest<com.seeyon.cdp.common.dto.DeleteAppParamsDto>);
    default com.seeyon.boot.transport.ListResponse<com.seeyon.cdp.common.dto.validation.CdpDetectionErrorDto> detectionPartEntityForDataset(com.seeyon.boot.transport.SingleRequest<com.seeyon.cdp.common.dto.validation.part.CdpDetectionEntityDto>);
    default com.seeyon.boot.transport.ListResponse<com.seeyon.cdp.common.dto.validation.CdpDetectionErrorDto> detectionPartEntityForStream(com.seeyon.boot.transport.SingleRequest<com.seeyon.cdp.common.dto.validation.part.CdpDetectionEntityDto>);
    default com.seeyon.boot.transport.ListResponse<com.seeyon.cdp.common.dto.validation.CdpDetectionErrorDto> detectionPartModelForStream(com.seeyon.boot.transport.SingleRequest<com.seeyon.cdp.common.dto.validation.part.CdpDetectionModelRequestDto>);
    default com.seeyon.boot.transport.ListResponse<com.seeyon.cdp.common.dto.validation.CdpDetectionErrorDto> detectionPartModelForIndicator(com.seeyon.boot.transport.SingleRequest<com.seeyon.cdp.common.dto.validation.part.CdpDetectionModelRequestDto>);
    default com.seeyon.boot.transport.ListResponse<com.seeyon.cdp.common.dto.validation.CdpDetectionErrorDto> detectionPartModelForReport(com.seeyon.boot.transport.SingleRequest<com.seeyon.cdp.common.dto.validation.part.CdpDetectionModelRequestDto>);
    default com.seeyon.boot.transport.ListResponse<com.seeyon.cdp.common.dto.validation.CdpDetectionErrorDto> detectionPartIndicatorForTable(com.seeyon.boot.transport.SingleRequest<com.seeyon.cdp.common.dto.validation.part.CdpDetectionIndicatorRequestDto>);
    default com.seeyon.boot.transport.SingleResponse<java.lang.Integer> upgradeApps(com.seeyon.boot.transport.SingleRequest<java.util.List<java.util.Map>>);
    default com.seeyon.boot.transport.SingleResponse<java.lang.Boolean> cascadeHandleEntityForDataset(com.seeyon.boot.transport.SingleRequest<java.util.List<com.seeyon.cdp.common.dto.validation.part.CdpCascadeHandleEntityDto>>);
```

### `IndexStoreAppService`（5 方法）

`com.seeyon.cdp.index.api.IndexStoreAppService`

```java
    com.seeyon.boot.transport.SingleResponse<java.lang.Boolean> save(com.seeyon.boot.transport.SingleRequest<com.seeyon.cdp.index.dto.IndexStoreDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> updateIndexAuth(com.seeyon.boot.transport.SingleRequest<com.seeyon.cdp.index.dto.IndexUpdateAuthDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> delete(com.seeyon.boot.transport.SingleRequest<com.seeyon.cdp.index.dto.IndexDeleteDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Boolean> batchDelete(com.seeyon.boot.transport.SingleRequest<com.seeyon.cdp.index.dto.IndexDeleteDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Boolean> saveIndexBpmData(com.seeyon.boot.transport.SingleRequest<com.seeyon.cdp.index.dto.IndexBpmDataDto>);
```

### `IndexAppService`（4 方法）

`com.seeyon.cdp.index.api.IndexAppService`

```java
    com.seeyon.boot.transport.PageResponse<com.seeyon.cdp.index.dto.search.SearchResultDto> search(com.seeyon.boot.transport.PageDtoRequest<com.seeyon.cdp.index.dto.search.SearchConditionDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.cdp.index.dto.search.SuggestResultDto> suggest(com.seeyon.boot.transport.SingleRequest<com.seeyon.cdp.index.dto.search.SuggestConditionDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.cdp.index.dto.search.SearchHistoryDto> hotSearch(com.seeyon.boot.transport.SingleRequest<java.lang.Integer>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.cdp.index.dto.search.SearchHistoryDto> searchHistory(com.seeyon.boot.transport.SingleRequest<com.seeyon.cdp.index.dto.search.SearchHistoryConditionDto>);
```

### `ReportOpenApiAppService`（2 方法）

`com.seeyon.cdp.bi.api.ReportOpenApiAppService`

```java
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cdp.bi.dto.ReportDetailDto> getReportDetail(com.seeyon.boot.transport.SingleRequest<com.seeyon.cdp.bi.dto.ReportDetailRequestDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cdp.bi.dto.ReportResultDto> getReportResult(com.seeyon.boot.transport.SingleRequest<com.seeyon.cdp.bi.dto.ReportResultRequestDto>);
```

### `DatasetOpenApiAppService`（2 方法）

`com.seeyon.cdp.dataset.api.DatasetOpenApiAppService`

```java
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cdp.dataset.dto.DatasetModelDto> getDatasetModel(com.seeyon.boot.transport.SingleRequest<com.seeyon.cdp.dataset.dto.DatasetModelRequestDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cdp.common.dto.model.ModelExecuteResult> getDatasetResult(com.seeyon.boot.transport.SingleRequest<com.seeyon.cdp.dataset.dto.DatasetResultRequestDto>);
```

### `CdpEtlSourceAppService`（2 方法）

`com.seeyon.cdp.etl.api.CdpEtlSourceAppService`

```java
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cdp.etl.dto.CdpEtlSourceDto> getSource(com.seeyon.boot.transport.SingleRequest<com.seeyon.cdp.etl.dto.CdpEtlSourceParamsDto>);
    default com.seeyon.boot.transport.SingleResponse<com.seeyon.cdp.etl.dto.CdpEtlDatasetMetadataDto> getDatasetPublishMetadata(com.seeyon.boot.transport.SingleRequest<com.seeyon.cdp.etl.dto.CdpEtlDatasetMetadataRequest>);
```

### `IndicatorOpenApiAppService`（2 方法）

`com.seeyon.cdp.indicator.api.IndicatorOpenApiAppService`

```java
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cdp.indicator.dto.IndicatorModelDto> getIndicatorModel(com.seeyon.boot.transport.SingleRequest<com.seeyon.cdp.indicator.dto.IndicatorModelRequestDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cdp.common.dto.model.ModelExecuteResult> getIndicatorResult(com.seeyon.boot.transport.SingleRequest<com.seeyon.cdp.indicator.dto.IndicatorResultRequestDto>);
```

### `StreamOpenApiAppService`（2 方法）

`com.seeyon.cdp.stream.api.StreamOpenApiAppService`

```java
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cdp.stream.dto.StreamModelDto> getStreamModel(com.seeyon.boot.transport.SingleRequest<com.seeyon.cdp.stream.dto.StreamModelRequestDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cdp.common.dto.model.ModelExecuteResult> getStreamResult(com.seeyon.boot.transport.SingleRequest<com.seeyon.cdp.stream.dto.StreamResultRequestDto>);
```

### `CdpEtlRunAppService`（1 方法）

`com.seeyon.cdp.etl.api.CdpEtlRunAppService`

```java
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cdp.etl.dto.CdpEtlRunResultDto> jobSuccess(com.seeyon.boot.transport.SingleRequest<com.seeyon.cdp.etl.dto.CdpEtlRunDto>);
```

### `IndexParamsResetServiceSpi`（1 方法）

`com.seeyon.cdp.index.spi.IndexParamsResetServiceSpi`

```java
    com.seeyon.cdp.index.dto.search.SearchConditionDto paramsReset(com.seeyon.cdp.index.dto.search.SearchConditionDto);
```

## 四、枚举（12）

- `CdpMqDataType`（7 常量）：DETECTION_MODEL, DETECTION_INDICATOR, DETECTION_REPORT, INDEX_DATA_SAVE, INDEX_DATA_DELETE, INDEX_BPM_DATA_SAVE, INDEX_AUTH_UPDATE
- `TransportOutType`（2 常量）：TRANSPORT_COPY_OUT, TRANSPORT_DEPLOY_OUT
- `CdpBizType`（6 常量）：stream, table_sync, indicator, dataset, dataset_preview, stream_preview
- `CdpEtlSourceType`（4 常量）：entity_source, third_source, dw_source, cap_source
- `CkClusterType`（3 常量）：single_shard_multiple_replica, multiple_shard_single_replica, multiple_shard_multiple_replica
- `IndexDataType`（7 常量）：application, menu, portal, space, approval, report, doc
- `IndexDocFormat`（10 常量）：word, excel, ppt, html, pdf, ofd, picture, video, other, docLink
- `SearchField`（11 常量）：title, content, attachmentName, attachmentContent, attachmentSecretN, extendType, extendTerminal, extendDocFormat, opinions, extendEdocUnit, extendEdocType
- `SearchMode`（2 常量）：precise, participle
- `SearchScope`（4 常量）：title, content, attachment, opinion
- `SearchTimeScope`（7 常量）：all, week, month, quarter, half_a_year, year, custom
- `TerminalType`（2 常量）：pc, mobile
