# boot-starter-lock：接口与方法签名

> 自动生成，勿手改。`tools/core/platform/emit_package_surfaces.py` 重跑即可。
> 构件 `com.seeyon:boot-starter-lock`（jar `boot-starter-lock-5.3.600.jar`）
> 规模：9 类 / 0 接口 / 0 注解 / 0 枚举 / 1 个关键类 / 80 方法。
> 签名逐字来自 javap 原文；已去掉 `public` 前缀与 `throws` 子句。

## 一、接口（0）

（本构件没有接口）

## 二、关键类（1）

### `DistributedLockFactory`（6 方法）

`com.seeyon.boot.starter.lock.DistributedLockFactory`

```java
    java.util.concurrent.locks.Lock newLock(java.lang.String);
    java.util.concurrent.locks.Lock newLockIgnoreTenant(java.lang.String);
    java.util.concurrent.locks.Lock newLockIgnoreTenant(java.lang.String, java.lang.Long);
    java.util.concurrent.locks.Lock newLock(java.lang.String, java.lang.Long);
    private java.util.concurrent.locks.Lock newLock(java.lang.String, java.lang.Long, boolean);
    private java.util.concurrent.locks.Lock instanceLock(java.lang.String, java.lang.String, java.lang.Long, java.lang.String)
```
