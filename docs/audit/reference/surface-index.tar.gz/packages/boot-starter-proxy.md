# boot-starter-proxy：接口与方法签名

> 自动生成，勿手改。`tools/core/platform/emit_package_surfaces.py` 重跑即可。
> 构件 `com.seeyon:boot-starter-proxy`（jar `boot-starter-proxy-5.3.600.jar`）
> 规模：18 类 / 4 接口 / 0 注解 / 1 枚举 / 5 个关键类 / 115 方法。
> 签名逐字来自 javap 原文；已去掉 `public` 前缀与 `throws` 子句。

## 一、接口（4）

### `CustomerProxyAppService`（7 方法）

`com.seeyon.boot.starter.proxy.api.CustomerProxyAppService`

```java
    com.seeyon.boot.transport.SingleResponse<java.lang.Object> invokeAppService(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.dubbo.dto.AppServiceInvokeDto>);
    default com.seeyon.boot.transport.ListResponse<java.lang.Object> invokeAppServiceForList(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.dubbo.dto.AppServiceInvokeDto>);
    default com.seeyon.boot.transport.PageResponse<java.lang.Object> invokeAppServiceForPage(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.dubbo.dto.AppServiceInvokeDto>);
    <T> com.seeyon.boot.transport.SingleResponse reliableInvokeAppService(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.dubbo.dto.AppServiceReliableInvokeDto<T>>);
    default void schedulePendingServiceInvoke();
    default void scheduleCallbackProcessResult();
    default void scheduleRecoveryMisProcess();
```

### `ParamEscapeService`（2 方法）

`com.seeyon.boot.starter.proxy.api.ParamEscapeService`

```java
    default java.lang.String paramEscape(java.lang.String, java.lang.String, java.lang.String, java.util.Map<java.lang.String, java.lang.Object>);
    default void saveApiLog(com.seeyon.boot.starter.dubbo.dto.AppServiceAsyncInvokeDto, java.lang.Object);
```

### `ProxyInvokeInfoDao`（0 方法） extends ProxyInvokeInfo>

`com.seeyon.boot.starter.proxy.domain.dao.ProxyInvokeInfoDao`

```java
```

### `ReliableInvokeInfoDao`（0 方法） extends ReliableInvokeInfo>

`com.seeyon.boot.starter.proxy.domain.dao.ReliableInvokeInfoDao`

```java
```

## 二、关键类（5）

### `CtpCustomerProxyAppServiceImpl`（22 方法）

`com.seeyon.boot.starter.proxy.appservice.CtpCustomerProxyAppServiceImpl`

```java
    com.seeyon.boot.transport.SingleResponse<java.lang.Object> invokeAppService(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.dubbo.dto.AppServiceInvokeDto>);
    com.seeyon.boot.transport.ListResponse<java.lang.Object> invokeAppServiceForList(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.dubbo.dto.AppServiceInvokeDto>);
    com.seeyon.boot.transport.PageResponse<java.lang.Object> invokeAppServiceForPage(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.dubbo.dto.AppServiceInvokeDto>);
    private com.seeyon.boot.transport.BaseResponse asyncInvokeAppService(com.seeyon.boot.starter.dubbo.dto.AppServiceAsyncInvokeDto, java.lang.Class);
    private java.lang.String processBeforeReturn(com.seeyon.boot.starter.dubbo.dto.AppServiceAsyncInvokeDto, java.lang.Object);
    <T> com.seeyon.boot.transport.SingleResponse reliableInvokeAppService(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.dubbo.dto.AppServiceReliableInvokeDto<T>>);
    private com.seeyon.boot.transport.BaseResponse processServiceInvoke(com.seeyon.boot.starter.dubbo.dto.AppServiceInvokeDto);
    private com.seeyon.boot.transport.SingleResponse<java.lang.Object> wrapResponse(java.lang.Object, boolean);
    void schedulePendingServiceInvoke();
    void doServiceInvoke(java.lang.Long);
    private void processOpenInvoke(com.seeyon.boot.starter.proxy.domain.entity.ProxyInvokeInfo);
    void scheduleCallbackProcessResult();
    void feedbackResult(java.lang.Long);
    void scheduleRecoveryMisProcess();
    private void recoveryMisProcessTask();
    private java.util.List<com.seeyon.boot.starter.proxy.domain.entity.ProxyInvokeInfo> selectPendingList();
    private java.util.List<com.seeyon.boot.starter.proxy.domain.entity.ProxyInvokeInfo> selectPendingCallbackList();
    private java.util.List<com.seeyon.boot.starter.proxy.domain.entity.ProxyInvokeInfo> selectRecoveryList();
```

### `AppServiceReliableInvoker`（15 方法）

`com.seeyon.boot.starter.proxy.appservice.AppServiceReliableInvoker`

```java
    com.seeyon.boot.transport.SingleResponse<java.lang.Object> invoke(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.dubbo.dto.AppServiceInvokeDto>, java.lang.String);
    com.seeyon.boot.transport.SingleResponse<java.lang.Object> invoke(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.dubbo.dto.AppServiceInvokeDto>, java.lang.String, java.lang.Integer);
    com.seeyon.boot.transport.ListResponse<java.lang.Object> invokeForList(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.dubbo.dto.AppServiceInvokeDto>, java.lang.String);
    com.seeyon.boot.transport.ListResponse<java.lang.Object> invokeForList(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.dubbo.dto.AppServiceInvokeDto>, java.lang.String, java.lang.Integer);
    com.seeyon.boot.transport.PageResponse<java.lang.Object> invokeForPage(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.dubbo.dto.AppServiceInvokeDto>, java.lang.String);
    com.seeyon.boot.transport.PageResponse<java.lang.Object> invokeForPage(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.dubbo.dto.AppServiceInvokeDto>, java.lang.String, java.lang.Integer);
    <T> com.seeyon.boot.transport.SingleResponse reliableInvoke(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.dubbo.dto.AppServiceReliableInvokeDto<T>>, java.lang.String);
    private <T> void doInvoke(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.dubbo.dto.AppServiceReliableInvokeDto<T>>, java.lang.String, com.seeyon.boot.starter.proxy.domain.entity.ReliableInvokeInfo);
    private com.seeyon.boot.starter.dubbo.api.AppServiceProxy getProxy(java.lang.String, java.lang.Integer);
    private boolean processServiceReliableInvoke(com.seeyon.boot.starter.dubbo.dto.AppServiceReliableInvokeDto, java.lang.String);
    void scheduleProcessServiceInvoke();
    private void scheduleTask();
    private void compensateReliableInvoke(java.util.List<com.seeyon.boot.starter.proxy.domain.entity.ReliableInvokeInfo>);
```

### `ReliableInvokeInfoService`（6 方法）

`com.seeyon.boot.starter.proxy.domain.service.ReliableInvokeInfoService`

```java
    long create(com.seeyon.boot.starter.proxy.domain.entity.ReliableInvokeInfo);
    void update(com.seeyon.boot.starter.proxy.domain.entity.ReliableInvokeInfo);
    java.util.List<com.seeyon.boot.starter.proxy.domain.entity.ReliableInvokeInfo> selectByConditions(java.util.Map, int);
    void updateStatusById(java.lang.Long, com.seeyon.boot.starter.proxy.enums.InvokeStatusEnum);
    void deleteById(java.lang.Long);
    void deleteRubbishJob();
```

### `AppServiceProxyApiImpl`（5 方法）

`com.seeyon.boot.starter.proxy.appservice.AppServiceProxyApiImpl`

```java
    com.seeyon.boot.transport.SingleResponse<java.lang.Object> invokeAppService(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.dubbo.dto.AppServiceInvokeDto>);
    com.seeyon.boot.transport.ListResponse<java.lang.Object> invokeAppServiceForList(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.dubbo.dto.AppServiceInvokeDto>);
    com.seeyon.boot.transport.PageResponse<java.lang.Object> invokeAppServiceForPage(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.dubbo.dto.AppServiceInvokeDto>);
    <T> com.seeyon.boot.transport.SingleResponse reliableInvokeAppService(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.dubbo.dto.AppServiceReliableInvokeDto<T>>);
    private void loadDynamicModuleIfNecessary(java.lang.String, java.lang.String);
```

### `ProxyInvokeInfoService`（5 方法）

`com.seeyon.boot.starter.proxy.domain.service.ProxyInvokeInfoService`

```java
    com.seeyon.boot.starter.proxy.domain.entity.ProxyInvokeInfo selectById(java.lang.Long);
    void deleteById(java.lang.Long);
    void update(com.seeyon.boot.starter.proxy.domain.entity.ProxyInvokeInfo);
    com.seeyon.boot.transport.PageData<com.seeyon.boot.starter.proxy.domain.entity.ProxyInvokeInfo> selectPageByConditions(com.seeyon.boot.transport.PageInfo, java.util.Map);
    com.seeyon.boot.starter.proxy.domain.entity.ProxyInvokeInfo saveProxyInvokeInfo(com.seeyon.boot.starter.dubbo.dto.AppServiceAsyncInvokeDto);
```

## 四、枚举（1）

- `InvokeStatusEnum`（6 常量）：FAILURE, SUCCESS, PENDING, PROCESSING, PENDING_FEEDBACK, FEEDBACKING
