# udc-web：接口与方法签名

> 自动生成，勿手改。`tools/core/platform/emit_package_surfaces.py` 重跑即可。
> 构件 `com.seeyon:udc-web`（jar `udc-web-5.3.517.jar`）
> 规模：54 类 / 0 接口 / 0 注解 / 0 枚举 / 6 个关键类 / 691 方法。
> 签名逐字来自 javap 原文；已去掉 `public` 前缀与 `throws` 子句。

## 一、接口（0）

（本构件没有接口）

## 二、关键类（6）

### `PageTemplateController`（14 方法）

`com.seeyon.udc.controller.PageTemplateController`

```java
    com.seeyon.boot.transport.SingleResponse<java.lang.Long> batchCreate(java.util.List<com.seeyon.udc.page.dto.PageTemplateDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Long> createOrUpdate(com.seeyon.udc.page.dto.PageTemplateDto);
    com.seeyon.boot.transport.SingleResponse<java.lang.Long> saveAs(com.seeyon.udc.page.dto.PageTemplateDto);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> deleteById(java.lang.Long);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> deleteById(java.util.List<java.lang.Long>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.udc.page.dto.PageTemplateDto> selectById(java.lang.Long);
    com.seeyon.boot.transport.ListResponse<com.seeyon.udc.page.dto.PageTemplateDto> selectDetailById(java.lang.Long);
    com.seeyon.boot.transport.ListResponse<com.seeyon.udc.page.dto.PageTemplateDto> selectAllListByConditions(java.util.Map<java.lang.String, java.lang.Object>, com.seeyon.boot.transport.Sort);
    com.seeyon.boot.transport.PageResponse<com.seeyon.udc.page.dto.PageTemplateDto> selectListByConditions(com.seeyon.boot.transport.PageInfo, java.util.Map<java.lang.String, java.lang.Object>, com.seeyon.boot.transport.Sort);
    com.seeyon.boot.transport.PageResponse<com.seeyon.udc.page.dto.PageTemplateDto> selectListByConditionsWithRights(com.seeyon.boot.transport.PageInfo, java.util.Map<java.lang.String, java.lang.Object>, com.seeyon.boot.transport.Sort);
    com.seeyon.boot.transport.PageResponse<com.seeyon.udc.page.dto.PageTemplateDto> selectAvailableListByConditions(com.seeyon.boot.transport.PageInfo, java.util.Map<java.lang.String, java.lang.Object>, com.seeyon.boot.transport.Sort);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.udc.page.dto.PageTemplateExportDto> exportPreset(java.util.List<java.lang.Long>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Void> publish(com.seeyon.udc.page.dto.PageTemplateDto);
    com.seeyon.boot.transport.SingleResponse<java.lang.Boolean> checkName(java.util.List<com.seeyon.udc.page.dto.PageTemplateDto>);
```

### `UdcManagerController`（14 方法）

`com.seeyon.udc.controller.UdcManagerController`

```java
    com.seeyon.boot.transport.SingleResponse<java.lang.String> explain(java.lang.String);
    com.seeyon.boot.transport.SingleResponse clearTimeout(java.lang.String);
    com.seeyon.boot.transport.SingleResponse clearForce(java.lang.String);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.udc.common.concurrent.RequestStatusDto> getRequestStatus(java.lang.String);
    private com.seeyon.udc.common.concurrent.TaskRateLimiter getTaskRateLimiter(java.lang.String);
    com.seeyon.boot.transport.ListResponse<java.lang.String> getLogs(java.lang.String);
    com.seeyon.boot.transport.ListResponse<com.seeyon.udc.system.dto.ComponentLogDto> getComponentLogs(com.seeyon.udc.system.dto.ComponentLogSearchDto);
    com.seeyon.boot.transport.SingleResponse<java.lang.Boolean> enableAppLogConfig(java.lang.String, java.lang.Long);
    com.seeyon.boot.transport.SingleResponse<java.lang.Boolean> resetAppLogConfig(java.lang.String, java.lang.Long);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.udc.common.dto.AppLogConfigDto> getAppLogConfig(java.lang.String);
    com.seeyon.boot.transport.SingleResponse<java.lang.Boolean> resetAppDataLogConfig(java.lang.Integer);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> getAppDataLogConfig();
    com.seeyon.boot.transport.PageResponse<com.seeyon.udc.config.dto.ServiceInfoDto> selectPageByConditions(com.seeyon.boot.transport.PageRequest);
    com.seeyon.boot.transport.PageResponse<com.seeyon.udc.config.dto.ServiceInfoDto> selectSubAppPageByConditions(com.seeyon.boot.transport.PageRequest);
```

### `ReferConfigController`（12 方法）

`com.seeyon.udc.controller.ReferConfigController`

```java
    com.seeyon.boot.transport.SingleResponse<java.lang.Long> create(com.seeyon.udc.dto.ReferConfigDto);
    com.seeyon.boot.transport.SingleResponse<java.lang.Long> createOrUpdate(com.seeyon.udc.dto.ReferConfigDto);
    com.seeyon.boot.transport.SingleResponse<java.lang.Long> createConfigInfo(com.seeyon.udc.dto.ReferConfigInfoDto);
    com.seeyon.boot.transport.SingleResponse<java.lang.Long> convertToMobile(java.lang.Long);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> updateConfigInfo(com.seeyon.udc.dto.ReferConfigInfoDto);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> update(com.seeyon.udc.dto.ReferConfigDto);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> deleteById(java.lang.Long);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> deleteByGroupId(java.lang.Long);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.udc.dto.ReferConfigDto> selectById(java.lang.Long);
    com.seeyon.boot.transport.PageResponse<com.seeyon.udc.dto.ReferConfigDto> selectPageByCondition(com.seeyon.boot.transport.PageInfo, java.util.Map<java.lang.String, java.lang.Object>, com.seeyon.boot.transport.Sort);
    com.seeyon.boot.transport.ListResponse<com.seeyon.udc.dto.ReferConfigDto> selectListByConditions(java.util.Map<java.lang.String, java.lang.Object>, com.seeyon.boot.transport.Sort);
    com.seeyon.boot.transport.ListResponse<com.seeyon.udc.dto.ReferConfigGroupDto> selectGroupListByConditions(java.util.Map<java.lang.String, java.lang.Object>, com.seeyon.boot.transport.Sort);
```

### `PageTemplatePublishedController`（9 方法）

`com.seeyon.udc.controller.PageTemplatePublishedController`

```java
    com.seeyon.boot.transport.SingleResponse<java.lang.Long> createOrUpdate(com.seeyon.udc.page.dto.PageTemplatePublishedDto);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> deleteById(java.lang.Long);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> deleteById(java.util.List<java.lang.Long>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.udc.page.dto.PageTemplatePublishedDto> selectById(java.lang.Long);
    com.seeyon.boot.transport.PageResponse<com.seeyon.udc.page.dto.PageTemplatePublishedDto> selectAvailableListByConditions(com.seeyon.boot.transport.PageInfo, java.util.Map<java.lang.String, java.lang.Object>, com.seeyon.boot.transport.Sort);
    com.seeyon.boot.transport.ListResponse<com.seeyon.udc.page.dto.PageTemplatePublishedDto> selectAllListByConditions(java.util.Map<java.lang.String, java.lang.Object>, com.seeyon.boot.transport.Sort);
    com.seeyon.boot.transport.PageResponse<com.seeyon.udc.page.dto.PageTemplatePublishedDto> selectListByConditions(com.seeyon.boot.transport.PageInfo, java.util.Map<java.lang.String, java.lang.Object>, com.seeyon.boot.transport.Sort);
    com.seeyon.boot.transport.SingleResponse<java.lang.Boolean> checkName(java.util.List<com.seeyon.udc.page.dto.PageTemplatePublishedDto>);
    com.seeyon.boot.transport.SingleResponse<java.util.Map> selectPageTemplatePublishedToPresetJson(java.util.Map<java.lang.String, java.lang.Object>);
```

### `AttachmentTemplateController`（7 方法）

`com.seeyon.udc.controller.AttachmentTemplateController`

```java
    com.seeyon.boot.transport.SingleResponse<com.seeyon.udc.attachment.dto.AttachmentTemplateDto> create(com.seeyon.udc.attachment.dto.AttachmentTemplateDto);
    com.seeyon.boot.transport.ListResponse<com.seeyon.udc.attachment.dto.AttachmentTemplateDto> createBatch(java.util.List<com.seeyon.udc.attachment.dto.AttachmentTemplateDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.udc.common.dto.CommonFileDto> selectByGuid(java.lang.Long);
    com.seeyon.boot.transport.ListResponse<com.seeyon.udc.common.dto.CommonFileDto> selectByGuids(java.util.List<java.lang.Long>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.udc.common.dto.CommonFileDto> selectByAppId(java.lang.Long);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> delete(java.lang.Long);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> delete(java.util.List<java.lang.Long>);
```

### `PageTemplateClassController`（7 方法）

`com.seeyon.udc.controller.PageTemplateClassController`

```java
    com.seeyon.boot.transport.SingleResponse<java.lang.Long> create(com.seeyon.udc.page.dto.PageTemplateCategoryDto);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> delete(java.lang.Long);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> update(com.seeyon.udc.page.dto.PageTemplateCategoryDto);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.udc.page.dto.PageTemplateCategoryDto> select(java.lang.Long);
    com.seeyon.boot.transport.ListResponse<com.seeyon.udc.page.dto.PageTemplateCategoryDto> selectAllListByConditions(java.util.Map<java.lang.String, java.lang.Object>, com.seeyon.boot.transport.Sort);
    com.seeyon.boot.transport.ListResponse<com.seeyon.udc.page.dto.PageTemplateCategoryDto> selectClassTree();
    com.seeyon.boot.transport.ListResponse<com.seeyon.udc.page.dto.PageTemplateCategoryDto> selectClassTreeByCategory(com.seeyon.udc.page.enums.PageTemplateCategory);
```
