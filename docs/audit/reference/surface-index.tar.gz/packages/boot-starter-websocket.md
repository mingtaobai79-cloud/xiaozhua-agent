# boot-starter-websocket：接口与方法签名

> 自动生成，勿手改。`tools/core/platform/emit_package_surfaces.py` 重跑即可。
> 构件 `com.seeyon:boot-starter-websocket`（jar `boot-starter-websocket-5.3.600.jar`）
> 规模：8 类 / 2 接口 / 0 注解 / 0 枚举 / 0 个关键类 / 23 方法。
> 签名逐字来自 javap 原文；已去掉 `public` 前缀与 `throws` 子句。

## 一、接口（2）

### `ReceiveProcessService`（1 方法）

`com.seeyon.boot.starter.websocket.api.ReceiveProcessService`

```java
    void receiveMessage(com.seeyon.boot.starter.websocket.message.TextMessage);
```

### `Constants`（0 方法）

`com.seeyon.boot.starter.websocket.common.Constants`

```java
```
