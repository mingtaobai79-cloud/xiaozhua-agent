# cip-connector-facade：接口与方法签名

> 自动生成，勿手改。`tools/core/platform/emit_package_surfaces.py` 重跑即可。
> 构件 `com.seeyon:cip-connector-facade`（jar `cip-connector-facade-5.3.286.jar`）
> 规模：121 类 / 15 接口 / 0 注解 / 26 枚举 / 0 个关键类 / 1165 方法。
> 签名逐字来自 javap 原文；已去掉 `public` 前缀与 `throws` 子句。

## 一、接口（15）

### `MappingDetailAppService`（12 方法）

`com.seeyon.cip.application.api.MappingDetailAppService`

```java
    default com.seeyon.boot.transport.SingleResponse<java.lang.Long> addOrgMappingDetail(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.application.dto.mappingconfig.OrgMappingDetailAddReqDto>);
    default com.seeyon.boot.transport.SingleResponse<java.lang.Void> modifyOrgMappingDetail(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.application.dto.mappingconfig.OrgMappingDetailUpdateReqDto>);
    default com.seeyon.boot.transport.SingleResponse<java.lang.Long> addUserMappingDetail(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.application.dto.mappingconfig.UserMappingDetailAddReqDto>);
    default com.seeyon.boot.transport.SingleResponse<java.lang.Void> modifyUserMappingDetail(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.application.dto.mappingconfig.UserMappingDetailUpdateReqDto>);
    default com.seeyon.boot.transport.PageResponse<com.seeyon.cip.application.dto.mappingconfig.UserMappingDetailResDto> queryUserMappingDetail(com.seeyon.boot.transport.PageRequest);
    default com.seeyon.boot.transport.PageResponse<com.seeyon.cip.application.dto.mappingconfig.OrgMappingDetailResDto> queryOrgMappingDetail(com.seeyon.boot.transport.PageRequest);
    default com.seeyon.boot.transport.SingleResponse<java.lang.Void> deleteOrgMappingDetail(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.application.dto.mappingconfig.OrgMappingDetailDeleteReqDto>);
    default com.seeyon.boot.transport.SingleResponse<java.lang.Void> deleteUserMappingDetail(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.application.dto.mappingconfig.UserMappingDetailDeleteReqDto>);
    default com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.application.dto.mappingconfig.OrgInnerIdResDto> getOrgInnerIdByOuterId(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.application.dto.mappingconfig.OrgInnerIdReqDto>);
    default com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.application.dto.mappingconfig.OrgOuterIdResDto> getOrgOuterIdByInnerId(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.application.dto.mappingconfig.OrgOuterIdReqDto>);
    default com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.application.dto.mappingconfig.UserInnerIdResDto> getUserInnerIdByOuterId(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.application.dto.mappingconfig.UserInnerIdReqDto>);
    default com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.application.dto.mappingconfig.UserOuterIdResDto> getUserOuterIdByInnerId(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.application.dto.mappingconfig.UserOuterIdReqDto>);
```

### `MiddleTableAppService`（12 方法）

`com.seeyon.cip.application.api.MiddleTableAppService`

```java
    default com.seeyon.boot.transport.SingleResponse<java.lang.Void> saveUnit(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.application.dto.middletable.UnitInfoReqDto>);
    default com.seeyon.boot.transport.SingleResponse<java.lang.Void> saveLevel(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.application.dto.middletable.LevelInfoReqDto>);
    default com.seeyon.boot.transport.SingleResponse<java.lang.Void> savePost(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.application.dto.middletable.PostInfoReqDto>);
    default com.seeyon.boot.transport.SingleResponse<java.lang.Void> saveDuty(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.application.dto.middletable.DutyInfoReqDto>);
    default com.seeyon.boot.transport.SingleResponse<java.lang.Void> saveMember(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.application.dto.middletable.MemberInfoReqDto>);
    default com.seeyon.boot.transport.SingleResponse<java.lang.String> fullFinish(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    default com.seeyon.boot.transport.PageResponse<com.seeyon.cip.application.dto.middletable.UnitInfoDto> queryUnit(com.seeyon.boot.transport.PageRequest);
    default com.seeyon.boot.transport.PageResponse<com.seeyon.cip.application.dto.middletable.LevelInfoDto> queryLevel(com.seeyon.boot.transport.PageRequest);
    default com.seeyon.boot.transport.PageResponse<com.seeyon.cip.application.dto.middletable.PostInfoDto> queryPost(com.seeyon.boot.transport.PageRequest);
    default com.seeyon.boot.transport.PageResponse<com.seeyon.cip.application.dto.middletable.MemberInfoDto> queryMember(com.seeyon.boot.transport.PageRequest);
    default com.seeyon.boot.transport.SingleResponse<java.lang.Void> delete(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.application.dto.middletable.MiddleTableDeleteReqDto>);
    default com.seeyon.boot.transport.SingleResponse<java.lang.Void> runningOrgSyncNowByLinkerCode(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.application.dto.middletable.RunningOrgSyncNowDto>);
```

### `LinkerAppService`（12 方法）

`com.seeyon.cip.connector.api.core.LinkerAppService`

```java
    com.seeyon.boot.transport.PageResponse<com.seeyon.cip.connector.dto.info.LinkerInfoDto> selectPageByCondition(com.seeyon.boot.transport.PageRequest);
    com.seeyon.boot.transport.ListResponse<com.seeyon.cip.connector.dto.info.LinkerInfoDto> selectAll();
    com.seeyon.boot.transport.ListResponse<com.seeyon.cip.connector.dto.info.LinkerDetailDto> selectDetailsByInfoId(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.cip.connector.dto.info.LinkerParameterDisplayDto> selectLinkerDetailParameterDisplay(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.cip.connector.dto.info.LinkerEventDetailDto> selectEventDetailsByInfoId(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.connector.dto.info.LinkerEventDetailDto> selectEventDetailById(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.PageResponse<com.seeyon.cip.connector.dto.info.LinkerDetailDto> selectPageDetailByCondition(com.seeyon.boot.transport.PageRequest);
    com.seeyon.boot.transport.PageResponse<com.seeyon.cip.connector.dto.info.LinkerEventDetailDto> selectPageEventDetailByCondition(com.seeyon.boot.transport.PageRequest);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.connector.dto.info.LinkerDetailDto> selectDetailById(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.connector.dto.execute.ExecuteResponseDto> execute(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.connector.dto.execute.ExecuteRequestDto>);
    default com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.connector.dto.execute.MqCustomSendResultDto> mqCustomSend(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.connector.dto.execute.MqCustomSendDto>);
    default com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.connector.dto.execute.SqlResultDto> executeSql(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.connector.dto.execute.ExecuteSqlDto>);
```

### `BaseConfigAppService`（11 方法）

`com.seeyon.cip.connector.api.core.BaseConfigAppService`

```java
    com.seeyon.boot.transport.SingleResponse<java.lang.Long> createDatabase(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.connector.dto.database.DatabaseInfoDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> updateDatabase(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.connector.dto.database.DatabaseInfoDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> deleteDatabaseById(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.connector.dto.database.DatabaseInfoDto> selectDatabaseById(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.cip.connector.dto.database.DatabaseInfoDto> selectDatabaseByIds(com.seeyon.boot.transport.SingleRequest<java.util.List<java.lang.Long>>);
    com.seeyon.boot.transport.PageResponse<com.seeyon.cip.connector.dto.database.DatabaseInfoDto> selectPageDatabaseByCondition(com.seeyon.boot.transport.PageRequest);
    com.seeyon.boot.transport.SingleResponse<java.lang.String> connectorDatabase(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.connector.dto.database.DatabaseInfoDto>);
    com.seeyon.boot.transport.ListResponse<java.lang.String> selectAllDatabaseType();
    com.seeyon.boot.transport.SingleResponse<java.util.Map<java.lang.String, java.util.List<com.seeyon.cip.connector.dto.database.TableInfoDto>>> selectAllTableInfo(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.ListResponse<java.lang.String> selectAllTableNameById(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.cip.connector.dto.database.TableInfoDto> selectTableInfo(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.connector.dto.database.TableInfoDto>);
```

### `ApplicationAffairAppService`（8 方法）

`com.seeyon.cip.application.api.ApplicationAffairAppService`

```java
    default com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.application.dto.PluginAffairResultDto> addModifyPluginAffair(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.application.dto.PluginAffairBatchDto>);
    default com.seeyon.boot.transport.SingleResponse<java.lang.Void> processRevoke(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.application.dto.PluginAffairGroupDto>);
    default com.seeyon.boot.transport.SingleResponse<java.lang.Void> processTerminate(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.application.dto.PluginAffairGroupDto>);
    default com.seeyon.boot.transport.SingleResponse<java.lang.String> queryExternalIdByAffair(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    default com.seeyon.boot.transport.ListResponse<com.seeyon.cip.application.dto.AffairIdMappingResultDto> listExternalIdsByAffairIds(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.application.dto.AffairIdMappingQueryDto>);
    default com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.application.dto.AffairDisplayDto> queryAffairByExternalId(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.application.dto.AffairQueryDto>);
    default com.seeyon.boot.transport.SingleResponse<java.lang.Void> retryPushAffair(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.application.dto.RetryPushAffairOpenApiDto>);
    default com.seeyon.boot.transport.ListResponse<com.seeyon.cip.application.dto.AffairDisplayDto> queryAffairListByExternalIdList(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.application.dto.AffairBatchQueryDto>);
```

### `LinkerMigrationAppService`（4 方法）

`com.seeyon.cip.connector.api.core.LinkerMigrationAppService`

```java
    com.seeyon.boot.transport.SingleResponse<java.lang.String> exportEntityTask(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.connector.dto.info.LinkMigrationRequestDto>);
    com.seeyon.boot.transport.SingleResponse<java.util.Map<java.lang.String, java.lang.String>> initDataJsonByNames(com.seeyon.boot.transport.SingleRequest<java.util.List<java.lang.String>>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.cip.connector.dto.migrate.ConnectorMigrateDto> listConnectorData(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.connector.dto.migrate.ConnectorMigrateRequestDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Void> importConnectorData(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.connector.dto.migrate.ConnectorMigrateImportResponseDto>);
```

### `ApplicationMobileAppService`（2 方法）

`com.seeyon.cip.application.api.ApplicationMobileAppService`

```java
    default com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.application.dto.AppUrlResponseDto> getAppUrl(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.application.dto.AppUrlRequestDto>);
    default com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.application.dto.mobile.RecallMsgResultDto> recallMessage(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.application.dto.mobile.RecallMsgDto>);
```

### `ApplicationPluginStatusAppService`（2 方法）

`com.seeyon.cip.application.api.ApplicationPluginStatusAppService`

```java
    com.seeyon.boot.transport.ListResponse<com.seeyon.cip.application.dto.PlugStatusDto> selectStatusByPlugIds(com.seeyon.boot.transport.SingleRequest<java.util.List<java.lang.Long>>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.cip.application.dto.PlugStatusDto> selectStatusByLinkerIds(com.seeyon.boot.transport.SingleRequest<java.util.List<java.lang.Long>>);
```

### `WarningManageAppService`（2 方法）

`com.seeyon.cip.application.api.WarningManageAppService`

```java
    default com.seeyon.boot.transport.SingleResponse<java.lang.Long> addWarningInfo(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.application.dto.CipWarningInfoDto>);
    default com.seeyon.boot.transport.SingleResponse<java.lang.Void> modifyWarningInfo(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.application.dto.CipWarningInfoDto>);
```

### `ApplicationMessageAppService`（1 方法）

`com.seeyon.cip.application.api.ApplicationMessageAppService`

```java
    default com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.application.dto.PluginMessageResultDto> syncPluginMessage(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.application.dto.PluginMessageBatchDto>);
```

### `WarningCallBackAppService`（1 方法）

`com.seeyon.cip.application.api.WarningCallBackAppService`

```java
    default com.seeyon.boot.transport.SingleResponse<java.lang.Void> redoWarning(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.application.dto.CipWarningInfoDto>);
```

### `LinkerEnumAppService`（1 方法）

`com.seeyon.cip.connector.api.core.LinkerEnumAppService`

```java
    com.seeyon.boot.transport.ListResponse<com.seeyon.cip.connector.dto.info.LinkerEnumItemDto> selectItemList(com.seeyon.boot.transport.ListRequest);
```

### `SsoExecutorAppService`（1 方法）

`com.seeyon.cip.connector.api.core.SsoExecutorAppService`

```java
    com.seeyon.boot.transport.SingleResponse<java.lang.String> ssoLongin(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.connector.dto.sso.SsoRequestDto>);
```

### `CipPlugCapabilityAppService`（1 方法）

`com.seeyon.cip.plug.api.CipPlugCapabilityAppService`

```java
    default com.seeyon.boot.transport.ListResponse<com.seeyon.cip.plug.dto.CipPluginCapabilityInfoDto> getAndCheckCapability(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.plug.dto.CapabilityInfoQueryDto>);
```

### `MobileAppService`（0 方法）

`com.seeyon.cip.application.api.MobileAppService`

```java
```

## 四、枚举（26）

- `ActionResultTypeEnum`（2 常量）：SUCCESS, FAIL
- `AffairActionEnum`（3 常量）：START, OTHER, MODIFY_AGENT
- `AffairResultEnum`（4 常量）：ADD, MODIFY, IGNORE, ERR
- `ApplicationTypeEnum`（2 常量）：InCip, OutCip
- `GenderEnum`（4 常量）：NONE, MALE, FEMALE, UN_KNOW
- `MemberTypeEnum`（2 常量）：MEMBER, OUTSIDE_MEMBER
- `MiddleTableCategoryEnum`（3 常量）：NONE, BENCH_MARK, SELF_BUILT
- `MiddleTableDimensionEnum`（5 常量）：UNIT, LEVEVL, POSITION, MEMBER, STAFF_DUTY
- `MiddleTableUnitTypeEnum`（5 常量）：INSTITUTION, DEPARTMENT, OUTSIDE_INSTITUTION, OUTSIDE_DEPARTMENT, LOCAL
- `ScopeTypeEnum`（6 常量）：NONE, INSTITUTION, INSTITUTIONS, ONLY_CHILDREN, SPECIFY_INSTITUTION, SPECIFY_INSTITUTIONS
- `UserIdTypeEnum`（5 常量）：OUTER_ID, V8_ID, V8_CODE, V8_LOGIN_NAME, V8_PHONE
- `DatabaseUseRangeEnum`（2 常量）：ONLY_CURRENT, INCLUDE_SUBORDINATE
- `DbStatementType`（4 常量）：SELECT, UPDATE, DELETE, INSERT
- `ImportFileTypeEnum`（5 常量）：SWAGGER, EXCLUSIVE, POSTMAN, EXCLUSIVE_FULL, EXCLUSIVE_FULL_ORIGINAL
- `RequestTypeEnum`（4 常量）：POST, PUT, GET, DELETE
- `SourceEnum`（3 常量）：CUSTOM, MALL, INTERNAL
- `SsoClientTypeEnum`（2 常量）：PC, PHONE
- `StatusEnum`（3 常量）：OPEN, STOP, DELETE
- `TypeEnum`（3 常量）：REST, SOAP, DATABASE
- `UserMappingTypeEnum`（3 常量）：MAPPING, PHONE, EMAIL
- `VerifyFailProcessorTypeEnum`（3 常量）：IGNORE, LOG, THROW_EXCEPTION
- `DataSyncMethodEnum`（6 常量）：CONNECTOR, LDAP, EVENT, MQ, OPEN_API, MIDDLE_TABLE
- `PluginCapabilityStatusEnum`（2 常量）：ONLINE, OFFLINE
- `PluginCapabilityTypeEnum`（4 常量）：ORG_SYNC, AFFAIR, MESSAGE, THIRD_DATA
- `PluginDataDirectionEnum`（5 常量）：DOWNLOAD, UPLOAD, EVENT_PULL, MQ_SUBSCRIBE, OPENAPI_PUSH
- `TodoDirectionEnum`（3 常量）：toA9, toThird, toNull
