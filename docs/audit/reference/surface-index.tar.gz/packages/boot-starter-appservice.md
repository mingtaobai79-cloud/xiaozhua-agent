# boot-starter-appservice：接口与方法签名

> 自动生成，勿手改。`tools/core/platform/emit_package_surfaces.py` 重跑即可。
> 构件 `com.seeyon:boot-starter-appservice`（jar `boot-starter-appservice-5.3.600.jar`）
> 规模：41 类 / 3 接口 / 1 注解 / 1 枚举 / 13 个关键类 / 196 方法。
> 签名逐字来自 javap 原文；已去掉 `public` 前缀与 `throws` 子句。

## 一、接口（3）

### `ExceptionHandler`（1 方法） extends Throwable>

`com.seeyon.boot.starter.appservice.ex.ExceptionHandler`

```java
    void handle(com.seeyon.boot.starter.appservice.ex.ExceptionContext<?>, EX);
```

### `DBExceptionParser`（1 方法）

`com.seeyon.boot.starter.appservice.ex.parser.DBExceptionParser`

```java
    com.seeyon.boot.exception.BusinessException parser(java.lang.String);
```

### `IdempotentInfoDao`（0 方法） extends CtpIdempotent>

`com.seeyon.boot.starter.appservice.domain.dao.IdempotentInfoDao`

```java
```

## 二、关键类（13）

### `AppServiceContext`（20 方法）

`com.seeyon.boot.starter.appservice.AppServiceContext`

```java
    java.lang.String getLoggerMethodName();
    java.lang.String getMethodClassSimpleName();
    org.aopalliance.intercept.MethodInvocation getMethodInvocation();
    java.lang.Object getTarget();
    java.lang.Object getResult();
    java.lang.Throwable getTargetThrowable();
    java.util.Set<java.lang.String> getPlugins();
    boolean isModuleAppService();
    net.sf.cglib.proxy.MethodProxy getMethodProxy();
    void setMethodInvocation(org.aopalliance.intercept.MethodInvocation);
    void setTarget(java.lang.Object);
    void setResult(java.lang.Object);
    void setTargetThrowable(java.lang.Throwable);
    void setPlugins(java.util.Set<java.lang.String>);
    void setModuleAppService(boolean);
    void setMethodProxy(net.sf.cglib.proxy.MethodProxy);
    boolean equals(java.lang.Object);
    protected boolean canEqual(java.lang.Object);
    int hashCode();
    java.lang.String toString();
```

### `AppServiceProperties`（18 方法）

`com.seeyon.boot.starter.appservice.AppServiceProperties`

```java
    java.lang.String getExceptionHandlerScanPackage();
    boolean isEnable();
    boolean isLogEnable();
    boolean isLogTransaction();
    java.lang.String getAppScanPackage();
    java.util.Map<java.lang.String, java.lang.String> getScanPackages();
    java.lang.String getParameterCheckFilter();
    void setEnable(boolean);
    void setLogEnable(boolean);
    void setLogTransaction(boolean);
    void setAppScanPackage(java.lang.String);
    void setScanPackages(java.util.Map<java.lang.String, java.lang.String>);
    void setParameterCheckFilter(java.lang.String);
    void setExceptionHandlerScanPackage(java.lang.String);
    boolean equals(java.lang.Object);
    protected boolean canEqual(java.lang.Object);
    int hashCode();
    java.lang.String toString();
```

### `AppServiceBeanPostProcessor`（15 方法）

`com.seeyon.boot.starter.appservice.AppServiceBeanPostProcessor`

```java
    static boolean isCglibProxyClass(java.lang.Class);
    private java.lang.Class<?> getTargetClass(java.lang.Object);
    private int getDubboBPPIndex(java.util.List<org.springframework.beans.factory.config.BeanPostProcessor>);
    private int getFacadeBPPIndex(java.util.List<org.springframework.beans.factory.config.BeanPostProcessor>);
    private int getAOPBPPIndex(java.util.List<org.springframework.beans.factory.config.BeanPostProcessor>);
    private void checkBPPOrder();
    java.lang.Object postProcessBeforeInitialization(java.lang.Object, java.lang.String)
    private boolean hasAppServiceAnnotation(java.lang.Object);
    private java.lang.Object transactionCheck(java.lang.Object);
    private void appServiceMethodInterceptor(java.lang.Object, java.lang.String)
    int getOrder();
    void postProcessBeanDefinitionRegistry(org.springframework.beans.factory.support.BeanDefinitionRegistry)
    void postProcessBeanFactory(org.springframework.beans.factory.config.ConfigurableListableBeanFactory)
    void setBeanFactory(org.springframework.beans.factory.BeanFactory)
```

### `CtpIdempotentService`（13 方法）

`com.seeyon.boot.starter.appservice.domain.service.CtpIdempotentService`

```java
    static void addIdempotentBean(java.lang.Object, java.lang.String);
    static java.lang.String getIdempotentBeanName(java.lang.Object);
    com.seeyon.boot.starter.appservice.domain.entity.CtpIdempotent selectById(java.lang.Long);
    boolean timeOutCheck(com.seeyon.boot.starter.appservice.domain.entity.CtpIdempotent);
    void infoLog(java.lang.String);
    void errorLog(java.lang.Throwable);
    boolean create(com.seeyon.boot.starter.appservice.domain.entity.CtpIdempotent);
    void update(com.seeyon.boot.starter.appservice.domain.entity.CtpIdempotent);
    com.seeyon.boot.starter.appservice.domain.entity.CtpIdempotent selectOneByCondition(java.util.Map);
    private void removeCache(java.lang.ClassLoader);
    void onApplicationEvent(com.seeyon.boot.event.ModuleUnloadEvent);
    void onApplicationEvent(org.springframework.context.ApplicationEvent);
```

### `AppServiceMethodInterceptor`（7 方法）

`com.seeyon.boot.starter.appservice.aop.AppServiceMethodInterceptor`

```java
    static com.seeyon.boot.starter.appservice.aop.AppServiceMethodInterceptor getInstance();
    void register(java.lang.reflect.Method);
    boolean canBeProxy();
    private java.lang.String getMethodKey(java.lang.reflect.Method);
    java.lang.Object invoke(org.aopalliance.intercept.MethodInvocation)
    void setBeanFactory(org.springframework.beans.factory.BeanFactory)
```

### `ExceptionHandlers`（7 方法）

`com.seeyon.boot.starter.appservice.ex.ExceptionHandlers`

```java
    static boolean isCglibProxyClass(java.lang.Class);
    static private static java.lang.Class<?> getInterfaceGenricType(java.lang.Class<?>, java.lang.Class<?>, int);
    private void addHandler(com.seeyon.boot.starter.appservice.ex.ExceptionHandler<?>);
    private java.lang.Class<?> getTargetClass(java.lang.Object);
    boolean handle(com.seeyon.boot.starter.appservice.ex.ExceptionContext<?>, java.lang.Throwable);
    private boolean handle(com.seeyon.boot.starter.appservice.ex.ExceptionContext, java.lang.Throwable, java.lang.Class<?>);
    void afterPropertiesSet()
```

### `AppServiceLogFilter`（6 方法）

`com.seeyon.boot.starter.appservice.filter.AppServiceLogFilter`

```java
    void doFilter(com.seeyon.boot.starter.appservice.AppServiceContext, com.seeyon.boot.starter.filterchain.FilterChain<com.seeyon.boot.starter.appservice.AppServiceContext>);
    private void traceLog(com.seeyon.boot.starter.appservice.AppServiceContext, long);
    private boolean skipClass(java.lang.String);
    int getOrder();
    void afterPropertiesSet()
    void doFilter(com.seeyon.boot.starter.filterchain.BaseContext, com.seeyon.boot.starter.filterchain.FilterChain);
```

### `AppServiceAnnotationAdvisor`（5 方法）

`com.seeyon.boot.starter.appservice.aop.AppServiceAnnotationAdvisor`

```java
    org.springframework.aop.Pointcut getPointcut();
    org.aopalliance.aop.Advice getAdvice();
    int getOrder();
    void setBeanFactory(org.springframework.beans.factory.BeanFactory)
```

### `AppServiceLicenseFilter`（5 方法）

`com.seeyon.boot.starter.appservice.filter.AppServiceLicenseFilter`

```java
    void doFilter(com.seeyon.boot.starter.appservice.AppServiceContext, com.seeyon.boot.starter.filterchain.FilterChain<com.seeyon.boot.starter.appservice.AppServiceContext>);
    private boolean hasAnyPlugin(java.util.Set<java.lang.String>);
    int getOrder();
    void afterPropertiesSet()
    void doFilter(com.seeyon.boot.starter.filterchain.BaseContext, com.seeyon.boot.starter.filterchain.FilterChain);
```

### `AppServiceAutoConfiguration`（4 方法）

`com.seeyon.boot.starter.appservice.AppServiceAutoConfiguration`

```java
    com.seeyon.boot.starter.appservice.AppServiceBeanPostProcessor appServiceBeanPostProcessor(com.seeyon.boot.starter.appservice.AppServiceProperties);
    com.seeyon.boot.starter.appservice.aop.AppServiceAnnotationAdvisor appServiceAnnotationAdvisor();
    com.seeyon.boot.starter.appservice.aop.IdempotentAnnotationAdvisor idempotentAnnotationAdvisor();
    com.seeyon.boot.starter.appservice.aop.TransactionMethodLogAdvisor transactionMethodLogAdvisor();
```

### `CtpIdempotentClearService`（3 方法）

`com.seeyon.boot.starter.appservice.domain.service.CtpIdempotentClearService`

```java
    com.seeyon.boot.transport.SingleResponse<?> exec();
```

### `AppServiceFilterChain`（3 方法）

`com.seeyon.boot.starter.appservice.filter.AppServiceFilterChain`

```java
    private void replaceDefaultCheckFilter();
    protected void adjustFilters();
    void destroy();
```

### `JavasistUtils`（3 方法）

`com.seeyon.boot.starter.appservice.util.JavasistUtils`

```java
    static void addAnnotationToMethod(java.lang.Class<?>, java.lang.String, java.lang.Class<?>, java.util.function.BiConsumer<javassist.bytecode.annotation.Annotation, javassist.bytecode.ConstPool>);
    static private static javassist.bytecode.AnnotationsAttribute getAnnotationsAttributeFromMethod(javassist.CtMethod);
    static private static void retransformClass(java.lang.Class<?>, byte[]);
```

## 三、注解（1）

| 注解 | 元素 |
|---|---|
| `Idempotent` |  |

## 四、枚举（1）

- `IdempotentStatusEnum`（3 常量）：PROCESSING, SUCCESS, FAILED
