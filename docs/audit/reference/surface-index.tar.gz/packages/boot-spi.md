# boot-spi：接口与方法签名

> 自动生成，勿手改。`tools/core/platform/emit_package_surfaces.py` 重跑即可。
> 构件 `com.seeyon:boot-spi`（jar `boot-spi-5.3.600.jar`）
> 规模：3 类 / 3 接口 / 0 注解 / 0 枚举 / 0 个关键类 / 8 方法。
> 签名逐字来自 javap 原文；已去掉 `public` 前缀与 `throws` 子句。

## 一、接口（3）

### `DataSignExecution`（5 方法）

`com.seeyon.boot.spi.DataSignExecution`

```java
    java.lang.Boolean envEnable();
    java.util.Map<java.lang.String, java.lang.String> SignatureList(java.util.List<java.lang.String>);
    java.lang.String Signature(java.lang.String);
    java.lang.Boolean Verify(java.lang.String, java.lang.String);
    java.util.Map<java.lang.String, java.lang.Boolean> VerifyList(java.util.Map<java.lang.String, java.lang.String>);
```

### `EntityEncryption`（2 方法）

`com.seeyon.boot.spi.EntityEncryption`

```java
    java.lang.String decrypt(java.lang.String);
    java.lang.String encrypt(java.lang.String);
```

### `SensitiveSpi`（1 方法）

`com.seeyon.boot.spi.SensitiveSpi`

```java
    java.lang.String sensitiveProcess(java.lang.String);
```
