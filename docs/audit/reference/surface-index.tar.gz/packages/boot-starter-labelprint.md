# boot-starter-labelprint：接口与方法签名

> 自动生成，勿手改。`tools/core/platform/emit_package_surfaces.py` 重跑即可。
> 构件 `com.seeyon:boot-starter-labelprint`（jar `boot-starter-labelprint-5.3.600.jar`）
> 规模：23 类 / 3 接口 / 0 注解 / 2 枚举 / 9 个关键类 / 213 方法。
> 签名逐字来自 javap 原文；已去掉 `public` 前缀与 `throws` 子句。

## 一、接口（3）

### `LabelPrintCategoryDao`（0 方法） extends LabelPrintCategory>

`com.seeyon.boot.starter.labelprint.domain.dao.LabelPrintCategoryDao`

```java
```

### `LabelPrintRecordDao`（0 方法） extends LabelPrintRecord>

`com.seeyon.boot.starter.labelprint.domain.dao.LabelPrintRecordDao`

```java
```

### `LabelPrintTemplateDao`（0 方法） extends LabelPrintTemplate>

`com.seeyon.boot.starter.labelprint.domain.dao.LabelPrintTemplateDao`

```java
```

## 二、关键类（9）

### `LabelPrintTemplateDto`（30 方法）

`com.seeyon.boot.starter.labelprint.dto.LabelPrintTemplateDto`

```java
    java.lang.Long getId();
    java.util.Date getCreateTime();
    java.util.Date getUpdateTime();
    java.lang.Long getEntityId();
    java.lang.String getCaption();
    java.lang.Long getAppId();
    java.lang.String getCompanyCode();
    java.lang.String getCompanyName();
    java.lang.String getTemplateThumbnail();
    java.lang.String getTemplate();
    java.lang.String getIn_param();
    java.lang.Long getCreateUserId();
    java.lang.String getCreateUserName();
    com.seeyon.boot.starter.labelprint.enums.LabelPrintStatusEnum getStatus();
    java.lang.Boolean getDeleted();
    void setId(java.lang.Long);
    void setCreateTime(java.util.Date);
    void setUpdateTime(java.util.Date);
    void setEntityId(java.lang.Long);
    void setCaption(java.lang.String);
    void setAppId(java.lang.Long);
    void setCompanyCode(java.lang.String);
    void setCompanyName(java.lang.String);
    void setTemplateThumbnail(java.lang.String);
    void setTemplate(java.lang.String);
    void setIn_param(java.lang.String);
    void setCreateUserId(java.lang.Long);
    void setCreateUserName(java.lang.String);
    void setStatus(com.seeyon.boot.starter.labelprint.enums.LabelPrintStatusEnum);
    void setDeleted(java.lang.Boolean);
```

### `LabelPrintTemplate`（22 方法）

`com.seeyon.boot.starter.labelprint.domain.entity.LabelPrintTemplate`

```java
    java.lang.Long getEntityId();
    java.lang.String getCaption();
    java.lang.Long getAppId();
    java.lang.String getCompanyCode();
    java.lang.String getCompanyName();
    java.lang.String getTemplateThumbnail();
    java.lang.String getTemplate();
    java.lang.String getIn_param();
    java.lang.Long getCreateUserId();
    com.seeyon.boot.starter.labelprint.enums.LabelPrintStatusEnum getStatus();
    java.lang.Boolean getDeleted();
    void setEntityId(java.lang.Long);
    void setCaption(java.lang.String);
    void setAppId(java.lang.Long);
    void setCompanyCode(java.lang.String);
    void setCompanyName(java.lang.String);
    void setTemplateThumbnail(java.lang.String);
    void setTemplate(java.lang.String);
    void setIn_param(java.lang.String);
    void setCreateUserId(java.lang.Long);
    void setStatus(com.seeyon.boot.starter.labelprint.enums.LabelPrintStatusEnum);
    void setDeleted(java.lang.Boolean);
```

### `LabelPrintAppService`（18 方法）

`com.seeyon.boot.starter.labelprint.appservice.LabelPrintAppService`

```java
    com.seeyon.boot.transport.SingleResponse<java.lang.Long> createCategory(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.labelprint.dto.LabelPrintCategoryDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> updateCategory(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.labelprint.dto.LabelPrintCategoryDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> deleteCategoryById(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.boot.starter.labelprint.dto.LabelPrintCategoryDto> selectCategoryById(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.boot.starter.labelprint.dto.LabelPrintCategoryDto> selectCategoryListByConditions(com.seeyon.boot.transport.ListRequest);
    com.seeyon.boot.transport.SingleResponse<java.lang.Long> createTemplate(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.labelprint.dto.LabelPrintTemplateDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> updateTemplate(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.labelprint.dto.LabelPrintTemplateDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> updateTemplateStatus(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.labelprint.dto.biz.LabelPrintTemplateStatusDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> deleteTemplateById(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> deleteTemplateByIds(com.seeyon.boot.transport.SingleRequest<java.util.List<java.lang.Long>>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.boot.starter.labelprint.dto.LabelPrintTemplateDto> selectTemplateById(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.PageResponse<com.seeyon.boot.starter.labelprint.dto.LabelPrintTemplateDto> selectTemplatePageByConditions(com.seeyon.boot.transport.PageRequest);
    com.seeyon.boot.transport.ListResponse<com.seeyon.boot.starter.labelprint.dto.LabelPrintTemplateDto> selectTemplateListByConditions(com.seeyon.boot.transport.ListRequest);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.boot.starter.labelprint.dto.biz.LabelPrintTemplateUrlDto> templateUrlForApi(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.labelprint.dto.biz.LabelPrintTemplateUrlDto>);
    com.seeyon.boot.transport.SingleResponse<java.util.Map<java.lang.Long, java.lang.Long>> createRecordBatch(com.seeyon.boot.transport.SingleRequest<java.util.List<com.seeyon.boot.starter.labelprint.dto.LabelPrintRecordDto>>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> updateRecordResultBatch(com.seeyon.boot.transport.SingleRequest<java.util.List<com.seeyon.boot.starter.labelprint.dto.LabelPrintRecordResultDto>>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.boot.starter.labelprint.dto.LabelPrintRecordDto> selectRecordById(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.PageResponse<com.seeyon.boot.starter.labelprint.dto.LabelPrintRecordDto> selectRecordPageByConditions(com.seeyon.boot.transport.PageRequest);
```

### `LabelPrintTemplateService`（9 方法）

`com.seeyon.boot.starter.labelprint.domain.service.LabelPrintTemplateService`

```java
    java.lang.Long create(com.seeyon.boot.starter.labelprint.dto.LabelPrintTemplateDto);
    int update(com.seeyon.boot.starter.labelprint.dto.LabelPrintTemplateDto);
    int updateTemplateStatus(com.seeyon.boot.starter.labelprint.dto.biz.LabelPrintTemplateStatusDto);
    int deleteById(java.lang.Long);
    int deleteByIds(java.util.List<java.lang.Long>);
    com.seeyon.boot.starter.labelprint.dto.LabelPrintTemplateDto selectById(java.lang.Long);
    com.seeyon.boot.transport.PageData<com.seeyon.boot.starter.labelprint.dto.LabelPrintTemplateDto> selectPageByConditions(com.seeyon.boot.transport.PageInfo, java.util.Map<java.lang.String, java.lang.Object>, com.seeyon.boot.transport.Sort);
    java.util.List<com.seeyon.boot.starter.labelprint.dto.LabelPrintTemplateDto> selectListByConditions(java.util.Map<java.lang.String, java.lang.Object>, com.seeyon.boot.transport.Sort);
    boolean existCaption(java.lang.String);
```

### `LabelPrintTemplateUrlDto`（8 方法）

`com.seeyon.boot.starter.labelprint.dto.biz.LabelPrintTemplateUrlDto`

```java
    java.lang.Long getTemplateId();
    java.lang.Long getRecordId();
    java.lang.String getFileName();
    java.lang.String getDownloadUrl();
    void setTemplateId(java.lang.Long);
    void setRecordId(java.lang.Long);
    void setFileName(java.lang.String);
    void setDownloadUrl(java.lang.String);
```

### `LabelPrintRecordService`（7 方法）

`com.seeyon.boot.starter.labelprint.domain.service.LabelPrintRecordService`

```java
    java.util.Map<java.lang.Long, java.lang.Long> createBatch(java.util.List<com.seeyon.boot.starter.labelprint.dto.LabelPrintRecordDto>);
    int updateResultBatch(java.util.List<com.seeyon.boot.starter.labelprint.dto.LabelPrintRecordResultDto>);
    com.seeyon.boot.starter.labelprint.dto.LabelPrintRecordDto selectById(java.lang.Long);
    com.seeyon.boot.transport.PageData<com.seeyon.boot.starter.labelprint.dto.LabelPrintRecordDto> selectPageByConditions(com.seeyon.boot.transport.PageInfo, java.util.Map<java.lang.String, java.lang.Object>, com.seeyon.boot.transport.Sort);
```

### `LabelPrintTemplateStatusDto`（6 方法）

`com.seeyon.boot.starter.labelprint.dto.biz.LabelPrintTemplateStatusDto`

```java
    java.lang.Long getId();
    java.lang.Long getCreateUserId();
    com.seeyon.boot.starter.labelprint.enums.LabelPrintStatusEnum getStatus();
    void setId(java.lang.Long);
    void setCreateUserId(java.lang.Long);
    void setStatus(com.seeyon.boot.starter.labelprint.enums.LabelPrintStatusEnum);
```

### `LabelPrintCategoryService`（5 方法）

`com.seeyon.boot.starter.labelprint.domain.service.LabelPrintCategoryService`

```java
    java.lang.Long create(com.seeyon.boot.starter.labelprint.dto.LabelPrintCategoryDto);
    int update(com.seeyon.boot.starter.labelprint.dto.LabelPrintCategoryDto);
    int deleteById(java.lang.Long);
    com.seeyon.boot.starter.labelprint.dto.LabelPrintCategoryDto selectById(java.lang.Long);
    java.util.List<com.seeyon.boot.starter.labelprint.dto.LabelPrintCategoryDto> selectListByConditions(java.util.Map<java.lang.String, java.lang.Object>, com.seeyon.boot.transport.Sort);
```

### `LabelPrintOtherService`（4 方法）

`com.seeyon.boot.starter.labelprint.domain.service.LabelPrintOtherService`

```java
    com.seeyon.udc.common.dto.EntityDto selectEntityById(java.lang.Long);
    java.util.List<com.seeyon.udc.common.dto.EntityDto> selectEntityListByConditions(java.util.Map<java.lang.String, java.lang.Object>);
    private void dealWithResponse(com.seeyon.boot.transport.BaseResponse);
```

## 四、枚举（2）

- `LabelPrintResultEnum`（3 常量）：PENDING, SUCCESS, FAIL
- `LabelPrintStatusEnum`（2 常量）：OFF, ON
