# ctp-message-facade：接口与方法签名

> 自动生成，勿手改。`tools/core/platform/emit_package_surfaces.py` 重跑即可。
> 构件 `com.seeyon:ctp-message-facade`（jar `ctp-message-facade-5.3.287.jar`）
> 规模：45 类 / 9 接口 / 0 注解 / 13 枚举 / 2 个关键类 / 310 方法。
> 签名逐字来自 javap 原文；已去掉 `public` 前缀与 `throws` 子句。

## 一、接口（9）

### `CtpMessageManageAppService`（8 方法）

`com.seeyon.ctp.message.api.CtpMessageManageAppService`

```java
    com.seeyon.boot.transport.SingleResponse<java.util.Map<java.lang.String, java.lang.Boolean>> onlineInfo(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> kickOffline(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.message.dto.KickOfflineDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.ctp.message.dto.CtpMessageManageDto> selectBySetType(com.seeyon.boot.transport.SingleRequest<java.util.Map<java.lang.String, java.lang.Object>>);
    com.seeyon.boot.transport.SingleResponse<java.util.Map<com.seeyon.ctp.message.enums.ManageSetTypeEnum, java.lang.String>> selectListByUserId(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> set(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.message.dto.CtpMessageManageDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Long> onlineNumber();
    com.seeyon.boot.transport.SingleResponse<java.lang.Boolean> deleteMessageRegister(com.seeyon.boot.transport.SingleRequest<java.lang.String>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> getMessageNumber(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.message.dto.MessageStatusDto>);
```

### `CtpMessageOpenApiService`（3 方法）

`com.seeyon.ctp.message.api.CtpMessageOpenApiService`

```java
    com.seeyon.boot.transport.SingleResponse<java.lang.Boolean> sendMessageSimple(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.message.dto.MessageSendSimpleDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Boolean> sendMessage(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.message.dto.MessageSendDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Boolean> saveMessageTemplate(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.message.dto.CtpMessageTemplateDto>);
```

### `CtpMessageSourceTypeAppService`（2 方法）

`com.seeyon.ctp.message.api.CtpMessageSourceTypeAppService`

```java
    com.seeyon.boot.transport.SingleResponse<java.lang.Long> createSource(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.message.dto.CtpMessageSourceBaseDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Long> createType(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.message.dto.CtpMessageTypeDto>);
```

### `CtpUdcMessageSendAppService`（2 方法）

`com.seeyon.ctp.message.api.CtpUdcMessageSendAppService`

```java
    com.seeyon.boot.transport.SingleResponse<java.lang.String> sendMessageByUser(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.message.dto.UdcMessageSendUserDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.String> sendMessageByChooseJson(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.message.dto.UdcMessageSendChooseDto>);
```

### `CtpMessageOperateAppService`（1 方法）

`com.seeyon.ctp.message.api.CtpMessageOperateAppService`

```java
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> deleteMessageByIdentification(com.seeyon.boot.transport.SingleRequest<java.lang.String>);
```

### `MessageUtil`（1 方法）

`com.seeyon.ctp.message.utils.MessageUtil`

```java
    java.lang.String getDefaultValue(java.lang.String);
```

### `MessageConstant`（0 方法）

`com.seeyon.ctp.message.constant.MessageConstant`

```java
```

### `MqMessageConstant`（0 方法）

`com.seeyon.ctp.message.constant.MqMessageConstant`

```java
```

### `ReSendConstants`（0 方法）

`com.seeyon.ctp.message.constant.ReSendConstants`

```java
```

## 二、关键类（2）

### `CtpMessageTemplateDto`（8 方法）

`com.seeyon.ctp.message.dto.CtpMessageTemplateDto`

```java
    java.lang.String getMessageSourceCode();
    java.lang.String getTemplateKey();
    java.util.Map<java.lang.String, java.lang.String> getTemplateMap();
    java.util.List<java.lang.String> getOptionalVariables();
    void setMessageSourceCode(java.lang.String);
    void setTemplateKey(java.lang.String);
    void setTemplateMap(java.util.Map<java.lang.String, java.lang.String>);
    void setOptionalVariables(java.util.List<java.lang.String>);
```

### `CtpUdcMessageSendServiceImpl`（4 方法）

`com.seeyon.ctp.message.service.CtpUdcMessageSendServiceImpl`

```java
    com.seeyon.boot.transport.SingleResponse<java.lang.String> sendMessageByUser(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.message.dto.UdcMessageSendUserDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.String> sendMessageByChooseJson(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.message.dto.UdcMessageSendChooseDto>);
    private com.seeyon.ctp.message.dto.MessageSendDto buildMessageSendDto(com.seeyon.ctp.message.dto.UdcBaseMessageSendDto);
```

## 四、枚举（13）

- `ClassificationEnum`（1 常量）：ATTENTION
- `DeviceFirmEnum`（5 常量）：XIAOMI, HUAWEI, OPPO, VIVO, APPLE
- `DeviceTypeEnum`（4 常量）：ANDROID, IPHONE, ANDROIDPAD, IPAD
- `ManageSetTypeEnum`（9 常量）：WEB_MUTE, READ_REMOVE, MOBILE_MUTE, RECEIVE_NEW_MESSAGE, VIEW_CONTENT, MOBILE_RECEIVE_TIME, SUBSCRIBE_ORG, IS_SEND_OFFLINE, IS_SEND_ONLINE
- `MessageChannelEnum`（3 常量）：SYSTEM, EMAIL, SHORT_MESSAGE
- `MessageStatusEnum`（3 常量）：ALL, READ, UNREAD
- `OpenTypeEnum`（3 常量）：SERVICE, WORKSPACE, NEWWINDOW
- `ParamModeEnum`（2 常量）：COMMON, RESTFUL
- `PushTypeEnum`（3 常量）：M5, DINGDING, WEIXIN
- `RegisterPlatformEnum`（6 常量）：XIAOMI, HUAWEI, OPPO, VIVO, APPLE, APPLEINHOUSE
- `SenderEnum`（3 常量）：COMMON, SYSTEM, ANONYMOUS
- `SystemClassificationEnum`（2 常量）：ALL, OTHER
- `TerminalEnum`（6 常量）：WEB, PC, MOBILE, PAD, UDC, COMMON
