# boot-starter-cip：接口与方法签名

> 自动生成，勿手改。`tools/core/platform/emit_package_surfaces.py` 重跑即可。
> 构件 `com.seeyon:boot-starter-cip`（jar `boot-starter-cip-5.3.603.jar`）
> 规模：98 类 / 8 接口 / 0 注解 / 5 枚举 / 21 个关键类 / 967 方法。
> 签名逐字来自 javap 原文；已去掉 `public` 前缀与 `throws` 子句。

## 一、接口（8）

### `CipDatabaseCommonDao`（3 方法） extends CipParamEscapeDetail>

`com.seeyon.boot.starter.cip.domain.dao.CipDatabaseCommonDao`

```java
    java.util.List<java.util.Map<java.lang.String, java.lang.Object>> fetchColumnsByUniqueKey(java.lang.String, java.lang.String, java.util.List<java.lang.Object>, java.util.List<java.lang.String>, java.lang.Long);
    java.util.List<java.util.Map<java.lang.String, java.lang.Object>> selectAllColumnsWithCondition(java.lang.String, java.lang.String, java.lang.Object, java.lang.Long);
    java.util.List<java.util.Map<java.lang.String, java.lang.Object>> selectColumnsWithNoCondition(java.lang.String, java.util.List<java.lang.String>, java.lang.Long);
```

### `WeakTypeEscapeService`（1 方法）

`com.seeyon.boot.starter.cip.api.WeakTypeEscapeService`

```java
    com.seeyon.boot.starter.cip.dto.WeakTypeEscapeDto findWeakTypeEscapeDto(java.util.Map);
```

### `CipParamEscapeDetailDao`（0 方法） extends CipParamEscapeDetail>

`com.seeyon.boot.starter.cip.domain.dao.CipParamEscapeDetailDao`

```java
```

### `DocFileConvertRecordDao`（0 方法） extends DocFileConvertRecord>

`com.seeyon.boot.starter.cip.domain.dao.DocFileConvertRecordDao`

```java
```

### `DocFileVersionDao`（0 方法） extends DocFileVersion>

`com.seeyon.boot.starter.cip.domain.dao.DocFileVersionDao`

```java
```

### `V5DoneLogDao`（0 方法） extends V5DoneLog>

`com.seeyon.boot.starter.cip.domain.dao.V5DoneLogDao`

```java
```

### `V5FlowPngDao`（0 方法） extends V5FlowPng>

`com.seeyon.boot.starter.cip.domain.dao.V5FlowPngDao`

```java
```

### `V5OpinionDao`（0 方法） extends V5Opinion>

`com.seeyon.boot.starter.cip.domain.dao.V5OpinionDao`

```java
```

## 二、关键类（21）

### `ParamEscapeServiceImpl`（38 方法）

`com.seeyon.boot.starter.cip.domain.service.ParamEscapeServiceImpl`

```java
    void saveApiLog(com.seeyon.boot.starter.dubbo.dto.AppServiceAsyncInvokeDto, java.lang.Object);
    void normalParamEscape(java.lang.String, java.lang.String, com.seeyon.boot.starter.cip.enums.EscapeDirectionEnum, java.util.Map, java.lang.Boolean);
    void eventParamEscape(java.lang.String, java.lang.String, java.util.Map<java.lang.String, java.lang.Object>, java.util.Map<java.lang.String, java.lang.Object>);
    private java.lang.String saveGetKey(java.util.Map<java.lang.String, java.lang.Object>, java.lang.String);
    private java.lang.String getEscapeClassPrefix(java.util.Map<java.lang.String, java.lang.Object>);
    java.lang.String paramEscape(java.lang.String, java.lang.String, java.lang.String, java.util.Map<java.lang.String, java.lang.Object>);
    private java.lang.String paramNameEscape(java.lang.String, java.lang.String, java.util.Map<java.lang.String, java.lang.Object>);
    private void handleSingleNameEscape(java.util.Map<java.lang.String, java.lang.Object>, java.lang.String, java.lang.String);
    private java.lang.String paramValueEscape(java.lang.String, java.lang.String, java.lang.String, java.util.Map<java.lang.String, java.lang.Object>);
    void paramEscape(com.seeyon.boot.starter.cip.enums.EscapeDirectionEnum, java.lang.String, java.lang.Object, java.util.Map<java.lang.String, java.lang.Object>);
    private void weakTypeEscape(java.util.List<com.seeyon.boot.starter.cip.dto.EscapeAttributeBaseDto>, com.seeyon.boot.starter.cip.enums.EscapeDirectionEnum, java.lang.Object);
    java.lang.String paramEscape(java.lang.String, java.lang.String, java.lang.String, java.lang.Long);
    private void entityExtend(java.util.List<com.seeyon.boot.starter.cip.dto.EscapeAttributeBaseDto>, com.seeyon.boot.starter.cip.enums.EscapeDirectionEnum, java.lang.Object, java.lang.String);
    private java.util.Map<java.lang.String, java.lang.String> fetchColumnsData(com.seeyon.boot.starter.cip.dto.EntityExtendDetailDto, java.lang.String, java.util.List<java.lang.String>, java.lang.String, java.lang.String, com.seeyon.boot.starter.cip.enums.EscapeDirectionEnum);
    private java.util.Map<java.lang.String, java.lang.String> getEscapeDataFromService(com.seeyon.boot.starter.cip.dto.EntityExtendDetailDto, java.lang.String, java.util.List<java.lang.String>, java.lang.String, java.lang.Long, com.seeyon.boot.starter.cip.enums.EscapeDirectionEnum);
    private java.util.Map<java.lang.String, java.lang.String> handleResult(java.util.List<java.lang.String>, java.util.List<com.seeyon.boot.starter.cip.dto.TableColumnInfoResultDto>, java.lang.String, java.lang.String);
    private void extractAllData(com.seeyon.boot.starter.cip.dto.EscapeAttributeBaseDto, java.util.List<java.lang.String>, java.util.List<java.util.Map<java.lang.String, java.lang.Object>>, java.lang.String, java.lang.Object);
    private void extractSingleData(java.util.Map<java.lang.String, java.lang.Object>, int, com.seeyon.boot.starter.cip.dto.EscapeAttributeBaseDto, java.lang.String, java.util.List<java.lang.String>, java.util.List<java.util.Map<java.lang.String, java.lang.Object>>);
    private void dynamicEnumEscape(java.util.List<com.seeyon.boot.starter.cip.dto.EscapeAttributeBaseDto>, com.seeyon.boot.starter.cip.enums.EscapeDirectionEnum, java.lang.Object);
    private java.util.Map<java.lang.String, java.lang.String> getDynamicEnumMap(com.seeyon.boot.starter.cip.enums.EscapeDirectionEnum, java.lang.String, java.lang.String);
    private void enumEntityEscape(java.lang.String, java.util.List<com.seeyon.boot.starter.cip.dto.EscapeAttributeBaseDto>, com.seeyon.boot.starter.cip.enums.EscapeDirectionEnum, java.lang.Object);
    private java.util.Map<java.lang.String, java.lang.String> getEnumEscapeMap(java.lang.Long, com.seeyon.boot.starter.cip.enums.EscapeDirectionEnum);
    private void handleSingleObject(java.lang.Object, java.util.Map<java.lang.String, java.lang.String>, com.seeyon.boot.starter.cip.dto.EnumAttributeDetailDto);
    private java.lang.Object extractData(java.util.Map<java.lang.String, java.lang.Object>, java.lang.String);
    private void escapeSingleAttribute(java.util.Map<java.lang.String, java.lang.Object>, int, com.seeyon.boot.starter.cip.dto.EnumAttributeDetailDto, java.util.Map<java.lang.String, java.lang.String>);
    private void escapeTargetAttribute(java.util.Map<java.lang.String, java.lang.Object>, com.seeyon.boot.starter.cip.dto.EnumAttributeDetailDto, java.util.Map<java.lang.String, java.lang.String>);
```

### `CipParamEscapeDetailService`（36 方法）

`com.seeyon.boot.starter.cip.domain.service.CipParamEscapeDetailService`

```java
    void deleteEscapeConfig(java.lang.Long);
    java.lang.Long updateEscapeConfig(com.seeyon.boot.starter.cip.dto.ParamEscapeUpdateDto);
    com.seeyon.boot.transport.PageData<com.seeyon.boot.starter.cip.dto.ParamEscapeDetailDto> pageQueryEscapeDetails(com.seeyon.boot.starter.cip.dto.EscapeDetailPageQueryDto);
    private void makeHeaderInfo(java.util.List<java.lang.String>, java.util.List<java.lang.String>, com.seeyon.boot.starter.cip.dto.ParamEscapeConfigExportDto);
    void exportParamEscapeConfig(com.seeyon.boot.starter.cip.dto.ParamEscapeConfigExportDto);
    java.lang.String exportParamEscapeResult(java.lang.Long);
    java.lang.String exportParamEscapeConfigInEvent(com.seeyon.boot.starter.cip.dto.ParamEscapeConfigExportDto);
    java.util.List<java.lang.String> getExcelFileColumns(java.lang.String);
    void importParamEscapeConfig(com.seeyon.boot.starter.cip.dto.ParamEscapeConfigImportDto);
    void importParamEscapeConfigInEvent(com.seeyon.boot.starter.cip.dto.ParamEscapeConfigImportDto);
    private void clearCurrentData(java.lang.Long);
    private java.util.Map<java.lang.String, java.lang.Object> readDataFromExcelFile(com.seeyon.boot.starter.cip.dto.ParamEscapeConfigImportDto);
    private java.lang.String object2String(java.lang.Object);
    private java.util.List<java.util.Map<java.lang.String, java.lang.Object>> fetchAllData(com.seeyon.boot.starter.cip.dto.ParamEscapeConfigExportDto);
    private java.util.List<java.lang.String> getOuterCodeMatchedList(com.seeyon.boot.starter.cip.dto.EscapeDetailPageQueryDto);
    private java.util.List<java.util.Map> pageQueryEntityData(com.seeyon.boot.starter.cip.dto.EscapeDetailPageQueryDto, java.util.List<java.lang.String>);
    private com.seeyon.boot.transport.PageData<com.seeyon.boot.starter.cip.dto.ParamEscapeDetailDto> queryEntityEscapeDetails(com.seeyon.boot.starter.cip.dto.EscapeDetailPageQueryDto);
    private java.util.Map<java.lang.String, com.seeyon.boot.starter.cip.domain.entity.CipParamEscapeDetail> getConfigEscapeMap(com.seeyon.boot.starter.cip.dto.EscapeDetailPageQueryDto, java.util.List<java.util.Map>);
    private java.util.List<com.seeyon.boot.starter.cip.domain.entity.CipParamEscapeDetail> getEscapeDetails(java.lang.Long, java.lang.String);
    private com.seeyon.boot.transport.PageData<com.seeyon.boot.starter.cip.dto.ParamEscapeDetailDto> queryEnumEscapeDetails(com.seeyon.boot.starter.cip.dto.EscapeDetailPageQueryDto);
    private boolean isEnumMatch(java.lang.String, java.lang.String, java.util.Map<java.lang.String, com.seeyon.boot.starter.cip.domain.entity.CipParamEscapeDetail>);
    void deleteEscapeRule(java.lang.Long);
    java.util.Map<java.lang.String, java.lang.String> getDetailsByStandardCodeList(java.lang.Long, java.util.List<java.lang.String>);
    java.util.Map<java.lang.String, java.lang.String> getDetailsByOuterCodeList(java.lang.Long, java.util.List<java.lang.String>);
```

### `EscapeCacheService`（16 方法）

`com.seeyon.boot.starter.cip.cache.EscapeCacheService`

```java
    private java.util.Map<java.lang.String, com.seeyon.ctp.metadata.dto.DtoMetadataDto> getDtoMetadataDtoMap(java.lang.String);
    private boolean isCipConnectorService(java.lang.String);
    private java.util.List<com.seeyon.boot.starter.cip.dto.EscapeAttributeBaseDto> analysisDynamicService(java.lang.String, java.lang.String, java.lang.Boolean);
    java.util.List<com.seeyon.boot.starter.cip.dto.EscapeAttributeBaseDto> getDtoEscapeAttributes(boolean, java.lang.String, java.lang.String, java.lang.Boolean);
    private com.seeyon.boot.starter.cip.dto.EnumAttributeDetailDto handleEnum(java.lang.String, com.seeyon.ctp.metadata.dto.DtoAttributeMetadataDto, java.lang.String);
    private boolean findEscapeAttribute(java.lang.String, java.util.Map<java.lang.String, com.seeyon.boot.starter.cip.cache.EscapeCacheService$EntityCacheDto>, java.lang.String, java.lang.String, java.lang.String, java.lang.String, com.seeyon.boot.starter.cip.dto.EntityExtendDetailDto, java.lang.Boolean);
    private com.seeyon.boot.starter.cip.dto.EntityExtendDetailDto handleEntityEscape(java.util.Map<java.lang.String, com.seeyon.boot.starter.cip.cache.EscapeCacheService$EntityCacheDto>, java.lang.String, com.seeyon.ctp.metadata.dto.DtoAttributeMetadataDto, java.lang.String, java.lang.Boolean);
    private java.lang.String getSelfDefineName(com.seeyon.ctp.metadata.dto.DtoAttributeMetadataDto);
    private void analysisDtoEscapeAttribute(java.util.Map<java.lang.String, com.seeyon.boot.starter.cip.cache.EscapeCacheService$EntityCacheDto>, java.lang.String, java.lang.String, java.util.List<com.seeyon.boot.starter.cip.dto.EscapeAttributeBaseDto>, java.lang.String, java.util.Map<java.lang.String, java.lang.Integer>, boolean, java.util.Map<java.lang.String, java.util.List<com.seeyon.boot.starter.cip.dto.EscapeAttributeBaseDto>>, java.lang.Boolean);
    private com.seeyon.boot.starter.cip.dto.EscapeAttributeBaseDto handleDynamicEnumEscape(java.lang.String, java.lang.String, com.seeyon.ctp.metadata.dto.DtoAttributeMetadataDto, java.lang.String);
    private com.seeyon.boot.starter.cip.dto.WeakTypeDetailDto weakTypeEscape(java.lang.String, com.seeyon.ctp.metadata.dto.DtoAttributeMetadataDto, java.lang.String);
    private java.lang.String getObjectType(com.seeyon.ctp.metadata.dto.DtoAttributeMetadataDto);
    private boolean isEnum(com.seeyon.ctp.metadata.dto.DtoAttributeMetadataDto);
```

### `DocGeneralizeService`（16 方法）

`com.seeyon.boot.starter.cip.domain.service.DocGeneralizeService`

```java
    com.seeyon.boot.starter.cip.dto.DocFileDto getAuthorityUploadStreamProxy(com.seeyon.boot.starter.cip.dto.DocAuthorityUploadStreamProxyRequestDto);
    com.seeyon.boot.starter.cip.domain.entity.DocFileVersion createFileVersionInfo(com.seeyon.boot.starter.cip.dto.DocFileInfoStarterDto);
    com.seeyon.boot.transport.PageData<com.seeyon.boot.starter.cip.domain.entity.DocFileVersion> selectDocFileVersionPage(com.seeyon.boot.starter.cip.dto.DocFileVersionProxyRequestDto);
    com.seeyon.boot.transport.PageData<com.seeyon.boot.starter.cip.domain.entity.DocFileVersion> selectFileNotDeletedPage(com.seeyon.boot.starter.cip.dto.DocFileNotDeletedProxyRequestDto);
    java.lang.Integer batchUpdateDocFileVersionStatus(com.seeyon.boot.starter.cip.dto.DocFileBatchUpdateProxyRequestDto);
    java.lang.Integer getFileVersion(java.lang.String);
    com.seeyon.boot.starter.cip.domain.entity.DocFileVersion getDocFileVersion(com.seeyon.boot.starter.cip.domain.entity.DocFileVersion, java.lang.String);
    java.lang.Integer getMaxVersion(java.lang.String);
    com.seeyon.boot.starter.cip.dto.DocSaveVersionProxyResponseDto saveVersion(com.seeyon.boot.starter.cip.dto.DocSaveVersionProxyRequestDto);
    com.seeyon.boot.starter.cip.domain.entity.DocFileVersion getDocFileVersionProxy(com.seeyon.boot.starter.cip.dto.DocFileVersionProxyRequestDto);
    com.seeyon.boot.starter.cip.domain.entity.DocFileConvertRecord getDocFileConvertRecord(com.seeyon.boot.starter.cip.dto.DocFileConvertRecordDto);
    java.lang.Integer createDocFileConvertRecord(com.seeyon.boot.starter.cip.domain.entity.DocFileConvertRecord);
    java.lang.Integer updateDocFileConvertRecord(com.seeyon.boot.starter.cip.domain.entity.DocFileConvertRecord);
    java.lang.Integer deleteDocFileConvertRecord(com.seeyon.boot.starter.cip.dto.DocFileConvertRecordDto);
    java.lang.Integer executeMessageEvent(com.seeyon.boot.starter.cip.dto.DocMessageProxyRequestDto);
    com.seeyon.boot.starter.cip.dto.DocStarterVersionResponseDto getCurrentStarterVersion(com.seeyon.boot.starter.cip.dto.DocStarterVersionRequestDto);
```

### `CipDatabaseCommonService`（14 方法）

`com.seeyon.boot.starter.cip.domain.service.CipDatabaseCommonService`

```java
    java.util.List<com.seeyon.boot.starter.cip.dto.TableColumnInfoResultDto> fetchColumnsByUniqueKey(com.seeyon.boot.starter.cip.dto.TableColumnInfoQueryDto);
    private java.util.List<com.seeyon.boot.starter.cip.dto.TableColumnInfoResultDto> fetchColumnsByUniqueKeyCode2Id(com.seeyon.boot.starter.cip.dto.TableColumnInfoQueryDto);
    private java.util.List<java.util.Map<java.lang.String, java.lang.Object>> changeColumnName2Lower(java.util.List<java.util.Map<java.lang.String, java.lang.Object>>);
    private java.util.List<com.seeyon.boot.starter.cip.dto.TableColumnInfoResultDto> fetchColumnsByUniqueKeyId2Code(com.seeyon.boot.starter.cip.dto.TableColumnInfoQueryDto);
    java.util.List<java.util.Map> pageQueryTableData(java.lang.String, com.seeyon.boot.transport.PageInfo, java.lang.String, java.util.List<java.lang.String>, java.lang.String, java.lang.String, java.util.List<java.lang.String>);
    private java.lang.Class<?> getDaoClass(java.lang.String, java.lang.String)
    private com.seeyon.boot.starter.cip.domain.service.CipDatabaseCommonService$EntityInfoDto getEntityInfoDto(java.lang.String, java.lang.String);
```

### `ParamEscapeConfigImportDto`（14 方法）

`com.seeyon.boot.starter.cip.dto.ParamEscapeConfigImportDto`

```java
    java.lang.Long getEscapeRuleId();
    com.seeyon.boot.starter.cip.enums.ClassTypeEnum getType();
    java.lang.String getClassName();
    java.lang.String getStorageKey();
    java.lang.String getOuterCodeColumn();
    java.util.List<com.seeyon.boot.starter.cip.dto.ParamEscapeImportConditionDto> getConditionList();
    java.lang.String getServiceName();
    void setEscapeRuleId(java.lang.Long);
    void setType(com.seeyon.boot.starter.cip.enums.ClassTypeEnum);
    void setClassName(java.lang.String);
    void setStorageKey(java.lang.String);
    void setOuterCodeColumn(java.lang.String);
    void setConditionList(java.util.List<com.seeyon.boot.starter.cip.dto.ParamEscapeImportConditionDto>);
    void setServiceName(java.lang.String);
```

### `DocGeneralizeStarterAppService`（13 方法）

`com.seeyon.boot.starter.cip.appservice.DocGeneralizeStarterAppService`

```java
    com.seeyon.boot.transport.SingleResponse<com.seeyon.boot.starter.cip.dto.DocFileDto> getAuthorityUploadStreamProxy(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.cip.dto.DocAuthorityUploadStreamProxyRequestDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.boot.starter.cip.dto.DocSaveVersionProxyResponseDto> saveVersionProxy(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.cip.dto.DocSaveVersionProxyRequestDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.boot.starter.cip.domain.entity.DocFileVersion> getDocFileVersionProxy(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.cip.dto.DocFileVersionProxyRequestDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.boot.starter.cip.domain.entity.DocFileVersion> createFileVersionInfo(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.cip.dto.DocFileInfoStarterDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.boot.transport.PageData<com.seeyon.boot.starter.cip.domain.entity.DocFileVersion>> selectDocFileVersionPage(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.cip.dto.DocFileVersionProxyRequestDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.boot.transport.PageData<com.seeyon.boot.starter.cip.domain.entity.DocFileVersion>> selectFileNotDeletedPage(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.cip.dto.DocFileNotDeletedProxyRequestDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> batchUpdateDocFileVersionStatus(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.cip.dto.DocFileBatchUpdateProxyRequestDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.boot.starter.cip.domain.entity.DocFileConvertRecord> getDocFileConvertRecord(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.cip.dto.DocFileConvertRecordDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> createDocFileConvertRecord(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.cip.domain.entity.DocFileConvertRecord>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> updateDocFileConvertRecord(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.cip.domain.entity.DocFileConvertRecord>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> deleteDocFileConvertRecord(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.cip.dto.DocFileConvertRecordDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> executeMessageEvent(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.cip.dto.DocMessageProxyRequestDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.boot.starter.cip.dto.DocStarterVersionResponseDto> getCurrentStarterVersion(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.cip.dto.DocStarterVersionRequestDto>);
```

### `CipRedisService`（13 方法）

`com.seeyon.boot.starter.cip.domain.service.CipRedisService`

```java
    com.seeyon.boot.starter.cip.dto.EscapeExportTaskDto getEscapeExportTaskInfo(java.lang.Long);
    void setEscapeExportTaskRunning(java.lang.Long);
    void setEscapeExportTaskFinished(java.lang.Long, java.lang.String);
    boolean isEscapeImportTaskRunning(java.lang.Long);
    void setEscapeImportTaskFinished(java.lang.Long);
    void setEscapeImportTaskRunning(java.lang.Long);
    java.lang.Long getEscapeRule(java.lang.String);
    private java.lang.Long getEscapeRuleFromCipManager(java.lang.String);
    java.util.List<java.lang.String> getEscapeDataFromRedis(java.lang.String, java.util.List<java.lang.String>);
    void saveEscapeData(java.lang.String, java.lang.String, java.lang.String);
    java.util.Map<java.lang.String, java.lang.String> getParamNameEscapeMap(java.lang.Long, java.lang.String, boolean);
    private java.util.Map<java.lang.String, java.lang.String> getParamNameEscapeMapFromCipManager(java.lang.String);
```

### `ParamEscapeAppService`（10 方法）

`com.seeyon.boot.starter.cip.appservice.ParamEscapeAppService`

```java
    com.seeyon.boot.transport.ListResponse<com.seeyon.boot.starter.cip.dto.EscapeClassInfoDto> fetchEscapeClass(com.seeyon.boot.transport.SingleRequest<java.lang.String>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Void> deleteEscapeRule(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.PageResponse<com.seeyon.boot.starter.cip.dto.ParamEscapeDetailDto> pageQueryEscapeDetails(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.cip.dto.EscapeDetailPageQueryDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Void> deleteEscapeConfig(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Long> updateEscapeConfig(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.cip.dto.ParamEscapeUpdateDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Void> exportParamEscapeConfig(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.cip.dto.ParamEscapeConfigExportDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.String> exportParamEscapeResult(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Void> importParamEscapeConfig(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.cip.dto.ParamEscapeConfigImportDto>);
    com.seeyon.boot.transport.ListResponse<java.lang.String> getExcelFileColumns(com.seeyon.boot.transport.SingleRequest<java.lang.String>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.boot.starter.cip.dto.TableColumnInfoResultDto> fetchColumnsByUniqueKey(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.cip.dto.TableColumnInfoQueryDto>);
```

### `ParamEscapeConfigExportDto`（10 方法）

`com.seeyon.boot.starter.cip.dto.ParamEscapeConfigExportDto`

```java
    java.lang.Long getEscapeRuleId();
    com.seeyon.boot.starter.cip.enums.ClassTypeEnum getType();
    java.lang.String getClassName();
    java.util.List<com.seeyon.boot.starter.cip.dto.EscapeColumnInfoDto> getShowColumn();
    java.lang.String getServiceName();
    void setEscapeRuleId(java.lang.Long);
    void setType(com.seeyon.boot.starter.cip.enums.ClassTypeEnum);
    void setClassName(java.lang.String);
    void setShowColumn(java.util.List<com.seeyon.boot.starter.cip.dto.EscapeColumnInfoDto>);
    void setServiceName(java.lang.String);
```

### `ParamEscapeConfigController`（7 方法）

`com.seeyon.boot.starter.cip.controller.ParamEscapeConfigController`

```java
    com.seeyon.boot.transport.PageResponse<com.seeyon.boot.starter.cip.dto.ParamEscapeDetailDto> pageQueryEscapeDetails(com.seeyon.boot.starter.cip.dto.EscapeDetailPageQueryDto);
    com.seeyon.boot.transport.SingleResponse<java.lang.Void> deleteEscapeConfig(java.lang.Long);
    com.seeyon.boot.transport.SingleResponse<java.lang.Long> updateEscapeConfig(com.seeyon.boot.starter.cip.dto.ParamEscapeUpdateDto);
    com.seeyon.boot.transport.SingleResponse<java.lang.Void> exportParamEscapeConfig(com.seeyon.boot.starter.cip.dto.ParamEscapeConfigExportDto);
    com.seeyon.boot.transport.SingleResponse<java.lang.String> exportParamEscapeResult(java.lang.Long);
    com.seeyon.boot.transport.SingleResponse<java.lang.Void> importParamEscapeConfig(com.seeyon.boot.starter.cip.dto.ParamEscapeConfigImportDto);
    com.seeyon.boot.transport.ListResponse<java.lang.String> getExcelFileColumns(java.lang.String);
```

### `PoiExcelUtils`（6 方法）

`com.seeyon.boot.starter.cip.common.PoiExcelUtils`

```java
    static java.util.List<java.lang.String> getExcelFileColumns(java.io.InputStream);
    static private static java.util.List<java.lang.String> getHeader(java.util.List<java.util.Map>);
    static private static java.util.List<java.util.Map> getExcelData(java.io.InputStream);
    static java.util.List<java.util.Map<java.lang.String, java.lang.Object>> readExcelData(java.io.InputStream);
    static java.io.InputStream writeDataToExcel(java.lang.String, java.util.List<java.lang.String>, java.util.List<java.lang.String>, java.util.List<java.util.Map<java.lang.String, java.lang.Object>>);
```

### `OpenApiErrorCodeService`（6 方法）

`com.seeyon.boot.starter.cip.domain.service.OpenApiErrorCodeService`

```java
    java.util.List<com.seeyon.boot.starter.cip.dto.ErrorCodeInfoDto> listOpenApiErrorCode();
    private java.util.List<com.seeyon.boot.starter.cip.dto.ErrorCodeInfoDto> getErrorCode(java.lang.String);
    private void findAndAddClassesInPackageByFile(java.lang.String, java.lang.String, java.util.Set<java.lang.String>);
    private java.util.Set<java.lang.String> getClasses(java.lang.String);
```

### `OpenApiLogHandler`（6 方法）

`com.seeyon.boot.starter.cip.domain.service.OpenApiLogHandler`

```java
    void onOpenApiLogAsync(com.seeyon.boot.starter.cip.dto.CipOpenApiLogDto);
    void periodicTask();
    private void flushBuffer();
    private void retryFailedLogs();
    void saveOpenApiLogs(java.util.List<com.seeyon.boot.starter.cip.dto.CipOpenApiLogDto>);
    private void addLogsToFailedBuffer(java.util.List<com.seeyon.boot.starter.cip.dto.CipOpenApiLogDto>);
```

### `V5MigrateService`（6 方法）

`com.seeyon.boot.starter.cip.domain.service.V5MigrateService`

```java
    java.util.List<com.seeyon.boot.starter.cip.dto.OpinionResponseDto> queryPostscript(java.lang.Long);
    com.seeyon.boot.transport.PageData<com.seeyon.boot.starter.cip.dto.OpinionForActivityNodeDto> queryOpinions(com.seeyon.boot.transport.PageInfo, java.lang.Long);
    private com.seeyon.boot.starter.cip.dto.OpinionResponseDto convert(com.seeyon.boot.starter.cip.domain.entity.V5Opinion, java.lang.Long);
    com.seeyon.boot.transport.PageData<com.seeyon.boot.starter.cip.dto.BpmProcessLogDto> queryDoneLog(com.seeyon.boot.transport.PageInfo, java.util.Map<java.lang.String, java.lang.Object>);
    com.seeyon.boot.starter.cip.dto.V8FileDto queryProcessPng(java.lang.Long);
    private java.util.Date utilTime(java.util.Date);
```

### `VoucherCacheService`（5 方法）

`com.seeyon.boot.starter.cip.cache.VoucherCacheService`

```java
    java.lang.String getRelationAttrColumn(java.lang.String, java.lang.String, java.lang.String);
    java.lang.String getTableName(java.lang.String, java.lang.String);
    private void loadEntity(java.lang.String);
```

### `CipMqDeliveryService`（5 方法）

`com.seeyon.boot.starter.cip.domain.service.CipMqDeliveryService`

```java
    private void initEventClassMap(java.lang.String);
    private java.lang.String getEventKey(java.lang.String, java.util.Map<java.lang.String, java.lang.Object>);
    private java.lang.String getSelfDefineName(java.util.Map<java.lang.String, java.lang.Object>);
    java.lang.Boolean deliveryMqMessage(com.seeyon.boot.starter.cip.dto.CipMqDeliveryInnerDto);
```

### `ParamEscapeConfigService`（5 方法）

`com.seeyon.boot.starter.cip.domain.service.ParamEscapeConfigService`

```java
    java.util.List<com.seeyon.boot.starter.cip.dto.EscapeClassInfoDto> fetchEscapeClass(java.lang.String);
    private java.util.List<com.seeyon.boot.starter.cip.dto.EscapeClassInfoDto> fetchEnumClass(java.lang.String);
    private java.util.List<com.seeyon.boot.starter.cip.dto.EscapeClassInfoDto> fetchEntityClass(java.lang.String);
```

### `V5MigrateAppService`（4 方法）

`com.seeyon.boot.starter.cip.appservice.V5MigrateAppService`

```java
    com.seeyon.boot.transport.ListResponse<com.seeyon.boot.starter.cip.dto.OpinionResponseDto> queryPostscript(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.PageResponse<com.seeyon.boot.starter.cip.dto.OpinionForActivityNodeDto> queryOpinions(com.seeyon.boot.transport.PageRequest);
    com.seeyon.boot.transport.PageResponse<com.seeyon.boot.starter.cip.dto.BpmProcessLogDto> queryDoneLog(com.seeyon.boot.transport.PageRequest);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.boot.starter.cip.dto.V8FileDto> queryProcessPng(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
```

### `CipOpenApiConfig`（4 方法）

`com.seeyon.boot.starter.cip.config.CipOpenApiConfig`

```java
    void setMaxLogSize(int);
    void setMaxEscapeLevel(int);
    int getMaxLogSize();
    int getMaxEscapeLevel();
```

### `VoucherDataQueryService`（3 方法）

`com.seeyon.boot.starter.cip.domain.service.VoucherDataQueryService`

```java
    com.seeyon.boot.starter.cip.dto.VoucherEntityResultDto getVoucherData(com.seeyon.boot.starter.cip.dto.VoucherEntityQueryDto);
    private java.util.Map<java.lang.String, java.util.List<java.util.Map<java.lang.String, java.lang.Object>>> handleEntryEntity(java.lang.String, java.lang.String, java.util.List<java.util.Map<java.lang.String, java.lang.Object>>, java.util.List<java.lang.String>);
    java.util.List<java.util.Map<java.lang.String, java.lang.Object>> getEntityColumnValues(com.seeyon.boot.starter.cip.dto.EntityColumnDto);
```

## 四、枚举（5）

- `ActivityStateEnum`（14 常量）：NONE, NORMAL, WAIT_ACTIVE, READY, FINISHED, CANCEL, STOP, TEMPORARY, NEEDREDO_TOME, SUSPENDED, NO_PEOPLE_SKIP, PAUSE …
- `ClassTypeEnum`（2 常量）：ENTITY, JAVA_ENUM
- `ConvertStatusStarterEnum`（3 常量）：RUNNING, SUCCESS, FAILURE
- `DocConvertOperateTypeEnum`（7 常量）：OPERATE_SAVE_VERSION, OPERATE_CONVERT, OPERATE_CLEAN, OPERATE_TEXT_WATERMARK, OPERATE_IMAGE_WATERMARK, OPERATE_OFFICE_QUERY_BOOKMARK, OPERATE_OFFICE_WARP_HEADER
- `EscapeDirectionEnum`（2 常量）：CODE_ID, ID_CODE
