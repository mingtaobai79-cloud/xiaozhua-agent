# boot-starter-datasource：接口与方法签名

> 自动生成，勿手改。`tools/core/platform/emit_package_surfaces.py` 重跑即可。
> 构件 `com.seeyon:boot-starter-datasource`（jar `boot-starter-datasource-5.3.600.jar`）
> 规模：31 类 / 2 接口 / 0 注解 / 0 枚举 / 10 个关键类 / 632 方法。
> 签名逐字来自 javap 原文；已去掉 `public` 前缀与 `throws` 子句。

## 一、接口（2）

### `IConnectionPoolProxy`（15 方法）

`com.seeyon.boot.starter.datasource.dbpool.IConnectionPoolProxy`

```java
    void init(com.seeyon.boot.starter.datasource.dbpool.DBConProviderConfig, java.util.Properties)
    com.seeyon.boot.starter.datasource.dbpool.DBConProviderConfig getSJConProviderConfig();
    void clearExceedConnInfos();
    int getNoUseCount();
    java.util.Set<com.seeyon.boot.starter.datasource.dbpool.ConInfo> getUseList();
    java.sql.Connection getConnection()
    void releaseConnection(com.seeyon.boot.starter.datasource.dbpool.ConInfo);
    void clearPool();
    int getPeakConnectionCount();
    int getBusyConnectionCount();
    java.util.Date getActivePeakTime();
    void printInfo(java.io.PrintWriter);
    void printInUseList(java.io.PrintWriter);
    int getBianhao();
    int getTotalConnection();
```

### `ConnectionCallback`（3 方法）

`com.seeyon.boot.starter.datasource.dbpool.ConnectionCallback`

```java
    void commit(com.seeyon.boot.starter.datasource.dbpool.ProxyConnection);
    void rollback(com.seeyon.boot.starter.datasource.dbpool.ProxyConnection);
    void setAutoCommit(boolean, com.seeyon.boot.starter.datasource.dbpool.ProxyConnection);
```

## 二、关键类（10）

### `DBConProviderConfig`（35 方法）

`com.seeyon.boot.starter.datasource.dbpool.DBConProviderConfig`

```java
    protected final boolean isEmptyString(java.lang.String);
    protected final void initDefaultPName();
    protected final void initPName(java.util.Properties);
    protected final java.util.Properties readDefineProperties(java.lang.String);
    private final void putDefaultConfig();
    void readConfig(java.util.Properties);
    java.lang.String getName();
    java.lang.String getSQLdriver();
    java.lang.String getSQLUrl();
    java.lang.String getUserName();
    java.lang.String getPassWord();
    java.lang.String getConnectionPool();
    int getMaxWaitMillis();
    int getMinCount();
    int getMaxCount();
    int getTryCount();
    int getTryWait();
    int getConnectionThreshold();
    int getValidateOnGet();
    java.lang.String getValidateQuery();
    int getValidateTimeout();
    long getValidateInterval();
    long getTimeBetweenEvictionRunsMillis();
    double getRateLimit();
    static long getSqlConsThreshold();
    java.lang.String getConnectionPoolPName();
    java.lang.String getDriverPName();
    java.lang.String getSQLUrlPName();
    java.lang.String getUserNamePName();
    java.lang.String getPassWordPName();
    java.lang.String getMinCountPName();
    java.lang.String getMaxCountPName();
    java.lang.String getTryCountPName();
    java.lang.String getTryWaitPName();
    boolean isOverflowMonitorEnabled();
```

### `DBConProvider`（31 方法）

`com.seeyon.boot.starter.datasource.dbpool.DBConProvider`

```java
    void setDeadConnectionTimeout(long);
    long getDeadConnectionTimeout();
    final boolean inited();
    int getDoReconnectTime();
    private boolean checkConfig()
    private boolean checkWeakPwd();
    synchronized void init(java.lang.String, java.util.Properties)
    void clearExceedConnInfos();
    void clearSlowConnInfos();
    int getNoUseCount();
    java.util.Set<com.seeyon.boot.starter.datasource.dbpool.ConInfo> getUseList();
    private void clearPool();
    private void testLink(java.lang.String, java.lang.String)
    void printInfo(java.io.PrintWriter);
    void printInUseList(java.io.PrintWriter);
    java.sql.Connection getConnection()
    void releaseConnection(com.seeyon.boot.starter.datasource.dbpool.ConInfo);
    void unInit();
    int getPeakConnectionCount();
    int getBusyConnectionCount();
    int getTotalCount();
    void monitor();
    java.lang.String getUserName();
    java.lang.String getSQLdriver();
    java.lang.String getSQLUrl();
    int getMinCount();
    int getMaxCount();
    java.lang.String getPassword();
```

### `DataSourceConProvider`（21 方法）

`com.seeyon.boot.starter.datasource.dbpool.DataSourceConProvider`

```java
    void init(java.lang.String, java.util.Properties)
    void init()
    void setName(java.lang.String)
    java.lang.String getName();
    void setConfigProperties(java.util.Properties)
    void close()
    java.sql.Connection getConnection(java.lang.String, java.lang.String)
    java.sql.Connection getConnection()
    java.io.PrintWriter getLogWriter()
    int getLoginTimeout()
    void setLogWriter(java.io.PrintWriter)
    void setLoginTimeout(int)
    com.seeyon.boot.starter.datasource.dbpool.DBConProvider getFProvider();
    static java.util.List<com.seeyon.boot.starter.datasource.dbpool.DataSourceConProvider> getDataSources();
    static private static synchronized void startDBConnectionPoolingMonitor();
    static private static java.util.Date getTodayLastTime();
    <T> T unwrap(java.lang.Class<T>)
    boolean isWrapperFor(java.lang.Class<?>)
    java.util.logging.Logger getParentLogger()
```

### `TenantDataSourceConfig`（18 方法）

`com.seeyon.boot.starter.datasource.TenantDataSourceConfig`

```java
    void addDataSource(java.lang.Long, java.lang.Long, javax.sql.DataSource);
    javax.sql.DataSource getInitializedDataSource(java.lang.Long);
    java.util.Map<java.lang.Long, javax.sql.DataSource> getInitializedDataSources();
    javax.sql.DataSource getAvailableDataSource(java.lang.Long);
    void removeAvailableDataSource(java.lang.Long);
    void addAvailableDataSource(java.lang.Long, javax.sql.DataSource);
    java.util.Map<java.lang.String, javax.sql.DataSource> getAvailableDataSources();
    java.util.Set<java.lang.Long> getTenantIds(java.lang.Long);
    java.lang.Long getResourceId(java.lang.Long);
    java.util.Map<java.lang.Long, java.lang.Long> getTenantId2ResourceIds();
    java.util.Set<java.lang.Long> getResourceIds();
    void setExclusiveStorage(boolean);
    boolean isExclusiveStorage();
    boolean isSharingTenant(java.lang.Long);
    synchronized void addNoShardingTenant(java.lang.Long);
    boolean isNoShardingTenant(java.lang.Long);
    java.util.Set<java.lang.Long> getNoShardingTenants();
    java.lang.Long doSharding(java.lang.Long);
```

### `DataSourceScriptUtils`（13 方法）

`com.seeyon.boot.starter.datasource.util.DataSourceScriptUtils`

```java
    static java.lang.String executeSqlScript(java.sql.Connection, org.springframework.core.io.support.EncodedResource, boolean, boolean, java.lang.String, java.lang.String, java.lang.String, java.lang.String)
    static java.lang.String executeSqlScript(java.sql.Connection, org.springframework.core.io.support.EncodedResource, boolean, boolean, java.lang.String[], java.lang.String, java.lang.String, java.lang.String)
    static java.lang.String readScript(org.springframework.core.io.support.EncodedResource, java.lang.String, java.lang.String[], java.lang.String)
    static java.lang.String readScript(java.io.LineNumberReader, java.lang.String, java.lang.String, java.lang.String)
    static java.lang.String readScript(java.io.LineNumberReader, java.lang.String[], java.lang.String, java.lang.String)
    static private static void appendSeparatorToScriptIfNecessary(java.lang.StringBuilder, java.lang.String);
    static boolean containsSqlScriptDelimiters(java.lang.String, java.lang.String);
    static private static boolean containsStatementSeparator(org.springframework.core.io.support.EncodedResource, java.lang.String, java.lang.String, java.lang.String[], java.lang.String, java.lang.String)
    static void splitSqlScript(java.lang.String, char, java.util.List<java.lang.String>)
    static void splitSqlScript(java.lang.String, java.lang.String, java.util.List<java.lang.String>)
    static void splitSqlScript(org.springframework.core.io.support.EncodedResource, java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.util.List<java.lang.String>)
    static void splitSqlScript(org.springframework.core.io.support.EncodedResource, java.lang.String, java.lang.String, java.lang.String[], java.lang.String, java.lang.String, java.util.List<java.lang.String>)
    static private static boolean startsWithAny(java.lang.String, java.lang.String[], int);
```

### `IdTableHelper`（6 方法）

`org.hibernate.hql.spi.id.IdTableHelper`

```java
    boolean needsIdTable(org.hibernate.mapping.PersistentClass);
    void executeIdTableCreationStatements(java.util.List<java.lang.String>, org.hibernate.engine.jdbc.spi.JdbcServices, org.hibernate.engine.jdbc.connections.spi.JdbcConnectionAccess);
    void executeIdTableDropStatements(java.lang.String[], org.hibernate.engine.jdbc.spi.JdbcServices, org.hibernate.engine.jdbc.connections.spi.JdbcConnectionAccess);
    void executeIdTableCreationStatements(java.util.List<java.lang.String>, org.hibernate.engine.jdbc.spi.JdbcServices, org.hibernate.engine.jdbc.connections.spi.JdbcConnectionAccess, org.hibernate.service.ServiceRegistry);
    void executeIdTableDropStatements(java.lang.String[], org.hibernate.engine.jdbc.spi.JdbcServices, org.hibernate.engine.jdbc.connections.spi.JdbcConnectionAccess, org.hibernate.service.ServiceRegistry);
    org.hibernate.resource.transaction.spi.DdlTransactionIsolator getDdlTransactionIsolator(org.hibernate.engine.jdbc.spi.JdbcServices, org.hibernate.engine.jdbc.connections.spi.JdbcConnectionAccess, org.hibernate.service.ServiceRegistry);
```

### `DataSourceAutoConfiguration`（5 方法）

`com.seeyon.boot.starter.datasource.DataSourceAutoConfiguration`

```java
    javax.sql.DataSource dataSource();
    org.springframework.transaction.PlatformTransactionManager transactionManager(javax.sql.DataSource);
    org.springframework.jdbc.core.JdbcTemplate jdbcTemplate(javax.sql.DataSource);
    org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate namedParameterJdbcTemplate(javax.sql.DataSource);
    org.springframework.transaction.support.TransactionTemplate transactionTemplate(org.springframework.transaction.PlatformTransactionManager);
```

### `DataSourceConProviderFactory`（4 方法）

`com.seeyon.boot.starter.datasource.dbpool.DataSourceConProviderFactory`

```java
    private void putProperty(java.util.Properties, javax.naming.Reference, java.lang.String);
    java.lang.Object getObjectInstance(java.lang.Object, javax.naming.Name, javax.naming.Context, java.util.Hashtable)
    static javax.sql.DataSource createDataSource(java.lang.String, java.util.Properties)
    static private static void read(java.util.Properties, java.lang.String);
```

### `DataSourceUtils`（4 方法）

`com.seeyon.boot.starter.datasource.util.DataSourceUtils`

```java
    static java.lang.String generateJdbcUrl(com.seeyon.boot.domain.dao.support.DatabaseType, java.lang.String, int, java.lang.String);
    static java.lang.String generateJdbcUrl(com.seeyon.boot.domain.dao.support.DatabaseType, java.lang.String, java.lang.Integer, java.lang.String, java.lang.String, java.lang.Integer);
    static com.seeyon.boot.domain.dao.support.DatabaseType getDatabaseType(java.sql.Connection);
    static java.lang.String getDatabaseUrl(java.sql.Connection);
```

### `EnumArrayConverter`（4 方法）

`org.hibernate.converter.EnumArrayConverter`

```java
    java.lang.String convertToDatabaseColumn(java.util.List<com.seeyon.boot.enums.Messageable>);
    java.util.List<com.seeyon.boot.enums.Messageable> convertToEntityAttribute(java.lang.String);
    java.lang.Object convertToEntityAttribute(java.lang.Object);
    java.lang.Object convertToDatabaseColumn(java.lang.Object);
```
