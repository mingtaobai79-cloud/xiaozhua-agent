# udc-facade：接口与方法签名

> 自动生成，勿手改。`tools/core/platform/emit_package_surfaces.py` 重跑即可。
> 构件 `com.seeyon:udc-facade`（jar `udc-facade-5.3.605.jar`）
> 规模：66 类 / 10 接口 / 0 注解 / 3 枚举 / 0 个关键类 / 503 方法。
> 签名逐字来自 javap 原文；已去掉 `public` 前缀与 `throws` 子句。

## 一、接口（10）

### `ApplicationManagerAppService`（53 方法）

`com.seeyon.udc.api.ApplicationManagerAppService`

```java
    com.seeyon.boot.transport.SingleResponse<java.lang.Long> create(com.seeyon.boot.transport.SingleRequest<com.seeyon.udc.common.dto.ApplicationDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.udc.dto.form.OnlyPageApplicationDto> createOnlyPageApplication(com.seeyon.boot.transport.SingleRequest<com.seeyon.udc.dto.form.CreateOnlyPageApplicationDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Void> createNewLayoutAfterCall(com.seeyon.boot.transport.SingleRequest<com.seeyon.udc.dto.form.NewLayoutCreateAfterCallDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.udc.dto.form.OnlyPageApplicationDto> copyOnlyPageApp(com.seeyon.boot.transport.SingleRequest<com.seeyon.udc.common.dto.ApplicationCopyDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.udc.dto.form.OnlyPageApplicationUpgradeResultDto> upgradeOnlyPageApplication(com.seeyon.boot.transport.SingleRequest<com.seeyon.udc.dto.form.OnlyPageApplicationUpgradeDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.udc.dto.form.IntegrationApplicationDto> createIntegrationApplication(com.seeyon.boot.transport.SingleRequest<com.seeyon.udc.dto.form.IntegrationApplicationDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.udc.dto.form.LayoutApplicationDto> createLayoutApplication(com.seeyon.boot.transport.SingleRequest<com.seeyon.udc.dto.form.LayoutApplicationDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.udc.dto.form.LayoutApplicationDto> copyLayoutApp(com.seeyon.boot.transport.SingleRequest<com.seeyon.udc.common.dto.ApplicationCopyDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.udc.common.dto.ApplicationDto> selectById(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> update(com.seeyon.boot.transport.SingleRequest<com.seeyon.udc.common.dto.ApplicationDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> updateWithMember(com.seeyon.boot.transport.SingleRequest<com.seeyon.udc.dto.member.ApplicationWithMemberDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> updateAppCategoryBatch(com.seeyon.boot.transport.SingleRequest<com.seeyon.udc.dto.member.AppCategoryDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> deleteById(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.udc.common.dto.ApplicationDto> copyApp(com.seeyon.boot.transport.SingleRequest<com.seeyon.udc.common.dto.ApplicationCopyDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.String> copyAppAsync(com.seeyon.boot.transport.SingleRequest<com.seeyon.udc.common.dto.ApplicationCopyDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> createMember(com.seeyon.boot.transport.SingleRequest<com.seeyon.udc.dto.member.MemberAddDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.udc.dto.member.AppCollaborationDto> selectCollaborationRecordsByAppId(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Void> deleteMemberById(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    default com.seeyon.boot.transport.SingleResponse<java.lang.Integer> handoverApp(com.seeyon.boot.transport.SingleRequest<com.seeyon.udc.dto.member.AppHanoverDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.udc.common.dto.ApplicationDto> createReturnDto(com.seeyon.boot.transport.SingleRequest<com.seeyon.udc.common.dto.ApplicationDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> deleteFormAppByGuid(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> deleteFormAppByName(com.seeyon.boot.transport.SingleRequest<java.lang.String>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.udc.common.dto.DeployParamDto> deployNormal(com.seeyon.boot.transport.SingleRequest<com.seeyon.udc.common.dto.DeployNormalDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.udc.common.dto.DeployResultDto> deployForm(com.seeyon.boot.transport.SingleRequest<com.seeyon.udc.common.dto.DeployFormDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.udc.common.dto.ApplicationDto> selectLatestDesignAppByGuid(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.udc.dto.member.ApplicationWithMemberDto> selectLatestDesignAppWithMemberByGuid(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.SingleResponse<java.util.Map<java.lang.String, java.lang.Long>> selectAppNameAndIdMapByAppNames(com.seeyon.boot.transport.SingleRequest<java.util.List<java.lang.String>>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.udc.common.dto.ApplicationDto> selectDesignAppByGuid(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.PageResponse<com.seeyon.udc.common.dto.ApplicationDto> selectAppByUser(com.seeyon.boot.transport.SingleRequest<com.seeyon.udc.dto.app.ApplicationSearchDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.udc.common.dto.ApplicationDto> selectAppByUserAndGuid(com.seeyon.boot.transport.SingleRequest<com.seeyon.udc.dto.app.ApplicationSearchDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.udc.common.dto.ApplicationDto> selectAppByUserAndId(com.seeyon.boot.transport.SingleRequest<com.seeyon.udc.dto.app.ApplicationSearchDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.udc.common.dto.ApplicationExportDto> exportAppInfos(com.seeyon.boot.transport.SingleRequest<com.seeyon.udc.common.dto.AppInfoExportDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.udc.common.dto.AppVersionDto> selectAppDeployState(com.seeyon.boot.transport.SingleRequest<com.seeyon.udc.dto.form.QueryFormInfoDto>);
    default com.seeyon.boot.transport.SingleResponse<java.lang.String> downloadApp(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    default com.seeyon.boot.transport.SingleResponse<java.lang.String> downloadAppAsync(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    default com.seeyon.boot.transport.SingleResponse<java.lang.String> downloadAppByHost(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    default com.seeyon.boot.transport.SingleResponse<java.lang.Long> importApp(com.seeyon.boot.transport.SingleRequest<java.lang.String>);
    default com.seeyon.boot.transport.SingleResponse<java.lang.Long> importAppWithDto(com.seeyon.boot.transport.SingleRequest<com.seeyon.udc.common.dto.ApplicationImportDto>);
    default com.seeyon.boot.transport.SingleResponse<java.lang.String> batchDownloadAppAsync(com.seeyon.boot.transport.SingleRequest<java.util.List<java.lang.Long>>);
    default com.seeyon.boot.transport.SingleResponse<java.lang.String> batchTransferAppAsync(com.seeyon.boot.transport.SingleRequest<java.util.List<java.lang.String>>, com.seeyon.boot.transport.SingleRequest<java.util.Map<java.lang.String, java.lang.Object>>);
    default com.seeyon.boot.transport.ListResponse<com.seeyon.udc.common.dto.ImportValidationInfo> importFormValidate(java.lang.String, com.seeyon.udc.common.dto.ApplicationCopyDto);
    default com.seeyon.boot.transport.SingleResponse<java.lang.String> importFormApp(java.lang.String, com.seeyon.udc.common.dto.ApplicationCopyDto);
    default com.seeyon.boot.transport.SingleResponse<java.lang.Long> transfer(com.seeyon.boot.transport.SingleRequest<java.lang.String>)
    default com.seeyon.boot.transport.SingleResponse<java.lang.Long> transfer(com.seeyon.boot.transport.SingleRequest<java.lang.String>, com.seeyon.boot.transport.SingleRequest<java.util.Map<java.lang.String, java.lang.Object>>)
    default com.seeyon.boot.transport.SingleResponse<com.seeyon.udc.dto.shelf.ShelfDependResponseDto> getShelfDepend(com.seeyon.boot.transport.SingleRequest<com.seeyon.udc.dto.shelf.ShelfDependRequestDto>);
    default com.seeyon.boot.transport.ListResponse<com.seeyon.udc.common.dto.DependentApplicationDto> getDependsByAppId(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    default com.seeyon.boot.transport.ListResponse<com.seeyon.udc.common.dto.DependentApplicationDto> getDependsLayoutAppInfo(com.seeyon.boot.transport.SingleRequest<com.seeyon.udc.dto.app.BaseApplicationSearchDto>);
    default com.seeyon.boot.transport.SingleResponse<com.seeyon.udc.dto.shelf.ShelfCompatibilityLockResultDto> shelfCompatibilityLock(com.seeyon.boot.transport.SingleRequest<com.seeyon.udc.dto.shelf.ShelfCompatibilityLockRequestDto>);
    default com.seeyon.boot.transport.SingleResponse<java.lang.Long> migrationApp(com.seeyon.boot.transport.SingleRequest<com.seeyon.udc.common.dto.DeployFerryDto>);
    default com.seeyon.boot.transport.ListResponse<com.seeyon.udc.common.dto.DeployRecordDto> selectDeployRecordById(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.PageResponse<com.seeyon.udc.common.dto.ApplicationDto> selectAppPageByConditions(com.seeyon.boot.transport.PageRequest);
    default com.seeyon.boot.transport.SingleResponse<java.lang.Long> createEntity(com.seeyon.boot.transport.SingleRequest<com.seeyon.udc.common.dto.EntityDto>);
    default com.seeyon.boot.transport.ListResponse<com.seeyon.udc.common.dto.AttributeGroupDto> operateBatch(com.seeyon.boot.transport.SingleRequest<java.util.List<com.seeyon.udc.common.dto.AttributeGroupDto>>);
```

### `DesignMetadataQueryAppService`（49 方法）

`com.seeyon.udc.api.DesignMetadataQueryAppService`

```java
    com.seeyon.boot.transport.SingleResponse<com.seeyon.ctp.metadata.dto.ServiceMetadataDto> selectServiceMetadata(com.seeyon.boot.transport.SingleRequest<com.seeyon.udc.dto.meta.SearchDesignMetadataDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.ctp.metadata.dto.EntityMetadataDto> selectEntityMetadata(com.seeyon.boot.transport.SingleRequest<com.seeyon.udc.dto.meta.SearchDesignMetadataDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.ctp.metadata.dto.EntityMetadataDto> selectEntityMetadataExcludeBoot(com.seeyon.boot.transport.SingleRequest<com.seeyon.udc.dto.meta.SearchDesignMetadataDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.ctp.metadata.dto.EntityMetadataDto> selectEntityMetadataByFullName(com.seeyon.boot.transport.SingleRequest<com.seeyon.udc.dto.meta.SearchDesignMetadataByFullNameDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.ctp.metadata.dto.EntityMetadataDto> selectEntityMetadataByFullNames(com.seeyon.boot.transport.SingleRequest<com.seeyon.udc.dto.meta.SearchDesignMetadataByFullNamesDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.ctp.metadata.dto.AggMetadataDto> selectAggMetadata(com.seeyon.boot.transport.SingleRequest<com.seeyon.udc.dto.meta.SearchDesignMetadataDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.ctp.metadata.dto.AggMetadataDto> selectAggMetadataExcludeBoot(com.seeyon.boot.transport.SingleRequest<com.seeyon.udc.dto.meta.SearchDesignMetadataDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.ctp.metadata.dto.AggMetadataDto> selectAggMetadataByFullName(com.seeyon.boot.transport.SingleRequest<com.seeyon.udc.dto.meta.SearchDesignMetadataByFullNameDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.ctp.metadata.dto.AggMetadataDto> selectAggMetadataByFullNames(com.seeyon.boot.transport.SingleRequest<com.seeyon.udc.dto.meta.SearchDesignMetadataByFullNamesDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.ctp.metadata.dto.EntityMetadataDto> selectEntityListByAgg(com.seeyon.boot.transport.SingleRequest<com.seeyon.udc.dto.meta.SearchDesignMetadataByFullNameDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.ctp.metadata.dto.RestApiMetadataDto> selectRestApiMetadata(com.seeyon.boot.transport.SingleRequest<com.seeyon.udc.dto.meta.SearchDesignMetadataDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.ctp.metadata.dto.RestApiMetadataDto> selectRestApiMetadataExcludeBoot(com.seeyon.boot.transport.SingleRequest<com.seeyon.udc.dto.meta.SearchDesignMetadataDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.ctp.metadata.dto.RestApiMetadataDto> selectRestApiMetadataByFullNames(com.seeyon.boot.transport.SingleRequest<com.seeyon.udc.dto.meta.SearchDesignMetadataByFullNamesDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.ctp.metadata.dto.RestApiMetadataDto> selectRestApiMetadataByFullName(com.seeyon.boot.transport.SingleRequest<com.seeyon.udc.dto.meta.SearchDesignMetadataByFullNameDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.ctp.metadata.dto.DtoMetadataDto> selectDtoMetadata(com.seeyon.boot.transport.SingleRequest<com.seeyon.udc.dto.meta.SearchDesignMetadataDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.ctp.metadata.dto.DtoMetadataDto> selectDtoMetadataExcludeBoot(com.seeyon.boot.transport.SingleRequest<com.seeyon.udc.dto.meta.SearchDesignMetadataDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.ctp.metadata.dto.DtoMetadataDto> selectDtoMetadataByFullNames(com.seeyon.boot.transport.SingleRequest<com.seeyon.udc.dto.meta.SearchDesignMetadataByFullNamesDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.ctp.metadata.dto.DtoMetadataDto> selectDtoMetadataByFullName(com.seeyon.boot.transport.SingleRequest<com.seeyon.udc.dto.meta.SearchDesignMetadataByFullNameDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.ctp.metadata.dto.EnumMetadataDto> selectEnumMetadata(com.seeyon.boot.transport.SingleRequest<com.seeyon.udc.dto.meta.SearchDesignMetadataDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.ctp.metadata.dto.EnumMetadataDto> selectEnumMetadataByFullNames(com.seeyon.boot.transport.SingleRequest<com.seeyon.udc.dto.meta.SearchDesignMetadataByFullNamesDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.ctp.metadata.dto.EnumMetadataDto> selectEnumMetadataByFullName(com.seeyon.boot.transport.SingleRequest<com.seeyon.udc.dto.meta.SearchDesignMetadataByFullNameDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.ctp.metadata.dto.AggEntityMetadataDto> selectAggEntityMetadata(com.seeyon.boot.transport.SingleRequest<com.seeyon.udc.dto.meta.SearchDesignMetadataDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.ctp.metadata.dto.AggEntityMetadataDto> selectAggEntityMetadataByCondition(com.seeyon.boot.transport.SingleRequest<com.seeyon.udc.dto.meta.UdcAppMetaDataQueryDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.ctp.metadata.dto.AggEntityMetadataDto> selectAggEntityMetadataExcludeBoot(com.seeyon.boot.transport.SingleRequest<com.seeyon.udc.dto.meta.SearchDesignMetadataDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.ctp.metadata.dto.AggEntityMetadataDto> selectAggEntityMetadataByFullName(com.seeyon.boot.transport.SingleRequest<com.seeyon.udc.dto.meta.SearchDesignMetadataByFullNameDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.ctp.metadata.dto.AggEntityMetadataDto> selectAggEntityMetadataByFullNames(com.seeyon.boot.transport.SingleRequest<com.seeyon.udc.dto.meta.SearchDesignMetadataByFullNamesDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.ctp.metadata.dto.OpenApiMetadataDto> selectOpenApiMetadata(com.seeyon.boot.transport.SingleRequest<com.seeyon.udc.dto.meta.SearchDesignMetadataDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.ctp.metadata.dto.OpenApiMetadataDto> selectOpenApiMetadataByFullNames(com.seeyon.boot.transport.SingleRequest<com.seeyon.udc.dto.meta.SearchDesignMetadataByFullNamesDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.ctp.metadata.dto.OpenApiMetadataDto> selectOpenApiMetadataByFullName(com.seeyon.boot.transport.SingleRequest<com.seeyon.udc.dto.meta.SearchDesignMetadataByFullNameDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.ctp.metadata.dto.AppServiceMetadataDto> selectAppServiceMetadata(com.seeyon.boot.transport.SingleRequest<java.lang.String>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.ctp.metadata.dto.AppServiceMetadataDto> selectAppServiceMetadataExcludeBoot(com.seeyon.boot.transport.SingleRequest<java.lang.String>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.ctp.metadata.dto.AppServiceMetadataDto> selectAppServiceMetadataByFullNames(com.seeyon.boot.transport.SingleRequest<com.seeyon.udc.dto.meta.SearchDesignMetadataByFullNamesDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.ctp.metadata.dto.AppServiceMetadataDto> selectAppServiceMetadataByFullName(com.seeyon.boot.transport.SingleRequest<com.seeyon.udc.dto.meta.SearchDesignMetadataByFullNameDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.ctp.metadata.dto.MqMetadataDto> selectMqMetadata(com.seeyon.boot.transport.SingleRequest<com.seeyon.udc.dto.meta.SearchDesignMetadataDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.ctp.metadata.dto.MqMetadataDto> selectMqMetadataExcludeBoot(com.seeyon.boot.transport.SingleRequest<com.seeyon.udc.dto.meta.SearchDesignMetadataDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.ctp.metadata.dto.MqMetadataDto> selectMqMetadataByFullNames(com.seeyon.boot.transport.SingleRequest<com.seeyon.udc.dto.meta.SearchDesignMetadataByFullNamesDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.ctp.metadata.dto.MqMetadataDto> selectMqMetadataByFullName(com.seeyon.boot.transport.SingleRequest<com.seeyon.udc.dto.meta.SearchDesignMetadataByFullNameDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.ctp.metadata.dto.DtoMetadataDto> selectEntityRelationDtoMetadata(com.seeyon.boot.transport.SingleRequest<java.lang.String>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.ctp.metadata.dto.DtoMetadataDto> selectEntityRelationDtoMetadataExcludeBoot(com.seeyon.boot.transport.SingleRequest<com.seeyon.udc.dto.meta.SearchDesignMetadataDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.ctp.metadata.dto.DtoMetadataDto> selectDtoMetadataByEntityFullNames(com.seeyon.boot.transport.SingleRequest<com.seeyon.udc.dto.meta.SearchDesignMetadataByFullNamesDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.ctp.metadata.dto.DtoMetadataDto> selectDtoMetadataByEntityFullName(com.seeyon.boot.transport.SingleRequest<com.seeyon.udc.dto.meta.SearchDesignMetadataByFullNameDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.ctp.metadata.dto.AppServiceMetadataDto> selectAppServiceMetadataByDto(com.seeyon.boot.transport.SingleRequest<com.seeyon.udc.dto.meta.SearchDesignMetadataByFullNameDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.ctp.metadata.dto.ReferMetadataDto> selectReferMetadataByEntity(com.seeyon.boot.transport.SingleRequest<com.seeyon.udc.dto.meta.SearchDesignMetadataByFullNameDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.ctp.metadata.dto.ReferAndAppMetadataDto> selectReferAndAppMetadataByEntity(com.seeyon.boot.transport.SingleRequest<com.seeyon.udc.dto.meta.SearchDesignMetadataByFullNameDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.ctp.metadata.dto.EntityMetadataDto> selectBasicDataEntityMetadata(com.seeyon.boot.transport.SingleRequest<com.seeyon.udc.dto.meta.SearchDesignMetadataDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.ctp.metadata.dto.EntityMetadataDto> selectBasicDataEntityMetadataByFullName(com.seeyon.boot.transport.SingleRequest<com.seeyon.udc.dto.meta.SearchDesignMetadataByFullNameDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.ctp.metadata.dto.EntityMetadataDto> selectBasicDataEntityMetadataByFullNames(com.seeyon.boot.transport.SingleRequest<com.seeyon.udc.dto.meta.SearchDesignMetadataByFullNamesDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.ctp.metadata.dto.PageMetadataDto> selectPageMetadataList(com.seeyon.boot.transport.SingleRequest<com.seeyon.udc.dto.meta.SearchDesignMetadataDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.ctp.metadata.dto.EnumMetadataDto> selectEnumMetadataList(com.seeyon.boot.transport.SingleRequest<java.util.List<java.lang.Long>>);
```

### `EntityAppService`（18 方法）

`com.seeyon.udc.api.EntityAppService`

```java
    com.seeyon.boot.transport.SingleResponse<java.lang.Long> create(com.seeyon.boot.transport.SingleRequest<com.seeyon.udc.common.dto.EntityDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> update(com.seeyon.boot.transport.SingleRequest<com.seeyon.udc.common.dto.EntityDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> deleteById(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> deleteByIds(com.seeyon.boot.transport.SingleRequest<java.util.List<java.lang.Long>>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.udc.common.dto.EntityDto> selectById(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.udc.common.dto.EntityDto> selectByIds(com.seeyon.boot.transport.SingleRequest<java.util.List<java.lang.Long>>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.udc.common.dto.EntityDto> selectByName(com.seeyon.boot.transport.SingleRequest<java.lang.Long>, com.seeyon.boot.transport.SingleRequest<java.lang.String>);
    com.seeyon.boot.transport.PageResponse<com.seeyon.udc.common.dto.EntityDto> selectPageByCondition(com.seeyon.boot.transport.PageRequest);
    com.seeyon.boot.transport.ListResponse<com.seeyon.udc.common.dto.EntityDto> selectListByConditions(com.seeyon.boot.transport.SingleRequest<java.util.Map<java.lang.String, java.lang.Object>>, com.seeyon.boot.transport.Sort);
    com.seeyon.boot.transport.ListResponse<com.seeyon.udc.common.dto.EntityDto> selectListByTerm(com.seeyon.boot.transport.SingleRequest<java.lang.Long>, com.seeyon.boot.transport.SingleRequest<java.lang.String>, com.seeyon.boot.transport.Sort);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.udc.common.dto.EntityDto> selectParentById(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.udc.common.dto.EntityDto> selectEntitiesByAppId4Tree(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.udc.common.dto.EntityDto> selectAggregationEntitiesByAppId4Tree(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.PageResponse<com.seeyon.udc.common.dto.EntityDto> selectChildrenByCondition(com.seeyon.boot.transport.PageRequest);
    com.seeyon.boot.transport.ListResponse<com.seeyon.udc.common.dto.EntityDto> selectPrimaryEntityByAppId(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.udc.common.dto.EntityDto> selectByPrimaryEntityId(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Long> selectRootId(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.udc.common.dto.EntityDto> selectEntityByIdsLoadAttribute(com.seeyon.boot.transport.SingleRequest<java.util.List<java.lang.Long>>);
```

### `AttributeAppService`（15 方法）

`com.seeyon.udc.api.AttributeAppService`

```java
    com.seeyon.boot.transport.SingleResponse<java.lang.Long> create(com.seeyon.boot.transport.SingleRequest<com.seeyon.udc.common.dto.AttributeDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> createBatch(com.seeyon.boot.transport.SingleRequest<java.util.List<com.seeyon.udc.common.dto.AttributeDto>>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> createBatch4System(com.seeyon.boot.transport.SingleRequest<java.util.List<com.seeyon.udc.common.dto.AttributeDto>>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> update(com.seeyon.boot.transport.SingleRequest<com.seeyon.udc.common.dto.AttributeDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> updateBatch(com.seeyon.boot.transport.SingleRequest<java.util.List<com.seeyon.udc.common.dto.AttributeDto>>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> deleteById(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> deleteByIds(com.seeyon.boot.transport.SingleRequest<java.util.List<java.lang.Long>>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.udc.common.dto.AttributeDto> selectById(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.PageResponse<com.seeyon.udc.common.dto.AttributeDto> selectPageByCondition(com.seeyon.boot.transport.PageRequest);
    com.seeyon.boot.transport.ListResponse<com.seeyon.udc.common.dto.AttributeDto> selectListByCondition(com.seeyon.boot.transport.ListRequest);
    com.seeyon.boot.transport.ListResponse<com.seeyon.udc.common.dto.AttributeDto> selectListByTerm(com.seeyon.boot.transport.SingleRequest<java.lang.Long>, com.seeyon.boot.transport.SingleRequest<java.lang.String>, com.seeyon.boot.transport.Sort);
    com.seeyon.boot.transport.ListResponse<com.seeyon.udc.common.dto.AttributeDto> selectAllAttributeByEntityId(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.udc.common.dto.AttributeDto> selectEntityAttributeList(com.seeyon.boot.transport.ListRequest);
    com.seeyon.boot.transport.ListResponse<com.seeyon.udc.common.dto.AttributeDto> selectByAttributeSetId(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.udc.common.dto.AttributeDto> selectParentEnumAttributes(com.seeyon.boot.transport.ListRequest);
```

### `AsyncAppService`（7 方法）

`com.seeyon.udc.api.AsyncAppService`

```java
    com.seeyon.boot.transport.SingleResponse<java.lang.String> createLayoutApplicationAsync(com.seeyon.boot.transport.SingleRequest<com.seeyon.udc.dto.form.LayoutApplicationDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.String> createOnlyPageApplicationAsync(com.seeyon.boot.transport.SingleRequest<com.seeyon.udc.dto.form.CreateOnlyPageApplicationDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.String> upgradeOnlyPageApplicationAsync(com.seeyon.boot.transport.SingleRequest<com.seeyon.udc.dto.form.OnlyPageApplicationUpgradeDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.String> copyLayoutAppAsync(com.seeyon.boot.transport.SingleRequest<com.seeyon.udc.common.dto.ApplicationCopyDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.String> copyOnlyPageAppAsync(com.seeyon.boot.transport.SingleRequest<com.seeyon.udc.common.dto.ApplicationCopyDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.String> transferAsync(com.seeyon.boot.transport.SingleRequest<java.util.Map<java.lang.String, java.lang.Object>>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.udc.common.concurrent.RequestStatusDto> getRequestStatus(com.seeyon.boot.transport.SingleRequest<java.lang.String>);
```

### `AppCollaborationAppService`（5 方法）

`com.seeyon.udc.api.AppCollaborationAppService`

```java
    com.seeyon.boot.transport.ListResponse<java.lang.String> selectCollaborativeAppNames();
    com.seeyon.boot.transport.ListResponse<java.lang.Long> selectCollaborativeGuid();
    void handoverApp(com.seeyon.boot.transport.SingleRequest<com.seeyon.udc.dto.member.AppHanoverDto>);
    void batchHandoverApp(com.seeyon.boot.transport.SingleRequest<com.seeyon.udc.dto.member.AppBatchHandoverDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.udc.dto.member.AppMemberInfoDto> selectAppMemberInfoListByAppIdList(com.seeyon.boot.transport.SingleRequest<java.util.List<java.lang.Long>>);
```

### `MicroFlowInfoAppService`（2 方法）

`com.seeyon.udc.api.MicroFlowInfoAppService`

```java
    com.seeyon.boot.transport.SingleResponse<java.util.Map<java.lang.String, java.util.List<java.lang.String>>> findCallConnectorAppService(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.udc.dto.microflow.MicroFlowIntegrationAppInfoDto> findCallIntegrationAppService(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
```

### `PageMetadataQuery4SfAppService`（1 方法）

`com.seeyon.udc.api.PageMetadataQuery4SfAppService`

```java
    com.seeyon.boot.transport.SingleResponse<com.seeyon.udc.dto.meta.UdcApplicationMetaData4SfDto> selectAppMetaDataByAppName(com.seeyon.boot.transport.SingleRequest<java.lang.String>);
```

### `PageProcessEventAppService`（1 方法）

`com.seeyon.udc.api.PageProcessEventAppService`

```java
    com.seeyon.boot.transport.ListResponse<com.seeyon.udc.dto.page.PageProcessEventDto> selectListByCondition(com.seeyon.boot.transport.SingleRequest<com.seeyon.udc.dto.page.PageProcessEventSearchDto>);
```

### `UdcLateralAuthCheckAppService`（1 方法）

`com.seeyon.udc.api.UdcLateralAuthCheckAppService`

```java
    com.seeyon.boot.transport.SingleResponse<java.lang.Boolean> check(com.seeyon.boot.transport.SingleRequest<com.seeyon.udc.dto.auth.UdcLateralCheckDto>);
```

## 四、枚举（3）

- `CollaboratorsChangeTypeEnum`（2 常量）：ADD, REMOVE
- `ImportStrategyEnum`（2 常量）：IGNORE, COVER
- `QueryCollaboratorsTypeEnum`（3 常量）：ALL, CREATE, PARTAKE
