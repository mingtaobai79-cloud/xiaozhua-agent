# boot-starter-qrcode：接口与方法签名

> 自动生成，勿手改。`tools/core/platform/emit_package_surfaces.py` 重跑即可。
> 构件 `com.seeyon:boot-starter-qrcode`（jar `boot-starter-qrcode-5.3.600.jar`）
> 规模：59 类 / 4 接口 / 0 注解 / 3 枚举 / 13 个关键类 / 495 方法。
> 签名逐字来自 javap 原文；已去掉 `public` 前缀与 `throws` 子句。

## 一、接口（4）

### `CtpQrCodeRuleUdcAppService`（3 方法）

`com.seeyon.boot.starter.qrcode.detection.api.CtpQrCodeRuleUdcAppService`

```java
    com.seeyon.boot.transport.ListResponse<com.seeyon.boot.starter.qrcode.domain.entity.CtpQrCodeRule> getRuleListByAppIdAndFullNames(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.qrcode.dto.validation.PartDetectionRequestDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.boot.starter.qrcode.domain.entity.CtpQrCodeRule> getRuleListByAppIdAndFieldCodes(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.qrcode.dto.validation.PartDetectionRequestDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.boot.starter.qrcode.domain.entity.CtpQrCodeRule> getRuleListByAppId(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
```

### `CtpQrCodeService`（3 方法）

`com.seeyon.boot.starter.qrcode.domain.service.CtpQrCodeService`

```java
    default com.seeyon.boot.starter.qrcode.dto.CtpQrCodeFileResultDto createCtpQrCode(com.seeyon.boot.starter.qrcode.dto.CtpQrCodeCreateRequestDto, com.seeyon.boot.starter.qrcode.dto.CtpQrCodeRuleDto);
    default com.seeyon.boot.starter.qrcode.dto.CtpQrCodeResultDto createCtpQrCodeNoRule(com.seeyon.boot.starter.qrcode.dto.CtpQrCodeCreateNoRuleRequestDto);
    default com.seeyon.boot.starter.qrcode.dto.CtpQrCodeResultDto getQrCodeByQrValue(java.lang.String);
```

### `CtpQrCodeDao`（0 方法） extends CtpQrCode>

`com.seeyon.boot.starter.qrcode.domain.dao.CtpQrCodeDao`

```java
```

### `CtpQrCodeRuleDao`（0 方法） extends CtpQrCodeRule>

`com.seeyon.boot.starter.qrcode.domain.dao.CtpQrCodeRuleDao`

```java
```

## 二、关键类（13）

### `CtpQrCodeRuleService`（27 方法）

`com.seeyon.boot.starter.qrcode.domain.service.CtpQrCodeRuleService`

```java
    java.lang.Long create(com.seeyon.boot.starter.qrcode.dto.CtpQrCodeRuleDesignDto);
    boolean checkName(java.lang.Long, java.lang.String);
    java.lang.Integer createBatch(java.util.List<com.seeyon.boot.starter.qrcode.dto.CtpQrCodeRuleDto>);
    java.lang.Integer update(com.seeyon.boot.starter.qrcode.dto.CtpQrCodeRuleDesignDto);
    java.lang.Integer updateFieldCode(com.seeyon.boot.starter.qrcode.dto.QrCodeRuleUpdateFieldCodeDto);
    java.lang.Integer update4Implement(com.seeyon.boot.starter.qrcode.dto.CtpQrCodeRuleImplementUpdateDto);
    java.lang.Integer deleteById(java.lang.Long);
    java.lang.Integer physicalDeleteById(java.lang.Long);
    java.lang.Integer deleteByIds(java.util.List<java.lang.Long>);
    java.lang.Integer deactivateById(java.lang.Long);
    com.seeyon.boot.starter.qrcode.dto.CtpQrCodeRuleDto selectById(java.lang.Long);
    com.seeyon.boot.starter.qrcode.dto.CtpQrCodeRuleDto selectByGuid(java.lang.Long);
    com.seeyon.boot.transport.PageData<com.seeyon.boot.starter.qrcode.dto.CtpQrCodeRuleDto> selectPageByCondition(com.seeyon.boot.transport.PageInfo, com.seeyon.boot.starter.qrcode.dto.CtpQrCodeRuleParamsDto, com.seeyon.boot.transport.Sort);
    java.util.List<com.seeyon.boot.starter.qrcode.dto.CtpQrCodeRuleDto> selectListByFullName(java.lang.String);
    java.util.List<com.seeyon.boot.starter.qrcode.domain.entity.CtpQrCodeRule> selectListByAppIdAndName(java.lang.Long, java.lang.String);
    java.util.List<com.seeyon.boot.starter.qrcode.dto.CtpQrCodeRuleDto> selectListByConditions(com.seeyon.boot.starter.qrcode.dto.CtpQrCodeRuleParamsDto, com.seeyon.boot.transport.Sort);
    java.util.List<com.seeyon.boot.starter.qrcode.dto.CtpQrCodeRuleDownListDto> searchForDesignDropDownList(com.seeyon.boot.starter.qrcode.dto.CtpQrCodeRuleDownListQueryDto);
    java.util.List<com.seeyon.boot.starter.qrcode.dto.CtpQrCodeRuleDto> selectListByAppGuid(java.lang.Long);
    private void paramsWrapper(com.seeyon.boot.domain.dao.Wrapper, com.seeyon.boot.starter.qrcode.dto.CtpQrCodeRuleParamsDto, com.seeyon.boot.transport.Sort);
    java.lang.Integer startUsingById(java.lang.Long);
    java.lang.Integer updateQrCodeReleaseStateByAppGuid(java.lang.Long);
    java.lang.Integer deleteByAppGuids(java.util.List<java.lang.Long>);
```

### `CtpQrCodeBaseService`（23 方法）

`com.seeyon.boot.starter.qrcode.domain.service.CtpQrCodeBaseService`

```java
    com.seeyon.boot.starter.qrcode.dto.CtpQrCodeResultDto getQrCodeResult(java.lang.Long);
    com.seeyon.boot.starter.qrcode.domain.entity.CtpQrCode getQrCodeById(java.lang.Long);
    java.lang.Integer updateQrCodeValueById(com.seeyon.boot.starter.qrcode.dto.CtpQrCodeUpdateRequestDto);
    com.seeyon.boot.starter.qrcode.domain.entity.CtpQrCode createAndUpLoad(com.seeyon.boot.starter.qrcode.domain.entity.CtpQrCode, com.seeyon.boot.util.qrcode.model.QrCodeParam);
    com.seeyon.boot.starter.qrcode.domain.entity.CtpQrCode create(com.seeyon.boot.starter.qrcode.domain.entity.CtpQrCode);
    void updateRunningData(com.seeyon.boot.starter.qrcode.domain.entity.CtpQrCode);
    com.seeyon.boot.starter.qrcode.dto.CtpQrCodeFileResultDto buildCtpQrCodeFileResult(com.seeyon.boot.starter.qrcode.domain.entity.CtpQrCode, java.lang.Boolean);
    com.seeyon.boot.starter.qrcode.dto.CtpQrCodeResultDto buildCtpQrCodeResult(com.seeyon.boot.starter.qrcode.domain.entity.CtpQrCode);
    com.seeyon.boot.starter.qrcode.domain.entity.CtpQrCode buildQrCode(com.seeyon.boot.starter.qrcode.dto.CtpQrCodeCreateRequestDto, com.seeyon.boot.starter.qrcode.dto.CtpQrCodeRuleDto);
    private void setExpireTime(com.seeyon.boot.starter.qrcode.domain.entity.CtpQrCode, java.lang.Long);
    com.seeyon.boot.starter.qrcode.domain.entity.CtpQrCode buildQrCodeNoRule(com.seeyon.boot.starter.qrcode.dto.CtpQrCodeCreateNoRuleRequestDto);
    com.seeyon.boot.starter.qrcode.domain.entity.CtpQrCode getQrCode(java.lang.Long, java.lang.Long, java.lang.Long, java.lang.String);
    com.seeyon.boot.starter.qrcode.domain.entity.CtpQrCode getQrCodeByUrl(java.lang.Long, java.lang.Long, java.lang.String);
    void updateFieldsByObjectId(com.seeyon.boot.starter.qrcode.dto.EntityDataDto);
    java.util.List<java.lang.String> downLoadQrCode(com.seeyon.boot.starter.qrcode.dto.CtpQrCodeDownloadRequestDto);
    com.seeyon.boot.starter.qrcode.dto.CtpQrCodeViewResultDto getLinkQrCode(com.seeyon.boot.starter.qrcode.dto.CtpQrCodeDownloadRequestDto);
    java.io.InputStream bufferedImageToInputStream(java.awt.image.BufferedImage, java.lang.String);
    java.util.List<com.seeyon.boot.starter.qrcode.domain.entity.CtpQrCode> selectListByAppIdAndObjectId(java.lang.Long, java.lang.Long);
    private com.seeyon.boot.starter.file.dto.request.UploadRequestDto buildUploadRequestDto(java.lang.String, java.lang.String);
    static java.lang.String sanitizeFileName(java.lang.String);
    com.seeyon.boot.starter.qrcode.dto.CtpQrCodeFileResultDto getNewQrcodeBySize(com.seeyon.boot.starter.qrcode.dto.CtpQrCodeNewBuildDto);
    private com.seeyon.boot.starter.file.dto.FileDto uploadQrCode(com.seeyon.boot.starter.qrcode.domain.entity.CtpQrCode, com.seeyon.boot.util.qrcode.model.QrCodeParam);
```

### `CtpQrCodeRuleAppService`（18 方法）

`com.seeyon.boot.starter.qrcode.appservice.CtpQrCodeRuleAppService`

```java
    com.seeyon.boot.transport.SingleResponse<java.lang.Long> create(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.qrcode.dto.CtpQrCodeRuleDesignDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> createBatch(java.util.List<com.seeyon.boot.starter.qrcode.dto.CtpQrCodeRuleDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> update(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.qrcode.dto.CtpQrCodeRuleDesignDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> updateFieldCode(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.qrcode.dto.QrCodeRuleUpdateFieldCodeDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> update4Implement(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.qrcode.dto.CtpQrCodeRuleImplementUpdateDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> deleteById(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> physicalDeleteById(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> deleteByIds(com.seeyon.boot.transport.SingleRequest<java.util.List<java.lang.Long>>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> deactivateById(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.boot.starter.qrcode.dto.CtpQrCodeRuleDto> selectById(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.boot.starter.qrcode.dto.CtpQrCodeRuleDto> selectByGuid(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.PageResponse<com.seeyon.boot.starter.qrcode.dto.CtpQrCodeRuleDto> selectPageByConditions(com.seeyon.boot.transport.PageDtoRequest<com.seeyon.boot.starter.qrcode.dto.CtpQrCodeRuleParamsDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.boot.starter.qrcode.dto.CtpQrCodeRuleDto> selectListByConditions(com.seeyon.boot.transport.ListDtoRequest<com.seeyon.boot.starter.qrcode.dto.CtpQrCodeRuleParamsDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.boot.starter.qrcode.dto.CtpQrCodeRuleDto> selectListByAppGuid(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> startUsingById(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> updateQrCodeReleaseStateByAppGuid(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> deleteByAppGuids(com.seeyon.boot.transport.SingleRequest<java.util.List<java.lang.Long>>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.boot.starter.qrcode.dto.CtpQrCodeRuleDownListDto> searchForDesignDropDownList(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.qrcode.dto.CtpQrCodeRuleDownListQueryDto>);
```

### `LinkQrCodeServiceImpl`（12 方法）

`com.seeyon.boot.starter.qrcode.domain.service.impl.LinkQrCodeServiceImpl`

```java
    com.seeyon.boot.starter.qrcode.dto.CtpQrCodeFileResultDto createCtpQrCode(com.seeyon.boot.starter.qrcode.dto.CtpQrCodeCreateRequestDto, com.seeyon.boot.starter.qrcode.dto.CtpQrCodeRuleDto);
    com.seeyon.boot.starter.qrcode.dto.CtpQrCodeResultDto createCtpQrCodeNoRule(com.seeyon.boot.starter.qrcode.dto.CtpQrCodeCreateNoRuleRequestDto);
    private com.seeyon.boot.starter.shortlink.domain.entity.CtpShortLink getShortLinkByUrl(java.lang.String, java.lang.String);
    java.lang.String createShortLink(java.lang.String, java.lang.String);
    private java.lang.String buildShortLink(java.lang.String, java.lang.String);
    static private static java.lang.String appendUrl(java.lang.String, java.lang.Long, java.lang.String);
    private java.lang.Boolean generatePublicAccessQrCode(com.seeyon.boot.starter.qrcode.dto.CtpQrCodeCreateRequestDto, com.seeyon.boot.starter.qrcode.domain.entity.CtpQrCode, com.seeyon.boot.starter.qrcode.dto.CtpQrCodeRuleDto, java.lang.String, com.seeyon.boot.starter.qrcode.domain.service.impl.LinkQrCodeServiceImpl$QrUrl);
    private void updateShortLink(java.lang.String, java.lang.String);
    private com.seeyon.boot.starter.qrcode.domain.service.impl.LinkQrCodeServiceImpl$QrUrl generateUrl(com.seeyon.boot.starter.qrcode.dto.CtpQrCodeCreateRequestDto, com.seeyon.boot.starter.qrcode.dto.CtpQrCodeRuleDto, java.lang.String);
```

### `MetadataQueryManager`（10 方法）

`com.seeyon.boot.starter.qrcode.common.MetadataQueryManager`

```java
    com.seeyon.ctp.metadata.dto.EntityMetadataDto getEntityMetadata(java.lang.String, java.lang.String);
    com.seeyon.ctp.metadata.dto.EntityMetadataDto getEntityMetadata(com.seeyon.ctp.metadata.dto.request.SearchByFullNameDto);
    com.seeyon.ctp.metadata.dto.PageMetadataDto getPageMetadataByFullName(java.lang.String, java.lang.String);
    com.seeyon.ctp.metadata.dto.PageMetadataDto getPageMetadataByFullName(java.lang.String, java.lang.String, java.lang.String, java.lang.String);
    java.util.List<com.seeyon.ctp.metadata.dto.PageMetadataDto> getUdcPageListByFullName(com.seeyon.boot.starter.qrcode.dto.CtpMetaSearchDto);
    java.util.List<com.seeyon.ctp.metadata.dto.PageMetadataDto> selectPageMetadataList(java.util.Map<java.lang.String, java.lang.Object>);
    java.lang.Long selectCtpApplicationIdByAppId(java.lang.String);
```

### `CtpQrCodeAppService`（9 方法）

`com.seeyon.boot.starter.qrcode.appservice.CtpQrCodeAppService`

```java
    com.seeyon.boot.transport.SingleResponse<com.seeyon.boot.starter.qrcode.dto.CtpQrCodeFileResultDto> createCtpQrCodeByRule(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.qrcode.dto.CtpQrCodeCreateRequestDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.boot.starter.qrcode.dto.CtpQrCodeResultDto> createCtpQrCodeNoRule(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.qrcode.dto.CtpQrCodeCreateNoRuleRequestDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> updateCtpQrCodeValueById(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.qrcode.dto.CtpQrCodeUpdateRequestDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.boot.starter.qrcode.dto.CtpQrCodeResultDto> getCtpQrCodeById(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.boot.starter.qrcode.dto.CtpQrCodeResultDto> getQrCodeByQrValue(com.seeyon.boot.transport.SingleRequest<java.lang.String>);
    com.seeyon.boot.transport.SingleResponse<java.util.List<java.lang.String>> downLoadQrCode(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.qrcode.dto.CtpQrCodeDownloadRequestDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.boot.starter.qrcode.dto.CtpQrCodeViewResultDto> getLinkQrCode(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.qrcode.dto.CtpQrCodeDownloadRequestDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.boot.starter.qrcode.dto.CtpQrCodeFileResultDto> getNewQrcodeBySize(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.qrcode.dto.CtpQrCodeNewBuildDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.ctp.metadata.dto.PageMetadataDto> getUdcPageListByFullName(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.qrcode.dto.CtpMetaSearchDto>);
```

### `EntityDataManager`（8 方法）

`com.seeyon.boot.starter.qrcode.common.EntityDataManager`

```java
    com.seeyon.boot.starter.qrcode.dto.EntityDataDto parseData(java.lang.Object);
    java.util.Map<java.lang.String, java.lang.Object> getRunningDataById(java.lang.String, java.lang.Long);
    java.lang.Integer updateRunningData(java.util.Map<java.lang.String, java.lang.Object>, java.lang.String);
    void reflexUpdateRunningData(java.util.Map<java.lang.String, java.lang.Object>, java.lang.String);
    private java.lang.String entityFullNameToDtoFullName(java.lang.String);
    private java.lang.String fullNameToSingleName(java.lang.String);
    static java.lang.String fullNameToAppName(java.lang.String);
    private java.lang.String parseEntityFullName(java.lang.Object);
```

### `CtpQrCodeUtils`（7 方法）

`com.seeyon.boot.starter.qrcode.utils.CtpQrCodeUtils`

```java
    static private static java.awt.image.BufferedImage createImage(java.lang.String, com.seeyon.boot.util.qrcode.model.QrCodeParam)
    static private static com.google.zxing.common.BitMatrix resetWhiteBorder(com.google.zxing.common.BitMatrix);
    static private static void insertLogoImage(java.awt.image.BufferedImage, com.seeyon.boot.util.qrcode.model.QrCodeParam)
    static java.awt.image.BufferedImage encode(java.lang.String, com.seeyon.boot.util.qrcode.model.QrCodeParam)
    static java.lang.String toCamelCase(java.lang.String);
    static boolean isContainChinese(java.lang.String);
    static java.lang.String shortUrl(java.lang.String);
```

### `CtpQrCodeDetectionService`（6 方法）

`com.seeyon.boot.starter.qrcode.detection.CtpQrCodeDetectionService`

```java
    void deleteQrCodeRulePartValidateToUdc(com.seeyon.boot.starter.qrcode.dto.validation.CtpQrCodeRuleDetectionDto);
    java.util.List<com.seeyon.boot.starter.qrcode.domain.entity.CtpQrCodeRule> getRuleListByAppIdAndFullNames(com.seeyon.boot.starter.qrcode.dto.validation.PartDetectionRequestDto);
    java.util.List<com.seeyon.boot.starter.qrcode.domain.entity.CtpQrCodeRule> getRuleListByAppIdAndFieldCodes(com.seeyon.boot.starter.qrcode.dto.validation.PartDetectionRequestDto);
    java.util.List<com.seeyon.boot.starter.qrcode.domain.entity.CtpQrCodeRule> getRuleListByAppId(java.lang.Long);
    java.util.List<com.seeyon.boot.starter.qrcode.domain.entity.CtpQrCodeRule> getRuleListByAppIdAndFullNames(java.lang.Long, java.util.List<java.lang.String>);
    java.util.List<com.seeyon.boot.starter.qrcode.domain.entity.CtpQrCodeRule> getRuleListByAppIdAndFieldCodes(java.lang.Long, java.util.List<java.lang.String>);
```

### `QrCodeThreadPoolManager`（6 方法）

`com.seeyon.boot.starter.qrcode.listener.QrCodeThreadPoolManager`

```java
    void afterPropertiesSet()
    void addEntityUpdateTask(com.seeyon.boot.starter.qrcode.dto.EntityDataDto);
    java.util.Queue<java.lang.Object> getMsgQueue();
```

### `BarCodeUtils`（5 方法）

`com.seeyon.boot.starter.qrcode.utils.BarCodeUtils`

```java
    static java.awt.image.BufferedImage getBarCode(java.lang.String);
    static java.awt.image.BufferedImage insertWords(java.awt.image.BufferedImage, java.lang.String);
    static private static void setGraphics2D(java.awt.Graphics2D);
    static private static void setColorWhite(java.awt.Graphics2D);
    static private static void setDrawRect(java.awt.Graphics2D);
```

### `CtpQrCodeRuleUdcAppServiceImpl`（3 方法）

`com.seeyon.boot.starter.qrcode.detection.api.CtpQrCodeRuleUdcAppServiceImpl`

```java
    com.seeyon.boot.transport.ListResponse<com.seeyon.boot.starter.qrcode.domain.entity.CtpQrCodeRule> getRuleListByAppIdAndFullNames(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.qrcode.dto.validation.PartDetectionRequestDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.boot.starter.qrcode.domain.entity.CtpQrCodeRule> getRuleListByAppIdAndFieldCodes(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.qrcode.dto.validation.PartDetectionRequestDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.boot.starter.qrcode.domain.entity.CtpQrCodeRule> getRuleListByAppId(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
```

### `FieldQrCodeServiceImpl`（3 方法）

`com.seeyon.boot.starter.qrcode.domain.service.impl.FieldQrCodeServiceImpl`

```java
    com.seeyon.boot.starter.qrcode.dto.CtpQrCodeFileResultDto createCtpQrCode(com.seeyon.boot.starter.qrcode.dto.CtpQrCodeCreateRequestDto, com.seeyon.boot.starter.qrcode.dto.CtpQrCodeRuleDto);
    private com.seeyon.boot.starter.qrcode.dto.CtpQrCodeFieldDto buildRunningFields(java.lang.String, java.lang.String, java.lang.String);
    private java.lang.String getFieldValue(java.lang.String, java.lang.Long, java.lang.String);
```

## 四、枚举（3）

- `CtpQrCodeLinkTypeEnum`（2 常量）：APP, CUSTOM
- `CtpQrCodeTypeEnum`（4 常量）：BARCODE, LINKQRCODE, FIELDQRCODE, QRCODE
- `QrCodeReleaseStateEnum`（3 常量）：DESIGN, IMPLEMENTATION, RUNNING
