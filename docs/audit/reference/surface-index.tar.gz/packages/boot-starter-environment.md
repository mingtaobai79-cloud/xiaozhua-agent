# boot-starter-environment：接口与方法签名

> 自动生成，勿手改。`tools/core/platform/emit_package_surfaces.py` 重跑即可。
> 构件 `com.seeyon:boot-starter-environment`（jar `boot-starter-environment-5.3.600.jar`）
> 规模：13 类 / 0 接口 / 0 注解 / 2 枚举 / 10 个关键类 / 77 方法。
> 签名逐字来自 javap 原文；已去掉 `public` 前缀与 `throws` 子句。

## 一、接口（0）

（本构件没有接口）

## 二、关键类（10）

### `CtpSystemEnvProperties`（17 方法）

`com.seeyon.boot.starter.system.env.CtpSystemEnvProperties`

```java
    java.util.List<com.seeyon.boot.starter.system.env.enums.CtpSystemEnvEnum> getDeploymentEnv();
    void setDeploymentEnvList(java.util.List<com.seeyon.boot.starter.system.env.enums.CtpSystemEnvEnum>);
    void setDeploymentEnv(java.lang.String);
    void setGroup(java.lang.String);
    void setEnablePageEdit(java.lang.Boolean);
    void setCheckDeploymentToProd(java.lang.Boolean);
    void setCheckDeploymentToDev(java.lang.Boolean);
    void setDeploymentEnvStr(java.lang.String);
    void setDataPushStr(java.lang.String);
    void setCurrentEnv(com.seeyon.boot.starter.system.env.enums.CtpSystemEnvEnum);
    java.lang.String getGroup();
    java.lang.Boolean getEnablePageEdit();
    java.lang.Boolean getCheckDeploymentToProd();
    java.lang.Boolean getCheckDeploymentToDev();
    java.lang.String getDeploymentEnvStr();
    java.lang.String getDataPushStr();
    com.seeyon.boot.starter.system.env.enums.CtpSystemEnvEnum getCurrentEnv();
```

### `CtpSystemEnvDto`（13 方法）

`com.seeyon.boot.starter.system.env.dto.CtpSystemEnvDto`

```java
    java.lang.String getDeploymentEnvsStr();
    java.util.List<com.seeyon.boot.starter.system.env.enums.CtpSystemEnvEnum> getDeploymentEnvs();
    com.seeyon.boot.starter.system.env.enums.CtpSystemEnvEnum getCurrentEnv();
    java.lang.Boolean getCheckDeploymentToDev();
    java.lang.String getUdc();
    java.lang.String getData();
    java.lang.String getDataPushStr();
    void setDeploymentEnvs(java.util.List<com.seeyon.boot.starter.system.env.enums.CtpSystemEnvEnum>);
    void setCurrentEnv(com.seeyon.boot.starter.system.env.enums.CtpSystemEnvEnum);
    void setCheckDeploymentToDev(java.lang.Boolean);
    void setUdc(java.lang.String);
    void setData(java.lang.String);
    void setDataPushStr(java.lang.String);
```

### `CtpSystemEnvController`（6 方法）

`com.seeyon.boot.starter.system.env.controller.CtpSystemEnvController`

```java
    com.seeyon.boot.transport.SingleResponse<java.lang.Boolean> isTargetEnvironment(com.seeyon.boot.starter.system.env.enums.CtpSystemModelType);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.boot.starter.system.env.dto.CtpSystemEnvDto> select();
    com.seeyon.boot.transport.SingleResponse<java.lang.Boolean> save(com.seeyon.boot.starter.system.env.dto.CtpSystemEnvDto, java.lang.Boolean)
    com.seeyon.boot.transport.SingleResponse<com.seeyon.boot.starter.system.env.dto.CtpSystemDirectionAllDto> selectDirection(com.seeyon.boot.starter.system.env.dto.CtpSystemEnvDto);
    com.seeyon.boot.transport.SingleResponse<java.util.List<com.seeyon.boot.starter.system.env.dto.CtpSystemEnvModelDto>> systemEnvModel(com.seeyon.boot.starter.system.env.enums.CtpSystemModelType);
    com.seeyon.boot.transport.SingleResponse<java.lang.Boolean> selectPageEdit();
```

### `CtpSystemDirectionAllDto`（6 方法）

`com.seeyon.boot.starter.system.env.dto.CtpSystemDirectionAllDto`

```java
    java.util.List<com.seeyon.boot.starter.system.env.dto.CtpSystemDirectionDto> getForm();
    java.util.List<com.seeyon.boot.starter.system.env.dto.CtpSystemDirectionDto> getData();
    java.util.List<com.seeyon.boot.starter.system.env.dto.CtpSystemDirectionDto> getUdc();
    void setForm(java.util.List<com.seeyon.boot.starter.system.env.dto.CtpSystemDirectionDto>);
    void setData(java.util.List<com.seeyon.boot.starter.system.env.dto.CtpSystemDirectionDto>);
    void setUdc(java.util.List<com.seeyon.boot.starter.system.env.dto.CtpSystemDirectionDto>);
```

### `CtpSystemDirectionDto`（6 方法）

`com.seeyon.boot.starter.system.env.dto.CtpSystemDirectionDto`

```java
    com.seeyon.boot.starter.system.env.dto.CtpSystemEnvModelDto getFrom();
    com.seeyon.boot.starter.system.env.dto.CtpSystemEnvModelDto getTo();
    java.lang.Boolean getChecked();
    void setFrom(com.seeyon.boot.starter.system.env.dto.CtpSystemEnvModelDto);
    void setTo(com.seeyon.boot.starter.system.env.dto.CtpSystemEnvModelDto);
    void setChecked(java.lang.Boolean);
```

### `CtpSystemEnvModelDto`（6 方法）

`com.seeyon.boot.starter.system.env.dto.CtpSystemEnvModelDto`

```java
    void setEnv(com.seeyon.boot.starter.system.env.enums.CtpSystemEnvEnum);
    java.lang.String getAliasName();
    java.lang.String getButtonName();
    com.seeyon.boot.starter.system.env.enums.CtpSystemEnvEnum getEnv();
    void setAliasName(java.lang.String);
    void setButtonName(java.lang.String);
```

### `CtpSystemEnvApi`（5 方法）

`com.seeyon.boot.starter.system.env.service.CtpSystemEnvApi`

```java
    boolean isTargetEnvironment();
    java.util.List<com.seeyon.boot.starter.system.env.dto.CtpSystemEnvModelDto> getCurrentModel();
    java.util.List<com.seeyon.boot.starter.system.env.dto.CtpSystemDirectionDto> getAllModel(com.seeyon.boot.starter.system.env.dto.CtpSystemEnvDto);
    java.util.List<java.lang.String> getPush(java.lang.String);
    protected void validateEnv();
```

### `CtpSystemEnvData`（4 方法）

`com.seeyon.boot.starter.system.env.service.CtpSystemEnvData`

```java
    boolean isTargetEnvironment();
    java.util.List<java.lang.String> getPush(java.lang.String);
    java.util.List<com.seeyon.boot.starter.system.env.dto.CtpSystemDirectionDto> getAllModel(com.seeyon.boot.starter.system.env.dto.CtpSystemEnvDto);
    java.util.List<com.seeyon.boot.starter.system.env.dto.CtpSystemEnvModelDto> getCurrentModel();
```

### `CtpSystemEnvUdc`（4 方法）

`com.seeyon.boot.starter.system.env.service.CtpSystemEnvUdc`

```java
    boolean isTargetEnvironment();
    java.util.List<com.seeyon.boot.starter.system.env.dto.CtpSystemEnvModelDto> getCurrentModel();
    java.util.List<java.lang.String> getPush(java.lang.String);
    java.util.List<com.seeyon.boot.starter.system.env.dto.CtpSystemDirectionDto> getAllModel(com.seeyon.boot.starter.system.env.dto.CtpSystemEnvDto);
```

### `CtpSystemAppService`（1 方法）

`com.seeyon.boot.starter.system.env.api.CtpSystemAppService`

```java
    com.seeyon.boot.transport.ListResponse<com.seeyon.boot.context.model.BuildInfo> depends(com.seeyon.boot.transport.SingleRequest<java.lang.Void>);
```

## 四、枚举（2）

- `CtpSystemEnvEnum`（5 常量）：development, prod, test, implement, pre
- `CtpSystemModelType`（3 常量）：FORM, DATA, UDC
