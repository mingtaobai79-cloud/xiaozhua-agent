# udc-starter-runtime：接口与方法签名

> 自动生成，勿手改。`tools/core/platform/emit_package_surfaces.py` 重跑即可。
> 构件 `com.seeyon:udc-starter-runtime`（jar `udc-starter-runtime-5.3.605.jar`）
> 规模：307 类 / 20 接口 / 0 注解 / 5 枚举 / 84 个关键类 / 2834 方法。
> 签名逐字来自 javap 原文；已去掉 `public` 前缀与 `throws` 子句。

## 一、接口（20）

### `UdcBpmProcessService`（8 方法）

`com.seeyon.boot.starter.udcrt.api.UdcBpmProcessService`

```java
    com.seeyon.boot.transport.SingleResponse<com.seeyon.boot.starter.udcrt.dto.BpmParameterDataDto> validUpdateFilterData(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.udcrt.dto.DataValidUpdateFilterDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.boot.starter.udcrt.dto.BpmParameterDataDto> validCreateFilterData(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.udcrt.dto.DataValidCreateFilterDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Boolean> processBpmApproval(com.seeyon.boot.transport.SingleRequest<com.seeyon.bpm.dto.message.BpmApprovalResultData>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Boolean> processBpmStop(com.seeyon.boot.transport.SingleRequest<com.seeyon.bpm.dto.message.event.BpmStopEvent>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Boolean> processBpmCancel(com.seeyon.boot.transport.SingleRequest<com.seeyon.bpm.dto.message.event.BpmCancelEvent>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Boolean> processBpmTakeBack(com.seeyon.boot.transport.SingleRequest<com.seeyon.bpm.dto.message.BpmApprovalResultData>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.boot.starter.udcrt.dto.BpmParameterDataDto> validFilterData(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.udcrt.dto.DataValidUpdateFilterDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> updateData(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.udcrt.dto.DataValidUpdateFilterDto>);
```

### `UdcSerialConfigAppService`（6 方法）

`com.seeyon.boot.starter.udcrt.api.UdcSerialConfigAppService`

```java
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> update(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.udcrt.dto.UdcSerialConfigDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.boot.starter.udcrt.dto.UdcSerialConfigDto> selectListByConditions(com.seeyon.boot.transport.ListRequest);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.boot.starter.udcrt.dto.EntityGroupAndItemDto> selectEntityList(com.seeyon.boot.transport.SingleRequest<java.lang.String>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.boot.starter.extmetadata.dto.UdcEntityMetaDataDto> selectEntityBySerialId(com.seeyon.boot.transport.ListRequest);
    com.seeyon.boot.transport.SingleResponse<java.lang.String> refreshHistoricalData(com.seeyon.boot.transport.SingleRequest<java.lang.String>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Boolean> cacheEvict(com.seeyon.boot.transport.SingleRequest<java.lang.String>);
```

### `AppDraftAppService`（5 方法）

`com.seeyon.boot.starter.udcrt.api.AppDraftAppService`

```java
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> createOrUpdate(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.udcrt.dto.AppDraftDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.boot.starter.udcrt.dto.AppDraftExistDto> exist(com.seeyon.boot.transport.SingleRequest<java.lang.String>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.boot.starter.udcrt.dto.AppDraftDto> select(com.seeyon.boot.transport.SingleRequest<java.lang.String>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> delete(com.seeyon.boot.transport.SingleRequest<java.lang.String>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> deleteAll(com.seeyon.boot.transport.SingleRequest<java.lang.String>);
```

### `SupportService`（3 方法）

`com.seeyon.boot.starter.udcrt.domain.service.functionsupport.SupportService`

```java
    java.lang.String getFunctionName();
    int getParameterSize();
    java.lang.Object calculate(java.util.List<java.lang.String>);
```

### `FormAppService`（2 方法）

`com.seeyon.boot.starter.udcrt.api.FormAppService`

```java
    com.seeyon.boot.transport.SingleResponse<java.lang.Void> loadForm(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.udcrt.dto.FormLoadParamDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.boot.context.model.BuildInfo> getHostAppDepends(com.seeyon.boot.transport.SingleRequest<java.lang.String>);
```

### `GraphqlProxyAppService`（2 方法）

`com.seeyon.boot.starter.udcrt.api.GraphqlProxyAppService`

```java
    com.seeyon.boot.transport.SingleResponse<java.lang.String> doGraphQL(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.udcrt.dto.GraphqlProxyRequestDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.String> doRest(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.udcrt.dto.RestRequestProxyDto>);
```

### `DeployNoticeService`（1 方法）

`com.seeyon.boot.starter.udcrt.api.DeployNoticeService`

```java
    default com.seeyon.boot.transport.SingleResponse<java.lang.Boolean> deployNotice(com.seeyon.boot.transport.SingleRequest<com.seeyon.udc.common.dto.ApplicationExportDto>);
```

### `FormHandler`（1 方法） extends UdcModuleBeanHandler

`com.seeyon.boot.starter.udcrt.domain.service.FormHandler`

```java
    <T> T dataProcess(com.seeyon.boot.starter.udcrt.dto.FormParamDto)
```

### `EventPublisher`（1 方法）

`com.seeyon.boot.starter.udcrt.event.publisher.EventPublisher`

```java
    <T extends java.io.Serializable> void publish(java.lang.String, T, com.seeyon.boot.starter.udcrt.event.publisher.EventPublisher$EventPhase);
```

### `AppDraftDao`（0 方法） extends AppDraft>

`com.seeyon.boot.starter.udcrt.domain.dao.AppDraftDao`

```java
```

### `AttachmentTemplateRtEntityDao`（0 方法） extends AttachmentTemplateRtEntity>

`com.seeyon.boot.starter.udcrt.domain.dao.AttachmentTemplateRtEntityDao`

```java
```

### `AttributeSnapshotDao`（0 方法） extends AttributeSnapshot>

`com.seeyon.boot.starter.udcrt.domain.dao.AttributeSnapshotDao`

```java
```

### `CustomApplicationDao`（0 方法） extends CustomApplication>

`com.seeyon.boot.starter.udcrt.domain.dao.CustomApplicationDao`

```java
```

### `IdToKeyMapEntityDao`（0 方法） extends IdToKeyMapEntity>

`com.seeyon.boot.starter.udcrt.domain.dao.IdToKeyMapEntityDao`

```java
```

### `UdcAppLogDao`（0 方法） extends UdcAppLog>

`com.seeyon.boot.starter.udcrt.domain.dao.UdcAppLogDao`

```java
```

### `UdcDataFlowLogDao`（0 方法） extends UdcDataFlowLog>

`com.seeyon.boot.starter.udcrt.domain.dao.UdcDataFlowLogDao`

```java
```

### `UdcDeductionLogDao`（0 方法） extends UdcDeductionLog>

`com.seeyon.boot.starter.udcrt.domain.dao.UdcDeductionLogDao`

```java
```

### `UdcEntityMonitorLogDao`（0 方法） extends UdcEntityMonitorLog>

`com.seeyon.boot.starter.udcrt.domain.dao.UdcEntityMonitorLogDao`

```java
```

### `UdcRtPageLogDao`（0 方法） extends UdcRtPageLog>

`com.seeyon.boot.starter.udcrt.domain.dao.UdcRtPageLogDao`

```java
```

### `UdcSerialConfigDao`（0 方法） extends UdcSerialConfig>

`com.seeyon.boot.starter.udcrt.domain.dao.UdcSerialConfigDao`

```java
```

## 二、关键类（84）

### `DisplayNameAppService`（120 方法）

`com.seeyon.boot.starter.udcrt.appservice.DisplayNameAppService`

```java
    static private static <T> java.util.Map<java.lang.String, java.util.Map<java.lang.String, java.lang.Object>> getCustomDataTypeFieldNameValueMap(java.util.Map<java.lang.String, java.util.List<java.lang.String>>, T);
    static private static void resetNullIds(java.util.Set<java.lang.Long>, java.util.List<java.util.Map<java.lang.String, java.lang.Object>>);
    <T extends com.seeyon.udc.common.dto.BaseEntityActionDto> com.seeyon.boot.transport.SingleResponse<java.util.Map<java.lang.String, ?>> handleBpmPermissionAndToMap(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.udcrt.dto.DisplayNameRequestDto<T>>);
    <T extends com.seeyon.boot.transport.BaseDto> com.seeyon.boot.transport.SingleResponse<java.util.Map<java.lang.String, ?>> toMap(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.udcrt.dto.DisplayNameRequestDto<T>>);
    <T extends com.seeyon.boot.transport.BaseDto> com.seeyon.boot.transport.ListResponse<java.util.Map<java.lang.String, ?>> toMapList(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.udcrt.dto.DisplayNameRequestDto<T>>);
    private java.util.Map<java.lang.String, java.util.Set<java.lang.String>> getAppNameEntityFullNameFieldNamesMap(java.util.Map<java.lang.reflect.Field, org.apache.commons.lang3.tuple.Pair<java.lang.String, java.lang.String>>, java.util.Map<java.lang.String, com.seeyon.udc.common.dto.datasource.RuntimeDataSourceAssAttributeInfoDto>);
    java.util.Map<java.lang.String, java.lang.Object> getIdDisplayNameObjectMap(java.util.List<com.seeyon.boot.starter.graphql.dto.AppServiceDisplayNameIdsProDto>);
    java.util.Map<java.lang.String, java.lang.Object> doGetDisplayNameMap(com.seeyon.boot.starter.graphql.dto.AppServiceDisplayNameIdsProDto);
    private java.util.Map<java.lang.String, ?> getIdDisplayNameObjectMap(java.util.List<com.seeyon.boot.starter.graphql.dto.AppServiceDisplayNameIdProDto>, java.util.Map<java.lang.String, java.util.Set<java.lang.String>>, java.util.Map<java.lang.String, java.util.List<com.seeyon.udc.common.dto.datasource.RuntimeDataSourceAssAttributeInfoDto>>);
    private void doAssAttributeMask(java.util.List<?>, java.lang.String, java.util.Map<java.lang.String, java.util.List<com.seeyon.udc.common.dto.datasource.RuntimeDataSourceAssAttributeInfoDto>>);
    private com.seeyon.boot.starter.graphql.dto.AppServiceDisplayNameIdsProDto buildAppServiceDisplayNameIdsDto(java.util.List<com.seeyon.boot.starter.graphql.dto.AppServiceDisplayNameIdProDto>, java.util.Map<java.lang.String, java.util.Set<java.lang.String>>);
    java.util.List<?> dynamicSelectByIds(com.seeyon.boot.starter.graphql.dto.AppServiceDisplayNameIdsProDto);
    private java.util.List<?> doDynamicSelectByIds(com.seeyon.boot.starter.graphql.dto.AppServiceDisplayNameIdsProDto);
    private <T> java.util.Map<java.lang.String, java.lang.reflect.Field> getFieldMap(java.lang.Class<T>);
    private <T> java.util.Map<java.lang.reflect.Field, org.apache.commons.lang3.tuple.Pair<java.lang.String, java.lang.String>> getRelationFieldMap(java.lang.Class<T>);
    private java.lang.String getEntityFullNameByDtoFullName(java.util.Map<java.lang.String, java.lang.String>, java.lang.String, java.lang.String);
    private <T> java.util.Map<java.lang.Object, java.util.Map<java.lang.String, org.apache.commons.lang3.tuple.Pair<java.lang.String, com.seeyon.boot.starter.graphql.dto.AppServiceDisplayNameIdProDto>>> getFieldNameDisplayNameIdDtoMap(java.util.Map<java.lang.Object, T>, java.util.Map<java.lang.reflect.Field, org.apache.commons.lang3.tuple.Pair<java.lang.String, java.lang.String>>, java.util.Map<java.lang.String, com.seeyon.udc.common.dto.datasource.RuntimeDataSourceAssAttributeInfoDto>, java.lang.String);
    private <T> java.util.Map<java.lang.String, org.apache.commons.lang3.tuple.Pair<java.lang.String, com.seeyon.boot.starter.graphql.dto.AppServiceDisplayNameIdProDto>> getFieldNameDisplayNameIdDtoMap(T, java.util.Map<java.lang.reflect.Field, org.apache.commons.lang3.tuple.Pair<java.lang.String, java.lang.String>>, java.util.Map<java.lang.String, com.seeyon.udc.common.dto.datasource.RuntimeDataSourceAssAttributeInfoDto>, java.lang.String);
    private <T extends com.seeyon.boot.transport.BaseDto> com.seeyon.boot.transport.SingleResponse<java.util.Map<java.lang.String, ?>> toMap(T, com.seeyon.udc.common.dto.datasource.RuntimeEntityDataSourceDto);
    private <T extends com.seeyon.boot.transport.BaseDto> java.util.Map<java.lang.String, ?> toMapWithoutResponse(T, com.seeyon.udc.common.dto.datasource.RuntimeEntityDataSourceDto);
    private <T extends com.seeyon.boot.transport.BaseDto> java.util.List<java.util.Map<java.lang.String, ?>> toGenericMapList(java.util.List<T>, com.seeyon.udc.common.dto.datasource.RuntimeEntityDataSourceDto, java.lang.String);
    private <T> void fillCustomDataTypeDisplayFieldName(java.util.Collection<T>, java.util.Map<java.lang.Object, java.util.Map<java.lang.String, java.lang.Object>>, java.util.Map<java.lang.String, java.util.List<java.lang.String>>);
    private java.util.Map<java.lang.String, java.util.List<java.lang.String>> getCustomDataTypeFieldNameMap(java.util.Map<java.lang.String, com.seeyon.boot.starter.extmetadata.dto.UdcAttributeMetaDataDto>, java.lang.String[]);
    private <T> java.util.Map<java.lang.Object, java.util.Map<java.lang.String, java.util.Map<java.lang.String, java.lang.Object>>> getCustomDataTypeFieldNameValueMap(java.util.Map<java.lang.Object, T>, java.util.Map<java.lang.String, java.util.List<java.lang.String>>);
    private <T extends com.seeyon.boot.transport.BaseDto> void dealOneToOneToMap(java.util.List<T>, java.util.Map<java.lang.Object, java.util.Map<java.lang.String, java.lang.Object>>, com.seeyon.udc.common.dto.datasource.RuntimeDataSourceEntityInfoDto, java.util.Map<java.lang.String, java.util.List<com.seeyon.boot.starter.extmetadata.dto.UdcAttributeMetaDataDto>>, java.lang.String);
    private <T extends com.seeyon.boot.transport.BaseDto> void dealOneToManyToMap(java.util.List<T>, java.util.Map<java.lang.Object, java.util.Map<java.lang.String, java.lang.Object>>, java.util.List<com.seeyon.udc.common.dto.datasource.RuntimeEntityDataSourceDto>, java.lang.String);
    private <T extends com.seeyon.boot.transport.BaseDto> java.util.Map<java.lang.Object, java.util.Map<java.lang.String, java.lang.Object>> one2oneFillDisplayName(java.util.List<T>, java.util.Map<java.lang.Object, java.util.Map<java.lang.String, java.lang.Object>>, com.seeyon.udc.common.dto.datasource.RuntimeDataSourceEntityInfoDto, java.util.Map<java.lang.String, com.seeyon.boot.starter.extmetadata.dto.UdcAttributeMetaDataDto>, java.lang.String);
    private <T> void doFillDisplayNameWithSnapshot(java.util.Collection<T>, java.util.Map<java.lang.Object, java.util.Map<java.lang.String, java.lang.Object>>, java.util.Map<java.lang.String, com.seeyon.boot.starter.extmetadata.dto.UdcAttributeMetaDataDto>, java.util.Map<java.lang.reflect.Field, org.apache.commons.lang3.tuple.Pair<java.lang.String, java.lang.String>>, java.util.Map<java.lang.String, com.seeyon.udc.common.dto.datasource.RuntimeDataSourceAssAttributeInfoDto>, java.lang.String);
    private java.util.Map<java.lang.Long, java.util.Map<java.lang.Long, com.seeyon.boot.starter.lowcode.dto.AttributeSnapshotDto>> snapshotData2Map(java.util.List<com.seeyon.boot.starter.lowcode.dto.AttributeSnapshotDto>);
    private <T> void fillDisplayNameToMapBatch(java.util.Collection<T>, java.util.Map<java.lang.Object, java.util.Map<java.lang.String, java.lang.Object>>, java.util.Map<java.lang.String, com.seeyon.boot.starter.extmetadata.dto.UdcAttributeMetaDataDto>, java.util.Map<java.lang.reflect.Field, org.apache.commons.lang3.tuple.Pair<java.lang.String, java.lang.String>>, java.util.Map<java.lang.String, com.seeyon.udc.common.dto.datasource.RuntimeDataSourceAssAttributeInfoDto>, java.lang.String, java.util.Map<java.lang.Object, java.util.Map<java.lang.String, org.apache.commons.lang3.tuple.Pair<java.lang.String, com.seeyon.boot.starter.graphql.dto.AppServiceDisplayNameIdProDto>>>);
    private java.util.Map<java.lang.Long, com.seeyon.boot.starter.extmetadata.dto.UdcAttributeMetaDataDto> getSnapshotAttributeMetaDataDtoMap(java.util.Map<java.lang.String, com.seeyon.boot.starter.extmetadata.dto.UdcAttributeMetaDataDto>, java.util.Map<java.lang.String, com.seeyon.udc.common.dto.datasource.RuntimeDataSourceAssAttributeInfoDto>);
    private java.util.Map<java.lang.String, java.util.List<com.seeyon.boot.starter.extmetadata.dto.UdcAttributeMetaDataDto>> getAttributeMetaDataDtoMap(com.seeyon.udc.common.dto.datasource.RuntimeEntityDataSourceDto);
    private int doFillDisplayNameToMap(java.util.Map<java.lang.Object, java.util.Map<java.lang.String, java.lang.Object>>, java.util.Map<java.lang.String, com.seeyon.boot.starter.extmetadata.dto.UdcAttributeMetaDataDto>, java.util.Map<java.lang.Object, java.util.Map<java.lang.String, org.apache.commons.lang3.tuple.Pair<java.lang.String, com.seeyon.boot.starter.graphql.dto.AppServiceDisplayNameIdProDto>>>, java.util.Map<java.lang.String, java.util.Set<java.lang.String>>, java.util.List<com.seeyon.boot.starter.graphql.dto.AppServiceDisplayNameIdProDto>, java.util.Map<java.lang.String, com.seeyon.udc.common.dto.datasource.RuntimeDataSourceAssAttributeInfoDto>);
    private <T> void fillDisplayFieldName(java.util.Map<java.lang.String, java.lang.Object>, java.util.Map<java.lang.String, java.lang.Object>, java.util.Map<java.lang.String, java.util.Map<java.lang.String, java.lang.Object>>);
    private <T> void fillDisplayFieldName(java.util.Map<java.lang.String, java.lang.Object>, java.util.Map<java.lang.String, com.seeyon.boot.starter.extmetadata.dto.UdcAttributeMetaDataDto>, java.lang.String[], java.util.Map<java.lang.String, ?>, java.util.Map<java.lang.String, org.apache.commons.lang3.tuple.Pair<java.lang.String, com.seeyon.boot.starter.graphql.dto.AppServiceDisplayNameIdProDto>>);
    private void doMask(java.util.Map<java.lang.String, com.seeyon.boot.starter.extmetadata.dto.UdcAttributeMetaDataDto>, java.util.Collection<java.util.Map<java.lang.String, java.lang.Object>>, com.seeyon.udc.common.dto.datasource.RuntimeDataSourceEntityInfoDto);
    private void doMask(java.util.Map<java.lang.String, com.seeyon.boot.starter.extmetadata.dto.UdcAttributeMetaDataDto>, java.util.Collection<java.util.Map<java.lang.String, java.lang.Object>>);
    private java.lang.String maskReverse(java.lang.String, com.seeyon.boot.annotation.enums.MaskType);
    private java.util.Map<java.lang.String, com.seeyon.boot.starter.extmetadata.dto.UdcAttributeMetaDataDto> getEntityAttributeMetaDataMap(com.seeyon.udc.common.dto.datasource.RuntimeDataSourceEntityInfoDto, java.util.Map<java.lang.String, java.util.List<com.seeyon.boot.starter.extmetadata.dto.UdcAttributeMetaDataDto>>);
    private void handlerSFOrganizationDefaultField(com.seeyon.udc.common.dto.datasource.RuntimeEntityDataSourceDto);
    private void handlerSFOrganizationDefaultField(com.seeyon.udc.common.dto.datasource.RuntimeDataSourceEntityInfoDto);
    void clear(java.lang.Class<?>);
    void onUnLoad(com.seeyon.udc.common.dto.AppInfoDto);
    void onCompleteLoad(com.seeyon.udc.common.dto.AppInfoDto);
    static private static java.lang.Object $deserializeLambda$(java.lang.invoke.SerializedLambda);
```

### `UdcPageProxyAppService`（61 方法）

`com.seeyon.boot.starter.udcrt.appservice.UdcPageProxyAppService`

```java
    com.seeyon.boot.transport.SingleResponse<java.lang.Long> create(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.udcrt.proxy.dto.UdcRestRequestDto<java.util.Map<java.lang.String, java.lang.Object>>>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> createBatch(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.udcrt.proxy.dto.UdcRestRequestDto<java.util.List<java.util.Map<java.lang.String, java.lang.Object>>>>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> deleteById(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.udcrt.proxy.dto.UdcRestRequestDto<java.lang.Long>>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> deleteByIds(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.udcrt.proxy.dto.UdcRestRequestDto<java.util.List<java.lang.Long>>>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> update(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.udcrt.proxy.dto.UdcRestRequestDto<java.util.Map<java.lang.String, java.lang.Object>>>);
    com.seeyon.boot.transport.SingleResponse<java.util.Map<java.lang.String, ?>> updateWithResult(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.udcrt.proxy.dto.UdcRestRequestDto<java.util.Map<java.lang.String, java.lang.Object>>>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> updateBatch(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.udcrt.proxy.dto.UdcRestRequestDto<java.util.List<java.util.Map<java.lang.String, java.lang.Object>>>>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.udc.common.dto.ResultDto> create4Bpm(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.udcrt.proxy.dto.UdcRestRequestDto<java.util.Map<java.lang.String, java.lang.Object>>>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.udc.common.dto.ResultDto> update4Bpm(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.udcrt.proxy.dto.UdcRestRequestDto<java.util.Map<java.lang.String, java.lang.Object>>>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> operateRootBatch(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.udcrt.proxy.dto.UdcRestRequestDto<java.util.List<java.util.Map<java.lang.String, java.lang.Object>>>>);
    com.seeyon.boot.transport.SingleResponse<java.util.Map<java.lang.String, ?>> selectCascadeById4Bpm(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.udcrt.proxy.dto.UdcRestRequestDto<com.seeyon.boot.starter.udcrt.dto.BillSearchRequestDto>>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.udc.common.dto.SingleForwardDataDto> forwardCascadeByConditions(com.seeyon.boot.transport.SingleRequest<com.seeyon.udc.common.dto.SingleForwardDto>);
    com.seeyon.boot.transport.SingleResponse<java.util.Map<java.lang.String, ?>> runtimeCopy(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.udcrt.proxy.dto.UdcRestRequestDto<java.lang.Long>>);
    com.seeyon.boot.transport.SingleResponse<java.util.Map<java.lang.String, ?>> getCascadeDefaultValue(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.udcrt.proxy.dto.UdcRestRequestDto<java.lang.Void>>);
    com.seeyon.boot.transport.SingleResponse<java.util.Map<java.lang.String, ?>> selectCascadeByConditions(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.udcrt.proxy.dto.UdcRestRequestDto<com.seeyon.boot.starter.udcrt.dto.PageCustomSearchDto>>);
    com.seeyon.boot.transport.PageResponse<java.util.Map<java.lang.String, ?>> dynamicJoinSelect(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.udcrt.proxy.dto.UdcRestRequestDto<com.seeyon.boot.starter.udcrt.dto.FilterPlanDynamicSelectDto>>);
    com.seeyon.boot.transport.PageResponse<java.util.Map<java.lang.String, ?>> dynamicSelect4FilterPlan(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.udcrt.proxy.dto.UdcRestRequestDto<com.seeyon.boot.starter.udcrt.dto.FilterPlanDynamicSelectDto>>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> dynamicJoinSelectCount(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.udcrt.proxy.dto.UdcRestRequestDto<com.seeyon.boot.starter.udcrt.dto.FilterPlanDynamicSelectDto>>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> dynamicSelect4FilterPlanCount(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.udcrt.proxy.dto.UdcRestRequestDto<com.seeyon.boot.starter.udcrt.dto.FilterPlanDynamicSelectDto>>);
    com.seeyon.boot.transport.ListResponse<java.util.Map<java.lang.String, ?>> selectAllChildren4HighestTree(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.udcrt.proxy.dto.UdcRestRequestDto<com.seeyon.boot.starter.udcrt.dto.TreeQueryDto>>);
    com.seeyon.boot.transport.PageResponse<java.util.Map<java.lang.String, ?>> selectHighestTree(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.udcrt.proxy.dto.UdcRestRequestDto<com.seeyon.boot.starter.udcrt.dto.TreeQueryDto>>);
    com.seeyon.boot.transport.PageResponse<java.util.Map<java.lang.String, ?>> selectTreeGrid(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.udcrt.proxy.dto.UdcRestRequestDto<com.seeyon.boot.starter.udcrt.dto.TreeQueryDto>>);
    com.seeyon.boot.transport.BaseResponse microFlowPost(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.udcrt.proxy.dto.UdcRestRequestDto<java.lang.Object>>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Object> selectById(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.udcrt.proxy.dto.UdcRestRequestDto<java.lang.Long>>);
    com.seeyon.boot.transport.ListResponse<java.lang.Object> selectByIds(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.udcrt.proxy.dto.UdcRestRequestDto<java.util.List<java.lang.Long>>>);
    com.seeyon.boot.transport.ListResponse<java.util.Map<java.lang.String, ?>> selectCascadeListByConditions(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.udcrt.proxy.dto.UdcRestRequestDto<com.seeyon.boot.starter.udcrt.dto.PageCustomSearchDto>>);
    com.seeyon.boot.transport.PageResponse<java.util.Map<java.lang.String, ?>> searchPageByCondition4Refer(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.udcrt.proxy.dto.UdcRestRequestDto<com.seeyon.boot.starter.udcrt.proxy.dto.UdcReferTreeRequestDto>>);
    com.seeyon.boot.transport.ListResponse<java.util.Map<java.lang.String, ?>> selectListByConditions4Refer(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.udcrt.proxy.dto.UdcRestRequestDto<com.seeyon.boot.transport.ListRequest>>);
    com.seeyon.boot.transport.ListResponse<java.util.Map<java.lang.String, ?>> selectTree(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.udcrt.proxy.dto.UdcRestRequestDto<com.seeyon.boot.starter.udcrt.dto.TreeQueryDto>>);
    com.seeyon.boot.transport.PageResponse<java.util.Map<java.lang.String, ?>> selectHighestTree4Refer(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.udcrt.proxy.dto.UdcRestRequestDto<com.seeyon.boot.starter.udcrt.proxy.dto.UdcReferTreeRequestDto>>);
    com.seeyon.boot.transport.ListResponse<java.util.Map<java.lang.String, ?>> selectAllChildren4Highest4Refer(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.udcrt.proxy.dto.UdcRestRequestDto<com.seeyon.boot.starter.udcrt.proxy.dto.UdcReferTreeRequestDto>>);
    com.seeyon.boot.transport.PageResponse<java.util.Map<java.lang.String, ?>> searchPageByCondition(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.udcrt.proxy.dto.UdcRestRequestDto<com.seeyon.boot.starter.udcrt.proxy.dto.UdcReferTreeRequestDto>>);
    com.seeyon.boot.transport.SingleResponse<java.lang.String> exportExcel(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.udcrt.proxy.dto.UdcRestRequestDto<com.seeyon.boot.starter.udcrt.dto.ExcelDynamicExportDto>>);
    private com.seeyon.boot.transport.SingleResponse<java.util.Map<java.lang.String, ?>> selectCascadeByConditions(com.seeyon.boot.starter.udcrt.proxy.dto.UdcEntityRequestDto, com.seeyon.boot.starter.udcrt.dto.RuntimePageCustomSearchDto, com.seeyon.udc.common.dto.datasource.RuntimeEntityDataSourceDto);
    private <T, U> U proxyEntityAppServiceMethod(com.seeyon.boot.starter.udcrt.proxy.dto.UdcRestRequestDto<T>);
    private <T, R, U> U proxyEntityAppServiceMethod(com.seeyon.boot.starter.udcrt.proxy.dto.UdcRestRequestDto<T>, java.util.function.BiFunction<com.seeyon.boot.starter.udcrt.proxy.dto.UdcRestPathParseDto, T, R>);
    private com.seeyon.boot.starter.udcrt.dto.ReferenceDynamicSelectDto<com.seeyon.boot.transport.BaseDto> getReferenceDynamicSelectDto(com.seeyon.boot.starter.udcrt.proxy.dto.UdcRestPathParseDto);
    private void changeTreeData(com.seeyon.boot.starter.udcrt.proxy.dto.UdcRestPathParseDto, com.seeyon.boot.starter.udcrt.dto.TreeQueryDto, com.seeyon.udc.common.dto.datasource.RuntimeEntityDataSourceDto, int);
    private com.seeyon.udc.common.dto.datasource.RuntimeEntityDataSourceDto getRuntimeEntityDataSourceByDto(com.seeyon.boot.starter.udcrt.dto.RuntimePageCustomSearchDto);
    private com.seeyon.udc.common.dto.datasource.RuntimeEntityDataSourceDto getRuntimeEntityDataSourceByControlId(com.seeyon.boot.starter.udcrt.proxy.dto.UdcRestPathParseDto);
    private com.seeyon.udc.common.dto.datasource.RuntimeEntityDataSourceDto getRuntimeEntityDataSourceByControlId(java.lang.String, java.lang.String, java.lang.String);
    private com.seeyon.udc.common.dto.ReferRuntimeConfigDto getReferConfigById(java.lang.String, java.lang.String);
    private com.seeyon.udc.common.dto.datasource.RuntimeEntityDataSourceDto getReferRuntimeEntityDataSourceByControlId(java.lang.String, java.lang.String);
    com.seeyon.boot.transport.PageResponse<java.util.Map<java.lang.String, ?>> dataFlowDynamicSelect(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.udcrt.proxy.dto.UdcRestRequestDto<com.seeyon.boot.starter.udcrt.proxy.dto.UdcDataFlowBaseRequestDto>>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.udc.common.dto.DataFlowResultDto> executeDataFlow(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.udcrt.proxy.dto.UdcRestRequestDto<com.seeyon.boot.starter.udcrt.proxy.dto.UdcDataFlowBaseRequestDto>>);
    private com.seeyon.udc.common.dto.datasource.RuntimeEntityDataSourceDto getDataFlowRuntimeEntityDataSourceByRestMappingName(java.lang.String, java.lang.String);
    private com.seeyon.udc.common.dto.DataFlowPlanRuntimeDto getDataFlowPlanRuntimeByRestMappingName(java.lang.String, java.lang.String);
    private java.lang.String getReferConfigKey(java.lang.String, java.lang.String);
    private java.lang.String getReferDataSourceKey(java.lang.String, java.lang.String);
    private java.lang.String getDataSourceKey(java.lang.String, java.lang.String, java.lang.String);
    private java.lang.String selectSingleControlId(com.seeyon.boot.starter.extmetadata.dto.UdcPageMetadataV2Dto, java.lang.String, java.lang.String);
    private void getRunTimeEntityDataSourceControlIddMap(com.seeyon.udc.common.dto.datasource.RuntimeEntityDataSourceDto, java.util.Map<java.lang.String, com.seeyon.udc.common.dto.datasource.RuntimeEntityDataSourceDto>);
    private void checkSupportForward(java.lang.String);
    com.seeyon.boot.transport.ListResponse<java.lang.Boolean> checkPageExistsByConditions(com.seeyon.boot.transport.SingleRequest<java.util.List<com.seeyon.boot.starter.udcrt.dto.UdcRtPageExistsDto>>);
    private boolean isUdcApp(java.lang.String);
    private boolean isUdcOuterTreeEntity(com.seeyon.boot.starter.extmetadata.dto.UdcSimpleEntityMetaDataDto);
```

### `UdcAppLogHelper`（61 方法）

`com.seeyon.boot.starter.udcrt.util.UdcAppLogHelper`

```java
    static org.springframework.data.redis.core.ValueOperations<java.lang.String, java.lang.String> getStringValueMap();
    static void buildMfLogV2(java.lang.String, com.seeyon.udc.common.enums.ModuleSubTypeEnum, java.lang.String, java.lang.String, java.lang.Long, java.lang.String);
    static void buildMfLog(java.lang.String, com.seeyon.udc.common.enums.ModuleSubTypeEnum, java.lang.String, java.lang.String, java.lang.Long);
    static void buildInputLog(java.lang.String, com.seeyon.udc.common.enums.ModuleSubTypeEnum, java.lang.Object, java.lang.Long);
    static void buildInputLog(java.lang.String, com.seeyon.udc.common.enums.ModuleSubTypeEnum, java.lang.String, java.lang.Long);
    static void buildEndLog(java.lang.String, java.lang.Object, java.lang.Long);
    static void buildEndLog(java.lang.String, java.lang.String, java.lang.Long);
    static void buildActivityStartLog(java.lang.String, com.seeyon.udc.common.enums.MicroFlowActivityTypeEnum, java.lang.String, java.lang.Object, java.lang.String, java.lang.Long);
    static void buildActivityStartLog(java.lang.String, com.seeyon.udc.common.enums.MicroFlowActivityTypeEnum, java.lang.String, java.lang.String, java.lang.String, java.lang.Long);
    static void buildForActivityStartLog(java.lang.String, com.seeyon.udc.common.enums.MicroFlowActivityTypeEnum, java.lang.String, java.lang.String, java.lang.String, java.lang.Integer, java.lang.Long);
    static void buildActivityEndLog(java.lang.String, com.seeyon.udc.common.enums.MicroFlowActivityTypeEnum, java.lang.String, java.lang.Object, java.lang.String, java.lang.String, boolean, java.lang.Long);
    static void buildActivityEndLog(java.lang.String, com.seeyon.udc.common.enums.MicroFlowActivityTypeEnum, java.lang.String, java.lang.Object, java.lang.String, boolean, java.lang.Long);
    static void buildActivityEndLog(java.lang.String, com.seeyon.udc.common.enums.MicroFlowActivityTypeEnum, java.lang.String, java.lang.String, java.lang.String, boolean, java.lang.Long);
    static void buildSubMfStartLog(java.lang.String, java.lang.String, java.lang.String, java.lang.Object, java.lang.String, java.lang.Long);
    static void buildSubMfStartLog(java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.Long);
    static void buildSubMfEndLog(java.lang.String, java.lang.String, java.lang.String, java.lang.Object, java.lang.String, boolean, java.lang.Long);
    static void buildSubMfEndLog(java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String, boolean, java.lang.Long);
    static void buildErrorLog(java.lang.String, com.seeyon.udc.common.enums.MicroFlowActivityTypeEnum, java.lang.String, java.lang.Object, java.lang.String, boolean, java.lang.Long);
    static void buildErrorLog(java.lang.String, com.seeyon.udc.common.enums.MicroFlowActivityTypeEnum, java.lang.String, java.lang.String, java.lang.String, boolean, java.lang.Long);
    static void buildTraceAndRequest(java.lang.String);
    static java.lang.String buildTraceMapKey(java.lang.String);
    static java.lang.String buildForTraceMapKey(java.lang.String, int, java.lang.String);
    static java.lang.String buildTraceIdAndMethodKey(java.lang.String);
    static private static com.seeyon.boot.starter.udcrt.dto.UdcAppLogDto addUdcAppLogDto(java.lang.String, com.seeyon.udc.common.enums.ModuleSubTypeEnum, java.lang.String, java.lang.String, com.seeyon.udc.common.enums.MicroFlowActivityTypeEnum, java.lang.String, java.lang.Object, java.lang.String, java.lang.String, java.lang.String, java.lang.Integer, java.lang.Long);
    static private static com.seeyon.boot.starter.udcrt.dto.UdcAppLogDto addUdcAppLogDto(java.lang.String, com.seeyon.udc.common.enums.ModuleSubTypeEnum, java.lang.String, java.lang.String, com.seeyon.udc.common.enums.MicroFlowActivityTypeEnum, java.lang.String, java.lang.Object, java.lang.String, java.lang.String, java.lang.String, java.lang.Long);
    static private static com.seeyon.boot.starter.udcrt.dto.UdcAppLogDto addUdcAppLogDto(java.lang.String, com.seeyon.udc.common.enums.ModuleSubTypeEnum, java.lang.String, java.lang.String, com.seeyon.udc.common.enums.MicroFlowActivityTypeEnum, java.lang.String, java.lang.Object, java.lang.String, java.lang.String, java.lang.Boolean, java.lang.Long, java.lang.String, java.lang.Integer, java.lang.Long);
    static private static void addTraceMethodSet(java.lang.String, com.seeyon.udc.common.enums.LogModuleEnum, java.lang.String);
    static com.seeyon.boot.starter.udcrt.dto.UdcBaseRuntimeLogDto getTailByRedis(java.lang.String);
    static com.seeyon.boot.starter.udcrt.dto.UdcBaseRuntimeLogDto getHeadByRedis(java.lang.String);
    static void rightPushLog(java.lang.String, com.seeyon.boot.starter.udcrt.dto.UdcBaseRuntimeLogDto);
    static java.lang.Integer getListSize(java.lang.String);
    static java.util.List<com.seeyon.boot.starter.udcrt.dto.UdcBaseRuntimeLogDto> getAllLogsByTraceKey(java.lang.String, com.seeyon.udc.common.enums.LogModuleEnum, java.lang.String);
    static private static void addLogsForSignature(java.util.List<com.seeyon.boot.starter.udcrt.dto.UdcBaseRuntimeLogDto>, java.lang.String);
    static private static void addLogsForKey(java.util.List<com.seeyon.boot.starter.udcrt.dto.UdcBaseRuntimeLogDto>, java.lang.String);
    static void clearByTraceKey(java.lang.String, com.seeyon.udc.common.enums.LogModuleEnum, java.lang.String);
    static boolean isNotEmptyMethodLogs(java.lang.String);
    static java.lang.Integer convertLong2Integer(java.lang.Long);
    static com.seeyon.boot.starter.udcrt.dto.UdcAppLogDto getTail(java.util.LinkedHashMap<java.lang.String, com.seeyon.boot.starter.udcrt.dto.UdcAppLogDto>);
    static java.lang.String getTailKey(java.util.LinkedHashMap<java.lang.String, com.seeyon.boot.starter.udcrt.dto.UdcAppLogDto>);
    static com.seeyon.boot.starter.udcrt.dto.UdcAppLogDto getHead(java.util.LinkedHashMap<java.lang.String, com.seeyon.boot.starter.udcrt.dto.UdcAppLogDto>);
    static void startCreateUdcAppLog(java.lang.String, com.seeyon.udc.common.enums.LogModuleEnum);
    static private static com.seeyon.boot.starter.udcrt.dto.UdcAppLogDto getMfLog(java.lang.String, java.lang.Long);
    static private static boolean isForNode4LastNode(java.lang.String, com.seeyon.udc.common.enums.MicroFlowActivityTypeEnum, java.lang.String);
    static private static boolean isForIndexNode4LastNode(java.lang.String, java.lang.String, java.util.LinkedHashMap<java.lang.String, com.seeyon.boot.starter.udcrt.dto.UdcAppLogDto>);
    static private static boolean isForNode(com.seeyon.boot.starter.udcrt.dto.UdcAppLogDto);
    static private static void dealForNodeForPath(com.seeyon.boot.starter.udcrt.dto.UdcAppLogDto, com.seeyon.boot.starter.udcrt.dto.UdcAppLogDto);
    static private static void buildForPathAndForIndex(com.seeyon.boot.starter.udcrt.dto.UdcAppLogDto, com.seeyon.boot.starter.udcrt.dto.UdcAppLogDto);
    static private static void buildAfterForEndLogPath(com.seeyon.boot.starter.udcrt.dto.UdcAppLogDto, com.seeyon.boot.starter.udcrt.dto.UdcAppLogDto);
    static private static boolean isForEndLog(com.seeyon.boot.starter.udcrt.dto.UdcAppLogDto);
    static void replaceLastElement(java.lang.String, com.seeyon.boot.starter.udcrt.dto.UdcBaseRuntimeLogDto);
    static void replaceFirstElement(java.lang.String, com.seeyon.boot.starter.udcrt.dto.UdcBaseRuntimeLogDto);
    static java.lang.String getLogAppName(java.lang.Long);
    static void addSimpleLog(com.seeyon.boot.starter.udcrt.dto.UdcBaseRuntimeLogDto);
    static void addSimpleEndLog(com.seeyon.boot.starter.udcrt.dto.UdcBaseRuntimeLogDto);
    static boolean isLogDisable(java.lang.String);
    static void startLogging(java.lang.String);
    static void endLogging(java.lang.String);
```

### `UdcEntityLogService`（42 方法）

`com.seeyon.boot.starter.udcrt.domain.service.UdcEntityLogService`

```java
    int createBatch(java.util.List<com.seeyon.boot.starter.udcrt.dto.UdcEntityMonitorLogDto>);
    com.seeyon.boot.transport.PageData<com.seeyon.boot.starter.udcrt.dto.UdcEntityMonitorLogDto> searchAppDataLog(com.seeyon.boot.transport.PageInfo, java.util.Map<java.lang.String, java.lang.Object>, com.seeyon.boot.transport.Sort);
    int deleteAll();
    com.seeyon.boot.starter.udcrt.dto.UdcEntityMonitorLogDto selectAppDataById(java.lang.Long);
    void fillAttributeMetaData(java.lang.String, java.lang.String, java.util.List<com.seeyon.boot.starter.lowcode.dto.EntityChangeDto>);
    java.util.Map<java.lang.String, java.lang.Object> fillAttributeDisplayName(java.util.List<com.seeyon.boot.starter.lowcode.dto.EntityChangeDto>);
    com.seeyon.boot.starter.udcrt.domain.entity.UdcEntityMonitorLog selectByDataId(java.lang.Long, java.util.Set<com.seeyon.boot.starter.lowcode.enums.FlowActionType>);
    private int deleteById(java.lang.Long);
    java.util.List<com.seeyon.boot.starter.udcrt.dto.UdcEntityMonitorLogDto> selectAppDataByDataId(java.lang.Long);
    int saveDataChange(java.util.List<com.seeyon.boot.starter.lowcode.dto.AggEntityChangeDto>);
    int saveFlowSanpshot(com.seeyon.boot.starter.lowcode.context.OperateContext);
    void dataProcess(com.seeyon.boot.starter.lowcode.context.OperateContext);
    private void diffAndSave(com.seeyon.boot.starter.lowcode.context.OperateContext);
    void flowProcess(com.seeyon.boot.starter.lowcode.context.OperateContext);
```

### `ApproveFeatureService`（41 方法）

`com.seeyon.boot.starter.udcrt.domain.service.ApproveFeatureService`

```java
    void beforeApprovalCreate(com.seeyon.boot.starter.lowcode.dto.ApprovalContext);
    void afterApprovalCreate(com.seeyon.boot.starter.lowcode.dto.ApprovalContext);
    void beforeApprovalUpdate(com.seeyon.boot.starter.lowcode.dto.ApprovalContext);
    void afterApprovalUpdate(com.seeyon.boot.starter.lowcode.dto.ApprovalContext);
    void beforeApprovalCreateValidate(com.seeyon.boot.starter.lowcode.dto.ApprovalContext);
    void beforeApprovalUpdateValidate(com.seeyon.boot.starter.lowcode.dto.ApprovalContext);
    com.seeyon.bpm.dto.approval.BpmPrefixForUdcResponseDto getBpmPrefixParams(java.lang.Object);
    com.seeyon.boot.starter.udcrt.dto.BpmProcessLaunchResultDto startProcess(java.lang.Object, java.lang.Object, java.util.Map<java.lang.String, java.lang.Object>);
    com.seeyon.boot.starter.udcrt.dto.BpmProcessLaunchResultDto startProcess0(java.lang.Object, java.lang.String, java.lang.String, com.seeyon.bpm.dto.approval.BpmPrefixForUdcResponseDto);
    private com.seeyon.boot.starter.udcrt.dto.BpmProcessLaunchResultDto sendProcess(java.lang.Object, java.util.Map<java.lang.String, java.lang.Object>, com.seeyon.bpm.dto.approval.BpmPrefixForUdcResponseDto);
    private java.lang.Long getAffairId(java.lang.Object);
    private boolean isMainProcess(com.seeyon.boot.starter.udcrt.dto.BpmProcessLaunchResultDto);
    private java.lang.String getEntityFullName(java.lang.Object);
    private com.seeyon.boot.starter.udcrt.dto.BpmProcessLaunchResultDto saveDraft(java.lang.Object, java.util.Map<java.lang.String, java.lang.Object>, com.seeyon.bpm.dto.approval.BpmPrefixForUdcResponseDto);
    private com.seeyon.boot.starter.udcrt.dto.BpmProcessLaunchResultDto repealProcess(java.lang.Object, com.seeyon.bpm.dto.approval.BpmPrefixForUdcResponseDto);
    private com.seeyon.bpm.dto.BpmCommentDto getBpmComment(java.util.Map<java.lang.String, java.lang.Object>);
    private boolean getCommentRequired(java.util.Map<java.lang.String, java.lang.Object>);
    private com.seeyon.bpm.dto.BpmOperationNodeDto getBpmOperationNodeDto(java.util.Map<java.lang.String, java.lang.Object>);
    private com.seeyon.bpm.dto.BpmCommentDto getBpmCommentDtoResult(java.lang.Object);
    private java.util.List<com.seeyon.bpm.dto.ChangeNodeRequestDto> getChangeNodeRequest(java.util.Map<java.lang.String, java.lang.Object>);
    private com.seeyon.bpm.dto.PreMatchRequestDto getPreMatchRequestDto(java.util.Map<java.lang.String, java.lang.Object>);
    private void updateBpmProcessAttribute(java.lang.Object, com.seeyon.boot.starter.udcrt.dto.BpmProcessLaunchResultDto);
    private boolean errorResponse(com.seeyon.boot.transport.SingleResponse);
```

### `ReferDynamicSelectAppService`（36 方法）

`com.seeyon.boot.starter.udcrt.appservice.ReferDynamicSelectAppService`

```java
    com.seeyon.boot.transport.SingleResponse<java.lang.Boolean> clearCache();
    <T> com.seeyon.boot.transport.ListResponse<T> selectReferenceListDynamic(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.udcrt.dto.ReferenceDynamicSelectDto<T>>);
    <T> com.seeyon.boot.transport.PageResponse<T> selectReferenceDynamic(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.udcrt.dto.ReferenceDynamicSelectDto<T>>);
    <T> com.seeyon.boot.transport.PageResponse<T> selectThirdReferenceDynamic(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.udcrt.dto.ReferenceDynamicSelectDto<T>>);
    <T> com.seeyon.boot.transport.PageResponse<T> selectNotUdcCustomReferenceDynamic(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.udcrt.dto.ReferenceDynamicSelectDto<T>>);
    private <T> com.seeyon.boot.starter.dynamicsql.dto.ProxyJoinParamDto getDynamicParamDto(com.seeyon.boot.starter.udcrt.dto.ReferenceDynamicSelectDto<T>);
    private void handlerDefaultField(java.lang.String, com.seeyon.boot.starter.dynamicsql.dto.ProxyJoinParamDto, java.util.Map<java.lang.String, com.seeyon.boot.starter.extmetadata.dto.UdcEntityMetaDataDto>);
    private <T> void handlerTree(com.seeyon.boot.starter.udcrt.dto.ReferenceDynamicSelectDto<T>);
    private void handlerTreeFiled(com.seeyon.boot.starter.udcrt.dto.ReferenceDynamicSelectDto, com.seeyon.boot.starter.dynamicsql.dto.ProxyJoinParamDto);
    private <T> com.seeyon.boot.transport.PageResponse<T> invokerDynamicJoinSelect(java.lang.String, java.lang.String, java.lang.String, com.seeyon.boot.starter.dynamicsql.dto.ProxyJoinParamDto);
    private <T> com.seeyon.boot.transport.PageResponse<T> invokerDynamicJoinSelect(com.seeyon.boot.starter.udcrt.dto.UdcInvokerDynamicDto);
    private com.seeyon.boot.transport.PageResponse selectInvokeNotUdcDynamicSearch(java.lang.String, java.lang.String, java.lang.String, com.seeyon.boot.starter.dynamicsql.dto.ProxyParamDto);
    private <T> com.seeyon.boot.transport.PageResponse<T> selectInnerThirdEntityRefer(com.seeyon.boot.starter.udcrt.dto.ReferenceDynamicSelectDto<T>);
    private <T> java.lang.String buildRootEntityFullName(com.seeyon.boot.starter.udcrt.dto.ReferenceDynamicSelectDto<T>);
    private <T> com.seeyon.boot.transport.PageResponse<T> dynamicSelect(com.seeyon.boot.starter.udcrt.dto.ReferenceDynamicSelectDto<T>);
    com.seeyon.boot.transport.PageResponse selectInvokeDynamicSearch4Third(java.lang.String, java.lang.String, java.lang.String, com.seeyon.boot.starter.udcrt.dto.ReferenceDynamicSelectDto);
    private boolean isDynamicApp(java.lang.String);
    private void handlerOrgManage(java.lang.String, com.seeyon.udc.common.dto.ReferRuntimeConfigDto, java.util.Map<java.lang.String, java.lang.Object>, java.util.Map<java.lang.String, com.seeyon.boot.starter.extmetadata.dto.UdcEntityMetaDataDto>);
    private void handlerConstraintEntity(com.seeyon.udc.common.dto.ReferRuntimeConfigDto, com.seeyon.boot.starter.dynamicsql.dto.ProxyJoinParamDto, com.seeyon.boot.starter.condition.dto.dynamicsearch.DynamicSearchParamDto);
    private void mergeJoinParam(com.seeyon.boot.starter.dynamicsql.dto.ProxyJoinParamDto, com.seeyon.boot.starter.dynamicsql.dto.ProxyJoinParamDto);
    private com.seeyon.boot.starter.dynamicsql.dto.ProxyJoinParamDto getConstraintEntity(com.seeyon.udc.common.dto.ReferRuntimeConfigDto, com.seeyon.boot.starter.condition.dto.dynamicsearch.DynamicSearchParamDto);
    private java.util.List<java.util.Map<java.lang.String, java.lang.Object>> getShowList(java.lang.String, java.lang.String, java.lang.String);
    private com.seeyon.boot.starter.dynamicsql.dto.JoinParamDto getJoinParamDto(com.seeyon.boot.starter.extmetadata.dto.UdcEntityMetaDataDto, com.seeyon.boot.starter.extmetadata.dto.UdcEntityMetaDataDto);
    private java.util.List<java.lang.String> getConstraintAggEntities(com.seeyon.udc.common.dto.ReferRuntimeConfigDto);
    private void getConstraintEntityFullName(java.util.List<com.seeyon.boot.starter.condition.dto.ConditionInfoDto>, java.util.List<java.lang.String>);
    private com.seeyon.boot.transport.PageResponse invokeForPage(com.seeyon.boot.starter.dubbo.dto.AppServiceInvokeDto, java.lang.String);
    private com.seeyon.boot.transport.PageResponse invokeForPage(com.seeyon.boot.starter.udcrt.dto.UdcReferInvokeDto);
```

### `PageCustomSearchAppService`（32 方法）

`com.seeyon.boot.starter.udcrt.appservice.PageCustomSearchAppService`

```java
    void onCompleteLoad(com.seeyon.udc.common.dto.AppInfoDto);
    void clearCache(java.lang.String);
    com.seeyon.boot.transport.SingleResponse<java.lang.Boolean> clearCache();
    com.seeyon.boot.transport.SingleResponse<com.seeyon.udc.common.dto.datasource.RuntimeControlDataSourceDto> selectMasterDataSourceByControlId(com.seeyon.boot.transport.SingleRequest<java.util.Map<java.lang.String, java.lang.Object>>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.udc.common.dto.DataFlowPlanRuntimeDto> getDataFlowPlanRuntime(com.seeyon.boot.transport.SingleRequest<java.lang.String>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.udc.common.dto.datasource.RuntimeEntityDataSourceDto> getRuntimeEntityDataSource(com.seeyon.boot.transport.SingleRequest<java.lang.String>);
    private com.seeyon.udc.common.dto.datasource.RuntimeEntityDataSourceDto getRuntimeEntityDataSource(java.lang.String);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.udc.common.dto.datasource.RuntimeEntityDataSourceDto> getRuntimeEntityDataSourceByDto(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.udcrt.dto.RuntimePageCustomSearchDto>);
    private java.util.List<com.seeyon.udc.common.dto.datasource.RuntimeEntityDataSourceDto> getPageParamRuntimeEntityDataSource(java.lang.String, java.lang.String);
    private void mergeRuntimeEntityDataSources(com.seeyon.udc.common.dto.datasource.RuntimeEntityDataSourceDto, java.util.List<com.seeyon.udc.common.dto.datasource.RuntimeEntityDataSourceDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.udc.common.dto.ReferRuntimeConfigDto> getReferConfigItem(com.seeyon.boot.transport.SingleRequest<java.lang.String>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.boot.starter.dynamicsql.dto.QueryConditionDto> changeCustomConditions(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.udcrt.dto.RuntimePageCustomSearchDto>);
    private com.seeyon.boot.starter.dynamicsql.dto.QueryConditionDto getQueryConditionDto(com.seeyon.boot.starter.udcrt.dto.RuntimePageCustomSearchDto);
    private java.util.Map<java.lang.String, com.seeyon.boot.starter.condition.dto.dynamicsearch.DynamicSearchParamDto> getDynamicSearchParamDtoMap(com.seeyon.boot.starter.udcrt.dto.PageCustomSearchDto);
    private com.seeyon.boot.starter.dynamicsql.dto.QueryConditionDto getQueryConditionDtoByDataSource(java.lang.String, com.seeyon.udc.common.dto.datasource.RuntimeEntityDataSourceDto, java.util.Map<java.lang.String, com.seeyon.boot.starter.condition.dto.dynamicsearch.DynamicSearchParamDto>);
    private java.util.Set<java.lang.String> getSearchAttributeSet(com.seeyon.udc.common.dto.datasource.RuntimeDataSourceEntityInfoDto);
    private void setControlDefaultFilterPlan(java.lang.String, com.seeyon.udc.common.dto.datasource.RuntimeEntityDataSourceDto);
    private com.seeyon.udc.common.dto.datasource.RuntimeControlDataSourceDto selectMasterDataSourceByControlId(java.lang.String, java.lang.Long, java.lang.String);
    private com.seeyon.boot.transport.Sort$Direction getDirectionEnumByName(java.lang.String);
    private java.lang.String getCacheKey(java.lang.String);
    private java.lang.String getDataSourceKey(java.lang.String, java.lang.Long, java.lang.String);
    private java.util.List<com.seeyon.boot.starter.extmetadata.dto.PageInfoItemOssDto> selectPageInfoItem4Jar(java.lang.String);
    private java.lang.String getAppDeployTime(java.lang.String);
```

### `EntityAttrSnapshotCallBackService`（31 方法）

`com.seeyon.boot.starter.udcrt.domain.service.EntityAttrSnapshotCallBackService`

```java
    static private static void fillAttrSnapshotListRefData(java.util.Map<java.lang.String, java.util.Map<java.lang.Long, java.lang.Object>>, java.util.List<com.seeyon.boot.starter.lowcode.dto.AttributeSnapshotDto>);
    static private static java.util.List<com.seeyon.boot.starter.lowcode.core.AttributeMeta> findUseSnapshotAttributes(java.util.List<com.seeyon.boot.starter.lowcode.core.AttributeMeta>);
    static private static void buildRefDataGroupIdMap(java.util.Map<java.lang.String, java.util.Map<java.lang.Long, java.lang.Object>>, java.lang.String, java.util.List<?>);
    static private static java.lang.String getRefGroupKey(java.lang.String, java.lang.String);
    <T extends com.seeyon.udc.common.dto.BaseEntityActionDto> void saveSnapshot(java.util.List<T>, com.seeyon.boot.starter.lowcode.core.EntityMeta);
    <T extends com.seeyon.udc.common.dto.BaseEntityActionDto> void updateSnapshot(java.util.List<T>, java.util.Map<java.lang.Long, T>, java.util.Map<java.lang.Long, T>, com.seeyon.boot.starter.lowcode.core.EntityMeta);
    void deleteByDataMasterIds(java.util.List<java.lang.Long>);
    void deleteDataIds(java.util.List<java.lang.Long>);
    private void resolveEntityAdd(java.util.List<com.seeyon.boot.starter.lowcode.dto.AttributeSnapshotDto>, java.util.List<com.seeyon.boot.starter.lowcode.dto.EntityCrudDiffDto>, java.util.Set<java.lang.Long>, java.util.Map<java.lang.String, java.util.Set<java.lang.String>>);
    private int buildRelationEntityDataMap(java.lang.String, java.lang.String, java.util.Set<java.lang.String>, java.util.Map<java.lang.String, java.util.Map<java.lang.Long, java.lang.Object>>);
    private <T extends com.seeyon.udc.common.dto.BaseEntityActionDto> void preAssembleChildEntityAttrSnapshot(java.util.List<T>, com.seeyon.boot.starter.lowcode.core.EntityMeta, java.lang.String, java.util.Map<java.lang.String, java.util.Set<java.lang.String>>, java.util.List<com.seeyon.boot.starter.lowcode.dto.AttributeSnapshotDto>, java.lang.Long);
    private <T extends com.seeyon.udc.common.dto.BaseEntityActionDto> void preAssembleAttrSnapshotList(java.util.List<T>, java.lang.String, java.lang.String, java.util.List<com.seeyon.boot.starter.lowcode.core.AttributeMeta>, java.util.Map<java.lang.String, java.util.Set<java.lang.String>>, com.seeyon.boot.starter.lowcode.core.EntityMeta, java.util.List<com.seeyon.boot.starter.lowcode.dto.AttributeSnapshotDto>, java.lang.Long);
    private <T extends com.seeyon.udc.common.dto.BaseEntityActionDto> java.util.Set<java.lang.Long> getDeletedEntityId(java.util.Map<java.lang.Long, T>, java.util.Map<java.lang.Long, T>);
    private java.util.Set<java.lang.String> getRefIdSetFromAttrValue(java.lang.Object);
    private boolean checkIsNullRefValue(java.lang.Object);
    static private static java.lang.Object $deserializeLambda$(java.lang.invoke.SerializedLambda);
```

### `UdcReflectUtil`（31 方法）

`com.seeyon.boot.starter.udcrt.util.UdcReflectUtil`

```java
    static void clearCache();
    static void clearCache(java.lang.Class);
    static java.lang.Object getFieldValue(java.lang.Object, java.lang.String);
    static java.util.List<java.lang.reflect.Field> getFiledList(java.lang.Class);
    static void setFieldValue(java.lang.Object, java.lang.String, java.lang.Object);
    static boolean hasField(java.lang.Object, java.lang.String);
    static java.lang.reflect.Field getFiledClass(java.lang.Object, java.lang.String);
    static java.util.Map<java.lang.String, java.lang.Object> bean2Map(java.lang.Object);
    static boolean isEnumType(java.lang.Class);
    static java.lang.String getEnumName(java.lang.Object);
    static void setEnumFiled(java.lang.Object, java.lang.String, java.lang.String);
    static java.lang.String getEnumFiledName(java.lang.Object, java.lang.String);
    static private static java.util.Map<java.lang.String, java.lang.Object> map2map(java.lang.Object);
    static private static java.util.Map<java.lang.String, java.lang.Object> dto2Map(java.lang.Object);
    static private static java.lang.Object getListData(java.lang.Object);
    static private static boolean isBasicType(java.lang.Class);
    static java.util.Map<java.lang.String, java.lang.Object> beanToMap(java.lang.Object, java.lang.String...);
    static java.util.Map<java.lang.String, java.lang.Object> beanToNullSafetyMap(java.lang.Object, java.lang.String...);
    static java.util.Map<java.lang.String, java.lang.Object> beanToMap(java.lang.Object, java.util.function.UnaryOperator<cn.hutool.core.bean.copier.CopyOptions>, java.lang.String...);
    static boolean isSecret(java.lang.Class<? extends com.seeyon.udc.common.dto.BaseEntityActionDto>);
```

### `UdcSerialConfigDto`（28 方法）

`com.seeyon.boot.starter.udcrt.dto.UdcSerialConfigDto`

```java
    java.lang.String getSourceFullName();
    java.lang.String getSourceCaption();
    java.lang.String getEntityFullName();
    java.lang.String getEntityCaption();
    java.lang.Long getSerialId();
    java.lang.String getSerialCaption();
    java.lang.Boolean getSerialActive();
    java.lang.Boolean getCanEdit();
    java.lang.Boolean getPreset();
    java.lang.String getAppName();
    java.lang.Long getAppGuid();
    java.lang.String getSerialAppName();
    java.lang.String getSerialHostAppName();
    java.lang.Long getSerialGuid();
    void setSourceFullName(java.lang.String);
    void setSourceCaption(java.lang.String);
    void setEntityFullName(java.lang.String);
    void setEntityCaption(java.lang.String);
    void setSerialId(java.lang.Long);
    void setSerialCaption(java.lang.String);
    void setSerialActive(java.lang.Boolean);
    void setCanEdit(java.lang.Boolean);
    void setPreset(java.lang.Boolean);
    void setAppName(java.lang.String);
    void setAppGuid(java.lang.Long);
    void setSerialAppName(java.lang.String);
    void setSerialHostAppName(java.lang.String);
    void setSerialGuid(java.lang.Long);
```

### `BpmActionProcessingService`（27 方法）

`com.seeyon.boot.starter.udcrt.domain.service.BpmActionProcessingService`

```java
    boolean processApprovalAction(com.seeyon.bpm.dto.message.BpmApprovalResultData, boolean);
    private void saveSanpshot(java.lang.Object);
    boolean processBpmStopAction(com.seeyon.bpm.dto.message.event.BpmStopEvent);
    boolean processBpmCancelAction(com.seeyon.bpm.dto.message.event.BpmCancelEvent);
    private void processBpmAction(com.seeyon.bpm.dto.message.event.BpmBaseEvent);
    private void approvalActionDealing(com.seeyon.bpm.dto.message.BpmApprovalResultData, java.lang.Object);
    private void processActionDealing(com.seeyon.bpm.dto.message.event.BpmBaseEvent, java.lang.Object, java.lang.Object, boolean)
    private void processBpmStop(com.seeyon.bpm.dto.message.event.BpmStopEvent, java.lang.Object);
    private void processBillUpdate(java.lang.Object, java.lang.Object, boolean)
    private void updateFormData(com.seeyon.boot.starter.udcrt.dto.FormParamDto, java.lang.Object)
    private void updateNormalData(java.lang.Object, java.lang.Object)
    private void updateProcessActionSource(java.lang.Object);
    private boolean isProcessEntity(java.lang.Object);
    private boolean isMainProcess(com.seeyon.bpm.dto.message.event.BpmBaseEvent);
```

### `CustomApplicationService`（27 方法）

`com.seeyon.boot.starter.udcrt.domain.service.CustomApplicationService`

```java
    void handleDeployNotice(com.seeyon.udc.common.dto.DeployNoticeMsgDto);
    com.seeyon.udc.common.enums.ApplicationFeatureEnum appFeature();
    com.seeyon.boot.starter.udcrt.dto.CustomApplicationDto create(com.seeyon.boot.starter.udcrt.dto.CustomApplicationDto);
    int createBatch(java.util.List<com.seeyon.boot.starter.udcrt.dto.CustomApplicationDto>);
    private boolean isNull(java.lang.Long);
    int deleteById(java.lang.Long);
    int deleteByIds(java.util.List<java.lang.Long>);
    int deleteByOriginPageGuid(java.lang.Long);
    int deleteByOriginPageGuids(java.util.List<java.lang.Long>);
    int updateAuth(java.lang.Long, java.lang.String);
    java.lang.String upgrade(com.seeyon.boot.starter.udcrt.dto.CustomApplicationUpgradeDto);
    int updateDeployState(com.seeyon.boot.starter.udcrt.dto.CustomApplicationDto);
    int updateCaption(java.lang.Long, java.lang.String);
    int updateUsageState(java.util.List<java.lang.Long>, com.seeyon.udc.common.enums.UsageStateEnum);
    java.util.List<com.seeyon.boot.starter.udcrt.dto.CustomApplicationDto> selectListByConditions(java.util.Map<java.lang.String, java.lang.Object>, com.seeyon.boot.transport.Sort);
    java.util.List<com.seeyon.boot.starter.udcrt.dto.CustomApplicationDto> selectListByOriginPageGuids(java.util.Collection<java.lang.String>);
    com.seeyon.boot.transport.PageResponse<com.seeyon.boot.starter.udcrt.dto.CustomApplicationDto> selectPageListByConditions(com.seeyon.boot.transport.PageInfo, java.util.Map<java.lang.String, java.lang.Object>, com.seeyon.boot.transport.Sort);
    private void fillParams(java.util.Map<java.lang.String, java.lang.Object>);
    com.seeyon.boot.starter.udcrt.dto.CustomApplicationDto selectById(java.lang.Long);
    java.util.List<com.seeyon.boot.starter.udcrt.dto.CustomApplicationDto> selectByIds(java.util.List<java.lang.Long>);
    private java.util.List<com.seeyon.boot.starter.udcrt.domain.entity.CustomApplication> selectEntityByIds(java.util.List<java.lang.Long>);
```

### `FormServiceProxy`（23 方法）

`com.seeyon.boot.starter.udcrt.domain.service.FormServiceProxy`

```java
    com.seeyon.boot.transport.SingleResponse<java.lang.Void> loadForm(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.udcrt.dto.FormLoadParamDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.boot.context.model.BuildInfo> getHostAppDepends(com.seeyon.boot.transport.SingleRequest<java.lang.String>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Void> loadForm(com.seeyon.boot.starter.udcrt.dto.FormParamDto)
    <T> com.seeyon.boot.transport.SingleResponse<T> validate(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.udcrt.dto.FormParamDto>)
    <T> com.seeyon.boot.transport.SingleResponse<T> mergeByCondition(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.udcrt.dto.FormParamDto>)
    <T> com.seeyon.boot.transport.SingleResponse<T> create(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.udcrt.dto.FormParamDto>)
    <T> com.seeyon.boot.transport.SingleResponse<T> selectById(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.udcrt.dto.FormParamDto>)
    <T> com.seeyon.boot.transport.ListResponse<T> selectByIds(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.udcrt.dto.FormParamDto>)
    <T> com.seeyon.boot.transport.PageResponse<T> dynamicSelect(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.udcrt.dto.FormParamDto>)
    <T> com.seeyon.boot.transport.PageResponse<T> dynamicJoinSelect(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.udcrt.dto.FormParamDto>)
    <T> com.seeyon.boot.transport.SingleResponse<T> selectCascadeById(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.udcrt.dto.FormParamDto>)
    <T> com.seeyon.boot.transport.ListResponse<T> selectCascadeByIds(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.udcrt.dto.FormParamDto>)
    <T> com.seeyon.boot.transport.SingleResponse<T> update(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.udcrt.dto.FormParamDto>)
    <T> com.seeyon.boot.transport.SingleResponse<T> updateWithResult(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.udcrt.dto.FormParamDto>)
    <T> com.seeyon.boot.transport.SingleResponse<T> createWithResult(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.udcrt.dto.FormParamDto>)
    <T> com.seeyon.boot.transport.SingleResponse<T> getDefaultValue(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.udcrt.dto.FormParamDto>)
    <T> com.seeyon.boot.transport.SingleResponse<T> deleteById(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.udcrt.dto.FormParamDto>)
    <T> com.seeyon.boot.transport.SingleResponse<T> update4Bpm(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.udcrt.dto.FormParamDto>)
    java.lang.ClassLoader getClassLoader(com.seeyon.boot.starter.udcrt.dto.FormParamDto)
    private java.lang.Object invokeMethod(com.seeyon.boot.starter.udcrt.dto.FormParamDto, java.lang.String)
    private void assertNotNull(java.lang.Class<?>, java.lang.Object, java.lang.String);
    private void assertNotNull(java.lang.Object, java.lang.String);
```

### `UdcSerialConfigService`（23 方法）

`com.seeyon.boot.starter.udcrt.domain.service.UdcSerialConfigService`

```java
    java.lang.Integer update(com.seeyon.boot.starter.udcrt.dto.UdcSerialConfigDto);
    java.util.List<com.seeyon.boot.starter.udcrt.dto.UdcSerialConfigDto> selectListByConditions(java.util.Map<java.lang.String, java.lang.Object>, com.seeyon.boot.transport.Sort);
    java.util.List<com.seeyon.boot.starter.udcrt.dto.UdcSerialConfigDto> selectListByConditions(java.util.Map<java.lang.String, java.lang.Object>, com.seeyon.boot.transport.Sort, boolean);
    com.seeyon.boot.starter.udcrt.dto.UdcSerialConfigDto getSerialConfigBySourceFullName(java.lang.String);
    java.util.List<com.seeyon.boot.starter.udcrt.dto.UdcSerialConfigDto> getSerialConfigByEntityFullName(java.lang.String);
    java.lang.String genSerialNumberBySourceFullName(java.lang.Object, java.lang.String);
    java.lang.String genSerialNumberById(java.lang.Object, java.lang.Long);
    private com.seeyon.boot.starter.serialnumber.domain.dto.SerialSchemeDto getSerialSchemeDto(java.lang.Long);
    private java.lang.String getCacheKey(java.lang.String);
    void cacheEvict();
    java.lang.String refreshHistoricalData(java.lang.String);
    java.lang.String refreshHistoricalData(com.seeyon.udc.common.dto.AppInfoDto);
    private java.util.List<com.seeyon.boot.starter.serialnumber.domain.dto.SerialSchemeDto> selectSerialSchemeByIds(java.util.List<java.lang.Long>);
    private java.util.List<com.seeyon.boot.starter.serialnumber.domain.dto.SerialSchemeDto> selectAppCommonSerialSchemeByGuids(java.util.List<java.lang.Long>);
    private java.util.List<com.seeyon.boot.starter.serialnumber.domain.dto.SerialSchemeDto> invokeSelectAppCommonSerialSchemeList(java.util.Map<java.lang.String, java.lang.Object>, com.seeyon.boot.transport.Sort);
    java.util.List<com.seeyon.udc.common.dto.AttributeDto> getAttributeListFromOss(java.lang.String, java.net.URLClassLoader);
```

### `UdcSerialConfig`（22 方法）

`com.seeyon.boot.starter.udcrt.domain.entity.UdcSerialConfig`

```java
    java.lang.String getSourceFullName();
    java.lang.String getSourceCaption();
    java.lang.String getEntityFullName();
    java.lang.Long getSerialId();
    java.lang.Boolean getCanEdit();
    java.lang.Boolean getPreset();
    java.lang.String getAppName();
    java.lang.Long getAppGuid();
    java.lang.String getSerialAppName();
    java.lang.String getSerialHostAppName();
    java.lang.Long getSerialGuid();
    void setSourceFullName(java.lang.String);
    void setSourceCaption(java.lang.String);
    void setEntityFullName(java.lang.String);
    void setSerialId(java.lang.Long);
    void setCanEdit(java.lang.Boolean);
    void setPreset(java.lang.Boolean);
    void setAppName(java.lang.String);
    void setAppGuid(java.lang.Long);
    void setSerialAppName(java.lang.String);
    void setSerialHostAppName(java.lang.String);
    void setSerialGuid(java.lang.Long);
```

### `CustomApplicationAppService`（20 方法）

`com.seeyon.boot.starter.udcrt.appservice.CustomApplicationAppService`

```java
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> create(com.seeyon.boot.transport.SingleRequest<com.seeyon.udc.dto.form.CreateOnlyPageApplicationDto>);
    com.seeyon.boot.transport.ListResponse<java.lang.Long> createNewLayout(com.seeyon.boot.transport.SingleRequest<com.seeyon.udc.dto.form.NewLayoutCreateOnlyPageApplicationDto>);
    private java.util.List<com.seeyon.udc.dto.form.OnlyPageApplicationDto> createPageApplication(com.seeyon.boot.transport.SingleRequest<com.seeyon.udc.dto.form.CreateOnlyPageApplicationDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Void> createNewLayoutAfterCall(com.seeyon.boot.transport.ListResponse<java.lang.Long>, com.seeyon.udc.dto.form.NewLayoutCreateOnlyPageApplicationDto);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.boot.starter.udcrt.dto.CustomApplicationDto> copyApp(com.seeyon.boot.transport.SingleRequest<com.seeyon.udc.common.dto.ApplicationCopyDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> copyAppAsync(com.seeyon.boot.transport.SingleRequest<com.seeyon.udc.common.dto.ApplicationCopyDto>);
    private com.seeyon.boot.starter.udcrt.dto.CustomApplicationDto buildCustomApplicationDto(com.seeyon.boot.starter.udcrt.dto.CustomApplicationDto, com.seeyon.udc.dto.form.OnlyPageApplicationDto);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> updateCaption(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.udcrt.dto.CustomApplicationUpdateCaptionDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> updateUsageState(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.udcrt.dto.CustomApplicationUpdateUsageStateDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> updateDeployState(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.udcrt.dto.CustomApplicationUpdateDeployStateDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> updateAuth(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.udcrt.dto.CustomApplicationUpdateAuthDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.String> upgrade(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.udcrt.dto.CustomApplicationUpgradeDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> deleteByIds(com.seeyon.boot.transport.SingleRequest<java.util.List<java.lang.Long>>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.boot.starter.udcrt.dto.CustomApplicationDto> selectListByConditions(com.seeyon.boot.transport.ListRequest);
    com.seeyon.boot.transport.PageResponse<com.seeyon.boot.starter.udcrt.dto.CustomApplicationDto> selectPageListByConditions(com.seeyon.boot.transport.PageRequest);
```

### `DynamicSelectAppService`（20 方法）

`com.seeyon.boot.starter.udcrt.appservice.DynamicSelectAppService`

```java
    com.seeyon.boot.starter.dynamicsql.dto.ProxyJoinParamDto getDynamicSelectProxyParam(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.udcrt.dto.FilterPlanDynamicSelectDto>);
    com.seeyon.boot.starter.dynamicsql.dto.ProxyJoinParamDto getDynamicSqlProxyParamWithoutJoinByCondition(com.seeyon.boot.starter.udcrt.dto.DynamicJoinSelectParamDto);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> selectCount(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.udcrt.dto.FilterPlanDynamicSelectDto>);
    java.util.Map<java.lang.String, java.lang.Object> getDynamicSearchSettingMap(com.seeyon.boot.starter.udcrt.dto.FilterPlanDynamicSelectDto);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.udc.common.dto.UdcProxyParamDto> getProxyParamDtoFromFilterPlan(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.udcrt.dto.FilterPlanDynamicSelectDto>);
    java.util.List<com.seeyon.boot.starter.udcrt.dto.ThirdPartyEntityDynamicSearchCondition> buildThirdPartyEntitySearchCondition(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.udcrt.dto.FilterPlanDynamicSelectDto>);
    java.util.List<com.seeyon.boot.starter.udcrt.dto.ThirdPartyEntityDynamicSearchCondition> buildThirdPartyEntitySearchCondition4Refer(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.udcrt.dto.ReferenceDynamicSelectDto>);
    static private static void resoleThirdPartyEntitySearchParam(java.util.Map<java.lang.String, com.seeyon.boot.starter.udcrt.dto.ThirdPartyEntityDynamicSearchCondition>, com.seeyon.boot.starter.udcrt.dto.ThirdPartyEntityDynamicSearchCondition);
    private java.util.List<com.seeyon.boot.starter.udcrt.dto.ThirdPartyEntityDynamicSearchCondition> addThirdPartyCondition(java.util.List<?>, com.seeyon.boot.starter.condition.dto.dynamicsearch.DynamicSearchParamDto);
    private boolean needSkipCondition(java.lang.Object);
    private java.lang.Object getThirdPartyEntityConditionRightValue(com.seeyon.boot.starter.condition.dto.SingleConditionDto$LeftParamDto, com.seeyon.boot.starter.condition.dto.SingleConditionDto$RightParamDto, com.seeyon.boot.starter.condition.dto.ConditionInfoDto, com.seeyon.boot.starter.condition.dto.dynamicsearch.DynamicSearchParamDto, int);
    private java.util.List<com.seeyon.boot.starter.customplan.dto.FilterPlanDto> getFilterPlanList(com.seeyon.boot.starter.udcrt.dto.FilterPlanDynamicSelectDto);
    private java.util.List<com.seeyon.boot.starter.udcrt.dto.ThirdPartyEntityDynamicSearchCondition> buildThirdPartyEntitySearchCondition(java.util.Map<java.lang.String, java.lang.Object>, com.seeyon.boot.starter.condition.dto.BaseConditionDto$LogicalOperator);
    private com.seeyon.udc.common.enums.SearchOperationEnum getSearchOperationByConditionOp(java.lang.String);
```

### `AbstractFromService`（20 方法）

`com.seeyon.boot.starter.udcrt.domain.service.AbstractFromService`

```java
    void handleDeployNotice(com.seeyon.udc.common.dto.DeployNoticeMsgDto);
    void setApplicationContext(org.springframework.context.ApplicationContext)
    java.lang.Class<T> getEntityClass();
    void loadFrom(T);
    void loadFrom(T, java.lang.String);
    boolean createOrUpdateAppInfo(java.util.List<T>);
    void asynLoadApp(java.util.List<T>);
    com.seeyon.udc.common.enums.ApplicationFeatureEnum appFeature();
    java.lang.String getHostAppName();
    private java.lang.String getMvnPath(java.lang.String);
```

### `OldUdcAppLogHelper`（20 方法）

`com.seeyon.boot.starter.udcrt.util.OldUdcAppLogHelper`

```java
    static void buildMfLog(java.lang.String, com.seeyon.boot.starter.udcrt.enums.ModuleSubTypeEnum, java.lang.String);
    static void buildInputLog(java.lang.String, com.seeyon.boot.starter.udcrt.enums.ModuleSubTypeEnum, java.lang.String);
    static void buildEndLog(java.lang.String, java.lang.String);
    static void buildActivityStartLog(java.lang.String, com.seeyon.boot.starter.udcrt.enums.MicroFlowActivityTypeEnum, java.lang.String, java.lang.String, java.lang.String);
    static void buildActivityEndLog(java.lang.String, com.seeyon.boot.starter.udcrt.enums.MicroFlowActivityTypeEnum, java.lang.String, java.lang.String, java.lang.String, boolean);
    static void buildSubMfStartLog(java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String);
    static void buildSubMfEndLog(java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String, boolean);
    static void buildErrorLog(java.lang.String, com.seeyon.boot.starter.udcrt.enums.MicroFlowActivityTypeEnum, java.lang.String, java.lang.String, java.lang.String, boolean);
    static void buildTraceAndRequest(java.lang.String);
    static java.lang.String buildTraceMapKey(java.lang.String);
    static java.lang.String buildForTraceMapKey(java.lang.String, int);
    static private static com.seeyon.boot.starter.udcrt.dto.UdcAppLogDto addUdcAppLogDto(java.lang.String, com.seeyon.boot.starter.udcrt.enums.ModuleSubTypeEnum, java.lang.String, java.lang.String, com.seeyon.boot.starter.udcrt.enums.MicroFlowActivityTypeEnum, java.lang.String, java.lang.String, java.lang.String);
    static private static com.seeyon.boot.starter.udcrt.dto.UdcAppLogDto addUdcAppLogDto(java.lang.String, com.seeyon.boot.starter.udcrt.enums.ModuleSubTypeEnum, java.lang.String, java.lang.String, com.seeyon.boot.starter.udcrt.enums.MicroFlowActivityTypeEnum, java.lang.String, java.lang.String, java.lang.String, java.lang.Boolean, java.lang.Long);
    static com.seeyon.boot.starter.udcrt.dto.UdcAppLogDto getTail(java.util.LinkedHashMap<java.lang.String, com.seeyon.boot.starter.udcrt.dto.UdcAppLogDto>);
    static java.lang.String getTailKey(java.util.LinkedHashMap<java.lang.String, com.seeyon.boot.starter.udcrt.dto.UdcAppLogDto>);
    static com.seeyon.boot.starter.udcrt.dto.UdcAppLogDto getHead(java.util.LinkedHashMap<java.lang.String, com.seeyon.boot.starter.udcrt.dto.UdcAppLogDto>);
    static void startCreateUdcAppLog(java.lang.String);
    static private static com.seeyon.boot.starter.udcrt.dto.UdcAppLogDto getMfLog(java.lang.String);
    static private static boolean isForNode4LastNode(java.lang.String, com.seeyon.boot.starter.udcrt.enums.MicroFlowActivityTypeEnum, java.lang.String);
    static private static boolean isForIndexNode4LastNode(java.lang.String, java.lang.String, java.util.LinkedHashMap<java.lang.String, com.seeyon.boot.starter.udcrt.dto.UdcAppLogDto>);
```

### `FromAcrossService`（18 方法）

`com.seeyon.boot.starter.udcrt.domain.service.FromAcrossService`

```java
    static private static java.lang.String getMd5FileName(java.lang.String, java.io.File);
    boolean acrossRefresh(java.util.Date);
    boolean acrossRefresh();
    java.lang.String download(java.lang.String, java.lang.String);
    java.util.List<com.seeyon.udc.common.dto.ApplicationExportDto> getAppInfo(java.lang.String)
    private java.lang.String getFileMd5(java.lang.String);
    private boolean isChangeMd5(java.lang.String, java.lang.String, java.lang.String);
    private boolean writeMd5(java.lang.String, java.lang.String, java.lang.String)
    java.lang.String getHostAppName();
```

### `EntityRuntimeService`（17 方法）

`com.seeyon.boot.starter.udcrt.domain.service.EntityRuntimeService`

```java
    <T extends com.seeyon.udc.common.dto.BaseEntityActionDto> T buildInitialValue(com.seeyon.boot.starter.lowcode.core.EntityMeta, T, T);
    <T extends com.seeyon.udc.common.dto.BaseEntityActionDto> void requiredValidate(com.seeyon.boot.starter.lowcode.core.EntityMeta, T, T);
    private <T extends com.seeyon.udc.common.dto.BaseEntityActionDto> com.seeyon.boot.starter.customplan.dto.BpmFromPermissionCheckDto<T> getBpmFromPermissionCheckDto(com.seeyon.boot.starter.lowcode.core.EntityMeta, T, T, java.util.Map<java.lang.String, java.lang.Object>);
    void setEntityValue(com.seeyon.boot.transport.BaseDto, java.lang.Class<? extends com.seeyon.boot.domain.entity.BaseEntity>);
    private void setSerialValue(com.seeyon.boot.transport.BaseDto, java.lang.Class<? extends com.seeyon.boot.domain.entity.BaseEntity>, java.util.List<java.lang.reflect.Field>);
    void setEntityValue(java.util.List<? extends com.seeyon.boot.transport.BaseDto>, java.lang.Class<? extends com.seeyon.boot.domain.entity.BaseEntity>);
    java.util.List<java.lang.reflect.Field> getSerialField(java.lang.Class<? extends com.seeyon.boot.domain.entity.BaseEntity>);
    private com.seeyon.bpm.dto.BpmFormPermissionIncludeContentDto mapToBpmFormPermissionIncludeContentDto(java.util.Map<java.lang.String, java.lang.Object>);
    private com.seeyon.bpm.dto.BpmFormPermissionContentDto mapToBpmFormPermissionContentDto(java.util.Map<java.lang.String, java.lang.Object>);
```

### `UdcAppLogService`（17 方法）

`com.seeyon.boot.starter.udcrt.domain.service.UdcAppLogService`

```java
    int createBatch(java.util.List<com.seeyon.boot.starter.udcrt.dto.UdcBaseRuntimeLogDto>);
    com.seeyon.boot.transport.PageData<com.seeyon.udc.common.dto.MicroFlowLogResultDto> search(com.seeyon.udc.common.dto.MicroFlowLogSearchDto, com.seeyon.boot.transport.PageInfo);
    com.seeyon.boot.transport.PageData<com.seeyon.udc.common.dto.MicroFlowLogDetailsResultDto> searchDetails(com.seeyon.udc.common.dto.MicroFlowLogDetailsSearchDto, com.seeyon.boot.transport.PageInfo);
    com.seeyon.udc.common.dto.MicroFlowFlowLogResultDto searchDetails4FlowLog(com.seeyon.udc.common.dto.MicroFlowLogDetailsSearchDto);
    private void countForCycles(com.seeyon.udc.common.dto.MicroFlowLogDetailsSearchDto, java.util.Map<java.lang.String, java.util.List<com.seeyon.boot.starter.udcrt.domain.entity.UdcAppLog>>, java.util.List<com.seeyon.udc.common.dto.FlowForCyclesInfo>);
    private boolean isNotFirstForNode(com.seeyon.boot.starter.udcrt.domain.entity.UdcAppLog, java.lang.String);
    int deleteAll();
    void saveModuleLogs(java.lang.String, com.seeyon.udc.common.enums.LogModuleEnum, java.lang.String);
    void saveModuleExceptionLogs(java.lang.String, com.seeyon.udc.common.enums.LogModuleEnum, java.lang.Throwable, java.lang.String);
    void addErrorLog(java.lang.Throwable, com.seeyon.boot.starter.udcrt.dto.UdcBaseRuntimeLogDto);
    private void saveLogs(java.lang.String, com.seeyon.udc.common.enums.LogModuleEnum);
    private void setMicroFlowNodeEndTime(java.lang.String);
    void setLogError(java.lang.Throwable, java.lang.String, com.seeyon.udc.common.enums.LogModuleEnum);
```

### `UdcAppLogAppService`（15 方法）

`com.seeyon.boot.starter.udcrt.appservice.UdcAppLogAppService`

```java
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> createBatch(com.seeyon.boot.transport.SingleRequest<java.util.List<com.seeyon.boot.starter.udcrt.dto.UdcAppLogDto>>);
    com.seeyon.boot.transport.PageResponse<com.seeyon.udc.common.dto.MicroFlowLogResultDto> search(com.seeyon.boot.transport.PageDtoRequest<com.seeyon.udc.common.dto.MicroFlowLogSearchDto>);
    com.seeyon.boot.transport.PageResponse<com.seeyon.udc.common.dto.MicroFlowLogDetailsResultDto> searchDetails(com.seeyon.boot.transport.PageDtoRequest<com.seeyon.udc.common.dto.MicroFlowLogDetailsSearchDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.udc.common.dto.MicroFlowFlowLogResultDto> searchDetails4FlowLog(com.seeyon.boot.transport.SingleRequest<com.seeyon.udc.common.dto.MicroFlowLogDetailsSearchDto>);
    com.seeyon.boot.transport.PageResponse<com.seeyon.boot.starter.udcrt.dto.UdcDataFlowLogDto> searchDataFlow(com.seeyon.boot.transport.PageDtoRequest<com.seeyon.udc.common.dto.DataFlowLogSearchDto>);
    com.seeyon.boot.transport.PageResponse<com.seeyon.boot.starter.udcrt.dto.UdcDataFlowLogDto> searchDataFlowDetails(com.seeyon.boot.transport.PageDtoRequest<com.seeyon.udc.common.dto.DataFlowLogSearchDto>);
    com.seeyon.boot.transport.PageResponse<com.seeyon.boot.starter.udcrt.dto.UdcDeductionLogDto> searchDeduction(com.seeyon.boot.transport.PageDtoRequest<com.seeyon.udc.common.dto.DeductionLogSearchDto>);
    com.seeyon.boot.transport.PageResponse<com.seeyon.boot.starter.udcrt.dto.UdcDeductionLogDto> searchDeductionDetails(com.seeyon.boot.transport.PageDtoRequest<com.seeyon.udc.common.dto.DeductionLogSearchDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> deleteAll();
    com.seeyon.boot.transport.SingleResponse<java.lang.Boolean> setRestEnableLog(com.seeyon.boot.transport.SingleRequest<java.lang.Boolean>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.udc.common.dto.AppLogConfigDto> getAppLogConfig(com.seeyon.boot.transport.SingleRequest<java.lang.String>);
    com.seeyon.boot.transport.PageResponse<com.seeyon.boot.starter.udcrt.dto.UdcEntityMonitorLogDto> searchAppDataLog(com.seeyon.boot.transport.PageRequest);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.boot.starter.udcrt.dto.UdcEntityMonitorLogDto> selectAppDataById(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.boot.starter.udcrt.dto.UdcEntityMonitorLogDto> selectAppDataByDataId(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Boolean> saveFrontLog(com.seeyon.boot.transport.SingleRequest<java.lang.String>);
```

### `AttachmentTemplateRtService`（14 方法）

`com.seeyon.boot.starter.udcrt.domain.service.AttachmentTemplateRtService`

```java
    com.seeyon.boot.starter.udcrt.dto.AttachmentTemplateDto create(com.seeyon.boot.starter.udcrt.dto.AttachmentTemplateDto);
    java.util.List<com.seeyon.boot.starter.udcrt.dto.AttachmentTemplateDto> createBatch(java.util.List<com.seeyon.boot.starter.udcrt.dto.AttachmentTemplateDto>);
    com.seeyon.udc.common.dto.CommonFileDto selectByGuid(java.lang.Long);
    java.util.List<com.seeyon.udc.common.dto.CommonFileDto> selectByGuids(java.util.List<java.lang.Long>);
    java.util.List<com.seeyon.udc.common.dto.CommonFileDto> selectByAppId(java.lang.Long);
    java.lang.Integer deleteByGuid(java.lang.Long);
    java.lang.Integer deleteByGuids(java.util.List<java.lang.Long>);
    private void checkBatchCreate(java.util.List<com.seeyon.boot.starter.udcrt.dto.AttachmentTemplateDto>);
    private java.util.List<com.seeyon.boot.starter.udcrt.dto.AttachmentTemplateDto> selectRecordsByAppId(java.lang.Long);
    private java.util.List<com.seeyon.udc.common.dto.CommonFileDto> getCommonFiles(java.util.List<com.seeyon.boot.starter.udcrt.domain.entity.AttachmentTemplateRtEntity>);
```

### `BillStateHandlerService`（13 方法）

`com.seeyon.boot.starter.udcrt.domain.service.BillStateHandlerService`

```java
    <T extends com.seeyon.udc.common.dto.BaseEntityActionDto> T checkBillState(T, T);
    private void old_PENDING_REVIEW(java.lang.String);
    private void old_COME_INTO_FORCE(java.lang.String);
    private void old_TERMINATED(java.lang.String);
    private void old_NULLIFIED(java.lang.String);
    private void old_SUSPENDED(java.lang.String);
    private void old_FAILED(java.lang.String);
    private void bpm_old_PENDING_REVIEW(java.lang.String);
    private void bpm_old_COME_INTO_FORCE(java.lang.String);
    private void bpm_old_TERMINATED(java.lang.String);
    private void bpm_old_NULLIFIED(java.lang.String);
    private void bpm_old_SUSPENDED(java.lang.String);
    private void bpm_old_FAILED(java.lang.String);
```

### `ExpressionEntityParamRtServiceImpl`（13 方法）

`com.seeyon.boot.starter.udcrt.domain.service.ExpressionEntityParamRtServiceImpl`

```java
    java.util.List<com.seeyon.boot.starter.formula.dto.variable.SchemaStructureDto> loadParamSchemaInfo(com.seeyon.boot.starter.formula.dto.variable.VariableSchemaLoadDto);
    private com.seeyon.boot.starter.formula.dto.variable.SchemaStructureDto getRootSchema(com.seeyon.boot.starter.extmetadata.dto.UdcEntityMetaDataDto, java.util.Map<java.lang.String, com.seeyon.boot.starter.extmetadata.dto.UdcEntityMetaDataDto>, java.util.Set<java.lang.String>);
    void setSchemaProperties(java.util.List<com.seeyon.boot.starter.formula.dto.variable.SchemaStructureDto>, com.seeyon.boot.starter.extmetadata.dto.UdcAttributeMetaDataDto, java.util.Map<java.lang.String, com.seeyon.boot.starter.extmetadata.dto.UdcEntityMetaDataDto>);
    private com.seeyon.boot.starter.formula.dto.variable.SchemaStructureDto buildBasicAttributeSchema(com.seeyon.boot.starter.extmetadata.dto.UdcAttributeMetaDataDto, java.lang.String);
    private com.seeyon.boot.starter.formula.dto.variable.SchemaStructureDto buildCtpEnumAttributeSchema(com.seeyon.boot.starter.extmetadata.dto.UdcAttributeMetaDataDto);
    private com.seeyon.boot.starter.formula.dto.variable.SchemaStructureDto buildJavaEnumAttributeSchema(com.seeyon.boot.starter.extmetadata.dto.UdcAttributeMetaDataDto);
    private java.lang.String getReferenceProperties(com.seeyon.boot.starter.extmetadata.dto.UdcAttributeMetaDataDto);
    private java.lang.String getJavaEnumControlProperties(com.seeyon.boot.starter.extmetadata.dto.UdcAttributeMetaDataDto);
```

### `GraphqlProxyAppServiceImpl`（12 方法）

`com.seeyon.boot.starter.udcrt.appservice.GraphqlProxyAppServiceImpl`

```java
    com.seeyon.boot.transport.SingleResponse<java.lang.String> doGraphQL(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.udcrt.dto.GraphqlProxyRequestDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.String> doRest(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.udcrt.dto.RestRequestProxyDto>);
    private java.lang.String getRestUrl(com.seeyon.boot.starter.udcrt.dto.RestRequestProxyDto);
    private java.lang.String getUrl(java.lang.String, com.seeyon.udc.common.enums.ApplicationSourceEnum);
```

### `ColiDataUpgradeAppService`（12 方法）

`com.seeyon.boot.starter.udcrt.coli.ColiDataUpgradeAppService`

```java
    com.seeyon.boot.transport.SingleResponse<java.util.List<java.lang.String>> upgradeData(com.seeyon.boot.transport.SingleRequest<java.util.Map<java.lang.String, java.lang.Object>>);
    java.util.List<java.lang.Object> dynamicJoinSelect(java.lang.String, java.lang.String, java.util.Map<java.lang.String, com.seeyon.ctp.metadata.dto.EntityMetadataDto>);
    private java.util.List<com.seeyon.udc.common.dto.EntityDto> selectEntityList4Jar(java.lang.String);
    private java.util.List<com.seeyon.udc.common.dto.AttributeDto> selectAttributeDtoList4Jar(java.lang.String);
    private com.seeyon.udc.common.dto.ApplicationDto selectApplicationDto4Jar(java.lang.String);
    static java.lang.String idReplace(java.lang.String, java.util.Map<java.lang.String, java.lang.String>);
```

### `OpinionConfigDto`（12 方法）

`com.seeyon.boot.starter.udcrt.opinionbox.dto.OpinionConfigDto`

```java
    void setParentId(java.lang.String);
    void setWidgetId(java.lang.String);
    void setDataField(java.lang.String);
    void setFullName(java.lang.String);
    void setIsEdit(java.lang.Boolean);
    void setPermissionId(java.lang.Long);
    java.lang.String getParentId();
    java.lang.String getWidgetId();
    java.lang.String getDataField();
    java.lang.String getFullName();
    java.lang.Boolean getIsEdit();
    java.lang.Long getPermissionId();
```

### `EntityAuthHelper`（12 方法）

`com.seeyon.boot.starter.udcrt.util.EntityAuthHelper`

```java
    void checkBpmSummaryPermission(com.seeyon.boot.transport.BaseDto);
    void check(com.seeyon.boot.transport.BaseDto);
    private boolean isCandidateStereotype(com.seeyon.boot.transport.BaseDto);
    private void pollCheckBpmSummaryPermission(java.lang.String);
```

### `UdcBpmProcessServiceImpl`（11 方法）

`com.seeyon.boot.starter.udcrt.appservice.UdcBpmProcessServiceImpl`

```java
    private com.seeyon.boot.transport.SingleResponse<com.seeyon.boot.starter.udcrt.dto.BpmParameterDataDto> validFilterData(com.seeyon.boot.starter.udcrt.dto.DataValidBaseFilterDto, java.lang.String);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.boot.starter.udcrt.dto.BpmParameterDataDto> validUpdateFilterData(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.udcrt.dto.DataValidUpdateFilterDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.boot.starter.udcrt.dto.BpmParameterDataDto> validCreateFilterData(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.udcrt.dto.DataValidCreateFilterDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.boot.starter.udcrt.dto.BpmParameterDataDto> validFilterData(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.udcrt.dto.DataValidUpdateFilterDto>);
    com.seeyon.boot.transport.SingleResponse updateData(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.udcrt.dto.DataValidUpdateFilterDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Boolean> processBpmApproval(com.seeyon.boot.transport.SingleRequest<com.seeyon.bpm.dto.message.BpmApprovalResultData>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Boolean> processBpmStop(com.seeyon.boot.transport.SingleRequest<com.seeyon.bpm.dto.message.event.BpmStopEvent>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Boolean> processBpmCancel(com.seeyon.boot.transport.SingleRequest<com.seeyon.bpm.dto.message.event.BpmCancelEvent>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Boolean> processBpmTakeBack(com.seeyon.boot.transport.SingleRequest<com.seeyon.bpm.dto.message.BpmApprovalResultData>);
    private com.seeyon.boot.transport.SingleResponse getErrorResponse(java.lang.Exception);
```

### `UdcSerialConfigController`（11 方法）

`com.seeyon.boot.starter.udcrt.controller.UdcSerialConfigController`

```java
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> update(com.seeyon.boot.starter.udcrt.dto.UdcSerialConfigDto);
    com.seeyon.boot.transport.ListResponse<com.seeyon.boot.starter.udcrt.dto.UdcSerialConfigDto> selectListByConditions(java.util.Map<java.lang.String, java.lang.Object>, com.seeyon.boot.transport.Sort);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.boot.starter.udcrt.dto.EntityGroupAndItemDto> selectEntityList(java.lang.String);
    com.seeyon.boot.transport.ListResponse<com.seeyon.boot.starter.extmetadata.dto.UdcEntityMetaDataDto> selectEntityBySerial(java.util.Map<java.lang.String, java.lang.Object>);
    com.seeyon.boot.transport.SingleResponse<java.lang.String> refreshHistoricalData(java.lang.String);
    com.seeyon.boot.transport.SingleResponse<java.lang.Boolean> cacheEvict(java.lang.String);
    private boolean checkSerialConfigResourcePermission();
    private <T> com.seeyon.boot.transport.ListResponse<T> handlerErrorListResponse();
    private <T> com.seeyon.boot.transport.SingleResponse<T> handlerErrorResponse();
```

### `UdcSecretCheckService`（11 方法）

`com.seeyon.boot.starter.udcrt.domain.service.UdcSecretCheckService`

```java
    <D extends com.seeyon.udc.common.dto.BaseEntityActionDto> void checkSecret(java.util.Collection<D>);
    static private static void doCollectAttachment(java.util.Map<java.lang.String, java.util.List<java.util.Map<java.lang.String, java.lang.Object>>>, java.lang.Class<? extends com.seeyon.udc.common.dto.BaseEntityActionDto>, java.util.Collection<? extends com.seeyon.udc.common.dto.BaseEntityActionDto>, boolean, java.lang.Long);
    static private static void findAttachment(com.seeyon.udc.common.dto.BaseEntityActionDto, java.util.List<java.lang.reflect.Field>, java.util.List<java.util.Map<java.lang.String, java.lang.Object>>);
    private void doCheckSecret(java.util.Collection<? extends com.seeyon.udc.common.dto.BaseEntityActionDto>);
```

### `AnnotationUtils`（11 方法）

`com.seeyon.boot.starter.udcrt.util.AnnotationUtils`

```java
    static boolean isEntity(java.lang.Class<?>, java.lang.Class<? extends java.lang.annotation.Annotation>);
    static boolean isEntity(java.lang.Class<?>);
    static boolean isEntityFrom(java.lang.Class<?>, java.lang.String...);
    static com.seeyon.boot.annotation.enums.EntityType getEntityType(java.lang.Class<?>);
    static <T> T getAnnotationValue(java.lang.Class<?>, java.lang.Class<? extends java.lang.annotation.Annotation>, java.lang.String);
    static java.lang.String getCustomAttributeValue(java.lang.reflect.AnnotatedElement, java.lang.Class<? extends java.lang.annotation.Annotation>, java.lang.String);
```

### `AppDraftService`（10 方法）

`com.seeyon.boot.starter.udcrt.domain.service.AppDraftService`

```java
    int createOrUpdate(com.seeyon.boot.starter.udcrt.dto.AppDraftDto);
    com.seeyon.boot.starter.udcrt.dto.AppDraftExistDto exist(java.lang.String);
    com.seeyon.boot.starter.udcrt.dto.AppDraftDto select(java.lang.String);
    int delete(java.lang.String);
    int deleteOnlyAppNameKey();
    int deleteAll(java.lang.String);
    int deleteTimeout(int);
    long getCurrentUserId();
    com.seeyon.boot.domain.dao.Wrapper getDataIdAndCurrentUserWrapper(java.lang.String);
```

### `DynamicJarService`（10 方法）

`com.seeyon.boot.starter.udcrt.domain.service.DynamicJarService`

```java
    java.lang.String importJar(java.lang.String);
    java.lang.String downloadApp(com.seeyon.boot.starter.udcrt.dto.FormJarDefinitionDto);
    java.lang.String downloadApp(java.lang.String);
    private java.lang.String buildFileName(java.lang.String, java.lang.String);
    private java.lang.String getJarModule(java.lang.String);
```

### `UdcFunctionNodeService`（10 方法）

`com.seeyon.boot.starter.udcrt.domain.service.UdcFunctionNodeService`

```java
    java.util.List<com.seeyon.udc.common.dto.UdcFunctionNodeMetadataDto> selectFunctionNodeTreeMetaData(java.lang.String);
    private java.util.List<com.seeyon.ctp.user.dto.CtpResourceDto> select4Sentniel(java.util.Map<java.lang.String, java.lang.Object>, com.seeyon.boot.transport.Sort);
    private java.util.function.Predicate<com.seeyon.boot.starter.extmetadata.dto.UdcPageMetadataV2Dto> getPageMetadataDtoPredicate();
    private void fillPageMetaData(java.util.List<com.seeyon.udc.common.dto.UdcFunctionNodeMetadataDto>, java.util.Map<java.lang.String, java.util.List<com.seeyon.boot.starter.extmetadata.dto.UdcPageMetadataV2Dto>>);
```

### `BpmDataUtil`（10 方法）

`com.seeyon.boot.starter.udcrt.util.BpmDataUtil`

```java
    static java.util.Map<java.lang.String, java.lang.Object> filterMapData(java.util.Map<java.lang.String, java.lang.Object>, java.util.List<java.lang.String>);
    static private static java.util.Map<java.lang.String, java.lang.Object> filterMapData(java.util.Map<java.lang.String, java.lang.Object>, java.util.List<java.lang.String>, java.lang.String);
```

### `IdToKeyMapEntityService`（9 方法）

`com.seeyon.boot.starter.udcrt.domain.service.IdToKeyMapEntityService`

```java
    java.util.List<java.lang.String> selectKeyListByIds(java.util.List<java.lang.Long>);
    <T extends com.seeyon.udc.common.dto.BaseEntityActionDto> void setObjectIdsFromKey(java.util.List<T>);
    <T extends com.seeyon.udc.common.dto.BaseEntityActionDto> void setOrGenerateIds(java.util.List<T>);
    private java.lang.String getEntityFullNameFromDto(com.seeyon.udc.common.dto.BaseEntityActionDto);
    private java.lang.String getEntityGuid(com.seeyon.boot.annotation.EntityInfo);
    private java.lang.reflect.Field getUniqueField(java.lang.Class<?>);
    private com.seeyon.boot.starter.udcrt.domain.entity.IdToKeyMapEntity generateIdByMap(java.lang.String, java.lang.String, java.lang.String);
```

### `MicroFlowOrgPeopleService`（8 方法）

`com.seeyon.boot.starter.udcrt.domain.service.MicroFlowOrgPeopleService`

```java
    com.seeyon.organization.dto.core.OrgMemberPostCoreDto buildMemberPostByMemberId(java.lang.String);
    java.util.List<com.seeyon.organization.dto.core.OrgMemberPostCoreDto> buildMemberPostByOrgTypeAndIds(java.lang.String, java.util.List<java.lang.Long>);
    java.util.List<com.seeyon.organization.dto.core.OrgMemberPostCoreDto> buildMemberPostByOrgType(java.lang.String, java.lang.String);
    com.seeyon.organization.dto.core.OrgMemberCoreDto buildMemberCoreByUserId(java.lang.String);
    java.util.List<com.seeyon.organization.dto.core.OrgMemberCoreDto> buildMemberCoreByPeopleData(com.seeyon.organization.dto.common.SelectPeopleDataDto);
    java.util.List<com.seeyon.organization.dto.core.OrgMemberCoreDto> buildMemberCoreByPublishScope(java.lang.String);
    java.util.List<com.seeyon.organization.dto.core.OrgMemberPostCoreDto> buildMemberPostCoreByPublishScope(java.lang.String);
    java.util.List<com.seeyon.organization.dto.core.OrgMemberPostCoreDto> buildMemberPostByPeopleData(com.seeyon.organization.dto.common.SelectPeopleDataDto);
```

### `BpmApiFormPermissionAppServiceProxy`（8 方法）

`com.seeyon.boot.starter.udcrt.domain.service.proxy.BpmApiFormPermissionAppServiceProxy`

```java
    java.lang.Long create(com.seeyon.boot.starter.udcrt.dto.FormPermissionDto);
    void update(com.seeyon.boot.starter.udcrt.dto.FormPermissionDto);
    void deleteById(java.lang.Long);
    com.seeyon.bpm.dto.BpmFormPermissionDto selectById(java.lang.Long);
    java.util.List<com.seeyon.bpm.dto.BpmFormPermissionDto> selectByApplicationName(java.lang.String);
    java.util.List<com.seeyon.bpm.dto.BpmFormDesensitizedDto> selectFormDesensitizedList(com.seeyon.boot.starter.udcrt.dto.BillSearchRequestDto);
```

### `RecycleSerialNumberService`（8 方法）

`com.seeyon.boot.starter.udcrt.serialnumber.RecycleSerialNumberService`

```java
    static java.lang.String getTraceIdKey();
    void add(com.seeyon.boot.starter.udcrt.dto.RecycleSerialNumberDto);
    <DTO extends com.seeyon.udc.common.dto.BaseEntityActionDto> void setNoRecoverSerialNumber(java.util.Collection<DTO>);
    void run()
```

### `DateUtil`（8 方法）

`com.seeyon.boot.starter.udcrt.util.DateUtil`

```java
    static java.util.Date getDateByTimeStampOrDateTimeString(java.lang.String);
    static java.util.Date getDateByTimeStampOrDateString(java.lang.String);
    static java.lang.String getDateTimeFormatStringByTimeStampOrString(java.lang.String);
    static java.lang.String getDateFormatStringByTimeStampOrString(java.lang.String);
    static int getSecondsByTimeString(java.lang.String);
    static private static int getSecondsByHour(java.lang.String);
    static private static int getSecondsByMinute(java.lang.String);
    static private static int getSecondsBySecond(java.lang.String);
```

### `UdcDynamicSelectUtil`（8 方法）

`com.seeyon.boot.starter.udcrt.util.UdcDynamicSelectUtil`

```java
    static boolean isInnerInvoke(java.lang.String);
    static com.seeyon.boot.starter.dynamicsql.dto.DynamicConditionDto getWhereCondition(java.lang.String, com.seeyon.boot.starter.udcrt.dto.ReferenceDynamicSelectDto);
    static void buildSearchCond(com.seeyon.boot.starter.dynamicsql.dto.DynamicConditionDto, java.util.Map<java.lang.String, java.lang.Object>, com.seeyon.boot.starter.condition.dto.BaseConditionDto$LogicalOperator);
    static com.seeyon.boot.starter.condition.dto.dynamicsearch.DynamicSearchParamDto conditions2DynamicParam(java.lang.String, com.seeyon.boot.transport.ListRequest);
    static com.seeyon.boot.starter.condition.dto.dynamicsearch.DynamicSearchParamDto handlerFilterDynamicParam(com.seeyon.udc.common.dto.datasource.RuntimeEntityDataSourceDto, com.seeyon.boot.starter.condition.dto.dynamicsearch.DynamicSearchParamDto);
    static private static void addDynamicFiled(com.seeyon.udc.common.dto.datasource.RuntimeDataSourceEntityInfoDto, java.util.List<java.util.Map<java.lang.String, java.lang.Object>>);
```

### `UdcJsonUtils`（8 方法）

`com.seeyon.boot.starter.udcrt.util.UdcJsonUtils`

```java
    static java.lang.String toJson(java.lang.Object);
    static java.lang.String toJson(java.lang.Object, boolean);
    static java.lang.String toJsonLongToString(java.lang.Object);
    static java.lang.String toJsonDecimalToString(java.lang.Object);
    static <K, V> java.util.Map<K, V> toMap(java.lang.String, java.lang.Class<K>, java.lang.Class<V>);
    static java.util.Map<java.lang.String, java.lang.Object> toMap(java.lang.String);
    static private static <T> T readValue(java.lang.String, com.fasterxml.jackson.databind.JavaType)
    static private static <T> T readValue(java.lang.String, java.lang.Class<T>)
```

### `AttachmentTemplateRtAppService`（7 方法）

`com.seeyon.boot.starter.udcrt.appservice.AttachmentTemplateRtAppService`

```java
    com.seeyon.boot.transport.SingleResponse<com.seeyon.boot.starter.udcrt.dto.AttachmentTemplateDto> create(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.udcrt.dto.AttachmentTemplateDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.boot.starter.udcrt.dto.AttachmentTemplateDto> createBatch(com.seeyon.boot.transport.SingleRequest<java.util.List<com.seeyon.boot.starter.udcrt.dto.AttachmentTemplateDto>>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.udc.common.dto.CommonFileDto> selectByGuid(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.udc.common.dto.CommonFileDto> selectByGuids(com.seeyon.boot.transport.SingleRequest<java.util.List<java.lang.Long>>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.udc.common.dto.CommonFileDto> selectByAppId(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> deleteByGuid(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> deleteByGuids(com.seeyon.boot.transport.SingleRequest<java.util.List<java.lang.Long>>);
```

### `UdcSerialConfigAppServiceImpl`（7 方法）

`com.seeyon.boot.starter.udcrt.appservice.UdcSerialConfigAppServiceImpl`

```java
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> update(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.udcrt.dto.UdcSerialConfigDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.boot.starter.udcrt.dto.UdcSerialConfigDto> selectListByConditions(com.seeyon.boot.transport.ListRequest);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.boot.starter.udcrt.dto.EntityGroupAndItemDto> selectEntityList(com.seeyon.boot.transport.SingleRequest<java.lang.String>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.boot.starter.extmetadata.dto.UdcEntityMetaDataDto> selectEntityBySerialId(com.seeyon.boot.transport.ListRequest);
    com.seeyon.boot.transport.SingleResponse<java.lang.String> refreshHistoricalData(com.seeyon.boot.transport.SingleRequest<java.lang.String>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Boolean> cacheEvict(com.seeyon.boot.transport.SingleRequest<java.lang.String>);
```

### `AttachmentTemplateController`（7 方法）

`com.seeyon.boot.starter.udcrt.controller.AttachmentTemplateController`

```java
    com.seeyon.boot.transport.SingleResponse<com.seeyon.boot.starter.udcrt.dto.AttachmentTemplateDto> create(com.seeyon.boot.starter.udcrt.dto.AttachmentTemplateDto);
    com.seeyon.boot.transport.ListResponse<com.seeyon.boot.starter.udcrt.dto.AttachmentTemplateDto> createBatch(java.util.List<com.seeyon.boot.starter.udcrt.dto.AttachmentTemplateDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.udc.common.dto.CommonFileDto> selectByGuid(java.lang.Long);
    com.seeyon.boot.transport.ListResponse<com.seeyon.udc.common.dto.CommonFileDto> selectByGuids(java.util.List<java.lang.Long>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.udc.common.dto.CommonFileDto> selectByAppId(java.lang.Long);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> delete(java.lang.Long);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> deleteByGuids(java.util.List<java.lang.Long>);
```

### `ResourcePermissionService`（7 方法）

`com.seeyon.boot.starter.udcrt.domain.service.ResourcePermissionService`

```java
    void registerResource(com.seeyon.ctp.user.message.dto.ResourceMessageDto);
    void removeResource(java.lang.String);
    void registerPermission(com.seeyon.ctp.user.message.dto.ResourcePermissionMessageDto);
    void registerResourceAndPermission(com.seeyon.ctp.user.message.dto.ResourceAndPermissionMessageDto);
    void removePermission(java.lang.String);
    void registerResourceUser(com.seeyon.ctp.user.message.dto.UserResourceMessageDto);
    java.lang.Boolean checkUserResourceCode(com.seeyon.ctp.user.dto.CtpUserResourceSearchDto);
```

### `UdcRtPageLogService`（7 方法）

`com.seeyon.boot.starter.udcrt.domain.service.UdcRtPageLogService`

```java
    int createBatch(java.util.List<com.seeyon.boot.starter.udcrt.dto.UdcRtPageLogDto>);
    int create(com.seeyon.boot.starter.udcrt.dto.UdcRtPageLogDto);
    com.seeyon.boot.transport.PageData<com.seeyon.udc.common.dto.UdcRtPageLogSearchResultDto> search(com.seeyon.udc.common.dto.UdcRtPageLogSearchDto, com.seeyon.boot.transport.PageInfo, com.seeyon.boot.transport.Sort);
    com.seeyon.boot.transport.PageData<com.seeyon.udc.common.dto.UdcRtPageLogSearchResultDto> searchNonMetadata(com.seeyon.udc.common.dto.UdcRtPageLogSearchDto, com.seeyon.boot.transport.PageInfo, com.seeyon.boot.transport.Sort);
    int deleteAll();
    private com.seeyon.boot.domain.dao.Wrapper buildWrapper(com.seeyon.udc.common.dto.UdcRtPageLogSearchDto, com.seeyon.boot.transport.Sort);
```

### `UdcProxyAppServiceComponent`（7 方法）

`com.seeyon.boot.starter.udcrt.proxy.UdcProxyAppServiceComponent`

```java
    java.lang.Class<?> getClass(com.seeyon.boot.starter.udcrt.proxy.dto.UdcRestPathParseDto);
    private java.lang.Class<?> getClass(java.lang.String, java.lang.String, java.lang.String);
    <T> T proxyMicroFlowAppServiceMethod(com.seeyon.boot.starter.udcrt.proxy.dto.UdcMicroFlowRequestDto);
    <T> T proxyEntityAppServiceMethod(com.seeyon.boot.starter.udcrt.proxy.dto.UdcEntityRequestDto);
    <T> T proxyDataFlowAppServiceMethod(com.seeyon.boot.starter.udcrt.proxy.dto.UdcDataFlowRequestDto);
    boolean isGenericCall(com.seeyon.boot.starter.udcrt.proxy.dto.UdcEntityRequestDto);
    private void loadFormExplicitly(com.seeyon.boot.starter.udcrt.proxy.dto.UdcEntityRequestDto);
```

### `EntityRuleUtil`（7 方法）

`com.seeyon.boot.starter.udcrt.util.EntityRuleUtil`

```java
    static boolean checkObjectOrString(java.lang.Object);
    static boolean isNotDeleteActionType(java.lang.Object);
    static java.util.Set<java.lang.Long> getDeletedIds(java.util.List<? extends com.seeyon.udc.common.dto.BaseEntityActionDto>);
```

### `UdcArchiveTreeEntityRuntimeAppService`（6 方法）

`com.seeyon.boot.starter.udcrt.appservice.UdcArchiveTreeEntityRuntimeAppService`

```java
    com.seeyon.boot.starter.dynamicsql.dto.ProxyJoinParamDto assembleCondition(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.udcrt.dto.TreeQueryDto>, com.seeyon.boot.transport.SingleRequest<java.lang.Integer>);
    com.seeyon.boot.starter.dynamicsql.dto.ProxyJoinParamDto assembleCondition(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.udcrt.dto.TreeQueryDto>);
    com.seeyon.boot.starter.dynamicsql.dto.ProxyJoinParamDto assembleCondition4SelectHighestTree(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.udcrt.dto.TreeQueryDto>);
    com.seeyon.boot.starter.dynamicsql.dto.ProxyJoinParamDto assembleCondition4SelectAllChildren4HighestTree(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.udcrt.dto.TreeQueryDto>);
    private com.seeyon.boot.starter.udcrt.dto.FilterPlanDynamicSelectDto getFilterPlanDynamicSelectDto(com.seeyon.boot.starter.udcrt.dto.TreeQueryDto, java.util.Map<java.lang.String, java.lang.Object>);
    private void addTreeParam(com.seeyon.boot.starter.dynamicsql.dto.ProxyJoinParamDto, com.seeyon.boot.starter.udcrt.dto.TreeQueryDto);
```

### `AppDraftConfig`（6 方法）

`com.seeyon.boot.starter.udcrt.config.AppDraftConfig`

```java
    boolean isEnable();
    void setEnable(boolean);
    boolean equals(java.lang.Object);
    protected boolean canEqual(java.lang.Object);
    int hashCode();
    java.lang.String toString();
```

### `FormDataQueryService`（6 方法）

`com.seeyon.boot.starter.udcrt.dataquery.FormDataQueryService`

```java
    com.seeyon.boot.starter.udcrt.dto.EntityDataResponseDto selectEntityData(com.seeyon.boot.starter.udcrt.dto.EntityDataRequestDto);
    private java.util.Map<java.lang.String, java.lang.Object> selectRelationEntityData(java.lang.Object, com.seeyon.ctp.metadata.dto.AggEntityMetadataDto);
```

### `UdcPageInfoMetaDataEnhancedService`（6 方法）

`com.seeyon.boot.starter.udcrt.domain.service.UdcPageInfoMetaDataEnhancedService`

```java
    java.util.List<com.seeyon.boot.starter.extmetadata.dto.UdcMainPageMetadataDto> selectHostAppAndOnlyPageAppPages(com.seeyon.boot.starter.extmetadata.dto.request.UdcPagesMetaDataSearchDto);
    private java.util.Set<java.lang.String> parseCurrentOrgUnitPathIds(com.seeyon.boot.transport.SingleResponse<com.seeyon.organization.dto.core.response.OrgUnitDto>);
    private boolean illegalUsingScope(com.seeyon.boot.starter.udcrt.dto.CustomApplicationDto, java.util.Set<java.lang.String>, java.lang.String);
```

### `BpmPermissionHandlerDto`（6 方法）

`com.seeyon.boot.starter.udcrt.dto.BpmPermissionHandlerDto`

```java
    T getFormData();
    com.seeyon.boot.starter.customplan.dto.CBpmNodePermissionRequestDto getCBpmNodePermissionRequestDto();
    com.seeyon.boot.starter.udcrt.dto.RuntimePageCustomSearchDto getRuntimePageCustomSearchDto();
    void setFormData(T);
    void setCBpmNodePermissionRequestDto(com.seeyon.boot.starter.customplan.dto.CBpmNodePermissionRequestDto);
    void setRuntimePageCustomSearchDto(com.seeyon.boot.starter.udcrt.dto.RuntimePageCustomSearchDto);
```

### `AppDraftAppServiceImpl`（5 方法）

`com.seeyon.boot.starter.udcrt.appservice.AppDraftAppServiceImpl`

```java
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> createOrUpdate(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.udcrt.dto.AppDraftDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.boot.starter.udcrt.dto.AppDraftExistDto> exist(com.seeyon.boot.transport.SingleRequest<java.lang.String>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.boot.starter.udcrt.dto.AppDraftDto> select(com.seeyon.boot.transport.SingleRequest<java.lang.String>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> delete(com.seeyon.boot.transport.SingleRequest<java.lang.String>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> deleteAll(com.seeyon.boot.transport.SingleRequest<java.lang.String>);
```

### `BpmRetryService`（5 方法）

`com.seeyon.boot.starter.udcrt.domain.service.BpmRetryService`

```java
    void enqueue(java.lang.Object, java.util.Map);
    com.seeyon.boot.starter.udcrt.dto.BpmRetryTaskResultDto retry(com.seeyon.boot.starter.udcrt.dto.BpmRetryDto);
    static private static java.lang.String getAppNameByEntityFullName(java.lang.String);
    private boolean isDynamicApp(java.lang.String);
    private boolean isRetryFail(com.seeyon.boot.transport.SingleResponse<java.lang.Object>);
```

### `EntityAppServiceInvokeService`（5 方法）

`com.seeyon.boot.starter.udcrt.domain.service.EntityAppServiceInvokeService`

```java
    com.seeyon.ctp.metadata.dto.AppServiceMetadataDto findAppServiceMetaData(java.lang.String, java.lang.String);
    com.seeyon.boot.transport.SingleResponse invokeMethod(com.seeyon.ctp.metadata.dto.AppServiceMetadataDto, java.lang.String, java.lang.String, java.lang.String);
    com.seeyon.boot.transport.PageResponse invokePageMethod(com.seeyon.ctp.metadata.dto.AppServiceMetadataDto, java.lang.String, java.lang.String, java.lang.String);
```

### `UdcDataFlowLogService`（5 方法）

`com.seeyon.boot.starter.udcrt.domain.service.UdcDataFlowLogService`

```java
    int createBatch(java.util.List<com.seeyon.boot.starter.udcrt.dto.UdcBaseRuntimeLogDto>);
    com.seeyon.boot.transport.PageData<com.seeyon.boot.starter.udcrt.dto.UdcDataFlowLogDto> search(com.seeyon.udc.common.dto.DataFlowLogSearchDto, com.seeyon.boot.transport.PageInfo);
    com.seeyon.boot.transport.PageData<com.seeyon.boot.starter.udcrt.dto.UdcDataFlowLogDto> searchDetails(com.seeyon.udc.common.dto.DataFlowLogSearchDto, com.seeyon.boot.transport.PageInfo);
    private com.seeyon.boot.transport.PageData<com.seeyon.boot.starter.udcrt.dto.UdcDataFlowLogDto> pageWrapperByDataFlowLog(com.seeyon.boot.transport.PageInfo, com.seeyon.boot.domain.dao.Wrapper);
    int deleteAll();
```

### `UdcDeductionLogService`（5 方法）

`com.seeyon.boot.starter.udcrt.domain.service.UdcDeductionLogService`

```java
    int createBatch(java.util.List<com.seeyon.boot.starter.udcrt.dto.UdcBaseRuntimeLogDto>);
    com.seeyon.boot.transport.PageData<com.seeyon.boot.starter.udcrt.dto.UdcDeductionLogDto> search(com.seeyon.udc.common.dto.DeductionLogSearchDto, com.seeyon.boot.transport.PageInfo);
    com.seeyon.boot.transport.PageData<com.seeyon.boot.starter.udcrt.dto.UdcDeductionLogDto> searchDetails(com.seeyon.udc.common.dto.DeductionLogSearchDto, com.seeyon.boot.transport.PageInfo);
    private com.seeyon.boot.transport.PageData<com.seeyon.boot.starter.udcrt.dto.UdcDeductionLogDto> pageWrapperByDeductionLog(com.seeyon.boot.transport.PageInfo, com.seeyon.boot.domain.dao.Wrapper);
    int deleteAll();
```

### `EntityLogUtil`（5 方法）

`com.seeyon.boot.starter.udcrt.util.EntityLogUtil`

```java
    static boolean isEventBusMethod(java.lang.reflect.Method);
    static boolean isBaseEntityActionDtoClass(java.lang.Class<?>);
    static java.lang.Class<?> getDtoClassFromEventBusArgs(java.lang.Object);
    static java.lang.Class<?> getOriginalClass(java.lang.Object);
    static private static boolean isCglibProxyClass(java.lang.Class<?>);
```

### `MicroFlowRuntimeUtil`（5 方法）

`com.seeyon.boot.starter.udcrt.util.MicroFlowRuntimeUtil`

```java
    static void saveDefaultValue4RequestContext();
    static <T, U> void setFieldValueInDataMappingActivity(java.util.Map<java.lang.String, java.lang.Object>, java.lang.String, T, java.util.function.Function<java.lang.Object, U>, java.util.function.BiConsumer<T, U>);
    static com.seeyon.udc.common.dto.DataFlowExecuteParamDto buildDataFlowExecuteParamDtoWithCondition(java.util.Map<java.lang.String, java.lang.Object>, java.lang.Long);
    static com.seeyon.udc.common.dto.DataFlowExecuteParamDto buildDataFlowExecuteParamDtoWithCondition(com.seeyon.boot.starter.condition.output.map.MapConditionResult, java.lang.Long);
    static com.seeyon.udc.common.dto.DataFlowExecuteParamDto buildDataFlowExecuteParamDtoWithSelectParam(java.util.List<? extends com.seeyon.udc.common.dto.BaseEntityActionDto>, java.lang.Long);
```

### `TreeEntityUtil`（5 方法）

`com.seeyon.boot.starter.udcrt.util.TreeEntityUtil`

```java
    static java.lang.String getCodePatternByLength(int);
    static void checkCurLevelCode(int, java.lang.String);
    static java.util.List<java.lang.Long> getTreeEntityIdsByTreePath(java.lang.String);
```

### `AttributeSnapshotAppServiceImpl`（4 方法）

`com.seeyon.boot.starter.udcrt.appservice.AttributeSnapshotAppServiceImpl`

```java
    java.util.List<com.seeyon.boot.starter.lowcode.dto.AttributeSnapshotDto> selectByDataId(java.lang.Long);
    java.util.List<com.seeyon.boot.starter.lowcode.dto.AttributeSnapshotDto> selectByDataIds(java.util.List<java.lang.Long>);
    java.util.List<com.seeyon.boot.starter.lowcode.dto.AttributeSnapshotDto> selectByMasterDataId(java.lang.Long);
    java.util.List<com.seeyon.boot.starter.lowcode.dto.AttributeSnapshotDto> selectByMasterDataIds(java.util.List<java.lang.Long>);
```

### `UdcRtPageLogAppService`（4 方法）

`com.seeyon.boot.starter.udcrt.appservice.UdcRtPageLogAppService`

```java
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> createBatch(com.seeyon.boot.transport.SingleRequest<java.util.List<com.seeyon.boot.starter.udcrt.dto.UdcRtPageLogDto>>);
    com.seeyon.boot.transport.PageResponse<com.seeyon.udc.common.dto.UdcRtPageLogSearchResultDto> search(com.seeyon.boot.transport.PageDtoRequest<com.seeyon.udc.common.dto.UdcRtPageLogSearchDto>);
    com.seeyon.boot.transport.PageResponse<com.seeyon.udc.common.dto.UdcRtPageLogSearchResultDto> searchNonMetadata(com.seeyon.boot.transport.PageDtoRequest<com.seeyon.udc.common.dto.UdcRtPageLogSearchDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> deleteAll();
```

### `AttachmentTemplateRtEntity`（4 方法）

`com.seeyon.boot.starter.udcrt.domain.entity.AttachmentTemplateRtEntity`

```java
    java.lang.String getStorageKey();
    java.lang.Long getAppId();
    void setStorageKey(java.lang.String);
    void setAppId(java.lang.Long);
```

### `AppParamExpressionRtSchemaLoadServiceImpl`（4 方法）

`com.seeyon.boot.starter.udcrt.domain.service.AppParamExpressionRtSchemaLoadServiceImpl`

```java
    java.util.List<com.seeyon.boot.starter.formula.dto.variable.SchemaStructureDto> loadParamSchemaInfo(com.seeyon.boot.starter.formula.dto.variable.VariableSchemaLoadDto);
    private com.seeyon.boot.starter.formula.dto.variable.SchemaStructureDto buildJavaEnumType(com.seeyon.boot.starter.parameter.dto.CtpParameterDefinitionDto);
    com.seeyon.boot.starter.formula.dto.variable.SchemaStructureDto buildBasicType(com.seeyon.boot.starter.parameter.dto.CtpParameterDefinitionDto);
```

### `UdcRuntimeDatabaseQueryService`（4 方法）

`com.seeyon.boot.starter.udcrt.domain.service.database.UdcRuntimeDatabaseQueryService`

```java
    com.seeyon.boot.starter.udcrt.dto.UdcRuntimeDatabaseQueryRespDto queryData(com.seeyon.boot.starter.udcrt.dto.RuntimeDataBaseQueryDataReqDto);
    private java.util.List<com.seeyon.boot.starter.udcrt.dto.UdcRuntimeDataBaseColumnMetadataDto> getDatabaseColumnMetadata(java.lang.String);
    private java.util.List getDataList(java.lang.String, java.lang.Class<?>);
    static private static java.lang.String getTableName(java.lang.Class<?>);
```

### `MemberBelongsToService`（4 方法）

`com.seeyon.boot.starter.udcrt.domain.service.functionsupport.MemberBelongsToService`

```java
    int getParameterSize();
    java.lang.String getFunctionName();
    java.lang.Object calculate(java.util.List<java.lang.String>);
```

### `UnitBelongsToService`（4 方法）

`com.seeyon.boot.starter.udcrt.domain.service.functionsupport.UnitBelongsToService`

```java
    int getParameterSize();
    java.lang.String getFunctionName();
    java.lang.Object calculate(java.util.List<java.lang.String>);
```

### `AttachmentTemplateDto`（4 方法）

`com.seeyon.boot.starter.udcrt.dto.AttachmentTemplateDto`

```java
    java.lang.String getStorageKey();
    java.lang.Long getAppId();
    void setStorageKey(java.lang.String);
    void setAppId(java.lang.Long);
```

### `ExcelServiceHelper`（4 方法）

`com.seeyon.boot.starter.udcrt.excel.ExcelServiceHelper`

```java
    com.seeyon.boot.starter.udcrt.dto.ExcelDto buildExcelDto(com.seeyon.boot.starter.udcrt.dto.ExcelDynamicExportDto, java.lang.String, java.lang.String, java.lang.String);
    java.lang.String buildCondition4ExcelExport(com.seeyon.boot.starter.udcrt.dto.ExcelDto);
    private java.lang.Class<?> getClazz(com.seeyon.boot.starter.udcrt.dto.ExcelDto);
    private java.util.Map<java.lang.String, java.lang.Object> getDynamicSelectSetting(com.seeyon.boot.starter.udcrt.dto.FilterPlanDynamicSelectDto);
```

### `MicroFlowLogUtil`（4 方法）

`com.seeyon.boot.starter.udcrt.util.MicroFlowLogUtil`

```java
    static java.lang.String toJson4Log(java.lang.Object);
    static java.lang.Object toJson4LogV2(java.lang.Object, java.lang.String);
    static java.lang.String toJson4Log(java.lang.Object, java.lang.String);
    static java.lang.String convertProxyParamToJson(java.lang.String);
```

### `UdcOuterTreeEntityService`（3 方法）

`com.seeyon.boot.starter.udcrt.appservice.UdcOuterTreeEntityService`

```java
    com.seeyon.boot.transport.PageResponse selectOuterTree(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.udcrt.dto.TreeQueryDto>);
    com.seeyon.boot.transport.ListResponse selectOuterTreeChildren(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.udcrt.dto.TreeQueryDto>);
    private com.seeyon.boot.transport.PageResponse invokeTreeSelect(com.seeyon.udc.common.dto.tree.UdcTreeQueryDto);
```

### `UdcProxyEntityAppService`（3 方法）

`com.seeyon.boot.starter.udcrt.appservice.UdcProxyEntityAppService`

```java
    com.seeyon.boot.transport.SingleResponse<java.lang.Object> selectById(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.udcrt.proxy.dto.UdcEntityIdsRequestDto>);
    com.seeyon.boot.transport.ListResponse<java.lang.Object> selectByIds(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.udcrt.proxy.dto.UdcEntityIdsRequestDto>);
    private com.seeyon.boot.starter.udcrt.proxy.dto.UdcEntityRequestDto changeParams(com.seeyon.boot.starter.udcrt.proxy.dto.UdcEntityBaseRequestDto, java.lang.String);
```

### `BpmPermissionHandlerService`（3 方法）

`com.seeyon.boot.starter.udcrt.domain.service.BpmPermissionHandlerService`

```java
    void handlerSelectPermission(com.seeyon.boot.starter.udcrt.dto.BpmPermissionHandlerDto<T>);
    void handlerSelectPermission(T, com.seeyon.boot.starter.customplan.dto.CBpmNodePermissionRequestDto);
    private com.seeyon.boot.annotation.enums.MaskType changeMaskType(com.seeyon.bpm.enums.BpmFormDesensitizedTypeEnum);
```

### `EntityDataDiffCallBackService`（3 方法）

`com.seeyon.boot.starter.udcrt.domain.service.EntityDataDiffCallBackService`

```java
    <T extends com.seeyon.udc.common.dto.BaseEntityActionDto> java.util.List<com.seeyon.boot.starter.lowcode.dto.BaseCrudDiffDto> diffData(java.util.List<T>, java.util.Map<java.lang.Long, T>, java.util.Map<java.lang.Long, T>, com.seeyon.boot.starter.lowcode.core.EntityMeta);
    private <T extends com.seeyon.udc.common.dto.BaseEntityActionDto> void recursiveDiff(java.util.List<T>, java.util.Map<java.lang.Long, T>, com.seeyon.boot.starter.lowcode.core.EntityMeta, java.util.List<com.seeyon.boot.starter.lowcode.dto.BaseCrudDiffDto>, java.lang.Boolean, java.lang.Long);
```

### `FormHandlerFactory`（3 方法）

`com.seeyon.boot.starter.udcrt.domain.service.FormHandlerFactory`

```java
    static com.seeyon.boot.starter.udcrt.domain.service.FormHandler getFormHandler(com.seeyon.udc.common.enums.ApplicationSourceEnum);
    void afterPropertiesSet()
```

### `NormalDataHandler`（3 方法）

`com.seeyon.boot.starter.udcrt.domain.service.NormalDataHandler`

```java
    java.lang.Object dataProcess(com.seeyon.boot.starter.udcrt.dto.FormParamDto)
    private void assertNotNull(java.lang.Class<?>, java.lang.Object, java.lang.String);
    private void assertNotNull(java.lang.Object, java.lang.String);
```

### `CustomApplicationHandler`（3 方法）

`com.seeyon.boot.starter.udcrt.migration.CustomApplicationHandler`

```java
    boolean supports(java.lang.Class);
    java.util.Set<java.lang.String> getUpdateIgnoreFields(java.lang.Class<?>);
    <T extends com.seeyon.boot.domain.entity.BaseEntity> void processQueryData(com.seeyon.boot.starter.configmigration.core.context.ExecutionContext, T);
```

### `ScalabilityFieldHandler`（3 方法）

`com.seeyon.boot.starter.udcrt.migration.ScalabilityFieldHandler`

```java
    boolean supports(java.lang.Class<?>);
    <T extends com.seeyon.boot.domain.entity.BaseEntity> void processQueryData(com.seeyon.boot.starter.configmigration.core.context.ExecutionContext, T);
    <T extends com.seeyon.boot.domain.entity.BaseEntity> void processReplaceData(com.seeyon.boot.starter.configmigration.core.context.ExecutionContext, T);
```

### `EntityRtDaoContainer`（3 方法）

`com.seeyon.boot.starter.udcrt.util.EntityRtDaoContainer`

```java
    void setApplicationContext(org.springframework.context.ApplicationContext)
    com.seeyon.boot.starter.mybatis.BaseMybatisDao findDao(java.lang.String);
    private com.seeyon.boot.starter.mybatis.BaseMybatisDao findDao(java.lang.Class);
```

## 四、枚举（5）

- `ExcelTableHeadFieldTypeEnum`（3 常量）：VARCHAR, ENTITY, ENUM
- `LogModuleEnum`（1 常量）：MICRO_FLOW
- `MicroFlowActivityTypeEnum`（87 常量）：CONNECTOR, CREATE_VARIABLE, CHANGE_VARIABLE, CREATE_LIST, CHANGE_LIST, PUBLISH_BUSINESS_EVENT, ATTRIBUTE_REQUIRED, ASSIGN_VALUE, SHOW_MESSAGE, ATTRIBUTE_UNIQUE, RETRIEVE, RETRIEVE_ARRAY …
- `ModuleSubTypeEnum`（5 常量）：MICRO_FLOW_MANUAL, MICRO_FLOW_FRONTEND, MICRO_FLOW_ENTITY_RULE, MICRO_FLOW_BUSINESS_EVENT, MICRO_FLOW_SCHEDULE
- `WebRequestTypeEnum`（6 常量）：PAGE_DATASOURCE, PAGE_FILTER, PAGE_REFER, PAGE_REFER_CARRY, PAGE_MICRO_FLOW, DATA_FLOW
