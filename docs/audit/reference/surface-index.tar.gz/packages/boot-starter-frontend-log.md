# boot-starter-frontend-log：接口与方法签名

> 自动生成，勿手改。`tools/core/platform/emit_package_surfaces.py` 重跑即可。
> 构件 `com.seeyon:boot-starter-frontend-log`（jar `boot-starter-frontend-log-5.3.600.jar`）
> 规模：8 类 / 0 接口 / 0 注解 / 1 枚举 / 5 个关键类 / 26 方法。
> 签名逐字来自 javap 原文；已去掉 `public` 前缀与 `throws` 子句。

## 一、接口（0）

（本构件没有接口）

## 二、关键类（5）

### `FrontendLogDto`（10 方法）

`com.seeyon.boot.starter.frontend.log.dto.FrontendLogDto`

```java
    java.lang.String getAppName();
    java.lang.String getLogType();
    java.lang.String getErrorType();
    java.lang.String getLogContent();
    long getTimeStamp();
    void setAppName(java.lang.String);
    void setLogType(java.lang.String);
    void setErrorType(java.lang.String);
    void setLogContent(java.lang.String);
    void setTimeStamp(long);
```

### `FrontendHeaderLogDto`（6 方法）

`com.seeyon.boot.starter.frontend.log.dto.FrontendHeaderLogDto`

```java
    java.lang.String getHost();
    java.lang.String getReferer();
    java.lang.String getUserAgent();
    void setHost(java.lang.String);
    void setReferer(java.lang.String);
    void setUserAgent(java.lang.String);
```

### `FrontendLogController`（2 方法）

`com.seeyon.boot.starter.frontend.log.controller.FrontendLogController`

```java
    com.seeyon.boot.transport.SingleResponse reportLog(org.springframework.util.MultiValueMap<java.lang.String, java.lang.String>, com.seeyon.boot.starter.frontend.log.dto.request.FrontendLogRequestDto);
```

### `FrontendLogRequestDto`（2 方法）

`com.seeyon.boot.starter.frontend.log.dto.request.FrontendLogRequestDto`

```java
    java.util.List<com.seeyon.boot.starter.frontend.log.dto.FrontendLogDto> getList();
    void setList(java.util.List<com.seeyon.boot.starter.frontend.log.dto.FrontendLogDto>);
```

### `FrontendLogInitialize`（1 方法）

`com.seeyon.boot.starter.frontend.log.init.FrontendLogInitialize`

```java
    void init(com.seeyon.boot.log.LogbackConfigurator);
```

## 四、枚举（1）

- `FrontendLogType`（3 常量）：CODE_ERROR, RESOURCES_ERROR, GENERAL_LOG
