# boot-core：接口与方法签名

> 自动生成，勿手改。`tools/core/platform/emit_package_surfaces.py` 重跑即可。
> 构件 `com.seeyon:boot-core`（jar `boot-core-5.3.600.jar`）
> 规模：512 类 / 47 接口 / 38 注解 / 29 枚举 / 87 个关键类 / 3940 方法。
> 签名逐字来自 javap 原文；已去掉 `public` 前缀与 `throws` 子句。

## 一、接口（47）

### `BaseDao`（34 方法）

`com.seeyon.boot.domain.dao.BaseDao`

```java
    int create(T);
    int createBatch(java.util.List<T>);
    int createBatchNoClob(java.util.List<T>);
    int createBatchIgnoreTime(java.util.List<T>);
    int update(T);
    int updateColumns(T, java.util.Set<java.lang.String>);
    int updateColumnsIgnoreVersion(T, java.util.Set<java.lang.String>);
    int updateBatch(java.util.List<T>);
    int updateBatchIgnoreTime(java.util.List<T>);
    int updateBatchIgnoreVersion(java.util.List<T>);
    int versionNoUpdateBatchIgnoreVersion(java.util.List<T>);
    int deleteById(java.lang.Long);
    int deleteByIds(java.util.List<java.lang.Long>);
    int deleteByCondition(java.lang.String, java.lang.Object);
    int deleteByConditions(java.util.Map<java.lang.String, java.lang.Object>);
    int deleteByWrapper(com.seeyon.boot.domain.dao.Wrapper);
    T selectById(java.lang.Long);
    java.util.List<T> selectByIds(java.util.List<java.lang.Long>);
    T selectOneByCondition(java.lang.String, java.lang.Object);
    T selectOneByConditions(java.util.Map<java.lang.String, java.lang.Object>);
    int selectCountByCondition(java.lang.String, java.lang.Object);
    int selectCountByConditions(java.util.Map<java.lang.String, java.lang.Object>);
    java.util.List<T> selectListByCondition(java.lang.String, java.lang.Object, com.seeyon.boot.transport.Sort);
    java.util.List<T> selectListByConditions(java.util.Map<java.lang.String, java.lang.Object>, com.seeyon.boot.transport.Sort);
    java.util.List<T> selectListPropertiesByConditions(java.lang.String[], java.util.Map<java.lang.String, java.lang.Object>, com.seeyon.boot.transport.Sort);
    java.util.List<T> selectListExcludeByConditions(java.lang.String[], java.util.Map<java.lang.String, java.lang.Object>, com.seeyon.boot.transport.Sort);
    com.seeyon.boot.transport.PageData<T> selectPageByCondition(com.seeyon.boot.transport.PageInfo, java.lang.String, java.lang.Object, com.seeyon.boot.transport.Sort);
    com.seeyon.boot.transport.PageData<T> selectPageByConditions(com.seeyon.boot.transport.PageInfo, java.util.Map<java.lang.String, java.lang.Object>, com.seeyon.boot.transport.Sort);
    com.seeyon.boot.transport.PageData<T> selectPagePropertiesByConditions(com.seeyon.boot.transport.PageInfo, java.lang.String[], java.util.Map<java.lang.String, java.lang.Object>, com.seeyon.boot.transport.Sort);
    com.seeyon.boot.transport.PageData<T> selectPageExcludeByConditions(com.seeyon.boot.transport.PageInfo, java.lang.String[], java.util.Map<java.lang.String, java.lang.Object>, com.seeyon.boot.transport.Sort);
    T selectOneByWrapper(com.seeyon.boot.domain.dao.Wrapper);
    int selectCountByWrapper(com.seeyon.boot.domain.dao.Wrapper);
    java.util.List<T> selectListByWrapper(com.seeyon.boot.domain.dao.Wrapper);
    com.seeyon.boot.transport.PageData<T> selectPageByWrapper(com.seeyon.boot.transport.PageInfo, com.seeyon.boot.domain.dao.Wrapper);
```

### `TypeConverterManager`（11 方法）

`com.seeyon.boot.util.bean.TypeConverterManager`

```java
    <T> java.util.Collection<com.seeyon.boot.util.bean.TypeConverter<T>> getTypeConverter(java.lang.Class<T>);
    <S, T> com.seeyon.boot.util.bean.TypeConverter<T> getTypeConverter(java.lang.Class<S>, java.lang.Class<T>);
    <S, T> void register(java.lang.Class<? extends S>, java.lang.Class<T>, com.seeyon.boot.util.bean.TypeConverter<? extends T>);
    void register(com.seeyon.boot.util.bean.TypeConverter<?>);
    <S, T> com.seeyon.boot.util.bean.TypeConverter<T> unregister(java.lang.Class<S>, java.lang.Class<T>);
    <T> java.util.Collection<com.seeyon.boot.util.bean.TypeConverter<T>> unregister(java.lang.Class<T>);
    boolean containsType(java.lang.Class<?>);
    boolean containsType(java.lang.Class<?>, java.lang.Class<?>);
    boolean containsConverter(java.lang.Class<com.seeyon.boot.util.bean.TypeConverter<?>>);
    boolean canConvert(java.lang.Class<?>, java.lang.Class<?>);
    <T> T convert(java.lang.Object, java.lang.Class<T>);
```

### `Entityable`（10 方法）

`com.seeyon.boot.domain.entity.Entityable`

```java
    void setId(java.lang.Long);
    java.lang.Long getId();
    java.util.Date getCreateTime();
    void setCreateTime(java.util.Date);
    java.util.Date getUpdateTime();
    void setUpdateTime(java.util.Date);
    void setTenantId(java.lang.Long);
    default boolean isNew();
    default java.lang.String mgnToString();
    default java.lang.Object getId();
```

### `SeeyonCache`（8 方法） extends Serializable

`com.seeyon.boot.util.cache.SeeyonCache`

```java
    long size();
    boolean isEmpty();
    boolean containsKey(K);
    V get(K);
    boolean put(K, V);
    boolean remove(K);
    void putAll(java.util.Map<? extends K, ? extends V>);
    void clear();
```

### `Inspection`（7 方法）

`com.seeyon.boot.inspection.Inspection`

```java
    java.lang.String getName();
    boolean enable();
    java.lang.String getCaption();
    int getSort();
    java.util.List<com.seeyon.boot.inspection.dto.InspectionItemDto> getItems();
    com.seeyon.boot.inspection.dto.InspectionResultDto inspection();
    default void sortInspectionItems(java.util.List<com.seeyon.boot.inspection.dto.InspectionItemDto>);
```

### `MessageRepository`（7 方法）

`com.seeyon.boot.starter.i18n.MessageRepository`

```java
    java.lang.String getMessage(java.lang.String, java.lang.Object[]);
    java.lang.String getMessage(java.lang.String);
    java.lang.String getMessage(java.lang.String, java.lang.Object[], java.util.Locale);
    java.lang.String getMessage(java.lang.String, java.lang.String, java.lang.Object[]);
    java.lang.String getMessage(java.lang.String, java.lang.String);
    java.lang.String getMessage(java.lang.String, java.lang.String, java.lang.Object[], java.util.Locale);
    void loadBundle(java.lang.String);
```

### `TenantChangeFunction`（6 方法）

`com.seeyon.boot.function.TenantChangeFunction`

```java
    <R> R apply(java.lang.String, java.util.function.Supplier<R>);
    <R> R apply(java.lang.Long, java.util.function.Supplier<R>);
    void apply(java.lang.String, com.seeyon.boot.function.NothingFunction);
    void apply(java.lang.Long, com.seeyon.boot.function.NothingFunction);
    <T, R> R apply(java.lang.Long, T, java.util.function.Function<T, R>);
    <T, U, R> R apply(java.lang.Long, T, U, java.util.function.BiFunction<T, U, R>);
```

### `Asymmetric`（5 方法）

`com.seeyon.boot.encrypt.algorithm.asymmetric.Asymmetric`

```java
    java.lang.String getName();
    com.seeyon.boot.encrypt.algorithm.asymmetric.key.AsymmetricKey generateKey();
    java.lang.String encrypt(java.lang.String, java.lang.String);
    java.lang.String decrypt(java.lang.String, java.lang.String);
    java.lang.String getCipherTextPrefix();
```

### `BaseSecretEntityable`（4 方法）

`com.seeyon.boot.domain.entity.BaseSecretEntityable`

```java
    void setSecretId(java.lang.Long);
    void setSecretN(java.lang.Integer);
    java.lang.Long getSecretId();
    java.lang.Integer getSecretN();
```

### `BaseSignEntityable`（4 方法） extends Entityable

`com.seeyon.boot.domain.entity.BaseSignEntityable`

```java
    void setDataSign(java.lang.String);
    void setDataSignSuccess(java.lang.Integer);
    java.lang.String getDataSign();
    java.lang.Integer getDataSignSuccess();
```

### `Digest`（4 方法）

`com.seeyon.boot.encrypt.algorithm.digest.Digest`

```java
    java.lang.String getName();
    java.lang.String getCipherTextPrefix();
    java.lang.String encrypt(java.lang.String);
    boolean equals(java.lang.String, java.lang.String);
```

### `Symmetric`（4 方法）

`com.seeyon.boot.encrypt.algorithm.symmetric.Symmetric`

```java
    java.lang.String getName();
    java.lang.String getCipherTextPrefix();
    java.lang.String encrypt(java.lang.String);
    java.lang.String decrypt(java.lang.String);
```

### `ComponentDynamicLoader`（4 方法）

`com.seeyon.boot.loader.ComponentDynamicLoader`

```java
    default boolean loader(java.lang.String, java.lang.Class);
    boolean isComponent(java.lang.Class);
    default org.springframework.beans.factory.config.BeanDefinitionHolder buildBeanDefinitionHolder(java.lang.String, java.lang.Class);
    default void finishLoad();
```

### `TypeConverter`（4 方法）

`com.seeyon.boot.util.bean.TypeConverter`

```java
    java.lang.Class<T> getTargetType();
    java.util.List<java.lang.Class<?>> getSupportedSourceTypes();
    T convert(java.util.Map<? extends java.lang.Object, ? extends java.lang.Object>, java.lang.Object, java.lang.Class<? extends T>);
    T convert(java.lang.Object, java.lang.Class<? extends T>);
```

### `AsymmetricSpi`（3 方法）

`com.seeyon.boot.encrypt.algorithm.asymmetric.spi.AsymmetricSpi`

```java
    java.lang.String encrypt(java.lang.String, java.lang.String);
    java.lang.String decrypt(java.lang.String, java.lang.String);
    com.seeyon.boot.encrypt.algorithm.asymmetric.key.AsymmetricKey generateKey();
```

### `LicensePlugin`（3 方法）

`com.seeyon.boot.license.LicensePlugin`

```java
    boolean hasPlugin(java.lang.String);
    boolean hasAnyPlugin(java.util.Set<java.lang.String>);
    boolean hasAllPlugin(java.util.Set<java.lang.String>);
```

### `ModuleBeanRepository`（3 方法）

`com.seeyon.boot.loader.ModuleBeanRepository`

```java
    java.lang.Object getBean(java.lang.String);
    <T> T getBean(java.lang.Class<T>);
    <T> java.util.Map<java.lang.String, T> getBeansOfType(java.lang.Class<T>)
```

### `ComponentSecurityCheck`（3 方法）

`com.seeyon.boot.security.service.ComponentSecurityCheck`

```java
    boolean check(com.seeyon.boot.security.dto.ComponentCheckDto);
    boolean checkUser(java.lang.String, java.util.Map<java.lang.String, java.lang.Object>);
    default java.lang.String appName();
```

### `IdentifierGenerator`（3 方法）

`com.seeyon.boot.util.id.IdentifierGenerator`

```java
    java.lang.Long generateLong();
    java.lang.String generateString();
    T analyze(java.lang.Long);
```

### `BootRequestContextHolder`（2 方法）

`com.seeyon.boot.context.BootRequestContextHolder`

```java
    void setTenantId(java.lang.Long);
    void clear();
```

### `SymmetricSpi`（2 方法）

`com.seeyon.boot.encrypt.algorithm.symmetric.spi.SymmetricSpi`

```java
    java.lang.String encrypt(java.lang.String);
    java.lang.String decrypt(java.lang.String);
```

### `Messageable`（2 方法） extends Serializable

`com.seeyon.boot.enums.Messageable`

```java
    int code();
    <E extends com.seeyon.boot.enums.Messageable> E codeOf(java.lang.Class<E>, int);
```

### `TenantLoopFunction`（2 方法）

`com.seeyon.boot.function.TenantLoopFunction`

```java
    void apply(com.seeyon.boot.function.NothingFunction);
```

### `ComponentInitializer`（2 方法） extends AutoConfigExclude

`com.seeyon.boot.init.ComponentInitializer`

```java
    default void initialize(org.springframework.context.ConfigurableApplicationContext);
    default void setPropertyIfMissing(java.lang.String, java.lang.Object);
```

### `SeeyonApplicationRunner`（2 方法）

`com.seeyon.boot.init.SeeyonApplicationRunner`

```java
    void run()
    default int getOrder();
```

### `ComponentDynamicRegister`（2 方法）

`com.seeyon.boot.loader.ComponentDynamicRegister`

```java
    void register(java.lang.String, java.util.List<java.lang.String>);
    void unregister(java.lang.String);
```

### `ModuleProcessor`（2 方法）

`com.seeyon.boot.loader.ModuleProcessor`

```java
    void initialize(com.seeyon.boot.loader.ModuleAppClassLoader, java.lang.String, java.util.Set<java.lang.String>);
    void destroy(java.lang.String);
```

### `SysOpsDubboApi`（2 方法）

`com.seeyon.boot.sys.SysOpsDubboApi`

```java
    boolean dubboExport();
    boolean dubboUnExport();
```

### `LRUMapListener`（1 方法）

`com.seeyon.boot.cache.LRUMapListener`

```java
    void onRemove(K, V);
```

### `AppBeanNameModifier`（1 方法）

`com.seeyon.boot.common.AppBeanNameModifier`

```java
    default java.lang.String modifyBeanName(org.springframework.beans.factory.config.BeanDefinition, java.lang.String);
```

### `ComponentEntityable`（1 方法） extends Entityable

`com.seeyon.boot.domain.entity.ComponentEntityable`

```java
    void setAggregationAppName(java.lang.String);
```

### `HistorytEntityable`（1 方法） extends Entityable

`com.seeyon.boot.domain.entity.HistorytEntityable`

```java
    void setArchiveTime(java.util.Date);
```

### `AccessAuditLogService`（1 方法）

`com.seeyon.boot.domain.service.AccessAuditLogService`

```java
    void create(java.lang.String[], java.lang.String);
```

### `DigestSpi`（1 方法）

`com.seeyon.boot.encrypt.algorithm.digest.spi.DigestSpi`

```java
    java.lang.String encrypt(java.lang.String);
```

### `FindBusinessExceptionHandler`（1 方法）

`com.seeyon.boot.exception.FindBusinessExceptionHandler`

```java
    com.seeyon.boot.exception.BusinessException handler(java.lang.Throwable);
```

### `NothingFunction`（1 方法）

`com.seeyon.boot.function.NothingFunction`

```java
    void apply();
```

### `TenantSetFunction`（1 方法）

`com.seeyon.boot.function.TenantSetFunction`

```java
    void apply(java.lang.Long, com.seeyon.boot.function.NothingFunction);
```

### `AutoConfigExclude`（1 方法）

`com.seeyon.boot.init.AutoConfigExclude`

```java
    default java.util.List<java.lang.String> excludeAutoConfigClassNames();
```

### `DynamicClassLoader`（1 方法）

`com.seeyon.boot.loader.DynamicClassLoader`

```java
    java.lang.Class loadClass(java.lang.String);
```

### `LogInitializer`（1 方法）

`com.seeyon.boot.log.init.LogInitializer`

```java
    void init(com.seeyon.boot.log.LogbackConfigurator);
```

### `DeadLoopFunction`（1 方法）

`com.seeyon.boot.thread.DeadLoopFunction`

```java
    boolean apply()
```

### `FinalizableReference`（1 方法）

`com.seeyon.boot.util.bean.collection.ref.FinalizableReference`

```java
    void finalizeReferent();
```

### `ExcelDataHandler`（1 方法）

`com.seeyon.boot.util.excel.ExcelDataHandler`

```java
    void handle(T);
```

### `TokenConstants`（0 方法）

`com.seeyon.boot.common.TokenConstants`

```java
```

### `CommandConstants`（0 方法）

`com.seeyon.boot.message.CommandConstants`

```java
```

### `CtpMeterBinder`（0 方法） extends MeterBinder

`com.seeyon.boot.meter.CtpMeterBinder`

```java
```

### `AutoClearable`（0 方法）

`com.seeyon.boot.util.bean.collection.AutoClearable`

```java
```

## 二、关键类（87）

### `HttpClientUtil`（93 方法）

`com.seeyon.boot.util.http.HttpClientUtil`

```java
    static private static void create(com.seeyon.boot.util.http.common.HttpConfig)
    static java.lang.String get(java.lang.String, java.nio.charset.Charset);
    static <T> T get(java.lang.String, java.nio.charset.Charset, java.lang.Class<T>);
    static java.lang.String get(java.lang.String);
    static <T> T get(java.lang.String, java.lang.Class<T>);
    static java.lang.String get(java.lang.String, java.util.Map<java.lang.String, java.lang.Object>);
    static <T> T get(java.lang.String, java.util.Map<java.lang.String, java.lang.Object>, java.lang.Class<T>);
    static java.lang.String get(java.lang.String, java.util.Map<java.lang.String, java.lang.Object>, int);
    static <T> T get(java.lang.String, java.util.Map<java.lang.String, java.lang.Object>, int, java.lang.Class<T>);
    static java.lang.String get(java.lang.String, int);
    static <T> T get(java.lang.String, int, java.lang.Class<T>);
    static java.lang.String get(java.lang.String, java.nio.charset.Charset, int, com.seeyon.boot.util.http.common.HttpHeader, java.util.Map<java.lang.String, java.lang.Object>);
    static <T> T get(java.lang.String, java.nio.charset.Charset, int, com.seeyon.boot.util.http.common.HttpHeader, java.util.Map<java.lang.String, java.lang.Object>, java.lang.Class<T>);
    static java.lang.String get(java.lang.String, java.nio.charset.Charset, int, com.seeyon.boot.util.http.common.HttpHeader);
    static <T> T get(java.lang.String, java.nio.charset.Charset, int, com.seeyon.boot.util.http.common.HttpHeader, java.lang.Class<T>);
    static java.lang.String get(java.lang.String, com.seeyon.boot.util.http.common.HttpHeader);
    static <T> T get(java.lang.String, com.seeyon.boot.util.http.common.HttpHeader, java.lang.Class<T>);
    static java.lang.String get(java.lang.String, com.seeyon.boot.util.http.common.HttpHeader, java.util.Map<java.lang.String, java.lang.Object>);
    static java.util.Map<java.lang.String, java.lang.Object> getOverload(java.lang.String, com.seeyon.boot.util.http.common.HttpHeader, java.util.Map<java.lang.String, java.lang.Object>);
    static <T> T get(java.lang.String, com.seeyon.boot.util.http.common.HttpHeader, java.util.Map<java.lang.String, java.lang.Object>, java.lang.Class<T>);
    static java.lang.String get(com.seeyon.boot.util.http.common.HttpConfig)
    static java.util.Map<java.lang.String, java.lang.Object> getOverload(com.seeyon.boot.util.http.common.HttpConfig)
    static <T> T get(com.seeyon.boot.util.http.common.HttpConfig, java.lang.Class<T>)
    static java.lang.String delete(java.lang.String);
    static java.lang.String delete(java.lang.String, com.seeyon.boot.util.http.common.HttpHeader);
    static com.seeyon.boot.util.http.common.HttpResult delete(com.seeyon.boot.util.http.common.HttpConfig);
    static java.lang.String post(java.lang.String, java.util.Map<java.lang.String, java.lang.Object>);
    static <T> T post(java.lang.String, java.util.Map<java.lang.String, java.lang.Object>, java.lang.Class<T>);
    static java.lang.String post(java.lang.String, java.util.Map<java.lang.String, java.lang.Object>, com.seeyon.boot.util.http.common.HttpHeader);
    static <T> T post(java.lang.String, java.util.Map<java.lang.String, java.lang.Object>, com.seeyon.boot.util.http.common.HttpHeader, java.lang.Class<T>);
    static java.lang.String post(java.lang.String, java.util.Map<java.lang.String, java.lang.Object>, com.seeyon.boot.util.http.common.HttpHeader, int, java.nio.charset.Charset);
    static <T> T post(java.lang.String, java.util.Map<java.lang.String, java.lang.Object>, com.seeyon.boot.util.http.common.HttpHeader, int, java.nio.charset.Charset, java.lang.Class<T>);
    static java.lang.String post(java.lang.String, java.util.Map<java.lang.String, java.lang.Object>, int);
    static <T> T post(java.lang.String, java.util.Map<java.lang.String, java.lang.Object>, int, java.lang.Class<T>);
    static java.lang.String post(java.lang.String, java.lang.String);
    static <T> T post(java.lang.String, java.lang.String, java.lang.Class<T>);
    static java.lang.String post(java.lang.String, java.lang.String, com.seeyon.boot.util.http.common.HttpHeader);
    static java.util.Map<java.lang.String, java.lang.Object> postOverload(java.lang.String, java.lang.String, com.seeyon.boot.util.http.common.HttpHeader);
    static <T> T post(java.lang.String, java.lang.String, com.seeyon.boot.util.http.common.HttpHeader, java.lang.Class<T>);
    static java.lang.String post(java.lang.String, java.lang.String, com.seeyon.boot.util.http.common.HttpHeader, int, java.nio.charset.Charset);
    static <T> T post(java.lang.String, java.lang.String, com.seeyon.boot.util.http.common.HttpHeader, int, java.nio.charset.Charset, java.lang.Class<T>);
    static java.lang.String post(java.lang.String, java.lang.String, int);
    static <T> T post(java.lang.String, java.lang.String, int, java.lang.Class<T>);
    static java.lang.String post(com.seeyon.boot.util.http.common.HttpConfig)
    static java.util.Map<java.lang.String, java.lang.Object> postOverload(com.seeyon.boot.util.http.common.HttpConfig)
    static <T> T post(com.seeyon.boot.util.http.common.HttpConfig, java.lang.Class<T>)
    static com.seeyon.boot.util.http.common.HttpResult sendGet(java.lang.String, java.nio.charset.Charset);
    static com.seeyon.boot.util.http.common.HttpResult sendGet(java.lang.String);
    static com.seeyon.boot.util.http.common.HttpResult sendGet(java.lang.String, java.util.Map<java.lang.String, java.lang.Object>);
    static com.seeyon.boot.util.http.common.HttpResult sendGet(java.lang.String, java.util.Map<java.lang.String, java.lang.Object>, int);
    static com.seeyon.boot.util.http.common.HttpResult sendGet(java.lang.String, int);
    static com.seeyon.boot.util.http.common.HttpResult sendGet(java.lang.String, java.nio.charset.Charset, int, com.seeyon.boot.util.http.common.HttpHeader, java.util.Map<java.lang.String, java.lang.Object>);
    static com.seeyon.boot.util.http.common.HttpResult sendGet(java.lang.String, java.nio.charset.Charset, int, com.seeyon.boot.util.http.common.HttpHeader);
    static com.seeyon.boot.util.http.common.HttpResult sendGet(java.lang.String, com.seeyon.boot.util.http.common.HttpHeader);
    static com.seeyon.boot.util.http.common.HttpResult sendGet(java.lang.String, com.seeyon.boot.util.http.common.HttpHeader, java.util.Map<java.lang.String, java.lang.Object>);
    static com.seeyon.boot.util.http.common.HttpResult sendGet(com.seeyon.boot.util.http.common.HttpConfig)
    static com.seeyon.boot.util.http.common.HttpResult sendPost(java.lang.String, java.util.Map<java.lang.String, java.lang.Object>);
    static com.seeyon.boot.util.http.common.HttpResult sendPost(java.lang.String, java.util.Map<java.lang.String, java.lang.Object>, com.seeyon.boot.util.http.common.HttpHeader);
    static com.seeyon.boot.util.http.common.HttpResult sendPost(java.lang.String, java.util.Map<java.lang.String, java.lang.Object>, com.seeyon.boot.util.http.common.HttpHeader, int, java.nio.charset.Charset);
    static com.seeyon.boot.util.http.common.HttpResult sendPost(java.lang.String, java.util.Map<java.lang.String, java.lang.Object>, int);
    static com.seeyon.boot.util.http.common.HttpResult sendPost(java.lang.String, java.lang.String);
    static com.seeyon.boot.util.http.common.HttpResult sendPost(java.lang.String, java.lang.String, com.seeyon.boot.util.http.common.HttpHeader);
    static com.seeyon.boot.util.http.common.HttpResult sendPost(java.lang.String, java.lang.String, com.seeyon.boot.util.http.common.HttpHeader, int, java.nio.charset.Charset);
    static com.seeyon.boot.util.http.common.HttpResult sendPost(java.lang.String, java.lang.String, int);
    static com.seeyon.boot.util.http.common.HttpResult sendPost(com.seeyon.boot.util.http.common.HttpConfig)
    static java.io.OutputStream down(com.seeyon.boot.util.http.common.HttpConfig)
    static java.io.OutputStream down(java.lang.String, java.io.OutputStream)
    static org.apache.http.HttpResponse down(java.lang.String)
    static java.io.InputStream downForInputStream(com.seeyon.boot.util.http.common.HttpConfig)
    static java.io.OutputStream down(java.lang.String, com.seeyon.boot.util.http.common.HttpHeader, java.io.OutputStream)
    static java.lang.String upload(com.seeyon.boot.util.http.common.HttpConfig)
    static java.lang.String upload(java.lang.String, java.io.InputStream, java.lang.String)
    static java.lang.String upload(java.lang.String, java.io.File)
    static java.lang.String upload(java.lang.String, java.io.File, java.lang.String)
    static <T> T upload(java.lang.String, java.io.InputStream, java.lang.String, java.lang.Class<T>)
    static <T> T upload(java.lang.String, java.io.File, java.lang.Class<T>)
    static <T> T upload(java.lang.String, java.io.File, java.lang.String, java.lang.Class<T>)
    static <T> T upload(com.seeyon.boot.util.http.common.HttpConfig, java.lang.Class<T>)
    static com.seeyon.boot.util.http.common.HttpResult uploadAndGetResp(com.seeyon.boot.util.http.common.HttpConfig)
    static com.seeyon.boot.util.http.common.HttpResult uploadAndGetResp(java.lang.String, java.io.InputStream, java.lang.String)
    static com.seeyon.boot.util.http.common.HttpResult uploadAndGetResp(java.lang.String, java.io.File)
    static com.seeyon.boot.util.http.common.HttpResult uploadAndGetResp(java.lang.String, java.io.File, java.lang.String)
    static com.seeyon.boot.util.http.common.HttpResult put(com.seeyon.boot.util.http.common.HttpConfig)
    static int status(com.seeyon.boot.util.http.common.HttpConfig)
    static private static java.lang.String send(com.seeyon.boot.util.http.common.HttpConfig)
    static private static java.util.Map<java.lang.String, java.lang.Object> sendOverload(com.seeyon.boot.util.http.common.HttpConfig)
    static private static com.seeyon.boot.util.http.common.HttpResult sendAndGetResp(com.seeyon.boot.util.http.common.HttpConfig)
    static private static org.apache.http.HttpResponse execute(com.seeyon.boot.util.http.common.HttpConfig)
    static private static java.lang.String fmt2String(org.apache.http.HttpResponse, java.lang.String)
    static private static int fmt2Int(org.apache.http.HttpResponse)
    static private static java.io.OutputStream fmt2Stream(org.apache.http.HttpResponse, java.io.OutputStream)
    static private static org.apache.http.client.methods.HttpRequestBase getRequest(com.seeyon.boot.util.http.common.HttpConfig);
    static private static void close(org.apache.http.HttpResponse);
```

### `DateUtils`（61 方法）

`com.seeyon.boot.util.DateUtils`

```java
    static void registerPattern(java.lang.String);
    static void unRegisterPattern(java.lang.String);
    static private static void sort();
    static java.util.Date getDate(java.util.Date);
    static int[] getTime(java.util.Date);
    static java.util.Date getDate(int, int, int, int, int, int);
    static java.lang.String formatDate(java.util.Date);
    static java.lang.String formatDatetime(java.util.Date);
    static java.lang.String format(java.util.Date, java.lang.String);
    static java.lang.String format(java.util.Date, java.lang.String, java.util.TimeZone);
    static java.lang.String format(java.util.Date, java.lang.String, java.util.TimeZone, java.util.Locale);
    static java.util.Date parseDate(java.lang.String);
    static java.util.Date parseDatetime(java.lang.String);
    static java.util.Date parse(java.lang.String);
    static java.util.Date parse(java.lang.String, java.lang.String...);
    static java.util.Date parse(java.lang.String, java.util.Locale, java.lang.String...);
    static java.util.Date addYear(java.util.Date, int);
    static java.util.Date addMonth(java.util.Date, int);
    static java.util.Date addWeek(java.util.Date, int);
    static java.util.Date addDay(java.util.Date, int);
    static java.util.Date addHour(java.util.Date, int);
    static java.util.Date addMinute(java.util.Date, int);
    static java.util.Date addSecond(java.util.Date, int);
    static private static java.util.Date add(java.util.Date, int, int);
    static java.util.Date subDate(java.util.Date, long, java.util.concurrent.TimeUnit);
    static java.util.Date addDate(java.util.Date, long, java.util.concurrent.TimeUnit);
    static java.util.Date addDate(java.util.Date, long);
    static java.util.Date opt(java.util.Date, long, java.util.concurrent.TimeUnit);
    static long sub(java.util.Date, java.util.Date, int);
    static int getYear(java.util.Date);
    static int getMonth(java.util.Date);
    static int getDay(java.util.Date);
    static int getWeekDay(java.util.Date);
    static int getWeekOfYear(java.util.Date);
    static java.util.Date getMondayOfWeek(java.util.Date);
    static java.util.Date getSundayOfWeek(java.util.Date);
    static int getRemainDayOfMonth(java.util.Date);
    static int getPassDayOfMonth(java.util.Date);
    static int getDayOfMonth(java.util.Date);
    static java.util.Date getFirstDayInWeek(java.util.Date);
    static java.util.Date getLastDayInWeek(java.util.Date);
    static java.util.Date getFirstDayInMonth(java.util.Date);
    static java.util.Date getLastDayInMonth(java.util.Date);
    static java.util.Date getFirstDayInSeason(java.util.Date);
    static java.util.Date getLastDayInSeason(java.util.Date);
    static java.util.Date getFirstDayInYear(java.util.Date);
    static java.util.Date getLastDayInYear(java.util.Date);
    static int getDayOfSeason(java.util.Date);
    static int getRemainDayOfSeason(java.util.Date);
    static int getPassDayOfSeason(java.util.Date);
    static java.util.Date[] getQuarterDate(java.util.Date);
    static int getQuarter(java.util.Date);
    static java.util.List<java.lang.String> collectLocalDates(java.util.Date, java.util.Date);
    static java.util.List<java.lang.String> collectLocalDates(java.lang.String, java.lang.String);
    static java.util.List<java.lang.String> collectLocalDates(java.time.LocalDate, java.time.LocalDate);
    static boolean isDate(java.util.Date);
    static java.util.Date parse(java.lang.String, java.lang.String, java.util.TimeZone);
    static java.util.Date secondsToDate(java.lang.Integer);
    static java.util.Date millisecondToDate(java.lang.Long);
    static java.lang.Integer dateToSeconds(java.util.Date);
```

### `DatabaseUtils`（47 方法）

`com.seeyon.boot.util.DatabaseUtils`

```java
    static java.lang.String mysqlToDm(java.lang.String);
    static java.lang.String mysql2Oracle(java.lang.String);
    static java.lang.String mysql2Postgre(java.lang.String);
    static java.lang.String mysql2KingbaseV8(java.lang.String);
    static java.lang.String mysql2Sqlserver(java.lang.String);
    static private static java.lang.String initSql(java.lang.String);
    static private static java.lang.String dmAndKingAlter(java.lang.String);
    static private static java.lang.String varcharTooLargeForDm(java.lang.String);
    static private static java.lang.String varcharConvertDM(java.lang.String);
    static private static java.lang.String varcharConvert(java.lang.String);
    static private static java.lang.String nvarcharConvertDM(java.lang.String);
    static private static java.lang.String nvarcharConvert(java.lang.String);
    static private static java.lang.String varchar2TooLargeForOracle(java.lang.String);
    static private static java.lang.String timestampDefaultValue(java.lang.String);
    static private static java.lang.String dropIndexOracle(java.lang.String);
    static private static java.lang.String dropIndexSqlserver(java.lang.String);
    static private static java.lang.String convertIndex(java.lang.String);
    static private static java.lang.String oracleAddColumn(java.lang.String);
    static private static java.lang.String notNullDefaultValue(java.lang.String);
    static private static java.lang.String nullDefaultValue(java.lang.String);
    static private static java.lang.String dropRenameTable(java.lang.String);
    static private static java.lang.String notNullDrop(java.lang.String);
    static private static java.lang.String defaultValue(java.lang.String);
    static private static java.lang.String sqlServerAlterId(java.lang.String);
    static private static java.lang.String alterComment(java.lang.String);
    static private static java.lang.String pgAndKingAlterDefaultBoolean(java.lang.String);
    static private static java.lang.String sqlserverAddColumn(java.lang.String);
    static private static java.lang.String varcharTooLarge(java.lang.String);
    static private static java.lang.String nvarcharTooLarge(java.lang.String);
    static private static java.lang.String bit2Binary(java.lang.String);
    static private static java.lang.String bit2Raw(java.lang.String);
    static private static java.lang.String blankFormat(java.lang.String);
    static private static java.lang.String convertAlterChane(java.lang.String, java.lang.String);
    static private static java.lang.String convertAlterModify(java.lang.String, java.lang.String);
    static private static java.lang.String convertAlterModifyItem(java.lang.String, java.lang.String);
    static private static java.lang.String getColumnNameForModify(com.alibaba.druid.sql.ast.statement.SQLAlterTableStatement);
    static private static java.lang.String getConstraintsForModify(com.alibaba.druid.sql.ast.statement.SQLAlterTableStatement);
    static private static java.lang.String getDefaultForModify(com.alibaba.druid.sql.ast.statement.SQLAlterTableStatement);
    static private static java.lang.String getNewColumnNameForModify(com.alibaba.druid.sql.ast.statement.SQLAlterTableStatement);
    static private static java.lang.String getAlterDataTypeForModify(com.alibaba.druid.sql.ast.statement.SQLAlterTableStatement);
    static private static java.lang.String convertAlterChaneItem(java.lang.String, java.lang.String);
    static private static java.lang.String getColumnName(com.alibaba.druid.sql.ast.statement.SQLAlterTableStatement);
    static private static java.lang.String getNewColumnName(com.alibaba.druid.sql.ast.statement.SQLAlterTableStatement);
    static private static java.lang.String getDefaultForChane(com.alibaba.druid.sql.ast.statement.SQLAlterTableStatement);
    static private static java.lang.String getAlterDataType(com.alibaba.druid.sql.ast.statement.SQLAlterTableStatement);
    static private static void splitSqlScript(java.lang.String, java.util.List<java.lang.String>);
    static private static boolean startsWithAny(java.lang.String, java.lang.String[], int);
```

### `ToStringUtils`（44 方法）

`com.seeyon.boot.util.ToStringUtils`

```java
    static java.lang.String toString(java.lang.Object);
    static java.lang.String getPackageName(java.lang.Class<?>);
    static java.lang.String toString(java.util.Collection, int);
    static java.lang.String toString(java.util.Map, int, java.util.List<java.lang.String>);
    static java.lang.String toString(java.lang.String, int);
    static java.lang.String toString(long[], int);
    static java.lang.String toString(int[], int);
    static java.lang.String toString(short[], int);
    static java.lang.String toString(char[], int);
    static java.lang.String toString(byte[], int);
    static java.lang.String toString(boolean[], int);
    static java.lang.String toString(float[], int);
    static java.lang.String toString(double[], int);
    static java.lang.String toString(java.lang.Object[], int);
    static java.lang.String toString(byte);
    static java.lang.String toString(byte[]);
    static java.lang.String toString(short);
    static java.lang.String toString(short[]);
    static java.lang.String toString(int);
    static java.lang.String toString(int[]);
    static java.lang.String toString(long);
    static java.lang.String toString(long[]);
    static java.lang.String toString(char);
    static java.lang.String toString(char[]);
    static java.lang.String toString(float);
    static java.lang.String toString(float[]);
    static java.lang.String toString(double);
    static java.lang.String toString(double[]);
    static java.lang.String toString(boolean);
    static java.lang.String toString(boolean[]);
    static java.lang.String toString(java.lang.String);
    static java.lang.String toString(java.lang.String[]);
    static java.lang.String toString(java.util.Collection);
    static java.lang.String toString(java.util.Map);
    static java.lang.String toString(java.lang.Object[]);
    static java.lang.String mask(java.lang.String, int, int);
    static java.lang.String mask(java.lang.String);
    static java.lang.String maskAll(java.lang.String);
    static <E> java.util.List<E> newList(E...);
    static java.lang.String parseDate(java.util.Date);
    static private static char[] repeatAsterisk(int);
    static void clearDynamicCache(int);
```

### `SeeyonBeanFactory`（43 方法）

`com.seeyon.boot.spring.SeeyonBeanFactory`

```java
    static private static void initLazyInitBeanPatterns();
    static private static void initAsyncInitBeans();
    static private static java.util.List<java.util.Set<java.lang.String>> splitBeanNames(java.lang.String[], int);
    java.lang.Object getBean(java.lang.String);
    <T> T getBean(java.lang.Class<T>)
    java.lang.Object getSelfBean(java.lang.String);
    void callInitMethod(java.lang.String);
    java.lang.Object applyBeanPostProcessorsBeforeInitialization1(java.lang.Object, java.lang.String)
    protected java.lang.String determinePrimaryCandidate(java.util.Map<java.lang.String, java.lang.Object>, java.lang.Class<?>);
    private boolean hasPrimary(java.lang.String, java.lang.Object);
    java.lang.Object applyBeanPostProcessorsAfterInitialization(java.lang.Object, java.lang.String)
    void cacheBean(java.lang.String, java.lang.Object);
    void wrapBean(com.seeyon.boot.loader.ModuleClassLoader, java.lang.String);
    private java.lang.Object getDependencyModuleBean(com.seeyon.boot.loader.ModuleClassLoader, java.lang.String);
    void initializeBean(java.lang.String);
    void removeBean(java.lang.String);
    void clearAllCache(java.lang.String, com.seeyon.boot.loader.ModuleClassLoader);
    private void clearParameterNamesCache(com.seeyon.boot.loader.ModuleClassLoader);
    private void clearFilteredPropertyDescriptorsCache(com.seeyon.boot.loader.ModuleClassLoader);
    private void initParameterNamesCacheIfNecessary();
    private void clearAllMethodClassKeyCache(com.seeyon.boot.loader.ModuleClassLoader);
    private void clearMethodClassKeyCache(com.seeyon.boot.loader.ModuleClassLoader, java.lang.String, java.lang.Class);
    private void clearModuleClasses(java.lang.ClassLoader, java.lang.Object, java.lang.Class, java.lang.String, boolean);
    void setBeanClassLoader(java.lang.ClassLoader);
    protected boolean isTypeMatch(java.lang.String, org.springframework.core.ResolvableType, boolean)
    protected java.lang.String determineAutowireCandidate(java.util.Map<java.lang.String, java.lang.Object>, org.springframework.beans.factory.config.DependencyDescriptor);
    protected void invokeInitMethods(java.lang.String, java.lang.Object, org.springframework.beans.factory.support.RootBeanDefinition)
    protected org.springframework.beans.BeanWrapper createBeanInstance(java.lang.String, org.springframework.beans.factory.support.RootBeanDefinition, java.lang.Object[]);
    void registerBeanDefinition(java.lang.String, org.springframework.beans.factory.config.BeanDefinition);
    private boolean needCacheType(java.lang.Class, org.springframework.beans.factory.config.BeanDefinition);
    private void cacheBeanNamesOfType(java.lang.Class, java.lang.String);
    <T> java.util.Map<java.lang.String, T> getMappersOfType(java.lang.Class<T>)
    private boolean needLazyInit(java.lang.String);
    protected java.lang.Object getSingletonNoSynchronized(java.lang.String, boolean);
    java.util.Set<java.lang.String> getAsyncLazyInitBeanNames();
    <T> T getBean(java.lang.String, java.lang.Class<T>)
    void clearModuleAppCache(java.lang.ClassLoader);
    private void initModuleBeanRepositoryIfNecessary();
```

### `HttpConfig`（43 方法）

`com.seeyon.boot.util.http.common.HttpConfig`

```java
    static com.seeyon.boot.util.http.common.HttpConfig custom();
    com.seeyon.boot.util.http.common.HttpConfig client(org.apache.http.client.HttpClient);
    com.seeyon.boot.util.http.common.HttpConfig url(java.lang.String);
    com.seeyon.boot.util.http.common.HttpConfig httpVersion(com.seeyon.boot.util.http.enums.HttpVersionEnum);
    com.seeyon.boot.util.http.enums.HttpVersionEnum httpVersion();
    com.seeyon.boot.util.http.common.HttpConfig appendParams(java.util.Map<java.lang.String, java.lang.Object>);
    private java.lang.String encode(java.lang.String);
    com.seeyon.boot.util.http.common.HttpConfig headers(org.apache.http.Header[]);
    com.seeyon.boot.util.http.common.HttpConfig headers(java.util.List<org.apache.http.Header>);
    com.seeyon.boot.util.http.common.HttpConfig headers(java.util.Map<java.lang.String, java.lang.String>);
    com.seeyon.boot.util.http.common.HttpConfig addHeader(java.lang.String, java.lang.String);
    com.seeyon.boot.util.http.common.HttpConfig method(com.seeyon.boot.util.http.common.HttpMethods);
    com.seeyon.boot.util.http.common.HttpConfig map(java.util.Map);
    com.seeyon.boot.util.http.common.HttpConfig json(java.lang.String);
    com.seeyon.boot.util.http.common.HttpConfig xml(java.lang.String);
    com.seeyon.boot.util.http.common.HttpConfig files(com.seeyon.boot.util.http.model.FileUploadModel[]);
    com.seeyon.boot.util.http.common.HttpConfig files(com.seeyon.boot.util.http.model.FileUploadModel[], boolean);
    com.seeyon.boot.util.http.common.HttpConfig streams(com.seeyon.boot.util.http.model.FileStreamUploadModel[]);
    com.seeyon.boot.util.http.common.HttpConfig stream(java.io.InputStream, java.lang.String);
    com.seeyon.boot.util.http.common.HttpConfig streams(com.seeyon.boot.util.http.model.FileStreamUploadModel[], boolean);
    com.seeyon.boot.util.http.common.HttpConfig putStream(java.io.InputStream);
    java.io.InputStream getPutStream();
    com.seeyon.boot.util.http.common.HttpConfig encoding(java.lang.String);
    com.seeyon.boot.util.http.common.HttpConfig inenc(java.lang.String);
    com.seeyon.boot.util.http.common.HttpConfig outenc(java.lang.String);
    com.seeyon.boot.util.http.common.HttpConfig out(java.io.OutputStream);
    com.seeyon.boot.util.http.common.HttpConfig timeout(int);
    com.seeyon.boot.util.http.common.HttpConfig timeout(int, boolean);
    org.apache.http.client.HttpClient client();
    org.apache.http.Header[] headers();
    java.lang.String url();
    com.seeyon.boot.util.http.common.HttpMethods method();
    java.lang.String methodName();
    org.apache.http.protocol.HttpContext context();
    java.util.Map<java.lang.String, java.lang.Object> map();
    java.lang.String json();
    java.lang.String xml();
    java.lang.String encoding();
    java.lang.String inenc();
    java.lang.String outenc();
    java.io.OutputStream out();
    org.apache.http.client.config.RequestConfig requestConfig();
    com.seeyon.boot.util.http.common.HttpConfig ignoreCookie();
```

### `AbstractPrimitiveUtils`（38 方法）

`com.seeyon.boot.util.bean.AbstractPrimitiveUtils`

```java
    static short value(java.lang.Short);
    static int value(java.lang.Integer);
    static long value(java.lang.Long);
    static float value(java.lang.Float);
    static double value(java.lang.Double);
    static byte value(java.lang.Byte);
    static boolean value(java.lang.Boolean);
    static char value(java.lang.Character);
    static java.lang.Short value(short);
    static java.lang.Integer value(int);
    static java.lang.Long value(long);
    static java.lang.Float value(float);
    static java.lang.Double value(double);
    static java.lang.Byte value(byte);
    static java.lang.Boolean value(boolean);
    static java.lang.Character value(char);
    static int[] values(java.lang.Integer[]);
    static long[] values(java.lang.Long[]);
    static short[] values(java.lang.Short[]);
    static float[] values(java.lang.Float[]);
    static double[] values(java.lang.Double[]);
    static boolean[] values(java.lang.Boolean[]);
    static byte[] values(java.lang.Byte[]);
    static char[] values(java.lang.Character[]);
    static java.lang.Integer[] values(int[]);
    static java.lang.Long[] values(long[]);
    static java.lang.Short[] values(short[]);
    static java.lang.Float[] values(float[]);
    static java.lang.Double[] values(double[]);
    static java.lang.Boolean[] values(boolean[]);
    static java.lang.Byte[] values(byte[]);
    static java.lang.Character[] values(char[]);
    static java.lang.Class<?> getPrimitiveClass(java.lang.String);
    static java.lang.Class<?> getWrapperClass(java.lang.String);
    static java.lang.Class<?>[] getAllPrimitiveClasses();
    static java.lang.Class<?>[] getAllPrimitiveArrayClasses();
    static java.lang.Class<?>[] getAllWrapperClasses();
    static java.lang.Class<?>[] getAllWrapperArrayClasses();
```

### `LogbackConfigurator`（35 方法）

`com.seeyon.boot.log.LogbackConfigurator`

```java
    void conversionRule(java.lang.String, java.lang.Class<? extends ch.qos.logback.core.pattern.Converter>);
    void appender(java.lang.String, ch.qos.logback.core.Appender<?>);
    void logger(java.lang.String, ch.qos.logback.classic.Level);
    void logger(java.lang.String, ch.qos.logback.classic.Level, boolean);
    void logger(java.lang.String, ch.qos.logback.classic.Level, boolean, ch.qos.logback.core.Appender<ch.qos.logback.classic.spi.ILoggingEvent>);
    void root(ch.qos.logback.classic.Level, ch.qos.logback.core.Appender<ch.qos.logback.classic.spi.ILoggingEvent>...);
    void start(ch.qos.logback.core.spi.LifeCycle);
    ch.qos.logback.classic.Logger getRootLogger();
    ch.qos.logback.core.Appender<ch.qos.logback.classic.spi.ILoggingEvent> asyncFileAppender(java.lang.String, java.lang.String, java.lang.String, int);
    ch.qos.logback.core.rolling.RollingFileAppender<ch.qos.logback.classic.spi.ILoggingEvent> fileAppender(java.lang.String, java.lang.String, java.lang.String);
    ch.qos.logback.core.rolling.RollingFileAppender<ch.qos.logback.classic.spi.ILoggingEvent> fileAppender(java.lang.String, java.lang.String, java.lang.String, int);
    ch.qos.logback.core.Appender<ch.qos.logback.classic.spi.ILoggingEvent> asyncFileAppender(java.lang.String, java.lang.String, java.lang.String);
    private void base();
    private void setContextNameIfPossible(ch.qos.logback.classic.LoggerContext);
    private ch.qos.logback.classic.jul.LevelChangePropagator createLevelChangePropagator();
    java.lang.String getPattern();
    java.lang.String getAnsiPattern();
    void log(java.lang.String, java.lang.String...);
    java.util.List<java.lang.String> getLogs();
    static java.lang.String pattern();
    static java.lang.String pattern(boolean);
    static com.seeyon.boot.log.LogbackProperties getLogbackProperties();
    static void setLogLevel(java.lang.String);
    static java.lang.String getLogLevel();
    java.lang.Boolean consoleEnable();
    static java.lang.Boolean traceEnable();
    ch.qos.logback.classic.LoggerContext getContext();
    java.lang.ClassLoader getClassLoader();
    org.springframework.core.env.Environment getEnvironment();
    void setContext(ch.qos.logback.classic.LoggerContext);
    void setClassLoader(java.lang.ClassLoader);
    void setEnvironment(org.springframework.core.env.Environment);
    void setPattern(java.lang.String);
    void setLogs(java.util.List<java.lang.String>);
```

### `StringUtils`（35 方法）

`com.seeyon.boot.util.StringUtils`

```java
    static java.lang.String first(java.lang.String);
    static java.lang.String getSimpleNameFromFullName(java.lang.String);
    static java.lang.String toPinYinFirstSpell(java.lang.String);
    static java.lang.String toPinyin(java.lang.String);
    static java.lang.String toPinyinFistWord(java.lang.String);
    static java.lang.String toPinyinFistLetter(java.lang.String);
    static java.lang.String bigVersion(java.lang.String);
    static int compareVersion(java.lang.String, java.lang.String);
    static java.lang.String getMajorVersion(java.lang.String);
    static java.lang.String camelToUnderline(java.lang.String);
    static <T> T isBlankDefault(T, T);
    static boolean matcher(java.lang.String, java.lang.String);
    static java.lang.String mask(java.lang.String, int, int);
    static java.lang.String mask(java.lang.String, int, int, java.lang.Character);
    static java.lang.String maskUserName(java.lang.String);
    static java.lang.String maskBankCardNo(java.lang.String);
    static java.lang.String maskIdCardNo(java.lang.String);
    static java.lang.String maskMobileNo(java.lang.String);
    static java.lang.String maskEmail(java.lang.String);
    static java.lang.String maskAuto(java.lang.String);
    static private static boolean isEmail(java.lang.String);
    static private static boolean isMobile(java.lang.String);
    static private static boolean isCertNo(java.lang.String);
    static private static boolean isBankCard(java.lang.String);
    static java.lang.String maskByType(java.lang.String, com.seeyon.boot.annotation.Maskable);
    static java.lang.String maskReverse(java.lang.String, int, int);
    static java.lang.String maskReverse(java.lang.String, int, int, java.lang.Character);
    static java.lang.String maskReverse(java.lang.String, int, int, java.lang.Character, int);
    static boolean isNumber(java.lang.CharSequence);
    static boolean equals(java.lang.String, java.lang.String);
    static java.lang.String escapeJson(java.lang.String);
    static java.lang.String unescapeJson(java.lang.String);
    static java.lang.String formatFileSize(long, boolean);
    static java.lang.String getInjectBeanName(java.lang.String, boolean);
    static java.lang.String decode(java.lang.String, java.lang.String)
```

### `IoUtils`（28 方法）

`com.seeyon.boot.util.IoUtils`

```java
    static java.lang.String toString(byte[], java.lang.String);
    static java.lang.String toString(byte[]);
    static java.lang.String toString(java.io.InputStream)
    static java.lang.String toString(java.io.InputStream, java.nio.charset.Charset)
    static java.lang.String toString(java.io.InputStream, java.lang.String)
    static java.lang.String toString(java.io.Reader)
    static java.lang.String toString(java.net.URI, java.nio.charset.Charset)
    static java.lang.String toString(java.net.URI, java.lang.String)
    static java.lang.String toString(java.net.URL, java.nio.charset.Charset)
    static java.util.List<java.lang.String> readLines(java.io.InputStream)
    static java.util.List<java.lang.String> readLines(org.springframework.core.io.Resource)
    static int copy(java.io.InputStream, java.io.OutputStream)
    static java.lang.String toString(java.net.URL, java.lang.String)
    static java.io.InputStream toInputStream(java.lang.CharSequence, java.nio.charset.Charset);
    static java.io.InputStream toInputStream(java.lang.CharSequence, java.lang.String);
    static java.io.InputStream toInputStream(java.lang.String, java.nio.charset.Charset);
    static java.io.InputStream toInputStream(java.lang.String, java.lang.String);
    static java.io.InputStream toInputStream(java.lang.String);
    static void closeQuietly(java.io.Closeable);
    static void closeQuietly(java.io.Closeable...);
    static void closeQuietly(java.io.Closeable, java.util.function.Consumer<java.io.IOException>);
    static void closeQuietly(java.io.InputStream);
    static void closeQuietly(java.io.OutputStream);
    static void closeQuietly(java.io.Reader);
    static void closeQuietly(java.nio.channels.Selector);
    static void closeQuietly(java.net.ServerSocket);
    static void closeQuietly(java.net.Socket);
    static void closeQuietly(java.io.Writer);
```

### `JsonUtils`（28 方法）

`com.seeyon.boot.util.JsonUtils`

```java
    static void main(java.lang.String[]);
    static java.lang.String toJsonThrowError(java.lang.Object)
    static java.lang.String toJson(java.lang.Object);
    static java.lang.String toJsonEnumToCode(java.lang.Object);
    static java.lang.String toJson(java.lang.Object, boolean);
    static java.lang.String toJsonLongToString(java.lang.Object);
    static java.lang.String toJsonDecimalToString(java.lang.Object);
    static java.lang.String toJsonNotIncludeNull(java.lang.Object);
    static <T> T fromJson(java.lang.String, java.lang.Class<T>);
    static <T> T fromJsonThrowError(java.lang.String, java.lang.Class<T>)
    static <T> T fromJsonThrowError(java.lang.String, java.lang.Class<T>, java.lang.Class)
    static <T> T fromJson(java.lang.String, java.lang.Class<T>, java.lang.Class);
    static <T> T fromJson(java.lang.String, java.lang.Class<T>, java.lang.Class, java.lang.Class);
    static java.util.Map<java.lang.String, java.lang.String> toStringMapThrowError(java.lang.String)
    static java.util.Map<java.lang.String, java.lang.String> toStringMap(java.lang.String);
    static <K, V> java.util.Map<K, V> toMapThrowError(java.lang.String, java.lang.Class<K>, java.lang.Class<V>)
    static <K, V> java.util.Map<K, V> toMap(java.lang.String, java.lang.Class<K>, java.lang.Class<V>);
    static java.util.Map<java.lang.String, java.lang.Object> toMapThrowError(java.lang.String)
    static java.util.Map<java.lang.String, java.lang.Object> toMap(java.lang.String);
    static java.util.List<java.lang.String> toStringList(java.lang.String);
    static java.util.List toListThrowError(java.lang.String)
    static java.util.List toList(java.lang.String);
    static <T> java.util.List<T> toListThrowError(java.lang.String, java.lang.Class<T>)
    static <T> java.util.List<T> toList(java.lang.String, java.lang.Class<T>);
    static private static <T> T readValue(java.lang.String, com.fasterxml.jackson.databind.JavaType)
    static private static <T> T readValue(java.lang.String, java.lang.Class<T>)
    static void clearCache(int);
```

### `FileUtils`（21 方法）

`com.seeyon.boot.util.FileUtils`

```java
    static java.io.File tempFile(java.lang.String, java.lang.String...);
    static java.io.File tempFile(java.lang.String);
    static java.io.File tempFile();
    static java.io.File tempDir(java.lang.String...);
    static java.io.File tempDir();
    static java.io.InputStream openInputStream(java.io.File)
    static java.io.File writeStringToFile(java.lang.String, java.lang.String, java.lang.String)
    static java.io.File writeStringToFile(java.lang.String)
    static java.io.File copyInputStreamToFile(java.io.InputStream)
    static java.io.File copyInputStreamToFile(java.io.InputStream, java.io.File)
    static java.io.File copyURLToFile(java.net.URL)
    static java.util.List<java.lang.String> readLines(java.io.File, java.lang.String)
    static java.lang.String readFileToString(java.io.File, java.lang.String)
    static java.lang.String readFileToString(java.io.File)
    static java.util.List<java.lang.String> readLines(java.io.File)
    static void delete(java.io.File)
    static void forceDelete(java.io.File)
    static void forceDeleteOnExit(java.io.File)
    static void deleteDirectory(java.io.File)
    static void deleteQuietly(java.io.File);
    static java.lang.String getFileType(java.io.InputStream);
```

### `IpUtils`（21 方法）

`com.seeyon.boot.util.IpUtils`

```java
    static long ip2Long(java.lang.String);
    static java.lang.String long2Ip(long);
    static boolean isPublicIpv4(java.lang.String);
    static boolean isPublicIpv4(long);
    static boolean isIp(java.lang.String);
    static java.util.Collection<java.net.InetAddress> getAllHostAddress();
    static java.util.Collection<java.net.InetAddress> getAllHostIpV4Address();
    static java.util.Collection<java.net.InetAddress> getAllHostIpV6Address();
    static java.util.Collection<java.lang.String> getAllNoLoopbackAddresses();
    static java.util.Collection<java.lang.String> getAllNoLoopbackIpV4Addresses();
    static java.util.Collection<java.lang.String> getAllNoLoopbackIpV6Addresses();
    static java.lang.String getFirstNoLoopbackAddress();
    static java.lang.String getFirstNoLoopbackIPV4Address();
    static java.lang.String getFirstNoLoopbackIPV6Address();
    static java.lang.String getComputerName();
    static java.lang.String getMacAddress()
    static java.lang.String getMacAddress(java.net.InetAddress);
    static private static java.lang.String formatMac(byte[]);
    static private static java.lang.String getMacByNetworkInterface();
    static private static java.lang.String getMacByProcess();
    static java.lang.String getFirstLineOfCommand(java.lang.String...)
```

### `ExcelUtils`（19 方法）

`com.seeyon.boot.util.excel.ExcelUtils`

```java
    static <T> java.util.List<T> readExcel(java.io.InputStream, java.lang.Class<T>, int);
    static int readSheetCount(java.io.InputStream);
    static java.util.List<java.util.LinkedHashMap<java.lang.Integer, java.lang.Object>> readExcel(java.io.InputStream, int, int);
    static void readExcel(java.io.InputStream, com.seeyon.boot.util.excel.ExcelDataHandler, int, int);
    static java.util.List<java.util.LinkedHashMap<java.lang.Integer, java.lang.Object>> readExcel(java.io.InputStream, java.lang.String, int);
    static <T> java.util.List<T> readExcel(java.io.InputStream, java.lang.Class<T>);
    static java.io.File writeExcel(com.seeyon.boot.util.excel.enums.ExcelEnum, com.seeyon.boot.util.excel.model.SheetModel...);
    static byte[] writeExcelByteArray(com.seeyon.boot.util.excel.enums.ExcelEnum, com.seeyon.boot.util.excel.model.SheetModel...);
    static java.io.InputStream writeExcelSteam(com.seeyon.boot.util.excel.enums.ExcelEnum, com.seeyon.boot.util.excel.model.SheetModel...);
    static private static int setHead(java.lang.Class, com.alibaba.excel.read.builder.ExcelReaderSheetBuilder, com.alibaba.excel.write.builder.ExcelWriterSheetBuilder);
    static private static com.seeyon.boot.util.excel.model.style.CellStyle buildCellStyle(java.lang.annotation.Annotation);
    static private static com.seeyon.boot.util.excel.model.style.FontStyle buildFontStyle(java.lang.annotation.Annotation);
    static private static com.alibaba.excel.metadata.property.StyleProperty getStyleProperty(com.seeyon.boot.util.excel.model.style.CellStyle, com.alibaba.excel.metadata.property.StyleProperty);
    static private static com.alibaba.excel.metadata.property.FontProperty getFontProperty(com.seeyon.boot.util.excel.model.style.FontStyle, com.alibaba.excel.metadata.property.FontProperty);
    static private static com.alibaba.excel.metadata.property.StyleProperty getStyleProperty(java.lang.annotation.Annotation, com.alibaba.excel.metadata.property.StyleProperty);
    static private static com.alibaba.excel.metadata.property.FontProperty getFontProperty(java.lang.annotation.Annotation, com.alibaba.excel.metadata.property.FontProperty);
    static private static com.alibaba.excel.write.builder.ExcelWriterSheetBuilder buildHandlers(com.seeyon.boot.util.excel.model.SheetModel, com.alibaba.excel.write.builder.ExcelWriterSheetBuilder, java.util.List<java.lang.Integer>);
    static private static com.alibaba.excel.write.builder.ExcelWriterSheetBuilder buildHandlers(java.lang.Class, com.alibaba.excel.write.builder.ExcelWriterSheetBuilder, java.util.List<com.seeyon.boot.util.excel.model.style.DataValidity>);
    static private static java.lang.String cleanSheetName(java.lang.String);
```

### `SeeyonSpanBuilder`（17 方法）

`com.seeyon.boot.trace.SeeyonSpanBuilder`

```java
    io.opentracing.Tracer$SpanBuilder asChildOf(io.opentracing.SpanContext);
    io.opentracing.Tracer$SpanBuilder asChildOf(io.opentracing.Span);
    io.opentracing.Tracer$SpanBuilder addReference(java.lang.String, io.opentracing.SpanContext);
    io.opentracing.Tracer$SpanBuilder withTag(java.lang.String, java.lang.String);
    io.opentracing.Tracer$SpanBuilder withTag(java.lang.String, boolean);
    io.opentracing.Tracer$SpanBuilder withTag(java.lang.String, java.lang.Number);
    <T> io.opentracing.Tracer$SpanBuilder withTag(io.opentracing.tag.Tag<T>, T);
    io.opentracing.Tracer$SpanBuilder withStartTimestamp(long);
    io.opentracing.Span start();
    java.util.List<com.seeyon.boot.trace.SeeyonTag> getTags();
    java.lang.String getOperationName();
    boolean isEntry();
    boolean isExit();
    int getPort();
    java.lang.String getPeer();
    boolean isError();
    io.opentracing.Tracer$SpanBuilder ignoreActiveSpan();
```

### `ZipUtils`（17 方法）

`com.seeyon.boot.util.ZipUtils`

```java
    static java.io.File zip(java.io.File...);
    static java.io.File zip(boolean, java.io.File...);
    static java.io.File zip(boolean, java.lang.String, java.io.File...);
    static java.io.File zip(java.lang.String, boolean, java.lang.String, java.io.File...);
    static private static void validateFiles(java.io.File, java.io.File...)
    static java.io.File unZip(java.io.File);
    static java.io.File unZip(java.io.File, java.lang.String);
    static java.io.File unZip(java.io.File, java.lang.String, java.lang.String);
    static java.io.File unZipToDir(java.io.File, java.lang.String, java.lang.String);
    static java.io.File unZipToDir(java.io.InputStream, java.lang.String, java.lang.String);
    static java.io.File unZip(java.io.InputStream, java.lang.String, java.lang.String);
    static java.io.File unZip(java.io.InputStream, java.lang.String);
    static java.io.File unZip(java.io.InputStream);
    static java.io.File zip(java.io.InputStream, java.lang.String);
    static java.io.File zip(java.io.InputStream, java.lang.String, java.lang.String);
    static java.io.File zip(java.io.InputStream, java.lang.String, java.lang.String, java.lang.String);
    static byte[] getZipInnerFile(java.io.File, java.lang.String, java.lang.String);
```

### `SyMonitorRecordUtil`（16 方法）

`com.seeyon.boot.monitor.util.SyMonitorRecordUtil`

```java
    static void recordLog(com.seeyon.boot.monitor.dto.SyRecordDto);
    static private static void startBatchProcessor();
    static private static void flushBatch(java.util.List<com.seeyon.boot.monitor.dto.SyRecordDto>);
    static java.lang.String generateSqlTemplate(java.lang.String, java.lang.String);
    static java.lang.String generateSimpleSql(java.lang.String);
    static boolean containsIgnoreCase(java.lang.String, java.lang.String);
    static java.util.List<java.lang.String> extractTablesFromSql(java.lang.String, java.lang.String);
    static java.lang.String safeGetParams(java.lang.Object[]);
    static private static void appendSafeObject(java.lang.StringBuilder, java.lang.Object, int);
    static private static boolean isDangerousType(java.lang.Class<?>);
    static java.util.List<java.lang.String> getSimplifiedStacktraceList(java.lang.Throwable);
    static com.seeyon.boot.conifg.RecordProperties getRecordProperties();
    static void shutdown();
```

### `PomXmlUtil`（14 方法）

`com.seeyon.boot.util.PomXmlUtil`

```java
    java.lang.String getGroupId();
    java.lang.String getVersion();
    java.lang.String getArtifactId();
    java.lang.String getPomValue(java.lang.String);
    java.lang.String getPomXmlPath();
    org.apache.maven.model.Model getModel();
    org.codehaus.plexus.interpolation.StringSearchInterpolator getInterpolator();
    void setPomXmlPath(java.lang.String);
    void setModel(org.apache.maven.model.Model);
    void setInterpolator(org.codehaus.plexus.interpolation.StringSearchInterpolator);
    boolean equals(java.lang.Object);
    protected boolean canEqual(java.lang.Object);
    int hashCode();
    java.lang.String toString();
```

### `SimpleTypeConverterManager`（14 方法）

`com.seeyon.boot.util.bean.SimpleTypeConverterManager`

```java
    static void registerDefaultConverter(com.seeyon.boot.util.bean.TypeConverterManager);
    <T> java.util.Collection<com.seeyon.boot.util.bean.TypeConverter<T>> unregister(java.lang.Class<T>);
    <S, T> com.seeyon.boot.util.bean.TypeConverter<T> unregister(java.lang.Class<S>, java.lang.Class<T>);
    <S, T> void register(java.lang.Class<? extends S>, java.lang.Class<T>, com.seeyon.boot.util.bean.TypeConverter<? extends T>);
    void register(com.seeyon.boot.util.bean.TypeConverter<?>);
    private void doRegister(java.lang.Class<?>, java.lang.Class<?>, com.seeyon.boot.util.bean.TypeConverter<?>);
    <T> java.util.Collection<com.seeyon.boot.util.bean.TypeConverter<T>> getTypeConverter(java.lang.Class<T>);
    <S, T> com.seeyon.boot.util.bean.TypeConverter<T> getTypeConverter(java.lang.Class<S>, java.lang.Class<T>);
    private <T> com.seeyon.boot.util.bean.SimpleTypeConverterManager$SourceTypeConverterMap getSourceTypeConverterMap(java.lang.Class<T>);
    boolean containsType(java.lang.Class<?>);
    boolean containsType(java.lang.Class<?>, java.lang.Class<?>);
    boolean containsConverter(java.lang.Class<com.seeyon.boot.util.bean.TypeConverter<?>>);
    boolean canConvert(java.lang.Class<?>, java.lang.Class<?>);
    <T> T convert(java.lang.Object, java.lang.Class<T>);
```

### `HttpClientRoundRobinRouting`（14 方法）

`com.seeyon.boot.util.http.loadbalance.HttpClientRoundRobinRouting`

```java
    static java.lang.String choose(java.lang.String);
    static java.lang.String get(java.lang.String, java.lang.String);
    static java.lang.String get(java.lang.String, java.lang.String, java.nio.charset.Charset, int);
    static java.lang.String get(java.lang.String, java.lang.String, java.util.Map<java.lang.String, java.lang.Object>);
    static java.lang.String get(java.lang.String, java.lang.String, java.nio.charset.Charset, java.util.Map<java.lang.String, java.lang.Object>, int);
    static java.lang.String get(java.lang.String, java.lang.String, com.seeyon.boot.util.http.common.HttpHeader, java.util.Map<java.lang.String, java.lang.Object>);
    static java.lang.String get(java.lang.String, java.lang.String, java.nio.charset.Charset, com.seeyon.boot.util.http.common.HttpHeader, java.util.Map<java.lang.String, java.lang.Object>, int);
    static java.lang.String post(java.lang.String, java.lang.String, java.util.Map<java.lang.String, java.lang.Object>);
    static java.lang.String post(java.lang.String, java.lang.String, java.util.Map<java.lang.String, java.lang.Object>, int, java.nio.charset.Charset);
    static java.lang.String post(java.lang.String, java.lang.String, java.util.Map<java.lang.String, java.lang.Object>, com.seeyon.boot.util.http.common.HttpHeader);
    static java.lang.String post(java.lang.String, java.lang.String, java.util.Map<java.lang.String, java.lang.Object>, com.seeyon.boot.util.http.common.HttpHeader, int, java.nio.charset.Charset);
    static java.lang.String post(java.lang.String, java.lang.String, java.lang.String);
    static private static com.seeyon.boot.util.http.common.HttpHeader getHttpHeader();
    static private static com.seeyon.boot.util.http.common.HttpHeader getHttpHeader(com.seeyon.boot.util.http.common.HttpHeader);
```

### `EnumArrayUtil`（12 方法）

`com.seeyon.boot.util.EnumArrayUtil`

```java
    static boolean hasArrayEnumField(java.lang.String);
    static java.lang.Class getEnumClass(java.lang.String, java.lang.String);
    static java.lang.Class getEnumClassByEntity(java.lang.String, java.lang.String);
    static void regDyAppArrayEnums(java.lang.String, java.lang.Class);
    static void unRegDyAppArrayEnums(java.lang.String);
    static private static java.lang.String key(java.lang.String, java.lang.String);
    static java.util.Map<java.lang.String, java.lang.Class> findArrayEnum(java.lang.Class);
    static java.util.Map<java.lang.String, java.lang.Class> findArrayEnum(java.util.List<java.lang.Class>);
    static java.util.Map<java.lang.String, java.lang.Class> initEnumFieldCache();
    static java.lang.String parseEnumList2Str(java.util.List<com.seeyon.boot.enums.Messageable>);
    static java.util.List<com.seeyon.boot.enums.Messageable> parseStr2EnumList(java.lang.String, java.lang.String, java.lang.String);
    static private static com.seeyon.boot.enums.Messageable codeOf(int, java.lang.Class);
```

### `ResourceUtils`（12 方法）

`com.seeyon.boot.util.ResourceUtils`

```java
    static java.lang.String getAllClassPathResourceStr(java.lang.String);
    static java.lang.String getAppClassPathResourceStr(java.lang.String, java.lang.String);
    static java.util.List<java.lang.String> getAllClassPathResourceListStr(java.lang.String);
    static java.util.List<java.lang.String> getAppClassPathResourceListStr(java.lang.String, java.lang.String);
    static java.util.List<java.lang.String> readResourceStrList(org.springframework.core.io.Resource[]);
    static java.lang.String readResourceToStr(org.springframework.core.io.Resource);
    static org.springframework.core.io.Resource getAppClassPathResource(java.lang.String, java.lang.String);
    static private static org.springframework.core.io.Resource tempResource();
    static org.springframework.core.io.Resource getAllClassPathResource(java.lang.String);
    static org.springframework.core.io.Resource[] getAppClassPathResources(java.lang.String, java.lang.String);
    static org.springframework.core.io.Resource[] getAllClassPathResources(java.lang.String);
    static private static java.lang.String classPathStr(java.lang.String, boolean);
```

### `YamlUtil`（12 方法）

`com.seeyon.boot.util.YamlUtil`

```java
    static java.util.Map<java.lang.String, java.lang.Object> yamlString2Map(java.lang.String);
    static private static void switchToMap(java.lang.String, java.util.Map<java.lang.String, java.lang.Object>, java.util.Map<java.lang.String, java.lang.Object>, int);
    static java.util.LinkedHashMap yaml2LinkedHashMap(java.lang.String);
    static java.lang.String map2Yaml(java.util.LinkedHashMap);
    static java.lang.String hashMap2Yaml(java.util.Map<java.lang.String, java.lang.Object>);
    static private static java.util.LinkedHashMap<java.lang.String, java.lang.Object> parseToLinkMap(java.util.Map<java.lang.String, java.lang.Object>);
    static private static java.util.Map<java.lang.String, java.lang.Object> getChildMap(java.util.Map<java.lang.String, java.lang.Object>, java.lang.String);
    static java.util.LinkedHashMap changeValue(java.util.LinkedHashMap, java.lang.String, java.lang.Object);
    static private static java.lang.Object getRealValue(java.lang.Object);
```

### `TraceMonitorService`（11 方法）

`com.seeyon.boot.monitor.TraceMonitorService`

```java
    void addRedisPutCount(java.lang.String, java.lang.Object);
    void addRedisGetCount(java.lang.String, java.lang.Object);
    void addThreadCount(java.lang.String);
    com.seeyon.boot.monitor.TraceMonitorService$MonitorData getMonitorData(java.lang.String);
    com.seeyon.boot.monitor.TraceMonitorService$MonitorDataAll getMonitorDataAll();
```

### `EncryptConfigProperties`（10 方法）

`com.seeyon.boot.conifg.EncryptConfigProperties`

```java
    com.seeyon.boot.encrypt.enums.FileEncryptEnum getFileEncrypt();
    com.seeyon.boot.encrypt.enums.EncryptionTypeEnum getEncryptionType();
    java.lang.Boolean getTransferEncrypt();
    void setFileEncrypt(com.seeyon.boot.encrypt.enums.FileEncryptEnum);
    void setEncryptionType(com.seeyon.boot.encrypt.enums.EncryptionTypeEnum);
    void setTransferEncrypt(java.lang.Boolean);
    boolean equals(java.lang.Object);
    protected boolean canEqual(java.lang.Object);
    int hashCode();
    java.lang.String toString();
```

### `ClassUtils`（10 方法）

`com.seeyon.boot.util.ClassUtils`

```java
    static java.lang.Class getGenericClass(java.lang.Class);
    static java.lang.Class getGenericClass(java.lang.Class, int);
    static java.lang.Class getSuperClassGenricType(java.lang.Class);
    static java.lang.Class getSuperClassGenricType(java.lang.Class, int)
    static java.lang.Class<?> getParameterizedType(java.lang.reflect.Type);
    static void getAllDeclaredFields(java.util.List<java.lang.reflect.Field>, java.lang.Class);
    static java.util.List<java.lang.reflect.Field> getAllDeclaredFields(java.lang.Class);
    static java.util.List<java.lang.Class<?>> getSuperClasses(java.lang.Class<?>);
    static boolean containAnnotation(java.lang.Class, java.lang.Class<? extends java.lang.annotation.Annotation>);
    static boolean containFieldWithAnnotation(java.lang.Class, java.lang.Class<? extends java.lang.annotation.Annotation>);
```

### `ImageUtils`（10 方法）

`com.seeyon.boot.util.ImageUtils`

```java
    static void resize(java.lang.String, java.lang.String, int, int);
    static void resize(java.lang.String, java.lang.String, int, int, boolean);
    static java.io.File resize(java.lang.String, int, int, boolean);
    static void resize(java.lang.String, java.lang.String, int, int, float);
    static private static java.lang.String getImageFormatName(java.io.File);
    static void thumbnailGifImage(java.lang.String, java.lang.String, int, int);
    static void resize(java.lang.String, java.lang.String, int, int, float, boolean);
    static private static void copySrc(java.io.File, java.io.File, java.lang.Exception);
    static private static void resize(java.io.File, java.io.File, int, int, float, boolean)
    static java.io.File resize(java.lang.String, int, int, float, boolean);
```

### `RSAUtils`（10 方法）

`com.seeyon.boot.util.encrypt.RSAUtils`

```java
    static java.security.KeyPair generateKey();
    static java.lang.String keyEncrypt(java.security.Key);
    static java.lang.String encrypt(byte[], java.security.PublicKey);
    static java.lang.String encrypt(java.lang.String, java.security.PublicKey);
    static java.lang.String encrypt(java.lang.String, java.lang.String)
    static java.lang.String encrypt(byte[], java.lang.String);
    static byte[] decrypt2Byte(java.lang.String, java.lang.String);
    static java.lang.String decrypt(java.lang.String, java.lang.String);
    static java.lang.String decrypt(java.lang.String, java.security.PrivateKey);
    static byte[] decrypt2Byte(java.lang.String, java.security.PrivateKey);
```

### `SM4Utils`（10 方法）

`com.seeyon.boot.util.encrypt.SM4Utils`

```java
    static java.lang.String encrypt(byte[], byte[]);
    static byte[] encrypt2Byte(byte[], byte[]);
    static private static byte[] encrypt2Byte(byte[], byte[], boolean);
    static byte[] encrypt2ByteNoPadding(byte[], byte[]);
    static java.lang.String encrypt(java.lang.String, java.lang.String);
    static java.lang.String decrypt(byte[], byte[]);
    static byte[] decrypt2Byte(byte[], byte[]);
    static byte[] decrypt2ByteNoPadding(byte[], byte[]);
    static private static byte[] decrypt2Byte(byte[], byte[], boolean);
    static java.lang.String decrypt(java.lang.String, java.lang.String);
```

### `QrCodeUtils`（10 方法）

`com.seeyon.boot.util.qrcode.QrCodeUtils`

```java
    static private static java.awt.image.BufferedImage createImage(java.lang.String, com.seeyon.boot.util.qrcode.model.QrCodeParam)
    static private static com.google.zxing.common.BitMatrix resetWhiteBorder(com.google.zxing.common.BitMatrix);
    static private static void insertLogoImage(java.awt.image.BufferedImage, com.seeyon.boot.util.qrcode.model.QrCodeParam)
    static void encode(java.lang.String, java.lang.String, com.seeyon.boot.util.qrcode.model.QrCodeParam)
    static java.awt.image.BufferedImage encode(java.lang.String, com.seeyon.boot.util.qrcode.model.QrCodeParam)
    static java.lang.String encodeForBase64(java.lang.String, com.seeyon.boot.util.qrcode.model.QrCodeParam)
    static private static void mkdirs(java.lang.String);
    static java.lang.String decode(java.awt.image.BufferedImage)
    static java.lang.String decode(java.io.File)
    static java.lang.String decode(java.lang.String)
```

### `SM2Utils`（9 方法）

`com.seeyon.boot.util.encrypt.SM2Utils`

```java
    static java.security.KeyPair generateKey();
    static java.lang.String getPublicKey(java.security.KeyPair);
    static java.lang.String getPrivateKey(java.security.KeyPair);
    static java.lang.String encrypt(java.lang.String, java.lang.String);
    static java.lang.String encrypt(java.lang.String, org.bouncycastle.jcajce.provider.asymmetric.ec.BCECPublicKey);
    static java.lang.String decrypt(java.lang.String, java.lang.String);
    static java.lang.String decrypt(java.lang.String, org.bouncycastle.jcajce.provider.asymmetric.ec.BCECPrivateKey);
    static private static org.bouncycastle.jcajce.provider.asymmetric.ec.BCECPublicKey getECPublicKeyByPublicKeyHex(java.lang.String);
    static private static org.bouncycastle.jcajce.provider.asymmetric.ec.BCECPrivateKey getBCECPrivateKeyByPrivateKeyHex(java.lang.String);
```

### `LocalCacheBuilder`（8 方法）

`com.seeyon.boot.util.cache.LocalCacheBuilder`

```java
    com.seeyon.boot.util.cache.LocalCacheBuilder<K, V> capacity(long);
    float getLoadFactor();
    com.seeyon.boot.util.cache.LocalCacheBuilder<K, V> loadFactor(float);
    com.seeyon.boot.util.cache.LocalCacheBuilder<K, V> ttlMillis(long);
    com.seeyon.boot.util.cache.LocalCacheBuilder<K, V> eviction(com.seeyon.boot.util.cache.CacheEviction);
    static com.seeyon.boot.util.cache.LocalCacheBuilder defaultBuilder();
    com.seeyon.boot.util.cache.LocalCache<K, V> build();
    static private static long roundUpToPowerOf2(long, long);
```

### `AESUtils`（8 方法）

`com.seeyon.boot.util.encrypt.AESUtils`

```java
    static java.lang.String encrypt(java.lang.String, java.lang.String);
    static java.lang.String encrypt(java.lang.String, java.lang.String, int);
    static java.lang.String encrypt(byte[], java.lang.String);
    static java.lang.String encrypt(byte[], java.lang.String, int);
    static java.lang.String decrypt(java.lang.String, java.lang.String, int);
    static java.lang.String decrypt(java.lang.String, java.lang.String);
    static byte[] decrypt2Byte(java.lang.String, java.lang.String);
    static byte[] decrypt2Byte(java.lang.String, java.lang.String, int);
```

### `JwtUtils`（8 方法）

`com.seeyon.boot.util.jwt.JwtUtils`

```java
    static java.lang.String generateJwt(java.util.Map<java.lang.String, java.lang.String>);
    static java.lang.String generateJwt(java.util.Map<java.lang.String, java.lang.String>, java.lang.Long);
    static java.lang.String generateJwt(java.util.Map<java.lang.String, java.lang.String>, java.lang.Long, java.lang.Long);
    static java.util.Map<java.lang.String, com.auth0.jwt.interfaces.Claim> extractClaims(java.lang.String);
    static java.util.Map<java.lang.String, com.auth0.jwt.interfaces.Claim> extractClaimsWithException(java.lang.String);
    static java.lang.Boolean isExpired(java.lang.String);
    static private static java.lang.String getSecretKey();
    static protected static void loadSecretKey();
```

### `TenantUtils`（8 方法）

`com.seeyon.boot.util.teanant.TenantUtils`

```java
    static private static org.springframework.data.redis.core.RedisTemplate getRedisTemplate();
    static java.lang.Long getTenantIdByName(java.lang.String);
    static com.seeyon.boot.context.model.TenantInfo getTenantInfo();
    static com.seeyon.boot.context.model.TenantInfo getTenantInfo(java.lang.Long);
    static java.util.List<com.seeyon.boot.context.model.TenantInfo> getAllActiveTenant();
    static java.util.Set<java.lang.Long> getAllActiveTenantIds();
    static java.util.Set<java.lang.Long> getAllTenant();
```

### `LogbackMDCPatternConverter`（7 方法）

`com.seeyon.boot.log.trace.LogbackMDCPatternConverter`

```java
    void start();
    java.lang.String convert(ch.qos.logback.classic.spi.ILoggingEvent);
    private java.lang.String convertTenantId(ch.qos.logback.classic.spi.ILoggingEvent);
    private java.lang.String convertAppId(ch.qos.logback.classic.spi.ILoggingEvent);
    java.lang.String convertTID(ch.qos.logback.classic.spi.ILoggingEvent);
    java.lang.String convertSkyWalkingContext(ch.qos.logback.classic.spi.ILoggingEvent);
    java.lang.String convert(java.lang.Object);
```

### `ComponentUrlUtil`（7 方法）

`com.seeyon.boot.util.ComponentUrlUtil`

```java
    static void addUrl(java.lang.String);
    static java.util.Set<java.lang.String> getComponentUrl();
    static boolean isComponentUrl(java.lang.String);
    static boolean isComponentUrl2(java.lang.String);
    static boolean isDynamicUrl(java.lang.String);
    static java.lang.String getRealUri(java.lang.String);
```

### `BeanUtils`（7 方法）

`com.seeyon.boot.util.bean.BeanUtils`

```java
    static java.lang.Object getFieldValue(java.lang.Object, java.lang.String);
    static void setFieldValue(java.lang.Object, java.lang.String, java.lang.Object);
    static private static void generateGetterSetter(java.lang.Class, java.lang.String);
    static private static java.lang.ClassLoader getDefaultClassLoader();
    static private static java.lang.String getterName(java.lang.String);
    static private static java.lang.String setterName(java.lang.String);
    static private static java.lang.String firstCharUpperCase(java.lang.String);
```

### `SQLWildcardUtil`（6 方法）

`com.seeyon.boot.util.SQLWildcardUtil`

```java
    static private static void initEscape();
    static java.lang.String escape(java.lang.String);
    static boolean requireEscape(java.lang.String);
    static java.lang.String setEscapeCharacter();
    static java.lang.String likeLowerCase(java.lang.String);
    static java.lang.String chineseOrderBy(java.lang.String);
```

### `EnumTypeConverter`（6 方法）

`com.seeyon.boot.util.bean.EnumTypeConverter`

```java
    static private static java.lang.Enum<?> enumValue0(java.lang.Class<? extends java.lang.Enum>, java.lang.Object);
    static <E extends java.lang.Enum<E>> E enumValue(java.lang.Class<E>, java.lang.Object);
    java.lang.Class<java.lang.Enum<? extends java.lang.Enum<?>>> getTargetType();
    java.util.List<java.lang.Class<?>> getSupportedSourceTypes();
    java.lang.Enum<? extends java.lang.Enum<?>> convert(java.lang.Object, java.lang.Class<? extends java.lang.Enum<? extends java.lang.Enum<?>>>);
    java.lang.Object convert(java.lang.Object, java.lang.Class);
```

### `StringTypeConverter`（6 方法）

`com.seeyon.boot.util.bean.StringTypeConverter`

```java
    static java.lang.String stringValue(java.lang.Object, boolean);
    static java.lang.String stringValue(java.lang.Object);
    java.lang.Class<java.lang.String> getTargetType();
    java.util.List<java.lang.Class<?>> getSupportedSourceTypes();
    java.lang.String convert(java.lang.Object, java.lang.Class<? extends java.lang.String>);
    java.lang.Object convert(java.lang.Object, java.lang.Class);
```

### `SM3Utils`（6 方法）

`com.seeyon.boot.util.encrypt.SM3Utils`

```java
    static java.lang.String encrypt(java.lang.String);
    static java.lang.String encrypt(byte[]);
    static byte[] encrypt2Byte(byte[]);
    static java.lang.String encrypt(java.lang.String, java.lang.String);
    static java.lang.String encrypt(byte[], java.lang.String);
    static byte[] encrypt2Byte(byte[], java.lang.String);
```

### `SerializeUtils`（6 方法）

`com.seeyon.boot.util.serialize.SerializeUtils`

```java
    static byte[] serialize(java.lang.Object);
    static java.lang.String serializeToStr(java.lang.Object);
    static java.lang.Object deserialize(byte[]);
    static java.lang.Object deserializeStr(java.lang.String);
    static <T> T copy(T);
    static void setClassloader(java.lang.ClassLoader);
```

### `SeeyonSerializerProvider`（5 方法）

`com.seeyon.boot.util.SeeyonSerializerProvider`

```java
    com.fasterxml.jackson.databind.ser.DefaultSerializerProvider copy();
    com.fasterxml.jackson.databind.ser.DefaultSerializerProvider withCaches(com.fasterxml.jackson.databind.cfg.CacheProvider);
    com.seeyon.boot.util.SeeyonSerializerProvider createInstance(com.fasterxml.jackson.databind.SerializationConfig, com.fasterxml.jackson.databind.ser.SerializerFactory);
    void clearCache();
    com.fasterxml.jackson.databind.ser.DefaultSerializerProvider createInstance(com.fasterxml.jackson.databind.SerializationConfig, com.fasterxml.jackson.databind.ser.SerializerFactory);
```

### `AbstractTypeConverterUtils`（5 方法）

`com.seeyon.boot.util.bean.AbstractTypeConverterUtils`

```java
    static <T> T convert(java.lang.Object, java.lang.Class<T>);
    static java.lang.Object convertValue(java.lang.Object, java.lang.Class<?>);
    static private static com.seeyon.boot.util.bean.TypeConverter<java.lang.Object> getArrayTypeConvert(java.lang.Object, java.lang.Class<?>);
    static java.lang.Object convertValue(java.util.Map<? extends java.lang.Object, ? extends java.lang.Object>, java.lang.Object, java.lang.Class<?>);
    static final com.seeyon.boot.util.bean.TypeConverterManager getTypeConverterManager();
```

### `BigDecimalTypeConverter`（5 方法）

`com.seeyon.boot.util.bean.BigDecimalTypeConverter`

```java
    static java.math.BigDecimal bigDecValue(java.lang.Object)
    java.lang.Class<java.math.BigDecimal> getTargetType();
    java.util.List<java.lang.Class<?>> getSupportedSourceTypes();
    java.math.BigDecimal convert(java.lang.Object, java.lang.Class<? extends java.math.BigDecimal>);
    java.lang.Object convert(java.lang.Object, java.lang.Class);
```

### `BigIntegerTypeConverter`（5 方法）

`com.seeyon.boot.util.bean.BigIntegerTypeConverter`

```java
    static java.math.BigInteger bigIntValue(java.lang.Object)
    java.lang.Class<java.math.BigInteger> getTargetType();
    java.util.List<java.lang.Class<?>> getSupportedSourceTypes();
    java.math.BigInteger convert(java.lang.Object, java.lang.Class<? extends java.math.BigInteger>);
    java.lang.Object convert(java.lang.Object, java.lang.Class);
```

### `BooleanPrimitiveTypeConverter`（5 方法）

`com.seeyon.boot.util.bean.BooleanPrimitiveTypeConverter`

```java
    static boolean booleanValue(java.lang.Object);
    java.lang.Class<java.lang.Boolean> getTargetType();
    java.util.List<java.lang.Class<?>> getSupportedSourceTypes();
    java.lang.Boolean convert(java.lang.Object, java.lang.Class<? extends java.lang.Boolean>);
    java.lang.Object convert(java.lang.Object, java.lang.Class);
```

### `BytePrimitiveTypeConverter`（5 方法）

`com.seeyon.boot.util.bean.BytePrimitiveTypeConverter`

```java
    static byte byteValue(java.lang.Object)
    java.lang.Class<java.lang.Byte> getTargetType();
    java.util.List<java.lang.Class<?>> getSupportedSourceTypes();
    java.lang.Byte convert(java.lang.Object, java.lang.Class<? extends java.lang.Byte>);
    java.lang.Object convert(java.lang.Object, java.lang.Class);
```

### `CharTypeConverter`（5 方法）

`com.seeyon.boot.util.bean.CharTypeConverter`

```java
    static char charValue(java.lang.Object)
    java.lang.Class<java.lang.Character> getTargetType();
    java.util.List<java.lang.Class<?>> getSupportedSourceTypes();
    java.lang.Character convert(java.lang.Object, java.lang.Class<? extends java.lang.Character>);
    java.lang.Object convert(java.lang.Object, java.lang.Class);
```

### `DateTypeConverter`（5 方法）

`com.seeyon.boot.util.bean.DateTypeConverter`

```java
    static java.util.Date dateValue(java.lang.Object, java.lang.Class<? extends java.util.Date>);
    java.lang.Class<java.util.Date> getTargetType();
    java.util.List<java.lang.Class<?>> getSupportedSourceTypes();
    java.util.Date convert(java.lang.Object, java.lang.Class<? extends java.util.Date>);
    java.lang.Object convert(java.lang.Object, java.lang.Class);
```

### `DoublePrimitiveTypeConverter`（5 方法）

`com.seeyon.boot.util.bean.DoublePrimitiveTypeConverter`

```java
    static double doubleValue(java.lang.Object)
    java.lang.Class<java.lang.Double> getTargetType();
    java.util.List<java.lang.Class<?>> getSupportedSourceTypes();
    java.lang.Double convert(java.lang.Object, java.lang.Class<? extends java.lang.Double>);
    java.lang.Object convert(java.lang.Object, java.lang.Class);
```

### `FloatPrimitiveTypeConverter`（5 方法）

`com.seeyon.boot.util.bean.FloatPrimitiveTypeConverter`

```java
    static float floatcharValue(java.lang.Object)
    java.lang.Class<java.lang.Float> getTargetType();
    java.util.List<java.lang.Class<?>> getSupportedSourceTypes();
    java.lang.Float convert(java.lang.Object, java.lang.Class<? extends java.lang.Float>);
    java.lang.Object convert(java.lang.Object, java.lang.Class);
```

### `IntTypeConverter`（5 方法）

`com.seeyon.boot.util.bean.IntTypeConverter`

```java
    static int intValue(java.lang.Object)
    java.lang.Class<java.lang.Integer> getTargetType();
    java.util.List<java.lang.Class<?>> getSupportedSourceTypes();
    java.lang.Integer convert(java.lang.Object, java.lang.Class<? extends java.lang.Integer>);
    java.lang.Object convert(java.lang.Object, java.lang.Class);
```

### `ListTypeConverter`（5 方法）

`com.seeyon.boot.util.bean.ListTypeConverter`

```java
    static <E extends java.util.List<?>> E listValue(java.lang.Object, java.lang.Class<? extends E>);
    java.lang.Class<java.util.List<?>> getTargetType();
    java.util.List<java.lang.Class<?>> getSupportedSourceTypes();
    java.util.List<?> convert(java.lang.Object, java.lang.Class<? extends java.util.List<?>>);
    java.lang.Object convert(java.lang.Object, java.lang.Class);
```

### `LongPrimitiveTypeConverter`（5 方法）

`com.seeyon.boot.util.bean.LongPrimitiveTypeConverter`

```java
    static long longValue(java.lang.Object)
    java.lang.Class<java.lang.Long> getTargetType();
    java.util.List<java.lang.Class<?>> getSupportedSourceTypes();
    java.lang.Long convert(java.lang.Object, java.lang.Class<? extends java.lang.Long>);
    java.lang.Object convert(java.lang.Object, java.lang.Class);
```

### `QueueTypeConverter`（5 方法）

`com.seeyon.boot.util.bean.QueueTypeConverter`

```java
    static <E extends java.util.Queue<?>> E queueValue(java.lang.Object, java.lang.Class<? extends E>);
    java.lang.Class<java.util.Queue<?>> getTargetType();
    java.util.List<java.lang.Class<?>> getSupportedSourceTypes();
    java.util.Queue<?> convert(java.lang.Object, java.lang.Class<? extends java.util.Queue<?>>);
    java.lang.Object convert(java.lang.Object, java.lang.Class);
```

### `SetTypeConverter`（5 方法）

`com.seeyon.boot.util.bean.SetTypeConverter`

```java
    static <E extends java.util.Set<?>> E setValue(java.lang.Object, java.lang.Class<? extends E>);
    java.lang.Class<java.util.Set<?>> getTargetType();
    java.util.List<java.lang.Class<?>> getSupportedSourceTypes();
    java.util.Set<?> convert(java.lang.Object, java.lang.Class<? extends java.util.Set<?>>);
    java.lang.Object convert(java.lang.Object, java.lang.Class);
```

### `ShortPrimitiveTypeConverter`（5 方法）

`com.seeyon.boot.util.bean.ShortPrimitiveTypeConverter`

```java
    static short shortValue(java.lang.Object)
    java.lang.Class<java.lang.Short> getTargetType();
    java.util.List<java.lang.Class<?>> getSupportedSourceTypes();
    java.lang.Short convert(java.lang.Object, java.lang.Class<? extends java.lang.Short>);
    java.lang.Object convert(java.lang.Object, java.lang.Class);
```

### `Utils`（5 方法）

`com.seeyon.boot.util.http.common.Utils`

```java
    static java.lang.String checkHasParas(java.lang.String, java.util.List<org.apache.http.NameValuePair>, java.lang.String)
    static org.apache.http.HttpEntity map2HttpEntity(java.util.List<org.apache.http.NameValuePair>, java.util.Map<java.lang.String, java.lang.Object>, java.lang.String)
    static private static void removeContentTypeCharset(java.lang.String, org.apache.http.HttpEntity);
    static java.util.Map<java.lang.String, java.lang.Object> buildParas(java.lang.String);
    static java.util.Map<java.lang.String, java.lang.Object> buildParas(java.lang.String[][]);
```

### `InspectionService`（4 方法）

`com.seeyon.boot.inspection.InspectionService`

```java
    java.util.List<com.seeyon.boot.inspection.dto.InspectionMiddlewareDto> getInspectionMiddlewareList();
    private void init();
    com.seeyon.boot.inspection.dto.InspectionResultDto inspection(java.lang.String);
    java.util.Map<java.lang.String, com.seeyon.boot.inspection.dto.InspectionResultDto> inspection();
```

### `InspectionUtils`（4 方法）

`com.seeyon.boot.inspection.utils.InspectionUtils`

```java
    static boolean setVersion(com.seeyon.boot.inspection.dto.InspectionItemResultDto, java.lang.String, boolean, java.lang.String);
    static boolean setType(com.seeyon.boot.inspection.dto.InspectionItemResultDto, java.lang.String);
    static boolean setType(com.seeyon.boot.inspection.dto.InspectionItemResultDto, java.lang.String, java.lang.String);
    static boolean setConnection(com.seeyon.boot.inspection.dto.InspectionItemResultDto, boolean);
```

### `SPIProviderRegisterEvent`（4 方法）

`com.seeyon.boot.starter.spi.event.SPIProviderRegisterEvent`

```java
    java.lang.String getInterfaceName();
    java.util.List getSpiProviders();
    void setInterfaceName(java.lang.String);
    void setSpiProviders(java.util.List);
```

### `SystemTenantInvocationHandler`（4 方法）

`com.seeyon.boot.tenant.SystemTenantInvocationHandler`

```java
    static <T> T build(T, java.lang.Class);
    static <T> T build(T);
    static <T> T build(java.lang.Class<T>);
```

### `ClassPoolUtils`（4 方法）

`com.seeyon.boot.util.ClassPoolUtils`

```java
    static javassist.ClassPool getClassPool(java.lang.ClassLoader, java.lang.Class);
    static void clear(java.lang.ClassLoader);
    static void clearRubbish();
```

### `PropertiesBuilder`（4 方法）

`com.seeyon.boot.util.PropertiesBuilder`

```java
    static <T> T buildProperties(java.lang.Class<T>, java.lang.String);
    static <T> T buildProperties(java.lang.Class<T>);
    static private static java.lang.Object build(java.lang.Object, java.lang.String);
    static java.lang.Object build(java.lang.Object);
```

### `SqlCheckUtils`（4 方法）

`com.seeyon.boot.util.SqlCheckUtils`

```java
    static java.lang.String injectSqlRedisKey();
    static java.lang.String veryLongSqlRedisKey();
    static boolean isInject(java.lang.String);
    static boolean isVeryLong(java.lang.String);
```

### `BooleanTypeConverter`（4 方法）

`com.seeyon.boot.util.bean.BooleanTypeConverter`

```java
    java.lang.Class<java.lang.Boolean> getTargetType();
    java.util.List<java.lang.Class<?>> getSupportedSourceTypes();
    java.lang.Boolean convert(java.lang.Object, java.lang.Class<? extends java.lang.Boolean>);
    java.lang.Object convert(java.lang.Object, java.lang.Class);
```

### `ByteTypeConverter`（4 方法）

`com.seeyon.boot.util.bean.ByteTypeConverter`

```java
    java.lang.Class<java.lang.Byte> getTargetType();
    java.util.List<java.lang.Class<?>> getSupportedSourceTypes();
    java.lang.Byte convert(java.lang.Object, java.lang.Class<? extends java.lang.Byte>);
    java.lang.Object convert(java.lang.Object, java.lang.Class);
```

### `CharacterTypeConverter`（4 方法）

`com.seeyon.boot.util.bean.CharacterTypeConverter`

```java
    java.lang.Class<java.lang.Character> getTargetType();
    java.util.List<java.lang.Class<?>> getSupportedSourceTypes();
    java.lang.Character convert(java.lang.Object, java.lang.Class<? extends java.lang.Character>);
    java.lang.Object convert(java.lang.Object, java.lang.Class);
```

### `DoubleTypeConverter`（4 方法）

`com.seeyon.boot.util.bean.DoubleTypeConverter`

```java
    java.lang.Class<java.lang.Double> getTargetType();
    java.util.List<java.lang.Class<?>> getSupportedSourceTypes();
    java.lang.Double convert(java.lang.Object, java.lang.Class<? extends java.lang.Double>);
    java.lang.Object convert(java.lang.Object, java.lang.Class);
```

### `FloatTypeConverter`（4 方法）

`com.seeyon.boot.util.bean.FloatTypeConverter`

```java
    java.lang.Class<java.lang.Float> getTargetType();
    java.util.List<java.lang.Class<?>> getSupportedSourceTypes();
    java.lang.Float convert(java.lang.Object, java.lang.Class<? extends java.lang.Float>);
    java.lang.Object convert(java.lang.Object, java.lang.Class);
```

### `IntegerTypeConverter`（4 方法）

`com.seeyon.boot.util.bean.IntegerTypeConverter`

```java
    java.lang.Class<java.lang.Integer> getTargetType();
    java.util.List<java.lang.Class<?>> getSupportedSourceTypes();
    java.lang.Integer convert(java.lang.Object, java.lang.Class<? extends java.lang.Integer>);
    java.lang.Object convert(java.lang.Object, java.lang.Class);
```

### `LongTypeConverter`（4 方法）

`com.seeyon.boot.util.bean.LongTypeConverter`

```java
    java.lang.Class<java.lang.Long> getTargetType();
    java.util.List<java.lang.Class<?>> getSupportedSourceTypes();
    java.lang.Long convert(java.lang.Object, java.lang.Class<? extends java.lang.Long>);
    java.lang.Object convert(java.lang.Object, java.lang.Class);
```

### `ShortTypeConverter`（4 方法）

`com.seeyon.boot.util.bean.ShortTypeConverter`

```java
    java.lang.Class<java.lang.Short> getTargetType();
    java.util.List<java.lang.Class<?>> getSupportedSourceTypes();
    java.lang.Short convert(java.lang.Object, java.lang.Class<? extends java.lang.Short>);
    java.lang.Object convert(java.lang.Object, java.lang.Class);
```

### `TimestampTypeConverter`（4 方法）

`com.seeyon.boot.util.bean.TimestampTypeConverter`

```java
    java.lang.Class<java.sql.Timestamp> getTargetType();
    java.util.List<java.lang.Class<?>> getSupportedSourceTypes();
    java.sql.Timestamp convert(java.lang.Object, java.lang.Class<? extends java.sql.Timestamp>);
    java.lang.Object convert(java.lang.Object, java.lang.Class);
```

### `DESUtils`（4 方法）

`com.seeyon.boot.util.encrypt.DESUtils`

```java
    static java.lang.String encrypt(java.lang.String, java.lang.String);
    static java.lang.String encrypt(byte[], java.lang.String);
    static java.lang.String decrypt(java.lang.String, java.lang.String);
    static byte[] decrypt2Byte(java.lang.String, java.lang.String);
```

### `SHA256Utils`（4 方法）

`com.seeyon.boot.util.encrypt.SHA256Utils`

```java
    static java.lang.String encrypt(java.lang.String);
    static java.lang.String encrypt(byte[]);
    static byte[] encrypt2Byte(byte[]);
    static private static java.lang.String toHexString(byte[]);
```

### `RestServiceUtil`（4 方法）

`com.seeyon.boot.util.http.RestServiceUtil`

```java
    static com.seeyon.boot.transport.SingleResponse getSingleResponse(java.util.Map, java.lang.String);
    static com.seeyon.boot.transport.ListResponse getListResponse(java.util.Map, java.lang.String);
    static com.seeyon.boot.transport.PageResponse getPageResponse(java.util.Map, java.lang.String);
    static private static com.seeyon.boot.util.http.common.HttpHeader getHttpHeaders();
```

### `SWLogClientAppender`（3 方法）

`com.seeyon.boot.log.trace.SWLogClientAppender`

```java
    void start();
    protected void subAppend(ch.qos.logback.classic.spi.ILoggingEvent);
    protected void subAppend(java.lang.Object);
```

### `AopTargetUtils`（3 方法）

`com.seeyon.boot.util.AopTargetUtils`

```java
    static java.lang.Object getTarget(java.lang.Object);
    static private static java.lang.Object getCglibProxyTargetObject(java.lang.Object)
    static private static java.lang.Object getJdkDynamicProxyTargetObject(java.lang.Object)
```

### `PageUtils`（3 方法）

`com.seeyon.boot.util.PageUtils`

```java
    static <T> com.seeyon.boot.transport.PageResponse<T> paginate(java.util.List<T>, com.seeyon.boot.transport.PageInfo);
    static <T> com.seeyon.boot.transport.PageData<T> paginateData(java.util.List<T>, com.seeyon.boot.transport.PageInfo);
    static <T> java.util.List<T> paginateList(java.util.List<T>, com.seeyon.boot.transport.PageInfo);
```

### `AbstractArrayTypeConverterSupport`（3 方法）

`com.seeyon.boot.util.bean.AbstractArrayTypeConverterSupport`

```java
    static java.lang.Object arrayValue(java.lang.Class<? extends java.lang.Object>, java.lang.Object, com.seeyon.boot.util.bean.TypeConverterManager);
    static private static java.lang.Object conver(com.seeyon.boot.util.bean.TypeConverterManager, java.lang.Object, java.lang.Class<?>);
    T convert(java.lang.Object, java.lang.Class<? extends T>);
```

### `AbstractTypeConverter`（3 方法）

`com.seeyon.boot.util.bean.AbstractTypeConverter`

```java
    java.util.List<java.lang.Class<?>> getSupportedSourceTypes();
    T convert(java.util.Map<? extends java.lang.Object, ? extends java.lang.Object>, java.lang.Object, java.lang.Class<? extends T>);
    T convert(java.lang.Object, java.lang.Class<? extends T>);
```

### `ConverterNotFoundException`（3 方法）

`com.seeyon.boot.util.bean.ConverterNotFoundException`

```java
    java.lang.Class<?> getSourceType();
    java.lang.Class<?> getTargetType();
    java.lang.String toString();
```

### `SHA1Utils`（3 方法）

`com.seeyon.boot.util.encrypt.SHA1Utils`

```java
    static java.lang.String encrypt(java.lang.String);
    static java.lang.String encrypt(byte[]);
    static byte[] encrypt2Byte(byte[]);
```

### `HttpClientMetrics`（3 方法）

`com.seeyon.boot.util.http.meter.HttpClientMetrics`

```java
    void bindTo(io.micrometer.core.instrument.MeterRegistry);
    static void success();
    static void fail();
```

## 三、注解（38）

| 注解 | 元素 |
|---|---|
| `AppService` | value, description, sort, customs |
| `AppServiceOperation` | value, description, returnValue, openApi, sort, requestMaxSize |
| `BootApp` | name, names, caption, version, description, owner |
| `Custom` | name, properties |
| `CustomAttribute` | name, value |
| `DtoAttribute` | value, description, hidden, xssProcess, dataI18n, relationApp |
| `DtoInfo` | value, entity, sort, isPublic, customs |
| `EntityAttribute` | value, description, hidden, changeId, dataI18n, dataType |
| `EntityIndex` | value, indexType, name, columns |
| `EntityInfo` | value, description, entityType, historyEntity, plugins, fullTextSearch |
| `EnumAttribute` | value, description, icon, color, sort, customs |
| `EnumInfo` | value, type, description, excludes, sort, customs |
| `FileFieldAttribute` | fileFieldType |
| `HasRole` | value, orgId |
| `Maskable` | type, maskKeys, start, end |
| `MessageInfo` | value, description, topic, sort, openApi, customs |
| `MigrationIgnoreField` | ignoreField |
| `MigrationStorageField` | value, storageType |
| `MultiRequestBody` | required, value |
| `OpenApi` | isOpenApi, url, async, sort, customs |
| `ParameterInfo` | value, example, customs |
| `ResourcePermission` | pageInfo, resourceInfo |
| `RestApi` | value, sort, group, customs |
| `RestApiOperation` | value, description, returnValue, customs, auditMode, sort |
| `Safety` | encryption, auditLog, permission, sensitive, openApiEncrypt |
| `ConfigAutoRefresh` | autoRefreshed |
| `CtpSentinel` | fallback |
| `AsyncTrace` |  |
| `IgnoredException` |  |
| `Trace` | operationName |
| `TraceTag` | key, value |
| `TraceTags` | value |
| `ExcelColumn` | value, width |
| `ExcelColumnWidth` | value |
| `ExcelContentFontStyle` | fontName, fontHeightInPoints, italic, strikeout, color, underline |
| `ExcelContentStyle` | dataFormat, hidden, locked, wrapped, verticalAlignment, horizontalAlignment |
| `ExcelHeadFontStyle` | fontName, fontHeightInPoints, italic, strikeout, color, underline |
| `ExcelHeadStyle` | dataFormat, hidden, locked, wrapped, verticalAlignment, horizontalAlignment |

## 四、枚举（29）

- `AggregationType`（2 常量）：One2Many, One2One
- `EncryptionEnum`（3 常量）：NONE, SYSTEM, DES
- `EncryptionType`（3 常量）：NOT_ENCRYPTION, REVERSIBLE_ENCRYPTION, DECRYPT_ONLY
- `EntityIndexType`（3 常量）：GENERAL, PRIMARY, UNIQUE
- `EntityType`（2 常量）：MASTER_ENTITY, SUB_ENTITY
- `EnumType`（2 常量）：NORMAL, IMAGE
- `FileFieldType`（3 常量）：NONE, PUBLIC, PRIVATE
- `MaskType`（4 常量）：None, Auto, All, Custom
- `MigrationStorageType`（2 常量）：NORMAL, MAINAPP
- `RelationType`（5 常量）：Many2OneAssociation, One2OneAssociation, One2OneAggregation, One2ManyAggregation, NONE
- `SystemEnvironment`（9 常量）：prod, pre, performance, test, dev, demo, local, unKnow, currSystemEnvironment
- `DatabaseType`（24 常量）：mysql, oracle, sqlserver, tidb, postgresql, db2, sybase, sqlite, mairadb, derby, clickhouse, dm8 …
- `EncryptionTypeEnum`（2 常量）：INTERNATIONAL, NATIONAL
- `FileEncryptEnum`（3 常量）：NONE, MODERATE_ENCRYPTION, DEEP_ENCRYPTION
- `ActionType`（4 常量）：NORMAL, INSERT, UPDATE, DELETE
- `AppDeployStatus`（4 常量）：DEPLOY_NONE, DEPLOY_RUNNING, DEPLOY_SUCCESS, DEPLOY_FAIL
- `DataChangeType`（2 常量）：INSERT, UPDATE
- `DataType`（19 常量）：STRING, INTEGER, BIGINTEGER, DECIMAL, BOOLEAN, DATETIME, DATE, TIME, ENTITY, OBJECT, ENUM, ATTACHMENT …
- `ScanDirection`（2 常量）：PREV, NEXT
- `TerminalEnum`（4 常量）：WEB, PC, MOBILE, PAD
- `AuditMode`（3 常量）：NONE, AUTO, SPECIAL
- `LogBizTypeEnum`（2 常量）：MANAGEMENT, BUSINESS
- `LogPathTypeEnum`（2 常量）：DEFAULT, IP
- `LogTypeEnum`（4 常量）：LOGIN, LOGOUT, ACCESS, NO_ACCESS
- `CacheEviction`（2 常量）：LRU, NONE
- `ExcelEnum`（2 常量）：XLS, XLSX
- `HttpMethods`（8 常量）：GET, POST, HEAD, PUT, DELETE, TRACE, PATCH, OPTIONS
- `HttpVersionEnum`（3 常量）：HTTP_0_9, HTTP_1_0, HTTP_1_1
- `EnumJsonDeserializer`（0 常量）
