# portal-facade：接口与方法签名

> 自动生成，勿手改。`tools/core/platform/emit_package_surfaces.py` 重跑即可。
> 构件 `com.seeyon:portal-facade`（jar `portal-facade-5.3.392.jar`）
> 规模：49 类 / 7 接口 / 0 注解 / 5 枚举 / 2 个关键类 / 633 方法。
> 签名逐字来自 javap 原文；已去掉 `public` 前缀与 `throws` 子句。

## 一、接口（7）

### `PortalPortletAppService`（11 方法）

`com.seeyon.portal.api.PortalPortletAppService`

```java
    com.seeyon.boot.transport.SingleResponse<java.lang.Long> createCategory(com.seeyon.boot.transport.SingleRequest<com.seeyon.portal.dto.PortletCategoryDesignerDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Long> updateCategory(com.seeyon.boot.transport.SingleRequest<com.seeyon.portal.dto.PortletCategoryDesignerDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> deleteCategoryByCodes(com.seeyon.boot.transport.SingleRequest<java.util.List<java.lang.String>>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Long> createPortlet(com.seeyon.boot.transport.SingleRequest<com.seeyon.portal.dto.PortletDefinitionDesignerDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> deletePortletByIds(com.seeyon.boot.transport.SingleRequest<java.util.List<java.lang.String>>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> createBatchCategory(com.seeyon.boot.transport.SingleRequest<com.seeyon.portal.dto.UdcPortletCategoryListDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> createBatchPortlet(com.seeyon.boot.transport.SingleRequest<com.seeyon.portal.dto.UdcPortletDefinitionListDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> updatePortletSortNos(com.seeyon.boot.transport.SingleRequest<com.seeyon.portal.dto.PortalPortletSortNoParamDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Long> updatePortletName(com.seeyon.boot.transport.SingleRequest<com.seeyon.portal.dto.PortletDefinitionDesignerDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.portal.dto.PortletDefinitionDesignerDto> getPortalPortlet(com.seeyon.boot.transport.SingleRequest<com.seeyon.portal.dto.PortalPortletParamDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> deletePortlets(com.seeyon.boot.transport.SingleRequest<com.seeyon.portal.dto.PortletBatchOperateDto>);
```

### `PortalSetAppService`（11 方法）

`com.seeyon.portal.api.PortalSetAppService`

```java
    com.seeyon.boot.transport.SingleResponse<java.lang.Long> createPortal(com.seeyon.boot.transport.SingleRequest<com.seeyon.portal.dto.PortalSetDesignerDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Long> updatePortal(com.seeyon.boot.transport.SingleRequest<com.seeyon.portal.dto.PortalSetDesignerDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.String> exportPortalDesignInfo(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Long> importPortalDesignInfo(com.seeyon.boot.transport.SingleRequest<com.seeyon.portal.dto.PortalImportParamDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.String> publishPortalDesignInfo(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.portal.dto.PortalConsistenceDetectionDto> detection(com.seeyon.boot.transport.SingleRequest<com.seeyon.portal.dto.PortalDetectionRequestDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.String> deletePortalDesignInfo(com.seeyon.boot.transport.SingleRequest<java.util.List<java.lang.Long>>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Void> multiVersionPortalDesignInfo(com.seeyon.boot.transport.SingleRequest<java.util.List<java.util.Map>>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Long> createPcTemplateData(com.seeyon.boot.transport.SingleRequest<com.seeyon.portal.dto.PortalSetDesignerDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.portal.dto.PortalSetDto> selectRootOrgPortalSet(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.portal.dto.PortalSetDto> selectByIds(com.seeyon.boot.transport.SingleRequest<java.util.List<java.lang.Long>>);
```

### `PortalShortcutAppService`（6 方法）

`com.seeyon.portal.api.PortalShortcutAppService`

```java
    com.seeyon.boot.transport.SingleResponse<java.lang.Long> create(com.seeyon.boot.transport.SingleRequest<com.seeyon.portal.dto.PortalShortcutDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> update(com.seeyon.boot.transport.SingleRequest<com.seeyon.portal.dto.PortalShortcutDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> deleteById(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.portal.dto.PortalShortcutDto> selectById(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.portal.dto.PortalShortcutDto> selectListByConditions(com.seeyon.boot.transport.ListRequest);
    com.seeyon.boot.transport.ListResponse<com.seeyon.portal.dto.PortalShortcutDto> selectByIds(com.seeyon.boot.transport.SingleRequest<java.util.List<java.lang.Long>>);
```

### `PortalSpaceAppService`（6 方法）

`com.seeyon.portal.api.PortalSpaceAppService`

```java
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> deleteSpaceById(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Long> createSpace(com.seeyon.boot.transport.SingleRequest<com.seeyon.portal.dto.PortalSpaceDesignerDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Long> updateSpace(com.seeyon.boot.transport.SingleRequest<com.seeyon.portal.dto.PortalSpaceDesignerDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.portal.dto.PortalSpaceDesignerDto> selectDesignSpaceList(com.seeyon.boot.transport.SingleRequest<java.util.List<java.lang.Long>>);
    com.seeyon.boot.transport.SingleResponse<java.util.Map<java.lang.String, java.lang.Long>> saveAsPortalSpaceCopy(com.seeyon.boot.transport.SingleRequest<com.seeyon.portal.dto.UdcPortalSpaceAndInstanceDto>);
    default com.seeyon.boot.transport.SingleResponse<java.util.Map<java.lang.Long, java.util.List<java.util.Map<java.lang.String, java.lang.Object>>>> selectAllSectionsByUserIds(com.seeyon.boot.transport.SingleRequest<java.util.List<java.lang.Long>>);
```

### `AbstractHolidayReminderService`（4 方法）

`com.seeyon.portal.spi.AbstractHolidayReminderService`

```java
    java.util.List<com.seeyon.portal.dto.holiday.HolidayConfigDto> remind(java.lang.String, java.lang.String, java.util.List<com.seeyon.portal.dto.holiday.HolidayConfigDto>);
    void record(java.lang.String, java.lang.String, java.util.List<com.seeyon.portal.dto.holiday.HolidayConfigDto>);
    default java.lang.String remindType();
    default java.lang.String remindDescription();
```

### `PortalConfigAppService`（2 方法）

`com.seeyon.portal.api.PortalConfigAppService`

```java
    com.seeyon.boot.transport.SingleResponse<java.util.Map<java.lang.String, java.lang.Object>> config(com.seeyon.boot.transport.SingleRequest<com.seeyon.portal.dto.PortalConfigParamDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.portal.dto.AboutDto> about();
```

### `PortalConstants`（0 方法）

`com.seeyon.portal.constant.PortalConstants`

```java
```

## 二、关键类（2）

### `HolidayConfigDto`（18 方法）

`com.seeyon.portal.dto.holiday.HolidayConfigDto`

```java
    java.lang.Long getId();
    java.lang.String getTitle();
    java.lang.String getRemindType();
    java.lang.String getUseScope();
    java.util.Date getStartTime();
    java.util.Date getEndTime();
    java.lang.Integer getSortNo();
    java.lang.String getContentType();
    java.util.List<com.seeyon.portal.dto.holiday.HolidayContentDto> getContent();
    void setId(java.lang.Long);
    void setTitle(java.lang.String);
    void setRemindType(java.lang.String);
    void setUseScope(java.lang.String);
    void setStartTime(java.util.Date);
    void setEndTime(java.util.Date);
    void setSortNo(java.lang.Integer);
    void setContentType(java.lang.String);
    void setContent(java.util.List<com.seeyon.portal.dto.holiday.HolidayContentDto>);
```

### `PortalConfigParamDto`（8 方法）

`com.seeyon.portal.dto.PortalConfigParamDto`

```java
    com.seeyon.portal.enums.SpacePortalTypeEnum getPortalType();
    java.lang.String getSid();
    com.seeyon.portal.enums.PageLoginPageTypeEnum getPageLoginPageType();
    java.lang.String getUri();
    void setPortalType(com.seeyon.portal.enums.SpacePortalTypeEnum);
    void setSid(java.lang.String);
    void setPageLoginPageType(com.seeyon.portal.enums.PageLoginPageTypeEnum);
    void setUri(java.lang.String);
```

## 四、枚举（5）

- `PageLoginPageTypeEnum`（2 常量）：UNIFY, INDEPENDENT
- `PortalBusinessTypeEnum`（3 常量）：ROOT_ORG, NORMAL, LOGIN_ROOT_ORG
- `PortalMessageType`（1 常量）：BOTTOM_NAV_DETECTION
- `PortalSubOrgScopeEnum`（2 常量）：ALL_SUB_ORG, ASSIGN_SUB_ORG
- `SpacePortalTypeEnum`（4 常量）：PC, DESKTOP, MOBILE, PC_MOBILE
