# boot-starter-parameter：接口与方法签名

> 自动生成，勿手改。`tools/core/platform/emit_package_surfaces.py` 重跑即可。
> 构件 `com.seeyon:boot-starter-parameter`（jar `boot-starter-parameter-5.3.603.jar`）
> 规模：22 类 / 2 接口 / 0 注解 / 1 枚举 / 6 个关键类 / 248 方法。
> 签名逐字来自 javap 原文；已去掉 `public` 前缀与 `throws` 子句。

## 一、接口（2）

### `CtpParameterDao`（0 方法） extends CtpParameter>

`com.seeyon.boot.starter.parameter.domain.dao.CtpParameterDao`

```java
```

### `CtpParameterDefinitionDao`（0 方法） extends CtpParameterDefinition>

`com.seeyon.boot.starter.parameter.domain.dao.CtpParameterDefinitionDao`

```java
```

## 二、关键类（6）

### `CtpParameterService`（60 方法）

`com.seeyon.boot.starter.parameter.domain.service.CtpParameterService`

```java
    java.lang.Long create(com.seeyon.boot.starter.parameter.dto.CtpParameterDto);
    int update(com.seeyon.boot.starter.parameter.dto.CtpParameterDto);
    int createBatch(java.util.List<com.seeyon.boot.starter.parameter.dto.CtpParameterDto>);
    int updateBatch(java.util.List<com.seeyon.boot.starter.parameter.dto.CtpParameterDto>);
    void sendMessage(java.util.List<com.seeyon.boot.starter.parameter.mq.data.ParameterMessageData>);
    void addOrgCache(java.lang.String, java.lang.Long, java.lang.String);
    int deleteById(java.lang.Long);
    int deleteByIds(java.util.List<java.lang.Long>);
    int deleteByConditions(java.util.Map<java.lang.String, java.lang.Object>);
    com.seeyon.boot.starter.parameter.dto.CtpParameterDto selectById(java.lang.Long);
    java.util.List<com.seeyon.boot.starter.parameter.dto.CtpParameterDto> selectByIds(java.util.List<java.lang.Long>);
    com.seeyon.boot.starter.parameter.dto.CtpParameterDto selectOneByCondition(java.util.Map<java.lang.String, java.lang.Object>);
    com.seeyon.boot.transport.PageData<com.seeyon.boot.starter.parameter.dto.CtpParameterDto> selectPageByCondition(com.seeyon.boot.transport.PageInfo, java.util.Map<java.lang.String, java.lang.Object>, com.seeyon.boot.transport.Sort);
    java.util.Map<java.lang.String, java.lang.Object> selectValuesByApp(java.lang.String);
    java.util.Map<java.lang.String, java.lang.Object> selectValuesByAppName(java.lang.String);
    java.lang.String getValue(java.lang.String);
    java.util.Map<java.lang.String, java.lang.String> getValuesMap(java.util.List<com.seeyon.boot.starter.parameter.dto.CtpParameterDefinitionDto>);
    private java.util.Map<java.lang.String, java.lang.String> getParameterMap(java.util.List<com.seeyon.boot.starter.parameter.dto.CtpParameterDefinitionDto>, java.lang.Long, java.lang.Long[]);
    java.lang.String getValue(java.lang.String, com.seeyon.boot.starter.parameter.dto.CtpParameterDefinitionDto);
    private java.lang.String getValueForSystem(java.lang.String, com.seeyon.boot.starter.parameter.dto.CtpParameterDefinitionDto);
    private java.lang.String getParameterForSystem(java.lang.String);
    java.lang.String getValue(java.lang.String, java.lang.Long, java.lang.Long[]);
    java.util.List<com.seeyon.boot.starter.parameter.dto.CtpParameterDto> getParameterWithoutDefaultValue(java.util.List<java.lang.String>, java.util.List<java.lang.Long>);
    private java.util.List<com.seeyon.boot.starter.parameter.dto.CtpParameterDto> getParameters(java.util.List<java.lang.String>, java.util.List<java.lang.Long>);
    java.lang.String getValueNew(java.lang.String, java.util.List<java.lang.Long>);
    private java.lang.String getParameter(java.lang.String, java.lang.Long, java.lang.Long[]);
    java.util.Map<java.lang.Long, java.lang.String> getLocaleParameterNew(java.lang.String, java.util.List<java.lang.Long>, java.lang.Long);
    private java.lang.String getLocaleValue(java.lang.String, java.lang.String);
    private java.lang.String getParameterNew(java.lang.String, java.util.List<java.lang.Long>);
    private java.lang.String getValueByOrgid(java.lang.String, java.lang.Long);
    private java.lang.String getValue(java.util.List<java.lang.String>, java.lang.Long, java.lang.Long[]);
    private void cacheIt(org.springframework.cache.Cache, java.lang.String, java.util.List<com.seeyon.boot.starter.parameter.dto.CtpParameterDto>);
    private java.lang.String getDefaultValue(java.lang.String);
    private void evictCache(com.seeyon.boot.starter.parameter.dto.CtpParameterDto);
    java.util.List<com.seeyon.boot.starter.parameter.dto.CtpParameterDto> selectByAppId(java.lang.String);
    void setEnumValue(java.util.List<com.seeyon.boot.starter.parameter.dto.CtpParameterDto>);
    private void setParameterOrg(com.seeyon.boot.starter.parameter.dto.CtpParameterDefinitionDto, com.seeyon.boot.starter.parameter.dto.CtpParameterDto);
    private void fillAggregationAppName(com.seeyon.boot.starter.parameter.dto.CtpParameterDto);
    private void fillAggregationAppName(java.util.List<com.seeyon.boot.starter.parameter.dto.CtpParameterDto>);
    private java.lang.String getAggregationAppNameFromContext();
```

### `CtpParameterDefinitionService`（31 方法）

`com.seeyon.boot.starter.parameter.domain.service.CtpParameterDefinitionService`

```java
    private void clearCache(java.lang.String, java.lang.String, java.lang.Long);
    java.lang.Long create(com.seeyon.boot.starter.parameter.dto.CtpParameterDefinitionDto);
    java.lang.Integer createBatch(java.util.List<com.seeyon.boot.starter.parameter.dto.CtpParameterDefinitionDto>);
    private void validate(com.seeyon.boot.starter.parameter.dto.CtpParameterDefinitionDto);
    private com.seeyon.boot.starter.parameter.domain.entity.CtpParameterDefinition dto2Entity(com.seeyon.boot.starter.parameter.dto.CtpParameterDefinitionDto, com.seeyon.boot.starter.parameter.domain.entity.CtpParameterDefinition);
    private com.seeyon.boot.starter.parameter.dto.CtpParameterDefinitionDto entity2Dto(com.seeyon.boot.starter.parameter.domain.entity.CtpParameterDefinition);
    private java.util.List<com.seeyon.boot.starter.parameter.dto.CtpParameterDefinitionDto> entities2DtoList(java.util.List<com.seeyon.boot.starter.parameter.domain.entity.CtpParameterDefinition>);
    int update(com.seeyon.boot.starter.parameter.dto.CtpParameterDefinitionDto);
    int deleteById(java.lang.Long);
    int deleteByIds(java.util.List<java.lang.Long>);
    int deletePhysicalByIds(java.util.List<java.lang.Long>);
    com.seeyon.boot.starter.parameter.dto.CtpParameterDefinitionDto selectById(java.lang.Long);
    com.seeyon.boot.starter.parameter.dto.CtpParameterDefinitionDto setEnumValue(com.seeyon.boot.starter.parameter.dto.CtpParameterDefinitionDto);
    com.seeyon.boot.starter.parameter.dto.CtpParameterDefinitionDto selectByGuid(java.lang.Long);
    java.util.List<com.seeyon.boot.starter.parameter.dto.CtpParameterDefinitionDto> selectByIds(java.util.List<java.lang.Long>);
    java.util.List<com.seeyon.boot.starter.parameter.dto.CtpParameterDefinitionDto> selectListByConditions(java.util.Map<java.lang.String, java.lang.Object>);
    com.seeyon.boot.starter.parameter.dto.CtpParameterDefinitionDto getDefinition(java.lang.String);
    com.seeyon.boot.transport.PageData<com.seeyon.boot.starter.parameter.dto.CtpParameterDefinitionDto> selectPageByCondition(com.seeyon.boot.transport.PageInfo, java.util.Map<java.lang.String, java.lang.Object>, com.seeyon.boot.transport.Sort);
    com.seeyon.boot.starter.parameter.dto.CtpParameterDefinitionDto selectOneParameterDefinition(java.lang.String);
    com.seeyon.boot.starter.parameter.dto.CtpParameterDefinitionDto selectByAppIdAndName(java.lang.String, java.lang.String);
    java.util.List<com.seeyon.boot.starter.parameter.dto.CtpParameterDefinitionDto> selectByAppId(java.lang.String);
    java.util.List<com.seeyon.boot.starter.parameter.dto.CtpParameterDefinitionDto> selectByAppName(java.lang.String);
    java.util.List<com.seeyon.boot.starter.parameter.dto.CtpParameterDefinitionDto> selectByGroup(java.lang.String);
    java.lang.String getEnumValue(java.lang.String, com.seeyon.boot.starter.parameter.dto.CtpParameterDefinitionDto);
    com.seeyon.boot.transport.ListResponse<java.lang.Object> invokeAppService(java.lang.String, java.lang.String, java.lang.String, java.lang.Object, java.lang.String);
```

### `CtpParameterAppService`（19 方法）

`com.seeyon.boot.starter.parameter.appservice.CtpParameterAppService`

```java
    com.seeyon.boot.transport.SingleResponse<java.lang.Long> create(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.parameter.dto.CtpParameterDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> update(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.parameter.dto.CtpParameterDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> createBatch(com.seeyon.boot.transport.SingleRequest<java.util.List<com.seeyon.boot.starter.parameter.dto.CtpParameterDto>>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> updateBatch(com.seeyon.boot.transport.SingleRequest<java.util.List<com.seeyon.boot.starter.parameter.dto.CtpParameterDto>>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> deleteById(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> deleteByIds(com.seeyon.boot.transport.SingleRequest<java.util.List<java.lang.Long>>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> deleteByConditions(com.seeyon.boot.transport.SingleRequest<java.util.Map<java.lang.String, java.lang.Object>>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.boot.starter.parameter.dto.CtpParameterDto> selectById(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.PageResponse<com.seeyon.boot.starter.parameter.dto.CtpParameterDto> selectPageByCondition(com.seeyon.boot.transport.PageRequest);
    com.seeyon.boot.transport.ListResponse<com.seeyon.boot.starter.parameter.dto.CtpParameterDto> selectByIds(com.seeyon.boot.transport.SingleRequest<java.util.List<java.lang.Long>>);
    com.seeyon.boot.transport.SingleResponse<java.lang.String> getValue(java.lang.String);
    com.seeyon.boot.transport.SingleResponse<java.lang.String> getValueByName(com.seeyon.boot.transport.SingleRequest<java.lang.String>);
    com.seeyon.boot.transport.SingleResponse<java.lang.String> getValue(java.lang.String, java.lang.Long, java.lang.Long[]);
    com.seeyon.boot.transport.SingleResponse<java.lang.String> getValueNew(java.lang.String, java.util.List<java.lang.Long>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.boot.starter.parameter.dto.CtpParameterDto> getParameterWithoutDefaultValue(java.util.List<java.lang.String>, java.util.List<java.lang.Long>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.boot.starter.parameter.dto.CtpParameterDto> selectByAppId(com.seeyon.boot.transport.SingleRequest<java.lang.String>);
    com.seeyon.boot.transport.SingleResponse<java.util.Map<java.lang.String, java.lang.Object>> selectValuesByApp(com.seeyon.boot.transport.SingleRequest<java.lang.String>);
    com.seeyon.boot.transport.SingleResponse<java.util.Map<java.lang.String, java.lang.Object>> selectValuesByAppName(com.seeyon.boot.transport.SingleRequest<java.lang.String>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Boolean> setRestEnableLog(com.seeyon.boot.transport.SingleRequest<java.lang.Boolean>);
```

### `CtpParameterDefinitionAppService`（12 方法）

`com.seeyon.boot.starter.parameter.appservice.CtpParameterDefinitionAppService`

```java
    com.seeyon.boot.transport.SingleResponse<java.lang.Long> create(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.parameter.dto.CtpParameterDefinitionDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> update(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.parameter.dto.CtpParameterDefinitionDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> deleteById(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> deleteByIds(com.seeyon.boot.transport.SingleRequest<java.util.List<java.lang.Long>>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.boot.starter.parameter.dto.CtpParameterDefinitionDto> selectById(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.boot.starter.parameter.dto.CtpParameterDefinitionDto> selectByGuid(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.PageResponse<com.seeyon.boot.starter.parameter.dto.CtpParameterDefinitionDto> selectPageByCondition(com.seeyon.boot.transport.PageRequest);
    com.seeyon.boot.transport.ListResponse<com.seeyon.boot.starter.parameter.dto.CtpParameterDefinitionDto> selectByIds(com.seeyon.boot.transport.SingleRequest<java.util.List<java.lang.Long>>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.boot.starter.parameter.dto.CtpParameterDefinitionDto> selectByAppId(com.seeyon.boot.transport.SingleRequest<java.lang.String>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.boot.starter.parameter.dto.CtpParameterDefinitionDto> selectByAppIdWithoutDelete(com.seeyon.boot.transport.SingleRequest<java.lang.String>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.boot.starter.parameter.dto.CtpParameterDefinitionDto> selectByGroup(com.seeyon.boot.transport.SingleRequest<java.lang.String>);
```

### `CtpParameterConfig`（6 方法）

`com.seeyon.boot.starter.parameter.config.CtpParameterConfig`

```java
    boolean isEnableLog();
    void setEnableLog(boolean);
    boolean equals(java.lang.Object);
    protected boolean canEqual(java.lang.Object);
    int hashCode();
    java.lang.String toString();
```

### `ParameterUtil`（4 方法）

`com.seeyon.boot.starter.parameter.util.ParameterUtil`

```java
    static java.lang.String getValue(java.lang.String);
    static com.seeyon.boot.starter.parameter.dto.CtpParameterDto getParameter(java.lang.String);
    static java.lang.Object getRealValue(java.lang.String, com.seeyon.boot.starter.parameter.dto.CtpParameterDefinitionDto);
    static java.lang.String fullNameToName(java.lang.String);
```

## 四、枚举（1）

- `ParameterType`（3 常量）：SYSTEM, ORG, PERSONAL
