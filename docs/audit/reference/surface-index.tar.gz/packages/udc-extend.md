# udc-extend：接口与方法签名

> 自动生成，勿手改。`tools/core/platform/emit_package_surfaces.py` 重跑即可。
> 构件 `com.seeyon:udc-extend`（jar `udc-extend-5.3.517.jar`）
> 规模：82 类 / 0 接口 / 0 注解 / 0 枚举 / 21 个关键类 / 618 方法。
> 签名逐字来自 javap 原文；已去掉 `public` 前缀与 `throws` 子句。

## 一、接口（0）

（本构件没有接口）

## 二、关键类（21）

### `UdcBasicDataAppService`（58 方法）

`com.seeyon.udc.extend.appservice.UdcBasicDataAppService`

```java
    com.seeyon.boot.transport.SingleResponse<java.lang.Long> create(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.basicdata.dto.BasicDataEntityDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> update(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.basicdata.dto.BasicDataEntityDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> deleteById(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> deleteByIds(com.seeyon.boot.transport.SingleRequest<java.util.List<java.lang.Long>>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.udc.page.dto.PageInfoDto> createBasicDataPageSchema(com.seeyon.boot.transport.SingleRequest<com.seeyon.udc.extend.domain.dto.UdcBasicDataSchemaRequestDto>);
    private com.seeyon.udc.page.dto.PageInfoDto generateBasicInfoPage(com.seeyon.udc.common.dto.EntityDto, com.seeyon.boot.starter.basicdata.dto.BasicDataEntityDto);
    private java.util.List<com.seeyon.udc.common.dto.PageReferDto> referConfig(com.seeyon.udc.common.dto.EntityDto);
    private java.util.Map<java.lang.String, java.lang.Object> initPageSchema(com.seeyon.udc.page.dto.PageInfoDto, com.seeyon.udc.common.dto.EntityDto, com.seeyon.boot.starter.basicdata.dto.BasicDataEntityDto);
    private java.util.Map<java.lang.String, java.lang.Object> initChildById(java.lang.String, com.seeyon.udc.page.dto.PageInfoDto, com.seeyon.udc.common.dto.EntityDto, com.seeyon.boot.starter.basicdata.dto.BasicDataEntityDto);
    private java.util.List<java.lang.String> getFieldList(java.lang.String, java.util.List<com.seeyon.udc.common.dto.AttributeDto>, com.seeyon.udc.common.dto.EntityDto);
    private java.lang.String getAttrFullName(java.lang.String, java.lang.String, java.lang.String);
    private java.lang.String getEntityFullName(java.lang.String, java.lang.String);
    private java.lang.String getAttrKey(java.lang.String, java.lang.Long, java.lang.String);
    private java.lang.String getDefaultPlan(com.seeyon.udc.common.dto.EntityDto);
    com.seeyon.boot.transport.PageResponse<com.seeyon.udc.extend.domain.dto.UdcBasicDataUpgradeResultDto> designUpgradeCheck330(com.seeyon.boot.transport.PageRequest);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.udc.extend.domain.dto.UdcBasicDataUpgradeVersionDto> designUpgrade330(com.seeyon.boot.transport.SingleRequest<com.seeyon.udc.extend.domain.dto.UdcBasicDataUpgradeVersionDto>);
    private com.seeyon.udc.common.dto.EntityDto createUdcBasicEntity(com.seeyon.boot.starter.basicdata.dto.BasicDataEntityDto);
```

### `UdcCtpEnumService`（25 方法）

`com.seeyon.udc.extend.domain.service.UdcCtpEnumService`

```java
    java.util.List<com.seeyon.boot.starter.enums.dto.CtpEnumCategoryDto> selectCategoryByAppGuid(com.seeyon.udc.common.dto.UdcCtpEnumBaseSearchDto);
    com.seeyon.boot.starter.enums.dto.CtpEnumCategoryAndEnumDto selectCategoryAndEnum(com.seeyon.udc.common.dto.UdcCtpEnumBaseSearchDto);
    java.util.List<com.seeyon.boot.starter.enums.dto.CtpEnumDto> selectCtpEnum(com.seeyon.udc.common.dto.UdcCtpEnumBaseSearchDto);
    java.util.List<com.seeyon.boot.starter.enums.dto.CtpEnumDto> selectCtpEnumByIds(com.seeyon.udc.common.dto.UdcCtpEnumsSearchDto);
    com.seeyon.boot.starter.enums.dto.CtpEnumDto selectParentByCode(com.seeyon.udc.common.dto.UdcCtpEnumSearchDto);
    java.util.List<com.seeyon.boot.starter.enums.dto.CtpEnumDto> selectListByConditionsNoLevel(com.seeyon.udc.common.dto.UdcCtpEnumSearchDto);
    java.util.List<com.seeyon.boot.starter.enums.dto.CtpEnumDto> selectListByAppId(com.seeyon.udc.common.dto.UdcCtpEnumBaseSearchDto);
    java.util.List<com.seeyon.boot.starter.enums.dto.CtpEnumItemDto> selectCtpEnumItemByAppInfo(com.seeyon.udc.common.dto.UdcCtpEnumBaseSearchDto);
    com.seeyon.boot.starter.enums.dto.CtpEnumItemDto selectCtpEnumItemById(com.seeyon.udc.common.dto.UdcCtpEnumItemSearchDto);
    java.util.List<com.seeyon.boot.starter.enums.dto.CtpEnumItemDto> selectCtpEnumItemByEnumId(com.seeyon.udc.common.dto.UdcCtpEnumItemSearchDto);
    java.util.List<com.seeyon.boot.starter.enums.dto.CtpEnumItemDto> selectCtpEnumItemByAppNameAndEnumCode(com.seeyon.udc.common.dto.UdcCtpEnumItemSearchDto);
    java.util.List<com.seeyon.boot.starter.enums.dto.CtpEnumItemSimpleDto> selectCtpEnumItemSimpleByAppNameAndEnumCode(com.seeyon.udc.common.dto.UdcCtpEnumItemSearchDto);
    java.util.List<com.seeyon.boot.starter.enums.dto.CtpEnumItemSimpleDto> selectCtpEnumItemSimpleByAppNameAndEnumCodes(com.seeyon.udc.common.dto.UdcCtpEnumItemSearchDto);
    java.util.List<com.seeyon.boot.starter.enums.dto.CtpEnumItemDto> selectByEnumIds(com.seeyon.udc.common.dto.UdcCtpEnumItemSearchDto);
    java.util.List<com.seeyon.boot.starter.enums.dto.CtpEnumItemDto> selectEnumItemByConditions(com.seeyon.udc.common.dto.UdcCtpEnumItemSearchDto);
    java.util.List<com.seeyon.boot.starter.enums.dto.CtpEnumItemDto> selectEnumItemCascadeTreeByEnumCode(com.seeyon.udc.common.dto.UdcCtpEnumItemSearchDto);
    java.lang.Integer deleteByAppApprovalOrUdc(com.seeyon.udc.common.dto.UdcCtpEnumBaseSearchDto);
    java.lang.Integer updateBatchCategoryPreset(com.seeyon.udc.common.dto.UdcCtpEnumBaseSearchDto);
    java.lang.Integer updateBatchEnumPreset(com.seeyon.udc.common.dto.UdcCtpEnumBaseSearchDto);
    java.lang.Integer updateBatchEnumItemPreset(com.seeyon.udc.common.dto.UdcCtpEnumBaseSearchDto);
    void upgradeCtpEnumOrderNo(com.seeyon.udc.common.dto.UdcCtpEnumBaseSearchDto);
    private java.lang.Integer invokeForEnum(com.seeyon.boot.starter.dubbo.dto.AppServiceInvokeDto, java.util.Map<java.lang.String, java.lang.Object>, java.lang.String);
    private boolean nonNull(java.lang.Object);
    java.lang.Long getHostAppGuidByAppName(java.lang.String);
```

### `CtpSerialSchemaDetectionUtils`（21 方法）

`com.seeyon.udc.extend.detection.serial.util.CtpSerialSchemaDetectionUtils`

```java
    static java.util.List<com.seeyon.boot.starter.serialnumber.domain.dto.SerialSchemeDto> filterSerialSchemeDtoList(com.seeyon.udc.detection.context.DetectionContext);
    static java.util.Map<java.lang.Long, com.seeyon.boot.starter.serialnumber.domain.dto.SerialSchemeDto> getUnDeletedSerialSchemeMetadata(com.seeyon.udc.detection.context.DetectionContext);
    static java.util.Set<com.seeyon.udc.detection.dto.ConsistenceDetectionDto> doAttributeDetection(java.util.List<com.seeyon.boot.starter.serialnumber.domain.dto.SerialSchemeDto>, java.util.Map<java.lang.Long, com.seeyon.udc.common.dto.AttributeDto>, boolean);
    static java.util.Set<com.seeyon.udc.detection.dto.ConsistenceDetectionDto> doEntityDetection(java.util.List<com.seeyon.boot.starter.serialnumber.domain.dto.SerialSchemeDto>, java.util.Map<java.lang.Long, com.seeyon.udc.common.dto.EntityDto>, boolean);
    static private static java.util.Set<com.seeyon.udc.detection.dto.ConsistenceDetectionDto> buildAttributeDetectionDtoList(java.util.List<com.seeyon.boot.starter.serialnumber.domain.dto.SerialSchemeDto>, java.util.Map<java.lang.Long, com.seeyon.udc.common.dto.AttributeDto>, boolean);
    static private static java.util.Set<com.seeyon.udc.detection.dto.ConsistenceDetectionDto> buildEntityDetectionDtoList(java.util.List<com.seeyon.boot.starter.serialnumber.domain.dto.SerialSchemeDto>, java.util.Map<java.lang.Long, com.seeyon.udc.common.dto.EntityDto>, boolean);
    static private static java.util.function.Function<com.seeyon.boot.starter.serialnumber.domain.dto.SerialSchemeDto, com.seeyon.udc.detection.dto.ConsistenceDetectionDto> buildDetectionDtoFunction(com.seeyon.boot.starter.serialnumber.domain.dto.SerialSectionDto, com.seeyon.udc.detection.enums.ConsistenceDetectionCodeEnum);
    static private static java.lang.String buildRoute(com.seeyon.boot.starter.serialnumber.domain.dto.SerialSchemeDto, com.seeyon.boot.starter.serialnumber.domain.dto.SerialSectionDto, com.seeyon.udc.detection.enums.ConsistenceDetectionCodeEnum);
    static private static com.seeyon.udc.detection.dto.ConsistenceDetectionDto buildConsistenceDetectionDto(java.lang.Long, java.lang.String, java.lang.Object[], java.lang.Object[], com.seeyon.udc.detection.enums.ConsistenceDetectionCodeEnum);
```

### `UdcCtpEnumAppServiceImpl`（16 方法）

`com.seeyon.udc.extend.appservice.UdcCtpEnumAppServiceImpl`

```java
    com.seeyon.boot.transport.ListResponse<com.seeyon.boot.starter.enums.dto.CtpEnumCategoryDto> selectCategoryByAppGuid(com.seeyon.boot.transport.SingleRequest<com.seeyon.udc.common.dto.UdcCtpEnumBaseSearchDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.boot.starter.enums.dto.CtpEnumCategoryAndEnumDto> selectCategoryAndEnum(com.seeyon.boot.transport.SingleRequest<com.seeyon.udc.common.dto.UdcCtpEnumBaseSearchDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.boot.starter.enums.dto.CtpEnumDto> selectCtpEnum(com.seeyon.boot.transport.SingleRequest<com.seeyon.udc.common.dto.UdcCtpEnumBaseSearchDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.boot.starter.enums.dto.CtpEnumDto> selectCtpEnumByIds(com.seeyon.boot.transport.SingleRequest<com.seeyon.udc.common.dto.UdcCtpEnumsSearchDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.boot.starter.enums.dto.CtpEnumDto> selectParentByCode(com.seeyon.boot.transport.SingleRequest<com.seeyon.udc.common.dto.UdcCtpEnumSearchDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.boot.starter.enums.dto.CtpEnumDto> selectListByConditionsNoLevel(com.seeyon.boot.transport.SingleRequest<com.seeyon.udc.common.dto.UdcCtpEnumSearchDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.boot.starter.enums.dto.CtpEnumItemDto> selectCtpEnumItemById(com.seeyon.boot.transport.SingleRequest<com.seeyon.udc.common.dto.UdcCtpEnumItemSearchDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.boot.starter.enums.dto.CtpEnumItemDto> selectCtpEnumItemByAppInfo(com.seeyon.boot.transport.SingleRequest<com.seeyon.udc.common.dto.UdcCtpEnumBaseSearchDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.boot.starter.enums.dto.CtpEnumItemDto> selectCtpEnumItemByEnumId(com.seeyon.boot.transport.SingleRequest<com.seeyon.udc.common.dto.UdcCtpEnumItemSearchDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.boot.starter.enums.dto.CtpEnumItemDto> selectCtpEnumItemByAppNameAndEnumCode(com.seeyon.boot.transport.SingleRequest<com.seeyon.udc.common.dto.UdcCtpEnumItemSearchDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.boot.starter.enums.dto.CtpEnumItemSimpleDto> selectCtpEnumItemSimpleByAppNameAndEnumCode(com.seeyon.boot.transport.SingleRequest<com.seeyon.udc.common.dto.UdcCtpEnumItemSearchDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.boot.starter.enums.dto.CtpEnumItemSimpleDto> selectCtpEnumItemSimpleByAppNameAndEnumCodes(com.seeyon.boot.transport.SingleRequest<com.seeyon.udc.common.dto.UdcCtpEnumItemSearchDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.boot.starter.enums.dto.CtpEnumItemDto> selectByEnumIds(com.seeyon.boot.transport.SingleRequest<com.seeyon.udc.common.dto.UdcCtpEnumItemSearchDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.boot.starter.enums.dto.CtpEnumItemDto> selectEnumItemByConditions(com.seeyon.boot.transport.SingleRequest<com.seeyon.udc.common.dto.UdcCtpEnumItemSearchDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.boot.starter.enums.dto.CtpEnumItemDto> selectEnumItemCascadeTreeByEnumCode(com.seeyon.boot.transport.SingleRequest<com.seeyon.udc.common.dto.UdcCtpEnumItemSearchDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> deleteCtpEnumByAppApprovalOrUdc(com.seeyon.boot.transport.SingleRequest<com.seeyon.udc.common.dto.UdcCtpEnumItemSearchDto>);
```

### `AssociateEntityConfigDeployDto`（16 方法）

`com.seeyon.udc.extend.detection.associate.deploy.dto.AssociateEntityConfigDeployDto`

```java
    java.lang.Long getId();
    java.lang.String getControlCode();
    java.lang.String getAppName();
    java.lang.String getEntityFullName();
    java.lang.String getReferFullName();
    java.lang.String getTerminalType();
    java.lang.Integer getDataStatus();
    java.lang.Long getPackageTime();
    void setId(java.lang.Long);
    void setControlCode(java.lang.String);
    void setAppName(java.lang.String);
    void setEntityFullName(java.lang.String);
    void setReferFullName(java.lang.String);
    void setTerminalType(java.lang.String);
    void setDataStatus(java.lang.Integer);
    void setPackageTime(java.lang.Long);
```

### `UdcSerialSchemeService`（15 方法）

`com.seeyon.udc.extend.domain.service.UdcSerialSchemeService`

```java
    java.util.List<com.seeyon.boot.starter.serialnumber.domain.dto.SerialSchemeDto> selectSerialScheme(com.seeyon.udc.common.dto.UdcSerialSchemeSearchDto);
    private java.util.List<com.seeyon.boot.starter.serialnumber.domain.dto.SerialSchemeDto> invokeSelectSerialSchemeList(java.util.Map<java.lang.String, java.lang.Object>, com.seeyon.boot.transport.Sort, java.lang.String);
    java.util.List<com.seeyon.boot.starter.serialnumber.domain.dto.SerialRangeDto> selectSerialRange(com.seeyon.udc.common.dto.UdcSerialRangeSearchDto);
    com.seeyon.boot.starter.serialnumber.domain.dto.SerialSchemeDto selectSerialSchemeById(com.seeyon.udc.common.dto.UdcSerialSchemeSearchDto);
    java.lang.Long createEasyScheme(com.seeyon.udc.common.dto.UdcSerialSchemeCreateDto);
    java.util.List<com.seeyon.boot.starter.serialnumber.domain.dto.SerialSchemeDto> selectDepAppSerialScheme(java.util.List<com.seeyon.udc.common.dto.DependentApplicationDto>);
    java.util.List<com.seeyon.boot.starter.serialnumber.domain.dto.SerialSchemeDto> selectCommonSerialSchemeList(java.util.List<java.lang.Long>);
    private com.seeyon.boot.starter.serialnumber.domain.dto.SerialSchemeDto getEasyScheme(com.seeyon.udc.common.dto.UdcSerialSchemeCreateDto);
    java.lang.Integer updateBatchPreset(com.seeyon.udc.common.dto.UdcSerialSchemeBatchUpdateDto);
    private boolean nonNull(java.lang.Object);
    java.util.List<com.seeyon.udc.extend.dto.UdcSerialEntityDto> selectDesignSerialEntityList(com.seeyon.udc.extend.dto.UdcSearchSerialEntityDto);
    private java.util.List<com.seeyon.boot.starter.serialnumber.domain.dto.SerialSchemeDto> selectOutSerialScheme(com.seeyon.udc.common.dto.DependentApplicationDto);
```

### `AssociateConfigDeployDto`（12 方法）

`com.seeyon.udc.extend.detection.associate.deploy.dto.AssociateConfigDeployDto`

```java
    java.lang.Long getId();
    java.lang.String getControlCode();
    java.lang.String getAppScope();
    java.lang.String getAppName();
    java.lang.Integer getDataStatus();
    java.lang.Long getPackageTime();
    void setId(java.lang.Long);
    void setControlCode(java.lang.String);
    void setAppScope(java.lang.String);
    void setAppName(java.lang.String);
    void setDataStatus(java.lang.Integer);
    void setPackageTime(java.lang.Long);
```

### `BaseMetadataUtils`（12 方法）

`com.seeyon.udc.extend.util.BaseMetadataUtils`

```java
    static java.util.List<com.seeyon.boot.starter.enums.dto.CtpEnumCategoryDto> getCtpEnumCategoryMetadata(com.seeyon.udc.common.metadata.AppContext);
    static java.util.List<com.seeyon.boot.starter.enums.dto.CtpEnumDto> getCtpEnumMetadata(com.seeyon.udc.common.metadata.AppContext);
    static java.util.List<com.seeyon.boot.starter.enums.dto.CtpEnumItemDto> getCtpEnumItemMetadata(com.seeyon.udc.common.metadata.AppContext);
    static java.util.Map<java.lang.Long, com.seeyon.boot.starter.serialnumber.domain.dto.SerialSchemeDto> getCtpSerialSchemeMetadata(com.seeyon.udc.common.autocode.context.CodeContext);
    static java.util.List<com.seeyon.boot.starter.serialnumber.domain.dto.SerialSectionDto> getCtpSerialSectionMetadata(com.seeyon.udc.common.autocode.context.CodeContext);
    static java.util.List<com.seeyon.boot.starter.serialnumber.domain.dto.SerialConditionDto> getCtpSerialConditionMetadata(com.seeyon.udc.common.autocode.context.CodeContext);
    static java.util.List<com.seeyon.boot.starter.serialnumber.domain.dto.SerialRangeDto> getCtpSerialRangeMetadata(com.seeyon.udc.common.autocode.context.CodeContext);
    static java.util.List<com.seeyon.boot.starter.serialnumber.domain.dto.SerialCurrentDto> getCtpSerialCurrentMetadata(com.seeyon.udc.common.autocode.context.CodeContext);
    static java.util.List<com.seeyon.boot.starter.formconvert.dto.FormConvertCategoryDto> getFormConvertCategoryMetadata(com.seeyon.udc.common.autocode.context.CodeContext);
    static java.util.List<com.seeyon.boot.starter.formconvert.dto.FormConvertTemplateDto> getFormConvertTemplateMetadata(com.seeyon.udc.common.autocode.context.CodeContext);
    static java.util.List<com.seeyon.boot.starter.ganttchart.dto.setting.GanttChartSchemaDto> getProjectManagerSettingMetadata(com.seeyon.udc.common.autocode.context.CodeContext);
    static java.util.List<com.seeyon.boot.starter.qrcode.dto.CtpQrCodeRuleDto> getQrCodeRuleMetadata(com.seeyon.udc.common.autocode.context.CodeContext);
```

### `CtpExcelExportTemplateImporterBase`（11 方法）

`com.seeyon.udc.extend.autocode.transport.in.CtpExcelExportTemplateImporterBase`

```java
    void before(com.seeyon.udc.common.schema.TransportData);
    void in(com.seeyon.udc.common.schema.TransportData)
    void transfer(com.seeyon.udc.common.schema.TransportData);
    void importAppInfo(com.seeyon.udc.common.schema.TransportData);
    java.util.Set<java.lang.String> ignoreOnDefaultCopy();
    private void createData(com.seeyon.udc.common.schema.TransportData);
    java.util.List<com.seeyon.boot.starter.excel.domain.entity.ExcelExportTemplate> selectListByAppId(java.lang.Long);
```

### `CtpEnumUpgradeService`（10 方法）

`com.seeyon.udc.extend.domain.service.upgrade.CtpEnumUpgradeService`

```java
    void execute(java.util.List<java.util.Map>);
    void execute(java.lang.Object);
```

### `UdcQrCodeRuleDetectionService`（9 方法）

`com.seeyon.udc.extend.detection.qrcode.domain.service.UdcQrCodeRuleDetectionService`

```java
    java.util.List<com.seeyon.boot.starter.qrcode.domain.entity.CtpQrCodeRule> getRuleListByAppIdAndFieldCodes(com.seeyon.boot.starter.qrcode.dto.validation.PartDetectionRequestDto);
    java.util.List<com.seeyon.boot.starter.qrcode.domain.entity.CtpQrCodeRule> getRuleListByAppIdAndFullName(com.seeyon.boot.starter.qrcode.dto.validation.PartDetectionRequestDto);
    java.util.List<com.seeyon.boot.starter.qrcode.domain.entity.CtpQrCodeRule> getRuleListByAppId(java.lang.Long);
    java.util.List<com.seeyon.boot.starter.qrcode.domain.entity.CtpQrCodeRule> getDeleteRuleListByAppId(java.lang.Long);
```

### `CtpEnumSaveAsHandler`（7 方法）

`com.seeyon.udc.extend.autocode.transport.handler.CtpEnumSaveAsHandler`

```java
    void saveAs(com.seeyon.udc.common.schema.TransportData);
    void normalSaveAs(com.seeyon.udc.common.schema.TransportData);
    void execute(com.seeyon.udc.common.dto.ApplicationDto);
    void execute(java.lang.Object);
```

### `CtpQrCodeRuleSaveAsHandler`（7 方法）

`com.seeyon.udc.extend.autocode.transport.handler.CtpQrCodeRuleSaveAsHandler`

```java
    void before(com.seeyon.udc.common.schema.TransportData);
    void saveAs(com.seeyon.udc.common.schema.TransportData)
    void normalSaveAs(com.seeyon.udc.common.schema.TransportData)
    void execute(com.seeyon.udc.common.dto.ApplicationDto);
    void execute(java.lang.Object);
```

### `UdcFormConvertService`（7 方法）

`com.seeyon.udc.extend.domain.service.UdcFormConvertService`

```java
    java.util.List<com.seeyon.boot.starter.formconvert.dto.FormConvertTemplateDto> selectFormConvertTemplate(com.seeyon.udc.common.dto.UdcFormConvertSearchDto);
    java.util.List<com.seeyon.boot.starter.formconvert.dto.FormConvertCategoryDto> selectFormConvertCategory(com.seeyon.udc.common.dto.UdcFormConvertSearchDto);
    void copyBatchForAppApproval(com.seeyon.udc.common.schema.TransportData);
```

### `UdcCtpQrcodeRuleService`（6 方法）

`com.seeyon.udc.extend.domain.service.UdcCtpQrcodeRuleService`

```java
    java.util.List<com.seeyon.boot.starter.qrcode.dto.CtpQrCodeRuleDto> selectCtpQrcodeRule(com.seeyon.udc.extend.domain.dto.UdcCtpQrcodeRuleSearchDto);
    java.util.List<com.seeyon.boot.starter.qrcode.dto.CtpQrCodeRuleDto> getDesignQrCodeRuleListByAppGuid(java.lang.Long, java.lang.Long, java.lang.String);
    private boolean nonNull(java.lang.Object);
    java.lang.Integer updateQrCodeReleaseState(java.lang.Long, java.lang.String);
    java.lang.Integer deleteByAppGuids(java.util.List<java.lang.Long>);
```

### `UdcSerialSchemeAppServiceImpl`（5 方法）

`com.seeyon.udc.extend.appservice.UdcSerialSchemeAppServiceImpl`

```java
    com.seeyon.boot.transport.ListResponse<com.seeyon.boot.starter.serialnumber.domain.dto.SerialSchemeDto> selectSerialScheme(com.seeyon.boot.transport.SingleRequest<com.seeyon.udc.common.dto.UdcSerialSchemeSearchDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.boot.starter.serialnumber.domain.dto.SerialSchemeDto> selectSerialSchemeById(com.seeyon.boot.transport.SingleRequest<com.seeyon.udc.common.dto.UdcSerialSchemeSearchDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.boot.starter.serialnumber.domain.dto.SerialRangeDto> selectSerialRange(com.seeyon.boot.transport.SingleRequest<com.seeyon.udc.common.dto.UdcSerialRangeSearchDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Long> createEasyScheme(com.seeyon.boot.transport.SingleRequest<com.seeyon.udc.common.dto.UdcSerialSchemeCreateDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.boot.starter.serialnumber.domain.dto.SerialSchemeDto> selectDepAppSerialScheme(com.seeyon.boot.transport.SingleRequest<java.util.List<com.seeyon.udc.common.dto.DependentApplicationDto>>);
```

### `CtpExcelExportSaveAsHandler`（5 方法）

`com.seeyon.udc.extend.autocode.transport.handler.CtpExcelExportSaveAsHandler`

```java
    void saveAs(com.seeyon.udc.common.schema.TransportData);
    void normalSaveAs(com.seeyon.udc.common.schema.TransportData)
    void execute(com.seeyon.udc.common.dto.ApplicationDto);
    void execute(java.lang.Object);
```

### `CtpSerialNumberSaveAsHandler`（5 方法）

`com.seeyon.udc.extend.autocode.transport.handler.CtpSerialNumberSaveAsHandler`

```java
    void saveAs(com.seeyon.udc.common.schema.TransportData);
    void normalSaveAs(com.seeyon.udc.common.schema.TransportData)
    void execute(com.seeyon.udc.common.dto.ApplicationDto);
    void execute(java.lang.Object);
```

### `CtpEnumTransportHandler`（5 方法）

`com.seeyon.udc.extend.autocode.transport.out.CtpEnumTransportHandler`

```java
    java.util.List<com.seeyon.udc.common.transport.SchemaInfo> out(com.seeyon.udc.common.autocode.context.CodeContext);
    private java.lang.Long subTenantId(java.lang.Long);
    com.seeyon.udc.common.autocode.transport.compare.ComparisonResponse compare(com.seeyon.udc.common.autocode.transport.SchemaComparisonSourcePool);
```

### `SerialNumberTransportHandler`（5 方法）

`com.seeyon.udc.extend.autocode.transport.out.SerialNumberTransportHandler`

```java
    java.util.List<com.seeyon.udc.common.transport.SchemaInfo> out(com.seeyon.udc.common.autocode.context.CodeContext)
    private java.util.List<com.seeyon.boot.starter.serialnumber.domain.dto.SerialSchemeDto> querySerialScheme(com.seeyon.udc.common.dto.ApplicationDto);
    private java.util.List<com.seeyon.boot.starter.serialnumber.domain.dto.SerialRangeDto> querySerialRange(com.seeyon.udc.common.dto.ApplicationDto, java.util.List<java.lang.Long>);
```

### `CtpFormConvertSaveAsHandler`（4 方法）

`com.seeyon.udc.extend.autocode.transport.handler.CtpFormConvertSaveAsHandler`

```java
    void saveAs(com.seeyon.udc.common.schema.TransportData);
    void normalSaveAs(com.seeyon.udc.common.schema.TransportData)
    void execute(com.seeyon.udc.common.dto.ApplicationDto);
    void execute(java.lang.Object);
```
