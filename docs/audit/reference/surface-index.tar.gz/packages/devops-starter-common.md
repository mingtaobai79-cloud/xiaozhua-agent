# devops-starter-common：接口与方法签名

> 自动生成，勿手改。`tools/core/platform/emit_package_surfaces.py` 重跑即可。
> 构件 `com.seeyon:devops-starter-common`（jar `devops-starter-common-5.3.600.jar`）
> 规模：51 类 / 6 接口 / 0 注解 / 6 枚举 / 17 个关键类 / 338 方法。
> 签名逐字来自 javap 原文；已去掉 `public` 前缀与 `throws` 子句。

## 一、接口（6）

### `ICompressResult`（2 方法）

`com.seeyon.devops.common.compress.ICompressResult`

```java
    com.seeyon.devops.common.compress.IFileInfo fileInfo();
    java.lang.Exception compressError();
```

### `IFileInfo`（2 方法）

`com.seeyon.devops.common.compress.IFileInfo`

```java
    java.lang.String path();
    boolean directory();
```

### `ICompressHandler`（1 方法）

`com.seeyon.devops.common.compress.ICompressHandler`

```java
    com.seeyon.devops.common.compress.ICompressResult handle(com.seeyon.devops.common.compress.CompressContext);
```

### `IUncompressHandler`（1 方法）

`com.seeyon.devops.common.compress.IUncompressHandler`

```java
    com.seeyon.devops.common.compress.IUncompressResult handle(com.seeyon.devops.common.compress.CompressContext);
```

### `IUncompressResult`（1 方法）

`com.seeyon.devops.common.compress.IUncompressResult`

```java
    java.util.List<com.seeyon.devops.common.compress.IFileInfo> fileInfos();
```

### `Const`（0 方法）

`com.seeyon.devops.common.constant.Const`

```java
```

## 二、关键类（17）

### `MavenUtil`（51 方法）

`com.seeyon.devops.common.util.MavenUtil`

```java
    static org.eclipse.aether.RepositorySystem getRepositorySystem();
    static org.eclipse.aether.RepositorySystemSession getSession(org.eclipse.aether.RepositorySystem, java.lang.String);
    static java.lang.String key(org.eclipse.aether.artifact.Artifact);
    static java.lang.String key(java.lang.String, java.lang.String, java.lang.String);
    static org.eclipse.aether.artifact.Artifact getArtifactFormJar(java.lang.String);
    static org.eclipse.aether.artifact.Artifact getBuildInfoFromStream(java.io.InputStream);
    static org.apache.maven.model.Model parsePom(java.io.InputStream)
    static org.apache.maven.model.Model parsePom(java.io.File)
    static void writePom(java.io.File, org.apache.maven.model.Model)
    static void writePom(java.io.OutputStream, org.apache.maven.model.Model)
    static boolean updateArtifact(java.io.File, java.util.function.Function<java.lang.String, java.lang.String>);
    static boolean updateParentVersion(java.io.File, java.lang.String);
    static boolean addDependency(java.io.File, java.util.List<org.apache.maven.model.Dependency>);
    static void deleteDependency(java.io.File, java.util.List<java.lang.String>);
    static boolean deletePlugin(java.io.File, java.util.List<java.lang.String>);
    static boolean deletePlugin(java.io.File, java.util.List<java.lang.String>, java.util.function.Consumer<org.apache.maven.model.Model>);
    static boolean addPlugin(java.io.File, java.util.List<org.apache.maven.model.Plugin>);
    static boolean addPlugin(java.io.File, java.util.List<org.apache.maven.model.Plugin>, java.util.function.Consumer<org.apache.maven.model.Model>);
    static boolean addRepository(java.io.File, java.util.List<org.apache.maven.model.Repository>);
    static boolean addRepository(java.io.File, java.util.List<org.apache.maven.model.Repository>, java.util.function.Consumer<org.apache.maven.model.Model>);
    static java.util.List<org.apache.maven.model.Dependency> getDependencies(java.io.File);
    static java.util.List<org.apache.maven.model.Dependency> getDependencies(java.io.File, java.util.function.Predicate<org.apache.maven.model.Dependency>);
    static java.util.List<org.apache.maven.model.Plugin> getPlugins(java.io.File);
    static java.lang.String getMavenPath(java.lang.String);
    static org.apache.maven.shared.invoker.InvocationResult runMaven(java.lang.String, java.io.File, java.lang.String[])
    static void deployToRepo(java.lang.String, java.lang.String, org.eclipse.aether.artifact.Artifact)
    static void deployToRepo(java.lang.String, java.lang.String, java.lang.String, org.eclipse.aether.artifact.Artifact)
    static void install2Local(java.lang.String, java.lang.String, java.lang.String, org.eclipse.aether.artifact.Artifact)
    static void getLatestJarToLocal(java.lang.String, java.lang.String, org.eclipse.aether.artifact.Artifact);
    static void copyJarToTarget(java.lang.String, java.lang.String, java.lang.String, org.eclipse.aether.artifact.Artifact);
    static java.lang.String downloadFromRepo(java.lang.String, java.lang.String, org.eclipse.aether.artifact.Artifact)
    static java.lang.String downloadFromRepo(java.lang.String, java.lang.String, java.lang.String, org.eclipse.aether.artifact.Artifact)
    static com.seeyon.devops.common.resolver.ResolverResult resolveDependencies(java.lang.String, java.lang.String, org.eclipse.aether.artifact.Artifact)
    static com.seeyon.devops.common.resolver.ResolverResult resolveDependencies(java.lang.String, java.lang.String, java.lang.String, org.eclipse.aether.artifact.Artifact)
    static org.eclipse.aether.resolution.ArtifactResult resolveArtifact(java.lang.String, java.lang.String, org.eclipse.aether.artifact.Artifact)
    static org.eclipse.aether.resolution.ArtifactResult resolveArtifact(java.lang.String, java.lang.String, java.lang.String, org.eclipse.aether.artifact.Artifact)
    static void cleanFile(java.lang.String);
    static org.eclipse.aether.resolution.VersionRangeResult resolveVersionRange(java.lang.String, java.lang.String, org.eclipse.aether.artifact.Artifact)
    static org.eclipse.aether.resolution.VersionRangeResult resolveVersionRange(java.lang.String, java.lang.String, java.lang.String, org.eclipse.aether.artifact.Artifact)
    static org.eclipse.aether.resolution.VersionResult resolveVersion(java.lang.String, java.lang.String, org.eclipse.aether.artifact.Artifact)
    static org.eclipse.aether.resolution.VersionResult resolveVersion(java.lang.String, java.lang.String, java.lang.String, org.eclipse.aether.artifact.Artifact)
    static java.lang.String getJarVersion(java.lang.String);
```

### `EnvUtils`（23 方法）

`com.seeyon.devops.common.util.EnvUtils`

```java
    static java.io.File getUserHome();
    static java.lang.String getMavenHome();
    static private static java.lang.String locateMaven();
    static org.apache.maven.settings.Settings getSettings(java.lang.String)
    static org.apache.maven.settings.Settings getSettings(java.lang.String, java.lang.String)
    static java.io.File getSettingsXml(java.lang.String);
    static java.util.Map<com.seeyon.devops.common.enums.VersionTypeEnum, org.eclipse.aether.repository.RemoteRepository> getRemoteRepositoryMap(java.lang.String);
    static java.util.Map<com.seeyon.devops.common.enums.VersionTypeEnum, org.eclipse.aether.repository.RemoteRepository> getRemoteRepositoryMap(java.lang.String, java.lang.String);
    static java.util.List<org.eclipse.aether.repository.RemoteRepository> getAllRemoteRepository(java.lang.String, java.lang.String);
    static java.util.Map<java.lang.String, org.apache.maven.settings.Server> getServers(java.lang.String);
    static java.util.List<org.eclipse.aether.repository.RemoteRepository> getRemoteRepository(java.lang.String);
    static java.util.List<org.eclipse.aether.repository.RemoteRepository> getRemoteRepository(java.lang.String, java.lang.String);
    static org.apache.maven.settings.Server getSecureAccount(java.lang.String);
    static java.util.Properties parseArguments(java.lang.String[]);
```

### `ShellExecUtil`（20 方法）

`com.seeyon.devops.common.util.ShellExecUtil`

```java
    static int executeCommand(java.lang.String, org.apache.commons.exec.CommandLine);
    static int executeCommand(java.lang.String, org.apache.commons.exec.CommandLine, org.apache.commons.exec.ProcessDestroyer);
    static int executeCommand(java.lang.String, org.apache.commons.exec.CommandLine, java.io.OutputStream);
    static int executeCommand(java.lang.String, org.apache.commons.exec.CommandLine, java.io.OutputStream, org.apache.commons.exec.ProcessDestroyer);
    static int executeCommand(java.lang.String, org.apache.commons.exec.CommandLine, java.io.OutputStream, java.lang.Long, org.apache.commons.exec.ProcessDestroyer);
    static org.apache.commons.exec.ExecuteResultHandler executeCommandAsync(java.lang.String, org.apache.commons.exec.CommandLine);
    static org.apache.commons.exec.ExecuteResultHandler executeCommandAsync(java.lang.String, org.apache.commons.exec.CommandLine, org.apache.commons.exec.ProcessDestroyer);
    static org.apache.commons.exec.ExecuteResultHandler executeCommandAsync(java.lang.String, org.apache.commons.exec.CommandLine, java.io.OutputStream, java.lang.Long, org.apache.commons.exec.ProcessDestroyer);
    static int executeCommandWithTimeout(java.lang.String, org.apache.commons.exec.CommandLine, java.io.OutputStream, java.lang.Long);
    static org.apache.commons.exec.ExecuteResultHandler executeCommandAsyncWithTimeout(java.lang.String, org.apache.commons.exec.CommandLine, java.io.OutputStream, java.lang.Long);
    static int execShell(java.lang.String);
    static int execShell(java.lang.String, cn.hutool.core.io.LineHandler);
    static int execShell(java.lang.String, org.apache.commons.exec.ProcessDestroyer);
    static int execShell(java.lang.String, cn.hutool.core.io.LineHandler, org.apache.commons.exec.ProcessDestroyer);
    static int execShell(java.io.File, java.lang.String, cn.hutool.core.io.LineHandler, org.apache.commons.exec.ProcessDestroyer);
    static private static java.lang.String[] handleCmds(java.lang.String...);
    static private static java.lang.String[] cmdSplit(java.lang.String);
    static org.apache.commons.exec.CommandLine getBaseCommandLine(java.lang.String);
    static java.lang.String convertToShell(org.apache.commons.exec.CommandLine);
```

### `PathUtils`（12 方法）

`com.seeyon.devops.common.util.PathUtils`

```java
    static java.lang.String getBasePath();
    static java.lang.String getRelativePath(java.nio.file.Path, java.nio.file.Path);
    static java.nio.file.Path getPublicParentPath(java.util.List<java.nio.file.Path>);
    static private static java.lang.String getMaxLength(java.util.List<java.lang.String>);
    static java.util.List<java.nio.file.Path> getParentPaths(java.nio.file.Path);
    static java.nio.file.Path getParentPath(java.nio.file.Path);
    static java.util.List<java.lang.String> retainAll(java.util.List<java.util.List<java.lang.String>>);
    static java.util.List<java.nio.file.Path> getPathList(java.nio.file.Path);
    static java.util.List<java.nio.file.Path> getPathList(java.lang.String, java.lang.String);
    static java.lang.String getPath();
    static java.lang.String getRootPath();
```

### `TomcatLibUtil`（12 方法）

`com.seeyon.devops.common.util.TomcatLibUtil`

```java
    static org.eclipse.aether.artifact.Artifact getAssembleJar(java.lang.String);
    static java.util.List<org.eclipse.aether.artifact.Artifact> getAllJarFromLibs(java.lang.String);
    static java.util.List<org.eclipse.aether.artifact.Artifact> parseJar(java.io.File);
    static java.util.List<org.eclipse.aether.artifact.Artifact> parseSeeyonJarFromLibs(java.lang.String, java.util.List<java.lang.String>);
    static void syncTomcatJarToTarget(java.lang.String)
    static void syncArtifactToTarget(java.util.List<org.eclipse.aether.artifact.Artifact>, java.lang.String)
    static void syncJar2Target(java.util.List<java.lang.String>, java.lang.String)
```

### `AbstractArchiveHandler`（9 方法）

`com.seeyon.devops.common.compress.archive.AbstractArchiveHandler`

```java
    protected abstract org.apache.commons.compress.archivers.ArchiveOutputStream getArchiveOutputStream(java.io.File, java.lang.String);
    protected abstract org.apache.commons.compress.archivers.ArchiveEntry getArchiveEntry(org.apache.commons.compress.archivers.ArchiveOutputStream, java.io.File, java.lang.String);
    com.seeyon.devops.common.compress.ICompressResult handle(com.seeyon.devops.common.compress.CompressContext);
    protected com.seeyon.devops.common.compress.ICompressResult doHandle(com.seeyon.devops.common.compress.CompressContext);
    private java.util.List<java.nio.file.Path> buildAllPaths(java.util.List<java.nio.file.Path>);
    private java.lang.String getEntryName(java.nio.file.Path, java.io.File, com.seeyon.devops.common.compress.CompressContext);
```

### `CompressHelper`（6 方法）

`com.seeyon.devops.common.util.CompressHelper`

```java
    static com.seeyon.devops.common.compress.ICompressResult compress(java.lang.String);
    static com.seeyon.devops.common.compress.ICompressResult compress(java.lang.String, java.lang.String);
    static com.seeyon.devops.common.compress.ICompressResult compress(com.seeyon.devops.common.compress.enums.CompressTypeEnum, java.lang.String, java.lang.String);
    static com.seeyon.devops.common.compress.IUncompressResult uncompress(java.lang.String);
    static com.seeyon.devops.common.compress.IUncompressResult uncompress(java.lang.String, java.lang.String);
    static com.seeyon.devops.common.compress.IUncompressResult uncompress(com.seeyon.devops.common.compress.enums.CompressTypeEnum, java.lang.String, java.lang.String);
```

### `AbstractUnArchiveHandler`（5 方法）

`com.seeyon.devops.common.compress.archive.AbstractUnArchiveHandler`

```java
    protected abstract org.apache.commons.compress.archivers.ArchiveInputStream getArchiveInputStream(java.io.InputStream, java.lang.String);
    protected int getEntrySize(org.apache.commons.compress.archivers.ArchiveEntry);
    com.seeyon.devops.common.compress.IUncompressResult handle(com.seeyon.devops.common.compress.CompressContext);
    protected com.seeyon.devops.common.compress.IUncompressResult doHandler(com.seeyon.devops.common.compress.CompressContext);
    private java.lang.String buildFilePath(java.io.File, org.apache.commons.compress.archivers.ArchiveEntry);
```

### `OutSourceService`（5 方法）

`com.seeyon.devops.common.dependencies.OutSourceService`

```java
    static void pullMavenDependency(java.io.File, java.lang.String);
    static void pullMavenDependency(java.lang.String, java.io.File, java.lang.String);
    static void goOfflineMavenDependency(java.lang.String, java.io.File, java.lang.String);
    static void pullFromJars2local(java.lang.String, java.lang.String, java.lang.String, java.lang.String);
```

### `LockUtils`（4 方法）

`com.seeyon.devops.common.util.LockUtils`

```java
    static void lock(java.lang.String);
    static void unlock(java.lang.String);
    static boolean isLocked(java.lang.String);
    static int getQueueLength(java.lang.String);
```

### `UnZipUtils`（4 方法）

`com.seeyon.devops.common.util.UnZipUtils`

```java
    static java.io.File unZipToDir(java.io.InputStream, java.lang.String, java.lang.String);
    static java.io.File unzip(java.util.zip.ZipInputStream, java.io.File)
    static void read(java.util.zip.ZipInputStream, java.util.function.Consumer<java.util.zip.ZipEntry>);
```

### `GzipArchiveHandler`（3 方法）

`com.seeyon.devops.common.compress.archive.GzipArchiveHandler`

```java
    protected org.apache.commons.compress.archivers.ArchiveOutputStream getArchiveOutputStream(java.io.File, java.lang.String);
    protected org.apache.commons.compress.archivers.ArchiveEntry getArchiveEntry(org.apache.commons.compress.archivers.ArchiveOutputStream, java.io.File, java.lang.String);
    com.seeyon.devops.common.compress.ICompressResult handle(com.seeyon.devops.common.compress.CompressContext);
```

### `JarArchiveHandler`（3 方法）

`com.seeyon.devops.common.compress.archive.JarArchiveHandler`

```java
    protected org.apache.commons.compress.archivers.ArchiveOutputStream getArchiveOutputStream(java.io.File, java.lang.String);
    protected org.apache.commons.compress.archivers.ArchiveEntry getArchiveEntry(org.apache.commons.compress.archivers.ArchiveOutputStream, java.io.File, java.lang.String);
    com.seeyon.devops.common.compress.ICompressResult handle(com.seeyon.devops.common.compress.CompressContext);
```

### `ServenZArchiveHandler`（3 方法）

`com.seeyon.devops.common.compress.archive.ServenZArchiveHandler`

```java
    protected org.apache.commons.compress.archivers.ArchiveOutputStream getArchiveOutputStream(java.io.File, java.lang.String);
    protected org.apache.commons.compress.archivers.ArchiveEntry getArchiveEntry(org.apache.commons.compress.archivers.ArchiveOutputStream, java.io.File, java.lang.String);
    com.seeyon.devops.common.compress.ICompressResult handle(com.seeyon.devops.common.compress.CompressContext);
```

### `TarArchiveHandler`（3 方法）

`com.seeyon.devops.common.compress.archive.TarArchiveHandler`

```java
    protected org.apache.commons.compress.archivers.ArchiveOutputStream getArchiveOutputStream(java.io.File, java.lang.String);
    protected org.apache.commons.compress.archivers.ArchiveEntry getArchiveEntry(org.apache.commons.compress.archivers.ArchiveOutputStream, java.io.File, java.lang.String);
    com.seeyon.devops.common.compress.ICompressResult handle(com.seeyon.devops.common.compress.CompressContext);
```

### `ZipArchiveHandler`（3 方法）

`com.seeyon.devops.common.compress.archive.ZipArchiveHandler`

```java
    protected org.apache.commons.compress.archivers.ArchiveOutputStream getArchiveOutputStream(java.io.File, java.lang.String);
    protected org.apache.commons.compress.archivers.ArchiveEntry getArchiveEntry(org.apache.commons.compress.archivers.ArchiveOutputStream, java.io.File, java.lang.String);
    com.seeyon.devops.common.compress.ICompressResult handle(com.seeyon.devops.common.compress.CompressContext);
```

### `ZipUnArchiveHandler`（3 方法）

`com.seeyon.devops.common.compress.archive.ZipUnArchiveHandler`

```java
    protected org.apache.commons.compress.archivers.ArchiveInputStream getArchiveInputStream(java.io.InputStream, java.lang.String);
    protected int getEntrySize(org.apache.commons.compress.archivers.ArchiveEntry);
    com.seeyon.devops.common.compress.IUncompressResult handle(com.seeyon.devops.common.compress.CompressContext);
```

## 四、枚举（6）

- `CompressTypeEnum`（5 常量）：JAR, SEVENZ, ZIP, TAR, TGZ
- `AppTypeEnum`（3 常量）：NORMAL, FORM, CUSTOMIZED
- `BuildTypeEnum`（2 常量）：ALL, DELTA
- `ProjectTypeEnum`（3 常量）：FRONTEND, BACKEND, ALL
- `ServiceTypeEnum`（4 常量）：MONOLITHIC, MICROSERVICE, SANDBOX_BUILD_SERVICE, SANDBOX_PACKIMAGE_SERVICE
- `VersionTypeEnum`（2 常量）：RELEASE, SNAPSHOT
