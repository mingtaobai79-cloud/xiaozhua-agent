# boot-starter-condition：接口与方法签名

> 自动生成，勿手改。`tools/core/platform/emit_package_surfaces.py` 重跑即可。
> 构件 `com.seeyon:boot-starter-condition`（jar `boot-starter-condition-5.3.603.jar`）
> 规模：77 类 / 4 接口 / 0 注解 / 4 枚举 / 15 个关键类 / 396 方法。
> 签名逐字来自 javap 原文；已去掉 `public` 前缀与 `throws` 子句。

## 一、接口（4）

### `ValueConvert`（2 方法）

`com.seeyon.boot.starter.condition.convertor.datatype.ValueConvert`

```java
    com.seeyon.boot.enums.DataType getTargetDataType();
    java.lang.Object convert(java.lang.String);
```

### `MapOperatorParse`（2 方法）

`com.seeyon.boot.starter.condition.output.map.MapOperatorParse`

```java
    com.seeyon.boot.starter.condition.enums.OperatorEnum getOperator();
    boolean parseOperator(com.seeyon.boot.starter.condition.dto.SingleConditionDto, java.util.Map<java.lang.String, java.lang.Object>, java.util.List<cn.hutool.core.lang.Pair<java.lang.Boolean, java.lang.Object>>, com.seeyon.boot.starter.condition.dto.MapConditionParseConfigurationBo);
```

### `RightParamParser`（2 方法） extends Ordered

`com.seeyon.boot.starter.condition.output.parse.RightParamParser`

```java
    java.lang.String getType();
    java.lang.Object parseValue(com.seeyon.boot.starter.condition.dto.SingleConditionDto$LeftParamDto, com.seeyon.boot.starter.condition.dto.SingleConditionDto$RightParamDto, java.util.Map<java.lang.String, java.lang.Object>);
```

### `ConditionConfigOutput`（1 方法）

`com.seeyon.boot.starter.condition.output.ConditionConfigOutput`

```java
    T getContent(com.seeyon.boot.starter.condition.dto.ConditionOutputParam);
```

## 二、关键类（15）

### `DynamicConditionUtilV2`（34 方法）

`com.seeyon.boot.starter.condition.utils.DynamicConditionUtilV2`

```java
    static java.util.Map<java.lang.String, java.lang.Object> buildDynamicSqlCondMap(com.seeyon.boot.starter.condition.dto.Condition2DynamicSqlCondMapDto);
    static private static java.util.Map<java.lang.String, java.lang.Object> buildSingleConditionMap(com.seeyon.boot.starter.condition.dto.ConditionInfoDto, com.seeyon.boot.starter.condition.dto.Condition2DynamicSqlCondMapDto);
    static private static java.lang.String getDefaultConditionLeftKey(com.seeyon.boot.starter.condition.dto.ConditionInfoDto, com.seeyon.boot.starter.condition.dto.Condition2DynamicSqlCondMapDto);
    static private static java.lang.String getConditionLeftKeyByOperator(com.seeyon.boot.starter.condition.dto.ConditionInfoDto, com.seeyon.boot.starter.condition.enums.OperatorEnum, com.seeyon.boot.starter.condition.dto.Condition2DynamicSqlCondMapDto);
    static private static boolean hasRightEntityField(com.seeyon.boot.starter.condition.dto.ConditionInfoDto);
    static private static java.util.Map<java.lang.String, java.lang.Object> buildEqOrNeqConditionMap(com.seeyon.boot.starter.condition.dto.ConditionInfoDto, java.lang.String, java.util.List<java.lang.Object>);
    static private static java.util.Map<java.lang.String, java.lang.Object> buildInOrNotInConditionMap(com.seeyon.boot.starter.condition.dto.ConditionInfoDto, java.lang.String, java.util.List<java.lang.Object>);
    static private static java.util.Map<java.lang.String, java.lang.Object> buildLikeOrNotLikeConditionMap(com.seeyon.boot.starter.condition.dto.ConditionInfoDto, java.lang.String, java.util.List<java.lang.Object>, com.seeyon.boot.starter.condition.dto.Condition2DynamicSqlCondMapDto);
    static private static java.util.Map<java.lang.String, java.lang.Object> buildBetweenOrNotConditionMap(com.seeyon.boot.starter.condition.dto.ConditionInfoDto, java.util.List<java.lang.Object>, com.seeyon.boot.starter.condition.dto.Condition2DynamicSqlCondMapDto);
    static private static java.util.Map<java.lang.String, java.lang.Object> buildIncludeOrNotIncludeConditionMap(com.seeyon.boot.starter.condition.dto.ConditionInfoDto, com.seeyon.boot.starter.condition.enums.OperatorEnum, java.util.List<java.lang.Object>, com.seeyon.boot.starter.condition.dto.Condition2DynamicSqlCondMapDto);
    static private static java.util.Map<java.lang.String, java.lang.Object> buildCompareConditionMap(com.seeyon.boot.starter.condition.dto.ConditionInfoDto, com.seeyon.boot.starter.condition.enums.OperatorEnum, com.seeyon.boot.starter.condition.dto.Condition2DynamicSqlCondMapDto, java.lang.String, java.util.List<java.lang.Object>);
    static private static java.util.Map<java.lang.String, java.lang.Object> buildNormalConditionMap(com.seeyon.boot.starter.condition.dto.ConditionInfoDto, com.seeyon.boot.starter.condition.enums.OperatorEnum, com.seeyon.boot.starter.condition.dto.Condition2DynamicSqlCondMapDto, java.lang.String, java.util.List<java.lang.Object>);
    static private static void buildCondMap(java.lang.Object, java.util.Map<java.lang.String, java.lang.Object>, java.lang.String, java.lang.String, com.seeyon.boot.starter.condition.enums.OperatorEnum, com.seeyon.boot.starter.condition.dto.BaseConditionDto$LogicalOperator);
    static private static java.util.Map<java.lang.String, java.lang.Object> buildNullOrNotNullConditionMap(com.seeyon.boot.starter.condition.dto.ConditionInfoDto, java.lang.String, com.seeyon.boot.starter.condition.dto.Condition2DynamicSqlCondMapDto);
    static private static java.util.Map<java.lang.String, java.lang.Object> buildZeroOrNotZeroConditionMap(com.seeyon.boot.starter.condition.dto.ConditionInfoDto, java.lang.String);
    static private static java.util.Map<java.lang.String, java.lang.Object> buildInvalidCondition(com.seeyon.boot.starter.condition.dto.ConditionInfoDto, com.seeyon.boot.starter.condition.dto.Condition2DynamicSqlCondMapDto);
    static private static java.lang.Object getInvalidConditionDefaultRightValue(com.seeyon.boot.starter.condition.dto.SingleConditionDto$LeftParamDto, java.lang.String);
    static private static boolean ignoreConditionIfNullRightValue(com.seeyon.boot.starter.condition.dto.ConditionInfoDto, java.util.List<java.lang.Object>);
    static private static java.lang.Object getDefaultValueIfNullRightValue(com.seeyon.boot.starter.condition.dto.ConditionInfoDto, java.lang.Object);
    static private static com.seeyon.boot.starter.condition.dto.BaseConditionDto$LogicalOperator findLogicalOperator(java.util.List<com.seeyon.boot.starter.condition.dto.ConditionInfoDto>);
    static private static java.util.List<java.lang.Object> getRightValues(com.seeyon.boot.starter.condition.dto.ConditionInfoDto, com.seeyon.boot.starter.condition.dto.Condition2DynamicSqlCondMapDto);
    static private static java.lang.String toCamelCase(java.lang.String);
    static private static java.lang.String addUnderLinePrefix(java.lang.String);
    static private static java.lang.String getLeftEntityOrDtoName(com.seeyon.boot.starter.condition.dto.SingleConditionDto$LeftParamDto, com.seeyon.boot.starter.condition.dto.Condition2DynamicSqlCondMapDto);
    static private static java.lang.String getEntitySimpleNameByDtoSimpleName(java.lang.String);
    static private static boolean useEnumCodeAsRightValue(boolean, com.seeyon.boot.starter.condition.dto.SingleConditionDto$LeftParamDto, com.seeyon.boot.starter.condition.dto.SingleConditionDto$RightParamDto);
    static private static boolean isNullOrIllegalOrFrontExpressionValue(java.lang.Object);
    static private static java.lang.Integer getBooleanByRightValue(java.lang.String);
    static private static boolean checkHasExpressionParam(com.seeyon.boot.starter.condition.dto.ConditionInfoDto);
    static private static boolean isInvalidConditionIfAnyRightNullValue(com.seeyon.boot.starter.condition.dto.ConditionInfoDto, java.util.List<java.lang.Object>);
```

### `ConditionService`（26 方法）

`com.seeyon.boot.starter.condition.domain.service.ConditionService`

```java
    java.util.List<com.seeyon.boot.starter.condition.operator.ConditionOperator> getAllOperator();
    java.lang.String transfer(java.util.List<com.seeyon.boot.starter.condition.dto.ConditionInfoDto>);
    private void transferCondition(com.seeyon.boot.starter.condition.dto.BaseConditionDto$LogicalOperator, java.util.List<com.seeyon.boot.starter.condition.dto.BaseConditionDto>, java.lang.StringBuilder);
    boolean check(java.util.List<com.seeyon.boot.starter.condition.dto.ConditionInfoDto>);
    private void checkDetail(java.util.List<com.seeyon.boot.starter.condition.dto.BaseConditionDto>);
    private void checkInGroupConditions(java.util.List<com.seeyon.boot.starter.condition.dto.BaseConditionDto>);
    private void checkConditionLegal(com.seeyon.boot.starter.condition.dto.SingleConditionDto);
    private void checkNull(java.lang.Object, java.lang.String, com.seeyon.boot.starter.condition.dto.SingleConditionDto);
    java.util.List<com.seeyon.boot.starter.condition.params.ConditionParamResult> selectVariableParam(java.util.List<com.seeyon.boot.starter.condition.dto.ConditionInfoDto>);
    private void addVariableParam(java.util.List<com.seeyon.boot.starter.condition.dto.BaseConditionDto>, java.util.List<com.seeyon.boot.starter.condition.params.ConditionParamResult>);
    boolean isSingleCondition(java.util.List<com.seeyon.boot.starter.condition.dto.ConditionInfoDto>);
    private boolean checkSingleCondition(java.util.List<com.seeyon.boot.starter.condition.dto.BaseConditionDto>);
    java.util.Set<java.lang.String> selectEntityNames(java.util.List<com.seeyon.boot.starter.condition.dto.ConditionInfoDto>);
    private void addEntityName(java.util.List<com.seeyon.boot.starter.condition.dto.BaseConditionDto>, java.util.Set<java.lang.String>);
    java.util.List<com.seeyon.boot.starter.condition.dto.SingleConditionDto> selectSingleCondition(java.util.List<com.seeyon.boot.starter.condition.dto.ConditionInfoDto>);
    private void addSingleCondition(java.util.List<com.seeyon.boot.starter.condition.dto.BaseConditionDto>, java.util.List<com.seeyon.boot.starter.condition.dto.SingleConditionDto>);
```

### `ConditionConfigOutputUtil`（19 方法）

`com.seeyon.boot.starter.condition.output.ConditionConfigOutputUtil`

```java
    static com.seeyon.boot.domain.dao.Wrapper getWrapperContent(java.lang.String, com.seeyon.boot.domain.dao.Wrapper, java.util.Map<java.lang.String, java.lang.Object>);
    static java.lang.String getDynamicContent(java.lang.String);
    static java.lang.String getDynamicContentByExpression(java.lang.String, java.util.Map<java.lang.String, java.util.List<java.util.Map<java.lang.String, java.lang.Object>>>);
    static java.lang.String getDynamicContentByExpression(java.lang.String, java.util.Map<java.lang.String, java.util.List<java.util.Map<java.lang.String, java.lang.Object>>>, boolean);
    static java.lang.String getDynamicContentByExpression(java.util.List<com.seeyon.boot.starter.condition.dto.ConditionInfoDto>, java.util.Map<java.lang.String, java.util.List<java.util.Map<java.lang.String, java.lang.Object>>>, boolean);
    static java.lang.String getDynamicContentByConfig(java.lang.String, com.seeyon.boot.starter.condition.dto.DynamicContentConfigDto);
    static java.util.Map<java.lang.String, java.lang.Object> getParamsMapContent(java.lang.String, java.util.Map<java.lang.String, java.lang.Object>, boolean);
    static java.util.Map<java.lang.String, java.lang.Object> getParamsMapContent(com.seeyon.boot.starter.condition.dto.ParamMapBo);
    static com.seeyon.boot.starter.condition.output.map.MapConditionResult getMapConditionResult(com.seeyon.boot.starter.condition.dto.ParamMapBo);
    static java.util.Map<java.lang.String, java.lang.Object> getParamsMapContent(java.lang.String, java.util.Map<java.lang.String, java.lang.Object>);
    static com.seeyon.boot.domain.dao.Wrapper getWrapperContent(java.lang.String, com.seeyon.boot.domain.dao.Wrapper, java.util.List<java.util.Map<java.lang.String, java.lang.Object>>);
    static java.util.List<com.seeyon.boot.starter.condition.params.ConditionParamResult> selectVariableParams(java.lang.String);
    static private static void checkParam(java.lang.String);
    static java.lang.Object getRightValue(com.seeyon.boot.starter.condition.dto.SingleConditionDto$LeftParamDto, com.seeyon.boot.starter.condition.dto.SingleConditionDto$RightParamDto, java.util.Map<java.lang.String, java.lang.Object>);
    static boolean isSingleCondition(java.lang.String);
    static java.util.Set<java.lang.String> selectEntityNames(java.lang.String);
    static java.util.List<com.seeyon.boot.starter.condition.dto.SingleConditionDto> selectSingleCondition(java.lang.String);
    static java.util.List<com.seeyon.boot.starter.condition.dto.SingleConditionDto> selectSingleCondition(java.util.List<com.seeyon.boot.starter.condition.dto.ConditionInfoDto>);
    static java.lang.Boolean checkLegal(java.lang.String);
```

### `DynamicConditionUtil`（12 方法）

`com.seeyon.boot.starter.condition.utils.DynamicConditionUtil`

```java
    static void buildDataRuleSql(java.util.List<com.seeyon.boot.starter.condition.dto.BaseConditionDto>, java.util.Map<java.lang.String, java.lang.Object>, java.util.Map<java.lang.String, java.lang.Object>, java.util.Map<java.lang.String, java.util.List<java.util.Map<java.lang.String, java.lang.Object>>>, boolean, boolean);
    static private static void dealCondition(com.seeyon.boot.starter.condition.dto.SingleConditionDto, java.util.Map<java.lang.String, java.lang.Object>, java.util.Map<java.lang.String, java.lang.Object>, java.util.Map<java.lang.String, java.util.List<java.util.Map<java.lang.String, java.lang.Object>>>, boolean, boolean);
    static private static void buildCondition(com.seeyon.boot.starter.condition.enums.OperatorEnum, com.seeyon.boot.starter.condition.dto.SingleConditionDto$LeftParamDto, java.util.List<com.seeyon.boot.starter.condition.dto.SingleConditionDto$RightParamDto>, java.lang.Object, java.util.Map<java.lang.String, java.lang.Object>, java.util.Map<java.lang.String, java.lang.Object>, java.util.Map<java.lang.Integer, java.lang.Object>, boolean, boolean);
    static private static void setMultiRightValue(com.seeyon.boot.starter.condition.dto.SingleConditionDto$LeftParamDto, java.util.List<com.seeyon.boot.starter.condition.dto.SingleConditionDto$RightParamDto>, java.util.Map<java.lang.String, java.lang.Object>, java.util.Map<java.lang.Integer, java.lang.Object>, java.util.List<java.lang.Object>);
    static private static void buildCondMap(java.lang.Object, java.util.Map<java.lang.String, java.lang.Object>, java.lang.String, java.lang.String, com.seeyon.boot.starter.condition.enums.OperatorEnum, com.seeyon.boot.starter.condition.dto.BaseConditionDto$LogicalOperator);
    static private static java.lang.Integer getBooleanByRightValue(java.lang.String);
    static private static java.lang.String addUnderLinePrefix(java.lang.String);
    static private static java.lang.String toCamelCase(java.lang.String);
    static private static java.lang.String getEntitySimpleNameByDtoSimpleName(java.lang.String);
    static private static boolean useEnumCodeAsRightValue(boolean, com.seeyon.boot.starter.condition.dto.SingleConditionDto$LeftParamDto, com.seeyon.boot.starter.condition.dto.SingleConditionDto$RightParamDto);
    static private static boolean isIgnoreFrontExpressionValue(java.lang.Object);
```

### `MapConditionLeftParamUtil`（9 方法）

`com.seeyon.boot.starter.condition.utils.MapConditionLeftParamUtil`

```java
    static boolean checkMapConditionLeftParam(com.seeyon.boot.starter.condition.dto.SingleConditionDto$LeftParamDto, com.seeyon.boot.starter.condition.dto.SingleConditionDto$ConditionOperatorDto);
    static boolean isNullOperator(com.seeyon.boot.starter.condition.dto.SingleConditionDto$ConditionOperatorDto);
    static org.apache.commons.lang3.tuple.Pair<java.lang.Boolean, java.lang.String> getJavaType(com.seeyon.boot.starter.condition.dto.SingleConditionDto$LeftParamDto);
    static org.apache.commons.lang3.tuple.Pair<java.lang.Boolean, com.seeyon.boot.starter.condition.dto.SingleConditionDto$Type> getType(com.seeyon.boot.starter.condition.dto.SingleConditionDto$LeftParamDto);
    static org.apache.commons.lang3.tuple.Pair<java.lang.Boolean, java.lang.String> getDataType(com.seeyon.boot.starter.condition.dto.SingleConditionDto$LeftParamDto);
    static private static boolean isJavaEnum(com.seeyon.boot.starter.condition.dto.SingleConditionDto$LeftParamDto);
    static private static boolean isDate(com.seeyon.boot.starter.condition.dto.SingleConditionDto$LeftParamDto);
```

### `DynamicContentConfigDto`（8 方法）

`com.seeyon.boot.starter.condition.dto.DynamicContentConfigDto`

```java
    java.util.Map<java.lang.String, java.util.List<java.util.Map<java.lang.String, java.lang.Object>>> getExpressionValues();
    java.util.Map<java.lang.String, java.lang.Object> getContextVariableMap();
    boolean isUseEntitySimpleName();
    boolean isUseEnumCodeRightValue();
    void setExpressionValues(java.util.Map<java.lang.String, java.util.List<java.util.Map<java.lang.String, java.lang.Object>>>);
    void setContextVariableMap(java.util.Map<java.lang.String, java.lang.Object>);
    void setUseEntitySimpleName(boolean);
    void setUseEnumCodeRightValue(boolean);
```

### `ConditionUtil`（7 方法）

`com.seeyon.boot.starter.condition.utils.ConditionUtil`

```java
    static java.util.List<com.seeyon.boot.starter.condition.dto.BaseConditionDto> getBaseConditionDtos(java.util.List<com.seeyon.boot.starter.condition.dto.ConditionInfoDto>);
    static private static java.util.List<com.seeyon.boot.starter.condition.dto.BaseConditionDto> getConditions(java.util.List<com.seeyon.boot.starter.condition.dto.ConditionInfoDto>);
    static java.lang.String translationCondition(java.lang.String);
    static java.lang.String translationCondition(java.util.List<com.seeyon.boot.starter.condition.dto.ConditionInfoDto>);
    static private static void translationCondition(java.util.List<com.seeyon.boot.starter.condition.dto.ConditionInfoDto>, java.lang.StringBuilder);
```

### `WrapperConditionConfigOutput`（6 方法）

`com.seeyon.boot.starter.condition.output.impl.WrapperConditionConfigOutput`

```java
    com.seeyon.boot.domain.dao.Wrapper getContent(com.seeyon.boot.starter.condition.dto.ConditionOutputParam);
    tk.mybatis.mapper.entity.Example$Criteria buildWrapper(java.util.List<com.seeyon.boot.starter.condition.dto.BaseConditionDto>, com.seeyon.boot.domain.dao.Wrapper, java.util.Map<java.lang.String, java.lang.Object>, tk.mybatis.mapper.entity.Example$Criteria);
    private tk.mybatis.mapper.entity.Example$Criteria dealOperator(com.seeyon.boot.domain.dao.Wrapper, com.seeyon.boot.starter.condition.dto.BaseConditionDto$LogicalOperator);
    private void dealCondition(com.seeyon.boot.domain.dao.Wrapper, com.seeyon.boot.starter.condition.dto.SingleConditionDto, java.util.Map<java.lang.String, java.lang.Object>, tk.mybatis.mapper.entity.Example$Criteria);
    private void buildWrapper(tk.mybatis.mapper.entity.Example$Criteria, com.seeyon.boot.starter.condition.enums.OperatorEnum, com.seeyon.boot.starter.condition.dto.SingleConditionDto$LeftParamDto, java.lang.Object, com.seeyon.boot.starter.condition.dto.BaseConditionDto$LogicalOperator, java.util.List<com.seeyon.boot.starter.condition.dto.SingleConditionDto$RightParamDto>, java.util.Map<java.lang.String, java.lang.Object>);
    java.lang.Object getContent(com.seeyon.boot.starter.condition.dto.ConditionOutputParam);
```

### `MapOperatorParseUtil`（6 方法）

`com.seeyon.boot.starter.condition.output.map.util.MapOperatorParseUtil`

```java
    static boolean withoutLogicalOperator(java.util.Map<java.lang.String, java.lang.Object>, boolean);
    static java.lang.String buildConditionMapKey(com.seeyon.boot.starter.condition.dto.BaseConditionDto$LogicalOperator, com.seeyon.boot.starter.condition.enums.OperatorEnum, java.lang.String, boolean);
    static java.lang.String buildConditionMapKey(com.seeyon.boot.starter.condition.dto.BaseConditionDto$LogicalOperator, com.seeyon.boot.starter.condition.enums.OperatorEnum, java.lang.String);
    static private static java.lang.String addUnderLinePrefix(java.lang.String);
    static private static java.lang.String getLogicalOperator(com.seeyon.boot.starter.condition.dto.BaseConditionDto$LogicalOperator);
    static private static com.seeyon.boot.starter.mybatis.util.SearchFilter$Operator getMyBatisComponentOperator(com.seeyon.boot.starter.condition.enums.OperatorEnum);
```

### `ConditionAppService`（4 方法）

`com.seeyon.boot.starter.condition.appservice.ConditionAppService`

```java
    com.seeyon.boot.transport.ListResponse<com.seeyon.boot.starter.condition.operator.ConditionOperator> getAllOperator();
    com.seeyon.boot.transport.SingleResponse<java.lang.String> transfer(com.seeyon.boot.transport.SingleRequest<java.util.List<com.seeyon.boot.starter.condition.dto.ConditionInfoDto>>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Boolean> check(com.seeyon.boot.transport.SingleRequest<java.util.List<com.seeyon.boot.starter.condition.dto.ConditionInfoDto>>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.boot.starter.condition.params.ConditionParamResult> selectVariableParam(com.seeyon.boot.transport.SingleRequest<java.util.List<com.seeyon.boot.starter.condition.dto.ConditionInfoDto>>);
```

### `MapConditionConfigurationBo`（4 方法）

`com.seeyon.boot.starter.condition.dto.MapConditionConfigurationBo`

```java
    static com.seeyon.boot.starter.condition.dto.MapConditionConfigurationBo from();
    static com.seeyon.boot.starter.condition.dto.MapConditionConfigurationBo$MapConditionConfigurationBoBuilder builder();
    boolean isComplex();
    boolean isUseDefaultValue();
```

### `MapConditionParseConfigurationBo`（4 方法）

`com.seeyon.boot.starter.condition.dto.MapConditionParseConfigurationBo`

```java
    static com.seeyon.boot.starter.condition.dto.MapConditionParseConfigurationBo$MapConditionParseConfigurationBoBuilder builder(com.seeyon.boot.starter.condition.dto.MapConditionConfigurationBo);
    static com.seeyon.boot.starter.condition.dto.MapConditionParseConfigurationBo$MapConditionParseConfigurationBoBuilder hiddenBuilder();
    boolean isFilterNull();
    com.seeyon.boot.starter.condition.dto.MapConditionConfigurationBo getConfiguration();
```

### `DynamicConditionConfigOutPut`（3 方法）

`com.seeyon.boot.starter.condition.output.impl.DynamicConditionConfigOutPut`

```java
    java.lang.String getContent(com.seeyon.boot.starter.condition.dto.ConditionOutputParam);
    static void initSystemVariable(java.util.List<com.seeyon.boot.starter.condition.dto.ConditionInfoDto>, java.util.Map<java.lang.String, java.lang.Object>);
    java.lang.Object getContent(com.seeyon.boot.starter.condition.dto.ConditionOutputParam);
```

### `DefaultValueFactory`（3 方法）

`com.seeyon.boot.starter.condition.output.map.util.DefaultValueFactory`

```java
    void init();
    private void initDefaultValueDispatcher();
    java.util.Optional<java.lang.Object> getDefaultValueByLeftParam(com.seeyon.boot.starter.condition.dto.SingleConditionDto$LeftParamDto);
```

### `MapConditionUtil`（3 方法）

`com.seeyon.boot.starter.condition.utils.MapConditionUtil`

```java
    static java.util.Map<java.lang.String, java.lang.Object> getMapContent(com.seeyon.boot.starter.condition.dto.ConditionOutputParam);
    static cn.hutool.core.lang.Pair<java.lang.Boolean, java.lang.Object> getRightValue(com.seeyon.boot.starter.condition.dto.SingleConditionDto$LeftParamDto, com.seeyon.boot.starter.condition.dto.SingleConditionDto$RightParamDto, java.util.Map<java.lang.String, java.lang.Object>, boolean);
    static java.util.Map<java.lang.String, java.lang.Object> buildEmptyConditionMap(com.seeyon.boot.starter.condition.dto.MapConditionConfigurationBo);
```

## 四、枚举（4）

- `NullRightValueConditionEnum`（3 常量）：IGNORE_IF_ANY_NULL, USE_DEFAULT_VALUE, INVALID_IF_ANY_NULL
- `OperatorEnum`（22 常量）：EQ, NEQ, GT, LT, GE, LE, RLIKE, LLIKE, LIKE, NOTLIKE, IN, NOTIN …
- `ParamTypeEnum`（5 常量）：CONSTANT, CONTEXT_VARIABLE, SYSTEM_VARIABLE, EXPRESSION, ENTITY_FIELD
- `RelationEnum`（2 常量）：ONE2ONE, ONE2MANY
