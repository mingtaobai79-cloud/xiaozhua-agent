# boot-starter-datatype：接口与方法签名

> 自动生成，勿手改。`tools/core/platform/emit_package_surfaces.py` 重跑即可。
> 构件 `com.seeyon:boot-starter-datatype`（jar `boot-starter-datatype-5.3.600.jar`）
> 规模：23 类 / 1 接口 / 0 注解 / 0 枚举 / 1 个关键类 / 160 方法。
> 签名逐字来自 javap 原文；已去掉 `public` 前缀与 `throws` 子句。

## 一、接口（1）

### `DataType`（12 方法） extends Serializable

`com.seeyon.boot.starter.datatype.DataType`

```java
    java.lang.String getName();
    boolean getVisibility();
    java.lang.String getCaption();
    boolean baseDataType();
    java.lang.String getJavaType();
    int getDatabaseType();
    T valueOf(java.lang.String);
    java.lang.String getString(T);
    boolean isValid(java.lang.Object);
    int getOrder();
    java.lang.String getDataFormat();
    java.lang.Object mockUp();
```

## 二、关键类（1）

### `DataTypeManager`（5 方法）

`com.seeyon.boot.starter.datatype.DataTypeManager`

```java
    static java.util.List<com.seeyon.boot.starter.datatype.DataType> getDataTypes(java.lang.String...);
    static com.seeyon.boot.starter.datatype.DataType getDataTypeByName(java.lang.String);
```
