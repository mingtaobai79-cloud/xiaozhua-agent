# boot-starter-excel：接口与方法签名

> 自动生成，勿手改。`tools/core/platform/emit_package_surfaces.py` 重跑即可。
> 构件 `com.seeyon:boot-starter-excel`（jar `boot-starter-excel-5.3.603.jar`）
> 规模：72 类 / 2 接口 / 0 注解 / 2 枚举 / 25 个关键类 / 866 方法。
> 签名逐字来自 javap 原文；已去掉 `public` 前缀与 `throws` 子句。

## 一、接口（2）

### `DesignMetadataQueryApi`（5 方法）

`com.seeyon.boot.starter.excel.api.DesignMetadataQueryApi`

```java
    com.seeyon.boot.transport.SingleResponse<com.seeyon.ctp.metadata.dto.AggEntityMetadataDto> selectAggEntityMetadataByFullName(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.excel.dto.DesignMetadataRequestDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.ctp.metadata.dto.EntityMetadataDto> selectEntityMetadataByFullName(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.excel.dto.DesignMetadataRequestDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.ctp.metadata.dto.DtoMetadataDto> selectDtoMetadataByEntityFullName(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.excel.dto.DesignMetadataRequestDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.ctp.metadata.dto.CtpEnumMetadataDto> selectCtpEnumMetadataByFullNames(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.metadata.dto.request.SearchByFullNamesDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.ctp.metadata.dto.EnumMetadataDto> selectEnumMetadataByFullNames(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.metadata.dto.request.SearchByFullNamesDto>);
```

### `ExcelExportTemplateDao`（0 方法） extends ExcelExportTemplate>

`com.seeyon.boot.starter.excel.domain.dao.ExcelExportTemplateDao`

```java
```

## 二、关键类（25）

### `ExcelConvertService`（117 方法）

`com.seeyon.boot.starter.excel.domain.service.ExcelConvertService`

```java
    java.util.List<com.seeyon.boot.starter.excel.dto.ExcelColumnDto> getExcelColumnDtoList(java.util.List<java.util.List<java.lang.String>>, com.seeyon.boot.starter.excel.dto.ExcelMetadataInfoDto);
    java.util.List<com.seeyon.boot.starter.excel.dto.ExcelColumnDto> getRunExcelColumnDtoList(java.lang.String);
    private com.seeyon.boot.transport.SingleResponse<com.seeyon.ctp.metadata.dto.AggEntityMetadataDto> getAggEntityMetadataDto(java.lang.String);
    private java.lang.String getAggRootEntityFullName(java.lang.String, java.lang.String);
    static private static void getChildEntityFullName(java.util.List<java.lang.String>, java.util.List<com.seeyon.ctp.metadata.dto.AggMetadataDto>);
    private java.util.List<com.seeyon.ctp.metadata.dto.AggMetadataDto> getEntityMetadataExcludeBoot(java.lang.String);
    boolean isNotNull(com.seeyon.ctp.metadata.dto.EntityAttributeMetadataDto);
    boolean isArchiveTree(com.seeyon.ctp.metadata.dto.AggEntityMetadataDto);
    java.lang.String checkMustAttribute(com.seeyon.boot.starter.excel.dto.ExcelExportTemplateDto);
    java.lang.String checkMustAttriCore(com.seeyon.ctp.metadata.dto.AggEntityMetadataDto, java.util.Map<java.lang.String, java.util.Set<java.lang.String>>, java.util.Map<java.lang.String, java.util.Set<java.lang.String>>, java.util.Map<java.lang.String, com.seeyon.ctp.metadata.dto.EntityMetadataDto>);
    java.lang.String checkNotNullAndUnique(java.lang.String, com.seeyon.ctp.metadata.dto.EntityAttributeMetadataDto, java.util.Set<java.lang.String>);
    com.seeyon.ctp.metadata.dto.AggEntityMetadataDto getAggEntityMetadataDto(java.lang.String, java.lang.String);
    java.util.List<com.seeyon.ctp.metadata.dto.EnumMetadataDto> selectEnumMetadataByFullNames(java.lang.String, java.util.List<java.lang.String>, java.util.Map);
    java.util.List<com.seeyon.boot.starter.excel.dto.ExcelColumnDto> getExcelColumnDtoList(com.seeyon.boot.transport.SingleResponse<com.seeyon.ctp.metadata.dto.AggEntityMetadataDto>, java.util.List<java.util.List<java.lang.String>>, com.seeyon.boot.starter.excel.dto.ExcelMetadataInfoDto);
    boolean isAttriShow(com.seeyon.ctp.metadata.dto.EntityAttributeMetadataDto, java.lang.Boolean);
    java.util.List<com.seeyon.boot.starter.excel.dto.ExcelColumnDto> dealEntityMetadataAttributes(com.seeyon.ctp.metadata.dto.DtoMetadataDto, java.util.List<java.util.List<java.lang.String>>, com.seeyon.ctp.metadata.dto.AggEntityMetadataDto, com.seeyon.boot.starter.excel.dto.ExcelMetadataInfoDto);
    java.util.List<com.seeyon.boot.starter.excel.dto.ExcelColumnDto> dealEntityMetadataAttributes(java.util.List<java.util.List<java.lang.String>>, com.seeyon.ctp.metadata.dto.AggEntityMetadataDto, com.seeyon.boot.starter.excel.dto.ExcelMetadataInfoDto);
    java.util.List<com.seeyon.boot.starter.excel.dto.ExcelColumnDto> getRelationColumnList(java.util.List<java.util.List<java.lang.String>>, java.lang.Long, java.lang.String, java.lang.String, java.util.Map, java.lang.Boolean, java.lang.Boolean, java.lang.Boolean);
    java.util.List<com.seeyon.boot.starter.excel.dto.ExcelColumnDto> getRelationColumnList(com.seeyon.ctp.metadata.dto.EntityMetadataDto, com.seeyon.ctp.metadata.dto.DtoMetadataDto, java.util.List<java.util.List<java.lang.String>>, java.lang.String, java.lang.String, java.lang.Boolean, java.lang.Boolean, java.lang.Boolean);
    com.seeyon.ctp.metadata.dto.DtoMetadataDto selectDtoMetadataByEntityFullName(java.lang.Long, java.lang.String, java.lang.String, java.util.Map);
    com.seeyon.ctp.metadata.dto.EntityMetadataDto selectEntityMetadataByEntityFullName(java.lang.String, java.lang.String);
    com.seeyon.ctp.metadata.dto.EntityMetadataDto selectEntityMetadataByFullName(java.lang.Long, java.lang.String, java.lang.String, java.util.Map);
    java.util.List<com.seeyon.boot.starter.excel.dto.ExcelColumnDto> dealEntityMetadataChildren(java.util.List<java.util.List<java.lang.String>>, com.seeyon.ctp.metadata.dto.AggEntityMetadataDto, com.seeyon.boot.starter.excel.dto.ExcelMetadataInfoDto);
    void initRelationMap(com.seeyon.boot.starter.excel.dto.ExcelColumnDto);
    java.util.Map<java.lang.String, java.util.List<java.lang.String>> generateUniqueFieldMap(java.util.List<com.seeyon.boot.starter.excel.dto.ExcelColumnDto>);
    private java.lang.String getNameByMd5(java.lang.String);
    void excelOldImport(java.lang.String, java.lang.String, java.util.List<java.util.LinkedHashMap<java.lang.Integer, java.lang.Object>>, java.util.List<com.seeyon.boot.starter.excel.dto.ExcelColumnDto>, java.util.Map, java.util.List<com.seeyon.boot.starter.excel.dto.biz.ExcelImportResultDto>);
    com.seeyon.boot.starter.excel.dto.ExcelExportTemplateDto initTemplate(java.lang.Long, java.util.List<java.util.LinkedHashMap<java.lang.Integer, java.lang.Object>>);
    java.util.Set<java.lang.Long> getMainOneByOneByBatchIds(java.lang.String, java.util.Map<java.lang.String, java.lang.Object>);
    java.util.List<java.util.LinkedHashMap<java.lang.String, java.lang.Object>> excelConvertTree(java.util.List<java.lang.Object>, java.util.List<com.seeyon.boot.starter.excel.dto.ExcelColumnDto>, java.util.List<java.util.Map<java.lang.String, java.lang.Object>>);
    void saveTreeList(java.lang.String, java.lang.String, java.util.Map, java.util.List<java.util.LinkedHashMap<java.lang.String, java.lang.Object>>, java.util.Map<java.lang.String, java.util.Set<java.lang.Integer>>, java.util.List<com.seeyon.boot.starter.excel.dto.biz.ExcelImportResultDto>);
    private void handleErrorMsg(java.util.List<com.seeyon.boot.starter.excel.dto.biz.ExcelImportResultDto>, java.util.List<java.lang.Integer>, boolean, java.util.Map<java.lang.String, java.lang.String>, java.lang.String);
    private java.util.Map<java.lang.String, java.lang.String> getUdcEntityRuleErrorMsg(com.seeyon.boot.transport.SingleResponse);
    void initEntityIdByUnique(java.util.Map<java.lang.String, java.lang.Object>, java.util.List<java.util.Map<java.lang.String, java.lang.Object>>, java.util.List<java.lang.String>);
    void initRefMap(java.util.Map<java.lang.String, java.lang.Object>, java.util.Map<java.lang.String, java.lang.Object>, java.util.Map<java.lang.String, java.util.Map<java.lang.String, java.util.Map<java.lang.String, java.util.Map>>>, java.lang.Integer, boolean);
    java.lang.String generateUniqueByObject(java.util.Map<java.lang.String, java.lang.Object>);
    java.lang.String generateUniqueByObject(java.util.Map<java.lang.String, java.lang.Object>, java.lang.String, boolean);
    java.util.List<java.lang.Object> excelImportToGrid(java.util.List<java.util.LinkedHashMap<java.lang.Integer, java.lang.Object>>, java.util.List<com.seeyon.boot.starter.excel.dto.ExcelColumnDto>);
    java.util.List<com.seeyon.boot.starter.excel.dto.SheetModelExtendDto> excelExport(com.seeyon.boot.starter.excel.dto.ExcelExportTemplateDto, java.util.List<java.util.Map<java.lang.String, java.lang.Object>>);
    java.util.List<com.seeyon.boot.starter.excel.dto.SheetModelExtendDto> excelExportExtend(com.seeyon.boot.starter.excel.dto.ExcelExportTemplateDto, java.util.List<java.util.List<java.util.Map<java.lang.String, java.lang.Object>>>);
    private java.util.List<java.util.List<java.lang.Object>> getExcelObjectList(java.util.Map, java.util.List<com.seeyon.boot.starter.excel.dto.ExcelColumnDto>, java.util.List<com.seeyon.boot.starter.excel.dto.ExcelColumnDto>, java.util.List<java.util.Map<java.lang.String, java.lang.Object>>, boolean);
    static private static java.util.List<com.seeyon.boot.starter.excel.dto.ExcelColumnDto> getExcelMetaHeaderColumns(java.util.List<com.seeyon.boot.starter.excel.dto.ExcelColumnDto>, java.util.List<com.seeyon.boot.starter.excel.dto.ExcelColumnDto>, boolean);
    static private static java.util.List<com.seeyon.boot.starter.excel.dto.ExcelColumnDto> handleChildHeaderColumns(java.util.List<com.seeyon.boot.starter.excel.dto.ExcelColumnDto>);
    byte[] getExportDataList(com.seeyon.boot.starter.excel.dto.biz.ExcelExportDataDto, com.seeyon.boot.starter.excel.dto.ExcelExportTemplateDto, java.util.List<com.seeyon.boot.starter.excel.dto.ExcelColumnDto>);
    private void queryDataToExcelWriter(java.util.Map<java.lang.String, java.lang.String>, java.lang.String, java.util.Set<java.lang.String>, java.util.Map<java.lang.String, java.util.Set<java.lang.String>>, com.seeyon.boot.starter.dynamicsql.dto.DynamicConditionDto, com.seeyon.boot.transport.Sort, java.util.List<java.util.List<com.seeyon.boot.starter.excel.dto.ExcelColumnDto>>, java.util.List<com.seeyon.boot.starter.excel.dto.ExcelColumnDto>, com.alibaba.excel.ExcelWriter, com.alibaba.excel.write.metadata.WriteSheet, boolean);
    private java.util.List<java.util.Map<java.lang.String, java.lang.Object>> extractedSheetData(java.util.Map<java.lang.String, java.lang.String>, java.lang.String, java.util.Set<java.lang.String>, java.util.Map<java.lang.String, java.util.Set<java.lang.String>>, com.seeyon.boot.starter.dynamicsql.dto.DynamicConditionDto, int, com.seeyon.boot.transport.PageInfo, com.seeyon.boot.transport.Sort);
    private java.util.List<java.util.Map<java.lang.String, java.lang.Object>> getDbMaps(java.lang.String, java.util.Set<java.lang.String>, java.util.Map<java.lang.String, java.util.Set<java.lang.String>>, java.util.List<com.seeyon.boot.starter.dynamicsql.dto.JoinParamDto>, com.seeyon.boot.starter.dynamicsql.dto.DynamicConditionDto, int, com.seeyon.boot.transport.PageInfo, com.seeyon.boot.transport.Sort);
    java.util.List<java.util.List<com.seeyon.boot.starter.excel.dto.ExcelColumnDto>> rebuildExcelHeaders(java.util.List<com.seeyon.boot.starter.excel.dto.ExcelColumnDto>, java.util.List<java.util.List<com.seeyon.boot.starter.excel.dto.ExcelColumnDto>>);
    java.util.List<com.seeyon.boot.starter.excel.dto.ExcelColumnDto> handleMainTemplateColumns(java.util.List<com.seeyon.boot.starter.excel.dto.ExcelColumnDto>, java.util.List<com.seeyon.boot.starter.excel.dto.ExcelColumnDto>);
    void handleChildTemplateColumns(java.util.List<com.seeyon.boot.starter.excel.dto.ExcelColumnDto>, java.util.List<java.util.List<com.seeyon.boot.starter.excel.dto.ExcelColumnDto>>, java.util.List<com.seeyon.boot.starter.excel.dto.ExcelColumnDto>);
    static private static java.util.List<com.seeyon.boot.starter.excel.dto.ExcelColumnDto> getExcelOrderColumnsExtend(java.util.List<com.seeyon.boot.starter.excel.dto.ExcelColumnDto>, java.util.List<com.seeyon.boot.starter.excel.dto.ExcelColumnDto>);
    static private static java.util.List<java.util.List<java.lang.String>> handleLevelPathForRemoveCaption(java.util.List<java.util.List<java.lang.String>>);
    static private static java.util.List<com.seeyon.boot.starter.excel.dto.ExcelColumnDto> getExcelOrderColumns(java.util.List<com.seeyon.boot.starter.excel.dto.ExcelColumnDto>, java.util.List<com.seeyon.boot.starter.excel.dto.ExcelColumnDto>);
    static private static void handleRelationPathColumns(java.util.List<com.seeyon.boot.starter.excel.dto.ExcelColumnDto>, java.util.List<com.seeyon.boot.starter.excel.dto.ExcelColumnDto>, int);
    static void initAss(java.util.Map<java.lang.String, java.util.Map<java.lang.String, java.util.Map>>);
    static private static boolean isNumericAndNonZero(java.lang.String);
    java.util.List<java.util.Map<java.lang.String, java.lang.Object>> packageRowDataListPassAssExtend(java.util.List<java.util.Map<java.lang.String, java.lang.Object>>, java.util.List<com.seeyon.boot.starter.excel.dto.ExcelColumnDto>, java.util.Map<java.lang.String, java.util.Map<java.lang.String, java.util.Map>>);
    java.util.List packageRowDataListPassAss(java.util.List<java.util.Map<java.lang.String, java.lang.Object>>, java.util.List<com.seeyon.boot.starter.excel.dto.ExcelColumnDto>, java.util.Map<java.lang.String, java.util.Map<java.lang.String, java.util.Map>>, int);
    static java.util.List<java.lang.Object> addEntityAttributePassAssInvoke(com.seeyon.boot.starter.excel.dto.ExcelColumnDto, java.lang.Object, java.util.List<java.lang.Object>, java.util.Map<java.lang.String, java.util.Map<java.lang.String, java.util.Map>>);
    java.util.List<java.util.List<java.lang.Object>> packageRowDataListCompleteAssExtend(java.util.List<java.util.Map<java.lang.String, java.lang.Object>>, java.util.List<com.seeyon.boot.starter.excel.dto.ExcelColumnDto>, java.util.Map<java.lang.String, java.util.Map<java.lang.String, java.util.Map>>);
    java.util.List packageRowDataListCompleteAss(java.util.List<java.util.List<java.lang.Object>>, java.util.List<com.seeyon.boot.starter.excel.dto.ExcelColumnDto>, java.util.Map<java.lang.String, java.util.Map<java.lang.String, java.util.Map>>);
    static java.lang.String convertCellFinal(java.lang.String, java.lang.String, java.lang.String, com.seeyon.boot.starter.excel.dto.ExcelColumnDto, java.util.Map<java.lang.String, java.util.Map<java.lang.String, java.util.Map>>);
    void initAssRelationMap(java.util.List<com.seeyon.boot.starter.excel.dto.ExcelColumnDto>, java.util.List<java.util.LinkedHashMap<java.lang.Integer, java.lang.Object>>);
    boolean checkImportData(int, java.util.List<com.seeyon.boot.starter.excel.dto.ExcelColumnDto>, java.util.List<java.util.LinkedHashMap<java.lang.Integer, java.lang.Object>>, java.util.List<java.util.List<java.lang.Object>>, java.util.List<java.util.Map<java.lang.String, java.lang.Object>>);
    boolean checkImportDataBatch(int, java.util.List<com.seeyon.boot.starter.excel.dto.ExcelColumnDto>, java.util.List<java.util.LinkedHashMap<java.lang.Integer, java.lang.Object>>, java.util.List<java.util.List<java.lang.Object>>, java.util.List<java.util.Map<java.lang.String, java.lang.Object>>, java.util.Map<java.lang.String, java.util.Map<java.lang.String, java.util.Map<java.lang.String, java.lang.Integer>>>, java.util.Map<java.lang.Integer, java.util.Map<java.lang.Integer, java.lang.String>>, java.util.Map<java.lang.String, java.lang.Integer>, java.util.Map<java.lang.String, java.lang.Integer>, long);
    private void uniqueFieldCheck(int, java.util.List<com.seeyon.boot.starter.excel.dto.ExcelColumnDto>, java.util.List<java.util.LinkedHashMap<java.lang.Integer, java.lang.Object>>, java.util.List<java.util.Map<java.lang.String, java.lang.Object>>, java.util.Map<java.lang.String, java.util.Map<java.lang.String, java.util.Map<java.lang.String, java.lang.Integer>>>, java.util.Map<java.lang.Integer, java.util.Map<java.lang.Integer, java.lang.String>>, long, java.util.Map<java.lang.String, java.lang.Integer>);
    private void uniqueFieldCheckAccumulate(int, java.util.List<com.seeyon.boot.starter.excel.dto.ExcelColumnDto>, java.util.List<java.util.LinkedHashMap<java.lang.Integer, java.lang.Object>>, java.util.List<java.util.Map<java.lang.String, java.lang.Object>>, java.util.Map<java.lang.String, java.util.Map<java.lang.String, java.util.Map<java.lang.String, java.lang.Integer>>>, java.util.Map<java.lang.Integer, java.util.Map<java.lang.Integer, java.lang.String>>, long, java.util.Map<java.lang.String, java.lang.Integer>, java.util.Map<java.lang.String, java.lang.Integer>, long);
    private void checkImportRow(int, java.util.List<com.seeyon.boot.starter.excel.dto.ExcelColumnDto>, java.util.Map<java.lang.Integer, java.lang.Object>, java.lang.StringBuilder, java.util.Map<java.lang.String, java.util.Map<com.seeyon.boot.starter.excel.dto.ExcelColumnDto, java.lang.Boolean>>, java.util.List<java.lang.Object>, java.util.Map<java.lang.String, java.lang.Object>);
    private void checkAssField(java.util.Map<java.lang.String, java.util.Map<com.seeyon.boot.starter.excel.dto.ExcelColumnDto, java.lang.Boolean>>, java.lang.StringBuilder);
    java.lang.String checkImportDataCore(com.seeyon.boot.starter.excel.dto.ExcelColumnDto, java.lang.Object);
    java.lang.String excelImportTemplateFileStorageKey(java.util.List<java.util.List<com.seeyon.boot.starter.excel.dto.ExcelColumnDto>>, com.seeyon.boot.starter.excel.dto.ExcelExportTemplateDto, java.util.List<java.util.List<java.util.List<java.lang.Object>>>);
    java.lang.String excelImportTemplateFile(java.util.List<java.util.List<com.seeyon.boot.starter.excel.dto.ExcelColumnDto>>, com.seeyon.boot.starter.excel.dto.ExcelExportTemplateDto, java.util.List<java.util.List<java.util.List<java.lang.Object>>>);
    java.lang.String generateExcel2Url(java.util.List<java.util.List<com.seeyon.boot.starter.excel.dto.ExcelColumnDto>>, com.seeyon.boot.starter.excel.dto.ExcelExportTemplateDto, java.util.List<java.util.List<java.util.List<java.lang.Object>>>, java.lang.String);
    java.util.List<com.seeyon.boot.util.excel.model.SheetModel> excelTemplateSheetModel(com.seeyon.boot.starter.excel.dto.ExcelExportTemplateDto, java.util.List<java.util.List<com.seeyon.boot.starter.excel.dto.ExcelColumnDto>>, java.util.List);
    java.util.List<com.seeyon.boot.starter.excel.dto.SheetModelExtendDto> excelTemplateSheetModelExtend(com.seeyon.boot.starter.excel.dto.ExcelExportTemplateDto, java.util.List<java.util.List<com.seeyon.boot.starter.excel.dto.ExcelColumnDto>>, java.util.List);
    java.util.List<com.seeyon.boot.starter.excel.dto.SheetModelExtendDto> excelTemplateSheetModelExtend(com.seeyon.boot.starter.excel.dto.ExcelExportTemplateDto);
    void initMd5RefExcelNumMap(java.util.List<java.lang.Object>, java.util.Map<java.lang.String, java.util.Set<java.lang.Integer>>, int);
    java.util.List<java.util.List<java.util.LinkedHashMap<java.lang.Integer, java.lang.Object>>> getImportData(java.lang.String, java.util.List<java.util.List<com.seeyon.boot.starter.excel.dto.ExcelColumnDto>>, java.util.List<com.seeyon.boot.starter.excel.dto.ExcelColumnDto>);
    void onExcelImportCheckForEvent(com.seeyon.boot.starter.excel.event.ExcelImportCheckEvent, java.util.List<java.util.List<com.seeyon.boot.starter.excel.dto.ExcelColumnDto>>);
    boolean onExcelImportCheck(java.util.List<java.util.List<java.util.LinkedHashMap<java.lang.Integer, java.lang.Object>>>, java.util.List<java.util.List<com.seeyon.boot.starter.excel.dto.ExcelColumnDto>>, java.util.List<java.util.List<java.util.List<java.lang.Object>>>);
    private int getHeadRowNum(java.lang.String);
    private int getHeadRowNum(byte[]);
    private byte[] downloadFileBytes(java.lang.String);
    static private static void getNewColumn(com.seeyon.boot.starter.excel.dto.ExcelColumnDto, com.seeyon.boot.starter.excel.dto.ExcelColumnDto);
    void onExcelImportTransToGridCore(com.seeyon.boot.starter.excel.dto.ExcelExportTemplateDto, java.util.List<java.util.LinkedHashMap<java.lang.Integer, java.lang.Object>>, java.lang.String);
    void checkExcel(java.util.List<java.util.List<com.seeyon.boot.starter.excel.dto.ExcelColumnDto>>, java.util.List<java.util.List<java.util.LinkedHashMap<java.lang.Integer, java.lang.Object>>>, com.seeyon.boot.starter.excel.dto.ExcelExportTemplateDto, java.lang.String);
    void onExcelImportForEvent(com.seeyon.boot.starter.excel.event.ExcelImportEvent, java.util.List<java.util.List<java.util.List<java.lang.Object>>>);
```

### `ExcelTemplateUtil`（70 方法）

`com.seeyon.boot.starter.excel.utils.ExcelTemplateUtil`

```java
    static private static com.seeyon.boot.starter.i18n.MessageRepository getMessageRepository();
    static private static com.seeyon.boot.starter.proxy.appservice.AppServiceReliableInvoker getAppServiceReliableInvoker();
    static private static com.seeyon.boot.starter.file.FileService getFileService();
    static com.seeyon.boot.starter.excel.domain.service.ExcelConvertService getExcelConvertService();
    static java.util.List<java.util.List<com.seeyon.boot.starter.excel.dto.ExcelColumnDto>> convertExcelHeaderColumn(java.util.List<java.util.List<com.seeyon.boot.starter.excel.dto.ExcelColumnDto>>);
    static com.seeyon.boot.util.excel.model.SheetModel setFirstImportSheet(java.lang.String, int, java.lang.String);
    static com.seeyon.boot.starter.excel.dto.SheetModelExtendDto setFirstImportSheetExtend(java.lang.String, java.lang.String);
    static java.lang.String[] stringToStringArray(java.lang.String, int);
    static com.seeyon.boot.util.excel.model.style.CellStyle generateCellStyle();
    static void setImportCellStyle(com.seeyon.boot.util.excel.model.SheetModel, java.util.List<com.seeyon.boot.starter.excel.dto.ExcelColumnDto>);
    static void setImportCellStyleExtend(com.seeyon.boot.starter.excel.dto.SheetModelExtendDto, java.util.List<com.seeyon.boot.starter.excel.dto.ExcelColumnDto>);
    static void setSheetHeader(com.seeyon.boot.util.excel.model.SheetModel, java.util.List<com.seeyon.boot.starter.excel.dto.ExcelColumnDto>, java.util.List<java.lang.String>);
    static void setErrorColumnInfo(com.seeyon.boot.util.excel.model.SheetModel);
    static void setExportSheetModelData(com.seeyon.boot.util.excel.model.SheetModel, java.util.List<com.seeyon.boot.starter.excel.dto.ExcelColumnDto>, java.util.List<java.util.List<java.lang.Object>>);
    static java.util.List<java.util.List<java.lang.Object>> setExportSheetModelDataExtend(java.util.List<com.seeyon.boot.starter.excel.dto.ExcelColumnDto>, java.util.List<java.util.List<java.lang.Object>>);
    static void setImportSheetModelData(com.seeyon.boot.util.excel.model.SheetModel, java.util.List<com.seeyon.boot.starter.excel.dto.ExcelColumnDto>, java.util.List<java.util.List<java.lang.Object>>);
    static void setSheetName(com.seeyon.boot.util.excel.model.SheetModel, java.util.List<com.seeyon.boot.starter.excel.dto.ExcelColumnDto>, int);
    static java.util.List<com.seeyon.boot.util.excel.model.SheetModel> generatorSheetModel(com.seeyon.boot.starter.excel.dto.ExcelExportTemplateDto, java.util.List<java.util.List<com.seeyon.boot.starter.excel.dto.ExcelColumnDto>>, java.util.List<java.util.List<java.util.List<java.lang.Object>>>, boolean);
    static java.util.List<com.seeyon.boot.starter.excel.dto.SheetModelExtendDto> generatorSheetModelExtend(com.seeyon.boot.starter.excel.dto.ExcelExportTemplateDto, java.util.List<java.util.List<com.seeyon.boot.starter.excel.dto.ExcelColumnDto>>, java.util.List<java.util.List<java.util.List<java.lang.Object>>>, boolean);
    static private static java.lang.String checkAndReplaceSheetName(java.lang.String);
    static void putDataValidityIntoSheetModel(com.seeyon.boot.util.excel.model.SheetModel, java.util.List<com.seeyon.boot.starter.excel.dto.ExcelColumnDto>);
    static void putDataValidityIntoSheetModelExtend(com.seeyon.boot.starter.excel.dto.SheetModelExtendDto, java.util.List<com.seeyon.boot.starter.excel.dto.ExcelColumnDto>);
    static void booleanDataValidity(com.seeyon.boot.util.excel.model.style.DataValidity);
    static void enumDataValidity(com.seeyon.boot.starter.excel.dto.ExcelColumnDto, com.seeyon.boot.util.excel.model.style.DataValidity);
    static void ctpEnumDataValidity(com.seeyon.boot.starter.excel.dto.ExcelColumnDto, com.seeyon.boot.util.excel.model.style.DataValidity);
    static private static com.seeyon.boot.util.excel.model.style.DataValidity putDataValidityIntoSheetModel(com.seeyon.boot.starter.excel.dto.ExcelColumnDto, int);
    static java.lang.String fullNameToSingleName(java.lang.String);
    static java.lang.String fullNameToAppName(java.lang.String);
    static java.lang.String entityFullNameToDtoFullName(java.lang.String);
    static java.lang.String fullParamToFullEntity(java.lang.String);
    static java.lang.String transFirstCharToLowerCase(java.lang.String);
    static private static java.util.List<java.util.List<java.lang.String>> infoHead();
    static <T> java.util.List<T> deepCopy(java.util.List<T>)
    static <T extends java.io.Serializable> T clone(T);
    static com.seeyon.boot.transport.SingleResponse invokeSaveBatch(java.lang.String, java.lang.String, com.seeyon.boot.starter.excel.dto.biz.ExcelImportTransDto, java.lang.String);
    static java.util.List<com.seeyon.boot.starter.excel.dto.biz.ExcelImportResultDto> invokeImportExcel(java.lang.String, java.lang.String, com.seeyon.boot.starter.excel.dto.biz.ExcelImportTransDto);
    static java.lang.Object getEntityAppServiceName(java.lang.String);
    static java.lang.String entityToAppServiceName(java.lang.String);
    static java.lang.String getRandomNum(int);
    static java.lang.String getShowColumnName(com.seeyon.boot.starter.excel.dto.ExcelColumnDto);
    static java.lang.String getColumnComboName(com.seeyon.boot.starter.excel.dto.ExcelColumnDto);
    static java.util.List<java.util.Map<java.lang.String, java.lang.Object>> selectObjectListByConditions(java.lang.String, java.lang.String, java.util.Map<java.lang.String, java.lang.Object>, com.seeyon.boot.transport.Sort);
    static java.util.List<java.util.Map<java.lang.String, java.lang.Object>> selectDubboObjectListByConditions(java.lang.String, java.lang.String, java.util.Map<java.lang.String, java.lang.Object>, com.seeyon.boot.transport.Sort);
    static java.util.List<java.util.Map<java.lang.String, java.lang.Object>> selectDubboObjectListByConditions(java.lang.String, java.lang.String, java.util.Map<java.lang.String, java.lang.Object>);
    static java.util.List<java.util.Map<java.lang.String, java.lang.Object>> selectCtpEnumDubboObjectListByConditions(java.lang.String, java.lang.String);
    static java.util.Map<java.lang.Long, java.lang.String> selectEnumItemFullName(java.lang.String, java.lang.String);
    static java.util.Map<java.lang.String, java.lang.Object> selectCtpEnumByEnumId(java.lang.String, java.lang.Long);
    static java.util.List<java.util.LinkedHashMap<java.lang.String, java.lang.Object>> selectEntityListByIds(java.lang.String, java.lang.String, java.util.List<java.lang.Long>);
    static java.util.List<java.util.LinkedHashMap<java.lang.String, java.lang.Object>> selectDubboEntityListByIds(java.lang.String, java.lang.String, java.util.List<java.lang.Long>);
    static private static com.seeyon.boot.transport.ListResponse<java.lang.Object> invokeForList(java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.Object);
    static private static com.seeyon.boot.transport.SingleResponse<java.lang.Object> invoke(java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.Object);
    static private static java.lang.String getInterfaceNameByEntityFullName(java.lang.String, java.lang.String);
    static private static java.lang.String getInterfaceNameByEntityFullName4BasicMethod(java.lang.String, java.lang.String);
    static private static java.lang.String getInterfaceNameBasicMethod(java.lang.String);
    static java.lang.Boolean isDesign(java.util.Map);
    static java.lang.String getExcelRedisKey(java.lang.Long);
    static java.lang.String generateDownloadUrl(java.util.List<com.seeyon.boot.util.excel.model.SheetModel>, java.lang.String);
    static java.lang.String generateDownloadStorageKey(byte[], java.lang.String);
    static java.lang.String generateDownloadStorageKey(java.util.List<com.seeyon.boot.starter.excel.dto.SheetModelExtendDto>, java.lang.String);
    static java.lang.String generateDownloadUrlExtend(java.util.List<com.seeyon.boot.starter.excel.dto.SheetModelExtendDto>, java.lang.String);
    static java.lang.String uploadJsonFile(java.lang.String, java.lang.String);
    static void deleteFiles(java.util.List<java.lang.String>);
    static java.lang.String getFileToString(java.lang.String);
    static java.util.List<com.seeyon.boot.starter.excel.dto.ExcelColumnDto> pullSameLevel2Aggregation(java.util.List<com.seeyon.boot.starter.excel.dto.ExcelColumnDto>);
    static boolean isConsecutive(java.util.List<java.lang.Integer>);
    static java.lang.String exportFixedHeadForApplication(java.lang.String, java.lang.String, java.util.List<java.util.List<java.lang.String>>, java.util.List<java.util.List<java.lang.String>>);
```

### `ExcelExportTemplateDto`（38 方法）

`com.seeyon.boot.starter.excel.dto.ExcelExportTemplateDto`

```java
    java.lang.Long getId();
    java.lang.String getName();
    java.lang.String getAppId();
    java.lang.Long getAppGuid();
    java.lang.String getAppName();
    java.lang.String getMainFullName();
    java.lang.Long getCreateUserId();
    java.lang.String getSignatureCode();
    java.lang.String getMetadataContent();
    java.lang.String getExcelHeadInfo();
    java.lang.Boolean getIsCustom();
    java.lang.Boolean getIsImport();
    java.lang.Boolean getIsDefault();
    java.lang.Boolean getDeleteFlag();
    java.util.List<java.util.List<com.seeyon.boot.starter.excel.dto.ExcelColumnDto>> getColumnList();
    java.lang.Long getBelongGroupId();
    java.lang.Long getOriginalId();
    java.util.List<java.lang.String> getImportReminders();
    java.lang.String getAuthInfo();
    void setId(java.lang.Long);
    void setName(java.lang.String);
    void setAppId(java.lang.String);
    void setAppGuid(java.lang.Long);
    void setAppName(java.lang.String);
    void setMainFullName(java.lang.String);
    void setCreateUserId(java.lang.Long);
    void setSignatureCode(java.lang.String);
    void setMetadataContent(java.lang.String);
    void setExcelHeadInfo(java.lang.String);
    void setIsCustom(java.lang.Boolean);
    void setIsImport(java.lang.Boolean);
    void setIsDefault(java.lang.Boolean);
    void setDeleteFlag(java.lang.Boolean);
    void setColumnList(java.util.List<java.util.List<com.seeyon.boot.starter.excel.dto.ExcelColumnDto>>);
    void setBelongGroupId(java.lang.Long);
    void setOriginalId(java.lang.Long);
    void setImportReminders(java.util.List<java.lang.String>);
    void setAuthInfo(java.lang.String);
```

### `ExcelConvertUtil`（34 方法）

`com.seeyon.boot.starter.excel.utils.ExcelConvertUtil`

```java
    static java.lang.String checkDataType(java.lang.String, java.lang.String, java.lang.String, com.seeyon.boot.starter.i18n.MessageRepository);
    static java.lang.String checkEnumValue(com.seeyon.boot.starter.excel.dto.ExcelColumnDto, java.lang.String, java.lang.String, com.seeyon.boot.starter.i18n.MessageRepository);
    static java.util.Map<java.lang.String, java.lang.String> transEnumList2MessageMap(com.seeyon.boot.starter.excel.dto.ExcelColumnDto, com.seeyon.boot.starter.i18n.MessageRepository);
    static java.lang.String checkJSR303(java.lang.Object, java.util.Map, java.lang.String);
    static java.lang.String getValueFromMap(java.util.Map, java.lang.Object);
    static java.util.List<java.util.List<java.lang.Object>> extChildColumn(java.util.List<java.util.List<java.lang.Object>>, java.util.List<java.lang.Object>, java.util.List<java.lang.Integer>);
    static void setNextCanzhao(com.seeyon.boot.starter.excel.dto.ExcelColumnDto, java.util.List<com.seeyon.boot.starter.excel.dto.ExcelColumnDto>);
    static java.lang.String getSafetyValue(java.lang.String, com.seeyon.boot.starter.excel.dto.ExcelColumnDto);
    static java.lang.String getCurrValueFromCtpDateI18N(java.lang.String);
    static java.lang.String getEnumShowName(java.lang.Object, com.seeyon.boot.starter.i18n.MessageRepository);
    static void addJsr303ToColumn(com.seeyon.boot.starter.excel.dto.ExcelColumnDto, com.seeyon.ctp.metadata.dto.DtoAttributeMetadataDto);
    static java.util.List<java.util.Map<java.lang.String, java.lang.Object>> getExcelUniqueRowByDb(java.util.List<com.seeyon.boot.starter.excel.dto.ExcelColumnDto>, java.util.List<java.util.LinkedHashMap<java.lang.Integer, java.lang.Object>>);
    static void handleAssFieldValue(java.util.List<com.seeyon.boot.starter.excel.dto.ExcelColumnDto>, java.util.List<java.util.LinkedHashMap<java.lang.Integer, java.lang.Object>>);
    static java.util.List<java.lang.Object> packageImportExcelData(java.util.List<java.util.Map<java.lang.String, java.lang.Object>>, java.util.List<com.seeyon.boot.starter.excel.dto.ExcelColumnDto>, java.util.List<java.util.LinkedHashMap<java.lang.Integer, java.lang.Object>>, com.seeyon.boot.starter.excel.enums.Excel2ModelTypeEnum);
    static private static java.util.Map<java.lang.String, java.util.Map<java.lang.String, java.util.Map<java.lang.String, java.lang.Object>>> buildUniqueIndex(java.util.List<java.util.Map<java.lang.String, java.lang.Object>>);
    static java.util.List<java.lang.Object> packageImportExcelDataToMap(java.util.List<com.seeyon.boot.starter.excel.dto.ExcelColumnDto>, java.util.List<java.util.LinkedHashMap<java.lang.Integer, java.lang.Object>>, com.seeyon.boot.starter.excel.enums.Excel2ModelTypeEnum);
    static void initAssFieldUniqueValueMap(java.util.List<java.util.Map<java.lang.String, java.lang.Object>>, java.util.Map<java.lang.String, java.util.Map<java.lang.String, java.lang.String>>, java.lang.String, java.util.List<java.lang.String>);
    static java.util.HashMap<java.lang.String, java.lang.Object> generateMainEntityHashMapStructure(java.util.List<com.seeyon.boot.starter.excel.dto.ExcelColumnDto>);
    static java.util.Map packageCellDataToHashMap(java.util.Map, com.seeyon.boot.starter.excel.dto.ExcelColumnDto, java.lang.Object, com.seeyon.boot.starter.excel.enums.Excel2ModelTypeEnum);
    static java.lang.Object convertExcelObj(com.seeyon.boot.starter.excel.dto.ExcelColumnDto, java.lang.Object, com.seeyon.boot.starter.excel.enums.Excel2ModelTypeEnum);
    static boolean initResultSheetData(java.util.List<com.seeyon.boot.starter.excel.dto.biz.ExcelImportResultDto>, java.util.List<java.util.LinkedHashMap<java.lang.Integer, java.lang.Object>>, java.util.List<com.seeyon.boot.starter.excel.dto.ExcelColumnDto>, java.util.List<java.util.List<java.lang.Object>>);
    static com.alibaba.excel.write.metadata.WriteSheet getModelExcelWriteSheet(com.seeyon.boot.starter.excel.dto.ExcelExportTemplateDto, java.util.List<com.seeyon.boot.starter.excel.dto.ExcelColumnDto>, int);
    static java.util.List<java.util.LinkedHashMap<java.lang.String, java.lang.Object>> rebuildForChildChildDataImport(java.util.List<java.util.LinkedHashMap<java.lang.String, java.lang.Object>>, java.util.List<java.util.LinkedHashMap<java.lang.String, java.lang.Object>>);
    static void rebuildImportDataList(java.util.List<java.util.LinkedHashMap>, java.util.List<com.seeyon.boot.starter.excel.dto.ExcelColumnDto>, java.util.List<java.util.LinkedHashMap<java.lang.String, java.lang.Object>>);
```

### `ExcelExportTemplate`（32 方法）

`com.seeyon.boot.starter.excel.domain.entity.ExcelExportTemplate`

```java
    java.lang.String getName();
    java.lang.Long getBelongGroupId();
    java.lang.String getAppId();
    java.lang.Long getAppGuid();
    java.lang.String getAppName();
    java.lang.String getMainFullName();
    java.lang.Long getCreateUserId();
    java.lang.String getSignatureCode();
    java.lang.String getMetadataContent();
    java.lang.String getExcelHeadInfo();
    java.lang.Boolean getIsCustom();
    java.lang.Boolean getIsImport();
    java.lang.Boolean getIsDefault();
    java.lang.Boolean getDeleteFlag();
    java.lang.String getAggregationAppName();
    java.lang.String getAuthInfo();
    void setName(java.lang.String);
    void setBelongGroupId(java.lang.Long);
    void setAppId(java.lang.String);
    void setAppGuid(java.lang.Long);
    void setAppName(java.lang.String);
    void setMainFullName(java.lang.String);
    void setCreateUserId(java.lang.Long);
    void setSignatureCode(java.lang.String);
    void setMetadataContent(java.lang.String);
    void setExcelHeadInfo(java.lang.String);
    void setIsCustom(java.lang.Boolean);
    void setIsImport(java.lang.Boolean);
    void setIsDefault(java.lang.Boolean);
    void setDeleteFlag(java.lang.Boolean);
    void setAggregationAppName(java.lang.String);
    void setAuthInfo(java.lang.String);
```

### `ExcelCheckUtil`（30 方法）

`com.seeyon.boot.starter.excel.utils.ExcelCheckUtil`

```java
    static <T> boolean compare(java.util.List<T>, java.util.List<T>);
    static boolean checkNotBlank(com.seeyon.boot.starter.excel.dto.ExcelColumnDto, java.lang.Object);
    static java.lang.String checkJSR303(com.seeyon.boot.starter.excel.dto.ExcelColumnDto, java.lang.Object);
    static boolean isAss(java.util.List<java.util.List<java.lang.String>>);
    static java.lang.String getAssAttribute(com.seeyon.boot.starter.excel.dto.ExcelColumnDto);
    static boolean isAssNotUnique(com.seeyon.boot.starter.excel.dto.ExcelColumnDto);
    static boolean isAssUnique(com.seeyon.boot.starter.excel.dto.ExcelColumnDto);
    static boolean isNotNull(com.seeyon.ctp.metadata.dto.EntityAttributeMetadataDto);
    static java.lang.String getParentEnumAttributeFullName(com.seeyon.ctp.metadata.dto.EntityAttributeMetadataDto);
    static boolean isExtEntity(com.seeyon.ctp.metadata.dto.AggEntityMetadataDto);
    static boolean isMatchQuery(com.seeyon.ctp.metadata.dto.EntityAttributeMetadataDto);
    static java.lang.String getEntityFullname(com.seeyon.boot.starter.excel.dto.ExcelColumnDto);
    static java.lang.String getAttriFullname(com.seeyon.boot.starter.excel.dto.ExcelColumnDto);
    static java.lang.String getAssAttriFullname(com.seeyon.boot.starter.excel.dto.ExcelColumnDto);
    static java.lang.String getAssAttrEntityFullName(com.seeyon.boot.starter.excel.dto.ExcelColumnDto);
    static boolean isNotAssAttribute(com.seeyon.boot.starter.excel.dto.ExcelColumnDto);
    static boolean isAssAttribute(com.seeyon.boot.starter.excel.dto.ExcelColumnDto);
    static boolean isMainAttribute(com.seeyon.boot.starter.excel.dto.ExcelColumnDto);
    static boolean isMainAssAttribute(com.seeyon.boot.starter.excel.dto.ExcelColumnDto);
    static boolean isOneSelfAttribute(com.seeyon.boot.starter.excel.dto.ExcelColumnDto, boolean);
    static boolean isMainOneByOneAttribute(com.seeyon.boot.starter.excel.dto.ExcelColumnDto);
    static boolean isMainOneByOneAssAttribute(com.seeyon.boot.starter.excel.dto.ExcelColumnDto);
    static boolean isChildrenAttribute(com.seeyon.boot.starter.excel.dto.ExcelColumnDto);
    static boolean isChildrenAssAttribute(com.seeyon.boot.starter.excel.dto.ExcelColumnDto);
    static boolean isChildrenOneByOneAttribute(com.seeyon.boot.starter.excel.dto.ExcelColumnDto);
    static boolean isGrandsonAttribute(com.seeyon.boot.starter.excel.dto.ExcelColumnDto);
    static boolean isGrandsonAssAttribute(com.seeyon.boot.starter.excel.dto.ExcelColumnDto);
    static boolean isGrandsonOneByOneAttribute(com.seeyon.boot.starter.excel.dto.ExcelColumnDto);
    static java.util.List<java.lang.String> getZhuzisunFullnameList(java.util.List<com.seeyon.boot.starter.excel.dto.ExcelColumnDto>, java.util.Map<java.lang.String, java.util.List<java.lang.String>>);
    static boolean hasNotNullAttriValue(java.util.Map<java.lang.String, java.lang.Object>);
```

### `ExcelExportUtil`（25 方法）

`com.seeyon.boot.starter.excel.utils.ExcelExportUtil`

```java
    static java.lang.String getExportValueType(com.seeyon.boot.starter.excel.dto.ExcelColumnDto);
    static void entityAssInvoke(java.lang.String, java.lang.Object, java.util.List<com.seeyon.boot.starter.excel.dto.ExcelColumnDto>, java.util.Map<java.lang.String, java.lang.Object>);
    static void entityAssInvoke(com.seeyon.boot.starter.excel.dto.ExcelColumnDto, java.lang.Object, java.util.List<java.lang.Object>);
    static void initAssGlobalMap(com.seeyon.boot.starter.excel.dto.ExcelColumnDto, java.lang.Object, java.util.Map<java.lang.String, java.util.Map<java.lang.String, java.util.Map>>);
    static void initAssPassGlobalMap(com.seeyon.boot.starter.excel.dto.ExcelColumnDto, java.lang.Object, java.util.Map<java.lang.String, java.util.Map<java.lang.String, java.util.Map>>, java.util.List<java.lang.Object>);
    static java.lang.String enumI18nConvertOpt(com.seeyon.boot.starter.excel.dto.ExcelColumnDto, java.lang.String);
    static java.lang.String ctpEnumAssInvoke(com.seeyon.boot.starter.excel.dto.ExcelColumnDto, java.lang.Object);
    static java.lang.String enumConvert(com.seeyon.boot.starter.excel.dto.ExcelColumnDto, com.seeyon.boot.enums.Messageable);
    static java.lang.String enumAssInvoke(com.seeyon.boot.starter.excel.dto.ExcelColumnDto, java.lang.Object);
    static void initEnumRelation(com.seeyon.boot.starter.excel.dto.ExcelColumnDto);
    static void initCtpEnumRelation(com.seeyon.boot.starter.excel.dto.ExcelColumnDto);
    static void initBooleanRelation(com.seeyon.boot.starter.excel.dto.ExcelColumnDto);
    static java.lang.Object convertExport(com.seeyon.boot.starter.excel.dto.ExcelColumnDto, java.lang.Object);
    static private static com.seeyon.boot.starter.i18n.MessageRepository getMessageRepository();
    static java.lang.String generateString(char, int);
    static java.lang.String checkImport(com.seeyon.boot.starter.excel.dto.ExcelColumnDto, java.lang.String)
    static private static java.lang.String dateRangeCheck(java.lang.String, java.lang.String, java.lang.String);
    static java.util.Set<java.lang.String> getCondEntityFullName(com.seeyon.boot.starter.dynamicsql.dto.DynamicConditionDto, java.lang.String);
    static private static void handleParams(java.lang.String, java.util.Map$Entry<java.lang.String, java.lang.Object>, java.util.Set<java.lang.String>);
```

### `ExcelExportTemplateService`（24 方法）

`com.seeyon.boot.starter.excel.domain.service.ExcelExportTemplateService`

```java
    void upgradeDataForUdc(java.util.List<java.util.Map>);
    java.lang.Long create(com.seeyon.boot.starter.excel.dto.ExcelExportTemplateDto);
    java.lang.Integer update(com.seeyon.boot.starter.excel.dto.ExcelExportTemplateDto);
    private java.util.List<java.util.List<com.seeyon.boot.starter.excel.dto.ExcelColumnDto>> filterMetadataListList(java.util.List<java.util.List<com.seeyon.boot.starter.excel.dto.ExcelColumnDto>>);
    private java.util.List<java.util.List<com.seeyon.boot.starter.excel.dto.ExcelColumnDto>> getExcelHeadListByMetadataList(java.util.List<java.util.List<com.seeyon.boot.starter.excel.dto.ExcelColumnDto>>);
    com.seeyon.boot.starter.excel.dto.ExcelExportTemplateDto selectById(java.lang.Long);
    java.util.List<com.seeyon.boot.starter.excel.dto.SheetModelExtendDto> generateTemplateSheetModelExtend(com.seeyon.boot.starter.excel.dto.biz.ExcelExportDto);
    java.util.List<com.seeyon.boot.starter.excel.domain.entity.ExcelExportTemplate> selectByName(java.lang.String, java.lang.String, boolean);
    com.seeyon.boot.starter.excel.dto.ExcelExportTemplateDto selectTemplateByMd5(java.lang.String);
    java.util.List<com.seeyon.boot.starter.excel.dto.ExcelExportTemplateDto> selectListByConditions(java.util.Map<java.lang.String, java.lang.Object>, com.seeyon.boot.transport.Sort);
    java.util.List<com.seeyon.boot.starter.excel.dto.ExcelExportTemplateDto> selectCustomListByConditions(java.util.Map<java.lang.String, java.lang.Object>, com.seeyon.boot.transport.Sort);
    com.seeyon.boot.transport.PageData<com.seeyon.boot.starter.excel.dto.ExcelExportTemplateDto> selectPageByCondition(com.seeyon.boot.transport.PageInfo, java.util.Map<java.lang.String, java.lang.Object>, com.seeyon.boot.transport.Sort);
    int deleteById(java.lang.Long);
    int setTemplateDefault(java.lang.Long);
    java.util.List<com.seeyon.boot.starter.excel.dto.ExcelExportTemplateDto> getPreExcelTemplateList4Check(com.seeyon.boot.starter.excel.dto.ExcelTemplateCheckDto);
    void sendMessage(com.seeyon.boot.starter.excel.dto.biz.ExcelExportDataDto, java.lang.String, java.lang.String, java.lang.String, boolean, boolean);
    java.util.List<com.seeyon.boot.starter.excel.dto.ExcelExportTemplateDto> getUsableTemplateList(com.seeyon.boot.starter.excel.dto.ExcelTemplateAuthQueryDto);
    private void setTemplateDefaultAuth(java.util.List<com.seeyon.boot.starter.excel.domain.entity.ExcelExportTemplate>);
    private java.util.Map<java.lang.String, java.lang.Object> getOrgUnitRootByTenant(java.lang.Long);
    java.lang.Integer setExcelTemplateAuth(com.seeyon.boot.starter.excel.dto.ExcelTemplateAuthDto);
    private java.util.Map<java.lang.String, java.lang.Object> getResourceAndPermissionDto(com.seeyon.boot.starter.excel.domain.entity.ExcelExportTemplate);
    private void registerAuthorization(com.seeyon.boot.starter.excel.domain.entity.ExcelExportTemplate);
```

### `ExcelExportTemplate4GridDto`（20 方法）

`com.seeyon.boot.starter.excel.dto.ExcelExportTemplate4GridDto`

```java
    java.lang.String getName();
    java.lang.String getAppId();
    java.lang.String getAppName();
    java.lang.String getMainFullName();
    java.lang.Long getCreateUserId();
    java.lang.Boolean getIsCustom();
    java.lang.Boolean getIsImport();
    java.lang.Boolean getIsDefault();
    java.util.List<java.lang.String> getDataGridHeadInfos();
    java.util.Map getMap();
    void setName(java.lang.String);
    void setAppId(java.lang.String);
    void setAppName(java.lang.String);
    void setMainFullName(java.lang.String);
    void setCreateUserId(java.lang.Long);
    void setIsCustom(java.lang.Boolean);
    void setIsImport(java.lang.Boolean);
    void setIsDefault(java.lang.Boolean);
    void setDataGridHeadInfos(java.util.List<java.lang.String>);
    void setMap(java.util.Map);
```

### `ExcelExportAppService`（19 方法）

`com.seeyon.boot.starter.excel.appservice.ExcelExportAppService`

```java
    com.seeyon.boot.transport.SingleResponse<java.lang.String> getExcelColumnDtoList(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.excel.dto.ExcelMetadataInfoDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Long> createExcelTemplate(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.excel.dto.ExcelExportTemplateDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> update(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.excel.dto.ExcelExportTemplateDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> setTemplateDefault(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.boot.starter.excel.dto.ExcelExportTemplateDto> selectById(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.PageResponse<com.seeyon.boot.starter.excel.dto.ExcelExportTemplateDto> selectPageByCondition(com.seeyon.boot.transport.PageRequest);
    com.seeyon.boot.transport.ListResponse<com.seeyon.boot.starter.excel.dto.ExcelExportTemplateDto> selectListByConditions(com.seeyon.boot.transport.SingleRequest<java.util.Map<java.lang.String, java.lang.Object>>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.boot.starter.excel.dto.ExcelExportTemplateDto> selectCustomListByConditions(com.seeyon.boot.transport.SingleRequest<java.util.Map<java.lang.String, java.lang.Object>>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> deleteById(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.boot.util.excel.model.SheetModel> generateTemplateSheetModel(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.excel.dto.biz.ExcelExportDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.boot.starter.excel.dto.SheetModelExtendDto> generateTemplateSheetModelExtend(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.excel.dto.biz.ExcelExportDto>);
    java.lang.String generateExcelTable(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.excel.dto.biz.ExcelExportDataDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.String> getUrlByRedisKey(com.seeyon.boot.transport.SingleRequest<java.lang.String>);
    com.seeyon.boot.transport.SingleResponse<java.lang.String> exportTemplateFile(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.excel.dto.biz.ExcelExportDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.String> exportTemplateFileExtend(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.excel.dto.biz.ExcelExportDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Long> createExcelDataGridTemplate(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.excel.dto.ExcelExportTemplate4GridDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.boot.starter.excel.dto.ExcelExportTemplateDto> getPreExcelTemplateList4Check(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.excel.dto.ExcelTemplateCheckDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.boot.starter.excel.dto.ExcelExportTemplateDto> getUsableTemplateList(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.excel.dto.ExcelTemplateAuthQueryDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> setExcelTemplateAuth(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.excel.dto.ExcelTemplateAuthDto>);
```

### `ExcelExtendUtils`（13 方法）

`com.seeyon.boot.starter.excel.utils.ExcelExtendUtils`

```java
    static com.seeyon.boot.starter.excel.event.listener.LimitExcelReadListener getLimitExcelReadListener(java.io.InputStream, java.lang.Integer, java.lang.Integer);
    static byte[] writeExcelByteArray(com.seeyon.boot.util.excel.enums.ExcelEnum, com.seeyon.boot.starter.excel.dto.SheetModelExtendDto...);
    static void excelWriterMetaInfoSheet(com.seeyon.boot.starter.excel.dto.ExcelExportTemplateDto, com.alibaba.excel.ExcelWriter);
    static com.alibaba.excel.write.builder.ExcelWriterSheetBuilder getExcelWriterSheetBuilder(com.seeyon.boot.starter.excel.dto.SheetModelExtendDto, java.lang.Integer);
    static private static int setHead(java.lang.Class, com.alibaba.excel.read.builder.ExcelReaderSheetBuilder, com.alibaba.excel.write.builder.ExcelWriterSheetBuilder);
    static private static com.seeyon.boot.util.excel.model.style.CellStyle buildCellStyle(java.lang.annotation.Annotation);
    static private static com.seeyon.boot.util.excel.model.style.FontStyle buildFontStyle(java.lang.annotation.Annotation);
    static private static com.alibaba.excel.metadata.property.StyleProperty getStyleProperty(com.seeyon.boot.util.excel.model.style.CellStyle, com.alibaba.excel.metadata.property.StyleProperty);
    static private static com.alibaba.excel.metadata.property.FontProperty getFontProperty(com.seeyon.boot.util.excel.model.style.FontStyle, com.alibaba.excel.metadata.property.FontProperty);
    static private static com.alibaba.excel.metadata.property.StyleProperty getStyleProperty(java.lang.annotation.Annotation, com.alibaba.excel.metadata.property.StyleProperty);
    static private static com.alibaba.excel.metadata.property.FontProperty getFontProperty(java.lang.annotation.Annotation, com.alibaba.excel.metadata.property.FontProperty);
    static com.alibaba.excel.write.builder.ExcelWriterSheetBuilder buildHandlers(com.seeyon.boot.starter.excel.dto.SheetModelExtendDto, com.alibaba.excel.write.builder.ExcelWriterSheetBuilder, java.lang.Integer, java.lang.Integer);
    static private static com.alibaba.excel.write.builder.ExcelWriterSheetBuilder buildHandlers(java.lang.Class, com.alibaba.excel.write.builder.ExcelWriterSheetBuilder, java.util.List<com.seeyon.boot.util.excel.model.style.DataValidity>);
```

### `ExcelImportAppService`（12 方法）

`com.seeyon.boot.starter.excel.appservice.ExcelImportAppService`

```java
    com.seeyon.boot.transport.SingleResponse<java.util.Map<java.lang.String, java.lang.Object>> checkExcelDataV2(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.excel.dto.ExcelUploadRequestDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.String> checkExcelDataV1(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.excel.dto.ExcelUploadRequestDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.String> importExcelData(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.excel.dto.ExcelUploadRequestDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.String> importTransToGrid(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.excel.dto.ExcelUploadRequestDto>);
    com.seeyon.boot.starter.excel.dto.biz.ExcelExportDataDto checkExcelAndGetInfoData(com.seeyon.boot.starter.excel.dto.ExcelUploadRequestDto);
    private void checkExcelTemplate(java.util.List<java.lang.String>, java.lang.String, com.seeyon.boot.starter.excel.dto.ExcelExportTemplateDto, com.seeyon.boot.starter.excel.dto.biz.ExcelExportDataDto);
    private java.util.Map<java.lang.Integer, java.lang.Object> readExcelToObjectMap(java.io.InputStream);
    private com.seeyon.boot.starter.excel.dto.ExcelExportTemplateDto getExcelExportTemplateDto(java.util.Map<java.lang.Integer, java.lang.Object>);
```

### `ExcelTemplateCheckDto`（12 方法）

`com.seeyon.boot.starter.excel.dto.ExcelTemplateCheckDto`

```java
    java.lang.String getAppId();
    java.lang.String getMainFullName();
    java.lang.String getFieldFullName();
    java.lang.Boolean getIsUnique();
    java.lang.Boolean getIsNecessary();
    com.seeyon.boot.enums.ActionType getActionType();
    void setAppId(java.lang.String);
    void setMainFullName(java.lang.String);
    void setFieldFullName(java.lang.String);
    void setIsUnique(java.lang.Boolean);
    void setIsNecessary(java.lang.Boolean);
    void setActionType(com.seeyon.boot.enums.ActionType);
```

### `CascadeWriteHandler`（12 方法）

`com.seeyon.boot.starter.excel.event.Handler.CascadeWriteHandler`

```java
    void afterSheetCreate(com.alibaba.excel.write.metadata.holder.WriteWorkbookHolder, com.alibaba.excel.write.metadata.holder.WriteSheetHolder);
    void setHideSheet(java.lang.String, int, int, org.apache.poi.ss.usermodel.Workbook, java.util.List<java.lang.String>, java.util.List<java.lang.String>, java.util.Map<java.lang.String, java.util.List<java.lang.String>>);
    private void addConditionalFormatting(org.apache.poi.ss.usermodel.Sheet, java.util.Map<java.lang.Integer, java.util.List<java.lang.Integer>>, java.util.List<com.seeyon.boot.starter.excel.dto.ExcelCascadeDto>, int, java.lang.String, java.lang.String);
    private void setValidation(org.apache.poi.ss.usermodel.Sheet, org.apache.poi.ss.usermodel.DataValidationHelper, org.apache.poi.ss.usermodel.DataValidationConstraint, org.apache.poi.ss.util.CellRangeAddressList, java.lang.String, java.lang.String);
    int resolveStartRow(org.apache.poi.ss.usermodel.Sheet);
    java.lang.String buildCascadeRangeName(int);
    private java.lang.String buildLookupRangeName(java.lang.String, int);
    private void setOrCreateName(org.apache.poi.ss.usermodel.Workbook, java.lang.String, java.lang.String);
    java.lang.String buildIndirectFormula(java.lang.String, java.lang.String, java.util.List<java.lang.Integer>, java.lang.Integer, int);
    private java.lang.String getExcelColumn(int);
    java.lang.String getRange(int, int, int);
```

### `JsonUtil`（10 方法）

`com.seeyon.boot.starter.excel.utils.JsonUtil`

```java
    static java.lang.String getJson2String(java.lang.String);
    static com.fasterxml.jackson.databind.ObjectMapper instanceObjectMapper();
    static <K, V> java.util.Map<K, V> metadataToMap(java.lang.String, java.lang.Class<K>, java.lang.Class<V>, boolean);
    static java.util.List<java.util.List<com.seeyon.boot.starter.excel.dto.ExcelColumnDto>> convert2ExcelColumnDtoListList(java.lang.String);
    static java.util.Map<java.lang.String, com.seeyon.boot.starter.excel.dto.ExcelColumnDto> convert2ExcelColumnMap(java.util.List<com.seeyon.boot.starter.excel.dto.ExcelColumnDto>);
    static java.util.List<java.util.List<java.util.LinkedHashMap<java.lang.Integer, java.lang.Object>>> convert2ListListHashMapIntegerAndObj(java.lang.String);
    static java.util.List<com.seeyon.boot.starter.excel.dto.ExcelColumnDto> convert2StandardColumnListList(java.util.List<com.seeyon.boot.starter.excel.dto.ExcelColumnDto>);
```

### `ExcelImportUtil`（8 方法）

`com.seeyon.boot.starter.excel.utils.ExcelImportUtil`

```java
    static java.lang.String getImportValueType(com.seeyon.boot.starter.excel.dto.ExcelColumnDto);
    static java.lang.String ctpEnumExcel2Model(com.seeyon.boot.starter.excel.dto.ExcelColumnDto, java.lang.Object);
    static java.lang.Object enumExcel2Model(com.seeyon.boot.starter.excel.dto.ExcelColumnDto, java.lang.Object);
    static java.lang.Boolean booleanExcel2Model(com.seeyon.boot.starter.excel.dto.ExcelColumnDto, java.lang.Object);
    static java.lang.Object assExcel2Model(com.seeyon.boot.starter.excel.dto.ExcelColumnDto, java.lang.Object);
    static java.lang.Object dateExcel2Model(java.lang.Object, com.seeyon.boot.starter.excel.enums.Excel2ModelTypeEnum);
    static java.lang.Object dateTimeExcel2Model(java.lang.Object);
    static void initExcelData(java.util.List<java.util.LinkedHashMap<java.lang.Integer, java.lang.Object>>, java.util.List<com.seeyon.boot.starter.excel.dto.ExcelColumnDto>);
```

### `ExcelRedisCacheUtil`（8 方法）

`com.seeyon.boot.starter.excel.utils.ExcelRedisCacheUtil`

```java
    void put(java.lang.String, java.lang.String);
    java.lang.String get(java.lang.String);
    void putList(java.lang.String, java.util.List<java.lang.String>);
    java.util.List<java.lang.String> getList(java.lang.String);
    void remove(java.lang.String);
    void putHashValue(java.lang.String, java.lang.String, java.lang.Object);
    java.lang.String getHashValue(java.lang.String, java.lang.String);
    boolean hashKeyExists(java.lang.String, java.lang.String);
```

### `CascadeDropDownHandler`（7 方法）

`com.seeyon.boot.starter.excel.event.Handler.CascadeDropDownHandler`

```java
    void afterSheetCreate(com.alibaba.excel.write.metadata.holder.WriteWorkbookHolder, com.alibaba.excel.write.metadata.holder.WriteSheetHolder);
    private void setValidation(org.apache.poi.ss.usermodel.Sheet, org.apache.poi.ss.usermodel.DataValidationHelper, int, java.lang.String);
    private java.lang.String getExcelColumn(int);
    private void createName(org.apache.poi.ss.usermodel.Workbook, java.lang.String, java.lang.String);
    static private static java.lang.String generateRandomLetters(int);
    private java.lang.String cleanName(java.lang.String);
    private java.lang.String toColName(int);
```

### `CtpExcelTemplateUpgrade`（7 方法）

`com.seeyon.boot.starter.excel.upgrade.CtpExcelTemplateUpgrade`

```java
    int getOrder();
    void run();
    private void upgrade();
    java.util.Map<java.lang.String, com.seeyon.boot.starter.excel.upgrade.ApplicationDto> getApplicationListByNames(java.util.List<java.lang.String>);
    private com.seeyon.boot.starter.excel.upgrade.ApplicationDto buildApplicationDto(java.util.Map<java.lang.String, java.lang.Object>);
```

### `ExcelTemplateAuthQueryDto`（6 方法）

`com.seeyon.boot.starter.excel.dto.ExcelTemplateAuthQueryDto`

```java
    java.lang.String getMainFullName();
    java.lang.String getName();
    java.lang.Boolean getIsImport();
    void setMainFullName(java.lang.String);
    void setName(java.lang.String);
    void setIsImport(java.lang.Boolean);
```

### `CustomCellWriteHandlerHandler`（5 方法）

`com.seeyon.boot.starter.excel.event.Handler.CustomCellWriteHandlerHandler`

```java
    void afterCellDispose(com.alibaba.excel.write.metadata.holder.WriteSheetHolder, com.alibaba.excel.write.metadata.holder.WriteTableHolder, java.util.List<com.alibaba.excel.metadata.data.WriteCellData<?>>, org.apache.poi.ss.usermodel.Cell, com.alibaba.excel.metadata.Head, java.lang.Integer, java.lang.Boolean);
    void afterCellDataConverted(com.alibaba.excel.write.metadata.holder.WriteSheetHolder, com.alibaba.excel.write.metadata.holder.WriteTableHolder, com.alibaba.excel.metadata.data.WriteCellData<?>, org.apache.poi.ss.usermodel.Cell, com.alibaba.excel.metadata.Head, java.lang.Integer, java.lang.Boolean);
```

### `ExcelTemplateAuthDto`（4 方法）

`com.seeyon.boot.starter.excel.dto.ExcelTemplateAuthDto`

```java
    java.lang.Long getId();
    java.lang.String getAuthInfo();
    void setId(java.lang.Long);
    void setAuthInfo(java.lang.String);
```

### `SelectedSheetWriteHandler`（3 方法）

`com.seeyon.boot.starter.excel.event.Handler.SelectedSheetWriteHandler`

```java
    java.util.Map<java.lang.Integer, java.util.List<java.lang.String>> getSelectMap();
    void afterSheetCreate(com.alibaba.excel.write.metadata.holder.WriteWorkbookHolder, com.alibaba.excel.write.metadata.holder.WriteSheetHolder);
    private java.lang.String getExcelColumn(int);
```

### `CtpI18NDataUtil`（3 方法）

`com.seeyon.boot.starter.excel.utils.CtpI18NDataUtil`

```java
    static java.lang.String showCurrentLocaleValue(java.lang.String);
    static boolean isCtpI18NData(java.lang.String);
    static java.lang.String getCtpEnumCurrLocalValue(java.lang.String, java.util.Locale);
```

### `ExcelLocalCacheUtil`（3 方法）

`com.seeyon.boot.starter.excel.utils.ExcelLocalCacheUtil`

```java
    T get(java.lang.String);
    void put(java.lang.String, T);
    void remove(java.lang.String);
```

## 四、枚举（2）

- `Excel2ModelTypeEnum`（2 常量）：UDC_DB, UDC_DESIGN
- `ExcelTemplateTypeEnum`（2 常量）：METADATA, DIY
