# boot-starter-artifact：接口与方法签名

> 自动生成，勿手改。`tools/core/platform/emit_package_surfaces.py` 重跑即可。
> 构件 `com.seeyon:boot-starter-artifact`（jar `boot-starter-artifact-5.3.600.jar`）
> 规模：16 类 / 2 接口 / 0 注解 / 1 枚举 / 4 个关键类 / 96 方法。
> 签名逐字来自 javap 原文；已去掉 `public` 前缀与 `throws` 子句。

## 一、接口（2）

### `MavenArtifactService`（4 方法）

`com.seeyon.boot.starter.artifact.service.MavenArtifactService`

```java
    com.seeyon.boot.starter.artifact.service.MavenTypeEnum getMavenType();
    boolean upload(com.seeyon.boot.starter.artifact.service.ArtifactDto)
    java.lang.String download(com.seeyon.boot.starter.artifact.service.ArtifactDto)
    default java.lang.String getMvnBasePath();
```

### `CtpArtifactUploadDao`（0 方法） extends CtpArtifactUpload>

`com.seeyon.boot.starter.artifact.domain.dao.CtpArtifactUploadDao`

```java
```

## 二、关键类（4）

### `MavenStorageService`（10 方法）

`com.seeyon.boot.starter.artifact.service.MavenStorageService`

```java
    static private static com.seeyon.boot.starter.artifact.service.ArtifactDto parseCoordinate(java.lang.String);
    static private static java.lang.String buildCoordinatePath(com.seeyon.boot.starter.artifact.service.ArtifactDto);
    java.lang.String getStorageType();
    void init(com.seeyon.boot.starter.file.storage.StorageProperties, java.lang.String);
    void shutdown();
    com.seeyon.boot.starter.file.dto.response.UploadResultDto upload(com.seeyon.boot.starter.file.dto.request.StorageUploadRequestDto);
    boolean delete(java.lang.String);
    boolean exist(java.lang.String);
    java.io.InputStream download(java.lang.String);
    private java.lang.String getFileCrc32(java.io.File);
```

### `CommonModelServiceImpl`（8 方法）

`com.seeyon.boot.starter.artifact.service.common.CommonModelServiceImpl`

```java
    com.seeyon.boot.starter.artifact.service.MavenTypeEnum getMavenType();
    boolean upload(com.seeyon.boot.starter.artifact.service.ArtifactDto);
    java.lang.String download(com.seeyon.boot.starter.artifact.service.ArtifactDto);
    private org.eclipse.aether.repository.RemoteRepository getRemoteRepository(java.lang.String);
    void afterPropertiesSet()
    private org.eclipse.aether.RepositorySystem getRepositorySystem();
    private org.eclipse.aether.RepositorySystemSession getSession(org.eclipse.aether.RepositorySystem, java.lang.String);
```

### `OssModelServiceImpl`（6 方法）

`com.seeyon.boot.starter.artifact.service.oss.OssModelServiceImpl`

```java
    com.seeyon.boot.starter.artifact.service.MavenTypeEnum getMavenType();
    boolean upload(com.seeyon.boot.starter.artifact.service.ArtifactDto);
    java.lang.String download(com.seeyon.boot.starter.artifact.service.ArtifactDto);
    void afterPropertiesSet()
    java.lang.String buildCoordinatePath(com.seeyon.boot.starter.artifact.service.ArtifactDto);
    java.lang.String buildCoordinatePathPom(java.lang.String);
```

### `BootArtifactManager`（3 方法）

`com.seeyon.boot.starter.artifact.service.BootArtifactManager`

```java
    boolean upload(com.seeyon.boot.starter.artifact.service.ArtifactDto);
    java.lang.String download(com.seeyon.boot.starter.artifact.service.ArtifactDto);
    void afterPropertiesSet();
```

## 四、枚举（1）

- `MavenTypeEnum`（2 常量）：common, bucket
