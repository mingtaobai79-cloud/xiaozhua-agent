# boot-starter-formconvert：接口与方法签名

> 自动生成，勿手改。`tools/core/platform/emit_package_surfaces.py` 重跑即可。
> 构件 `com.seeyon:boot-starter-formconvert`（jar `boot-starter-formconvert-5.3.600.jar`）
> 规模：40 类 / 2 接口 / 0 注解 / 1 枚举 / 17 个关键类 / 402 方法。
> 签名逐字来自 javap 原文；已去掉 `public` 前缀与 `throws` 子句。

## 一、接口（2）

### `FormConvertCategoryDao`（0 方法） extends FormConvertCategory>

`com.seeyon.boot.starter.formconvert.domain.dao.FormConvertCategoryDao`

```java
```

### `FormConvertTemplateDao`（0 方法） extends FormConvertTemplate>

`com.seeyon.boot.starter.formconvert.domain.dao.FormConvertTemplateDao`

```java
```

## 二、关键类（17）

### `FormConvertUtil`（34 方法）

`com.seeyon.boot.starter.formconvert.utils.FormConvertUtil`

```java
    static java.util.List<java.lang.Object> invokeSelectListDynamicMethod(java.lang.String, com.seeyon.boot.transport.ListRequest);
    static java.lang.Integer invokeUpdateDynamicMethod(java.lang.String, java.lang.Object);
    static java.lang.Object invokeSelectByIdDynamicMethod(java.lang.String, java.lang.Long);
    static private static java.lang.String getInterfaceNameByEntityFullName(java.lang.String, java.lang.String);
    static private static java.lang.String fullNameToAppName(java.lang.String);
    static java.lang.Object getEntityAppServiceName(java.lang.String);
    static private static com.seeyon.boot.starter.formconvert.domain.service.FormConvertMetaDataAppServiceProxy getFormConvertMetaDataAppServiceProxy();
    static void buildFormConvertData(java.lang.Object, java.util.List<com.seeyon.boot.starter.formconvert.dto.FormConvertFieldDto>, com.seeyon.ctp.metadata.dto.AggEntityMetadataDto, java.util.Map<java.lang.String, java.util.Map<java.lang.String, com.seeyon.ctp.metadata.dto.model.JavaEnumItemDto>>);
    static void buildFormConvertSubTableData(java.lang.Object, java.util.Map<java.lang.String, java.util.List<java.util.List<com.seeyon.boot.starter.formconvert.dto.FormConvertFieldDto>>>, com.seeyon.ctp.metadata.dto.AggEntityMetadataDto, java.util.Map<java.lang.String, java.util.Map<java.lang.String, com.seeyon.ctp.metadata.dto.model.JavaEnumItemDto>>);
    static java.util.List<java.lang.String> getReferDisplayField(java.lang.String, java.lang.String);
    static void setFieldValue(java.lang.Object, java.lang.String, java.lang.String, java.lang.String, java.lang.String);
    static void setSubFieldValue(java.lang.Object, java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.Long, java.lang.String, java.lang.String);
    static void getHeader(com.seeyon.boot.util.excel.model.SheetModel, java.lang.String);
    static void setCellStyle(com.seeyon.boot.util.excel.model.style.CellStyle);
    static java.lang.String entityToAppServiceName(java.lang.String);
    static java.lang.String transFirstCharToLowerCase(java.lang.String);
    static java.lang.String entityFullNameToDtoFullName(java.lang.String);
    static java.lang.String fullNameToSingleName(java.lang.String);
    static java.lang.String entityFullNameToDtoList(java.lang.String, java.lang.String);
    static java.lang.String dtoToEntityFullName(java.lang.String, java.lang.String);
    static <T> java.util.function.Predicate<T> distinctByKey(java.util.function.Function<? super T, java.lang.Object>);
    static <T> java.util.List<T> deepCopy(java.util.List<T>)
    static java.lang.String selectCurrentLocaleName(java.lang.String);
    static byte[] readBytesFromInputStream(java.io.InputStream);
    static java.lang.String replaceAppName(java.lang.String, java.lang.String);
    static java.lang.String parseEntityAppName(java.lang.String);
    static java.lang.Boolean isApprovalApp(java.lang.String);
```

### `FormConvertTemplate`（30 方法）

`com.seeyon.boot.starter.formconvert.domain.entity.FormConvertTemplate`

```java
    java.lang.String getName();
    java.lang.String getCode();
    java.lang.String getAppId();
    java.lang.String getAppGuid();
    java.lang.String getEntityFullName();
    java.lang.String getStorageKey();
    java.lang.Long getCreateUserId();
    java.lang.Long getCreateOrgId();
    java.lang.String getRule();
    java.lang.String getDynamicTitle();
    java.lang.Boolean getEnable();
    java.lang.Boolean getDeleteFlag();
    java.lang.Boolean getPreset();
    java.lang.Boolean getConvertImage();
    java.lang.String getImageConfig();
    void setName(java.lang.String);
    void setCode(java.lang.String);
    void setAppId(java.lang.String);
    void setAppGuid(java.lang.String);
    void setEntityFullName(java.lang.String);
    void setStorageKey(java.lang.String);
    void setCreateUserId(java.lang.Long);
    void setCreateOrgId(java.lang.Long);
    void setRule(java.lang.String);
    void setDynamicTitle(java.lang.String);
    void setEnable(java.lang.Boolean);
    void setDeleteFlag(java.lang.Boolean);
    void setPreset(java.lang.Boolean);
    void setConvertImage(java.lang.Boolean);
    void setImageConfig(java.lang.String);
```

### `FormConvertAppService`（29 方法）

`com.seeyon.boot.starter.formconvert.appservice.FormConvertAppService`

```java
    com.seeyon.boot.transport.SingleResponse<java.lang.String> formConvertMicro(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.formconvert.dto.FormConvertDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.boot.starter.file.dto.FileDto> formConvert(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.formconvert.dto.FormConvertDto>);
    java.lang.String getDynamicTitle(java.lang.String, java.util.List<com.seeyon.boot.starter.formconvert.dto.FormConvertFieldDto>, java.lang.String);
    private void generateContractMap(java.util.List<com.seeyon.boot.starter.formconvert.dto.FormConvertFieldDto>, java.util.Map<java.lang.String, java.util.List<java.util.List<com.seeyon.boot.starter.formconvert.dto.FormConvertFieldDto>>>, java.util.Map<java.lang.String, com.seeyon.boot.starter.formconvert.dto.FormConvertFieldDto>, java.util.Map<java.lang.String, java.util.List<java.util.Map<java.lang.String, com.seeyon.boot.starter.formconvert.dto.FormConvertFieldDto>>>, java.lang.String, java.util.List<com.seeyon.boot.starter.formconvert.dto.FormConvertTemplateDto>, java.util.List<java.lang.String>);
    private void dataToMap(java.util.List<com.seeyon.boot.starter.formconvert.dto.FormConvertFieldDto>, java.util.Map<java.lang.String, com.seeyon.boot.starter.formconvert.dto.FormConvertFieldDto>, java.util.Map<java.lang.String, com.seeyon.ctp.metadata.dto.EntityAttributeMetadataDto>, java.util.List<com.seeyon.boot.starter.formconvert.dto.FormConvertTemplateDto>);
    private void setContentComponent(com.seeyon.boot.starter.formconvert.dto.FormConvertFieldDto);
    private void setImageBytesList(com.seeyon.boot.starter.formconvert.dto.FormConvertFieldDto, java.util.List<com.seeyon.boot.starter.formconvert.dto.FormConvertTemplateDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.boot.starter.formconvert.dto.FormConvertBatchDto> formConvertBatch(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.formconvert.dto.FormConvertBatchDto>);
    void dealEntityData(java.util.List<com.seeyon.boot.starter.formconvert.dto.FormConvertFieldDto>, java.util.Map<java.lang.String, java.util.List<java.util.List<com.seeyon.boot.starter.formconvert.dto.FormConvertFieldDto>>>, java.lang.Object, java.util.Map<java.lang.String, java.util.Map<java.lang.String, com.seeyon.ctp.metadata.dto.model.JavaEnumItemDto>>, com.seeyon.ctp.metadata.dto.AggEntityMetadataDto);
    java.util.Map<java.lang.String, java.util.Map<java.lang.String, com.seeyon.ctp.metadata.dto.model.JavaEnumItemDto>> getEnumMap(java.lang.String, com.seeyon.ctp.metadata.dto.AggEntityMetadataDto);
    com.seeyon.boot.transport.ListResponse<com.seeyon.boot.starter.formconvert.dto.FormConvertTemplateDto> selectApplyTemplateByEntityId(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.formconvert.dto.FormConvertTemplateSearchDto>);
```

### `FormConvertTemplateDto`（28 方法）

`com.seeyon.boot.starter.formconvert.dto.FormConvertTemplateDto`

```java
    java.lang.String getName();
    java.lang.String getCode();
    java.lang.String getAppId();
    java.lang.String getAppGuid();
    java.lang.String getEntityFullName();
    java.lang.String getStorageKey();
    java.lang.Long getCreateUserId();
    java.lang.Long getCreateOrgId();
    java.lang.String getRule();
    java.lang.String getDynamicTitle();
    java.lang.Boolean getEnable();
    java.lang.Boolean getPreset();
    java.lang.Boolean getConvertImage();
    java.lang.String getImageConfig();
    void setName(java.lang.String);
    void setCode(java.lang.String);
    void setAppId(java.lang.String);
    void setAppGuid(java.lang.String);
    void setEntityFullName(java.lang.String);
    void setStorageKey(java.lang.String);
    void setCreateUserId(java.lang.Long);
    void setCreateOrgId(java.lang.Long);
    void setRule(java.lang.String);
    void setDynamicTitle(java.lang.String);
    void setEnable(java.lang.Boolean);
    void setPreset(java.lang.Boolean);
    void setConvertImage(java.lang.Boolean);
    void setImageConfig(java.lang.String);
```

### `FormConvertMetaDataAppServiceProxy`（18 方法）

`com.seeyon.boot.starter.formconvert.domain.service.FormConvertMetaDataAppServiceProxy`

```java
    com.seeyon.ctp.metadata.dto.AggEntityMetadataDto selectAggEntityMetadataByFullName(java.lang.String, java.lang.String);
    com.seeyon.boot.transport.SingleResponse<java.lang.Object> invokeAppService(java.lang.String, java.lang.String, java.lang.String, java.lang.Object, java.lang.String);
    private com.seeyon.boot.transport.ListResponse<java.lang.Object> invokeForList(java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.Object);
    java.lang.String getLatestDocStorageKey(com.seeyon.boot.starter.formconvert.dto.DocFileInfoRequestDto);
    java.util.List<com.seeyon.ctp.metadata.dto.EntityMetadataDto> selectEntityMetadataByFullNames(java.lang.String, java.util.List<java.lang.String>);
    com.seeyon.ctp.metadata.dto.AggDtoMetadataDto selectAggDtoMetadataByFullName(com.seeyon.ctp.metadata.dto.request.SearchByFullNameDto);
    java.util.List<com.seeyon.ctp.metadata.dto.EnumMetadataDto> selectEnumMetadataByFullNames(java.lang.String, java.util.List<java.lang.String>);
    com.seeyon.ctp.metadata.dto.EnumMetadataDto selectEnumMetadataByFullName(java.lang.String, java.lang.String);
    java.util.List<com.seeyon.ctp.metadata.dto.ReferMetadataDto> selectReferMetadataByEntity(java.lang.String, java.lang.String);
    void upgradeFormConvertAppGuid(java.util.Map<java.lang.String, java.lang.Object>);
    private void doUpgrade(java.util.List<com.seeyon.boot.starter.formconvert.domain.entity.FormConvertCategory>, java.util.Map<java.lang.String, java.lang.Object>);
    com.seeyon.ctp.metadata.dto.ServiceMetadataDto selectServiceMetadataByName(java.lang.String);
```

### `WordSwatchUtils`（16 方法）

`com.seeyon.boot.starter.formconvert.utils.WordSwatchUtils`

```java
    static private static java.io.InputStream getLicense()
    static void addBookMarks(java.util.List<java.io.File>, java.io.File, java.util.Map<java.lang.String, com.seeyon.boot.starter.formconvert.dto.FormConvertFieldDto>, java.util.Map<java.lang.String, java.util.List<java.util.Map<java.lang.String, com.seeyon.boot.starter.formconvert.dto.FormConvertFieldDto>>>, java.lang.String, java.util.Map<java.lang.String, java.lang.Long>, java.util.List<java.lang.String>)
    static private static void docGenerateSubData(java.util.List<java.io.File>, java.io.File, java.util.Map<java.lang.String, com.seeyon.boot.starter.formconvert.dto.FormConvertFieldDto>, java.util.Map<java.lang.String, java.util.List<java.util.Map<java.lang.String, com.seeyon.boot.starter.formconvert.dto.FormConvertFieldDto>>>, int, java.util.Map<java.lang.String, java.lang.Long>, java.util.List<java.lang.String>)
    static void removeWatermark(com.aspose.words.Document)
    static private static void setLicense();
    static void removeWatermark();
    static private static void removeWatermarkFromHeader(com.aspose.words.Section, int)
    static private static void generateMasterDataByType(java.util.Map<java.lang.String, com.seeyon.boot.starter.formconvert.dto.FormConvertFieldDto>, com.aspose.words.Document, java.lang.Long);
    static private static void generateOne2OneSubDataByType(java.util.Map<java.lang.String, com.seeyon.boot.starter.formconvert.dto.FormConvertFieldDto>, com.aspose.words.Document, java.lang.String, java.lang.Long);
    static private static void setValueByType(com.aspose.words.DocumentBuilder, java.lang.String, com.seeyon.boot.starter.formconvert.dto.FormConvertFieldDto, com.aspose.words.Paragraph, java.lang.Long);
    static private static java.lang.Double getHeightOrWidthByUnit(java.lang.Double, com.seeyon.boot.starter.formconvert.enums.PictureUnitEnum);
```

### `FormConvertTemplateService`（13 方法）

`com.seeyon.boot.starter.formconvert.domain.service.FormConvertTemplateService`

```java
    java.lang.Long create(com.seeyon.boot.starter.formconvert.dto.FormConvertTemplateDto);
    java.lang.Integer createBatchForAppApproval(java.util.List<com.seeyon.boot.starter.formconvert.dto.FormConvertTemplateDto>);
    java.lang.Integer update(com.seeyon.boot.starter.formconvert.dto.FormConvertTemplateDto);
    java.lang.Integer deleteById(java.lang.Long);
    java.lang.Integer deleteByIds(java.util.List<java.lang.Long>);
    com.seeyon.boot.starter.formconvert.dto.FormConvertTemplateDto selectById(java.lang.Long);
    java.util.List<com.seeyon.boot.starter.formconvert.dto.FormConvertTemplateDto> selectByIds(java.util.List<java.lang.Long>);
    java.util.List<com.seeyon.boot.starter.formconvert.dto.FormConvertTemplateDto> selectListByConditions(java.util.Map<java.lang.String, java.lang.Object>, com.seeyon.boot.transport.Sort);
    com.seeyon.boot.transport.PageData<com.seeyon.boot.starter.formconvert.dto.FormConvertTemplateDto> selectPageByConditions(com.seeyon.boot.transport.PageInfo, java.util.Map<java.lang.String, java.lang.Object>, com.seeyon.boot.transport.Sort);
    int updateBatchWithOutVersion(java.util.List<com.seeyon.boot.starter.formconvert.domain.entity.FormConvertCategory>);
```

### `FormConvertTemplateAppService`（11 方法）

`com.seeyon.boot.starter.formconvert.appservice.FormConvertTemplateAppService`

```java
    com.seeyon.boot.transport.SingleResponse<java.lang.Long> create(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.formconvert.dto.FormConvertTemplateDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> createBatchForAppApproval(java.util.List<com.seeyon.boot.starter.formconvert.dto.FormConvertTemplateDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> deleteByIds(com.seeyon.boot.transport.SingleRequest<java.util.List<java.lang.Long>>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> update(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.formconvert.dto.FormConvertTemplateDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.boot.starter.formconvert.dto.FormConvertTemplateDto> selectById(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.boot.starter.formconvert.dto.FormConvertTemplateDto> selectListByConditions(com.seeyon.boot.transport.ListRequest);
    com.seeyon.boot.transport.PageResponse<com.seeyon.boot.starter.formconvert.dto.FormConvertTemplateDto> selectPageByConditions(com.seeyon.boot.transport.PageRequest);
    com.seeyon.boot.transport.ListResponse<com.seeyon.boot.starter.formconvert.dto.FormConvertTemplateDto> selectApplyTemplate(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.formconvert.dto.FormConvertTemplateSearchDto>);
    java.util.List<com.seeyon.boot.starter.formconvert.dto.FormConvertTemplateDto> getApplyTemplate(java.util.Map<java.lang.String, java.lang.Object>, java.util.List<com.seeyon.boot.starter.formconvert.dto.FormConvertTemplateDto>);
    java.util.Map<java.lang.String, java.lang.Object> getEntityData(java.lang.Long, java.lang.String);
```

### `FormConvertConditionParamExprService`（11 方法）

`com.seeyon.boot.starter.formconvert.domain.service.FormConvertConditionParamExprService`

```java
    java.util.List<com.seeyon.boot.starter.formula.dto.variable.SchemaStructureDto> loadParamSchemaInfo(com.seeyon.boot.starter.formula.dto.variable.VariableSchemaLoadDto);
    private void builderParameter(com.seeyon.boot.starter.formula.dto.variable.VariableSchemaLoadDto, java.util.List<com.seeyon.boot.starter.formula.dto.variable.SchemaStructureDto>, com.seeyon.boot.starter.formconvert.domain.service.FormConvertConditionEntitySchemaBuilder);
    private com.seeyon.boot.starter.formula.dto.variable.SchemaStructureDto transParameter2Schema(com.seeyon.boot.starter.formconvert.domain.service.FormConvertConditionEntitySchemaBuilder, com.seeyon.ctp.metadata.dto.EntityAttributeMetadataDto, boolean, java.util.List<com.seeyon.ctp.metadata.dto.EnumMetadataDto>);
    private java.lang.String getDataType(java.lang.String);
    com.seeyon.ctp.metadata.dto.AggEntityMetadataDto selectAggEntityMetadataByFullName(java.lang.String, java.lang.String, boolean);
    com.seeyon.boot.transport.SingleResponse<java.lang.Object> invokeAppService(java.lang.String, java.lang.String, java.lang.String, java.lang.Object, java.lang.String);
    java.util.List<com.seeyon.ctp.metadata.dto.EnumMetadataDto> selectDesignMetadataEnums(java.lang.String, java.util.List<java.lang.String>);
```

### `FormConvertImageConfigDto`（10 方法）

`com.seeyon.boot.starter.formconvert.dto.FormConvertImageConfigDto`

```java
    java.lang.String getFieldFullName();
    java.lang.Double getHeight();
    com.seeyon.boot.starter.formconvert.enums.PictureUnitEnum getHeightUnit();
    java.lang.Double getWidth();
    com.seeyon.boot.starter.formconvert.enums.PictureUnitEnum getWidthUnit();
    void setFieldFullName(java.lang.String);
    void setHeight(java.lang.Double);
    void setHeightUnit(com.seeyon.boot.starter.formconvert.enums.PictureUnitEnum);
    void setWidth(java.lang.Double);
    void setWidthUnit(com.seeyon.boot.starter.formconvert.enums.PictureUnitEnum);
```

### `FormConvertCategoryService`（9 方法）

`com.seeyon.boot.starter.formconvert.domain.service.FormConvertCategoryService`

```java
    java.lang.Long create(com.seeyon.boot.starter.formconvert.dto.FormConvertCategoryDto);
    java.lang.Integer createBatchForAppApproval(java.util.List<com.seeyon.boot.starter.formconvert.dto.FormConvertCategoryDto>);
    java.lang.Integer deleteById(java.lang.Long);
    java.util.List<com.seeyon.boot.starter.formconvert.dto.FormConvertCategoryDto> selectByAppId(java.lang.String);
    java.util.List<com.seeyon.boot.starter.formconvert.dto.FormConvertCategoryDto> selectListByConditions(java.util.Map<java.lang.String, java.lang.Object>, com.seeyon.boot.transport.Sort);
    void checkEntityFullName(java.lang.String, java.lang.String);
    java.util.List<com.seeyon.boot.starter.formconvert.domain.entity.FormConvertCategory> selectUpgradeListByWrapperIgnoreTenant();
    int updateBatchWithOutVersion(java.util.List<com.seeyon.boot.starter.formconvert.domain.entity.FormConvertCategory>);
```

### `FormConvertConditionEntitySchemaBuilder`（9 方法）

`com.seeyon.boot.starter.formconvert.domain.service.FormConvertConditionEntitySchemaBuilder`

```java
    private void initEntityFieldToContinueParse();
    private void initExcludeFields();
    private void initEntityReference();
    private void initEntityReverseReference();
    com.seeyon.boot.starter.formula.dto.variable.SchemaStructureDto build(java.lang.String, boolean, java.lang.String, java.lang.String, java.lang.Boolean);
    private com.seeyon.boot.starter.formula.dto.variable.SchemaStructureDto parse(com.seeyon.ctp.metadata.dto.AggEntityMetadataDto, java.lang.Boolean);
    private void buildIdReference(java.lang.String, com.seeyon.boot.starter.formula.dto.variable.SchemaStructureDto);
    private com.seeyon.boot.starter.formula.dto.ControlData getControlData(java.lang.String);
    private com.seeyon.boot.starter.formula.dto.variable.SchemaStructureDto decorateSchema(com.seeyon.boot.starter.formula.dto.variable.SchemaStructureDto, boolean, java.lang.String, java.lang.String);
```

### `I18nUtil`（8 方法）

`com.seeyon.boot.starter.formconvert.utils.I18nUtil`

```java
    static java.lang.String getCurrentLocaleData(java.lang.String);
    static java.lang.String getDataI18n(java.lang.String, java.lang.String...);
    static java.lang.String getDataI18nStr(java.lang.String);
    static java.lang.String millis2DateDataI18n(java.lang.Long);
    static java.lang.String mergeDataI18n(java.lang.String, java.util.List<java.lang.String>);
    static java.util.Map<java.lang.String, java.lang.Object> getParams(java.lang.String...);
```

### `FormConvertTemplateController`（7 方法）

`com.seeyon.boot.starter.formconvert.controller.FormConvertTemplateController`

```java
    com.seeyon.boot.transport.SingleResponse<java.lang.Long> create(com.seeyon.boot.starter.formconvert.dto.FormConvertTemplateDto);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> deleteByIds(java.util.List<java.lang.Long>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> update(com.seeyon.boot.starter.formconvert.dto.FormConvertTemplateDto);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.boot.starter.formconvert.dto.FormConvertTemplateDto> selectById(java.lang.Long);
    com.seeyon.boot.transport.ListResponse<com.seeyon.boot.starter.formconvert.dto.FormConvertTemplateDto> selectApplyTemplate(com.seeyon.boot.starter.formconvert.dto.FormConvertTemplateSearchDto);
    com.seeyon.boot.transport.ListResponse<com.seeyon.boot.starter.formconvert.dto.FormConvertTemplateDto> selectByConditions(java.util.Map<java.lang.String, java.lang.Object>, com.seeyon.boot.transport.Sort);
    com.seeyon.boot.transport.PageResponse<com.seeyon.boot.starter.formconvert.dto.FormConvertTemplateDto> selectPageByConditions(com.seeyon.boot.transport.PageInfo, java.util.Map<java.lang.String, java.lang.Object>, com.seeyon.boot.transport.Sort);
```

### `FormConvertTemplateSearchDto`（6 方法）

`com.seeyon.boot.starter.formconvert.dto.FormConvertTemplateSearchDto`

```java
    java.lang.Long getEntityId();
    java.lang.String getEntityFullName();
    java.util.Map<java.lang.String, java.lang.Object> getObject();
    void setEntityId(java.lang.Long);
    void setEntityFullName(java.lang.String);
    void setObject(java.util.Map<java.lang.String, java.lang.Object>);
```

### `FormConvertCategoryAppService`（5 方法）

`com.seeyon.boot.starter.formconvert.appservice.FormConvertCategoryAppService`

```java
    com.seeyon.boot.transport.SingleResponse<java.lang.Long> create(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.formconvert.dto.FormConvertCategoryDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> createBatchForAppApproval(java.util.List<com.seeyon.boot.starter.formconvert.dto.FormConvertCategoryDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> deleteById(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.boot.starter.formconvert.dto.FormConvertCategoryDto> selectByAppId(com.seeyon.boot.transport.SingleRequest<java.lang.String>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.boot.starter.formconvert.dto.FormConvertCategoryDto> selectListByConditions(com.seeyon.boot.transport.ListRequest);
```

### `FormConvertTemplateUpdateListener`（3 方法）

`com.seeyon.boot.starter.formconvert.domain.event.listener.FormConvertTemplateUpdateListener`

```java
    void onUpdateFormConvertTemplate(com.seeyon.boot.starter.formconvert.domain.event.FormConvertTemplateUpdateEvent);
    void onCreateFormConvertTemplate(com.seeyon.boot.starter.formconvert.domain.event.FormConvertTemplateCreateEvent);
    void onDeleteFormConvertTemplate(com.seeyon.boot.starter.formconvert.domain.event.FormConvertTemplateDeleteEvent);
```

## 四、枚举（1）

- `PictureUnitEnum`（2 常量）：CM, PX
