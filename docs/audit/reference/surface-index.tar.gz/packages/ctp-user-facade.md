# ctp-user-facade：接口与方法签名

> 自动生成，勿手改。`tools/core/platform/emit_package_surfaces.py` 重跑即可。
> 构件 `com.seeyon:ctp-user-facade`（jar `ctp-user-facade-5.3.429.jar`）
> 规模：263 类 / 44 接口 / 0 注解 / 54 枚举 / 11 个关键类 / 2987 方法。
> 签名逐字来自 javap 原文；已去掉 `public` 前缀与 `throws` 子句。

## 一、接口（44）

### `CtpUserPermissionCommonAppService`（19 方法）

`com.seeyon.ctp.user.api.common.CtpUserPermissionCommonAppService`

```java
    com.seeyon.boot.transport.ListResponse<java.lang.String> selectUserResourceCode(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.user.dto.CtpUserResourceSearchDto>);
    default com.seeyon.boot.transport.SingleResponse<java.util.Map<java.lang.String, java.util.Set<java.lang.String>>> selectUserResourceCodesMap(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.user.dto.CtpUserResourceSearchMapDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Boolean> checkUserResourceCode(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.user.dto.CtpUserResourceSearchDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.ctp.user.dto.CtpUserResourceDto> selectUserResource(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.user.dto.CtpUserResourceSearchDto>);
    default com.seeyon.boot.transport.ListResponse<com.seeyon.ctp.user.dto.CtpUserResourceDto> selectUserResourceProperties(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.user.dto.CtpUserResourceSearchDto>);
    com.seeyon.boot.transport.PageResponse<com.seeyon.ctp.user.dto.CtpUserResourceDto> selectUserResource(com.seeyon.boot.transport.PageInfo, com.seeyon.ctp.user.dto.CtpUserResourceSearchDto);
    com.seeyon.boot.transport.SingleResponse<java.util.Map<java.lang.String, java.lang.Boolean>> checkUserResource(com.seeyon.boot.transport.SingleRequest<java.util.List<com.seeyon.ctp.user.dto.CheckResourcePermissionDto>>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Boolean> checkUserAppPermission(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.user.dto.CtpUserAppPermissionDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.ctp.user.dto.CtpResourceSecurityDto> selectControlMenus(com.seeyon.boot.transport.SingleRequest<java.util.Map<java.lang.String, java.lang.Object>>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.ctp.user.dto.CtpUserResourceSecurityDto> selectUserMenus(com.seeyon.boot.transport.SingleRequest<java.util.Map<java.lang.String, java.lang.Object>>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.ctp.user.dto.CtpResourceDto> selectAdminMenus(com.seeyon.boot.transport.SingleRequest<java.util.Map<java.lang.String, java.lang.Object>>);
    com.seeyon.boot.transport.ListResponse<java.lang.String> selectUserRoleCode(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.ListResponse<java.lang.String> selectUserRoleCodeByOrg(com.seeyon.boot.transport.SingleRequest<java.util.Map<java.lang.String, java.lang.Object>>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.ctp.user.dto.CtpUserRoleDto> selectUserRole(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.ctp.user.dto.CtpUserDataPermissionDto> selectUserDataPermission(com.seeyon.boot.transport.SingleRequest<java.util.Map<java.lang.String, java.lang.Object>>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Boolean> hasAdminRole(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.ListResponse<java.lang.Long> selectAdminOrgIdList(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    default com.seeyon.boot.transport.SingleResponse<java.util.Map<java.lang.String, java.lang.Object>> selectOrgAdminResourceAction(com.seeyon.boot.transport.SingleRequest<java.util.Map<java.lang.String, java.lang.Object>>);
    default com.seeyon.boot.transport.SingleResponse<java.lang.Boolean> checkOrgAdminPermission(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.user.dto.CheckOrgAdminPermissionDto>);
```

### `CtpUserCoreAppService`（18 方法）

`com.seeyon.ctp.user.api.core.CtpUserCoreAppService`

```java
    com.seeyon.boot.transport.SingleResponse<java.lang.Boolean> beforeCreateCheck(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.user.dto.CtpUserDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Long> create(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.user.dto.CtpUserDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> createBatch(com.seeyon.boot.transport.SingleRequest<java.util.List<com.seeyon.ctp.user.dto.CtpUserDto>>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Boolean> beforeUpdateCheck(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.user.dto.CtpUserDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> update(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.user.dto.CtpUserDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> updateBatch(com.seeyon.boot.transport.SingleRequest<java.util.List<com.seeyon.ctp.user.dto.CtpUserDto>>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.ctp.user.dto.CtpUserDto> selectById(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.ctp.user.dto.CtpUserDto> selectByIds(com.seeyon.boot.transport.SingleRequest<java.util.List<java.lang.Long>>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.ctp.user.dto.CtpUserSimpleDto> selectSimpleByIds(com.seeyon.boot.transport.SingleRequest<java.util.List<java.lang.Long>>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.ctp.user.dto.CtpUserDto> selectOneByCondition(com.seeyon.boot.transport.SingleRequest<java.util.Map<java.lang.String, java.lang.Object>>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.ctp.user.dto.CtpUserDto> selectListByConditions(com.seeyon.boot.transport.ListRequest);
    com.seeyon.boot.transport.PageResponse<com.seeyon.ctp.user.dto.CtpUserDto> selectPageByConditions(com.seeyon.boot.transport.PageRequest);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.ctp.user.dto.CtpUserDto> selectUserIgnoreTenant(com.seeyon.boot.transport.SingleRequest<java.util.Map<java.lang.String, java.lang.Object>>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.ctp.user.message.dto.SyncUserMessageDto> syncCreateBatch(com.seeyon.boot.transport.SingleRequest<java.util.List<com.seeyon.ctp.user.dto.CtpUserDto>>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.ctp.user.message.dto.SyncUserMessageDto> syncUpdateBatch(com.seeyon.boot.transport.SingleRequest<java.util.List<com.seeyon.ctp.user.dto.CtpUserDto>>);
    default com.seeyon.boot.transport.ListResponse<com.seeyon.ctp.user.message.dto.SyncUserMessageDto> syncCreateBatchCheck(com.seeyon.boot.transport.SingleRequest<java.util.List<com.seeyon.ctp.user.dto.CtpUserDto>>);
    default com.seeyon.boot.transport.ListResponse<com.seeyon.ctp.user.message.dto.SyncUserMessageDto> syncUpdateBatchCheck(com.seeyon.boot.transport.SingleRequest<java.util.List<com.seeyon.ctp.user.dto.CtpUserDto>>);
    default com.seeyon.boot.transport.SingleResponse<java.util.Map<java.lang.Long, java.util.List<com.seeyon.ctp.user.message.dto.UserTenantInfoDto>>> selectUserTenantInfoByIds(com.seeyon.boot.transport.SingleRequest<java.util.List<java.lang.Long>>);
```

### `CtpManagerTenantAppService`（14 方法）

`com.seeyon.ctp.manager.api.CtpManagerTenantAppService`

```java
    com.seeyon.boot.transport.SingleResponse<java.lang.Long> create(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.manager.dto.CtpManagerTenantDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> updateByUseTenantId(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.manager.dto.CtpManagerTenantDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> deleteByUseTenantId(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> updateStatusByUseTenantId(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.manager.dto.CtpManagerTenantStatusDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.ctp.manager.dto.CtpManagerTenantDto> selectByUseTenantId(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.ctp.manager.dto.CtpManagerTenantDto> selectByUseTenantCode(com.seeyon.boot.transport.SingleRequest<java.lang.String>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> retryInit(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.ctp.manager.dto.CtpManagerTenantStatusDto> selectStatusByUseTenantId(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.ctp.manager.dto.CtpManagerTenantInitDto> selectInitStatus(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.ctp.manager.dto.CtpManagerBaseAppDto> applicationList();
    com.seeyon.boot.transport.SingleResponse<java.lang.Boolean> replenishInit(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.manager.dto.CtpManagerReplenishInitDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.String> activationLicence(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.manager.dto.CtpLicenseInfoDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Boolean> bindingTenant(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.manager.dto.CtpManagerBindingTenantDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> updateTenantAdmin(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.manager.dto.CtpManagerTenantAdminUpdateDto>);
```

### `CtpRoleCoreAppService`（14 方法）

`com.seeyon.ctp.user.api.core.CtpRoleCoreAppService`

```java
    com.seeyon.boot.transport.SingleResponse<java.lang.Long> create(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.user.dto.CtpRoleDto>);
    default com.seeyon.boot.transport.SingleResponse<java.lang.Integer> saveBatch(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.user.dto.sync.CtpRoleSyncDto>);
    default com.seeyon.boot.transport.SingleResponse<java.lang.Integer> syncRoleResource(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.user.dto.sync.CtpRoleResourceSyncDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> update(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.user.dto.CtpRoleDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.ctp.user.dto.CtpRoleDto> selectById(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.ctp.user.dto.CtpRoleDto> selectByCode(com.seeyon.boot.transport.SingleRequest<java.lang.String>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.ctp.user.dto.CtpRoleDto> selectByIds(com.seeyon.boot.transport.SingleRequest<java.util.List<java.lang.Long>>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.ctp.user.dto.CtpRoleDto> selectListByConditions(com.seeyon.boot.transport.ListRequest);
    com.seeyon.boot.transport.PageResponse<com.seeyon.ctp.user.dto.CtpRoleDto> selectPageByConditions(com.seeyon.boot.transport.PageRequest);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> deleteByConditions(com.seeyon.boot.transport.SingleRequest<java.util.Map<java.lang.String, java.lang.Object>>);
    default com.seeyon.boot.transport.SingleResponse<com.seeyon.ctp.user.dto.CtpRoleDto> selectCascadeById(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    default com.seeyon.boot.transport.ListResponse<com.seeyon.ctp.user.dto.CtpRoleDto> selectCascadeByIds(com.seeyon.boot.transport.SingleRequest<java.util.List<java.lang.Long>>);
    default com.seeyon.boot.transport.PageResponse<com.seeyon.ctp.user.dto.CtpRoleDto> dynamicJoinSelect(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.dynamicsql.dto.ProxyJoinParamDto>);
    default com.seeyon.boot.transport.PageResponse<com.seeyon.ctp.user.dto.CtpRoleDto> dynamicSelect(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.dynamicsql.dto.ProxyParamDto>);
```

### `CtpSecretCommonAppService`（13 方法）

`com.seeyon.ctp.user.api.common.CtpSecretCommonAppService`

```java
    com.seeyon.boot.transport.SingleResponse<java.lang.Boolean> selectSecretEnable();
    com.seeyon.boot.transport.ListResponse<com.seeyon.ctp.user.dto.CtpSecretLevelEnumItemDto> selectSecretLevelEnumItem();
    com.seeyon.boot.transport.ListResponse<com.seeyon.ctp.user.dto.CtpSecretLevelEnumItemDto> selectOrgSecretLevelEnumItem();
    default com.seeyon.boot.transport.ListResponse<com.seeyon.ctp.user.dto.CtpSecretLevelEnumItemDto> selectSecretLevelEnumItemList(com.seeyon.boot.transport.SingleRequest<java.lang.Void>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.ctp.user.dto.CtpSecretLevelEnumItemDto> selectSecretLevelEnumItemByValue(com.seeyon.boot.transport.SingleRequest<java.lang.String>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.ctp.user.dto.CtpSecretLevelEnumItemDto> selectSecretLevelEnumItemByOrderNo(com.seeyon.boot.transport.SingleRequest<java.lang.Integer>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.ctp.user.dto.CtpSecretLevelEnumItemDto> selectOrgSecretLevelEnumItemByOrderNo(com.seeyon.boot.transport.SingleRequest<java.lang.Integer>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> selectSecretLevelOrderNoByValue(com.seeyon.boot.transport.SingleRequest<java.lang.String>);
    com.seeyon.boot.transport.SingleResponse<java.lang.String> selectSecretLevelValueByOrderNo(com.seeyon.boot.transport.SingleRequest<java.lang.Integer>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.ctp.user.dto.CtpSecretLevelEnumItemDto> selectListByConditions(com.seeyon.boot.transport.ListRequest);
    com.seeyon.boot.transport.SingleResponse<java.util.Map<java.lang.String, java.lang.String>> selectOrgToSystemSecretMap();
    com.seeyon.boot.transport.SingleResponse<java.util.Map<java.lang.String, java.lang.String>> selectSystemToOrgSecretMap();
    com.seeyon.boot.transport.SingleResponse<java.util.Map<java.lang.String, java.util.List<java.lang.Long>>> getAccessSecretEnumIds(com.seeyon.boot.transport.SingleRequest<java.util.Map<java.lang.String, java.lang.Object>>);
```

### `CtpAuthCoreAppService`（13 方法）

`com.seeyon.ctp.user.api.core.CtpAuthCoreAppService`

```java
    com.seeyon.boot.transport.SingleResponse<java.util.Map<java.lang.String, java.lang.Object>> authenticate(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.user.dto.CtpLoginDto>);
    com.seeyon.boot.transport.SingleResponse<java.util.Map<java.lang.String, java.lang.Object>> switchAdmin(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.user.dto.CtpSwitchIdentityDto>);
    com.seeyon.boot.transport.SingleResponse<java.util.Map<java.lang.String, java.lang.Object>> switchOrg(com.seeyon.boot.transport.SingleRequest<java.util.Map<java.lang.String, java.lang.Object>>);
    com.seeyon.boot.transport.SingleResponse<java.util.Map<java.lang.String, java.lang.Object>> switchUser(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.user.dto.CtpSwitchIdentityDto>);
    com.seeyon.boot.transport.SingleResponse<java.util.Map<java.lang.String, java.lang.Object>> getLoginUserInfo(com.seeyon.boot.transport.SingleRequest<java.util.Map<java.lang.String, java.lang.Object>>);
    default com.seeyon.boot.transport.SingleResponse<com.seeyon.ctp.user.dto.CtpLoginInfoDto> getPcUserInfo(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.ctp.manager.dto.CtpManagerTenantViewDto> selectTenantList(com.seeyon.boot.transport.SingleRequest<java.util.Map<java.lang.String, java.lang.Object>>);
    com.seeyon.boot.transport.SingleResponse<java.util.Map<java.lang.String, java.lang.Object>> switchTenant(com.seeyon.boot.transport.SingleRequest<java.util.Map<java.lang.String, java.lang.Object>>);
    com.seeyon.boot.transport.SingleResponse<java.lang.String> refreshAccessToken(com.seeyon.boot.transport.SingleRequest<java.lang.String>);
    com.seeyon.boot.transport.SingleResponse<java.lang.String> getAccessToken(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.user.dto.sso.AccessTokenRequestDto>);
    com.seeyon.boot.transport.SingleResponse<java.util.Map<java.lang.String, java.lang.Object>> selectTenantListByUserId(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.SingleResponse<java.lang.String> selectTicketByToken(com.seeyon.boot.transport.SingleRequest<java.lang.String>);
    com.seeyon.boot.transport.SingleResponse<java.lang.String> getTempAccessToken(com.seeyon.boot.transport.SingleRequest<java.util.Map<java.lang.String, java.lang.Object>>);
```

### `CtpUserRoleCoreAppService`（13 方法）

`com.seeyon.ctp.user.api.core.CtpUserRoleCoreAppService`

```java
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> createBatch(com.seeyon.boot.transport.SingleRequest<java.util.List<com.seeyon.ctp.user.dto.CtpUserRoleDto>>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Long> createUserRule(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.user.dto.CtpRuleRoleDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Long> createAuthorizationRule(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.user.dto.CtpAuthorizationDto>);
    default com.seeyon.boot.transport.SingleResponse<java.lang.Integer> createBatchAuthorizationRule(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.user.dto.CtpUserRoleSyncDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> deleteAuthorizationRuleById(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> deleteByIds(com.seeyon.boot.transport.SingleRequest<java.util.List<java.lang.Long>>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> deleteByConditions(com.seeyon.boot.transport.SingleRequest<java.util.Map<java.lang.String, java.lang.Object>>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.ctp.user.dto.CtpUserRoleDto> selectListByConditions(com.seeyon.boot.transport.ListRequest);
    default com.seeyon.boot.transport.ListResponse<com.seeyon.ctp.user.dto.CtpEntityRoleDto> selectEntityRoleListByConditions(com.seeyon.boot.transport.SingleRequest<java.util.Map<java.lang.String, java.lang.Object>>);
    com.seeyon.boot.transport.PageResponse<com.seeyon.ctp.user.dto.CtpUserRoleDto> selectPageByConditions(com.seeyon.boot.transport.PageRequest);
    default com.seeyon.boot.transport.SingleResponse<java.lang.Integer> authOrgAdmin(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.user.dto.CtpAuthOrgAdminDto>);
    default com.seeyon.boot.transport.SingleResponse<com.seeyon.ctp.user.dto.sync.CtpAuthorizationRuleSyncResultDto> roleAuthBatch(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.user.dto.sync.CtpAuthorizationRuleSyncDto>);
    default com.seeyon.boot.transport.PageResponse<com.seeyon.ctp.user.dto.CtpEntityRoleDto> selectCtpEntityRolePageByConditions(com.seeyon.boot.transport.PageRequest);
```

### `CtpOrgAdminOrgAppService`（13 方法）

`com.seeyon.ctp.user.api.org.CtpOrgAdminOrgAppService`

```java
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> configAdmin(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.user.dto.CtpOrgAdminConfigDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.ctp.user.dto.CtpOrgAdminConfigDto> selectByOrgId(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.ctp.user.dto.CtpOrgAdminDto> selectByOrgIds(com.seeyon.boot.transport.SingleRequest<java.util.List<java.lang.Long>>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.ctp.user.dto.CtpOrgAdminDto> selectByUserId(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.PageResponse<com.seeyon.ctp.user.dto.CtpOrgAdminDto> selectPageByConditions(com.seeyon.boot.transport.PageRequest);
    com.seeyon.boot.transport.ListResponse<com.seeyon.ctp.user.dto.CtpOrgAdminDto> selectListByConditions(com.seeyon.boot.transport.SingleRequest<java.util.Map<java.lang.String, java.lang.Object>>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.ctp.user.enums.ManageScopeEnum> selectManageScopeByOrgAndUser(com.seeyon.boot.transport.SingleRequest<java.util.Map<java.lang.String, java.lang.Object>>);
    default com.seeyon.boot.transport.SingleResponse<java.lang.Boolean> selectTreeMembersAdminEnable();
    default com.seeyon.boot.transport.ListResponse<com.seeyon.ctp.user.dto.CtpOrgAdminConfigDto> selectOrgAdminByOrgIds(com.seeyon.boot.transport.SingleRequest<java.util.List<java.lang.Long>>);
    default com.seeyon.boot.transport.SingleResponse<java.lang.Integer> batchConfigOrgAdmin(com.seeyon.boot.transport.SingleRequest<java.util.List<com.seeyon.ctp.user.dto.CtpOrgAdminConfigDto>>);
    default com.seeyon.boot.transport.SingleResponse<java.lang.Boolean> deleteOrgAdminByOrgId(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    default com.seeyon.boot.transport.SingleResponse<java.lang.Long> createAdmin(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.user.dto.CtpOrgAdminConfigDto>);
    default com.seeyon.boot.transport.SingleResponse<java.lang.Integer> updateAdmin(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.user.dto.CtpOrgAdminConfigDto>);
```

### `CtpApplicationCommonAppService`（10 方法）

`com.seeyon.ctp.application.api.common.CtpApplicationCommonAppService`

```java
    com.seeyon.boot.transport.ListResponse<com.seeyon.ctp.application.dto.CtpCategoryNameApplicationDto> selectCategoryApplications(com.seeyon.boot.transport.SingleRequest<java.util.Map<java.lang.String, java.lang.Object>>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.ctp.application.dto.CtpCategorySettingDto> selectCategorySetting(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.application.enums.ClientScopeEnum>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.ctp.application.dto.CtpApplicationDto> selectApplicationsByCategoryAndClientScope(com.seeyon.boot.transport.SingleRequest<java.util.Map<java.lang.String, java.lang.Object>>);
    com.seeyon.boot.transport.ListResponse<java.lang.String> selectAdminAppIdsByUserIdAndOrgId(com.seeyon.boot.transport.ListRequest);
    com.seeyon.boot.transport.SingleResponse<java.util.Map<java.lang.String, java.lang.Boolean>> selectEnabledApplications(com.seeyon.boot.transport.SingleRequest<java.util.Map<java.lang.String, java.lang.Object>>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Boolean> isEnabled(com.seeyon.boot.transport.SingleRequest<java.util.Map<java.lang.String, java.lang.Object>>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.ctp.user.dto.CtpMenuAndPortalDto> selectUserMenuAndPortal(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.user.dto.SearchMenuAndPortalDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Long> selectEntityManageOrgIdByAppId(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.user.dto.SearchEntityManageOrgIdDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> register(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.application.dto.CtpApplicationRegisterDto>);
    default com.seeyon.boot.transport.PageResponse<com.seeyon.ctp.application.dto.CtpApplicationDto> selectUserApplicationsByConditions(com.seeyon.boot.transport.PageRequest);
```

### `CtpAuthorizationRuleOrgAppService`（9 方法）

`com.seeyon.ctp.user.api.org.CtpAuthorizationRuleOrgAppService`

```java
    com.seeyon.boot.transport.SingleResponse<java.lang.Long> create(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.user.dto.authorization.CtpAuthorizationRuleAllDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> update(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.user.dto.authorization.CtpAuthorizationRuleAllDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> delete(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.user.dto.authorization.CtpAuthorizationRuleDeleteDto>);
    com.seeyon.boot.transport.PageResponse<com.seeyon.ctp.user.dto.authorization.CtpAuthorizationRuleDto> selectPageByConditions(com.seeyon.boot.transport.PageRequest);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.ctp.user.dto.authorization.CtpAuthorizationObjectDto> selectAuthorizationObject(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.user.dto.authorization.CtpAuthorizationSearchDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.ctp.user.dto.authorization.CtpAuthorizationEntityDto> selectAuthorizationEntity(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.ctp.user.dto.authorization.CtpAuthorizationRuleFuncListDto> selectAuthorizationFuncList(com.seeyon.boot.transport.SingleRequest<java.util.Map<java.lang.String, java.lang.Object>>);
    default com.seeyon.boot.transport.SingleResponse<com.seeyon.ctp.user.dto.authorization.CtpAuthorizationRuleByRoleDto> selectAuthorizationFuncListByRole(com.seeyon.boot.transport.SingleRequest<java.util.Map<java.lang.String, java.lang.Object>>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.ctp.user.dto.authorization.CtpAuthorizationRuleCustomDto> selectDuplicateRolesRule(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.user.dto.authorization.CtpAuthorizationRuleCustomDto>);
```

### `CtpResourceCoreAppService`（8 方法）

`com.seeyon.ctp.user.api.core.CtpResourceCoreAppService`

```java
    com.seeyon.boot.transport.SingleResponse<java.lang.Long> register(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.user.dto.CtpResourceDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> registerBatch(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.user.dto.sync.CtpResourceSyncDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.ctp.user.dto.CtpResourcePermissionBatchResultDto> registerResourcePermissionBatch(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.user.dto.CtpResourcePermissionBatchRegisterDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> updateByCode(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.user.dto.CtpResourceDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> deleteByConditions(com.seeyon.boot.transport.SingleRequest<java.util.Map<java.lang.String, java.lang.Object>>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.ctp.user.dto.CtpResourceDto> selectByCode(com.seeyon.boot.transport.SingleRequest<java.lang.String>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.ctp.user.dto.CtpResourceDto> selectListByConditions(com.seeyon.boot.transport.ListRequest);
    com.seeyon.boot.transport.PageResponse<com.seeyon.ctp.user.dto.CtpResourceDto> selectPageByConditions(com.seeyon.boot.transport.PageRequest);
```

### `CtpThirdPlatformConfigCoreAppService`（7 方法）

`com.seeyon.ctp.user.api.core.CtpThirdPlatformConfigCoreAppService`

```java
    com.seeyon.boot.transport.SingleResponse<java.lang.Long> create(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.user.dto.third.CtpThirdPlatformConfigDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> update(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.user.dto.third.CtpThirdPlatformConfigDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> deleteByIds(com.seeyon.boot.transport.SingleRequest<java.util.List<java.lang.Long>>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.ctp.user.dto.third.CtpThirdPlatformConfigDto> selectById(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.ctp.user.dto.third.CtpThirdPlatformConfigDto> selectOneByConditions(com.seeyon.boot.transport.SingleRequest<java.util.Map<java.lang.String, java.lang.Object>>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.ctp.user.dto.third.CtpThirdPlatformConfigDto> selectListByConditions(com.seeyon.boot.transport.ListRequest);
    com.seeyon.boot.transport.PageResponse<com.seeyon.ctp.user.dto.third.CtpThirdPlatformConfigDto> selectPageByConditions(com.seeyon.boot.transport.PageRequest);
```

### `CtpUserBindMappingAppService`（7 方法）

`com.seeyon.ctp.user.api.core.CtpUserBindMappingAppService`

```java
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> saveUpdate(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.user.dto.CtpUserMappingSyncRequestDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.ctp.user.dto.CtpUserMappingResponseDto> selectOneByCondition(com.seeyon.boot.transport.SingleRequest<java.util.Map<java.lang.String, java.lang.Object>>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.ctp.user.dto.CtpUserMappingResponseDto> selectListByConditions(com.seeyon.boot.transport.ListRequest);
    com.seeyon.boot.transport.PageResponse<com.seeyon.ctp.user.dto.CtpUserMappingResponseDto> pageUserMappingByUserIds(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.user.dto.CtpUserMappingQueryRequestDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.ctp.user.dto.CtpUserMappingResponseDto> listUserMappingByUserIds(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.user.dto.CtpUserMappingQueryRequestDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.ctp.user.dto.CtpUserMappingResponseDto> listUserMappingForPending(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.user.dto.CtpUserMappingQueryRequestDto>);
    com.seeyon.boot.transport.PageResponse<com.seeyon.ctp.user.dto.CtpUserMappingResponseDto> selectPageByConditions(com.seeyon.boot.transport.PageRequest);
```

### `CtpApplicationBaseAppService`（6 方法）

`com.seeyon.ctp.application.api.CtpApplicationBaseAppService`

```java
    com.seeyon.boot.transport.SingleResponse<java.lang.Long> create(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.application.dto.application.admin.CtpApplicationAdminCreateDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> update(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.application.dto.application.admin.CtpApplicationAdminCreateDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> updateStatus(com.seeyon.boot.transport.SingleRequest<java.lang.Long>, com.seeyon.boot.transport.SingleRequest<java.lang.Boolean>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> updateOnlineStatus(com.seeyon.boot.transport.SingleRequest<java.lang.String>, com.seeyon.boot.transport.SingleRequest<java.lang.String>);
    default com.seeyon.boot.transport.SingleResponse<java.lang.Integer> simpleUpdate(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.application.dto.application.admin.CtpApplicationAdminSimpleUpdateDto>);
    default com.seeyon.boot.transport.SingleResponse<java.lang.Integer> syncApplication(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.application.dto.CtpApplicationSyncDto>);
```

### `CtpApplicationAuthCoreAppService`（6 方法）

`com.seeyon.ctp.application.api.core.CtpApplicationAuthCoreAppService`

```java
    com.seeyon.boot.transport.ListResponse<com.seeyon.ctp.application.dto.CtpApplicationAuthorizationDto> selectApplicationAuthByAppId(com.seeyon.boot.transport.SingleRequest<java.lang.String>);
    com.seeyon.boot.transport.ListResponse<java.lang.String> selectAuthAppIdsByOrgId(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.ListResponse<java.lang.String> selectAuthAppIds(com.seeyon.boot.transport.SingleRequest<java.util.Map<java.lang.String, java.lang.Object>>);
    com.seeyon.boot.transport.ListResponse<java.lang.String> selectWithOutAuthAllAppIdsByOrgId(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    default com.seeyon.boot.transport.ListResponse<com.seeyon.ctp.application.dto.CtpApplicationDto> selectApplicationByAuthedOrg(com.seeyon.boot.transport.SingleRequest<java.util.Map<java.lang.String, java.lang.Object>>);
    default com.seeyon.boot.transport.PageResponse<com.seeyon.ctp.application.dto.CtpApplicationDto> selectPageApplicationByAuthedOrg(com.seeyon.boot.transport.PageRequest);
```

### `CtpLoginPreConfigAppService`（6 方法）

`com.seeyon.ctp.user.api.core.CtpLoginPreConfigAppService`

```java
    com.seeyon.boot.transport.SingleResponse<com.seeyon.ctp.user.dto.CtpLoginPreConfigDto> selectByOrgId(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> createOrUpdate(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.user.dto.CtpLoginPreConfigDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Boolean> allowChildCustomDefine();
    com.seeyon.boot.transport.SingleResponse<java.lang.Boolean> allowChildCustomDefine(com.seeyon.boot.transport.SingleRequest<java.lang.Boolean>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.ctp.user.dto.CtpLoginPreConfigDto> selectByUri(com.seeyon.boot.transport.SingleRequest<java.lang.String>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Boolean> hasRepeatName(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.user.dto.CtpLoginPreConfigDto>);
```

### `CtpUserRoleCommonAppService`（5 方法）

`com.seeyon.ctp.user.api.common.CtpUserRoleCommonAppService`

```java
    com.seeyon.boot.transport.ListResponse<java.util.Map<java.lang.String, java.lang.Object>> selectUserByRoleCode(com.seeyon.boot.transport.SingleRequest<java.util.Map<java.lang.String, java.lang.Object>>);
    com.seeyon.boot.transport.PageResponse<java.util.Map<java.lang.String, java.lang.Object>> selectPageUserByRoleCode(com.seeyon.boot.transport.PageRequest);
    com.seeyon.boot.transport.ListResponse<com.seeyon.ctp.user.dto.CtpUserRoleViewDto> selectUserByRoleCodeSearch(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.user.dto.CtpUserRoleSearchDto>);
    com.seeyon.boot.transport.ListResponse<java.lang.Long> selectUserIdByRoleCode(com.seeyon.boot.transport.SingleRequest<java.util.Map<java.lang.String, java.lang.Object>>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Boolean> hasRoleByOrgCode(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.user.dto.HasRoleByOrgCodeSearchDto>);
```

### `CtpPersonalPlanCoreAppService`（4 方法）

`com.seeyon.ctp.application.api.personalplan.CtpPersonalPlanCoreAppService`

```java
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> createOrUpdateBatch(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.application.dto.personalplan.CtpPersonalPlanPermissionDto>);
    com.seeyon.boot.transport.SingleResponse<java.util.List<java.lang.Long>> createRedirectBatch(com.seeyon.boot.transport.SingleRequest<java.util.List<com.seeyon.ctp.application.dto.personalplan.CtpPersonalPlanDto>>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> deleteByIds(com.seeyon.boot.transport.SingleRequest<java.util.List<java.lang.Long>>);
    default com.seeyon.boot.transport.PageResponse<com.seeyon.ctp.application.dto.personalplan.CtpPersonalPlanDto> selectPageByConditions(com.seeyon.boot.transport.PageRequest);
```

### `CtpUserCommonAppService`（4 方法）

`com.seeyon.ctp.user.api.common.CtpUserCommonAppService`

```java
    com.seeyon.boot.transport.SingleResponse<java.util.Map<java.lang.String, java.lang.Object>> getUserInfo(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.ctp.user.dto.CtpUserDto> selectUserByLoginName(com.seeyon.boot.transport.SingleRequest<java.lang.String>);
    com.seeyon.boot.transport.SingleResponse<java.util.Map<java.lang.String, java.lang.Object>> getLoginPageSetParameter();
    default com.seeyon.boot.transport.SingleResponse<java.util.Map<java.lang.Long, java.lang.Long>> getRecentUserId(java.lang.Integer);
```

### `CtpResourcePermissionCoreAppService`（4 方法）

`com.seeyon.ctp.user.api.core.CtpResourcePermissionCoreAppService`

```java
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> register(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.user.dto.CtpResourcePermissionRegisterDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> deleteByResourceCode(com.seeyon.boot.transport.SingleRequest<java.lang.String>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.ctp.user.dto.CtpResourcePermissionDto> selectByResourceCode(com.seeyon.boot.transport.SingleRequest<java.lang.String>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.ctp.user.dto.CtpResourcePermissionDto> selectListByConditions(com.seeyon.boot.transport.SingleRequest<java.util.Map<java.lang.String, java.lang.Object>>);
```

### `CtpUserResourceCoreAppService`（4 方法）

`com.seeyon.ctp.user.api.core.CtpUserResourceCoreAppService`

```java
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> createBatch(com.seeyon.boot.transport.SingleRequest<java.util.List<com.seeyon.ctp.user.dto.CtpUserResourceDto>>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> deleteByConditions(com.seeyon.boot.transport.SingleRequest<java.util.Map<java.lang.String, java.lang.Object>>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.ctp.user.dto.CtpUserResourceDto> selectListByConditions(com.seeyon.boot.transport.ListRequest);
    com.seeyon.boot.transport.PageResponse<com.seeyon.ctp.user.dto.CtpUserResourceDto> selectPageListByConditions(com.seeyon.boot.transport.PageRequest);
```

### `CtpUserRoleAppService`（4 方法）

`com.seeyon.ctp.user.api.core.CtpUserRoleAppService`

```java
    com.seeyon.boot.transport.SingleResponse<com.seeyon.ctp.user.dto.CtpUserRoleDto> selectCascadeById(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.ctp.user.dto.CtpUserRoleDto> selectCascadeByIds(com.seeyon.boot.transport.SingleRequest<java.util.List<java.lang.Long>>);
    com.seeyon.boot.transport.PageResponse<com.seeyon.ctp.user.dto.CtpUserRoleDto> dynamicJoinSelect(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.dynamicsql.dto.ProxyJoinParamDto>);
    com.seeyon.boot.transport.PageResponse<com.seeyon.ctp.user.dto.CtpUserRoleDto> dynamicSelect(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.dynamicsql.dto.ProxyParamDto>);
```

### `CtpPermissionApprovalOrgAppService`（4 方法）

`com.seeyon.ctp.user.api.org.CtpPermissionApprovalOrgAppService`

```java
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> update(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.user.dto.CtpPermissionApprovalDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.ctp.user.dto.CtpPermissionApprovalDto> selectById(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> batchKnow();
    com.seeyon.boot.transport.PageResponse<com.seeyon.ctp.user.dto.CtpPermissionApprovalDto> selectPageByConditions(com.seeyon.boot.transport.PageRequest);
```

### `CtpApplicationCoreAppService`（3 方法）

`com.seeyon.ctp.application.api.core.CtpApplicationCoreAppService`

```java
    com.seeyon.boot.transport.ListResponse<com.seeyon.ctp.application.dto.CtpApplicationDto> selectListByConditions(com.seeyon.boot.transport.ListRequest);
    com.seeyon.boot.transport.PageResponse<com.seeyon.ctp.application.dto.CtpApplicationDto> selectPageByConditions(com.seeyon.boot.transport.PageRequest);
    com.seeyon.boot.transport.ListResponse<com.seeyon.ctp.application.dto.CtpApplicationStatusDto> selectAppStatusListIgnoreTenantId();
```

### `CtpDeviceBindCommonAppService`（3 方法）

`com.seeyon.ctp.user.api.common.CtpDeviceBindCommonAppService`

```java
    com.seeyon.boot.transport.SingleResponse<java.lang.Long> bindDevice(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.user.dto.devicebind.CtpDeviceBindDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> batchUnbindDevice(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.user.dto.devicebind.CtpUnbindDeviceDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.ctp.user.dto.devicebind.CtpDeviceBindDto> selectByConditions(com.seeyon.boot.transport.SingleRequest<java.util.Map<java.lang.String, java.lang.Object>>);
```

### `CtpUserDefaultIdentityCommonAppService`（3 方法）

`com.seeyon.ctp.user.api.common.CtpUserDefaultIdentityCommonAppService`

```java
    com.seeyon.boot.transport.SingleResponse<java.lang.Long> selectDefaultSwitchAdminOrg(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.ctp.user.dto.CtpUserDefaultIdentityDto> selectUDefaultseIdentityInfo(com.seeyon.boot.transport.ListRequest);
    com.seeyon.boot.transport.SingleResponse<java.lang.Long> selectFrontUserDefaultTenant(com.seeyon.boot.transport.ListRequest);
```

### `SecurityCheckServiceSpi`（3 方法）

`com.seeyon.ctp.user.spi.SecurityCheckServiceSpi`

```java
    boolean preCheckPermission(javax.servlet.http.HttpServletRequest, java.lang.Object, java.util.Set<java.lang.String>, java.lang.String[]);
    boolean postCheckPermission(javax.servlet.http.HttpServletRequest);
    void afterCheckPermissionCompletion(javax.servlet.http.HttpServletRequest, java.lang.Exception);
```

### `CtpCategoryCoreAppService`（2 方法）

`com.seeyon.ctp.application.api.core.CtpCategoryCoreAppService`

```java
    com.seeyon.boot.transport.ListResponse<com.seeyon.ctp.application.dto.CtpCategoryDto> selectListByConditions(com.seeyon.boot.transport.ListRequest);
    com.seeyon.boot.transport.ListResponse<com.seeyon.ctp.application.dto.CtpWorkbenchItemDto> selectQuickListByConditions(com.seeyon.boot.transport.ListRequest);
```

### `CtpAccessLogService`（2 方法）

`com.seeyon.ctp.log.api.CtpAccessLogService`

```java
    com.seeyon.boot.transport.ListResponse<com.seeyon.ctp.log.dto.CtpAccessLogDto> selectAccessLogPageByConditions(com.seeyon.boot.transport.ListRequest);
    com.seeyon.boot.transport.PageResponse<com.seeyon.ctp.log.dto.CtpAccessLogDto> selectAccessByConditions(com.seeyon.boot.transport.PageRequest);
```

### `CtpMenuCommonAppService`（2 方法）

`com.seeyon.ctp.user.api.common.CtpMenuCommonAppService`

```java
    com.seeyon.boot.transport.ListResponse<com.seeyon.ctp.user.dto.CtpMenuDto> selectChildrenByCode(com.seeyon.boot.transport.SingleRequest<java.lang.String>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.ctp.user.dto.CtpMenuDto> selectListByConditions(com.seeyon.boot.transport.ListRequest);
```

### `CtpResourceCommonAppService`（2 方法）

`com.seeyon.ctp.user.api.common.CtpResourceCommonAppService`

```java
    com.seeyon.boot.transport.ListResponse<com.seeyon.ctp.user.dto.CtpResourceDto> selectDesignResources(com.seeyon.boot.transport.ListRequest);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> deleteDesignResources(com.seeyon.boot.transport.SingleRequest<java.lang.String>);
```

### `CtpSecretApprovalOrgAppService`（2 方法）

`com.seeyon.ctp.user.api.org.CtpSecretApprovalOrgAppService`

```java
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> create(com.seeyon.boot.transport.SingleRequest<java.util.List<com.seeyon.ctp.user.dto.CtpSecretApprovalDto>>);
    com.seeyon.boot.transport.ListResponse<java.util.Map<java.lang.String, java.lang.Object>> selectPendingInfo(com.seeyon.boot.transport.SingleRequest<java.util.List<java.lang.Long>>);
```

### `CtpAuthorizationUdcAppService`（2 方法）

`com.seeyon.ctp.user.api.udc.CtpAuthorizationUdcAppService`

```java
    com.seeyon.boot.transport.SingleResponse<java.lang.Long> autoAuthAppRoles(com.seeyon.boot.transport.SingleRequest<java.lang.String>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.ctp.user.dto.CtpRoleLinkDto> selectAppFirstLinks(com.seeyon.boot.transport.SingleRequest<java.lang.String>);
```

### `UserTenantInitServiceSpi`（2 方法）

`com.seeyon.ctp.user.spi.UserTenantInitServiceSpi`

```java
    java.lang.String getInitType();
    void doInit();
```

### `CtpCapabilityCoreAppService`（1 方法）

`com.seeyon.ctp.application.api.core.CtpCapabilityCoreAppService`

```java
    com.seeyon.boot.transport.ListResponse<com.seeyon.ctp.application.dto.CtpCapabilityDto> selectListByConditions(com.seeyon.boot.transport.ListRequest);
```

### `ThirdPermissionAppService`（1 方法）

`com.seeyon.ctp.user.api.ThirdPermissionAppService`

```java
    com.seeyon.boot.transport.SingleResponse<java.util.Map<java.lang.String, java.lang.Boolean>> checkPermissionByUser(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.user.dto.ThirdCheckResourcePermissionDto>);
```

### `CtpUserBpmAppService`（1 方法）

`com.seeyon.ctp.user.api.bpm.CtpUserBpmAppService`

```java
    com.seeyon.boot.transport.PageResponse<com.seeyon.ctp.user.dto.bpm.CtpUserBpmResourceDto> selectUserResourceIgnoreTenant(com.seeyon.boot.transport.PageInfo, java.util.Map<java.lang.String, java.lang.Object>);
```

### `CtpDataAuditCoreAppService`（1 方法）

`com.seeyon.ctp.user.api.core.CtpDataAuditCoreAppService`

```java
    com.seeyon.boot.transport.SingleResponse<java.lang.Long> create(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.user.dto.CtpDataAuditDto>);
```

### `CtpLoginLogCoreAppService`（1 方法）

`com.seeyon.ctp.user.api.core.CtpLoginLogCoreAppService`

```java
    com.seeyon.boot.transport.PageResponse<com.seeyon.ctp.user.dto.CtpLoginLogDto> selectPageByConditions(com.seeyon.boot.transport.PageRequest);
```

### `CtpResourceTypeCoreAppService`（1 方法）

`com.seeyon.ctp.user.api.core.CtpResourceTypeCoreAppService`

```java
    com.seeyon.boot.transport.ListResponse<com.seeyon.ctp.user.dto.CtpResourceTypeDto> selectListByConditions(com.seeyon.boot.transport.ListRequest);
```

### `CtpRoleResourceCoreAppService`（1 方法）

`com.seeyon.ctp.user.api.core.CtpRoleResourceCoreAppService`

```java
    default com.seeyon.boot.transport.SingleResponse<java.util.Map<java.lang.String, java.util.List<com.seeyon.ctp.user.dto.CtpRoleResourceActionDto>>> selectResourceActionByRoleCodes(com.seeyon.boot.transport.SingleRequest<java.util.List<java.lang.String>>);
```

### `CtpOrgSelectPeopleAppService`（1 方法）

`com.seeyon.ctp.user.api.org.CtpOrgSelectPeopleAppService`

```java
    com.seeyon.boot.transport.PageResponse<com.seeyon.ctp.user.dto.CtpRoleDto> selectPageByConditions(com.seeyon.boot.transport.PageRequest);
```

### `CtpOrgUpgradeAppService`（1 方法）

`com.seeyon.ctp.user.api.org.CtpOrgUpgradeAppService`

```java
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> updateBatchUserCode(com.seeyon.boot.transport.SingleRequest<java.util.Map<java.lang.Long, java.lang.String>>);
```

### `SyncOrgRoleTempAppService`（1 方法）

`com.seeyon.ctp.user.api.org.SyncOrgRoleTempAppService`

```java
    com.seeyon.boot.transport.SingleResponse<java.lang.Boolean> syncOrgRole(com.seeyon.boot.transport.SingleRequest<java.util.Map<java.lang.String, java.util.Set<java.lang.Long>>>);
```

## 二、关键类（11）

### `CtpManagerTenantDto`（28 方法）

`com.seeyon.ctp.manager.dto.CtpManagerTenantDto`

```java
    java.lang.Long getUseTenantId();
    java.util.List<java.lang.String> getAppNameList();
    java.util.Map<java.lang.String, java.lang.String> getReplaces();
    java.lang.String getUseTenantDomain();
    java.lang.String getUseTenantSubDomain();
    java.lang.String getPerfix();
    java.lang.String getUseTenantName();
    java.lang.String getUseTenantCode();
    java.lang.String getRemark();
    com.seeyon.ctp.manager.enums.TenantStatusEnum getStatus();
    java.lang.String getLocale();
    java.util.List<java.lang.String> getPluginAppNameList();
    java.util.Date getCreateTime();
    java.lang.Boolean getIsDomain();
    void setUseTenantId(java.lang.Long);
    void setAppNameList(java.util.List<java.lang.String>);
    void setReplaces(java.util.Map<java.lang.String, java.lang.String>);
    void setUseTenantDomain(java.lang.String);
    void setUseTenantSubDomain(java.lang.String);
    void setPerfix(java.lang.String);
    void setUseTenantName(java.lang.String);
    void setUseTenantCode(java.lang.String);
    void setRemark(java.lang.String);
    void setStatus(com.seeyon.ctp.manager.enums.TenantStatusEnum);
    void setLocale(java.lang.String);
    void setPluginAppNameList(java.util.List<java.lang.String>);
    void setCreateTime(java.util.Date);
    void setIsDomain(java.lang.Boolean);
```

### `CtpThirdPlatformConfigDto`（28 方法）

`com.seeyon.ctp.user.dto.third.CtpThirdPlatformConfigDto`

```java
    java.lang.Long getId();
    java.lang.String getName();
    com.seeyon.ctp.user.enums.ThirdPlatformTypeEnum getType();
    java.lang.Long getOrgId();
    java.lang.String getCorpId();
    java.lang.String getCorpSecret();
    java.lang.String getAppId();
    java.lang.String getAppKey();
    java.lang.String getAppSecret();
    java.lang.String getExtAttr1();
    java.lang.String getExtAttr2();
    java.lang.String getExtAttr3();
    java.lang.String getExtAttr4();
    java.lang.String getExtAttr5();
    void setId(java.lang.Long);
    void setName(java.lang.String);
    void setType(com.seeyon.ctp.user.enums.ThirdPlatformTypeEnum);
    void setOrgId(java.lang.Long);
    void setCorpId(java.lang.String);
    void setCorpSecret(java.lang.String);
    void setAppId(java.lang.String);
    void setAppKey(java.lang.String);
    void setAppSecret(java.lang.String);
    void setExtAttr1(java.lang.String);
    void setExtAttr2(java.lang.String);
    void setExtAttr3(java.lang.String);
    void setExtAttr4(java.lang.String);
    void setExtAttr5(java.lang.String);
```

### `CtpOrgAdminConfigDto`（26 方法）

`com.seeyon.ctp.user.dto.CtpOrgAdminConfigDto`

```java
    java.lang.Long getId();
    java.lang.Long getOrgId();
    java.lang.String getOrgName();
    java.lang.Boolean getOrgIsRoot();
    com.seeyon.ctp.user.enums.ManageScopeEnum getManageScope();
    com.seeyon.ctp.user.enums.ManagerTypeEnum getManageType();
    java.lang.String getIsTernary();
    java.util.List<com.seeyon.ctp.user.dto.CtpAdminConfigDto> getList();
    java.lang.Boolean getCheckUserNum();
    java.lang.Integer getDataSignSuccess();
    java.lang.Long getCreateOrgId();
    java.lang.String getAuthName();
    java.util.List<com.seeyon.ctp.user.dto.CtpRoleApplicationResourceDto> getAppList();
    void setId(java.lang.Long);
    void setOrgId(java.lang.Long);
    void setOrgName(java.lang.String);
    void setOrgIsRoot(java.lang.Boolean);
    void setManageScope(com.seeyon.ctp.user.enums.ManageScopeEnum);
    void setManageType(com.seeyon.ctp.user.enums.ManagerTypeEnum);
    void setIsTernary(java.lang.String);
    void setList(java.util.List<com.seeyon.ctp.user.dto.CtpAdminConfigDto>);
    void setCheckUserNum(java.lang.Boolean);
    void setDataSignSuccess(java.lang.Integer);
    void setCreateOrgId(java.lang.Long);
    void setAuthName(java.lang.String);
    void setAppList(java.util.List<com.seeyon.ctp.user.dto.CtpRoleApplicationResourceDto>);
```

### `CtpLoginPreConfigDto`（18 方法）

`com.seeyon.ctp.user.dto.CtpLoginPreConfigDto`

```java
    java.lang.Long getOrgId();
    java.lang.Long getTid();
    java.lang.Boolean getEnabledLoginManage();
    java.lang.Boolean getEnabledLoginPrePortal();
    java.lang.Boolean getEnabledUnifyLoginPortal();
    java.lang.Boolean getEnabledHolidayLoginPortal();
    java.lang.String getLoginManageUri();
    java.lang.Boolean getIsRootUnit();
    java.lang.Boolean getAllowChildCustomDefine();
    void setOrgId(java.lang.Long);
    void setTid(java.lang.Long);
    void setEnabledLoginManage(java.lang.Boolean);
    void setEnabledLoginPrePortal(java.lang.Boolean);
    void setEnabledUnifyLoginPortal(java.lang.Boolean);
    void setEnabledHolidayLoginPortal(java.lang.Boolean);
    void setLoginManageUri(java.lang.String);
    void setIsRootUnit(java.lang.Boolean);
    void setAllowChildCustomDefine(java.lang.Boolean);
```

### `CtpManagerTenantViewDto`（16 方法）

`com.seeyon.ctp.manager.dto.CtpManagerTenantViewDto`

```java
    java.lang.Long getUseTenantId();
    java.lang.String getUseTenantName();
    java.lang.String getUseTenantDomain();
    java.lang.String getUseTenantCode();
    java.lang.Long getUserId();
    java.lang.String getName();
    java.lang.String getAvatar();
    java.lang.Boolean getDefaultTenant();
    void setUseTenantId(java.lang.Long);
    void setUseTenantName(java.lang.String);
    void setUseTenantDomain(java.lang.String);
    void setUseTenantCode(java.lang.String);
    void setUserId(java.lang.Long);
    void setName(java.lang.String);
    void setAvatar(java.lang.String);
    void setDefaultTenant(java.lang.Boolean);
```

### `CtpManagerTenantAdminUpdateDto`（10 方法）

`com.seeyon.ctp.manager.dto.CtpManagerTenantAdminUpdateDto`

```java
    java.lang.String getNewAdminLoginName();
    java.lang.String getNewAdminPhoneNumber();
    java.lang.String getNewAdminPassword();
    java.lang.Long getUseTenantId();
    java.lang.String getAdminName();
    void setNewAdminLoginName(java.lang.String);
    void setNewAdminPhoneNumber(java.lang.String);
    void setNewAdminPassword(java.lang.String);
    void setUseTenantId(java.lang.Long);
    void setAdminName(java.lang.String);
```

### `CtpManagerTenantInitDto`（10 方法）

`com.seeyon.ctp.manager.dto.CtpManagerTenantInitDto`

```java
    java.lang.String getAppName();
    java.lang.String getAppVersion();
    java.lang.Long getUseTenantId();
    java.lang.String getStatus();
    java.lang.String getRemark();
    void setAppName(java.lang.String);
    void setAppVersion(java.lang.String);
    void setUseTenantId(java.lang.Long);
    void setStatus(java.lang.String);
    void setRemark(java.lang.String);
```

### `CtpManagerBaseAppDto`（8 方法）

`com.seeyon.ctp.manager.dto.CtpManagerBaseAppDto`

```java
    java.lang.String getAppName();
    java.lang.Boolean getOptional();
    java.lang.String getCaption();
    java.lang.Integer getIdx();
    void setAppName(java.lang.String);
    void setOptional(java.lang.Boolean);
    void setCaption(java.lang.String);
    void setIdx(java.lang.Integer);
```

### `CtpAdminConfigDto`（8 方法）

`com.seeyon.ctp.user.dto.CtpAdminConfigDto`

```java
    com.seeyon.ctp.user.enums.AdminTypeEnum getAdminType();
    java.util.List<java.lang.Long> getAuthUserIdList();
    java.util.List<java.lang.String> getAuthUserNameList();
    java.lang.Integer getDataSignSuccess();
    void setAdminType(com.seeyon.ctp.user.enums.AdminTypeEnum);
    void setAuthUserIdList(java.util.List<java.lang.Long>);
    void setAuthUserNameList(java.util.List<java.lang.String>);
    void setDataSignSuccess(java.lang.Integer);
```

### `CtpManagerTenantStatusDto`（6 方法）

`com.seeyon.ctp.manager.dto.CtpManagerTenantStatusDto`

```java
    java.lang.Long getUseTenantId();
    com.seeyon.ctp.manager.enums.TenantStatusEnum getStatus();
    java.util.Map<java.lang.String, java.lang.String> getErrorMap();
    void setUseTenantId(java.lang.Long);
    void setStatus(com.seeyon.ctp.manager.enums.TenantStatusEnum);
    void setErrorMap(java.util.Map<java.lang.String, java.lang.String>);
```

### `CtpManagerReplenishInitDto`（4 方法）

`com.seeyon.ctp.manager.dto.CtpManagerReplenishInitDto`

```java
    java.lang.String getAppName();
    java.lang.Long getUseTenantId();
    void setAppName(java.lang.String);
    void setUseTenantId(java.lang.Long);
```

## 四、枚举（54）

- `AppEntityManageModeEnum`（4 常量）：NONE, NO, INDEPENDENT, UNIFIED
- `AppSourceEnum`（6 常量）：NONE, SYSTEM, APP_STORE, THIRD_PARTY, SELF_BUILT, CDP_THIRD_PARTY
- `CapabilityTypeEnum`（5 常量）：NONE, CONFIG_TAB, PLUS_MSG, QUICK_MSG, ROBOT
- `ClientScopeEnum`（4 常量）：NONE, WEB, MOBILE, ALL
- `CtpAppHomePageTypeEnum`（5 常量）：NONE, PORTAL, NON_FIXED, APP, CUSTOM
- `CustomPlanSourceTypeEnum`（3 常量）：NONE, SYSTEM, CUSTOM
- `PlanAuthTypeEnum`（4 常量）：NONE, SYSTEM, ORG, MEMBER
- `TenantStatusEnum`（9 常量）：NONE_DB, NONE_CREATE, NONE, INIT, DISABLE, DELETE, ENABLE, ERROR, STOP
- `ActionSimpleTypeEnum`（3 常量）：NONE, CREATE, DELETE
- `ActionTypeEnum`（5 常量）：NONE, CREATE, MODIFY, DELETE, NO
- `AdminTypeEnum`（5 常量）：NONE, ORG, SECURITY, AUDITOR, ORG_MANAGER
- `ApprovalStatusEnum`（6 常量）：NONE, NO, PENDING, PASS, NO_PASS, KNOW
- `ApprovalTypeEnum`（8 常量）：NONE, ROLE, AUTH, MEMBER, SECRET_MEMBER, SECRET_POST, ACCOUNT_UNLOCK, IP_UNLOCK
- `AssignAppTypeEnum`（3 常量）：NONE, BACKEND, BUSINESS
- `AuthActionEnum`（3 常量）：NONE, GRANT, RECOVER
- `AuthRuleObjectDealTypeEnum`（3 常量）：NONE, MERGE, COVER
- `AuthRuleSourceEnum`（6 常量）：NONE, SYSTEM, APP, OPENAPI, ROLE, USER
- `AuthTypeEnum`（3 常量）：NONE, APP, ORG
- `AuthorizationOriginEnum`（4 常量）：NONE, USER, ORG, ROLE
- `AuthorizationRuleObjectTypeEnum`（10 常量）：NONE, INSTITUTION, DEPARTMENT, POST, JOB, LEVEL, TEAM, MEMBER, OUTSIDE_INSTITUTION, OUTSIDE_DEPARTMENT
- `BrowserOpenTypeEnum`（7 常量）：NONE, CURRENT, SYSTEM, EDGE, CHROME, IE, FIREFOX
- `ClientTypeEnum`（6 常量）：NONE, WEB, PC, MOBILE, PAD, THIRD
- `CtpUserTransferTypeEnum`（3 常量）：NONE, ORG_ROLE, APP_ROLE
- `CustomPermissionEnum`（5 常量）：NONE, SELECT_PEOPLE, INSTITUTION, INSTITUTIONS, SUB_INSTITUTIONS
- `DataPermissionScopeEnum`（9 常量）：NONE, NULL, ALL, SELF, DEPARTMENT, DEPARTMENTS, INSTITUTION, INSTITUTIONS, CUSTOM
- `DefaultIdentityTypeEnum`（4 常量）：NONE, FRONT, ADMIN, LAST
- `DefaultOrgScopeEnum`（9 常量）：NONE, ALL, SELF, INSTITUTION, INSTITUTIONS, UNIT, UNITS, SPECIFY_UNIT, SPECIFY_UNITS
- `DeviceTypeEnum`（9 常量）：NONE, WEB, PC, IOS, ANDROID, WECHAT, SINGLE, IOSPAD, ANDROIDPAD
- `IdentityTypeEnum`（6 常量）：NONE, FRONT, ADMINISTRATOR, GUEST, NATURAL_MEMBER, PUBLIC_ACCESS
- `LoginFromEnum`（7 常量）：NONE, NORMAL, CLOUD, SS0, NATURAL, OUTSIDE, SSO
- `ManageScopeEnum`（3 常量）：NONE, INSTITUTION, INSTITUTIONS
- `ManagerTypeEnum`（3 常量）：NONE, INSTITUTION, INSTITUTIONS
- `MenuStatusEnum`（4 常量）：NONE, ALL, NO_ALL, ONE_HALF
- `OrgScopeEnum`（13 常量）：NONE, INSTITUTION, INSTITUTIONS, ONLY_CHILDREN, SPECIFY_INSTITUTION, SPECIFY_INSTITUTIONS, UNIT, UNITS, ONLY_CHILDREN_UNITS, SPECIFY_UNIT, SPECIFY_UNITS, SPECIFY_BUSINESS …
- `OrgScopeOptionEnum`（3 常量）：NONE, IN, NOT_IN
- `OrgScopePropertyEnum`（3 常量）：NONE, UNIT_TYPE, UNIT_METADATA
- `PluginTypeEnum`（3 常量）：NONE, BASIC, VOUCHER
- `QrcodeScanEnum`（6 常量）：NONE, GENERATED, SCANNED_TODO, SCANNED, EXPIRED, ROUND
- `ResourceActionEnum`（5 常量）：NONE, basic, readonly, disabled, invisible
- `ResourceAppTypeEnum`（5 常量）：NONE, SYSTEM, BASIC, DESIGN, BUSINESS
- `ResourceAuthObjectTypeEnum`（11 常量）：NONE, INSTITUTION, DEPARTMENT, POST, JOB, LEVEL, TEAM, ROLE, MEMBER, OUTSIDE_INSTITUTION, OUTSIDE_DEPARTMENT
- `ResourceClientTypeEnum`（3 常量）：NONE, PC, MOBILE
- `ResourceOriginEnum`（3 常量）：NONE, SYSTEM, CUSTOM
- `ResourcePermissionBatchEnum`（4 常量）：NONE, SUCCESS, FAILED, ERROR
- `ResourcePermissionTypeEnum`（3 常量）：NONE, COVER, MERGE
- `ResourceTypeEnum`（10 常量）：NONE, MENU, PAGE, CONTROL, DATA, ENTITY, LAYOUT, SUBPAGE, NAV, GROUP
- `RoleCategoryEnum`（3 常量）：NONE, APP, ORG
- `RoleLevelEnum`（3 常量）：NONE, GROUP, INSTITUTION
- `RoleOriginEnum`（4 常量）：NONE, SYSTEM, ADMIN, APP
- `RolePermissionTypeEnum`（4 常量）：NONE, DATA, FIELD, FUNC
- `RoleTypeEnum`（4 常量）：NONE, PRESET, APP, ORG
- `ThirdPlatformTypeEnum`（5 常量）：NONE, WORK_WEI_XIN, DING_TALK, FEI_SHU, WEI_XIN_MP
- `UserDomainTypeEnum`（21 常量）：NONE, INSTITUTION, INSTITUTION_UP, DEPARTMENT, DEPARTMENT_UP, POST, JOB, LEVEL, MEMBER, TEAM, OUTSIDE_INSTITUTION, OUTSIDE_DEPARTMENT …
- `UserTypeEnum`（14 常量）：NONE, INTERNAL, EXTERNAL, VISITOR, DEVICE, ROBOT, ADMINISTRATOR, OPENAPI, OPS, CLOUD, NATURAL_MEMBER, GUEST …
