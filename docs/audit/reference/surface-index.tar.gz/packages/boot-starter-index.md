# boot-starter-index：接口与方法签名

> 自动生成，勿手改。`tools/core/platform/emit_package_surfaces.py` 重跑即可。
> 构件 `com.seeyon:boot-starter-index`（jar `boot-starter-index-5.3.265.jar`）
> 规模：24 类 / 0 接口 / 0 注解 / 0 枚举 / 7 个关键类 / 133 方法。
> 签名逐字来自 javap 原文；已去掉 `public` 前缀与 `throws` 子句。

## 一、接口（0）

（本构件没有接口）

## 二、关键类（7）

### `CombinerMetadataService`（9 方法）

`com.seeyon.boot.starter.index.combiner.service.CombinerMetadataService`

```java
    com.seeyon.ctp.metadata.dto.EntityMetadataDto selectEntityMetadataDtoByFullName(java.lang.String, java.lang.String);
    com.seeyon.ctp.metadata.dto.EntityMetadataDto getCacheEntityMetadata(java.lang.String, java.lang.String);
    com.seeyon.ctp.metadata.dto.EntityMetadataDto getEntityMetadataDto(java.lang.String, java.lang.String);
    com.seeyon.ctp.metadata.dto.ServiceMetadataDto getCacheServiceMetadataByName(java.lang.String);
    java.lang.Object getRelationEntityData(java.lang.String, java.lang.String, java.lang.String, java.lang.Long);
    private java.lang.String buildInterfaceName(java.lang.String, java.lang.String);
    private java.lang.String buildMethodName();
    private boolean isOrganizationApp(java.lang.String);
    private boolean isBpmApp(java.lang.String);
```

### `EnumDataManager`（7 方法）

`com.seeyon.boot.starter.index.combiner.manager.EnumDataManager`

```java
    java.lang.Object getCtpEnumNameByValue(java.lang.Long, java.lang.String);
    java.util.List<com.seeyon.boot.starter.enums.dto.CtpEnumItemDto> getAppEnumItemsByCode(java.lang.String, java.lang.String);
    java.lang.String getCtpEnumItemsById(java.lang.String, java.lang.String, java.lang.Object, boolean);
    java.lang.String getJavaEnumMetadataByName(java.lang.String, java.lang.String, java.lang.Object);
```

### `OrgEntityDataService`（6 方法）

`com.seeyon.boot.starter.index.combiner.service.OrgEntityDataService`

```java
    java.util.Map<java.lang.String, java.lang.String> getOrgEntityData(java.lang.String);
    java.util.Map<java.lang.String, java.lang.String> getOrgUnitData();
    java.util.Map<java.lang.String, java.lang.String> getOrgPostData();
    java.util.Map<java.lang.String, java.lang.String> getOrgJobData();
    java.util.Map<java.lang.String, java.lang.String> getOrgMemberData();
    java.util.Map<java.lang.String, java.lang.String> getOrgLevelData();
```

### `DataProcessorManager`（5 方法）

`com.seeyon.boot.starter.index.combiner.DataProcessorManager`

```java
    void afterPropertiesSet();
    void addEventDataInfo(com.seeyon.boot.starter.index.combiner.vo.EventDataInfo);
    protected void dataProcessorTask();
    private java.lang.String buildCacheKey();
```

### `DataProcessorService`（5 方法）

`com.seeyon.boot.starter.index.combiner.service.DataProcessorService`

```java
    com.seeyon.boot.starter.index.combiner.vo.EntityDataInfo parseEntityDataInfo(com.seeyon.boot.starter.index.combiner.vo.EventDataInfo);
    void process(com.seeyon.boot.starter.index.combiner.vo.EntityDataInfo);
    com.seeyon.boot.starter.index.combiner.vo.GlobalIndexInfo processRelation(com.seeyon.boot.starter.index.combiner.parse.EntityAttributeParser, java.lang.Long);
    boolean isFormEntity(com.seeyon.boot.starter.index.combiner.vo.EntityDataInfo);
    private boolean isDraftData(com.seeyon.boot.starter.index.combiner.vo.EntityDataInfo);
```

### `MetadataManager`（3 方法）

`com.seeyon.boot.starter.index.combiner.manager.MetadataManager`

```java
    com.seeyon.ctp.metadata.dto.EntityMetadataDto getEntityMetadata(com.seeyon.ctp.metadata.dto.request.SearchByFullNameDto);
    java.lang.Object getRelationEntityData(java.lang.String, java.lang.String, java.lang.String, java.lang.Long);
    com.seeyon.ctp.metadata.dto.ServiceMetadataDto selectServiceMetadataByName(java.lang.String);
```

### `CombinerDataSendService`（3 方法）

`com.seeyon.boot.starter.index.combiner.service.CombinerDataSendService`

```java
    void sendMessage(com.seeyon.boot.starter.index.combiner.vo.GlobalIndexInfo);
    void sendDeleteMessage(com.seeyon.boot.starter.index.combiner.vo.GlobalIndexInfo);
    com.seeyon.cdp.index.dto.IndexStoreDto buildIndexStoreDto(com.seeyon.boot.starter.index.combiner.vo.GlobalIndexInfo);
```
