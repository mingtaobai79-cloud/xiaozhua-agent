# boot-starter-prometheus：接口与方法签名

> 自动生成，勿手改。`tools/core/platform/emit_package_surfaces.py` 重跑即可。
> 构件 `com.seeyon:boot-starter-prometheus`（jar `boot-starter-prometheus-5.3.600.jar`）
> 规模：32 类 / 2 接口 / 4 注解 / 0 枚举 / 2 个关键类 / 122 方法。
> 签名逐字来自 javap 原文；已去掉 `public` 前缀与 `throws` 子句。

## 一、接口（2）

### `AlertRule`（1 方法）

`com.seeyon.boot.starter.prometheus.report.AlertRule`

```java
    void in(java.util.List<com.seeyon.boot.starter.prometheus.report.MetricValue>);
```

### `AlertTrigger`（1 方法）

`com.seeyon.boot.starter.prometheus.report.AlertTrigger`

```java
    void fireAlert(com.seeyon.boot.starter.prometheus.report.AlertSatisfied);
```

## 二、关键类（2）

### `NtpClient`（3 方法）

`com.seeyon.boot.starter.prometheus.ntp.NtpClient`

```java
    void setTimeout(int);
    static protected static double now();
    com.seeyon.boot.starter.prometheus.ntp.NtpResponse getResponse()
```

### `AlertRuleBuilder`（3 方法）

`com.seeyon.boot.starter.prometheus.report.AlertRuleBuilder`

```java
    static com.seeyon.boot.starter.prometheus.report.AlertRuleBuilder newBuilder();
    com.seeyon.boot.starter.prometheus.report.AlertRule buildOneTimeRange(java.lang.String, int, double, java.lang.String);
    com.seeyon.boot.starter.prometheus.report.AlertRule buildOneRateRange(java.lang.String, int, double, java.lang.String);
```

## 三、注解（4）

| 注解 | 元素 |
|---|---|
| `MetricMethodCounter` | metricType, metricName |
| `MetricMethodGauge` | metricType, metricName |
| `MetricMethodHistogram` | metricType, metricName |
| `MetricMethodSummary` | metricType, metricName |
