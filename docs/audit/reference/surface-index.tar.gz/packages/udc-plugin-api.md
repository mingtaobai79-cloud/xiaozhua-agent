# udc-plugin-api：接口与方法签名

> 自动生成，勿手改。`tools/core/platform/emit_package_surfaces.py` 重跑即可。
> 构件 `com.seeyon:udc-plugin-api`（jar `udc-plugin-api-5.3.517.jar`）
> 规模：307 类 / 71 接口 / 11 注解 / 26 枚举 / 25 个关键类 / 2667 方法。
> 签名逐字来自 javap 原文；已去掉 `public` 前缀与 `throws` 子句。

## 一、接口（71）

### `ApplicationAppService`（52 方法）

`com.seeyon.udc.api.ApplicationAppService`

```java
    com.seeyon.boot.transport.SingleResponse<java.lang.Long> create(com.seeyon.boot.transport.SingleRequest<com.seeyon.udc.common.dto.ApplicationDto>);
    com.seeyon.boot.transport.PageResponse<com.seeyon.udc.common.dto.ApplicationDto> selectPageByConditions(com.seeyon.boot.transport.PageRequest);
    com.seeyon.boot.transport.PageResponse<com.seeyon.udc.common.dto.ApplicationDto> selectAppPageByConditions(com.seeyon.boot.transport.PageRequest);
    com.seeyon.boot.transport.PageResponse<com.seeyon.udc.common.dto.ApplicationMultiVersionDto> selectAppPageByConditionsWithVersion(com.seeyon.boot.transport.PageRequest);
    com.seeyon.boot.transport.PageResponse<com.seeyon.udc.common.dto.SingleAppVersionInfoDto> selectAppPageByGuid(com.seeyon.boot.transport.PageRequest);
    com.seeyon.boot.transport.PageResponse<com.seeyon.udc.common.dto.ApplicationDto> selectTemplateAppPageByConditions(com.seeyon.boot.transport.PageRequest);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.udc.common.dto.ApplicationDto> selectById(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.udc.common.dto.ApplicationDto> selectByGuid(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.udc.common.dto.ApplicationDto> selectByIdUseAuth(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.udc.common.dto.ApplicationDto> selectDetailById(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.ListResponse<java.lang.String> selectPlatformVersion();
    com.seeyon.boot.transport.SingleResponse<java.util.Map> selectPlatformVersionMap();
    com.seeyon.boot.transport.ListResponse<com.seeyon.udc.common.dto.ApplicationHistoryVersionDto> selectHistoryById(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.udc.common.dto.ApplicationDto> selectByIds(com.seeyon.boot.transport.SingleRequest<java.util.List<java.lang.Long>>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> deleteById(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> deleteByGuid(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> deleteFormAppByGuid(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> update(com.seeyon.boot.transport.SingleRequest<com.seeyon.udc.common.dto.ApplicationDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> updateNoEvents(com.seeyon.boot.transport.SingleRequest<com.seeyon.udc.common.dto.ApplicationDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> updateCaptionForAllVersion(com.seeyon.boot.transport.SingleRequest<com.seeyon.udc.common.dto.ApplicationDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Long> createDepApp(com.seeyon.boot.transport.SingleRequest<com.seeyon.udc.common.dto.DependentApplicationDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> createDepAppBatch(com.seeyon.boot.transport.SingleRequest<java.util.List<com.seeyon.udc.common.dto.DependentApplicationDto>>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> updateDepApp(com.seeyon.boot.transport.SingleRequest<com.seeyon.udc.common.dto.DependentApplicationDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> updateBatchDepAppVersion(com.seeyon.boot.transport.SingleRequest<java.util.List<com.seeyon.udc.common.dto.DependentUpdateDto>>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> updateDepAppBatch(com.seeyon.boot.transport.SingleRequest<java.util.List<com.seeyon.udc.common.dto.DependentApplicationDto>>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> deleteDepAppsByAppId(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> deleteDepAppById(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> deleteDepAppsByIds(com.seeyon.boot.transport.SingleRequest<java.util.List<java.lang.Long>>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.udc.common.dto.DependentApplicationDto> selectDepAppListByAppId(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.udc.detection.dto.ConsistenceDetectionDto> selectDetectionListByAppId(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.udc.detection.dto.DetectionMessageDto> selectSummaryDetectionByAppId(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Boolean> detectionByAppId(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.udc.detection.dto.DetectionMessageDto> runDetectionState(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.udc.detection.dto.DetectionMessageDto> selectFrontDetectionByAppId(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Boolean> frontDetectionByAppId(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.SingleResponse<java.lang.String> downloadApp(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.udc.common.dto.ApplicationDto> selectByAppNames(com.seeyon.boot.transport.SingleRequest<java.util.List<java.lang.String>>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Long> copyApp(com.seeyon.boot.transport.SingleRequest<com.seeyon.udc.common.dto.ApplicationCopyDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Long> saveAsTemplate(com.seeyon.boot.transport.SingleRequest<com.seeyon.udc.common.dto.ApplicationCopyDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Long> createFromTemplate(com.seeyon.boot.transport.SingleRequest<com.seeyon.udc.common.dto.TemplateApplicationDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Boolean> renewalAppEditingTime(java.lang.Long);
    com.seeyon.boot.transport.SingleResponse<java.lang.Boolean> isExclusive(java.lang.Long);
    com.seeyon.boot.transport.ListResponse<com.seeyon.udc.common.dto.AppDesignDto> selectDesignDataChange(java.util.List<java.lang.Long>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.udc.common.dto.AppDesignDto> checkDesignModifiedAfterLastRelease(java.lang.Long);
    com.seeyon.boot.transport.SingleResponse<java.lang.Long> saveAsNewDesign(java.lang.Long);
    com.seeyon.boot.transport.SingleResponse<java.lang.Long> saveAsNormalNewDesign(com.seeyon.udc.common.dto.ApplicationSaveAsDto);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.udc.common.dto.DeployParamDto> deployNormal(com.seeyon.boot.transport.SingleRequest<com.seeyon.udc.common.dto.DeployNormalDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.udc.common.dto.DeployResultDto> deployForm(com.seeyon.boot.transport.SingleRequest<com.seeyon.udc.common.dto.DeployFormDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.udc.common.dto.MultiVersionDto> selectMultiVersion(com.seeyon.boot.transport.SingleRequest<com.seeyon.udc.common.dto.VersionSearchDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.udc.common.dto.DependentApplicationDto> selectDepByCondition(com.seeyon.boot.transport.ListRequest);
    com.seeyon.boot.transport.SingleResponse<java.lang.String> importAppZipIntoCurrentApp(java.lang.Long, java.lang.String, java.lang.String);
    com.seeyon.boot.transport.SingleResponse<java.lang.String> importAppOnlineIntoCurrentApp(java.lang.Long, java.lang.Long, java.lang.String);
```

### `PartDetectionTask`（18 方法）

`com.seeyon.udc.detection.PartDetectionTask`

```java
    java.lang.String getTargetDomainObject();
    java.lang.String getSourceDomainObject();
    default java.util.Set<java.lang.String> getCascadeAttrs();
    default java.util.List<com.seeyon.udc.detection.dto.CascadeHandleLogDto> cascadeHandleAffected(com.seeyon.udc.detection.context.DetectionContext);
    default java.util.Set<com.seeyon.udc.detection.dto.ConsistenceDetectionDto> detectionAffected(com.seeyon.udc.detection.context.DetectionContext);
    default java.util.Set<com.seeyon.udc.detection.dto.ConsistenceDetectionDto> detectionSelf(com.seeyon.udc.detection.context.DetectionContext);
    void setSelfIds(java.util.Set<java.lang.Long>);
    java.util.Set<java.lang.Long> getSelfIds();
    void setSourceDeleteIds(java.util.Set<java.lang.Long>);
    java.util.Set<java.lang.Long> getSourceDeleteIds();
    void setSourceDeleteIdDtoMap(java.util.Map<java.lang.Long, ? extends com.seeyon.boot.transport.BaseTraceableDto>);
    java.util.Map<java.lang.Long, ? extends com.seeyon.boot.transport.BaseTraceableDto> getSourceDeleteIdDtoMap();
    void setSourceUpdateIds(java.util.Set<java.lang.Long>);
    java.util.Set<java.lang.Long> getSourceUpdateIds();
    void setSourceUpdateIdDtoMap(java.util.Map<java.lang.Long, ? extends com.seeyon.boot.transport.BaseTraceableDto>);
    java.util.Map<java.lang.Long, ? extends com.seeyon.boot.transport.BaseTraceableDto> getSourceUpdateIdDtoMap();
    void setChangedCascadeAttrs(java.util.Map<java.lang.Long, java.util.Map<java.lang.String, cn.hutool.core.lang.Pair<java.lang.Object, java.lang.Object>>>);
    java.util.Map<java.lang.Long, java.util.Map<java.lang.String, cn.hutool.core.lang.Pair<java.lang.Object, java.lang.Object>>> getChangedCascadeAttrs();
```

### `AppFeatureHandler`（17 方法）

`com.seeyon.udc.common.application.feature.handler.AppFeatureHandler`

```java
    java.lang.String getHostAppName(com.seeyon.udc.common.dto.ApplicationDto);
    java.lang.String getAppUrl(com.seeyon.udc.common.dto.ApplicationDto);
    com.seeyon.udc.common.dto.AppDbInfoDto getAppDbInfo(com.seeyon.udc.common.dto.ApplicationDto);
    com.seeyon.udc.common.application.feature.AbstractAppFeature getAppFeatureByAppType(com.seeyon.udc.common.enums.ApplicationFeatureEnum);
    java.lang.String getVersion4JavaPackage(com.seeyon.udc.common.dto.ApplicationDto);
    default java.lang.String getJavaBasePackage(com.seeyon.udc.common.dto.ApplicationDto);
    default java.lang.String getAppName4Package(com.seeyon.udc.common.dto.ApplicationDto);
    default java.lang.String getAppDeployVersion(com.seeyon.udc.common.dto.ApplicationDto);
    boolean isRunInHostApp(com.seeyon.udc.common.dto.ApplicationDto);
    boolean isDynamicService(com.seeyon.udc.common.dto.ApplicationDto);
    boolean onlyRootAggregation(com.seeyon.udc.common.dto.ApplicationDto);
    java.util.List<com.seeyon.boot.starter.extmetadata.dto.UdcApplicationMetaDataDto> getAvailableAppMetaDataList(com.seeyon.udc.common.enums.ApplicationFeatureEnum, java.util.List<com.seeyon.ctp.metadata.dto.ServiceMetadataDto>);
    java.util.List<com.seeyon.udc.common.dto.DependentApplicationDto> getDefaultDependDtoList(com.seeyon.udc.common.dto.ApplicationDto);
    java.util.List<com.seeyon.udc.common.dto.DependentApplicationDto> handleDependVersion(com.seeyon.udc.common.dto.ApplicationDto, java.util.List<com.seeyon.udc.common.dto.DependentApplicationDto>);
    java.util.Map<java.lang.String, java.lang.String> getHostAppVersionMapping(com.seeyon.udc.common.dto.ApplicationDto);
    java.util.List<com.seeyon.udc.common.dto.DependentApplicationDto> getStarterDependVersion(com.seeyon.udc.common.dto.ApplicationDto, java.util.List<com.seeyon.udc.common.dto.DependentApplicationDto>);
    void buildApplicationDto4Create(com.seeyon.udc.common.dto.ApplicationDto);
```

### `UdcCtpEnumAppService`（16 方法）

`com.seeyon.udc.api.UdcCtpEnumAppService`

```java
    com.seeyon.boot.transport.ListResponse<com.seeyon.boot.starter.enums.dto.CtpEnumCategoryDto> selectCategoryByAppGuid(com.seeyon.boot.transport.SingleRequest<com.seeyon.udc.common.dto.UdcCtpEnumBaseSearchDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.boot.starter.enums.dto.CtpEnumCategoryAndEnumDto> selectCategoryAndEnum(com.seeyon.boot.transport.SingleRequest<com.seeyon.udc.common.dto.UdcCtpEnumBaseSearchDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.boot.starter.enums.dto.CtpEnumDto> selectCtpEnum(com.seeyon.boot.transport.SingleRequest<com.seeyon.udc.common.dto.UdcCtpEnumBaseSearchDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.boot.starter.enums.dto.CtpEnumDto> selectCtpEnumByIds(com.seeyon.boot.transport.SingleRequest<com.seeyon.udc.common.dto.UdcCtpEnumsSearchDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.boot.starter.enums.dto.CtpEnumDto> selectParentByCode(com.seeyon.boot.transport.SingleRequest<com.seeyon.udc.common.dto.UdcCtpEnumSearchDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.boot.starter.enums.dto.CtpEnumDto> selectListByConditionsNoLevel(com.seeyon.boot.transport.SingleRequest<com.seeyon.udc.common.dto.UdcCtpEnumSearchDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.boot.starter.enums.dto.CtpEnumItemDto> selectCtpEnumItemById(com.seeyon.boot.transport.SingleRequest<com.seeyon.udc.common.dto.UdcCtpEnumItemSearchDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.boot.starter.enums.dto.CtpEnumItemDto> selectCtpEnumItemByAppInfo(com.seeyon.boot.transport.SingleRequest<com.seeyon.udc.common.dto.UdcCtpEnumBaseSearchDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.boot.starter.enums.dto.CtpEnumItemDto> selectCtpEnumItemByEnumId(com.seeyon.boot.transport.SingleRequest<com.seeyon.udc.common.dto.UdcCtpEnumItemSearchDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.boot.starter.enums.dto.CtpEnumItemDto> selectCtpEnumItemByAppNameAndEnumCode(com.seeyon.boot.transport.SingleRequest<com.seeyon.udc.common.dto.UdcCtpEnumItemSearchDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.boot.starter.enums.dto.CtpEnumItemSimpleDto> selectCtpEnumItemSimpleByAppNameAndEnumCode(com.seeyon.boot.transport.SingleRequest<com.seeyon.udc.common.dto.UdcCtpEnumItemSearchDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.boot.starter.enums.dto.CtpEnumItemSimpleDto> selectCtpEnumItemSimpleByAppNameAndEnumCodes(com.seeyon.boot.transport.SingleRequest<com.seeyon.udc.common.dto.UdcCtpEnumItemSearchDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.boot.starter.enums.dto.CtpEnumItemDto> selectByEnumIds(com.seeyon.boot.transport.SingleRequest<com.seeyon.udc.common.dto.UdcCtpEnumItemSearchDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.boot.starter.enums.dto.CtpEnumItemDto> selectEnumItemByConditions(com.seeyon.boot.transport.SingleRequest<com.seeyon.udc.common.dto.UdcCtpEnumItemSearchDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.boot.starter.enums.dto.CtpEnumItemDto> selectEnumItemCascadeTreeByEnumCode(com.seeyon.boot.transport.SingleRequest<com.seeyon.udc.common.dto.UdcCtpEnumItemSearchDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> deleteCtpEnumByAppApprovalOrUdc(com.seeyon.boot.transport.SingleRequest<com.seeyon.udc.common.dto.UdcCtpEnumItemSearchDto>);
```

### `Feature`（16 方法）

`com.seeyon.udc.entity.stereotype.Feature`

```java
    java.lang.Long getId();
    java.lang.String getName();
    java.lang.String getCaption();
    java.lang.String getDescription();
    java.lang.Boolean nonIgnored();
    java.lang.Boolean isIgnored();
    java.lang.Boolean nonDeprecated();
    java.lang.Boolean isDeprecated();
    java.lang.Boolean isConfigurable();
    java.lang.Boolean isStereotypeBind();
    java.lang.String getConfiguration();
    java.lang.Integer getOrder();
    java.lang.String getAttributeSet();
    java.util.List<com.seeyon.udc.common.dto.AttributeDto> getAttributes();
    java.util.List<com.seeyon.udc.dto.BehaviorDto> getBehaviors();
    java.lang.Boolean isProcessEmbedded();
```

### `AppDeployContext`（15 方法） extends MetaDatable, AppContext

`com.seeyon.udc.common.metadata.AppDeployContext`

```java
    java.lang.String getBaseProjectPath();
    default java.lang.String getMetadataPath(com.seeyon.udc.common.enums.MetaDataTypeEnum, java.lang.String...);
    default java.lang.String getJarVersion();
    default java.lang.Long getDeployId();
    default java.lang.Long getTenantId();
    default com.seeyon.udc.common.enums.DeployTypeEnum getDeployType();
    default com.seeyon.udc.common.dto.AppDeployInfo getAppDeployInfo();
    default com.seeyon.udc.common.dto.DeploySchemeInfoDto getLastDeploySchemeInfo();
    default com.seeyon.udc.common.enums.TerminalTypeEnum getDeployTerminalType();
    default boolean isCrossEnv();
    default boolean isFirstDeploy();
    default boolean isCurrentVersionFirstDeploy();
    default com.seeyon.boot.starter.autocode.metadata.MetaDatable getParent();
```

### `ApplicationInnerReference`（14 方法）

`com.seeyon.udc.common.autocode.ApplicationInnerReference`

```java
    java.util.Collection<java.lang.Long> getEntityBackwardRefPages(java.lang.String);
    java.util.Collection<java.lang.String> getEntityBackwardRefPageUrls(java.lang.String, com.seeyon.udc.common.enums.PageUrlTypeEnum);
    java.util.Collection<java.lang.Long> getMicroFlowBackwardRefPages(java.lang.Long);
    java.util.Collection<java.lang.Long> getDataflowBackwardRefPages(java.lang.Long);
    java.util.Collection<java.lang.String> getControlRestUrls(java.lang.String);
    java.util.Collection<java.lang.String> getDependencyEntities();
    java.util.List<com.seeyon.udc.dto.FileReferenceDto> getFileReferences();
    java.util.Map<java.lang.String, java.util.Set<java.lang.String>> getDependencyAppEntities();
    java.util.Map<java.lang.String, java.util.Collection<java.lang.String>> getPageUrlResourceMapping();
    java.util.Map<java.lang.Long, java.util.List<com.seeyon.udc.dto.datasource.EntityDataSourceDto>> getPageEntityDataSource();
    java.util.Map<java.lang.Long, java.lang.Long> getPageIdGuidMap();
    java.util.Map<java.lang.Long, java.util.Set<java.lang.Long>> getFilterPlanIds();
    java.util.Map<java.lang.Long, java.util.Map<java.lang.String, java.util.Set<java.lang.String>>> getFilterPlanRelatedCmpIdMap();
    java.util.Map<java.lang.Long, java.util.Map<java.lang.String, java.util.List<java.util.Map>>> getResourceAuth();
```

### `CodeContext`（13 方法） extends Lifecycle, ConfigurableCodeContext, AppDeployContext

`com.seeyon.udc.common.autocode.context.CodeContext`

```java
    com.seeyon.udc.common.autocode.config.AutoCodeProperties getAutoCodeProperties();
    com.seeyon.udc.common.transport.VersionControl getVersionControl();
    java.lang.String getBasePackage();
    java.lang.String getAppName4Package();
    default java.lang.String getPackage(com.seeyon.udc.common.dto.ApplicationDto, java.lang.String...);
    java.lang.String getAppName();
    java.lang.String getBasePackagePathStr();
    java.lang.String getModelJavaPath(java.lang.String, java.lang.String...);
    java.lang.String getModelResourcePath(java.lang.String, java.lang.String...);
    java.lang.String getAuthor();
    java.lang.String getCreateTime();
    com.seeyon.udc.common.dto.AppDbInfoDto getAppDbInfoDto();
    com.seeyon.udc.common.autocode.i18n.I18nContext getI18nContext();
```

### `Importable`（11 方法）

`com.seeyon.udc.common.autocode.transport.upgrade.Importable`

```java
    default void importValidate(com.seeyon.udc.common.schema.TransportDataExploration);
    default void before(com.seeyon.udc.common.schema.TransportData);
    void in(com.seeyon.udc.common.schema.TransportData)
    default boolean matches(com.seeyon.udc.common.schema.TransportData);
    default void transfer(com.seeyon.udc.common.schema.TransportData)
    default <T> boolean transferFilter(com.seeyon.udc.common.schema.TransferData, java.lang.String, java.lang.Class<T>);
    default java.util.Set<java.lang.String> ignoreOnDefaultCopy();
    default <T extends com.seeyon.boot.domain.entity.BaseEntity> void createBatchOnExists(java.util.List, com.seeyon.boot.starter.mybatis.BaseMybatisDao<T>, java.lang.Class<T>);
    default java.lang.String getName();
    default void importAppInfo(com.seeyon.udc.common.schema.TransportData)
    default void afterImportUpgrade(com.seeyon.udc.common.dto.ApplicationDto, com.seeyon.udc.common.transport.TransportTypeEnum);
```

### `Stereotype`（11 方法）

`com.seeyon.udc.entity.Stereotype`

```java
    java.lang.String getName();
    java.lang.String getCaption();
    java.lang.Integer getOrder();
    java.lang.Boolean nonDeprecated();
    java.lang.Boolean getDeprecated();
    java.lang.String getDescription();
    java.util.List<java.lang.String> getFeatures();
    java.util.List<java.lang.String> getAvailableFeatures();
    java.util.List<java.lang.String> getNecessaryFeatures();
    java.lang.Boolean getDataFlowEnabled();
    java.lang.Boolean getProcessEmbedded();
```

### `ConfigurableCodeContext`（10 方法） extends AutoCodeContext

`com.seeyon.udc.common.autocode.config.ConfigurableCodeContext`

```java
    com.seeyon.udc.common.autocode.extension.param.CodeParam getCodeParam();
    void setCodeParam(com.seeyon.udc.common.autocode.extension.param.CodeParam);
    void registerUpdateChange(liquibase.change.Change);
    void registerDmlFileInfo(java.util.List<com.seeyon.udc.common.autocode.db.change.DmlFileDto>);
    void registerStaticFileInfo(java.util.List<com.seeyon.udc.common.autocode.file.StaticFileDto>);
    default boolean isDeploy();
    default void runAsyncTimeout(com.seeyon.udc.common.concurrent.NamedFutureTask<java.lang.String>);
    default void processAsync(com.seeyon.udc.common.concurrent.NamedFutureTask<java.lang.String>);
    default java.util.Set<java.lang.String> getComparedSchemaIdSet();
    default void writeTenantFile(java.lang.String, java.lang.String);
```

### `PluginDefinition`（8 方法）

`com.seeyon.udc.PluginDefinition`

```java
    java.lang.String getName();
    java.lang.String getCode();
    default java.util.Collection<com.seeyon.udc.common.autocode.CodeTask> getCodeTasks();
    default java.util.Collection<com.seeyon.udc.autocode.PomDependency> getPomDependencies();
    default java.util.Collection<com.seeyon.udc.detection.DetectionTask> getConsistenceDetections();
    default java.util.Collection<com.seeyon.udc.detection.PartDetectionTask> getPartConsistenceDetections();
    default java.util.Collection<java.lang.String> getDependencies();
    default java.util.Collection<com.seeyon.udc.common.autocode.transport.TransportHandler> getTransportHandlers();
```

### `UdcPortalPortletAppService`（7 方法）

`com.seeyon.udc.api.UdcPortalPortletAppService`

```java
    com.seeyon.boot.transport.SingleResponse<java.lang.Long> createCategory(com.seeyon.boot.transport.SingleRequest<com.seeyon.udc.common.dto.UdcPortalPortletCategoryDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Long> updateCategory(com.seeyon.boot.transport.SingleRequest<com.seeyon.udc.common.dto.UdcPortalPortletCategoryDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> deleteCategoryByIds(com.seeyon.boot.transport.SingleRequest<java.util.List<java.lang.String>>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Long> createOrUpdatePortlet(com.seeyon.boot.transport.SingleRequest<com.seeyon.udc.common.dto.UdcPortalPortletDefinitionDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> deletePortletByIds(com.seeyon.boot.transport.SingleRequest<com.seeyon.udc.common.dto.UdcPortletBatchOperateDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> updatePortletSortNos(com.seeyon.boot.transport.SingleRequest<com.seeyon.udc.common.dto.UdcPortalPortletSortNoParamDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Long> updatePortletName(com.seeyon.boot.transport.SingleRequest<com.seeyon.udc.common.dto.UdcPortalPortletDefinitionDto>);
```

### `ResourceAppService`（6 方法）

`com.seeyon.udc.api.ResourceAppService`

```java
    com.seeyon.boot.transport.SingleResponse<java.lang.Long> registerRole(com.seeyon.boot.transport.SingleRequest<com.seeyon.udc.dto.user.UdcRoleRegisterDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> registerResourceBatch(com.seeyon.boot.transport.SingleRequest<java.util.List<com.seeyon.udc.dto.user.UdcResourceRegisterDto>>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> registerResource(com.seeyon.boot.transport.SingleRequest<com.seeyon.udc.dto.user.UdcResourceRegisterDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> deleteByRef(com.seeyon.boot.transport.SingleRequest<com.seeyon.udc.dto.user.UdcResourceDeleteDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> deleteByPage(com.seeyon.boot.transport.SingleRequest<com.seeyon.udc.dto.user.UdcResourceDeleteDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> deleteByApp(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
```

### `UdcCtpEnumProxyAppService`（6 方法）

`com.seeyon.udc.api.UdcCtpEnumProxyAppService`

```java
    com.seeyon.boot.transport.SingleResponse<com.seeyon.boot.starter.enums.dto.CtpEnumItemDto> selectOneByIdAndApp(com.seeyon.boot.transport.SingleRequest<java.util.Map<java.lang.String, java.lang.Object>>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.boot.starter.enums.dto.CtpEnumItemSimpleDto> selectByEnumCodeAndAppGuid(com.seeyon.boot.transport.SingleRequest<java.util.Map<java.lang.String, java.lang.Object>>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.boot.starter.enums.dto.CtpEnumItemSimpleDto> selectByEnumCodesAndAppGuid(com.seeyon.boot.transport.SingleRequest<java.util.Map<java.lang.String, java.lang.Object>>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.boot.starter.enums.dto.CtpEnumItemDto> selectCascadeTreeByEnumCode(com.seeyon.boot.transport.SingleRequest<java.util.Map<java.lang.String, java.lang.Object>>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.boot.starter.enums.dto.CtpEnumItemSimpleDto> selectByEnumItemByDependentApp(com.seeyon.boot.transport.SingleRequest<java.util.Map<java.lang.String, java.lang.Object>>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.boot.starter.enums.dto.CtpEnumItemSimpleDto> selectByEnumItemByDependentApp(com.seeyon.udc.common.dto.DependentApplicationDto);
```

### `TransportHandler`（6 方法）

`com.seeyon.udc.common.autocode.transport.TransportHandler`

```java
    java.util.List<com.seeyon.udc.common.transport.SchemaInfo> out(com.seeyon.udc.common.autocode.context.CodeContext)
    default com.seeyon.udc.common.autocode.transport.compare.ComparisonResponse compare(com.seeyon.udc.common.autocode.transport.SchemaComparisonSourcePool);
    default void buildDmlFileDto(java.util.List<? extends com.seeyon.boot.domain.entity.BaseEntity>, java.util.List<com.seeyon.udc.common.autocode.db.change.DmlFileDto>);
    default void buildDmlFileDto(java.lang.String, java.lang.String, java.util.List<com.seeyon.udc.common.autocode.db.change.DmlFileDto>);
    default boolean isFormDeploy(com.seeyon.udc.common.autocode.context.CodeContext);
    default java.lang.String group();
```

### `ElementRepository`（6 方法） extends BaseTraceableDto>

`com.seeyon.udc.model.ElementRepository`

```java
    com.seeyon.udc.model.ElementType getType();
    T selectById(java.lang.Long);
    java.util.List<T> selectByAppId(java.lang.Long);
    default java.util.List<T> selectByIds(java.util.List<java.lang.Long>);
    default java.util.List<com.seeyon.udc.dto.ReferenceSearchResultDto> selectByIds4Search(java.util.List<java.lang.Long>);
```

### `OperationRecordService`（6 方法）

`com.seeyon.udc.operationlog.OperationRecordService`

```java
    com.seeyon.udc.operationlog.dto.OperationLogDetailsDto buildOperationLogDetailsDto4Create(T);
    com.seeyon.udc.operationlog.dto.OperationLogDetailsDto buildOperationLogDetailsDto4CreateBatch(java.util.List<T>);
    com.seeyon.udc.operationlog.dto.OperationLogDetailsDto buildOperationLogDetailsDto4Update(T);
    com.seeyon.udc.operationlog.dto.OperationLogDetailsDto buildOperationLogDetailsDto4UpdateBatch(java.util.List<T>);
    com.seeyon.udc.operationlog.dto.OperationLogDetailsDto buildOperationLogDetailsDto4delete(java.lang.Long);
    com.seeyon.udc.operationlog.dto.OperationLogDetailsDto buildOperationLogDetailsDto4deleteBatch(java.util.List<java.lang.Long>);
```

### `LastVersionMetadataManagerService`（5 方法）

`com.seeyon.udc.api.LastVersionMetadataManagerService`

```java
    java.util.List<com.seeyon.udc.dto.LastVersionMetadataDto> prepareLastVersionAfterDeployed(com.seeyon.udc.common.dto.ApplicationDto);
    com.seeyon.udc.dto.LastVersionMetadataDto fetchLastVersionMetadataFromDbIfNotExist(com.seeyon.udc.dto.user.LastVersionMetadataSearchDto);
    com.seeyon.udc.common.enums.LastVersionMetadataModuleEnum getModule();
    default com.seeyon.udc.common.enums.PublishStateEnum getRelationModulePublishState(com.seeyon.udc.dto.user.LastVersionMetadataSearchDto);
    default java.util.List<com.seeyon.udc.dto.LastVersionMetadataDto> refreshLastVersionMetadata(com.seeyon.udc.common.dto.ApplicationDto);
```

### `PluginPageInfoAppService`（5 方法）

`com.seeyon.udc.api.PluginPageInfoAppService`

```java
    com.seeyon.boot.transport.SingleResponse<com.seeyon.udc.common.dto.FilterPlanContentDto> createDefaultFilterPlanContentByEntityId(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.udc.common.dto.FilterPlanContentDto> createDefaultFilterPlanContentByEntity(com.seeyon.boot.transport.SingleRequest<com.seeyon.udc.common.dto.EntityDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.udc.dto.user.UdcResourceRegisterDto> parsePageResource(com.seeyon.boot.transport.SingleRequest<java.util.Map<java.lang.String, java.lang.Object>>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.udc.dto.user.UdcResourceRegisterDto> getResourceByCondition(com.seeyon.boot.transport.SingleRequest<com.seeyon.udc.dto.user.UdcResourceRegisterDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.udc.dto.user.UdcResourceRegisterDto> getResource4UserCenter(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
```

### `UdcSerialSchemeAppService`（5 方法）

`com.seeyon.udc.api.UdcSerialSchemeAppService`

```java
    com.seeyon.boot.transport.ListResponse<com.seeyon.boot.starter.serialnumber.domain.dto.SerialSchemeDto> selectSerialScheme(com.seeyon.boot.transport.SingleRequest<com.seeyon.udc.common.dto.UdcSerialSchemeSearchDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.boot.starter.serialnumber.domain.dto.SerialSchemeDto> selectSerialSchemeById(com.seeyon.boot.transport.SingleRequest<com.seeyon.udc.common.dto.UdcSerialSchemeSearchDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.boot.starter.serialnumber.domain.dto.SerialRangeDto> selectSerialRange(com.seeyon.boot.transport.SingleRequest<com.seeyon.udc.common.dto.UdcSerialRangeSearchDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Long> createEasyScheme(com.seeyon.boot.transport.SingleRequest<com.seeyon.udc.common.dto.UdcSerialSchemeCreateDto>);
    default com.seeyon.boot.transport.ListResponse<com.seeyon.boot.starter.serialnumber.domain.dto.SerialSchemeDto> selectDepAppSerialScheme(com.seeyon.boot.transport.SingleRequest<java.util.List<com.seeyon.udc.common.dto.DependentApplicationDto>>);
```

### `DetectionContext`（5 方法） extends AppContext

`com.seeyon.udc.detection.context.DetectionContext`

```java
    void start();
    void stop(com.seeyon.udc.detection.enums.DetectionStatusEnum);
    boolean isRunning();
    boolean passDetection();
    <T> T getDetectionMetadataRepository();
```

### `FrontDeployDetectionContext`（5 方法） extends DetectionContext

`com.seeyon.udc.detection.context.FrontDeployDetectionContext`

```java
    java.util.Date getLastDeployTime();
    com.seeyon.udc.common.dto.DeploySchemeInfoDto getLastDeploySchemeInfoDto();
    com.seeyon.udc.common.enums.TerminalTypeEnum getDeployTerminalType();
    com.seeyon.udc.common.metadata.AppSchemaContext getAppSchemaContext();
    <T> T getAppSchemaMetadata(java.lang.String);
```

### `ConsistenceDetectionAppService`（4 方法）

`com.seeyon.udc.api.ConsistenceDetectionAppService`

```java
    void updateDetection(com.seeyon.boot.transport.SingleRequest<java.lang.Class<? extends com.seeyon.boot.domain.entity.BaseEntity>>, com.seeyon.boot.transport.SingleRequest<java.lang.Class>, com.seeyon.boot.transport.SingleRequest<java.util.List<java.lang.Long>>);
    void updateDetection4Dto(com.seeyon.boot.transport.SingleRequest<java.lang.Class<? extends com.seeyon.boot.domain.entity.BaseEntity>>, com.seeyon.boot.transport.SingleRequest<java.lang.Class>, com.seeyon.boot.transport.SingleRequest<java.util.List<? extends com.seeyon.boot.transport.BaseTraceableDto>>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.udc.detection.dto.ConsistenceDetectionDto> selectDetectionListByAppId(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    void deleteDetection(com.seeyon.boot.transport.SingleRequest<java.lang.Class<? extends com.seeyon.boot.domain.entity.BaseEntity>>, com.seeyon.boot.transport.SingleRequest<java.lang.Class>, com.seeyon.boot.transport.SingleRequest<java.util.List<? extends com.seeyon.boot.transport.BaseTraceableDto>>);
```

### `UdcFunctionAppService`（4 方法）

`com.seeyon.udc.api.UdcFunctionAppService`

```java
    void createFunctionRefer(com.seeyon.boot.transport.SingleRequest<java.util.Map<java.lang.String, java.lang.Object>>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> deletePortalFunctionRefer(com.seeyon.boot.transport.SingleRequest<java.util.Map<java.lang.String, java.lang.Object>>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> updateFunctionRefer(com.seeyon.boot.transport.SingleRequest<java.util.Map<java.lang.String, java.lang.Object>>);
    com.seeyon.boot.transport.SingleResponse<java.util.Map<java.lang.Long, java.lang.Object>> findMenuDefaultPage(com.seeyon.boot.transport.SingleRequest<java.util.List<java.lang.Long>>);
```

### `AppFeature`（4 方法）

`com.seeyon.udc.common.application.feature.AppFeature`

```java
    com.seeyon.udc.common.enums.ApplicationFeatureEnum getTypeEnum();
    java.lang.String getName();
    java.lang.String getCaptionI18n();
    boolean isDynamicService();
```

### `SplitHandler`（4 方法）

`com.seeyon.udc.common.autocode.transport.coli.SplitHandler`

```java
    default void postProcessContext(com.seeyon.udc.common.autocode.transport.coli.SplitContext);
    com.seeyon.udc.common.coli.ModuleDependency getRelation(com.seeyon.udc.common.autocode.transport.coli.SplitContext);
    default void resolveCustomRelation(com.seeyon.udc.common.coli.ModuleDependency, com.seeyon.udc.common.autocode.transport.coli.SplitContext);
    default java.util.List<com.seeyon.udc.common.transport.SchemaInfo> prepareApp(java.util.List<com.seeyon.udc.common.coli.DependencyNode>, java.util.List<com.seeyon.udc.common.transport.SchemaInfo>, com.seeyon.udc.common.autocode.transport.coli.SplitContext);
```

### `AppContext`（4 方法） extends MetaDatable

`com.seeyon.udc.common.metadata.AppContext`

```java
    com.seeyon.udc.common.dto.ApplicationDto getAppInfo();
    default com.seeyon.udc.common.listener.AppContextListener getAppContextListener();
    default java.lang.String getLogSuffix();
    default java.lang.Long getTenantId();
```

### `PluginExecutor`（4 方法）

`com.seeyon.udc.plugin.PluginExecutor`

```java
    void execute(E);
    void executeAsync(E);
    void execute(E, java.lang.String...);
    java.util.Map<java.lang.String, T> getAllHandler();
```

### `PluginReferConfigGroupAppService`（3 方法）

`com.seeyon.udc.api.PluginReferConfigGroupAppService`

```java
    com.seeyon.boot.transport.SingleResponse<java.lang.Long> createDefaultRefer(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Void> updateDefaultRefer(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> deleteDefaultRefer(com.seeyon.boot.transport.SingleRequest<java.util.List<java.lang.Long>>);
```

### `UdcPageLayoutPluginAppService`（3 方法）

`com.seeyon.udc.api.UdcPageLayoutPluginAppService`

```java
    com.seeyon.boot.transport.ListResponse<com.seeyon.boot.starter.extmetadata.dto.UdcApplicationMetaDataDto> filterDependentApplicationList(com.seeyon.boot.transport.SingleRequest<java.util.List<com.seeyon.boot.starter.extmetadata.dto.UdcApplicationMetaDataDto>>);
    com.seeyon.boot.transport.ListResponse<java.lang.String> allowDependentLayoutApplicationList(com.seeyon.boot.transport.SingleRequest<com.seeyon.udc.common.dto.ApplicationDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.udc.common.enums.ApplicationFeatureEnum> filterApplicationFeature(com.seeyon.boot.transport.SingleRequest<com.seeyon.udc.common.dto.ApplicationDto>);
```

### `AuthCheck`（3 方法）

`com.seeyon.udc.auth.AuthCheck`

```java
    com.seeyon.udc.auth.dto.AuthCheckResultDto check(com.seeyon.udc.auth.AuthOperationType, com.seeyon.udc.common.dto.UdcBaseEntityDto);
    com.seeyon.udc.auth.dto.AuthCheckResultDto check(com.seeyon.udc.auth.AuthOperationType, java.lang.Long);
    java.lang.String getModelName();
```

### `Lifecycle`（3 方法）

`com.seeyon.udc.common.autocode.context.Lifecycle`

```java
    void start();
    int stop();
    boolean isRunning();
```

### `SaveAsHandler`（3 方法）

`com.seeyon.udc.common.autocode.transport.saveas.SaveAsHandler`

```java
    default void before(com.seeyon.udc.common.schema.TransportData);
    void saveAs(com.seeyon.udc.common.schema.TransportData)
    default void normalSaveAs(com.seeyon.udc.common.schema.TransportData)
```

### `ConsistenceDetection`（3 方法）

`com.seeyon.udc.detection.ConsistenceDetection`

```java
    java.lang.Class<? extends com.seeyon.boot.domain.entity.BaseEntity> getDomainObject();
    <T extends com.seeyon.boot.transport.BaseTraceableDto> java.util.List<com.seeyon.udc.detection.dto.ConsistenceDetectionDto> delDetection(java.util.List<java.lang.Long>, java.util.List<T>);
    <T extends com.seeyon.boot.transport.BaseTraceableDto> java.util.List<com.seeyon.udc.detection.dto.ConsistenceDetectionDto> updateDetection(java.util.List<T>, java.util.List<T>);
```

### `EntitySaveProcessor`（3 方法）

`com.seeyon.udc.entity.stereotype.EntitySaveProcessor`

```java
    void afterEntitySaved(com.seeyon.udc.common.dto.EntityDto, com.seeyon.udc.common.dto.EntityDto);
    void resolveAttribute4Feature(com.seeyon.udc.common.dto.EntityDto, com.seeyon.udc.common.dto.EntityDto, java.util.List<com.seeyon.udc.common.dto.AttributeDto>);
    void afterEntityDeleted(com.seeyon.udc.common.dto.EntityDto);
```

### `ReferenceParser`（3 方法）

`com.seeyon.udc.model.ReferenceParser`

```java
    java.util.Collection<com.seeyon.udc.model.Relation> parse(T);
    java.util.Collection<com.seeyon.udc.model.Relation> scan(java.lang.Long);
    com.seeyon.udc.model.ElementType getSourceType();
```

### `ApplicationShelfService`（2 方法）

`com.seeyon.udc.api.ApplicationShelfService`

```java
    default java.lang.String module();
    void updateStateAfterAppShelf(com.seeyon.udc.common.dto.ApplicationDto);
```

### `LateralAuthChecker`（2 方法）

`com.seeyon.udc.api.LateralAuthChecker`

```java
    void check(java.util.function.Supplier<java.lang.Long>);
    void checkByAppName(java.util.function.Supplier<java.lang.String>);
```

### `PluginEntityAppService`（2 方法）

`com.seeyon.udc.api.PluginEntityAppService`

```java
    com.seeyon.boot.transport.SingleResponse<java.lang.Long> create(com.seeyon.boot.transport.SingleRequest<com.seeyon.udc.common.dto.EntityDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> update(com.seeyon.boot.transport.SingleRequest<com.seeyon.udc.common.dto.EntityDto>);
```

### `ColiImportable`（2 方法） extends Importable

`com.seeyon.udc.common.autocode.transport.coli.ColiImportable`

```java
    default void preImport(com.seeyon.udc.common.autocode.transport.coli.SplitImportContext);
    default void afterImport(com.seeyon.udc.common.autocode.transport.coli.SplitImportContext);
```

### `ContextListener`（2 方法）

`com.seeyon.udc.common.metadata.ContextListener`

```java
    boolean onAdd(com.seeyon.udc.common.metadata.AppContext);
    boolean onRemove(com.seeyon.udc.common.metadata.AppContext);
```

### `SchemaFilter`（2 方法）

`com.seeyon.udc.common.transport.SchemaFilter`

```java
    boolean matches(java.lang.String, java.lang.String);
    com.seeyon.udc.common.transport.SchemaInfo filter(com.seeyon.udc.common.transport.SchemaInfo, com.seeyon.udc.common.transport.SchemaInfo);
```

### `DetectionTask`（2 方法）

`com.seeyon.udc.detection.DetectionTask`

```java
    java.util.Set<java.lang.String> getDomainObjects();
    boolean detection(com.seeyon.udc.detection.context.DetectionContext);
```

### `LastFrontMetaDataContextPostProcess`（2 方法）

`com.seeyon.udc.detection.context.metadata.LastFrontMetaDataContextPostProcess`

```java
    void loadMetaDataContext(com.seeyon.udc.detection.context.FrontDeployDetectionContext);
    <T> java.util.List<T> readDirectoryToDtoList(java.lang.String, com.seeyon.udc.common.enums.MetaDataTypeEnum, java.lang.Class<T>);
```

### `SqlProcessor`（2 方法）

`com.seeyon.udc.entity.stereotype.SqlProcessor`

```java
    java.lang.String getSql(com.seeyon.udc.common.dto.EntityDto);
    java.lang.String getName();
```

### `DeployBeforeService`（1 方法） extends Condition

`com.seeyon.udc.api.DeployBeforeService`

```java
    boolean handle(com.seeyon.udc.common.metadata.AppContext)
```

### `DeployFinishService`（1 方法） extends Condition

`com.seeyon.udc.api.DeployFinishService`

```java
    default boolean callback(com.seeyon.udc.dto.DeployCallbackDto);
```

### `ExprConsistencyValidator`（1 方法）

`com.seeyon.udc.api.ExprConsistencyValidator`

```java
    com.seeyon.udc.dto.expression.ConsistencyValidateResult validateConsistency(com.seeyon.udc.dto.expression.ConsistencyValidateConfig);
```

### `ExtendAppOperationAuthCheck`（1 方法）

`com.seeyon.udc.api.ExtendAppOperationAuthCheck`

```java
    boolean hasRight(com.seeyon.udc.dto.ExtendAppAuthCheckInfoDto);
```

### `MetadataHandleService`（1 方法） extends Condition

`com.seeyon.udc.api.MetadataHandleService`

```java
    boolean handle(com.seeyon.udc.common.metadata.AppContext);
```

### `PluginAttributeAppService`（1 方法）

`com.seeyon.udc.api.PluginAttributeAppService`

```java
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> createBatch(com.seeyon.boot.transport.SingleRequest<java.util.List<com.seeyon.udc.common.dto.AttributeDto>>);
```

### `UdcBpmAppService`（1 方法）

`com.seeyon.udc.api.UdcBpmAppService`

```java
    com.seeyon.boot.transport.SingleResponse<java.lang.String> selectDefaultLayoutAppName();
```

### `UdcPortalSetAppService`（1 方法）

`com.seeyon.udc.api.UdcPortalSetAppService`

```java
    com.seeyon.boot.transport.SingleResponse<java.lang.Long> createPcTemplateData(com.seeyon.boot.transport.SingleRequest<com.seeyon.udc.common.dto.UdcPortalSetDesignerDto>);
```

### `UdcPortalSpaceAppService`（1 方法）

`com.seeyon.udc.api.UdcPortalSpaceAppService`

```java
    com.seeyon.boot.transport.ListResponse<com.seeyon.udc.common.dto.UdcPortalSpaceDto> selectDesignSpaceList(com.seeyon.boot.transport.SingleRequest<java.util.List<java.lang.Long>>);
```

### `CodeTask`（1 方法）

`com.seeyon.udc.common.autocode.CodeTask`

```java
    java.lang.String code(com.seeyon.udc.common.autocode.context.CodeContext)
```

### `Recoverable`（1 方法）

`com.seeyon.udc.common.autocode.Recoverable`

```java
    void recover();
```

### `I18nHandler`（1 方法）

`com.seeyon.udc.common.autocode.i18n.I18nHandler`

```java
    void handle(T, com.seeyon.udc.common.autocode.i18n.I18nContext);
```

### `CodeContextAware`（1 方法）

`com.seeyon.udc.common.autocode.metadata.CodeContextAware`

```java
    void setCodeContext(com.seeyon.udc.common.autocode.context.CodeContext);
```

### `TenantDataFilter`（1 方法）

`com.seeyon.udc.common.autocode.transport.TenantDataFilter`

```java
    java.lang.String filter(java.lang.String, java.util.List<java.lang.Object>);
```

### `Compatible`（1 方法）

`com.seeyon.udc.common.autocode.transport.compare.Compatible`

```java
    com.seeyon.udc.common.autocode.transport.compare.ComparisonResponse compare(com.seeyon.udc.common.autocode.context.CodeContext, java.util.List<com.seeyon.udc.common.transport.SchemaInfo>, java.util.List<com.seeyon.udc.common.transport.SchemaInfo>);
```

### `AppContextListener`（1 方法）

`com.seeyon.udc.common.listener.AppContextListener`

```java
    default <R> R process(com.seeyon.udc.common.listener.ProcessCallable<R>);
```

### `AppMetaDataContextPostProcess`（1 方法）

`com.seeyon.udc.common.metadata.AppMetaDataContextPostProcess`

```java
    void postProcessAppMetaDataContext(com.seeyon.udc.common.metadata.AppContext);
```

### `Condition`（1 方法）

`com.seeyon.udc.deploy.Condition`

```java
    default boolean matches(com.seeyon.udc.common.metadata.AppContext);
```

### `FrontDeployDetectionTask`（1 方法）

`com.seeyon.udc.detection.FrontDeployDetectionTask`

```java
    boolean detection(com.seeyon.udc.detection.context.FrontDeployDetectionContext);
```

### `DetectionMetadataAware`（1 方法）

`com.seeyon.udc.detection.context.metadata.DetectionMetadataAware`

```java
    void init(com.seeyon.udc.detection.context.DetectionContext, java.util.Set<java.lang.String>);
```

### `PluginHandler`（1 方法）

`com.seeyon.udc.plugin.handler.PluginHandler`

```java
    void execute(T);
```

### `CommonSchemaKey`（0 方法）

`com.seeyon.udc.common.autocode.transport.CommonSchemaKey`

```java
```

### `CompleteMultiVersionPluginHandler`（0 方法） extends Map>>

`com.seeyon.udc.plugin.handler.multiversion.CompleteMultiVersionPluginHandler`

```java
```

### `MultiVersionPluginHandler`（0 方法） extends ApplicationDto>

`com.seeyon.udc.plugin.handler.multiversion.MultiVersionPluginHandler`

```java
```

### `SandboxPluginHandler`（0 方法） extends SandboxTransportDto>

`com.seeyon.udc.plugin.handler.sandbox.SandboxPluginHandler`

```java
```

## 二、关键类（25）

### `PageSchemaUtils`（86 方法）

`com.seeyon.udc.page.util.PageSchemaUtils`

```java
    static java.util.Map<java.lang.String, com.fasterxml.jackson.databind.node.ObjectNode> parseNodeContainDs(com.seeyon.udc.common.dto.PageSchemaDto);
    static java.util.Map<java.lang.String, com.fasterxml.jackson.databind.node.ObjectNode> parseNodeContainEvents(com.seeyon.udc.common.dto.PageSchemaDto);
    static java.util.Map<java.lang.String, com.fasterxml.jackson.databind.node.ObjectNode> parsePreDetectedNode4Report(com.seeyon.udc.common.dto.PageSchemaDto);
    static java.util.Map<java.lang.String, java.util.Map<cn.hutool.core.lang.Pair<java.lang.String, java.lang.String>, cn.hutool.core.lang.Pair<java.lang.String, java.lang.String>>> parseInParams(com.seeyon.udc.common.dto.PageSchemaDto);
    static java.util.List<java.lang.String> parseLayoutParamsMapping(java.lang.String, java.lang.String);
    static java.util.List<java.lang.String> paramsMappingAdapter(java.util.List<java.lang.String>);
    static java.util.List<java.lang.String> parseSubPageParamsMappingIds(java.lang.String);
    static java.util.Map<java.lang.String, cn.hutool.core.lang.Pair<java.lang.String, java.util.Set<java.lang.String>>> parseNodes4ContainNotExistWidget(com.seeyon.udc.common.dto.PageSchemaDto);
    static private static void detectExpressionBySchemaPath(java.util.Map<java.lang.String, cn.hutool.core.lang.Pair<java.lang.String, java.util.Set<java.lang.String>>>, java.util.Set<java.lang.String>, java.util.Map<java.lang.String, java.lang.Object>, com.fasterxml.jackson.databind.node.ObjectNode);
    static private static void detectExpressionByFixedPath(java.util.Map<java.lang.String, cn.hutool.core.lang.Pair<java.lang.String, java.util.Set<java.lang.String>>>, java.util.Set<java.lang.String>, com.fasterxml.jackson.databind.node.ObjectNode);
    static private static void detectExpression(java.util.Map<java.lang.String, cn.hutool.core.lang.Pair<java.lang.String, java.util.Set<java.lang.String>>>, java.util.Set<java.lang.String>, java.util.Collection<java.lang.String>, java.lang.String, com.fasterxml.jackson.databind.node.ObjectNode);
    static java.util.Map<java.lang.String, com.fasterxml.jackson.databind.node.ObjectNode> parseNodes(com.seeyon.udc.common.dto.PageSchemaDto, java.lang.String);
    static java.util.Map<java.lang.String, com.fasterxml.jackson.databind.node.ObjectNode> parseNodeByWidGetType(com.seeyon.udc.common.dto.PageSchemaDto, java.util.Set<java.lang.String>);
    static java.lang.Object getByPath(java.lang.String, java.lang.String);
    static boolean usedOutsideLayout(java.lang.String);
    static boolean usedLayout(java.lang.String);
    static boolean usedLayout(cn.hutool.json.JSONObject);
    static java.util.List<java.lang.String> parseLayoutPlaceholders(java.lang.String);
    static java.util.List<java.lang.String> parsePagePlaceholders(cn.hutool.json.JSONObject);
    static private static java.lang.String containNotExistWidgetPath(java.util.Set<java.lang.String>, com.fasterxml.jackson.databind.node.ObjectNode, java.lang.String);
    static java.util.Map<java.lang.String, java.util.Set<java.lang.String>> parseWidgetByExpSchema(java.lang.String);
    static private static java.util.List<com.seeyon.boot.starter.formula.dto.ExpressionToken> parseExpressionTokens(java.lang.String);
    static cn.hutool.core.lang.Pair<java.lang.String, java.util.Set<java.lang.String>> parseWidget(java.lang.String);
    static cn.hutool.core.lang.Pair<java.lang.String, java.util.List<java.lang.String>> parseExpTokenWidget(java.lang.String);
    static private static java.lang.String[] getExpWidgetArray(java.lang.String);
    static private static cn.hutool.core.lang.Pair<java.lang.String, java.util.List<java.lang.String>> buildExpAppParamPair(java.lang.String);
    static java.util.Map<java.lang.String, com.fasterxml.jackson.databind.node.ObjectNode> parsePreDetectedNode(java.util.Map<java.lang.String, com.fasterxml.jackson.databind.node.ObjectNode>, java.lang.String);
    static java.util.Map<java.lang.String, com.fasterxml.jackson.databind.node.ObjectNode> parsePreDetectedNode4Columns(java.util.Map<java.lang.String, com.fasterxml.jackson.databind.node.ObjectNode>);
    static java.util.Map<java.lang.String, com.fasterxml.jackson.databind.node.ObjectNode> parsePreDetectedNode4Refer(java.util.Map<java.lang.String, com.fasterxml.jackson.databind.node.ObjectNode>);
    static java.lang.String writeSchema(com.fasterxml.jackson.databind.JsonNode);
    static com.fasterxml.jackson.databind.JsonNode parseSchema(java.lang.String);
    static <T> T getNode(com.fasterxml.jackson.databind.JsonNode, java.lang.String);
    static java.lang.String getTextValue(com.fasterxml.jackson.databind.JsonNode, java.lang.String);
    static java.util.Map<java.lang.String, java.lang.Object> getComponentInfo(com.jayway.jsonpath.DocumentContext, java.util.List<java.lang.String>, int);
    static java.util.Map<java.lang.String, java.lang.Object> getComponentInfo(java.util.List<java.util.Map<java.lang.String, java.lang.Object>>, java.util.List<java.lang.String>, int);
    static java.util.Map<java.lang.String, java.lang.Object> getChildByIdComponentInfo(com.jayway.jsonpath.DocumentContext, java.util.List<java.lang.String>);
    static java.lang.String getComponentName(com.fasterxml.jackson.databind.node.ObjectNode);
    static java.lang.String getComponentName(java.util.Map<java.lang.String, java.lang.Object>);
    static java.lang.String getString4Component(java.util.Map, java.lang.Object, java.lang.String);
    static java.lang.String getComponentId(com.jayway.jsonpath.DocumentContext, java.util.List<java.lang.String>, int);
    static boolean hasChildren(com.jayway.jsonpath.DocumentContext);
    static boolean hasChildren(java.lang.String);
    static java.lang.String pageSchemaToPortletSchema(com.seeyon.udc.page.dto.PageInfoDto, java.lang.String);
    static private static java.lang.String parseInParamsFullName(cn.hutool.json.JSONObject, java.lang.String);
    static private static java.util.function.Predicate<java.util.Map$Entry<java.lang.String, com.fasterxml.jackson.databind.node.ObjectNode>> findObjectNodePredicate(java.lang.String);
    static private static java.util.function.Predicate<java.util.Map$Entry<java.lang.String, com.fasterxml.jackson.databind.node.ObjectNode>> findObjectNodePredicateBySettingsPro(java.lang.String);
    static private static java.util.function.Predicate<java.util.Map$Entry<java.lang.String, com.fasterxml.jackson.databind.node.ObjectNode>> findObjectNodePredicateForColumns();
    static cn.hutool.json.JSONObject parseJson4PageSchema(java.lang.String);
    static java.util.List<java.lang.Object> parseEventTypeOnDefineInPageSchema(java.lang.String);
    static java.util.List<java.lang.Object> parseEventTypeOnDefineInParams(java.lang.String);
    static java.util.Map<org.apache.commons.lang3.tuple.Triple<java.lang.String, java.lang.String, java.lang.Boolean>, java.util.Map<java.lang.String, java.lang.Object>> parsePageSchemaRangeMap(com.seeyon.udc.common.dto.PageSchemaDto);
    static java.util.Map<java.lang.String, java.util.Map<java.lang.String, java.lang.Object>> detectionAttValidation(java.lang.String, java.lang.String);
    static private static java.lang.String getRequiredValue(java.util.Map<java.lang.String, java.lang.Object>);
    static java.util.Map<java.lang.String, java.util.Map<java.lang.String, java.lang.Object>> parseAttValidationFieldMap(java.lang.String, java.util.Map<java.lang.String, java.util.Map<java.lang.String, java.lang.Object>>);
    static <T extends com.seeyon.udc.common.dto.UdcBaseEntityDto> java.util.Map<java.lang.String, java.util.List<cn.hutool.core.lang.Pair<java.lang.String, java.lang.String>>> checkReferredFrontendMicroFlow(com.seeyon.udc.common.dto.PageSchemaDto, com.jayway.jsonpath.DocumentContext, java.util.Map<java.lang.Long, T>, java.util.function.Function<T, com.seeyon.udc.common.enums.MicroFlowDataStateEnum>);
    static org.apache.commons.lang3.tuple.MutableTriple<java.lang.String, java.lang.String, java.lang.String> frontendMicroFlowRoute(com.jayway.jsonpath.DocumentContext, java.util.Map$Entry<java.lang.String, java.util.List<cn.hutool.core.lang.Pair<java.lang.String, java.lang.String>>>);
    static java.lang.String getEventsPropTag(java.util.Map<java.lang.String, java.lang.Object>, java.lang.String, java.util.List<java.lang.String>);
```

### `RedisDetectionUtils`（40 方法）

`com.seeyon.udc.detection.persistent.RedisDetectionUtils`

```java
    static java.lang.String getDetectionOptKey(java.lang.String);
    static java.lang.String getDetectionErrorKey(java.lang.String);
    static java.lang.String getDetectionErrorDataKey(java.lang.String);
    static java.lang.String getDetectionErrorCountKey(java.lang.String);
    static java.lang.String getFrontDetectionErrorCountKey(java.lang.String);
    static java.lang.String getProgressPrefixKey(java.lang.String);
    static java.lang.String getDetectionRunStateKey(java.lang.String);
    static java.lang.String getDistributedLockKey(java.lang.String);
    static java.lang.Long save(org.springframework.data.redis.core.RedisTemplate<java.lang.String, java.lang.Object>, java.lang.Long, java.lang.String, java.lang.String, java.lang.String, java.util.Map<java.lang.Long, java.util.Set<com.seeyon.udc.detection.dto.ConsistenceDetectionDto>>);
    static java.lang.Long merge(org.springframework.data.redis.core.RedisTemplate<java.lang.String, java.lang.Object>, java.lang.Long, java.lang.String, java.lang.String, java.lang.String, java.util.Map<java.lang.Long, java.util.Set<com.seeyon.udc.detection.dto.ConsistenceDetectionDto>>);
    static java.util.Set<java.lang.Long> getLastDifference(org.springframework.data.redis.core.RedisTemplate<java.lang.String, java.lang.Object>, java.lang.String, java.util.Map<java.lang.Long, java.util.Set<com.seeyon.udc.detection.dto.ConsistenceDetectionDto>>);
    static void delete(org.springframework.data.redis.core.RedisTemplate<java.lang.String, java.lang.Object>, java.lang.Long, java.lang.String, java.lang.String, java.util.Set<java.lang.Long>);
    static void deleteByAppId(org.springframework.data.redis.core.RedisTemplate<java.lang.String, java.lang.Object>, java.lang.String);
    static java.util.Set<com.seeyon.udc.detection.dto.ConsistenceDetectionDto> selectDetectionSetByAppId(java.lang.String);
    static java.util.Set<com.seeyon.udc.detection.dto.ConsistenceDetectionDto> selectDetectionSetByAppId(org.springframework.data.redis.core.RedisTemplate<java.lang.String, java.lang.Object>, java.lang.String);
    static com.seeyon.udc.detection.dto.DetectionMessageDto selectFrontDetectionByAppId(java.lang.String);
    static com.seeyon.udc.detection.dto.DetectionMessageDto selectDetectionCountByAppId(java.lang.String);
    static com.seeyon.udc.detection.dto.DetectionMessageDto selectDetectionCountByAppId(org.springframework.data.redis.core.RedisTemplate<java.lang.String, java.lang.Integer>, java.lang.String);
    static <T> void saveOptData(org.springframework.data.redis.core.RedisTemplate<java.lang.String, java.lang.Object>, java.lang.String, java.lang.Long, java.util.Collection<T>, java.lang.String);
    static java.util.Map<java.lang.String, java.util.Map<java.lang.String, java.util.Set<com.seeyon.boot.transport.BaseTraceableDto>>> queryAndDeleteOptData(org.springframework.data.redis.core.RedisTemplate<java.lang.String, java.lang.Object>, java.lang.Long);
    static private static <T> java.util.Map<java.lang.String, java.util.Map<java.lang.String, java.util.Set<T>>> getAndDeleteOptData(org.springframework.data.redis.core.RedisTemplate<java.lang.String, java.lang.Object>, java.lang.String);
    static private static <T> java.util.Map<java.lang.String, java.util.Set<T>> getOptDataMap(org.springframework.data.redis.core.RedisTemplate<java.lang.String, java.lang.Object>, java.util.Set<java.lang.String>, java.lang.String);
    static java.util.Set<java.lang.String> getMembers(org.springframework.data.redis.core.RedisTemplate<java.lang.String, java.lang.Object>, java.lang.String);
    static com.seeyon.udc.common.enums.ModuleTypeEnum getModuleType(java.lang.String);
    static private static <T> java.util.Set<java.lang.Long> getIds(java.util.Set<T>);
    static private static <T> java.lang.Long getId(T);
    static com.seeyon.udc.detection.dto.DetectionMessageDto getDetectionCount(java.util.Set<com.seeyon.udc.detection.dto.ConsistenceDetectionDto>);
```

### `ReferConfigDto`（38 方法）

`com.seeyon.udc.dto.ReferConfigDto`

```java
    java.lang.Long getId();
    java.lang.String getCaption();
    java.lang.String getType();
    java.lang.String getDisplayName();
    java.lang.String getPullDisplayName();
    java.lang.String getDetailPage();
    java.lang.Long getDetailPageId();
    java.lang.String getConfigInfo();
    java.lang.Boolean getIsDefault();
    java.lang.Long getAppId();
    java.lang.Long getEntityId();
    com.seeyon.udc.common.enums.TerminalTypeEnum getTerminalType();
    java.lang.Long getGroupId();
    com.seeyon.udc.common.enums.ReferConfigSourceTypeEnum getSourceType();
    java.lang.Long getPageId();
    java.lang.String getRelationApp();
    java.lang.String getRelationEntity();
    java.lang.String getSourceRefer();
    com.seeyon.boot.enums.ActionType getActionType();
    void setId(java.lang.Long);
    void setCaption(java.lang.String);
    void setType(java.lang.String);
    void setDisplayName(java.lang.String);
    void setPullDisplayName(java.lang.String);
    void setDetailPage(java.lang.String);
    void setDetailPageId(java.lang.Long);
    void setConfigInfo(java.lang.String);
    void setIsDefault(java.lang.Boolean);
    void setAppId(java.lang.Long);
    void setEntityId(java.lang.Long);
    void setTerminalType(com.seeyon.udc.common.enums.TerminalTypeEnum);
    void setGroupId(java.lang.Long);
    void setSourceType(com.seeyon.udc.common.enums.ReferConfigSourceTypeEnum);
    void setPageId(java.lang.Long);
    void setRelationApp(java.lang.String);
    void setRelationEntity(java.lang.String);
    void setSourceRefer(java.lang.String);
    void setActionType(com.seeyon.boot.enums.ActionType);
```

### `AppFeatureHandlerFacade`（18 方法）

`com.seeyon.udc.common.application.feature.AppFeatureHandlerFacade`

```java
    void afterSingletonsInstantiated();
    private com.seeyon.udc.common.application.feature.handler.AppFeatureHandler getAppFeatureHandler(com.seeyon.udc.common.enums.ApplicationFeatureEnum);
    java.lang.String getHostAppName(com.seeyon.udc.common.dto.ApplicationDto);
    java.lang.String getAppUrl(com.seeyon.udc.common.dto.ApplicationDto);
    com.seeyon.udc.common.dto.AppDbInfoDto getAppDbInfo(com.seeyon.udc.common.dto.ApplicationDto);
    com.seeyon.udc.common.application.feature.AbstractAppFeature getAppFeatureByAppType(com.seeyon.udc.common.enums.ApplicationFeatureEnum);
    java.lang.String getVersion4JavaPackage(com.seeyon.udc.common.dto.ApplicationDto);
    java.lang.String getAppDeployVersion(com.seeyon.udc.common.dto.ApplicationDto);
    boolean isRunInHostApp(com.seeyon.udc.common.dto.ApplicationDto);
    boolean isDynamicService(com.seeyon.udc.common.dto.ApplicationDto);
    boolean onlyRootAggregation(com.seeyon.udc.common.dto.ApplicationDto);
    java.util.List<com.seeyon.boot.starter.extmetadata.dto.UdcApplicationMetaDataDto> getAvailableAppMetaDataList(com.seeyon.udc.common.enums.ApplicationFeatureEnum, java.util.List<com.seeyon.ctp.metadata.dto.ServiceMetadataDto>);
    java.util.List<com.seeyon.udc.common.dto.DependentApplicationDto> getDefaultDependDtoList(com.seeyon.udc.common.dto.ApplicationDto);
    java.util.List<com.seeyon.udc.common.dto.DependentApplicationDto> handleDependVersion(com.seeyon.udc.common.dto.ApplicationDto, java.util.List<com.seeyon.udc.common.dto.DependentApplicationDto>);
    java.util.List<com.seeyon.udc.common.dto.DependentApplicationDto> getStarterDependVersion(com.seeyon.udc.common.dto.ApplicationDto, java.util.List<com.seeyon.udc.common.dto.DependentApplicationDto>);
    void buildApplicationDto4Create(com.seeyon.udc.common.dto.ApplicationDto);
    java.util.Map<java.lang.String, java.lang.String> getHostAppVersionMapping(com.seeyon.udc.common.dto.ApplicationDto);
```

### `ObjectCompareUtil`（15 方法）

`com.seeyon.udc.common.utils.ObjectCompareUtil`

```java
    static private static java.util.List<java.beans.PropertyDescriptor> getPropertyDescriptors(java.lang.Class, java.lang.Class);
    static <T extends com.seeyon.boot.transport.BaseTraceableDto> java.util.Map<java.lang.Long, java.util.Map<java.lang.String, cn.hutool.core.lang.Pair<java.lang.Object, java.lang.Object>>> compareDtoChangedAttr(java.util.Collection<cn.hutool.core.lang.Pair<T, T>>, java.util.Set<java.lang.String>);
    static <T extends com.seeyon.boot.transport.BaseTraceableDto> java.util.Map<java.lang.Long, java.util.Map<java.lang.String, cn.hutool.core.lang.Pair<java.lang.Object, java.lang.Object>>> compareDtoChangedAttrWithOutIgnore(java.util.Collection<cn.hutool.core.lang.Pair<T, T>>, java.util.Set<java.lang.String>);
    static <T extends com.seeyon.boot.transport.BaseTraceableDto> java.util.Map<java.lang.Long, java.util.Map<java.lang.String, cn.hutool.core.lang.Pair<java.lang.Object, java.lang.Object>>> compareDtoChangedAttr(java.util.List<T>, java.util.Map<java.lang.Long, T>, java.util.function.Function<T, java.lang.Long>, java.lang.String[]);
    static boolean compareObject(java.lang.Object, java.lang.Object);
    static boolean compareObject(java.lang.Object, java.lang.Object, java.lang.String[], boolean);
    static java.util.Map<java.lang.String, cn.hutool.core.lang.Pair<java.lang.Object, java.lang.Object>> compareFieldsWithIgnore(java.lang.Object, java.lang.Object, java.util.List<java.lang.String>);
    static java.util.Map<java.lang.String, cn.hutool.core.lang.Pair<java.lang.Object, java.lang.Object>> compareFields(java.lang.Object, java.lang.Object, java.lang.String[]);
```

### `ImportConfig`（12 方法）

`com.seeyon.udc.common.schema.ImportConfig`

```java
    java.util.List<java.lang.String> models();
    void addModel(java.lang.String);
    boolean containsModelData(java.lang.String, java.lang.String);
    boolean isCustomerResolve(java.lang.String, java.lang.String);
    void addUdcCustomerResolveDataId(java.lang.String);
    void addCustomerResolveDataId(java.lang.String, java.lang.String);
    void addVersion(java.lang.String);
    boolean existModel(java.lang.String);
    boolean existVersion(java.lang.String);
    void checkVersion(java.lang.String[]);
```

### `AbstractPluginExecutor`（12 方法）

`com.seeyon.udc.plugin.AbstractPluginExecutor`

```java
    void setApplicationContext(org.springframework.context.ApplicationContext)
    void execute(E);
    void executeAsync(E);
    void execute(E, java.lang.String...);
    java.util.Map<java.lang.String, T> getAllHandler();
    void afterSingletonsInstantiated();
    private void runExplainCostTime(com.seeyon.udc.plugin.handler.PluginHandler, java.lang.Object);
```

### `OperationLogUtil`（9 方法）

`com.seeyon.udc.operationlog.utils.OperationLogUtil`

```java
    static void compareStringAttribute(java.lang.String, java.lang.String, java.lang.String, java.util.List<com.seeyon.udc.operationlog.dto.AttributeRecordDto>);
    static void compareStringAttribute(java.lang.String, java.lang.String, java.lang.String, java.util.List<com.seeyon.udc.operationlog.dto.AttributeRecordDto>, java.util.Map<java.lang.String, java.lang.String>, java.lang.String);
    static void compareStringAttributeWithoutValue(java.lang.String, java.lang.String, java.lang.String, java.util.List<com.seeyon.udc.operationlog.dto.AttributeRecordDto>);
    static void compareJsonAttribute(java.lang.String, java.lang.String, java.lang.String, java.util.List<com.seeyon.udc.operationlog.dto.AttributeRecordDto>);
    static void buildAttributeRecord4ObjectValue(java.lang.String, java.lang.String, java.lang.Object, java.lang.Object, java.util.List<com.seeyon.udc.operationlog.dto.AttributeRecordDto>);
    static void compareExpressionAttribute(java.lang.String, java.lang.String, java.lang.String, java.util.List<com.seeyon.udc.operationlog.dto.AttributeRecordDto>);
    static java.lang.String getExpressionTranslation(java.lang.String);
```

### `CommonSchemaImportPluginHandlerAdapter`（8 方法）

`com.seeyon.udc.common.autocode.transport.upgrade.CommonSchemaImportPluginHandlerAdapter`

```java
    protected abstract void onImport(com.seeyon.udc.common.schema.TransportData);
    final void execute(com.seeyon.udc.common.schema.TransportData);
    protected <T> java.lang.Object getCommonSchema(com.seeyon.udc.common.schema.TransportData, java.lang.String, java.lang.Class<T>);
    protected java.lang.Object getCommonSchema(com.seeyon.udc.common.schema.TransportData, java.lang.String);
    protected java.util.Map<java.lang.String, java.lang.String> getStorageKeyMap(com.seeyon.udc.common.schema.TransportData, java.lang.String);
    protected java.lang.String getTargetStorageKey(com.seeyon.udc.common.schema.TransportData, java.lang.String, java.lang.String);
    protected java.util.List<com.seeyon.boot.starter.file.dto.FileDto> getCommonAttachmentFileDtoList(com.seeyon.udc.common.schema.TransportData, java.lang.String);
    void execute(java.lang.Object);
```

### `ConsistencyValidateConfig`（7 方法）

`com.seeyon.udc.dto.expression.ConsistencyValidateConfig`

```java
    static com.seeyon.udc.dto.expression.ConsistencyValidateConfig$ConsistencyValidateConfigBuilder builder();
    com.seeyon.udc.detection.context.DetectionContext getDetectionContext();
    com.seeyon.boot.starter.formula.dto.ExpressionDefinitionDto getExpressionDefinitionDto();
    java.lang.String getResultType();
    void setDetectionContext(com.seeyon.udc.detection.context.DetectionContext);
    void setExpressionDefinitionDto(com.seeyon.boot.starter.formula.dto.ExpressionDefinitionDto);
    void setResultType(java.lang.String);
```

### `ImportUtil`（6 方法）

`com.seeyon.udc.common.autocode.util.ImportUtil`

```java
    static java.lang.String repeatInfo4ImportAppSchema(java.util.Collection<java.lang.String>, java.lang.String, int, com.seeyon.udc.common.dto.ApplicationDto);
    static java.lang.String repeatInfo4ImportAppSchema(java.util.Collection<java.lang.String>, java.lang.String, int, com.seeyon.udc.common.dto.ApplicationDto, int);
    static java.lang.String repeatName4ImportAppSchema(java.util.Collection<java.lang.String>, java.lang.String, int, com.seeyon.udc.common.dto.ApplicationDto);
    static java.lang.String repeatName4ImportAppSchema(java.util.Collection<java.lang.String>, java.lang.String, int, com.seeyon.udc.common.dto.ApplicationDto, int);
    static java.lang.String repeatInfoWithSuffix(java.util.Collection<java.lang.String>, java.lang.String, int, java.lang.String[], int);
```

### `MapUtils`（5 方法）

`com.seeyon.udc.common.autocode.util.MapUtils`

```java
    static com.seeyon.udc.common.autocode.util.MapUtils newHashMap();
    static com.seeyon.udc.common.autocode.util.MapUtils newHashMapWithExpectedSize(int);
    <K, V> com.seeyon.udc.common.autocode.util.MapUtils put(K, V);
    static int capacity(int);
    java.util.Map getMap();
```

### `TransportUtils`（5 方法）

`com.seeyon.udc.common.transport.TransportUtils`

```java
    static java.lang.String wrapStorageKey(java.lang.String, java.lang.String);
    static java.lang.String getStorageKey(java.lang.String);
    static java.lang.String getFileName(java.lang.String);
    static java.lang.String wrapFileName(java.lang.String, java.lang.String);
    static java.lang.String getFileNameWithoutFileId(java.lang.String, java.lang.String);
```

### `ChangeUtils`（5 方法）

`com.seeyon.udc.common.utils.ChangeUtils`

```java
    static liquibase.change.core.CreateTableChange getBaseCreateTableChange(java.lang.String, java.lang.String, java.lang.String, java.lang.String);
    static liquibase.change.ColumnConfig getNotNullColumn(java.lang.String, java.lang.String, java.lang.String);
    static liquibase.change.ColumnConfig getNullableColumn(java.lang.String, java.lang.String, java.lang.String);
    static java.lang.String getRemark(com.seeyon.udc.common.dto.AttributeDto, com.seeyon.udc.common.datatype.UdcDataType);
    static boolean isRelationDataType(com.seeyon.udc.common.datatype.UdcDataType);
```

### `ZipFileUtils`（5 方法）

`com.seeyon.udc.common.utils.ZipFileUtils`

```java
    static java.io.File toZipFile(java.io.File, java.io.File, java.util.List<java.lang.String>);
    static java.util.List<java.lang.String> listFileNames(java.io.File, java.lang.String);
    static java.io.File unzip(java.io.InputStream, java.io.File, java.nio.charset.Charset)
```

### `AggregationRootConfig`（4 方法）

`com.seeyon.udc.common.application.feature.config.AggregationRootConfig`

```java
    int getLimit();
    boolean isOnlyRoot();
    void setLimit(int);
    void setOnlyRoot(boolean);
```

### `DependsConfig`（4 方法）

`com.seeyon.udc.common.application.feature.config.DependsConfig`

```java
    java.util.List<com.seeyon.udc.common.dto.DependentApplicationDto> getDependService();
    java.util.List<java.lang.String> getDependFrontComp();
    void setDependService(java.util.List<com.seeyon.udc.common.dto.DependentApplicationDto>);
    void setDependFrontComp(java.util.List<java.lang.String>);
```

### `EntityConfig`（4 方法）

`com.seeyon.udc.common.application.feature.config.EntityConfig`

```java
    com.seeyon.udc.common.application.feature.config.StereoTypeConfig getStereotype();
    com.seeyon.udc.common.application.feature.config.AggregationRootConfig getAggregationRoot();
    void setStereotype(com.seeyon.udc.common.application.feature.config.StereoTypeConfig);
    void setAggregationRoot(com.seeyon.udc.common.application.feature.config.AggregationRootConfig);
```

### `StereoTypeConfig`（4 方法）

`com.seeyon.udc.common.application.feature.config.StereoTypeConfig`

```java
    java.util.List<com.seeyon.udc.common.application.feature.config.StereoType> getStereotypes();
    java.lang.String getDefaultStereotype();
    void setStereotypes(java.util.List<com.seeyon.udc.common.application.feature.config.StereoType>);
    void setDefaultStereotype(java.lang.String);
```

### `DownloadTransportHandlerAdapter`（4 方法）

`com.seeyon.udc.common.autocode.transport.DownloadTransportHandlerAdapter`

```java
    protected com.seeyon.udc.common.autocode.config.AutoCodeProperties getAutoCodeProperties();
    protected boolean isFatPackage();
    final boolean matches(com.seeyon.udc.common.autocode.context.CodeContext, org.springframework.context.ApplicationContext);
    boolean matches(java.lang.Object, org.springframework.context.ApplicationContext);
```

### `PathUtils`（4 方法）

`com.seeyon.udc.common.autocode.util.PathUtils`

```java
    static java.lang.String combine(java.lang.String, java.lang.String...);
    static java.lang.String getProjectPath(java.lang.String, com.seeyon.udc.common.dto.ApplicationDto);
    static java.lang.String getFrontMetadataPath(java.lang.String, com.seeyon.udc.common.dto.ApplicationDto);
    static java.lang.String getAppNameByDeployTypeEnum(com.seeyon.udc.common.dto.ApplicationDto);
```

### `AppMetaDataUtils`（4 方法）

`com.seeyon.udc.common.metadata.AppMetaDataUtils`

```java
    static void withDefaultMetaData(com.seeyon.udc.common.metadata.AppMetaDatableContext);
    static void wrapContext(com.seeyon.udc.common.autocode.context.CodeContext);
    static com.seeyon.udc.common.metadata.AppContext getRefreshedAppContext(com.seeyon.udc.common.dto.ApplicationDto);
    static com.seeyon.udc.common.metadata.AppContext getRefreshedAppContext(com.seeyon.udc.common.dto.ApplicationDto, com.seeyon.udc.common.listener.AppContextListener);
```

### `EntityDaoContainer`（4 方法）

`com.seeyon.udc.common.schema.EntityDaoContainer`

```java
    void setApplicationContext(org.springframework.context.ApplicationContext)
    com.seeyon.boot.starter.mybatis.BaseMybatisDao findDao(java.lang.String);
    java.lang.Class getClass(java.lang.String);
    private com.seeyon.boot.starter.mybatis.BaseMybatisDao findDao(java.lang.Class);
```

### `AbstractUpgradeTransportHandler`（4 方法）

`com.seeyon.udc.common.transport.upgrade.AbstractUpgradeTransportHandler`

```java
    boolean matches(com.seeyon.udc.common.autocode.context.CodeContext, org.springframework.context.ApplicationContext);
    java.util.List<com.seeyon.udc.common.transport.SchemaInfo> out(com.seeyon.udc.common.autocode.context.CodeContext)
    protected abstract com.seeyon.udc.common.transport.upgrade.UpgradeAttachment prepareAttachment(com.seeyon.udc.common.metadata.AppMetaDatableContext);
    boolean matches(java.lang.Object, org.springframework.context.ApplicationContext);
```

### `TemplateBuilder`（3 方法）

`com.seeyon.udc.common.autocode.TemplateBuilder`

```java
    static com.seeyon.udc.common.autocode.TemplateBuilder getInstance(com.seeyon.udc.common.autocode.context.CodeContext);
    com.seeyon.udc.common.autocode.TemplateBuilder$Template newTemplate();
```

## 三、注解（11）

| 注解 | 元素 |
|---|---|
| `AuthModel` | name |
| `AuthOperation` | operationType |
| `AppOpsAuth` | type, appId |
| `ComparedSchema` | value |
| `Importer` | source, model |
| `ImportUpgradeHandler` |  |
| `UpgradeMethod` | sourceVersion, targetVersion, group |
| `ConsistencyDetection` | service |
| `LogDefault` | domainService, domainCaptionField, domainAppIdField, getDomainObjByIdsMethod, update |
| `LogDefaultUpdate` | attributeName, attributeField, valueType |
| `OperationLog` | operationType, module, subModule, requestDto, recordServiceClass, defaultImpl |

## 四、枚举（26）

- `AuthOperationType`（5 常量）：CREATE, DELETE, UPDATE, SELECT, UNKNOWN
- `AuthorizationEnum`（10 常量）：APP_TEST, APP_CHECK, APP_SAVE_AS, APP_DEPLOY, APP_DELETE, UPDATE, ADD_MEMBER, HAND_OVER, DELETE_MEMBER, DETAIL
- `RoleEnum`（2 常量）：APP_DESIGNER, COLLABORATION_DESIGNER
- `ContextTypeEnum`（7 常量）：COPY, FORM_SAVE_AS, NORMAL_SAVE_AS, DEPLOY, DOWNLOAD, DETECTION, FRONT_DEPLOY_DETECTION
- `DependencyTypeEnum`（13 常量）：ENTITY, ENTITY_RULE, PAGE, PAGE_RULE, MICRO_FLOW, UDC_ENUM, CTP_ENUM, SERIAL, BPM_TEMPLATE, COMMON_APP, DEPENDENT_APP, LAYOUT_APP …
- `DtoSourceEnum`（8 常量）：ENTITY_BUSINESS_EVENT, MICRO_FLOW, ENTITY, CONNECTOR, MICRO_FLOW_EVENT, MICRO_FLOW_MESSAGE, PAGE_VARIABLE, DYNAMIC_DEPENDENCY
- `DtoSourceTypeEnum`（2 常量）：PART, ALL
- `EventActionTypeEnum`（4 常量）：CREATE, UPDATE, DELETE, SELECT
- `EventSourceEnum`（3 常量）：ENTITY, MICRO_FLOW, MICRO_FLOW_EVENT
- `EventTriggerTypeEnum`（4 常量）：BEFORE, AFTER, TRANSACTION_SUCCESS, TRANSACTION_EXCEPTION
- `EventTypeEnum`（2 常量）：ENTITY_EVENT, BUSINESS_EVENT
- `LastVersionMetaDataRelationType`（7 常量）：ENTITY, APP, PAGE, EVENT, PORTLET, ATTRIBUTE_SET, MICRO_FLOW
- `LastVersionMetadataModuleEnum`（13 常量）：DEFAULT, ENTITY, ATTRIBUTE, INDEX, CTP_ENUM, CTP_ENUM_ITEM, PAGE_INFO, PAGE_SCHEMA, ENTITY_EVENT_DATA, PORTLET, ATTR_SET_ATTRIBUTE, MICRO_FLOW …
- `MessageTypeEnum`（2 常量）：DEFAULT, DELAY
- `MetaDataTypeEnum`（18 常量）：APP, ENTITY, ATTRIBUTE, PAGE, MICROFLOW, DATAFLOW, DEP_APP, JAVA_ENUM, REFER, DTO, CTP_ENUM, FILTER_PLAN …
- `ObjectTypeEnum`（2 常量）：OBJECT, LIST
- `WriteBackTimeEnum`（3 常量）：TARGET_INSERT, TARGET_UPDATE, TARGET_DELETE
- `TransportTypeEnum`（8 常量）：COPY, FORM_SAVE_AS, NORMAL_SAVE_AS, TRANSPORT, TRANSPORT2NEW, TRANSPORT_INFO, FORM_TRANSPORT2NEW, FORM_TRANSPORT2NEW_VALIDATE
- `ConsistenceDetectionCodeEnum`（512 常量）：UDC_CE_ENTITY_ASSOCIATION_NOT_EXIST, UDC_CE_ENTITY_SUPERIOR_NOT_EXIST, UDC_CE_ENTITY_INDEX_ATTR_NOT_EXIST, UDC_CE_ENTITY_INDEX_ATTR_MISMATCH, UDC_CE_ENTITY_ATTR_RELATION_ENTITY_NOT_EXIST, UDC_CE_ENTITY_ATTR_RELATION_CTP_ENUM_NOT_EXIST, UDC_CE_ENTITY_ATTR_RELATION_CUSTOM_DATATYPE_NOT_EXIST, UDC_CE_ENTITY_ATTR_CAL_ATTR_NOT_EXIST, UDC_CE_ENTITY_ATTR_CAL_ATTR_MIS_MATCH, UDC_CE_ENTITY_REFER_ATTR_NOT_EXIST, UDC_CE_ENTITY_REFER_PAGE_NOT_EXIST, UDC_CE_ENTITY_REFER_TREE_ENTITY_ILLEGAL …
- `DetectionStatusEnum`（3 常量）：EXECUTING, FAIL, SUCCESS
- `ElementType`（29 常量）：APPLICATION, ENTITY, PAGEINFO, MICROFLOW, FRONTFLOW, DATAFLOW, DEDUCTION, ATTRIBUTE, DTO, DTOATTRIBUTE, EVENT, INDEX …
- `LogOperationType`（4 常量）：CREATE, DELETE, UPDATE, RECOVER
- `ModuleEnum`（18 常量）：ALL, MICRO_FLOW, MENU, SUBPAGE, PORTLET, LAYOUT, ENTITY, APPLICATION, UDC_ENUM, ATTRIBUTE_SET, DATAFLOW, DEDUCTION …
- `RecordValueTypeEnum`（3 常量）：STRING, JSON, EXPRESSION
- `SubModuleEnum`（56 常量）：ALL, DATAFLOW, DEDUCTION, FUNCTION_NODE, WIDGET, PORTLET, PORTLET_GROUP, PAGE, LAYOUT, ENTITY_GROUP, ENTITY_BASE, ENTITY_ATTR …
- `FunctionTagEnum`（26 常量）：NORMAL, ROOT, BIZ_HOME, ENUM_MANAGE, PARAM_MANAGE, DEDUCT, EXTENSION_PLAN, SERIAL_NUMBER, BILL_CATEGORY, ARCHIVE_CATEGORY, DATA_FLOW, BIZ_RULE …
