# boot-starter-datamigration：接口与方法签名

> 自动生成，勿手改。`tools/core/platform/emit_package_surfaces.py` 重跑即可。
> 构件 `com.seeyon:boot-starter-datamigration`（jar `boot-starter-datamigration-5.3.600.jar`）
> 规模：247 类 / 28 接口 / 0 注解 / 18 枚举 / 60 个关键类 / 2250 方法。
> 签名逐字来自 javap 原文；已去掉 `public` 前缀与 `throws` 子句。

## 一、接口（28）

### `StorageServiceInterface`（11 方法）

`com.seeyon.boot.starter.datamigration2.storage.StorageServiceInterface`

```java
    java.lang.String uploadZip(java.io.File, java.lang.String);
    java.lang.String uploadJson(java.lang.String, java.lang.String);
    java.lang.String downloadUrl(java.lang.String);
    java.lang.String downloadFromOss(java.lang.String);
    java.lang.String downloadJson(java.lang.String);
    java.lang.String commonStorageToFerryboat(java.lang.String, java.lang.String);
    java.lang.String getFileNameFromOss(java.lang.String);
    java.lang.String ferryboatToCommonStorage(java.lang.String, java.lang.String, java.lang.String, java.lang.Boolean);
    boolean existForFile(java.lang.String);
    boolean existForPublicFile(java.lang.String);
    boolean enableFerryboat();
```

### `EntityDataHandler`（10 方法） extends DataUpdateStrategy, Ordered

`com.seeyon.boot.starter.configmigration.api.EntityDataHandler`

```java
    default int getOrder();
    boolean supports(java.lang.Class<?>);
    default java.util.List<com.seeyon.boot.starter.configmigration.core.context.RelationMetaInfo> getRelationMetaInfo(com.seeyon.boot.starter.configmigration.core.context.ExecutionContext, com.seeyon.boot.starter.configmigration.enums.RelationType);
    <T extends com.seeyon.boot.domain.entity.BaseEntity> void processQueryData(com.seeyon.boot.starter.configmigration.core.context.ExecutionContext, T);
    default void processCoverAggData(com.seeyon.boot.starter.configmigration.api.DataBackupHandler, com.seeyon.boot.starter.configmigration.core.context.DiffContext);
    default <T extends com.seeyon.boot.domain.entity.BaseEntity> void processBeforeReplaceData(com.seeyon.boot.starter.configmigration.core.context.ExecutionContext, T);
    <T extends com.seeyon.boot.domain.entity.BaseEntity> void processReplaceData(com.seeyon.boot.starter.configmigration.core.context.ExecutionContext, T);
    default <T extends com.seeyon.boot.domain.entity.BaseEntity> void processAfterReplaceData(com.seeyon.boot.starter.configmigration.core.context.ExecutionContext, T);
    default <T extends com.seeyon.boot.domain.entity.BaseEntity> void processCallBack(com.seeyon.boot.starter.configmigration.core.context.CallBackContext);
```

### `ExecuteTemplate`（7 方法）

`com.seeyon.boot.starter.configmigration.executor.ExecuteTemplate`

```java
    com.seeyon.boot.starter.configmigration.core.result.QueryResult executeQuery(com.seeyon.boot.starter.configmigration.dto.TaskInfoDto);
    boolean executeUpload(java.lang.Long, java.lang.String);
    boolean executeDownload(java.lang.Long, java.lang.String);
    com.seeyon.boot.starter.configmigration.core.result.ValidationResult executeValidate(java.lang.Long);
    com.seeyon.boot.starter.configmigration.core.result.ReceiveResult executeUpdate(java.lang.Long);
    com.seeyon.boot.starter.configmigration.core.result.RollBackResult executeRollBack(java.lang.Long);
    void executeCallBack(java.lang.Long);
```

### `WritableField`（6 方法）

`com.seeyon.boot.starter.configmigration.core.transform.WritableField`

```java
    F getValue(T);
    void setValue(T, F);
    default void applyTransforms(java.util.Collection<? extends T>, java.util.function.Function<? super F, ? extends F>);
    default void applyTransform(T, java.util.function.Function<? super F, ? extends F>);
    default <R> com.seeyon.boot.starter.configmigration.core.transform.WritableField<T, R> map(java.util.function.Function<? super F, ? extends R>, java.util.function.BiFunction<? super F, ? super R, ? extends F>);
```

### `DependencyValidator`（5 方法）

`com.seeyon.boot.starter.configmigration.api.DependencyValidator`

```java
    boolean supports(java.lang.Class<?>);
    com.seeyon.boot.starter.configmigration.enums.RelationType getSupportedType();
    default java.util.List<com.seeyon.boot.starter.configmigration.core.context.RelationMetaInfo> getRelationMetaInfo(com.seeyon.boot.starter.configmigration.core.context.ExecutionContext);
    void doValidate(com.seeyon.boot.starter.configmigration.core.context.ExecutionContext, com.seeyon.boot.starter.configmigration.core.result.DataValidationResult);
```

### `TaskExecutor`（5 方法）

`com.seeyon.boot.starter.configmigration.executor.TaskExecutor`

```java
    org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor getExecutor();
    com.seeyon.boot.starter.configmigration.listener.TaskListener getTaskListener();
    com.seeyon.boot.starter.configmigration.executor.TaskManager getTaskManager();
    void execute(T);
    default void cancel(java.lang.Long);
```

### `TaskManager`（5 方法）

`com.seeyon.boot.starter.configmigration.executor.TaskManager`

```java
    boolean addFutureTask(java.lang.Long, java.util.concurrent.CompletableFuture<?>);
    boolean cancelFutureTask(java.lang.Long);
    boolean removeFutureTask(java.lang.Long, java.util.concurrent.CompletableFuture<?>);
    int countFutureTask(java.lang.Long);
    java.util.List<java.lang.Long> getAllTasks();
```

### `TaskListener`（5 方法）

`com.seeyon.boot.starter.configmigration.listener.TaskListener`

```java
    void onStart(com.seeyon.boot.starter.configmigration.dto.TaskInfoDto);
    void beforeExecute(com.seeyon.boot.starter.configmigration.dto.TaskInfoDto);
    void afterExecute(com.seeyon.boot.starter.configmigration.dto.TaskInfoDto);
    void onComplete(com.seeyon.boot.starter.configmigration.dto.TaskInfoDto);
    void onError(com.seeyon.boot.starter.configmigration.dto.TaskInfoDto, java.lang.Exception);
```

### `StorageMigrationService`（5 方法）

`com.seeyon.boot.starter.datamigration.domain.service.StorageMigrationService`

```java
    java.lang.String uploadForFerryboat(java.lang.String, java.lang.String);
    java.lang.String ossUpload(java.io.File);
    java.util.Map<java.lang.String, java.lang.Object> downloadFromFerryboat(java.lang.String);
    void downloadFromOss(java.lang.String, java.lang.String, java.lang.String);
    boolean existForFerryboat(java.lang.String);
```

### `EntityDslHandler`（4 方法）

`com.seeyon.boot.starter.configmigration.api.EntityDslHandler`

```java
    boolean supports(java.lang.Class<?>);
    default int getPageSize();
    com.seeyon.boot.transport.PageData<? extends com.seeyon.boot.domain.entity.BaseEntity> fetchData(com.seeyon.boot.starter.configmigration.core.context.condition.FetchCondition);
    void handleDsl(com.seeyon.boot.starter.configmigration.dto.EntityDslDto);
```

### `FieldResolver`（4 方法）

`com.seeyon.boot.starter.configmigration.core.resolver.FieldResolver`

```java
    R resolve(T);
    default java.util.List<R> batchResolve(java.util.Collection<? extends T>);
    default <V> com.seeyon.boot.starter.configmigration.core.resolver.FieldResolver<T, V> andThen(com.seeyon.boot.starter.configmigration.core.resolver.FieldResolver<? super R, ? extends V>);
```

### `CodeReplacer`（3 方法）

`com.seeyon.boot.starter.configmigration.api.CodeReplacer`

```java
    com.seeyon.boot.starter.configmigration.enums.RelationType getRelationType();
    void processRelationCodeById(java.util.List<com.seeyon.boot.starter.configmigration.domain.entity.FieldRelationData>);
    void processRelationIdByCode(java.util.List<com.seeyon.boot.starter.configmigration.domain.entity.FieldRelationData>);
```

### `DataComparator`（3 方法） extends Ordered

`com.seeyon.boot.starter.configmigration.api.DataComparator`

```java
    default int getOrder();
    boolean supports(java.lang.Class<?>);
    void compare(com.seeyon.boot.starter.configmigration.core.context.ExecutionContext, com.seeyon.boot.starter.configmigration.core.result.DataValidationResult);
```

### `Lifecycle`（3 方法）

`com.seeyon.boot.starter.configmigration.core.context.Lifecycle`

```java
    void start();
    void stop();
    boolean isRunning();
```

### `MgnInAdapter`（3 方法）

`com.seeyon.boot.starter.datamigration2.customer.MgnInAdapter`

```java
    java.util.List<?> before(com.seeyon.boot.starter.datamigration2.customer.MgnInParam);
    java.util.LinkedList<java.lang.String> sort(com.seeyon.boot.starter.datamigration2.customer.MgnSortParam);
    void after(com.seeyon.boot.starter.datamigration2.customer.MgnInAfterParam);
```

### `DataBackupHandler`（2 方法）

`com.seeyon.boot.starter.configmigration.api.DataBackupHandler`

```java
    default <T extends com.seeyon.boot.domain.entity.BaseEntity> void backupData(java.lang.Long, java.util.List<T>);
    default <T extends com.seeyon.boot.domain.entity.BaseEntity> void rollBackData(java.util.List<com.seeyon.boot.starter.configmigration.core.context.ExecutionContext>);
```

### `DataConsistencyValidator`（2 方法）

`com.seeyon.boot.starter.configmigration.api.DataConsistencyValidator`

```java
    java.util.List<java.lang.Class> supports();
    java.util.List<com.seeyon.boot.starter.configmigration.core.result.DataValidationResult> doValidate(com.seeyon.boot.starter.configmigration.core.context.DataConsistencyContext);
```

### `ConfigServiceInterface`（2 方法）

`com.seeyon.boot.starter.configmigration.view.ConfigServiceInterface`

```java
    java.util.List<com.seeyon.boot.starter.configmigration.view.dto.ConfigItemDto> selectConfigItemList(com.seeyon.boot.starter.configmigration.view.dto.ConfigItemSearchDto);
    com.seeyon.boot.transport.PageData<com.seeyon.boot.starter.configmigration.view.dto.ConfigItemDto> selectPageConfigItemList(com.seeyon.boot.starter.configmigration.view.dto.ConfigItemSearchDto);
```

### `DataUpdateStrategy`（1 方法）

`com.seeyon.boot.starter.configmigration.core.strategy.DataUpdateStrategy`

```java
    default java.util.Set<java.lang.String> getUpdateIgnoreFields(java.lang.Class<?>);
```

### `EntityConfigDataDao`（1 方法） extends EntityConfigData>

`com.seeyon.boot.starter.configmigration.domain.dao.EntityConfigDataDao`

```java
    java.util.List<java.lang.String> selectModuleCodeByPackageId(java.lang.Long);
```

### `FieldRelationDataDao`（1 方法） extends FieldRelationData>

`com.seeyon.boot.starter.configmigration.domain.dao.FieldRelationDataDao`

```java
    java.util.List<com.seeyon.boot.starter.configmigration.enums.RelationType> selectRelationTypeByPackageId(java.lang.Long);
```

### `MgnExportBatchInterface`（1 方法）

`com.seeyon.boot.starter.datamigration2.customer.MgnExportBatchInterface`

```java
    com.seeyon.boot.starter.datamigration2.customer.MgnExportResult dynamicExport(com.seeyon.boot.starter.datamigration2.customer.MgnExportBatchParam);
```

### `MgnExportInterface`（1 方法）

`com.seeyon.boot.starter.datamigration2.customer.MgnExportInterface`

```java
    java.util.List<com.seeyon.boot.starter.datamigration2.customer.MgnExportResult> dynamicExport(java.util.List<com.seeyon.boot.starter.datamigration2.customer.MgnExportParam>);
```

### `MgnUniqueAdapter`（1 方法）

`com.seeyon.boot.starter.datamigration2.customer.MgnUniqueAdapter`

```java
    void before(com.seeyon.boot.starter.datamigration2.customer.MgnUniqueParam);
```

### `Constants`（0 方法）

`com.seeyon.boot.starter.configmigration.constant.Constants`

```java
```

### `CtpDataMigrationNotifyDao`（0 方法） extends CtpDataMigrationNotify>

`com.seeyon.boot.starter.datamigration.domain.dao.CtpDataMigrationNotifyDao`

```java
```

### `CtpDataMigrationTaskDetailDao`（0 方法） extends CtpDataMigrationTaskDetail>

`com.seeyon.boot.starter.datamigration.domain.dao.CtpDataMigrationTaskDetailDao`

```java
```

### `CtpDataMigrationTaskInfoDao`（0 方法） extends CtpDataMigrationTaskInfo>

`com.seeyon.boot.starter.datamigration.domain.dao.CtpDataMigrationTaskInfoDao`

```java
```

## 二、关键类（60）

### `BizMgnStorageService`（59 方法）

`com.seeyon.boot.starter.datamigration2.storage.biz.BizMgnStorageService`

```java
    boolean enableFerryboat();
    boolean existForFile(java.lang.String);
    boolean existForPublicFile(java.lang.String);
    void appVersionUpload(com.seeyon.boot.starter.datamigration2.dto.AppVersionDataDto, java.lang.String, java.lang.String);
    java.lang.String appVersionGet(java.lang.String, java.lang.String);
    void uploadEnv(java.lang.String);
    java.util.List<java.lang.String> envListGet();
    void appChNameUpdate(java.util.Map<java.lang.String, java.lang.String>, java.lang.String);
    java.util.Map<java.lang.String, java.lang.String> appChNameGet(java.util.List<java.lang.String>, java.lang.String);
    java.util.List<com.seeyon.boot.starter.datamigration2.dto.MgnInfoDto> mgnInfoListGet(java.lang.String);
    void mgnInfoCreate(java.lang.String, com.seeyon.boot.starter.datamigration2.dto.MgnInfoDto);
    void mgnInfoListDel(java.lang.String, java.lang.String);
    void mgnInfoUpdate(java.lang.String, java.lang.String, java.lang.String, com.seeyon.boot.starter.datamigration2.enums.MgnInfoStatus);
    java.util.List<com.seeyon.boot.starter.datamigration2.dto.MgnTaskDto> mgnTaskListGet(java.lang.String);
    void mgnTaskListDel(java.lang.String, java.lang.String);
    com.seeyon.boot.starter.datamigration2.enums.MgnTaskStatus mgnTaskListStatusGet(java.lang.String, java.lang.String, java.lang.String);
    void mgnTaskListStatusUpdate(java.lang.String, java.lang.String, java.lang.String, com.seeyon.boot.starter.datamigration2.enums.MgnTaskStatus);
    java.lang.String mainTaskDataFileName(java.lang.String, java.lang.String);
    java.lang.String mainTaskDataEndFileName(java.lang.String);
    void mainTaskDataUpload(com.seeyon.boot.starter.datamigration2.dto.MgnOutTaskInfoDto, java.lang.String, java.lang.String);
    com.seeyon.boot.starter.datamigration2.dto.MgnOutTaskInfoDto mainTaskDataGet(java.lang.String, java.lang.String);
    java.lang.String inMainTaskFileName(java.lang.String, java.lang.String);
    void inMainTaskUpload(com.seeyon.boot.starter.datamigration2.dto.MgnInTaskInfoDto, java.lang.String, java.lang.String);
    com.seeyon.boot.starter.datamigration2.dto.MgnInTaskInfoDto inMainTaskGet(java.lang.String, java.lang.String);
    void rejectTaskUpload(java.lang.String, java.lang.String);
    java.lang.String rejectTaskGet(java.lang.String, java.lang.String);
    java.lang.String entityOutInfoFileName(java.lang.String, java.lang.String, java.lang.String);
    void entityOutInfoUpdate(com.seeyon.boot.starter.datamigration2.dto.MgnOutEntityInfoDto, java.lang.String);
    com.seeyon.boot.starter.datamigration2.dto.MgnOutEntityInfoDto entityOutInfoGet(java.lang.String, java.lang.String, java.lang.String);
    java.lang.String entityOutDataFileName(java.lang.String, java.lang.String, java.lang.String, java.lang.Integer, java.lang.Long);
    void entityOutDataUpload(java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.Integer, java.lang.Long);
    java.lang.String entityOutDataGet(java.lang.String);
    java.lang.String entityOssFieldFileName(java.lang.String, java.lang.String, java.lang.String, java.lang.Integer, java.lang.Long);
    void entityOssFieldUpload(java.util.List<com.seeyon.boot.starter.datamigration2.dto.StorageFieldDataDto>, java.lang.String, java.lang.String, java.lang.String, java.lang.Integer, java.lang.Long);
    java.util.List<com.seeyon.boot.starter.datamigration2.dto.StorageFieldDataDto> entityOssFieldGet(java.lang.String);
    java.lang.String inEntityInfoFileName(java.lang.String, java.lang.String, java.lang.String);
    void inEntityInfoUpdate(com.seeyon.boot.starter.datamigration2.dto.MgnInEntityInfoDto, java.lang.String);
    com.seeyon.boot.starter.datamigration2.dto.MgnInEntityInfoDto inEntityInfoGet(java.lang.String, java.lang.String, java.lang.String);
    java.lang.String inEntityResultFileName(java.lang.String, java.lang.String, java.lang.String, java.lang.Integer);
    void inEntityResultUpload(java.util.List<com.seeyon.boot.starter.datamigration2.dto.MgnInEntityDetailDto>, java.lang.String, java.lang.String, java.lang.String, java.lang.Integer);
    java.util.List<com.seeyon.boot.starter.datamigration2.dto.MgnInEntityDetailDto> inEntityResultGet(java.lang.String);
    java.lang.String allZipFileName(java.lang.String, java.lang.String);
    java.lang.String allZipUpload(java.io.File, java.lang.String, java.lang.String);
    java.lang.String allZipTaskName(java.lang.String, java.lang.String);
    void allZipTaskUpload(com.seeyon.boot.starter.datamigration2.dto.MgnZipDownloadInfoDto, java.lang.String, java.lang.String);
    com.seeyon.boot.starter.datamigration2.dto.MgnZipDownloadInfoDto allZipTaskGet(java.lang.String, java.lang.String);
    java.lang.String downloadFromOss(java.lang.String);
    java.lang.String uploadZipTaskFileName(java.lang.String, java.lang.String);
    com.seeyon.boot.starter.datamigration2.dto.MgnZipUploadInfoDto uploadZipTaskGet(java.lang.String, java.lang.String);
    void uploadZipTaskUpload(com.seeyon.boot.starter.datamigration2.dto.MgnZipUploadInfoDto, java.lang.String, java.lang.String);
    void uploadJson(java.lang.String, java.lang.String);
    java.lang.String downloadUrl(java.lang.String);
    java.lang.String ferryboatToCommonStorage(java.lang.String, java.lang.String, java.lang.String, java.lang.Boolean);
    java.lang.String getFileNameFromOss(java.lang.String);
    java.lang.String commonStorageToFerryboat(java.lang.String, java.lang.String);
    com.seeyon.boot.starter.datamigration2.dto.MgnTenantTaskInfoDto getTenantTaskInfo(java.lang.String);
    void uploadTenantTaskInfo(com.seeyon.boot.starter.datamigration2.dto.MgnTenantTaskInfoDto, java.lang.String);
    com.seeyon.boot.starter.datamigration2.dto.MgnTenantTaskDto getTenantTask(java.lang.String, java.lang.String);
    void uploadTenantTask(com.seeyon.boot.starter.datamigration2.dto.MgnTenantTaskDto, java.lang.String, java.lang.String);
```

### `DefaultExecuteTemplate`（55 方法）

`com.seeyon.boot.starter.configmigration.executor.DefaultExecuteTemplate`

```java
    void handleRelationField(java.util.List<com.seeyon.boot.starter.configmigration.core.context.ExecutionContext>);
    private java.util.List<com.seeyon.boot.starter.configmigration.core.context.ExecutionContext> buildContext(java.util.List<? extends com.seeyon.boot.domain.entity.BaseEntity>);
    private java.util.List<com.seeyon.boot.starter.configmigration.core.context.ExecutionContext> buildQueryContext(com.seeyon.boot.starter.configmigration.dto.TaskInfoDto, com.seeyon.boot.starter.configmigration.dto.EntityDslDto, java.util.List<? extends com.seeyon.boot.domain.entity.BaseEntity>, com.seeyon.boot.starter.configmigration.core.result.QueryResult);
    com.seeyon.boot.starter.configmigration.core.result.QueryResult executeQuery(com.seeyon.boot.starter.configmigration.dto.TaskInfoDto);
    boolean executeUpload(java.lang.Long, java.lang.String);
    boolean executeDownload(java.lang.Long, java.lang.String);
    private com.seeyon.boot.domain.dao.Wrapper buildQueryWrapper(com.seeyon.boot.starter.configmigration.core.context.DataMetaInfo, com.seeyon.boot.domain.entity.BaseEntity);
    static private static void buildQueryWrapperByUniqueField(com.seeyon.boot.domain.dao.Wrapper, com.seeyon.boot.starter.configmigration.core.context.DataMetaInfo, com.seeyon.boot.domain.entity.BaseEntity, java.util.Set<java.lang.String>);
    com.seeyon.boot.starter.configmigration.core.result.ValidationResult executeValidate(java.lang.Long);
    private void updateValidationResult(java.util.List<com.seeyon.boot.starter.configmigration.core.context.ExecutionContext>);
    com.seeyon.boot.starter.configmigration.core.result.ReceiveResult executeUpdate(java.lang.Long);
    com.seeyon.boot.starter.configmigration.core.result.RollBackResult executeRollBack(java.lang.Long);
    void executeCallBack(java.lang.Long);
    private void dispatchCallBack(java.util.List<com.seeyon.boot.starter.configmigration.domain.entity.EntityConfigData>);
    private void doExecuteQuery(com.seeyon.boot.starter.configmigration.dto.TaskInfoDto, com.seeyon.boot.starter.configmigration.core.result.QueryResult);
    private void writeBackData(java.lang.Long, java.lang.Long, java.util.List<com.seeyon.boot.starter.configmigration.core.context.ExecutionContext>);
    private void processInsertData(com.seeyon.boot.starter.configmigration.dto.TaskInfoDto, java.util.List<com.seeyon.boot.starter.configmigration.core.context.ExecutionContext>);
    java.util.List<com.seeyon.boot.starter.configmigration.core.context.RelationMetaInfo> extractRelationMetaInfo(com.seeyon.boot.starter.configmigration.dto.EntityDslDto, com.seeyon.boot.domain.entity.BaseEntity);
    private void doExecuteQuery(com.seeyon.boot.starter.configmigration.dto.TaskInfoDto, com.seeyon.boot.starter.configmigration.dto.EntityDslDto, com.seeyon.boot.starter.configmigration.core.context.condition.FetchCondition, com.seeyon.boot.starter.configmigration.core.result.QueryResult);
    private void handleRelationEntity(com.seeyon.boot.starter.configmigration.dto.TaskInfoDto, com.seeyon.boot.starter.configmigration.dto.EntityDslDto, java.util.List<? extends com.seeyon.boot.domain.entity.BaseEntity>, com.seeyon.boot.starter.configmigration.core.result.QueryResult);
    private void doRelationExecuteQuery(com.seeyon.boot.starter.configmigration.dto.TaskInfoDto, com.seeyon.boot.starter.configmigration.core.result.QueryResult, java.lang.String, java.lang.String, java.util.List<?>, boolean);
    private void handleOldData(com.seeyon.boot.starter.configmigration.core.context.ExecutionContext, com.seeyon.boot.starter.mybatis.BaseMybatisDao<? extends com.seeyon.boot.domain.entity.BaseEntity>);
    private <T> void processBatch(java.util.Map<java.lang.String, java.lang.Object>, com.seeyon.boot.starter.configmigration.executor.DefaultExecuteTemplate$PageProcessor<T>, com.seeyon.boot.starter.configmigration.executor.DefaultExecuteTemplate$BatchProcessor<T>);
    private <T> void processBatch(int, java.util.Map<java.lang.String, java.lang.Object>, com.seeyon.boot.starter.configmigration.executor.DefaultExecuteTemplate$PageProcessor<T>, com.seeyon.boot.starter.configmigration.executor.DefaultExecuteTemplate$BatchProcessor<T>);
```

### `EntityConfigData`（42 方法）

`com.seeyon.boot.starter.configmigration.domain.entity.EntityConfigData`

```java
    java.lang.String getUnique();
    java.lang.Long getPackageId();
    java.lang.String getAppName();
    java.lang.String getModuleCode();
    java.lang.Boolean getRootModule();
    java.lang.Long getDataId();
    java.lang.Integer getDataVersion();
    java.util.Date getDataUpdateTime();
    java.lang.Long getRootDataId();
    java.lang.String getTitleField();
    java.lang.String getTitle();
    java.lang.String getUniqueField();
    java.lang.String getCodeField();
    java.lang.String getCode();
    java.lang.Long getOrgId();
    java.lang.Long getCreator();
    java.lang.String getOldData();
    java.lang.String getNewData();
    com.seeyon.boot.starter.configmigration.enums.DiffType getDiffType();
    com.seeyon.boot.starter.configmigration.enums.ExecutionPolicy getPolicy();
    com.seeyon.boot.enums.ActionType getActionType();
    void setPackageId(java.lang.Long);
    void setAppName(java.lang.String);
    void setModuleCode(java.lang.String);
    void setRootModule(java.lang.Boolean);
    void setDataId(java.lang.Long);
    void setDataVersion(java.lang.Integer);
    void setDataUpdateTime(java.util.Date);
    void setRootDataId(java.lang.Long);
    void setTitleField(java.lang.String);
    void setTitle(java.lang.String);
    void setUniqueField(java.lang.String);
    void setUnique(java.lang.String);
    void setCodeField(java.lang.String);
    void setCode(java.lang.String);
    void setOrgId(java.lang.Long);
    void setCreator(java.lang.Long);
    void setOldData(java.lang.String);
    void setNewData(java.lang.String);
    void setDiffType(com.seeyon.boot.starter.configmigration.enums.DiffType);
    void setPolicy(com.seeyon.boot.starter.configmigration.enums.ExecutionPolicy);
    void setActionType(com.seeyon.boot.enums.ActionType);
```

### `MgnApiService`（35 方法）

`com.seeyon.boot.starter.datamigration2.service.MgnApiService`

```java
    java.lang.String getAppVersion(java.lang.String, java.lang.String);
    void appChNameUpdate(java.util.Map<java.lang.String, java.lang.String>);
    java.util.Map<java.lang.String, java.lang.String> getAppChName(java.util.List<java.lang.String>);
    java.util.List<com.seeyon.boot.starter.datamigration2.dto.MgnInfoDto> getMgnInfoList();
    void mgnInfoCreate(com.seeyon.boot.starter.datamigration2.dto.MgnInfoDto);
    void mgnInfoUpdate(java.lang.String, java.lang.String, com.seeyon.boot.starter.datamigration2.enums.MgnInfoStatus);
    java.util.List<com.seeyon.boot.starter.datamigration2.dto.MgnTaskDto> getInMgnJobList();
    java.lang.String createOutMgnJob(java.lang.String, java.util.List<com.seeyon.boot.starter.datamigration2.dto.MgnOutEntityInfoDto>);
    java.lang.String createOutMgnJob(java.lang.String, java.util.List<com.seeyon.boot.starter.datamigration2.dto.MgnOutEntityInfoDto>, java.util.Set<java.lang.Long>, java.lang.Long);
    java.lang.String createOutMgnJob(java.lang.String, java.lang.String, java.util.List<com.seeyon.boot.starter.datamigration2.dto.MgnOutEntityInfoDto>, java.util.Set<java.lang.Long>, java.lang.Long, java.lang.Long, java.lang.String);
    com.seeyon.boot.starter.datamigration2.dto.MgnOutTaskInfoDto getOutTaskInfo(java.lang.String, java.lang.String);
    com.seeyon.boot.starter.datamigration2.dto.MgnOutEntityInfoDto getOutEntityInfo(java.lang.String, java.lang.String, java.lang.String);
    java.util.List<java.lang.Object> getOutEntityData(java.lang.String, java.lang.String, java.lang.String);
    java.util.List<java.lang.Object> getOutEntityData(java.lang.String, java.lang.String, java.lang.String, int);
    java.util.List<java.lang.Object> getOutEntityData(java.lang.String, java.lang.String, java.lang.String, java.lang.Long, int);
    com.seeyon.boot.starter.datamigration2.dto.MgnOutTaskInfoDto getInMgn(java.lang.String, java.lang.String);
    java.lang.String createInMgnJob(java.lang.String, java.lang.String, com.seeyon.boot.starter.datamigration2.dto.MgnOutTaskInfoDto);
    com.seeyon.boot.starter.datamigration2.dto.MgnInTaskInfoDto getInTaskInfo(java.lang.String, java.lang.String);
    com.seeyon.boot.starter.datamigration2.dto.MgnInEntityInfoDto getInEntityInfo(java.lang.String, java.lang.String, java.lang.String);
    java.util.List<com.seeyon.boot.starter.datamigration2.dto.MgnInEntityDetailDto> getInEntityRes(java.lang.String, java.lang.String, java.lang.String);
    java.util.List<com.seeyon.boot.starter.datamigration2.dto.MgnInEntityDetailDto> getInEntityRes(java.lang.String, java.lang.String, java.lang.String, int);
    void rejectTaskUpload(java.lang.String, java.lang.String);
    java.lang.String rejectTaskGet(java.lang.String, java.lang.String);
    void rollbackAll(java.lang.String, java.lang.String);
    void deleteMgnJob(java.lang.String);
    com.seeyon.boot.starter.datamigration2.dto.MgnZipDownloadInfoDto downZip(java.lang.String, java.lang.String);
    com.seeyon.boot.starter.datamigration2.dto.MgnZipUploadInfoDto uploadZip(java.lang.String, java.lang.String, java.lang.String);
    private void writeJson(java.lang.String, java.lang.String)
    private java.util.Map<java.lang.String, java.util.List<com.seeyon.boot.starter.datamigration2.dto.MgnInEntityInfoDto>> convert(java.util.Map<java.lang.String, java.util.List<com.seeyon.boot.starter.datamigration2.dto.MgnOutEntityInfoDto>>);
    com.seeyon.boot.starter.datamigration2.enums.MgnTaskStatus readTaskListStatus(java.lang.String, java.lang.String, java.lang.String);
    void updateTaskList(java.lang.String, java.lang.String, java.lang.String, com.seeyon.boot.starter.datamigration2.enums.MgnTaskStatus);
```

### `TaskExecuteUtils`（34 方法）

`com.seeyon.boot.starter.configmigration.util.TaskExecuteUtils`

```java
    static java.lang.String changeTaskCancelTopic();
    static private static void init();
    static private static java.lang.String buildDataResultKey(com.seeyon.boot.starter.configmigration.enums.TaskType, com.seeyon.boot.starter.configmigration.enums.DiffType, java.lang.String);
    static private static java.lang.String buildRelationResultKey(com.seeyon.boot.starter.configmigration.enums.TaskType, java.lang.String);
    static private static java.lang.String buildResultKey(com.seeyon.boot.starter.configmigration.enums.TaskType, java.lang.String);
    static private static java.lang.String buildStatusKey(com.seeyon.boot.starter.configmigration.enums.TaskType, java.lang.String);
    static void initStatus(com.seeyon.boot.starter.configmigration.enums.TaskType, java.lang.String, java.util.Set<java.lang.String>);
    static boolean isTaskExecuting(com.seeyon.boot.starter.configmigration.enums.TaskType, java.lang.String, java.lang.String);
    static boolean isAnyTaskExecuting(com.seeyon.boot.starter.configmigration.enums.TaskType, java.lang.String);
    static boolean isAnyTaskFail(com.seeyon.boot.starter.configmigration.enums.TaskType, java.lang.String);
    static boolean isAllTaskSuccess(com.seeyon.boot.starter.configmigration.enums.TaskType, java.lang.String);
    static void markGlobalErrorLog(com.seeyon.boot.starter.configmigration.enums.TaskType, java.lang.String, java.lang.String, java.lang.String);
    static void markExecuteStatus(com.seeyon.boot.starter.configmigration.enums.TaskType, java.lang.String, java.lang.String, com.seeyon.boot.starter.configmigration.enums.TaskStatus, java.lang.String);
    static void clearDetectResult(java.lang.String);
    static void setDataDetectCount(java.lang.String, java.lang.String, java.util.Map<com.seeyon.boot.starter.configmigration.enums.DiffType, java.lang.Integer>);
    static void setDataValidationResult(java.lang.String, java.lang.String, java.util.List<com.seeyon.boot.starter.configmigration.core.result.DataDiffResult>);
    static void setRelationValidationResult(java.lang.String, java.lang.String, java.util.List<com.seeyon.boot.starter.configmigration.core.result.RelationValidationResult>);
    static void setReceiveResult(java.lang.String, java.lang.String, com.seeyon.boot.starter.configmigration.core.result.ReceiveResult);
    static com.seeyon.boot.starter.configmigration.dto.TaskStatusDto getExecuteStatus(com.seeyon.boot.starter.configmigration.enums.TaskType, java.lang.String);
    static com.seeyon.boot.starter.configmigration.core.result.ReceiveResult getReceiveResult(java.lang.String);
    static private static com.seeyon.boot.starter.configmigration.dto.TaskStatusDto mergeStatusList(java.util.List<com.seeyon.boot.starter.configmigration.dto.TaskStatusDto>);
    static java.util.Map<com.seeyon.boot.starter.configmigration.enums.DiffType, java.lang.Long> getDiffCount(java.lang.String);
    static java.util.List<com.seeyon.boot.starter.configmigration.core.result.DataDiffResult> getDataValidationResult(java.lang.String, com.seeyon.boot.starter.configmigration.enums.DiffType);
    static java.util.List<com.seeyon.boot.starter.configmigration.core.result.RelationValidationResult> getRelationValidationResult(java.lang.String);
```

### `EntityGraphService`（20 方法）

`com.seeyon.boot.starter.configmigration.service.EntityGraphService`

```java
    private java.lang.String getEntityCacheKey();
    private java.lang.String getFieldCacheKey();
    void deleteEntityCache();
    void deleteFieldCache();
    boolean existField();
    boolean existEntity();
    java.util.Map<java.lang.String, java.util.Set<java.lang.String>> buildEntityGraph();
    java.util.Map<java.lang.String, java.util.Set<java.lang.String>> buildEntityGraph(java.lang.String);
    void registerField(java.util.List<com.seeyon.boot.starter.configmigration.dto.FieldRelationDslDto>);
    void registerEntity(java.util.List<com.seeyon.boot.starter.configmigration.dto.EntityDslDto>);
    java.util.List<com.seeyon.boot.starter.configmigration.dto.FieldRelationDslDto> getFieldRelationDsl(java.lang.String);
    com.seeyon.boot.starter.configmigration.dto.EntityDslDto getEntityDsl(java.lang.String);
    java.util.List<com.seeyon.boot.starter.configmigration.dto.FieldRelationDslDto> getForwardRelations(java.lang.String);
    java.util.List<com.seeyon.boot.starter.configmigration.dto.FieldRelationDslDto> getReverseRelations(java.lang.String);
```

### `ConfigItemDto`（20 方法）

`com.seeyon.boot.starter.configmigration.view.dto.ConfigItemDto`

```java
    java.lang.Long getParentId();
    java.lang.Long getDataId();
    java.lang.String getModuleName();
    java.lang.String getDataTitle();
    java.lang.Long getOrgId();
    java.lang.String getOrgName();
    java.util.Map<java.lang.String, java.lang.Object> getShowData();
    java.util.List<com.seeyon.boot.starter.configmigration.view.dto.ConfigItemDto> getChildren();
    void setParentId(java.lang.Long);
    void setDataId(java.lang.Long);
    void setModuleName(java.lang.String);
    void setDataTitle(java.lang.String);
    void setOrgId(java.lang.Long);
    void setOrgName(java.lang.String);
    void setShowData(java.util.Map<java.lang.String, java.lang.Object>);
    void setChildren(java.util.List<com.seeyon.boot.starter.configmigration.view.dto.ConfigItemDto>);
    boolean equals(java.lang.Object);
    protected boolean canEqual(java.lang.Object);
    int hashCode();
    java.lang.String toString();
```

### `EntityConfigDataService`（19 方法）

`com.seeyon.boot.starter.configmigration.domain.service.EntityConfigDataService`

```java
    int insertEntityConfigData(java.util.List<com.seeyon.boot.starter.configmigration.core.context.ExecutionContext>);
    java.util.Set<java.lang.Long> checkDataIdsExist(java.lang.Long, java.util.List<java.lang.Long>);
    int insertBatch(java.util.List<com.seeyon.boot.starter.configmigration.domain.entity.EntityConfigData>);
    boolean existByPackageIdAndDataId(java.lang.Long, java.lang.Long);
    int updateOldEntity(com.seeyon.boot.starter.configmigration.domain.entity.EntityConfigData);
    int updateBatch(java.util.List<com.seeyon.boot.starter.configmigration.domain.entity.EntityConfigData>, java.util.Set<java.lang.String>);
    int deleteDataByPackageId(java.lang.Long);
    java.util.List<java.lang.String> selectModuleCodeByPackageId(java.lang.Long);
    com.seeyon.boot.transport.PageData<com.seeyon.boot.starter.configmigration.domain.entity.EntityConfigData> selectPageByCondition(java.util.Map<java.lang.String, java.lang.Object>, com.seeyon.boot.transport.PageInfo);
    com.seeyon.boot.transport.PageData<com.seeyon.boot.starter.configmigration.domain.entity.EntityConfigData> selectPageExcludeByConditions(java.util.Map<java.lang.String, java.lang.Object>, com.seeyon.boot.transport.PageInfo);
    java.util.List<com.seeyon.boot.starter.configmigration.domain.entity.EntityConfigData> selectListByCondition(java.util.Map<java.lang.String, java.lang.Object>);
    com.seeyon.boot.transport.PageData<com.seeyon.boot.starter.configmigration.domain.entity.EntityConfigData> selectPageByCondition(java.util.Map<java.lang.String, java.lang.Object>, com.seeyon.boot.transport.PageInfo, com.seeyon.boot.transport.Sort);
    java.util.List<com.seeyon.boot.starter.configmigration.domain.entity.EntityConfigData> selectAggData(java.lang.Long, java.lang.Long);
    com.seeyon.boot.transport.PageData<com.seeyon.boot.starter.configmigration.core.result.DataDiffResult> selectPageByDataRootId(com.seeyon.boot.transport.PageRequest);
```

### `FieldRelationDataService`（19 方法）

`com.seeyon.boot.starter.configmigration.domain.service.FieldRelationDataService`

```java
    int insertEntityRelationData(java.util.List<com.seeyon.boot.starter.configmigration.core.context.ExecutionContext>);
    int createBatch(java.util.List<com.seeyon.boot.starter.configmigration.dto.FieldRelationDataDto>);
    java.util.List<com.seeyon.boot.starter.configmigration.dto.FieldRelationDataDto> selectByPackageIdAndStatus(java.lang.Long, com.seeyon.boot.starter.configmigration.enums.DataStatus);
    int selectRelationDataCountByPackageId(java.lang.Long);
    java.util.List<com.seeyon.boot.starter.configmigration.enums.RelationType> selectRelationTypeByPackageId(java.lang.Long);
    com.seeyon.boot.transport.PageData<com.seeyon.boot.starter.configmigration.domain.entity.FieldRelationData> selectPageByCondition(java.util.Map<java.lang.String, java.lang.Object>, com.seeyon.boot.transport.PageInfo);
    com.seeyon.boot.transport.PageData<com.seeyon.boot.starter.configmigration.domain.entity.FieldRelationData> selectPageByCondition(java.util.Map<java.lang.String, java.lang.Object>, com.seeyon.boot.transport.PageInfo, com.seeyon.boot.transport.Sort);
    com.seeyon.boot.transport.PageData<com.seeyon.boot.starter.configmigration.domain.entity.FieldRelationData> selectListByWrapper(com.seeyon.boot.transport.PageInfo, com.seeyon.boot.domain.dao.Wrapper);
    java.util.List<com.seeyon.boot.starter.configmigration.domain.entity.FieldRelationData> selectPageByConditions(java.util.Map<java.lang.String, java.lang.Object>);
    void updateBatch(java.util.List<com.seeyon.boot.starter.configmigration.domain.entity.FieldRelationData>, java.util.Set<java.lang.String>);
    private int updateByColumns(com.seeyon.boot.starter.configmigration.dto.FieldRelationDataDto, java.util.Set<java.lang.String>);
    int insertBatch(java.util.List<com.seeyon.boot.starter.configmigration.domain.entity.FieldRelationData>);
    int deleteDataByPackageId(java.lang.Long);
```

### `ConfigItemSearchDto`（18 方法）

`com.seeyon.boot.starter.configmigration.view.dto.ConfigItemSearchDto`

```java
    java.lang.String getAppName();
    java.lang.String getHostAppName();
    java.lang.String getModuleCode();
    java.lang.Integer getSelectType();
    java.lang.String getTitleField();
    java.util.Set<java.lang.String> getFliedNames();
    java.util.List<com.seeyon.boot.starter.configmigration.view.dto.ShowFieldDto> getDisplayFields();
    void setAppName(java.lang.String);
    void setHostAppName(java.lang.String);
    void setModuleCode(java.lang.String);
    void setSelectType(java.lang.Integer);
    void setTitleField(java.lang.String);
    void setFliedNames(java.util.Set<java.lang.String>);
    void setDisplayFields(java.util.List<com.seeyon.boot.starter.configmigration.view.dto.ShowFieldDto>);
    boolean equals(java.lang.Object);
    protected boolean canEqual(java.lang.Object);
    int hashCode();
    java.lang.String toString();
```

### `AggDataMergeHandler`（16 方法）

`com.seeyon.boot.starter.configmigration.handler.AggDataMergeHandler`

```java
    void mergeValidationDiffData(java.lang.Long, com.seeyon.boot.starter.configmigration.core.result.ValidationResult);
    void processExecutionResults(java.lang.Long);
    private void writeBackData(java.lang.Long, java.util.List<com.seeyon.boot.starter.configmigration.dto.DataLogDto>);
    private void processCoverAggData(java.lang.Long, java.lang.String, java.util.Map<java.lang.String, java.util.Set<java.lang.String>>, java.util.List<com.seeyon.boot.starter.configmigration.domain.entity.EntityConfigData>);
```

### `DefaultEntityDataHandler`（15 方法）

`com.seeyon.boot.starter.configmigration.handler.DefaultEntityDataHandler`

```java
    int getOrder();
    boolean supports(java.lang.Class);
    <T extends com.seeyon.boot.domain.entity.BaseEntity> void processQueryData(com.seeyon.boot.starter.configmigration.core.context.ExecutionContext, T);
    void processCoverAggData(com.seeyon.boot.starter.configmigration.api.DataBackupHandler, com.seeyon.boot.starter.configmigration.core.context.DiffContext);
    <T extends com.seeyon.boot.domain.entity.BaseEntity> void processReplaceData(com.seeyon.boot.starter.configmigration.core.context.ExecutionContext, T);
```

### `ImportStorageService`（15 方法）

`com.seeyon.boot.starter.configmigration.service.ImportStorageService`

```java
    boolean importFromOss(java.lang.Long, java.lang.String);
    private com.seeyon.boot.starter.configmigration.dto.oss.AppManifestDto downloadAndParseManifest(java.lang.Long, java.lang.String);
    private void importConfigData(com.seeyon.boot.starter.configmigration.dto.oss.AppManifestDto);
    private void importRelationData(com.seeyon.boot.starter.configmigration.dto.oss.AppManifestDto);
```

### `MigrationAppService`（14 方法）

`com.seeyon.boot.starter.datamigration.appservice.MigrationAppService`

```java
    com.seeyon.boot.transport.SingleResponse<java.lang.String> exportEntityTask(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.datamigration.dto.MigrationExportEntityRequestDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.String> exportJsonTask(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.datamigration.dto.MigrationExportRequestDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.String> exportAllJsonTask(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.datamigration.dto.MigrationExportAllRequestDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.boot.starter.datamigration.dto.JsonExportTaskResponseDto> taskQuery(com.seeyon.boot.transport.SingleRequest<java.lang.String>);
    private void errToDb(java.lang.String, java.lang.String, java.lang.String, java.lang.String);
```

### `MigrationJsonAppService`（14 方法）

`com.seeyon.boot.starter.datamigration.appservice.MigrationJsonAppService`

```java
    com.seeyon.boot.transport.SingleResponse<java.lang.String> exportEntityFile(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.datamigration.dto.JsonExportEntityRequestDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.String> exportEntityFileTask(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.datamigration.dto.JsonExportEntityRequestDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.String> exportJsonFile(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.datamigration.dto.JsonExportRequestDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.String> exportJsonFileTask(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.datamigration.dto.JsonExportRequestDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.String> exportAllJsonFile(com.seeyon.boot.transport.SingleRequest<java.lang.Boolean>);
    com.seeyon.boot.transport.SingleResponse<java.lang.String> exportAllJsonFileTask(com.seeyon.boot.transport.SingleRequest<java.lang.Boolean>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.boot.starter.datamigration.dto.JsonExportTaskResponseDto> exportTaskQuery(com.seeyon.boot.transport.SingleRequest<java.lang.String>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.boot.starter.datamigration.dto.JsonImportTaskResponseDto> importTaskQuery(com.seeyon.boot.transport.SingleRequest<java.lang.String>);
    com.seeyon.boot.transport.SingleResponse<java.lang.String> importJsonFile(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.datamigration.dto.JsonImportRequestDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.String> importJsonFileTask(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.datamigration.dto.JsonImportRequestDto>);
```

### `ExportStorageService`（11 方法）

`com.seeyon.boot.starter.configmigration.service.ExportStorageService`

```java
    boolean exportUploadOss(java.lang.Long, java.lang.String);
    private com.seeyon.boot.starter.configmigration.dto.oss.ModuleManifestDto exportConfigData(java.lang.Long, java.lang.String, java.lang.String);
    private com.seeyon.boot.starter.configmigration.dto.oss.ModuleManifestDto exportRelationData(java.lang.Long, java.lang.String);
    private com.seeyon.boot.starter.configmigration.dto.oss.FileInfoDto fileMap(com.seeyon.boot.starter.file.dto.response.UploadResultDto);
```

### `JsonExportService`（11 方法）

`com.seeyon.boot.starter.datamigration.domain.service.JsonExportService`

```java
    com.seeyon.boot.transport.SingleResponse<com.seeyon.boot.starter.datamigration.dto.JsonExportRequestDto> getAllEntity(com.seeyon.boot.transport.SingleRequest<java.lang.Boolean>);
    com.seeyon.boot.transport.SingleResponse<java.lang.String> exportJsonFile(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.datamigration.dto.JsonExportRequestDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.String> exportJsonEntityFile(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.datamigration.dto.JsonExportEntityRequestDto>);
    private java.lang.String getDownloadUrl(java.util.Set<java.lang.String>, java.lang.Boolean)
    private java.lang.String getDownloadUrl(java.util.Map<java.lang.String, java.util.Map<java.lang.String, java.lang.Object>>, java.lang.Boolean)
    private java.lang.String getEntityData(java.lang.String, java.lang.Boolean);
    private java.lang.String getEntityDataByCondition(java.lang.String, java.util.Map<java.lang.String, java.lang.Object>, java.lang.Boolean);
    private void dataConvert(java.util.List<java.lang.Object>, java.lang.String, java.lang.Boolean);
    private void writeJson(java.lang.String, java.lang.String)
    private java.util.Set<java.lang.String> getEntitySet(com.seeyon.boot.starter.datamigration.dto.JsonExportRequestDto);
    private void getChildren(com.seeyon.ctp.metadata.dto.AggMetadataDto, java.util.Set<java.lang.String>, int);
```

### `StorageServiceCommonImpl`（11 方法）

`com.seeyon.boot.starter.datamigration2.storage.StorageServiceCommonImpl`

```java
    java.lang.String downloadUrl(java.lang.String);
    java.lang.String uploadZip(java.io.File, java.lang.String);
    java.lang.String uploadJson(java.lang.String, java.lang.String);
    java.lang.String downloadJson(java.lang.String);
    java.lang.String downloadFromOss(java.lang.String);
    java.lang.String commonStorageToFerryboat(java.lang.String, java.lang.String);
    java.lang.String getFileNameFromOss(java.lang.String);
    java.lang.String ferryboatToCommonStorage(java.lang.String, java.lang.String, java.lang.String, java.lang.Boolean);
    boolean existForFile(java.lang.String);
    boolean existForPublicFile(java.lang.String);
    boolean enableFerryboat();
```

### `StorageServiceMgnImpl`（11 方法）

`com.seeyon.boot.starter.datamigration2.storage.StorageServiceMgnImpl`

```java
    java.lang.String downloadUrl(java.lang.String);
    java.lang.String uploadZip(java.io.File, java.lang.String);
    java.lang.String uploadJson(java.lang.String, java.lang.String);
    java.lang.String downloadJson(java.lang.String);
    java.lang.String downloadFromOss(java.lang.String);
    java.lang.String commonStorageToFerryboat(java.lang.String, java.lang.String);
    java.lang.String getFileNameFromOss(java.lang.String);
    java.lang.String ferryboatToCommonStorage(java.lang.String, java.lang.String, java.lang.String, java.lang.Boolean);
    boolean existForFile(java.lang.String);
    boolean existForPublicFile(java.lang.String);
    boolean enableFerryboat();
```

### `StorageServiceNexusImpl`（11 方法）

`com.seeyon.boot.starter.datamigration2.storage.StorageServiceNexusImpl`

```java
    java.lang.String uploadZip(java.io.File, java.lang.String);
    java.lang.String uploadJson(java.lang.String, java.lang.String);
    java.lang.String downloadUrl(java.lang.String);
    java.lang.String downloadFromOss(java.lang.String);
    java.lang.String downloadJson(java.lang.String);
    java.lang.String commonStorageToFerryboat(java.lang.String, java.lang.String);
    java.lang.String getFileNameFromOss(java.lang.String);
    java.lang.String ferryboatToCommonStorage(java.lang.String, java.lang.String, java.lang.String, java.lang.Boolean);
    boolean existForFile(java.lang.String);
    boolean existForPublicFile(java.lang.String);
    boolean enableFerryboat();
```

### `DefaultTaskManager`（8 方法）

`com.seeyon.boot.starter.configmigration.executor.DefaultTaskManager`

```java
    boolean addFutureTask(java.lang.Long, java.util.concurrent.CompletableFuture<?>);
    boolean cancelFutureTask(java.lang.Long);
    boolean removeFutureTask(java.lang.Long, java.util.concurrent.CompletableFuture<?>);
    int countFutureTask(java.lang.Long);
    java.util.List<java.lang.Long> getAllTasks();
```

### `AbstractApplicationHandler`（8 方法）

`com.seeyon.boot.starter.configmigration.handler.AbstractApplicationHandler`

```java
    boolean supports(java.lang.Class<?>);
    <T extends com.seeyon.boot.domain.entity.BaseEntity> void processQueryData(com.seeyon.boot.starter.configmigration.core.context.ExecutionContext, T);
    <T extends com.seeyon.boot.domain.entity.BaseEntity> void processReplaceData(com.seeyon.boot.starter.configmigration.core.context.ExecutionContext, T);
    private boolean statusCallback(java.lang.String, java.util.function.Consumer<java.lang.String>);
```

### `AbstractPackageHandler`（8 方法）

`com.seeyon.boot.starter.configmigration.handler.AbstractPackageHandler`

```java
    boolean supports(java.lang.Class<?>);
    <T extends com.seeyon.boot.domain.entity.BaseEntity> void processQueryData(com.seeyon.boot.starter.configmigration.core.context.ExecutionContext, T);
    <T extends com.seeyon.boot.domain.entity.BaseEntity> void processReplaceData(com.seeyon.boot.starter.configmigration.core.context.ExecutionContext, T);
    java.lang.String callDownloadApp(java.lang.String)
    java.lang.String callImportJar(java.lang.String)
```

### `BaseConfigItemSearchDto`（8 方法）

`com.seeyon.boot.starter.configmigration.view.dto.BaseConfigItemSearchDto`

```java
    java.lang.Long getMenuId();
    com.seeyon.boot.transport.PageInfo getPageInfo();
    com.seeyon.boot.transport.Sort getSort();
    java.util.Map<java.lang.String, java.lang.Object> getConditions();
    void setMenuId(java.lang.Long);
    void setPageInfo(com.seeyon.boot.transport.PageInfo);
    void setSort(com.seeyon.boot.transport.Sort);
    void setConditions(java.util.Map<java.lang.String, java.lang.Object>);
```

### `MgnInMainService`（8 方法）

`com.seeyon.boot.starter.datamigration2.appservice.MgnInMainService`

```java
    com.seeyon.boot.transport.SingleResponse<java.lang.String> createInMgnJob(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.datamigration2.dto.MgnInAppTaskInfoDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.boot.starter.datamigration2.dto.MgnInEntityInfoDto> getInEntityInfo(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.datamigration2.dto.MgnInEntityTaskInfoParam>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.boot.starter.datamigration2.dto.MgnInEntityDetailDto> getInEntityRes(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.datamigration2.dto.MgnInEntityTaskInfoParam>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.boot.starter.datamigration2.dto.MgnInEntityDetailDto> getInEntityRes(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.datamigration2.dto.MgnInEntityTaskInfoParam>, int);
    com.seeyon.boot.transport.SingleResponse<java.lang.String> rollback(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.datamigration2.dto.MgnInRollbackParam>);
    private void validate(com.seeyon.boot.starter.datamigration2.dto.MgnInAppTaskInfoDto);
    private com.seeyon.boot.starter.datamigration2.customer.MgnSortParam getSortParam(java.util.List<com.seeyon.boot.starter.datamigration2.dto.MgnInEntityInfoDto>, java.lang.String, java.lang.String, java.lang.String);
    private java.util.List<com.seeyon.boot.starter.datamigration2.dto.MgnInEntityInfoDto> sort(java.util.List<com.seeyon.boot.starter.datamigration2.dto.MgnInEntityInfoDto>, java.util.List<java.lang.String>);
```

### `MgnOutMainService`（8 方法）

`com.seeyon.boot.starter.datamigration2.appservice.MgnOutMainService`

```java
    com.seeyon.boot.transport.SingleResponse<java.lang.String> createOutMgnJob(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.datamigration2.dto.MgnOutAppTaskInfoDto>);
    private boolean isMainAgg(com.seeyon.boot.starter.datamigration2.dto.MgnOutEntityInfoDto);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.boot.starter.datamigration2.dto.MgnOutEntityInfoDto> getOutEntityInfo(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.datamigration2.dto.MgnOutEntityTaskInfoParam>);
    com.seeyon.boot.transport.SingleResponse<java.lang.String> getFileNameFromOss(com.seeyon.boot.transport.SingleRequest<java.lang.String>);
    com.seeyon.boot.transport.ListResponse<java.lang.Object> getOutEntityData(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.datamigration2.dto.MgnOutEntityTaskInfoParam>);
    com.seeyon.boot.transport.ListResponse<java.lang.Object> getOutEntityData(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.datamigration2.dto.MgnOutEntityTaskInfoParam>, int);
    com.seeyon.boot.transport.ListResponse<java.lang.Object> getOutEntityData(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.datamigration2.dto.MgnOutEntityTaskInfoParam>, java.lang.Long, int);
    private void validate(com.seeyon.boot.starter.datamigration2.dto.MgnOutAppTaskInfoDto);
```

### `MgnAdapterConfig`（8 方法）

`com.seeyon.boot.starter.datamigration2.customer.MgnAdapterConfig`

```java
    void exportBatchInterfaceAdd(java.lang.String, com.seeyon.boot.starter.datamigration2.customer.MgnExportBatchInterface);
    void exportInterfaceAdd(java.lang.String, com.seeyon.boot.starter.datamigration2.customer.MgnExportInterface);
    void inAdapterAdd(java.lang.String, com.seeyon.boot.starter.datamigration2.customer.MgnInAdapter);
    void uniqueAdapterAdd(java.lang.String, com.seeyon.boot.starter.datamigration2.customer.MgnUniqueAdapter);
    com.seeyon.boot.starter.datamigration2.customer.MgnExportBatchInterface exportBatchInterfaceGet(java.lang.String);
    com.seeyon.boot.starter.datamigration2.customer.MgnExportInterface exportInterfaceGet(java.lang.String);
    com.seeyon.boot.starter.datamigration2.customer.MgnInAdapter inAdapterGet(java.lang.String);
    com.seeyon.boot.starter.datamigration2.customer.MgnUniqueAdapter uniqueAdapterGet(java.lang.String);
```

### `MgnTenantService`（8 方法）

`com.seeyon.boot.starter.datamigration2.service.MgnTenantService`

```java
    java.util.List<java.lang.String> envListGet();
    com.seeyon.boot.starter.datamigration2.dto.MgnTenantTaskInfoDto getTaskStatus(java.lang.String);
    java.lang.String createOutJob(com.seeyon.boot.starter.datamigration2.dto.MgnTenantTaskDto);
    java.lang.String createInJob(com.seeyon.boot.starter.datamigration2.dto.MgnTenantTaskDto);
    com.seeyon.boot.starter.datamigration2.dto.MgnTenantTaskDto getJobInfo(java.lang.String, java.lang.String);
    com.seeyon.boot.starter.datamigration2.dto.MgnTenantTaskDto jobCancel(java.lang.String, java.lang.String);
    java.util.Map<java.lang.Long, java.lang.Integer> tenantExist(java.util.List<java.lang.Long>, java.util.List<java.lang.String>);
    void uploadEnv(java.lang.String);
```

### `PrepareTaskExecutor`（7 方法）

`com.seeyon.boot.starter.configmigration.executor.impl.PrepareTaskExecutor`

```java
    void execute(java.util.List<com.seeyon.boot.starter.configmigration.dto.TaskInfoDto>);
    private void execute0(java.util.List<com.seeyon.boot.starter.configmigration.dto.TaskInfoDto>);
    void execute(java.lang.Object);
```

### `AttachmentHandler`（7 方法）

`com.seeyon.boot.starter.configmigration.handler.AttachmentHandler`

```java
    int getOrder();
    boolean supports(java.lang.Class<?>);
    <T extends com.seeyon.boot.domain.entity.BaseEntity> void processQueryData(com.seeyon.boot.starter.configmigration.core.context.ExecutionContext, T);
    <T extends com.seeyon.boot.domain.entity.BaseEntity> void processReplaceData(com.seeyon.boot.starter.configmigration.core.context.ExecutionContext, T);
```

### `ValueMappingUtils`（7 方法）

`com.seeyon.boot.starter.configmigration.util.ValueMappingUtils`

```java
    static private static void init();
    static void clear(java.lang.Long);
    static <T> void appendMap(java.lang.Long, java.util.Map<T, T>);
    static java.lang.String getStringValue(java.lang.Long, java.lang.String);
    static java.lang.Long getLongValue(java.lang.Long, java.lang.String);
    static <T> java.util.Map<T, T> getMapValues(java.lang.Long, java.util.Set<java.lang.String>);
```

### `AutoListenerService`（7 方法）

`com.seeyon.boot.starter.datamigration.domain.service.AutoListenerService`

```java
    void downloadAndImport(java.lang.String, java.lang.String, java.lang.String);
    private void updateSqlInitVersion(java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String);
    private com.seeyon.boot.transport.SingleResponse<java.lang.String> importJsonFile(java.lang.String, java.lang.String, java.lang.String, java.lang.String);
    private java.lang.String getDbVersion(java.lang.String);
    private boolean checkUpdate(java.lang.String, java.lang.String);
    boolean versionCompare(java.lang.String, java.lang.String);
```

### `EntityDataImportService`（7 方法）

`com.seeyon.boot.starter.datamigration2.in.EntityDataImportService`

```java
    java.util.List<com.seeyon.boot.starter.datamigration2.dto.MgnInEntityDetailDto> entityImport(com.seeyon.boot.starter.datamigration2.dto.MgnOutEntityInfoDto, java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.Boolean, java.lang.Boolean);
    private boolean childrenExe(java.lang.String, java.lang.String, java.lang.Boolean, java.lang.Boolean, java.util.List<com.seeyon.boot.starter.datamigration2.dto.MgnInEntityDetailDto>, java.util.Map<java.lang.String, java.util.Map<java.lang.String, java.lang.String>>, java.util.Map<java.lang.String, java.util.Map<java.lang.String, java.lang.String>>, java.lang.Long, com.seeyon.boot.starter.datamigration2.dto.MgnInEntityDetailDto);
    void rollBack(com.seeyon.boot.starter.datamigration2.dto.MgnInEntityInfoDto, java.lang.String);
    private boolean customerUniqueCheck(java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.util.List<com.seeyon.boot.starter.datamigration2.dto.MgnInEntityDetailDto>, java.lang.Object, java.lang.Long, com.seeyon.boot.starter.datamigration2.dto.MgnInEntityDetailDto);
    private void OssFieldChange(java.lang.String, java.lang.String, java.util.Map<java.lang.String, java.lang.reflect.Field>, java.util.Map<java.lang.String, java.util.List<com.seeyon.boot.starter.datamigration2.dto.StorageFieldDataDto>>, java.lang.Object, java.lang.Long);
    private void customerAfter(java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.util.List<java.lang.Object>);
```

### `MgnStarterInvokeService`（6 方法）

`com.seeyon.boot.starter.configmigration.service.MgnStarterInvokeService`

```java
    java.lang.String invokeDownloadApp(java.lang.Long);
    java.lang.String invokeTransfer(java.lang.String);
    java.util.Map<java.lang.String, java.lang.Object> invokeRequestStatus(java.lang.String);
    void invokeTaskCallBack(com.seeyon.boot.starter.configmigration.dto.TaskInfoDto);
    java.util.List<java.util.Map> invokeSelectDataByCondition(com.seeyon.boot.starter.configmigration.dto.DataSearchDto);
```

### `ValidatorManager`（6 方法）

`com.seeyon.boot.starter.configmigration.validator.ValidatorManager`

```java
    private <T> com.seeyon.boot.starter.configmigration.api.DataComparator findDataComparator(java.lang.Class<?>);
    void relationValid(com.seeyon.boot.starter.configmigration.core.context.ExecutionContext, com.seeyon.boot.starter.configmigration.core.result.DataValidationResult);
    com.seeyon.boot.starter.configmigration.core.result.DataValidationResult dataValid(com.seeyon.boot.starter.configmigration.core.context.ExecutionContext);
    private com.seeyon.boot.starter.configmigration.core.result.DataValidationResult buildDataValidationResult(com.seeyon.boot.starter.configmigration.core.context.DataMetaInfo);
```

### `EntityDataScanService`（6 方法）

`com.seeyon.boot.starter.datamigration2.out.EntityDataScanService`

```java
    java.lang.Integer getEntityDataCount(java.lang.String);
    java.util.List<java.lang.Object> getEntityData(java.lang.String, java.util.Set<java.lang.String>, com.seeyon.boot.transport.PageInfo);
    java.lang.Integer batchCreate(java.lang.String, java.util.List<java.lang.Object>);
    java.lang.Integer getEntityDataByConditionCount(java.lang.String, java.util.Map<java.lang.String, java.lang.Object>);
    java.util.List<java.lang.Object> getEntityDataByCondition(java.lang.String, java.util.Map<java.lang.String, java.lang.Object>, java.util.Set<java.lang.String>, com.seeyon.boot.transport.PageInfo);
    private void dataConvert(java.util.List<java.lang.Object>, java.lang.String, java.util.Set<java.lang.String>);
```

### `MgnOutScheduleService`（6 方法）

`com.seeyon.boot.starter.datamigration2.task.MgnOutScheduleService`

```java
    void startImport(java.lang.String, java.lang.String, java.lang.String);
    void deleteImport(java.lang.String);
    void taskClear();
    void task();
    void checkStatus(java.lang.String, java.lang.String);
    synchronized void appTaskCheck(java.lang.String, com.seeyon.boot.starter.datamigration2.dto.MgnTaskDto);
```

### `EntityDataService`（5 方法）

`com.seeyon.boot.starter.configmigration.service.EntityDataService`

```java
    <T> java.util.List<T> selectByConditions(java.lang.String, java.util.Map<java.lang.String, java.lang.Object>, java.util.Set<java.lang.String>, com.seeyon.boot.transport.Sort);
    <T> com.seeyon.boot.transport.PageData<T> selectPageByConditions(java.lang.String, java.util.Map<java.lang.String, java.lang.Object>, java.util.Set<java.lang.String>, com.seeyon.boot.transport.PageInfo, com.seeyon.boot.transport.Sort);
    private void dataConvert(java.util.List<java.lang.Object>, java.lang.String, java.util.Set<java.lang.String>);
    java.util.List<java.util.Map> selectDataByCondition(com.seeyon.boot.starter.configmigration.dto.DataSearchDto);
```

### `JsonImportService`（5 方法）

`com.seeyon.boot.starter.datamigration.domain.service.JsonImportService`

```java
    com.seeyon.boot.transport.SingleResponse<java.lang.String> importJsonFile(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.datamigration.dto.JsonImportRequestDto>);
    private void scanAndInitDb(java.lang.String);
    private void initJSON(java.lang.String, java.lang.String);
    private void entityListInit(java.lang.Class<?>, java.util.List<?>, java.lang.String)
    private void batchExe(java.util.List<java.lang.Long>, java.util.Map<java.lang.Long, java.lang.Object>, com.seeyon.boot.starter.mybatis.BaseMybatisDao, java.util.Map<java.lang.String, java.lang.reflect.Field>)
```

### `OssMigrationServiceImpl`（5 方法）

`com.seeyon.boot.starter.datamigration.domain.service.OssMigrationServiceImpl`

```java
    java.lang.String uploadForFerryboat(java.lang.String, java.lang.String);
    java.lang.String ossUpload(java.io.File);
    java.util.Map<java.lang.String, java.lang.Object> downloadFromFerryboat(java.lang.String);
    void downloadFromOss(java.lang.String, java.lang.String, java.lang.String);
    boolean existForFerryboat(java.lang.String);
```

### `MgnInScheduleService`（5 方法）

`com.seeyon.boot.starter.datamigration2.task.MgnInScheduleService`

```java
    void startImport(java.lang.String, java.lang.String, java.lang.String);
    void deleteImport(java.lang.String);
    void task();
    void checkStatus(java.lang.String, java.lang.String);
    private synchronized void appTaskCheck(java.lang.String, com.seeyon.boot.starter.datamigration2.dto.MgnTaskDto);
```

### `ConfigAppService`（4 方法）

`com.seeyon.boot.starter.configmigration.appservice.ConfigAppService`

```java
    com.seeyon.boot.transport.PageResponse<com.seeyon.boot.starter.configmigration.view.dto.ConfigItemDto> selectPageConfigItemList(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.configmigration.view.dto.ConfigItemSearchDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.boot.starter.configmigration.view.dto.ConfigItemDto> selectConfigItemList(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.configmigration.view.dto.ConfigItemSearchDto>);
    com.seeyon.boot.transport.ListResponse<java.util.Map> selectDataByCondition(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.configmigration.dto.DataSearchDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Boolean> saveConfigData(com.seeyon.boot.transport.SingleRequest<java.util.List<com.seeyon.boot.starter.configmigration.dto.TaskInfoDto>>);
```

### `ConfigDataController`（4 方法）

`com.seeyon.boot.starter.configmigration.controller.ConfigDataController`

```java
    com.seeyon.boot.transport.ListResponse<com.seeyon.boot.starter.configmigration.core.context.DataMetaInfo> selectAggData(java.lang.Long, java.lang.Long);
    com.seeyon.boot.transport.PageResponse<com.seeyon.boot.starter.configmigration.core.result.DataDiffResult> selectPageByDataRootId(com.seeyon.boot.transport.PageRequest);
    com.seeyon.boot.transport.SingleResponse<java.lang.Boolean> importData(java.lang.Long);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.boot.starter.configmigration.dto.TaskStatusDto> selectTaskProgress(java.lang.String, java.lang.Long);
```

### `FieldResolverFactory`（4 方法）

`com.seeyon.boot.starter.configmigration.factory.FieldResolverFactory`

```java
    static <T, R> com.seeyon.boot.starter.configmigration.core.resolver.FieldResolver<T, R> reflection(java.lang.Class<?>, java.lang.String);
    static <T, R> com.seeyon.boot.starter.configmigration.core.resolver.FieldResolver<T, R> functional(java.util.function.Function<T, R>);
    static <T extends com.seeyon.boot.domain.entity.BaseEntity> com.seeyon.boot.starter.configmigration.core.resolver.FieldResolver<T, java.lang.Long> idResolver();
    static <T, R, V> com.seeyon.boot.starter.configmigration.core.resolver.FieldResolver<T, V> transforming(com.seeyon.boot.starter.configmigration.core.resolver.FieldResolver<T, R>, java.util.function.Function<R, V>);
```

### `WritableFieldFactory`（4 方法）

`com.seeyon.boot.starter.configmigration.factory.WritableFieldFactory`

```java
    static <T, F> com.seeyon.boot.starter.configmigration.core.transform.WritableField<T, F> reflection(java.lang.Class<T>, java.lang.String);
    static <T, F> com.seeyon.boot.starter.configmigration.core.transform.WritableField<T, F> functional(java.util.function.Function<T, F>, java.util.function.BiConsumer<T, F>);
    static <T, F> com.seeyon.boot.starter.configmigration.core.transform.TrackableWritableField<T, F> warpWritableField(com.seeyon.boot.starter.configmigration.core.transform.WritableField<T, F>);
    static <T, F> com.seeyon.boot.starter.configmigration.core.transform.ChainedWritableField<T, F> chainedWritableField();
```

### `DataUtils`（4 方法）

`com.seeyon.boot.starter.configmigration.util.DataUtils`

```java
    static com.seeyon.boot.starter.configmigration.core.context.DataMetaInfo extractMetaInfo(java.lang.Long, com.seeyon.boot.starter.configmigration.dto.EntityDslDto, com.seeyon.boot.domain.entity.BaseEntity);
    static org.apache.commons.lang3.tuple.Pair<com.seeyon.boot.starter.configmigration.core.context.StandardValue, com.seeyon.boot.starter.configmigration.core.context.StandardValue> extractDiffFieldValue(com.seeyon.boot.starter.configmigration.core.context.DataMetaInfo, com.seeyon.boot.domain.entity.BaseEntity, com.seeyon.boot.domain.entity.BaseEntity, java.util.Set<java.lang.String>);
```

### `PathBuilderUtils`（4 方法）

`com.seeyon.boot.starter.configmigration.util.PathBuilderUtils`

```java
    static java.lang.String getAttachmentPath(com.seeyon.boot.starter.configmigration.enums.RelationType, java.lang.String);
    static java.lang.String buildPackagePath(java.lang.Long);
    static java.lang.String buildAppManifestPath(java.lang.Long, java.lang.String);
    static java.lang.String buildModulePath(java.lang.Long, java.lang.String, java.lang.String);
```

### `EnvInfoUploadService`（4 方法）

`com.seeyon.boot.starter.datamigration2.EnvInfoUploadService`

```java
    private void uploadEnvVersion();
    java.lang.String getAppVersion(java.lang.String, java.lang.String);
    void onApplicationEvent(com.seeyon.boot.event.SystemStartedEvent);
    void onApplicationEvent(org.springframework.context.ApplicationEvent);
```

### `MgnSendMessageService`（4 方法）

`com.seeyon.boot.starter.datamigration2.message.MgnSendMessageService`

```java
    void successMessage(java.lang.String, com.seeyon.boot.starter.datamigration2.dto.MgnOutTaskInfoDto);
```

### `ConfigDataAppService`（3 方法）

`com.seeyon.boot.starter.configmigration.appservice.ConfigDataAppService`

```java
    com.seeyon.boot.transport.ListResponse<com.seeyon.boot.starter.configmigration.core.context.DataMetaInfo> selectAggData(com.seeyon.boot.transport.SingleRequest<java.util.Map>);
    com.seeyon.boot.transport.PageResponse<com.seeyon.boot.starter.configmigration.core.result.DataDiffResult> selectPageByDataRootId(com.seeyon.boot.transport.PageRequest);
```

### `AbstractTaskExecutor`（3 方法）

`com.seeyon.boot.starter.configmigration.executor.AbstractTaskExecutor`

```java
    org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor getExecutor();
    com.seeyon.boot.starter.configmigration.listener.TaskListener getTaskListener();
    com.seeyon.boot.starter.configmigration.executor.TaskManager getTaskManager();
```

### `CallBackTaskExecutor`（3 方法）

`com.seeyon.boot.starter.configmigration.executor.impl.CallBackTaskExecutor`

```java
    void execute(java.lang.Long);
    void execute(java.lang.Object);
```

### `ReceiveTaskExecutor`（3 方法）

`com.seeyon.boot.starter.configmigration.executor.impl.ReceiveTaskExecutor`

```java
    void execute(java.lang.Long);
    void execute(java.lang.Object);
```

### `RollBackTaskExecutor`（3 方法）

`com.seeyon.boot.starter.configmigration.executor.impl.RollBackTaskExecutor`

```java
    void execute(java.lang.Long);
    void execute(java.lang.Object);
```

### `UploadTaskExecutor`（3 方法）

`com.seeyon.boot.starter.configmigration.executor.impl.UploadTaskExecutor`

```java
    void execute(java.lang.Long);
    void execute(java.lang.Object);
```

### `ValidationTaskExecutor`（3 方法）

`com.seeyon.boot.starter.configmigration.executor.impl.ValidationTaskExecutor`

```java
    void execute(java.lang.Long);
    void execute(java.lang.Object);
```

### `DefaultDataBackupHandler`（3 方法）

`com.seeyon.boot.starter.configmigration.handler.DefaultDataBackupHandler`

```java
    <T extends com.seeyon.boot.domain.entity.BaseEntity> void backupData(java.lang.Long, java.util.List<T>);
    <T extends com.seeyon.boot.domain.entity.BaseEntity> void rollBackData(java.util.List<com.seeyon.boot.starter.configmigration.core.context.ExecutionContext>);
```

### `DefaultEntityDslHandler`（3 方法）

`com.seeyon.boot.starter.configmigration.handler.DefaultEntityDslHandler`

```java
    boolean supports(java.lang.Class<?>);
    com.seeyon.boot.transport.PageData<? extends com.seeyon.boot.domain.entity.BaseEntity> fetchData(com.seeyon.boot.starter.configmigration.core.context.condition.FetchCondition);
    void handleDsl(com.seeyon.boot.starter.configmigration.dto.EntityDslDto);
```

### `GraphUtils`（3 方法）

`com.seeyon.boot.starter.configmigration.util.GraphUtils`

```java
    static <N> com.google.common.graph.MutableGraph<N> buildDirectedGraph(java.util.Collection<com.google.common.graph.EndpointPair<N>>);
    static <N> com.google.common.graph.MutableGraph<N> reverseGraph(com.google.common.graph.Graph<N>);
```

### `EntityConfigServiceImpl`（3 方法）

`com.seeyon.boot.starter.configmigration.view.impl.EntityConfigServiceImpl`

```java
    com.seeyon.boot.transport.PageData<com.seeyon.boot.starter.configmigration.view.dto.ConfigItemDto> selectPageConfigItemList(com.seeyon.boot.starter.configmigration.view.dto.ConfigItemSearchDto);
    java.util.List<com.seeyon.boot.starter.configmigration.view.dto.ConfigItemDto> selectConfigItemList(com.seeyon.boot.starter.configmigration.view.dto.ConfigItemSearchDto);
    private java.util.List<com.seeyon.boot.starter.configmigration.view.dto.ConfigItemDto> dataConvert(java.util.List<java.lang.Object>, java.lang.String, java.util.Set<java.lang.String>);
```

## 四、枚举（18）

- `ConditionType`（3 常量）：ALL, IDS, CONDITION
- `DataStatus`（3 常量）：PROCESSING, SUCCESS, FAIL
- `DiffType`（3 常量）：MISSING, EQUAL, CONFLICT
- `EntityType`（2 常量）：ENTITY, COMPONENT
- `ExecutionPolicy`（5 常量）：NONE, NEW, OVERWRITE, IGNORE, REJECT
- `RelationType`（6 常量）：ENTITY, ATTACHMENT, APPLICATION, PACKAGE, DELEGATE, CUSTOM
- `RequestStatusEnum`（4 常量）：PROCESSING, COMPLETE, EXCEPTION, TIMEOUT
- `TaskStatus`（4 常量）：NONE, EXECUTING, SUCCESS, FAIL
- `TaskType`（9 常量）：NOTICE, WRITE_BACK, PREPARE, UPLOAD, DOWNLOAD, DETECT, RECEIVE, ROLLBACK, CALLBACK
- `MgnDbStatus`（2 常量）：SUCCESS, FAIL
- `MgnDbType`（3 常量）：INSERT, UPDATE, NODO
- `MgnEnvRelation`（4 常量）：mgnprodTomgntest, mgnprodTomgnimpl, mgnimplTomgnprod, ALL
- `MgnInStatus`（6 常量）：CREATE, START, SUCCESSALL, SUCCESSSOME, FAIL, NONE
- `MgnInfoStatus`（3 常量）：CREATE, SUCCESS, FAIL
- `MgnOutStatus`（5 常量）：CREATE, START, SUCCESS, FAIL, NONE
- `MgnOutType`（3 常量）：COMMON, CUSTOMER, CUSTOMER_BATCH
- `MgnTaskStatus`（4 常量）：CREATE, UPLOAD, START, FINISH
- `MgnUploadZipStatus`（3 常量）：UPLOADING, UPLOAD_FINISH, ERROR
