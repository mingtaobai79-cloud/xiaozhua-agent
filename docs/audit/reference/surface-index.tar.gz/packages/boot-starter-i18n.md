# boot-starter-i18n：接口与方法签名

> 自动生成，勿手改。`tools/core/platform/emit_package_surfaces.py` 重跑即可。
> 构件 `com.seeyon:boot-starter-i18n`（jar `boot-starter-i18n-5.3.600.jar`）
> 规模：28 类 / 3 接口 / 0 注解 / 2 枚举 / 4 个关键类 / 367 方法。
> 签名逐字来自 javap 原文；已去掉 `public` 前缀与 `throws` 子句。

## 一、接口（3）

### `MetadataI18nResourceLoader`（6 方法）

`com.seeyon.boot.starter.i18n.loader.MetadataI18nResourceLoader`

```java
    java.util.Map<java.lang.String, java.util.Map<java.lang.String, com.seeyon.boot.starter.i18n.dto.I18nResourceDto>> loadEntityMetadataResources(java.lang.String);
    java.util.Map<java.lang.String, java.util.Map<java.lang.String, com.seeyon.boot.starter.i18n.dto.I18nResourceDto>> loadDyAppEntityMetadataResources(java.lang.String, java.lang.String);
    java.util.Map<java.lang.String, java.util.Map<java.lang.String, com.seeyon.boot.starter.i18n.dto.I18nResourceDto>> loadStarterEntityMetadataResources(com.seeyon.boot.context.model.StarterInfo);
    java.util.Map<java.lang.String, com.seeyon.boot.starter.i18n.dto.I18nResourcePageInfoDto> loadPageMenusMapping(java.lang.String);
    java.util.Map<java.lang.String, com.seeyon.boot.starter.i18n.dto.I18nResourcePageInfoDto> loadDyPageInfo(java.lang.String);
    void clearI18nCache(com.seeyon.boot.starter.i18n.dto.BundleChangeMessageDto);
```

### `I18nLocaleAppService`（4 方法）

`com.seeyon.boot.starter.i18n.api.I18nLocaleAppService`

```java
    default com.seeyon.boot.transport.SingleResponse<java.util.Map<java.lang.String, java.lang.String>> getEnableLocalesMap(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    default com.seeyon.boot.transport.SingleResponse<java.lang.String> getTenantDefaultLocale();
    default com.seeyon.boot.transport.SingleResponse<java.util.List<java.util.Map<java.lang.String, java.lang.String>>> getSystemDataI18nLocaleList();
    default com.seeyon.boot.transport.SingleResponse<java.util.List<java.util.Map<java.lang.String, java.lang.String>>> getTenantDataI18nLocaleList();
```

### `I18nResourceAppService`（1 方法）

`com.seeyon.boot.starter.i18n.api.I18nResourceAppService`

```java
    default com.seeyon.boot.transport.SingleResponse<java.util.Map<java.lang.String, com.seeyon.boot.starter.i18n.dto.I18nResourceDto>> getTenantResourceDtoMap(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.i18n.dto.TenantResourceRequestDto>);
```

## 二、关键类（4）

### `I18nResourceService`（95 方法）

`com.seeyon.boot.starter.i18n.I18nResourceService`

```java
    void destroy();
    boolean getResourceEnable();
    void init();
    void clearMetadataI18nCache(com.seeyon.boot.starter.i18n.dto.BundleChangeMessageDto);
    void initMetadataI18nResourceLoader();
    private void initNotice(java.util.List<com.seeyon.boot.context.model.AppInfo>, java.util.List<com.seeyon.boot.context.model.StarterInfo>, java.util.List<java.lang.String>);
    private void initNotice(java.util.List<java.lang.String>);
    private boolean canNotice();
    private void notice(com.seeyon.boot.starter.i18n.dto.DefaultI18nResourceChangeMessageDto);
    void bundleChangeNotice(java.lang.String, java.lang.Long);
    void bundleChangeNotice(java.util.List<java.lang.String>, java.lang.Long);
    void createThirdAppMenuI18nResource(java.lang.String, java.util.Map<java.lang.String, com.seeyon.boot.starter.i18n.dto.I18nResourceDto>);
    private java.util.Map<java.lang.String, java.util.Map<java.lang.String, com.seeyon.boot.starter.i18n.dto.I18nResourceDto>> collectAppMetadataI18nResources(java.lang.String);
    private java.util.Map<java.lang.String, java.util.Map<java.lang.String, com.seeyon.boot.starter.i18n.dto.I18nResourceDto>> collectAppI18nResources(java.lang.String, java.util.Map<java.lang.String, com.seeyon.boot.starter.i18n.dto.BundleInfoDto>)
    private void registerAppResource(com.seeyon.boot.context.model.AppInfo, java.util.Map<java.lang.String, com.seeyon.boot.starter.i18n.dto.BundleInfoDto>, java.util.Map<java.lang.String, java.util.Map<java.lang.String, com.seeyon.boot.starter.i18n.dto.I18nResourceDto>>);
    private java.util.Map<java.lang.String, com.seeyon.boot.starter.i18n.dto.BundleInfoDto> buildAppBundleInfoMap(com.seeyon.boot.context.model.AppInfo, java.util.Map<java.lang.String, java.util.Map<java.lang.String, com.seeyon.boot.starter.i18n.dto.I18nResourceDto>>);
    private void registerFrontAppResource(com.seeyon.boot.context.model.AppInfo, java.util.Map<java.lang.String, com.seeyon.boot.starter.i18n.dto.BundleInfoDto>, java.util.Map<java.lang.String, java.util.Map<java.lang.String, com.seeyon.boot.starter.i18n.dto.I18nResourceDto>>);
    java.util.Map<java.lang.String, com.seeyon.boot.starter.i18n.dto.I18nResourceDto> buildFrontComponentsResource(java.lang.String, com.seeyon.boot.starter.i18n.dto.FrontCompInfoDto);
    java.util.Map<java.lang.String, com.seeyon.boot.starter.i18n.dto.FrontResourceInfoDto> getFrontResourceInfoMap(java.lang.String);
    void saveFrontResourceInfoMap(java.lang.String, java.util.Map<java.lang.String, com.seeyon.boot.starter.i18n.dto.FrontResourceInfoDto>);
    private void refreshBundleRelation(java.lang.String, java.lang.String);
    private void refreshBundleRelation(java.lang.String, com.seeyon.boot.starter.i18n.dto.FrontResourceInfoDto);
    private void refreshDyBundleRelation(java.lang.String, java.lang.String, com.seeyon.boot.starter.i18n.dto.FrontResourceInfoDto);
    java.util.Set<java.lang.String> getRelationBundleSet(java.lang.String);
    private void writeDataJson(java.lang.String, java.lang.String);
    void frontAppResourceJob();
    java.util.Map<java.lang.String, com.seeyon.boot.starter.i18n.dto.FrontCompInfoDto> getFrontCompInfoMap();
    void saveFrontCompInfo(java.util.Map<java.lang.String, com.seeyon.boot.starter.i18n.dto.FrontCompInfoDto>);
    java.util.Map<java.lang.String, com.seeyon.boot.starter.i18n.dto.FrontCompInfoDto> readAllFrontCompInfoFromStorage();
    private void putDep(java.util.Map<java.lang.String, com.seeyon.boot.starter.i18n.dto.FrontCompInfoDto>, com.seeyon.boot.starter.i18n.dto.FrontCompInfoDto);
    private void loadFrontAppResource(com.seeyon.boot.context.model.AppInfo, java.util.List<java.lang.String>);
    private boolean compListIsChange(java.util.List<java.lang.String>, java.util.List<java.lang.String>);
    private java.util.List<java.lang.String> getFrontAppList(java.lang.String);
    private java.util.Map<java.lang.String, com.seeyon.boot.starter.i18n.dto.FrontResourceInfoDto> readAppMetadataJson(java.lang.String);
    private java.lang.String readJsonByHttp(java.lang.String, java.lang.String);
    private java.lang.String readJsonByFile(java.lang.String, java.lang.String);
    private java.lang.String readJsonForMonolithic(java.lang.String);
    java.lang.String readFrontI18nJson(java.lang.String);
    private java.util.Map<java.lang.String, java.util.Map<java.lang.String, com.seeyon.boot.starter.i18n.dto.I18nResourceDto>> collectFrontAppResourceMap(java.lang.String, java.util.Map<java.lang.String, com.seeyon.boot.starter.i18n.dto.BundleInfoDto>, java.util.Map<java.lang.String, com.seeyon.boot.starter.i18n.dto.FrontResourceInfoDto>);
    private java.util.Map<java.lang.String, java.util.Map<java.lang.String, java.lang.String>> readFrontJsonResource(java.lang.String, java.lang.String, java.lang.String);
    private void collectFrontDyAppResourceMap(java.lang.String, java.lang.String, java.util.Map<java.lang.String, java.util.Map<java.lang.String, com.seeyon.boot.starter.i18n.dto.I18nResourceDto>>);
    private java.util.Map<java.lang.String, com.seeyon.boot.starter.i18n.dto.BundleInfoDto> findAllMenuBundle(java.lang.String, boolean, java.util.Map<java.lang.String, com.seeyon.boot.starter.i18n.dto.BundleInfoDto>);
    private void findAllMenuBundle(java.lang.String, com.seeyon.boot.starter.i18n.dto.BundleInfoDto, java.lang.String, java.util.Map<java.lang.String, java.util.Map<java.lang.String, java.lang.Object>>, java.util.Map<java.lang.String, com.seeyon.boot.starter.i18n.dto.BundleInfoDto>, java.util.Map<java.lang.String, com.seeyon.boot.starter.i18n.dto.BundleInfoDto>);
    void readFrontAppResource(java.util.Map<java.lang.String, java.util.Map<java.lang.String, com.seeyon.boot.starter.i18n.dto.I18nResourceDto>>, java.util.Map<java.lang.String, com.seeyon.boot.starter.i18n.dto.BundleInfoDto>, java.util.Map<java.lang.String, com.seeyon.boot.starter.i18n.dto.BundleInfoDto>, java.util.Map<java.lang.String, java.util.Map<java.lang.String, java.lang.String>>, java.util.Map<java.lang.String, com.seeyon.boot.starter.i18n.dto.I18nResourcePageInfoDto>, java.lang.String, com.seeyon.boot.starter.i18n.dto.FrontResourceInfoDto);
    private void readFrontDyAppResource(java.util.Map<java.lang.String, java.util.Map<java.lang.String, com.seeyon.boot.starter.i18n.dto.I18nResourceDto>>, com.seeyon.boot.starter.i18n.dto.FrontResourceInfoDto, java.util.Map<java.lang.String, java.util.Map<java.lang.String, java.lang.String>>, java.util.Map<java.lang.String, com.seeyon.boot.starter.i18n.dto.I18nResourcePageInfoDto>, java.lang.String, java.lang.String);
    private java.lang.String getPageCode(java.lang.String);
    private java.lang.String getPageResourceKey(java.lang.String, java.lang.String);
    private void saveDefaultI18nResource(java.util.Map<java.lang.String, java.util.Map<java.lang.String, com.seeyon.boot.starter.i18n.dto.I18nResourceDto>>);
    private void saveDefaultI18nResource(java.lang.String, java.util.Map<java.lang.String, com.seeyon.boot.starter.i18n.dto.I18nResourceDto>);
    private java.util.Map<java.lang.String, java.util.Map<java.lang.String, java.util.Map<java.lang.String, java.lang.String>>> getCommonDefaultI18nResource();
    java.util.Map<java.lang.String, com.seeyon.boot.starter.i18n.dto.I18nResourceDto> getDefaultI18nResource(java.lang.String);
    java.util.Map<java.lang.String, java.util.Map<java.lang.String, java.lang.String>> getDefaultI18nResourceForMap(java.lang.String);
    private void setRedisKeyExpire(java.lang.String);
    private void setRedisKeyExpireByDay(int, java.lang.String...);
    private java.lang.Long currentTenantId();
    java.util.Map<java.lang.String, com.seeyon.boot.starter.i18n.dto.I18nResourceDto> getTenantResourceDtoMap(java.lang.String, java.lang.Long);
    java.util.Map<java.lang.String, java.util.Map<java.lang.String, java.lang.String>> getTenantResourceForMap(java.lang.String, java.lang.Long);
    private void saveAppBundleMap(java.lang.String, java.util.Map<java.lang.String, com.seeyon.boot.starter.i18n.dto.BundleInfoDto>);
    void insertFrontAppBundle(java.lang.String, com.seeyon.boot.starter.i18n.dto.BundleInfoDto);
    private void insertFrontAppBundle(java.lang.String, java.util.Map<java.lang.String, com.seeyon.boot.starter.i18n.dto.BundleInfoDto>);
    private void saveStarterBundleMap(java.util.Map<java.lang.String, com.seeyon.boot.context.model.StarterInfo>, java.util.Map<java.lang.String, com.seeyon.boot.starter.i18n.dto.BundleInfoDto>, java.util.Map<java.lang.String, com.seeyon.boot.starter.i18n.dto.BundleInfoDto>);
    private void saveAllSubBundleMap(java.lang.String, java.util.Map<java.lang.String, com.seeyon.boot.starter.i18n.dto.BundleInfoDto>);
    private java.util.Map<java.lang.String, com.seeyon.boot.starter.i18n.dto.BundleInfoDto> getAllSubBundleMap(java.lang.String);
    java.util.Map<java.lang.String, com.seeyon.boot.starter.i18n.dto.BundleInfoDto> getBundleMap(java.lang.String);
    java.util.List<com.seeyon.boot.starter.i18n.dto.BundleInfoDto> getBundleList(java.lang.String, java.lang.String);
    private java.lang.String readJsonFromStorage(java.lang.String);
    private java.lang.String getBundleListFileName(java.lang.String);
    private java.lang.String getDefaultFileName(java.lang.String);
    private java.lang.String getFrontResourceInfoFileName(java.lang.String);
    private void uploadJson(java.lang.String, java.lang.String);
    private java.util.Map<java.lang.String, java.util.Map<java.lang.String, com.seeyon.boot.starter.i18n.dto.I18nResourceDto>> collectAppPropertiesI18nResources(java.lang.String)
    private java.util.Map<java.lang.String, java.util.Map<java.lang.String, com.seeyon.boot.starter.i18n.dto.I18nResourceDto>> collectAppMenuI18nResources(java.lang.String);
    private java.util.Map<java.lang.String, java.util.Map<java.lang.String, com.seeyon.boot.starter.i18n.dto.I18nResourceDto>> collectAppMenuI18nResources(java.lang.String, java.lang.String);
    private java.util.Map<java.lang.String, java.util.Map<java.lang.String, com.seeyon.boot.starter.i18n.dto.I18nResourceDto>> collectAppJsr303I18nResources(java.lang.String);
    private java.util.Map<java.lang.String, java.util.Map<java.lang.String, com.seeyon.boot.starter.i18n.dto.I18nResourceDto>> collectComponentI18nResources(java.util.List<com.seeyon.boot.context.model.StarterInfo>, java.util.List<java.lang.String>)
    private java.util.Map<java.lang.String, com.seeyon.boot.starter.i18n.dto.I18nResourceDto> collectJsr303I18nResource(java.util.List<java.lang.Class>, java.lang.String, java.lang.String, com.seeyon.boot.starter.i18n.enums.ResourceTypeEnum);
    void loadDynamicFrontI18n(java.lang.String, java.lang.String);
    void loadDynamicJarI18n(java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String)
    private com.seeyon.boot.starter.i18n.dto.BundleInfoDto dyAppBundleMap(java.lang.String, java.lang.String, java.lang.String, java.util.List<java.lang.String>);
    private java.util.Map<java.lang.String, com.seeyon.boot.starter.i18n.dto.BundleInfoDto> initBundleTemplateMap();
    void job()
    private boolean isOther(java.lang.String);
    private void putDefaultResourceToMessageRepository(java.util.Map<java.lang.String, java.util.Map<java.lang.String, com.seeyon.boot.starter.i18n.dto.I18nResourceDto>>);
    private void putDefaultResourceToMessageRepositoryMap(java.util.Map<java.lang.String, java.util.Map<java.lang.String, java.util.Map<java.lang.String, java.lang.String>>>);
    java.lang.String getFrontResourceVersion(java.lang.String, boolean);
```

### `I18nResourceUtils`（42 方法）

`com.seeyon.boot.starter.i18n.util.I18nResourceUtils`

```java
    static int compareFrontVersion(java.lang.String, java.lang.String);
    static java.lang.String processFrontVersion(java.lang.String);
    static java.lang.String buildVersion(com.seeyon.boot.context.model.BuildInfo);
    static boolean compareBuildVersion(com.seeyon.boot.context.model.BuildInfo, java.lang.String);
    static java.lang.String jarName(java.lang.String);
    static boolean isJar(java.lang.String);
    static java.util.Map<java.lang.String, com.seeyon.boot.context.model.StarterInfo> starterInfoMap();
    static void jsonToMap(java.util.Map<java.lang.String, java.lang.String>, java.lang.String);
    static java.util.Map<java.lang.String, java.lang.String> jsonToMap(java.lang.String);
    static com.seeyon.boot.starter.i18n.dto.ResourceFileInfo pareFilePath(java.lang.String);
    static java.lang.String getJarResourceBundleName(java.lang.String);
    static void jsonMapToProperties(java.util.Map<java.lang.String, java.lang.String>, java.util.Map<java.lang.String, java.lang.Object>, java.lang.String);
    static java.util.Properties readResourceToProperties(org.springframework.core.io.Resource);
    static java.util.Properties readSteamToProperties(java.io.InputStream);
    static java.lang.String propertiesToJson(java.util.Map<java.lang.String, java.lang.String>);
    static java.util.Map<java.lang.String, java.lang.Object> propertiesToJsonMap(java.util.Map<java.lang.String, java.lang.String>);
    static boolean hasJsr303Annotation(java.lang.reflect.Field);
    static boolean isStarterClass(java.lang.Class);
    static boolean isStarterClass(java.lang.String);
    static java.util.List<org.springframework.core.io.Resource> getI18nResourceByAppName(java.lang.String);
    static java.util.List<org.springframework.core.io.Resource> getExtendI18nResourceByAppName(java.lang.String);
    static java.lang.String getMenuJsonByAppName(java.lang.String);
    static java.util.Map<java.lang.String, java.util.Map<java.lang.String, java.lang.Object>> getMenuMapByAppName(java.lang.String);
    static java.util.Map<java.lang.String, java.util.List<org.springframework.core.io.Resource>> groupStarterResourceList(java.util.Map<java.lang.String, com.seeyon.boot.context.model.StarterInfo>);
    static java.util.Map<java.lang.String, java.util.List<java.lang.Class>> groupStarterDtoList(java.util.Map<java.lang.String, com.seeyon.boot.context.model.StarterInfo>);
    static java.lang.String getStarterResourceBundleName(com.seeyon.boot.context.model.StarterInfo, java.lang.String);
    static java.lang.String getStarterBundleName(com.seeyon.boot.context.model.StarterInfo);
    static java.lang.String getStarterRootBundleName(com.seeyon.boot.context.model.StarterInfo);
    static java.lang.String getStarterRootBundleNameByStarterType(java.lang.String);
    static java.lang.String getAppResourceBundleName(java.lang.String, java.lang.String);
    static java.lang.String getDyAppResourceBundleName(java.lang.String, java.lang.String, java.lang.String);
    static void setEnumsParent(java.util.Map<java.lang.String, com.seeyon.boot.starter.i18n.dto.I18nResourceDto>);
    static java.util.Map<java.lang.String, java.lang.String> resourceToStrMap(java.util.Map<java.lang.String, com.seeyon.boot.starter.i18n.dto.I18nResourceDto>);
    static boolean isReWriteRedis(java.util.Map<java.lang.String, ?>);
    static java.util.Map<java.lang.String, com.seeyon.boot.starter.i18n.dto.I18nResourceDto> setTempI18nResourceDto(java.util.Map<java.lang.String, com.seeyon.boot.starter.i18n.dto.I18nResourceDto>);
    static void removeTempI18nResourceDto(java.util.Map<java.lang.String, ?>);
    static java.lang.String toJson(java.lang.Object);
    static java.util.Map toMap(java.lang.String);
    static <T> java.util.List<T> readAllFrontCompI18nJsonList(java.lang.String, java.lang.Class<T>);
    static <T> java.util.List<T> readAppFrontCompI18nJsonList(java.lang.String, java.lang.Class<T>);
    static java.lang.String compI18nJson(java.lang.Object);
    static <T> T appI18nJsonToBean(java.lang.String, java.lang.Class<T>);
```

### `I18nLocaleService`（13 方法）

`com.seeyon.boot.starter.i18n.I18nLocaleService`

```java
    java.util.Map<java.lang.String, java.lang.String> getSystemEnableLocalesMap();
    java.util.Map<java.lang.String, java.lang.String> getTenantEnableLocalesMap();
    java.util.Locale getSystemDefaultLocale();
    java.util.Locale getTenantDefaultLocale();
    void invalidateLocaleCache(java.lang.Long);
    java.util.List<java.util.Map<java.lang.String, java.lang.String>> getSystemDataI18nLocaleList();
    java.util.List<java.util.Map<java.lang.String, java.lang.String>> getTenantDataI18nLocaleList();
    private java.util.Locale getDefaultLocale(java.lang.Long);
    private java.util.Map<java.lang.String, java.lang.String> getEnableLocalesMap(java.lang.Long);
    private java.util.Map<java.lang.String, java.lang.String> getLocales(java.lang.Long);
    protected void syncLocales();
```

### `DataI18nUtils`（3 方法）

`com.seeyon.boot.starter.i18n.util.DataI18nUtils`

```java
    static java.lang.String getCurrentLocaleStr(java.lang.String);
    static java.lang.String getSpecifyLocaleStr(java.lang.String, java.util.Locale);
    static java.lang.String getSpecifyLocaleStr(java.lang.String, java.lang.String);
```

## 四、枚举（2）

- `ResourceTypeEnum`（6 常量）：APP, DY_APP, BASE_COMP, BIZ_COMP, FRONT_CONTROL, FRONT_BIZ_COMP
- `ResourceUseTypeEnum`（3 常量）：COMMON, PC, MOBILE
