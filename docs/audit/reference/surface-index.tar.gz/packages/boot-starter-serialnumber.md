# boot-starter-serialnumber：接口与方法签名

> 自动生成，勿手改。`tools/core/platform/emit_package_surfaces.py` 重跑即可。
> 构件 `com.seeyon:boot-starter-serialnumber`（jar `boot-starter-serialnumber-5.3.603.jar`）
> 规模：85 类 / 6 接口 / 0 注解 / 6 枚举 / 18 个关键类 / 874 方法。
> 签名逐字来自 javap 原文；已去掉 `public` 前缀与 `throws` 子句。

## 一、接口（6）

### `SerialRangeDao`（4 方法） extends SerialRange>

`com.seeyon.boot.starter.serialnumber.domain.dao.SerialRangeDao`

```java
    int deleteValue(java.lang.String, java.lang.Long);
    int deleteRange(java.lang.String);
    int incrementStartValue(java.lang.String, java.lang.Long, java.lang.Long, java.util.Date);
    java.util.List<com.seeyon.boot.starter.serialnumber.domain.entity.SerialRange> exist(java.lang.String, java.lang.Long);
```

### `SerialCurrentDao`（1 方法） extends SerialCurrent>

`com.seeyon.boot.starter.serialnumber.domain.dao.SerialCurrentDao`

```java
    int updateValue(java.lang.String, java.lang.Long, java.util.Date, java.lang.Long);
```

### `SerialSchemeDao`（1 方法） extends SerialScheme>

`com.seeyon.boot.starter.serialnumber.domain.dao.SerialSchemeDao`

```java
    java.lang.Integer getMaxSortNumByAppId(java.lang.String);
```

### `SerialSectionDao`（1 方法） extends SerialSection>

`com.seeyon.boot.starter.serialnumber.domain.dao.SerialSectionDao`

```java
    int updateSerialCurrent(java.lang.Long, java.util.Date, java.lang.Long);
```

### `SerialConditionDao`（0 方法） extends SerialCondition>

`com.seeyon.boot.starter.serialnumber.domain.dao.SerialConditionDao`

```java
```

### `SerialHistoryDao`（0 方法） extends SerialHistory>

`com.seeyon.boot.starter.serialnumber.domain.dao.SerialHistoryDao`

```java
```

## 二、关键类（18）

### `SerialSchemeService`（41 方法）

`com.seeyon.boot.starter.serialnumber.domain.service.SerialSchemeService`

```java
    com.google.common.cache.LoadingCache<java.lang.String, com.seeyon.boot.starter.serialnumber.domain.dto.SerialSchemeDto> getSchemeInstanceCache();
    void initSerialSchemeInMonolithic(com.seeyon.boot.starter.serialnumber.domain.entity.SerialScheme)
    java.lang.Long create(com.seeyon.boot.starter.serialnumber.domain.dto.SerialSchemeDto);
    java.lang.Integer schemeCopy(com.seeyon.boot.starter.serialnumber.domain.dto.SerialSchemeCopyDto);
    java.lang.Long createEasyScheme(com.seeyon.boot.starter.serialnumber.domain.dto.SerialEasySchemeDto);
    java.lang.Integer update(com.seeyon.boot.starter.serialnumber.domain.dto.SerialSchemeDto);
    java.lang.String getIncrKey(java.lang.Long, java.util.Map);
    java.lang.Integer getMaxSortNumByAppId(java.lang.String);
    java.lang.Integer updateActive(com.seeyon.boot.starter.serialnumber.domain.dto.SerialSchemeActiveDto);
    java.lang.Integer updatePresetBatch(java.util.Map<java.lang.String, java.lang.Object>);
    java.lang.Integer deleteById(java.lang.Long);
    java.lang.Integer deleteByIds(java.util.List<java.lang.Long>);
    java.lang.Integer runTimeDeleteById(java.lang.Long);
    com.seeyon.boot.starter.serialnumber.domain.dto.SerialSchemeDto selectById(java.lang.Long);
    com.seeyon.boot.starter.serialnumber.domain.dto.SerialSchemeDto selectByIdNoCache(java.lang.Long);
    com.seeyon.boot.starter.serialnumber.domain.dto.SerialSchemeDto selectByGuid(java.lang.Long);
    com.seeyon.boot.starter.serialnumber.domain.dto.SerialSchemeDto selectByCodeAndAppId(java.lang.String, java.lang.String);
    java.util.List<com.seeyon.boot.starter.serialnumber.domain.entity.SerialScheme> selectByAppId(java.lang.String);
    java.util.List<com.seeyon.boot.starter.serialnumber.domain.dto.SerialSchemeDto> selectByIds(java.util.List<java.lang.Long>);
    java.util.List<com.seeyon.boot.starter.serialnumber.domain.dto.SerialSchemeDto> invokeSelectCommonByGuIds(java.util.List<java.lang.Long>);
    java.util.List<com.seeyon.boot.starter.serialnumber.domain.dto.SerialSchemeDto> selectByCode(java.lang.String);
    com.seeyon.boot.starter.serialnumber.domain.dto.SerialSchemeDto selectByCodeAndAppGuid(java.lang.String, java.lang.String);
    private void putSections2SchemaDto(com.seeyon.boot.starter.serialnumber.domain.dto.SerialSchemeDto, boolean);
    private void putSections2SchemaDtoSelectAllFlag(com.seeyon.boot.starter.serialnumber.domain.dto.SerialSchemeDto);
    com.seeyon.boot.transport.PageData<com.seeyon.boot.starter.serialnumber.domain.dto.SerialSchemeDto> selectPageByCondition(com.seeyon.boot.transport.PageInfo, java.util.Map<java.lang.String, java.lang.Object>, com.seeyon.boot.transport.Sort);
    java.util.List<com.seeyon.boot.starter.serialnumber.domain.dto.SerialSchemeDto> selectListByConditions(java.util.Map<java.lang.String, java.lang.Object>, com.seeyon.boot.transport.Sort);
    private void checkDto4Create(com.seeyon.boot.starter.serialnumber.domain.dto.SerialSchemeDto);
    private void checkDto4Update(com.seeyon.boot.starter.serialnumber.domain.dto.SerialSchemeDto);
    void increaseSerialSectionCurrentValue(java.lang.Long);
    private void checkCodeUnique(com.seeyon.boot.starter.serialnumber.domain.dto.SerialSchemeDto);
    java.lang.Long previewSerialValue(com.seeyon.boot.starter.serialnumber.domain.dto.SerialSchemeDto, java.lang.Long);
    private void evictSerialSchemeCache(com.seeyon.boot.starter.serialnumber.domain.dto.SerialSchemeDto);
    java.util.List<com.seeyon.boot.starter.serialnumber.domain.dto.SerialSchemeDto> selectByAppGuid(java.lang.String);
    com.seeyon.boot.transport.PageData<com.seeyon.boot.starter.serialnumber.domain.dto.SerialSchemeDto> selectPageByEntityFullName(com.seeyon.boot.transport.PageInfo, java.util.Map<java.lang.String, java.lang.Object>, com.seeyon.boot.transport.Sort);
    private java.util.List<java.lang.Object> getEntityFieldBySerialId(java.lang.Long, java.lang.String);
    private void operationLog(java.lang.String, com.seeyon.boot.starter.serialnumber.domain.dto.SerialSchemeDto, com.seeyon.boot.starter.serialnumber.domain.dto.SerialSchemeDto);
```

### `SerialCurrentService`（33 方法）

`com.seeyon.boot.starter.serialnumber.domain.service.SerialCurrentService`

```java
    java.lang.Long incrementSerialCurrent(java.lang.String, java.lang.Long, java.lang.Long, java.lang.Long, java.util.Map<java.lang.String, java.lang.String>);
    java.lang.Long incrementSerialCache(java.lang.String, java.lang.Long, java.lang.Long, java.lang.Long, java.util.Map<java.lang.String, java.lang.String>);
    java.util.List<java.lang.Long> batchIncrementSerialCache(java.util.List<java.lang.Long>, com.seeyon.boot.starter.serialnumber.domain.dto.SerialNumberDataDto, java.lang.Long);
    void incrementSerialForUnUseNumber(java.lang.Long, java.lang.String, java.lang.Long, java.util.Map<java.lang.String, java.lang.String>);
    java.lang.Long preInitListUnUserNumIncrement(java.lang.String, java.lang.Long, java.lang.Long);
    java.lang.Long getAndIncrement(java.lang.String, java.lang.String, java.lang.Long, java.lang.Long);
    int updateCurrentValue(com.seeyon.boot.starter.serialnumber.domain.event.SerialCurrentEventDto);
    java.lang.Long incrementSerialDb(java.lang.String, java.lang.Long);
    java.lang.Long previewSerialValueCache(java.lang.String, java.lang.Long);
    java.lang.Long previewSerialValueDb(java.lang.String);
    java.util.List<com.seeyon.boot.starter.serialnumber.domain.dto.SerialCurrentDto> selectListByConditions(java.util.Map<java.lang.String, java.lang.Object>, com.seeyon.boot.transport.Sort);
    com.seeyon.boot.starter.serialnumber.domain.entity.SerialCurrent selectCurrentByIncrKey(java.lang.String);
    java.lang.Long selectCurrentValueByIncrKey(java.lang.String, java.lang.Long);
    java.lang.Long createOrUpdateSerialCurrent(com.seeyon.boot.starter.serialnumber.domain.dto.SerialCurrentDto);
    com.seeyon.boot.transport.PageData<com.seeyon.boot.starter.serialnumber.domain.dto.SerialCurrentDto> selectPageByConditions(com.seeyon.boot.transport.PageInfo, java.util.Map<java.lang.String, java.lang.Object>, com.seeyon.boot.transport.Sort);
    void handleCurrentQueueData(java.util.List<com.seeyon.boot.starter.serialnumber.domain.event.SerialCurrentEventDto>);
    java.lang.Boolean recoverSerialNumber(java.util.List<java.lang.Long>);
    java.lang.Integer setNoRecoverSerialNumber(java.util.List<java.lang.Long>);
    void handleRecoverTask(java.util.List<java.lang.Long>);
    java.lang.Object pushAndSort(java.lang.String, java.util.List<java.lang.String>);
    void invokeRecoverSerialNumberForUdc(java.util.List<java.lang.Long>);
    int getOrder();
    void run();
```

### `SerialNumberService`（30 方法）

`com.seeyon.boot.starter.serialnumber.domain.service.SerialNumberService`

```java
    java.lang.String getSerialNumberByCondition(com.seeyon.boot.starter.serialnumber.domain.dto.SerialNumberConditionDto);
    java.lang.String getSerialNumber(com.seeyon.boot.starter.serialnumber.domain.dto.SerialNumberDto);
    java.lang.String previewSerialNumber(com.seeyon.boot.starter.serialnumber.domain.dto.SerialNumberDto);
    java.util.List<java.lang.String> batchSerialNumber(com.seeyon.boot.starter.serialnumber.domain.dto.SerialNumberBatchDto);
    java.lang.String getSerialNumberByCache(com.seeyon.boot.starter.serialnumber.domain.dto.SerialNumberDataDto, com.seeyon.boot.starter.serialnumber.domain.dto.SerialSchemeDto, com.seeyon.boot.starter.serialnumber.domain.dto.SerialSectionDto, java.lang.Boolean, int);
    private void limitCheck(com.seeyon.boot.starter.serialnumber.domain.dto.SerialSectionDto, java.lang.String, java.lang.String);
    java.lang.String getCurrentNumberByInitCache(java.lang.Long, java.lang.String);
    java.lang.String getSerialNumber(com.seeyon.boot.starter.serialnumber.domain.dto.SerialSchemeDto, java.util.Map<java.lang.String, java.lang.Object>, java.lang.Boolean);
    java.lang.String getSerialNumberForUdc(com.seeyon.boot.starter.serialnumber.domain.dto.SerialSchemeExtendDto);
    java.lang.String invokeGetSerialNumberForUdc(com.seeyon.boot.starter.serialnumber.domain.dto.SerialSchemeExtendDto);
    com.seeyon.boot.starter.serialnumber.domain.dto.SerialNumberDataDto getSerialNumberDataDto(com.seeyon.boot.starter.serialnumber.domain.dto.SerialSchemeDto, java.util.Map<java.lang.String, java.lang.Object>);
    private com.seeyon.boot.starter.serialnumber.domain.dto.SerialSectionDto getSerialTypeSectionDto(com.seeyon.boot.starter.serialnumber.domain.dto.SerialSchemeDto, com.seeyon.boot.starter.serialnumber.domain.dto.SerialNumberDataDto);
    com.seeyon.boot.starter.serialnumber.domain.dto.SerialSchemeDto getSerialSchemeDto(com.seeyon.boot.starter.serialnumber.domain.dto.SerialNumberDto);
    com.seeyon.boot.starter.serialnumber.domain.dto.SerialNumberDataDto getSerialValueTemplate(com.seeyon.boot.starter.serialnumber.domain.dto.SerialSchemeDto, java.util.Map<java.lang.String, java.lang.Object>, java.util.Map<java.lang.String, com.seeyon.ctp.metadata.dto.EntityAttributeMetadataDto>);
    private java.lang.String getVariableValue(com.seeyon.boot.starter.serialnumber.domain.dto.SerialSchemeDto, java.util.Map<java.lang.String, java.lang.Object>, java.util.Map<java.lang.String, com.seeyon.ctp.metadata.dto.EntityAttributeMetadataDto>, com.seeyon.boot.starter.serialnumber.domain.dto.SerialSectionDto);
    private java.util.List<java.lang.Long> batchSerialNumberSerialValue(com.seeyon.boot.starter.serialnumber.domain.dto.SerialNumberDataDto, com.seeyon.boot.starter.serialnumber.domain.dto.SerialSchemeDto, com.seeyon.boot.starter.serialnumber.domain.dto.SerialSectionDto, java.lang.Integer);
    void preInitSerialNumber(com.seeyon.boot.starter.serialnumber.domain.dto.SerialNumberDataDto, com.seeyon.boot.starter.serialnumber.domain.dto.SerialSchemeDto, java.lang.String);
    void preProductNumber(java.lang.String, java.lang.String, java.lang.Integer, java.lang.String, java.lang.Long);
    java.lang.Long consumeUnusedSerialNumber(java.lang.String);
    org.apache.commons.lang3.tuple.Pair<java.util.List<java.lang.Long>, java.lang.Integer> consumeUnusedSerialNumber(java.lang.String, java.lang.Integer);
    java.lang.Boolean produceUnusedSerialNumber(java.lang.String, java.lang.Long, java.lang.Long);
    java.lang.Boolean delUnusedSerialNumber(java.lang.String, java.lang.Long);
    java.lang.Boolean updateSerialNumber(com.seeyon.boot.starter.serialnumber.domain.dto.SerialUpdateNumberDto);
    java.lang.Boolean resetSerialNumber(com.seeyon.boot.starter.serialnumber.domain.dto.SerialResetDto);
    private void resetCurrent(com.seeyon.boot.starter.serialnumber.domain.dto.SerialResetDto, com.seeyon.boot.starter.serialnumber.domain.dto.SerialSchemeDto, com.seeyon.boot.starter.serialnumber.domain.entity.SerialCurrent);
    java.lang.Boolean resetSerialNumberByAppId(java.lang.String);
    com.seeyon.boot.starter.serialnumber.domain.entity.SerialSection getSerialSection(java.lang.Long);
    java.util.List<com.seeyon.boot.starter.serialnumber.domain.entity.SerialSection> getSectionBySerialSchemeId(java.lang.Long, int);
    java.util.List<com.seeyon.boot.starter.serialnumber.domain.entity.SerialSection> getSectionBySerialSchemeIs(java.util.List<java.lang.Long>, int);
    void recoveryUnusedSerial(com.seeyon.boot.starter.serialnumber.domain.dto.UnusedRecoverSerialDto);
```

### `SerialRangeService`（23 方法）

`com.seeyon.boot.starter.serialnumber.domain.service.SerialRangeService`

```java
    java.lang.Long create(com.seeyon.boot.starter.serialnumber.domain.dto.SerialRangeDto);
    private void checkRangeRepeat(com.seeyon.boot.starter.serialnumber.domain.dto.SerialRangeDto, boolean);
    java.lang.Integer recoverNumber(com.seeyon.boot.starter.serialnumber.domain.dto.SerialNumberRecoverDto);
    java.lang.Long createUnused(com.seeyon.boot.starter.serialnumber.domain.dto.SerialRangeUnusedDto);
    private java.lang.Boolean checkRangeExist(com.seeyon.boot.starter.serialnumber.domain.dto.SerialRangeUnusedDto);
    java.lang.Long createBatchUnused(com.seeyon.boot.starter.serialnumber.domain.dto.SerialRangeBatchUnusedDto);
    int update(com.seeyon.boot.starter.serialnumber.domain.dto.SerialRangeDto);
    int updateForbiddenFlag(com.seeyon.boot.starter.serialnumber.domain.dto.SerialRange4ForbiddenDto);
    int deleteById(java.lang.Long);
    int deleteBySerialSchemeId(java.lang.Long);
    int deleteBySerialSchemeIdAndCurrentId(java.lang.Long, java.lang.String);
    java.lang.Integer deleteByIds(java.util.List<java.lang.Long>);
    com.seeyon.boot.starter.serialnumber.domain.dto.SerialRangeDto selectById(java.lang.Long);
    int delRangeByIncrKey(java.lang.String, java.lang.Long);
    int delRangeBySerialSchemeId(java.lang.String);
    com.seeyon.boot.transport.PageData<com.seeyon.boot.starter.serialnumber.domain.dto.SerialRangeDto> selectPageByConditions(com.seeyon.boot.transport.PageInfo, java.util.Map<java.lang.String, java.lang.Object>, com.seeyon.boot.transport.Sort);
    void checkColumnMap(java.util.Map<java.lang.String, java.lang.Object>);
    java.util.List<com.seeyon.boot.starter.serialnumber.domain.dto.SerialRangeDto> selectListByConditions(java.util.Map<java.lang.String, java.lang.Object>, com.seeyon.boot.transport.Sort);
    private void checkDto(com.seeyon.boot.starter.serialnumber.domain.dto.SerialRangeDto);
    java.lang.Long createUnusedBySerialNumber(com.seeyon.boot.starter.serialnumber.domain.dto.SerialNumberUnusedDto);
    java.lang.String getSerialRangeUnUseNumber(java.lang.String, java.lang.Long);
```

### `SerialSchemaExtendService`（22 方法）

`com.seeyon.boot.starter.serialnumber.api.SerialSchemaExtendService`

```java
    java.lang.Object serialBeforeCreate(com.seeyon.boot.starter.serialnumber.api.dto.SerialBeforeCreateDto<org.apache.poi.ss.formula.functions.T>);
    private void handleSerialNumber(java.util.List<com.seeyon.boot.starter.serialnumber.api.dto.SerialEntityAttributeDto>, java.lang.Object);
    private void setSerialValueToCreate(com.seeyon.boot.starter.serialnumber.domain.dto.SerialSchemeExtendDto, java.lang.Object, java.lang.String);
    private java.lang.String buildCreateSerialNumber(com.seeyon.boot.starter.serialnumber.domain.dto.SerialSchemeExtendDto, java.lang.String, java.lang.Object);
    java.lang.Object serialBeforeUpdate(com.seeyon.boot.starter.serialnumber.api.dto.SerialBeforeUpdateDto<org.apache.poi.ss.formula.functions.T>);
    private void setSerialValueToUpdate(java.lang.Object, java.lang.Object, java.lang.Object, com.seeyon.boot.starter.serialnumber.domain.dto.SerialSchemeDto, java.lang.String);
    private java.lang.String buildUpdateSerialNumber(java.lang.Object, java.util.Map<java.lang.String, java.lang.Object>, java.lang.Object, com.seeyon.boot.starter.serialnumber.domain.dto.SerialSchemeDto, java.lang.String);
    private java.util.List<com.seeyon.boot.starter.serialnumber.domain.dto.SerialSchemeDto> getSerialSchemeDtoList(java.util.List<com.seeyon.boot.starter.serialnumber.api.dto.SerialEntityAttributeDto>);
    private com.seeyon.boot.starter.serialnumber.domain.dto.SerialSchemeDto checkAndGetSerial(com.seeyon.boot.starter.serialnumber.api.dto.SerialEntityAttributeDto, java.util.List<com.seeyon.boot.starter.serialnumber.domain.dto.SerialSchemeDto>);
    static private static java.lang.Object getRunObj(java.lang.Object, java.lang.String, int);
    static private static java.lang.Object getObject(java.lang.Object, int, java.util.List<java.lang.String>)
    private void setProperty(java.lang.Object, java.lang.String, java.lang.String, int);
    private java.lang.String getSingleName(java.lang.String);
    private java.lang.String parseEntityFullName(java.lang.Object);
```

### `SerialSchemeAppService`（17 方法）

`com.seeyon.boot.starter.serialnumber.appservice.SerialSchemeAppService`

```java
    com.seeyon.boot.transport.SingleResponse<java.lang.Long> create(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.serialnumber.domain.dto.SerialSchemeDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Long> createEasyScheme(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.serialnumber.domain.dto.SerialEasySchemeDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> update(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.serialnumber.domain.dto.SerialSchemeDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> updateActive(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.serialnumber.domain.dto.SerialSchemeActiveDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> updatePresetBatch(com.seeyon.boot.transport.ListRequest);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> deleteById(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> runTimeDeleteById(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> deleteByIds(com.seeyon.boot.transport.SingleRequest<java.util.List<java.lang.Long>>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.boot.starter.serialnumber.domain.dto.SerialSchemeDto> selectById(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.boot.starter.serialnumber.domain.dto.SerialSchemeDto> selectByIds(com.seeyon.boot.transport.SingleRequest<java.util.List<java.lang.Long>>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.boot.starter.serialnumber.domain.dto.SerialSchemeDto> selectByCode(com.seeyon.boot.transport.SingleRequest<java.lang.String>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> getMaxSortNumByAppId(com.seeyon.boot.transport.SingleRequest<java.lang.String>);
    com.seeyon.boot.transport.PageResponse<com.seeyon.boot.starter.serialnumber.domain.dto.SerialSchemeDto> selectPageByCondition(com.seeyon.boot.transport.PageRequest);
    com.seeyon.boot.transport.ListResponse<com.seeyon.boot.starter.serialnumber.domain.dto.SerialSchemeDto> selectListByConditions(com.seeyon.boot.transport.ListRequest);
    com.seeyon.boot.transport.ListResponse<com.seeyon.boot.starter.serialnumber.domain.dto.SerialSchemeDto> selectByAppGuid(com.seeyon.boot.transport.SingleRequest<java.lang.String>);
    com.seeyon.boot.transport.PageResponse<com.seeyon.boot.starter.serialnumber.domain.dto.SerialSchemeDto> selectPageByEntityFullName(com.seeyon.boot.transport.PageRequest);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> schemeCopy(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.serialnumber.domain.dto.SerialSchemeCopyDto>);
```

### `SerialNumberUtil`（17 方法）

`com.seeyon.boot.starter.serialnumber.utils.SerialNumberUtil`

```java
    static java.lang.String getSerialSchemePrefixKey(java.lang.String, java.lang.String);
    static java.lang.String getPreProdSerialNumberKey(java.lang.Long, java.lang.String);
    static java.lang.String getSerialNumberUnusedKey();
    static java.lang.String getSerialNumberHistoryKey();
    static java.lang.String getSerialNumberHistoryHashKey(java.lang.Long, java.lang.String);
    static java.lang.String getNewKey(java.lang.Long, java.lang.String);
    static java.lang.String getIncrKey(com.seeyon.boot.starter.serialnumber.domain.dto.SerialSchemeDto, java.util.Map<java.lang.String, java.lang.Object>);
    static java.util.List<com.seeyon.boot.starter.formula.dto.preset.SystemPresetVariableDto> getListSystemVariable();
    static void initOldContext(com.seeyon.boot.starter.serialnumber.domain.dto.SerialSchemeDto, java.util.Map<java.lang.String, java.lang.Object>);
    static java.lang.String getVariableValue(com.seeyon.boot.starter.serialnumber.domain.dto.SerialSchemeDto, com.seeyon.boot.starter.serialnumber.domain.dto.SerialSectionDto, java.util.Map<java.lang.String, java.lang.Object>);
    static private static java.lang.String dateVariable(java.util.Date, java.lang.String);
    static java.lang.String redisKeyAddTenantId(java.lang.String);
    static java.lang.String resolveSerialNumber(java.lang.String, com.seeyon.boot.starter.serialnumber.domain.dto.SerialSectionDto);
    static java.lang.String fillIn(java.lang.String, com.seeyon.boot.starter.serialnumber.domain.dto.SerialSectionDto);
    static long getSerialNumberMaxValue(com.seeyon.boot.starter.serialnumber.domain.dto.SerialSectionDto);
    static java.lang.String fullNameToAppName(java.lang.String);
```

### `SerialConditionService`（16 方法）

`com.seeyon.boot.starter.serialnumber.domain.service.SerialConditionService`

```java
    java.lang.Integer batchCreateSerialCondition(com.seeyon.boot.starter.serialnumber.domain.dto.SerialConditionBatchCreateDto);
    java.lang.Integer delSerialConditionBySchemeId(java.lang.Long);
    java.lang.Boolean evalConditionExpression(java.lang.Long, boolean, java.util.Map<java.lang.String, java.lang.Object>);
    private java.lang.Boolean checkExpression(java.lang.String, java.util.Map<java.lang.String, java.lang.Object>);
    java.lang.Integer delSerialConditionById(java.lang.Long);
    java.util.List<com.seeyon.boot.starter.serialnumber.domain.dto.SerialConditionDto> selectSerialConditionDtoListBySchemeId(java.lang.Long);
    private java.util.List<com.seeyon.boot.starter.serialnumber.domain.entity.SerialCondition> selectSerialConditionListBySchemeId(java.lang.Long);
    private com.seeyon.boot.starter.serialnumber.domain.entity.SerialCondition selectSerialConditionBySchemeId(java.lang.Long, java.lang.String);
    java.lang.Boolean evalCreateExpression(java.lang.Long, java.lang.String, java.util.Map<java.lang.String, java.lang.Object>);
    java.lang.Boolean evalCreateExpression(com.seeyon.boot.starter.serialnumber.domain.dto.SerialConditionDto, java.util.Map<java.lang.String, java.lang.Object>);
    java.lang.Boolean evalReleaseExpression(java.lang.Long, java.lang.String, java.util.Map<java.lang.String, java.lang.Object>);
    java.lang.Boolean evalReleaseExpression(com.seeyon.boot.starter.serialnumber.domain.dto.SerialConditionDto, java.util.Map<java.lang.String, java.lang.Object>);
    private void removeSerialConditionLocalCache(java.lang.Long);
```

### `SerialSchemeUpgradeService`（14 方法）

`com.seeyon.boot.starter.serialnumber.domain.upgrade.SerialSchemeUpgradeService`

```java
    int getOrder();
    void run();
    void upgradeIncrKeyPre(java.lang.String);
    private java.lang.String getCompleteCacheKeyWithoutAppName(java.lang.Long, java.lang.String, java.lang.String);
    void upgradeRedisInitNumber(java.lang.Long);
    void upgradeRedisInitNumberV1(java.lang.String);
    static java.lang.String getPreProdSerialNumberKey(java.lang.Long, java.lang.String, java.lang.Long);
    static java.lang.String removeStrBeginZero(java.lang.String);
    void upgradeIncrKeyFor0730();
    void upgradeIncrKeyFor260To310();
```

### `SerialNumberAppService`（13 方法）

`com.seeyon.boot.starter.serialnumber.appservice.SerialNumberAppService`

```java
    com.seeyon.boot.transport.SingleResponse<java.lang.String> getSerialNumberByCondition(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.serialnumber.domain.dto.SerialNumberConditionDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.String> getSerialNumber(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.serialnumber.domain.dto.SerialNumberDto>);
    com.seeyon.boot.transport.ListResponse<java.lang.String> batchSerialNumber(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.serialnumber.domain.dto.SerialNumberBatchDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.String> previewSerialNumber(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.serialnumber.domain.dto.SerialNumberDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Long> createOrUpdateSerialCurrent(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.serialnumber.domain.dto.SerialCurrentDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.boot.starter.serialnumber.domain.dto.SerialCurrentDto> selectListByConditions(com.seeyon.boot.transport.ListRequest);
    com.seeyon.boot.transport.PageResponse<com.seeyon.boot.starter.serialnumber.domain.dto.SerialCurrentDto> selectPageByCondition(com.seeyon.boot.transport.PageRequest);
    com.seeyon.boot.transport.SingleResponse<java.lang.Boolean> updateSerialNumber(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.serialnumber.domain.dto.SerialUpdateNumberDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Boolean> resetSerialNumber(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.serialnumber.domain.dto.SerialResetDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Boolean> resetSerialNumberByAppId(com.seeyon.boot.transport.SingleRequest<java.lang.String>);
    com.seeyon.boot.transport.SingleResponse<java.lang.String> getSerialNumberForUdc(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.serialnumber.domain.dto.SerialSchemeExtendDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Boolean> recoverSerialNumber(com.seeyon.boot.transport.SingleRequest<java.util.List<java.lang.Long>>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> setNoRecoverSerialNumber(com.seeyon.boot.transport.SingleRequest<java.util.List<java.lang.Long>>);
```

### `SerialConditionExpFieldHandler`（13 方法）

`com.seeyon.boot.starter.serialnumber.migration.SerialConditionExpFieldHandler`

```java
    boolean supports(java.lang.Class<?>);
    <T extends com.seeyon.boot.domain.entity.BaseEntity> void processQueryData(com.seeyon.boot.starter.configmigration.core.context.ExecutionContext, T);
    <T extends com.seeyon.boot.domain.entity.BaseEntity> void processBeforeReplaceData(com.seeyon.boot.starter.configmigration.core.context.ExecutionContext, T);
    <T extends com.seeyon.boot.domain.entity.BaseEntity> void processReplaceData(com.seeyon.boot.starter.configmigration.core.context.ExecutionContext, T);
    <T extends com.seeyon.boot.domain.entity.BaseEntity> void processAfterReplaceData(com.seeyon.boot.starter.configmigration.core.context.ExecutionContext, T);
    private java.util.List<com.seeyon.boot.starter.configmigration.dto.DelegateRelationDataDto> tokenConvertRelationMetaInfo(java.lang.String);
```

### `SerialRangeAppService`（12 方法）

`com.seeyon.boot.starter.serialnumber.appservice.SerialRangeAppService`

```java
    com.seeyon.boot.transport.SingleResponse<java.lang.Long> create(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.serialnumber.domain.dto.SerialRangeDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Long> createUnused(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.serialnumber.domain.dto.SerialRangeUnusedDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> recoverNumber(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.serialnumber.domain.dto.SerialNumberRecoverDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Long> createBatchUnused(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.serialnumber.domain.dto.SerialRangeBatchUnusedDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> update(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.serialnumber.domain.dto.SerialRangeDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> updateForbiddenFlag(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.serialnumber.domain.dto.SerialRange4ForbiddenDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> deleteById(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> deleteByIds(com.seeyon.boot.transport.SingleRequest<java.util.List<java.lang.Long>>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.boot.starter.serialnumber.domain.dto.SerialRangeDto> selectById(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.PageResponse<com.seeyon.boot.starter.serialnumber.domain.dto.SerialRangeDto> selectPageByCondition(com.seeyon.boot.transport.PageRequest);
    com.seeyon.boot.transport.ListResponse<com.seeyon.boot.starter.serialnumber.domain.dto.SerialRangeDto> selectListByConditions(com.seeyon.boot.transport.ListRequest);
    com.seeyon.boot.transport.SingleResponse<java.lang.Long> createUnusedBySerialNumber(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.serialnumber.domain.dto.SerialNumberUnusedDto>);
```

### `SerialEnumService`（9 方法）

`com.seeyon.boot.starter.serialnumber.domain.service.SerialEnumService`

```java
    java.lang.String getAppEnumNameItemsByIds(java.lang.String, java.util.List<java.lang.Long>);
    java.lang.String getAppName(java.lang.String);
    java.lang.String getJavaEnumMetadataByName(java.lang.String, java.lang.String, java.lang.String);
    java.util.Map<java.lang.String, com.seeyon.ctp.metadata.dto.EntityAttributeMetadataDto> getEntityAttributes(com.seeyon.boot.starter.serialnumber.domain.dto.SerialSchemeDto);
    static private static void reflexInvokeSerialConfigForEntityFullName(com.seeyon.boot.starter.serialnumber.domain.dto.SerialSchemeDto);
    private boolean existEntitySection(com.seeyon.boot.starter.serialnumber.domain.dto.SerialSchemeDto);
    private com.seeyon.ctp.metadata.dto.EntityMetadataDto getEntityMetadataDto(java.lang.String, java.lang.String);
    private java.lang.String entityFullName(java.lang.String, java.lang.String);
```

### `SerialRedisCacheUtil`（9 方法）

`com.seeyon.boot.starter.serialnumber.utils.SerialRedisCacheUtil`

```java
    void put(java.lang.String, java.lang.Object);
    java.lang.Object get(java.lang.String);
    java.lang.Long putList(java.lang.String, java.util.List<java.lang.Long>);
    java.util.List<java.lang.Long> getList(java.lang.String);
    void hashPut(java.lang.String, java.lang.String, java.lang.Object);
    java.lang.Object hashGet(java.lang.String, java.lang.String);
    boolean isExists(java.lang.String, java.lang.String);
    void add(java.lang.String, java.lang.String);
    void batchAdd(java.lang.String, java.util.List<java.lang.Long>);
```

### `SerialInitService`（6 方法）

`com.seeyon.boot.starter.serialnumber.domain.service.SerialInitService`

```java
    void run();
    void initAllSerialNumber();
    void initAllSerialCurrent();
    void initSerialNumberCore(java.util.List<com.seeyon.boot.starter.serialnumber.domain.entity.SerialRange>);
    void initSerialCurrentCore(java.util.List<com.seeyon.boot.starter.serialnumber.domain.entity.SerialCurrent>, java.lang.String);
    int getOrder();
```

### `SerialQueueTaskService`（6 方法）

`com.seeyon.boot.starter.serialnumber.domain.task.SerialQueueTaskService`

```java
    void add(com.seeyon.boot.starter.serialnumber.domain.event.SerialCurrentEventDto);
    void add(com.seeyon.boot.starter.serialnumber.api.dto.SerialNumberRecoverEvent);
    com.seeyon.boot.starter.serialnumber.domain.service.SerialCurrentService getSerialCurrentService();
    com.seeyon.boot.starter.serialnumber.utils.SerialRedisCacheUtil getSerialRedisCacheUtil();
    java.util.concurrent.LinkedBlockingQueue<com.seeyon.boot.starter.serialnumber.domain.event.SerialCurrentEventDto> getTaskQueue();
    java.util.concurrent.LinkedBlockingQueue<com.seeyon.boot.starter.serialnumber.api.dto.SerialNumberRecoverEvent> getReCoverTaskQueue();
```

### `SerialConditionAppService`（5 方法）

`com.seeyon.boot.starter.serialnumber.appservice.SerialConditionAppService`

```java
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> batchCreate(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.serialnumber.domain.dto.SerialConditionBatchCreateDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.boot.starter.serialnumber.domain.dto.SerialConditionDto> selectListBySchemeId(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> delBySchemeId(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> delById(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Boolean> evalExpression(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.serialnumber.domain.dto.SerialConditionCheckDto>);
```

### `SerialLocalCacheUtil`（3 方法）

`com.seeyon.boot.starter.serialnumber.utils.SerialLocalCacheUtil`

```java
    T get(java.lang.String);
    void put(java.lang.String, T);
    void remove(java.lang.String);
```

## 四、枚举（6）

- `CutTypeEnum`（3 常量）：LEFT, RIGHT, NONE
- `FillTypeEnum`（3 常量）：LEFT, RIGHT, NONE
- `SerialRangeTypeEnum`（2 常量）：RESERVE, UNUSED
- `SerialResetRuleEnum`（4 常量）：NONE, YEAR, MONTH, DAY
- `SerialRuleTypeEnum`（3 常量）：APP, BIG, SMALL
- `SerialTypeEnum`（4 常量）：CONSTANT, CONTEXT, ENTITY, SERIAL
