# 连接器：入参 DTO 字段表

> 自动生成。包前缀 `com.seeyon.cip`。共 346 个 DTO。
> 字段类型逐字来自 javap；`static` 前缀表示常量而非实例字段。

## `LinkerDetailApiDto`（44 字段）

`com.seeyon.cip.connector.dto.db.LinkerDetailApiDto`

被这些方法当入参：

- `DataBaseExecutorService.executeDetail()`（裸参数）
- `DataBaseExecutorService.executeDetailForCount()`（裸参数）
- `DataBaseExecutorService.generateSql()`（裸参数）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `CAPTION_REG_EXP` | static `java.lang.String` |
| `NAME_REG_EXP` | static `java.lang.String` |
| `id` | `java.lang.Long` |
| `infoId` | `java.lang.Long` |
| `caption` | `java.lang.String` |
| `targetNamespace` | `java.lang.String` |
| `paramNeedNs` | `java.lang.Boolean` |
| `methodName` | `java.lang.String` |
| `classifyId` | `java.lang.Long` |
| `classifyCaption` | `java.lang.String` |
| `isAuthAction` | `java.lang.Boolean` |
| `requestUrl` | `java.lang.String` |
| `requestType` | `com.seeyon.cip.connector.enums.RequestTypeEnum` |
| `consumes` | `java.lang.String` |
| `produces` | `java.lang.String` |
| `description` | `java.lang.String` |
| `requestPath` | `java.lang.String` |
| `requestQuery` | `java.lang.String` |
| `requestHeader` | `java.lang.String` |
| `requestBody` | `java.lang.String` |
| `xmlParam` | `java.lang.String` |
| `returnParam` | `java.lang.String` |
| `status` | `java.lang.Boolean` |
| `authStatus` | `java.lang.Boolean` |
| `signStatus` | `java.lang.Boolean` |
| `dbStatementType` | `com.seeyon.cip.connector.enums.DbStatementType` |
| `selectParam` | `java.lang.String` |
| `formParam` | `java.lang.String` |
| `whereParam` | `java.lang.String` |
| `groupByParam` | `java.lang.String` |
| `orderByParam` | `java.lang.String` |
| `havingParam` | `java.lang.String` |
| `isDistinct` | `java.lang.Boolean` |
| `isPage` | `java.lang.Boolean` |
| `pageParam` | `java.lang.String` |
| `sqlParam` | `java.lang.String` |
| `updateTime` | `java.util.Date` |
| `verifyResultExpression` | `java.lang.String` |
| `verifyFailProcessorType` | `com.seeyon.cip.connector.enums.VerifyFailProcessorTypeEnum` |
| `dataSourceId` | `java.lang.Long` |
| `enableEntity` | `java.lang.Boolean` |
| `enablePackageResult` | `java.lang.Boolean` |
| `enableAsync` | `java.lang.Boolean` |

## `CapabilityEnum`（36 字段）

`com.seeyon.cip.provider.enums.CapabilityEnum`

被这些方法当入参：

- `CapabilityManageAppService.selectProvidersByEnum()`（包装入参）
- `CapabilityManageAppService.selectEnableProvidersByEnum()`（包装入参）
- `CapabilityManageAppService.selectProvidersListByEnum()`（包装入参）
- `CapabilityManageAppService.selectActiveXFunctionByEnum()`（包装入参）
- `CapabilityManageAppService.queryEnableByEnum()`（包装入参）
- `CapabilityManageAppService.checkFeatureByEnum()`（包装入参）
- … 另 1 处

| 字段 | 类型 |
|---|---|
| `Routing` | static `com.seeyon.cip.provider.enums.CapabilityEnum` |
| `TestCapability` | static `com.seeyon.cip.provider.enums.CapabilityEnum` |
| `Sms` | static `com.seeyon.cip.provider.enums.CapabilityEnum` |
| `Ocr` | static `com.seeyon.cip.provider.enums.CapabilityEnum` |
| `Invoice` | static `com.seeyon.cip.provider.enums.CapabilityEnum` |
| `Video` | static `com.seeyon.cip.provider.enums.CapabilityEnum` |
| `Email` | static `com.seeyon.cip.provider.enums.CapabilityEnum` |
| `Translation` | static `com.seeyon.cip.provider.enums.CapabilityEnum` |
| `Location` | static `com.seeyon.cip.provider.enums.CapabilityEnum` |
| `Weather` | static `com.seeyon.cip.provider.enums.CapabilityEnum` |
| `Credit` | static `com.seeyon.cip.provider.enums.CapabilityEnum` |
| `Doc` | static `com.seeyon.cip.provider.enums.CapabilityEnum` |
| `Offline` | static `com.seeyon.cip.provider.enums.CapabilityEnum` |
| `Ofd` | static `com.seeyon.cip.provider.enums.CapabilityEnum` |
| `Missive` | static `com.seeyon.cip.provider.enums.CapabilityEnum` |
| `Signature` | static `com.seeyon.cip.provider.enums.CapabilityEnum` |
| `Resume` | static `com.seeyon.cip.provider.enums.CapabilityEnum` |
| `PhysicalSeal` | static `com.seeyon.cip.provider.enums.CapabilityEnum` |
| `BusinessTrip` | static `com.seeyon.cip.provider.enums.CapabilityEnum` |
| `Censor` | static `com.seeyon.cip.provider.enums.CapabilityEnum` |
| `Pay` | static `com.seeyon.cip.provider.enums.CapabilityEnum` |
| `FaceId` | static `com.seeyon.cip.provider.enums.CapabilityEnum` |
| `LabelPrint` | static `com.seeyon.cip.provider.enums.CapabilityEnum` |
| `Gis` | static `com.seeyon.cip.provider.enums.CapabilityEnum` |
| `Ai` | static `com.seeyon.cip.provider.enums.CapabilityEnum` |
| `Bankpay` | static `com.seeyon.cip.provider.enums.CapabilityEnum` |
| `Search` | static `com.seeyon.cip.provider.enums.CapabilityEnum` |
| `Voice` | static `com.seeyon.cip.provider.enums.CapabilityEnum` |
| `Schedule` | static `com.seeyon.cip.provider.enums.CapabilityEnum` |
| `Archives` | static `com.seeyon.cip.provider.enums.CapabilityEnum` |
| `isHidden` | `boolean` |
| `code` | `int` |
| `description` | `java.lang.String` |
| `nameByI18n` | `java.lang.String` |
| `sort` | `int` |
| `$VALUES` | static `com.seeyon.cip.provider.enums.CapabilityEnum[]` |

## `TripApplyAddRequestDto`（31 字段）

`com.seeyon.cip.provider.dto.trip.TripApplyAddRequestDto`

被这些方法当入参：

- `BusinessTripAppService.applyAdd()`（包装入参）

| 字段 | 类型 |
|---|---|
| `corpName` | `java.lang.String` |
| `userId` | `java.lang.String` |
| `userName` | `java.lang.String` |
| `departId` | `java.lang.String` |
| `departName` | `java.lang.String` |
| `thirdpartDepartId` | `java.lang.String` |
| `tripDay` | `java.lang.Integer` |
| `tripCause` | `java.lang.String` |
| `tripTitle` | `java.lang.String` |
| `thirdpartApplyId` | `java.lang.String` |
| `type` | `java.lang.Integer` |
| `itineraryRule` | `java.lang.Integer` |
| `itinerarySetList` | `java.util.List<com.seeyon.cip.provider.dto.trip.TripApplyAddRequestDto$ApplyAddRequestItinerarySetList>` |
| `itineraryList` | `java.util.List<com.seeyon.cip.provider.dto.trip.TripApplyAddRequestDto$ApplyAddRequestItineraryList>` |
| `travelerList` | `java.util.List<com.seeyon.cip.provider.dto.trip.TripApplyAddRequestDto$ApplyAddRequestTravelerList>` |
| `externalTravelerList` | `java.util.List<com.seeyon.cip.provider.dto.trip.TripApplyAddRequestDto$ApplyAddRequestExternalTravelerList>` |
| `status` | `java.lang.Integer` |
| `thirdpartBusinessId` | `java.lang.String` |
| `unionNo` | `java.lang.String` |
| `hotelBudget` | `java.lang.Long` |
| `flightBudget` | `java.lang.Long` |
| `trainBudget` | `java.lang.Long` |
| `vehicleBudget` | `java.lang.Long` |
| `budget` | `java.lang.Long` |
| `budgetMerge` | `java.lang.Integer` |
| `limitTraveler` | `java.lang.Integer` |
| `togetherBookRule` | `java.lang.Integer` |
| `hotelShare` | `com.seeyon.cip.provider.dto.trip.TripApplyAddRequestDto$ApplyAddRequestHotelShare` |
| `externalTravelerStandard` | `com.seeyon.cip.provider.dto.trip.TripApplyAddRequestDto$ApplyAddRequestExternalTravelerStandard` |
| `travelerStandard` | `java.util.List<com.seeyon.cip.provider.dto.trip.TripApplyAddRequestDto$ApplyAddRequestTravelerStandard>` |
| `internationalFlightCabins` | `java.lang.String` |

## `MobileMessageRequestDto`（28 字段）

`com.seeyon.cip.connector.dto.mobile.MobileMessageRequestDto`

被这些方法当入参：

- `MobileApplicationProviderService.sendMessage()`（裸参数）

| 字段 | 类型 |
|---|---|
| `messageId` | `java.lang.String` |
| `identification` | `java.lang.String` |
| `title` | `java.lang.String` |
| `contentJson` | `java.lang.String` |
| `mobileOpenUrl` | `java.lang.String` |
| `webOpenUrl` | `java.lang.String` |
| `host` | `java.lang.String` |
| `messageUrl` | `java.lang.String` |
| `user` | `com.seeyon.cip.connector.dto.mobile.MobileUserRequestDto` |
| `type` | `java.lang.String` |
| `pluginId` | `java.lang.Long` |
| `unitIdList` | `java.util.List<java.lang.Long>` |
| `affairCount` | `java.lang.String` |
| `meetingCount` | `java.lang.String` |
| `pluginCorpId` | `java.lang.Long` |
| `userList` | `java.util.List<com.seeyon.cip.connector.dto.mobile.MobileUserRequestDto>` |
| `isBatch` | `java.lang.Boolean` |
| `userMappingList` | `java.util.List<com.seeyon.cip.connector.dto.mobile.MobileUserMappingDto>` |
| `msgMappingList` | `java.util.List<com.seeyon.cip.connector.dto.mobile.MobileMsgMappingDto>` |
| `storageKey` | `java.lang.String` |
| `fileName` | `java.lang.String` |
| `isPicture` | `java.lang.Boolean` |
| `defaultStorageKey` | `java.lang.String` |
| `defaultFileName` | `java.lang.String` |
| `interfaceDomain` | `java.lang.String` |
| `templateKey` | `java.lang.String` |
| `templateSourceCode` | `java.lang.String` |
| `reSendDto` | `com.seeyon.cip.connector.dto.mobile.MobileReSendDto` |

## `DocFileInfoDto`（25 字段）

`com.seeyon.cip.capability.dto.doc.DocFileInfoDto`

被这些方法当入参：

- `DocCallBackAppService.fileInfo()`（包装入参）
- `DocCallBackAppService.userInfo()`（包装入参）
- `DocCallBackAppService.editFileOnline()`（包装入参）
- `DocCallBackAppService.editFileSave()`（包装入参）
- `DocCallBackAppService.editFileVersion()`（包装入参）
- `DocCallBackAppService.editFileRename()`（包装入参）
- … 另 5 处

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `token` | `java.lang.String` |
| `type` | `java.lang.String` |
| `appid` | `java.lang.String` |
| `storageKey` | `java.lang.String` |
| `fileName` | `java.lang.String` |
| `fileId` | `java.lang.String` |
| `checkToken` | `java.lang.String` |
| `fileSize` | `java.lang.String` |
| `appName` | `java.lang.String` |
| `version` | `java.lang.String` |
| `userId` | `java.lang.String` |
| `inputStream` | `java.io.InputStream` |
| `ids` | `java.util.List<java.lang.String>` |
| `fileAclDto` | `com.seeyon.cip.provider.dto.doc.FileAclDto` |
| `fileWatermarkDto` | `com.seeyon.cip.provider.dto.doc.FileWatermarkDto` |
| `userName` | `java.lang.String` |
| `userAvatar` | `java.lang.String` |
| `needLatestType` | `java.lang.Boolean` |
| `operateType` | `java.lang.String` |
| `historyReqDto` | `com.seeyon.cip.capability.dto.doc.DocHistoryReqDto` |
| `permission` | `java.lang.String` |
| `filePath` | `java.lang.String` |
| `channelProvider` | `java.lang.String` |
| `capabilityEnumName` | `java.lang.String` |

## `IntelligentWriteReqDto`（24 字段）

`com.seeyon.cip.capability.dto.missive.IntelligentWriteReqDto`

被这些方法当入参：

- `IntelligentMissiveAppService.createWrite()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `title` | `java.lang.String` |
| `storageKey` | `java.lang.String` |
| `keyWord` | `java.util.List<java.lang.String>` |
| `printingDate` | `java.util.Date` |
| `wordLength` | `java.lang.Integer` |
| `sendTo` | `java.lang.String` |
| `officialDocTypeEnum` | `com.seeyon.cip.provider.enums.missive.OfficialDocTypeEnum` |
| `writeOpinionDto` | `com.seeyon.cip.capability.dto.missive.IntelligentWriteOpinionDto` |
| `writeSummaryDto` | `com.seeyon.cip.capability.dto.missive.IntelligentWriteSummaryDto` |
| `writeInformDto` | `com.seeyon.cip.capability.dto.missive.IntelligentWriteInformDto` |
| `writeInstructionsDto` | `com.seeyon.cip.capability.dto.missive.IntelligentWriteInstructionsDto` |
| `writeAnnouncementDto` | `com.seeyon.cip.capability.dto.missive.IntelligentWriteAnnouncementDto` |
| `writeLetterDto` | `com.seeyon.cip.capability.dto.missive.IntelligentWriteLetterDto` |
| `writeBulletinDto` | `com.seeyon.cip.capability.dto.missive.IntelligentWriteBulletinDto` |
| `writeDecisionDto` | `com.seeyon.cip.capability.dto.missive.IntelligentWriteDecisionDto` |
| `writeResolutionDto` | `com.seeyon.cip.capability.dto.missive.IntelligentWriteResolutionDto` |
| `writeCommandDto` | `com.seeyon.cip.capability.dto.missive.IntelligentWriteCommandDto` |
| `writeReportDto` | `com.seeyon.cip.capability.dto.missive.IntelligentWriteReportDto` |
| `writeRespondDto` | `com.seeyon.cip.capability.dto.missive.IntelligentWriteRespondDto` |
| `writeMotionDto` | `com.seeyon.cip.capability.dto.missive.IntelligentWriteMotionDto` |
| `writeNoticeDto` | `com.seeyon.cip.capability.dto.missive.IntelligentWriteNoticeDto` |
| `writeNotificationDto` | `com.seeyon.cip.capability.dto.missive.IntelligentWriteNotificationDto` |
| `sendUpMsg` | `java.lang.Boolean` |

## `MobileTodoTaskDto`（24 字段）

`com.seeyon.cip.connector.dto.mobile.MobileTodoTaskDto`

被这些方法当入参：

- `MobileTodoProviderService.doneTodo()`（裸参数）
- `MobileTodoProviderService.deleteTodo()`（裸参数）

| 字段 | 类型 |
|---|---|
| `userId` | `java.lang.Long` |
| `userPhone` | `java.lang.String` |
| `userCode` | `java.lang.String` |
| `taskId` | `java.lang.String` |
| `thirdConfigId` | `java.lang.Long` |
| `host` | `java.lang.String` |
| `sourceId` | `java.lang.String` |
| `startUserPhone` | `java.lang.String` |
| `startUserCode` | `java.lang.String` |
| `receiveUserId` | `java.lang.Long` |
| `receiveUserPhone` | `java.lang.String` |
| `receiveUserCode` | `java.lang.String` |
| `webUrl` | `java.lang.String` |
| `mobileUrl` | `java.lang.String` |
| `title` | `java.lang.String` |
| `priority` | `com.seeyon.cip.connector.enums.MobileTodoPriorityEnum` |
| `dueTimestamp` | `java.lang.Long` |
| `done` | `java.lang.Boolean` |
| `delete` | `java.lang.Boolean` |
| `pluginCorpId` | `java.lang.Long` |
| `appName` | `java.lang.String` |
| `createTime` | `java.util.Date` |
| `updateTime` | `java.util.Date` |
| `nodePermissionTypeCode` | `java.lang.String` |

## `ThreePartySealIntegrationDto`（24 字段）

`com.seeyon.cip.provider.dto.signature.seal.ThreePartySealIntegrationDto`

被这些方法当入参：

- `SignatureAppService.stamp()`（包装入参）
- `SignatureAppService.withfileupload()`（包装入参）
- `SignatureAppService.invalid()`（包装入参）
- `SignatureAppService.recall()`（包装入参）
- `SignatureAppService.sealGetList()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `storageKey` | `java.lang.String` |
| `keyword` | `java.lang.String` |
| `control` | `java.lang.Integer` |
| `startPage` | `java.lang.Integer` |
| `endPage` | `java.lang.Integer` |
| `position` | `java.lang.Float` |
| `flag` | `java.lang.Boolean` |
| `page` | `java.lang.Integer` |
| `left` | `java.lang.Float` |
| `top` | `java.lang.Float` |
| `stampCode` | `java.lang.String` |
| `edocType` | `java.lang.String` |
| `operatorName` | `java.lang.String` |
| `operatorContact` | `java.lang.String` |
| `title` | `java.lang.String` |
| `bizId` | `java.lang.Long` |
| `contractId` | `java.lang.Long` |
| `documentIds` | `java.util.List<java.lang.Long>` |
| `businessMap` | `java.util.Map<java.lang.String, java.lang.Object>` |
| `companyId` | `java.lang.Long` |
| `sealIds` | `java.lang.String` |
| `companyName` | `java.lang.String` |
| `category` | `java.lang.String` |

## `SettingTaskReqDto`（23 字段）

`com.seeyon.cip.capability.dto.missive.SettingTaskReqDto`

被这些方法当入参：

- `IntelligentMissiveAppService.createSettingByTemplate()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `templateStorageKey` | `java.lang.String` |
| `templateFileName` | `java.lang.String` |
| `shareNumber` | `java.lang.String` |
| `classificationLevel` | `java.lang.String` |
| `degree` | `java.lang.String` |
| `authoritySignList` | `java.util.LinkedList<java.lang.String>` |
| `docNumber` | `java.lang.String` |
| `issuerList` | `java.util.LinkedList<java.lang.String>` |
| `title` | `java.lang.String` |
| `mainBodyStorageKey` | `java.lang.String` |
| `mainBodyFileName` | `java.lang.String` |
| `mainDelivery` | `java.lang.String` |
| `annexDescriptionList` | `java.util.LinkedList<java.lang.String>` |
| `annotations` | `java.lang.String` |
| `authoritySignatureList` | `java.util.LinkedList<java.lang.String>` |
| `mainDeliveryBanJi` | `java.lang.String` |
| `ccBanJi` | `java.lang.String` |
| `writtenDate` | `java.lang.String` |
| `issuingAuthority` | `java.lang.String` |
| `issuingDate` | `java.lang.String` |
| `extMap` | `java.util.Map<java.lang.String, java.lang.Object>` |
| `annexFiles` | `java.util.List<com.seeyon.cip.capability.dto.missive.SettingAnnexDetailReqDto>` |

## `OfdFileRequestDto`（23 字段）

`com.seeyon.cip.capability.dto.ofd.OfdFileRequestDto`

被这些方法当入参：

- `OfdAppService.getOfdViewUrl()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `storageKey` | `java.lang.String` |
| `fileName` | `java.lang.String` |
| `fileId` | `java.lang.String` |
| `businessId` | `java.lang.String` |
| `fileSize` | `java.lang.Long` |
| `fileType` | `com.seeyon.cip.provider.enums.ofd.OfdFileTypeEnum` |
| `enableSelectText` | `java.lang.Boolean` |
| `isConvertAllPage` | `java.lang.Boolean` |
| `waterMarkText` | `java.lang.String` |
| `ofdFileWatermarkDto` | `com.seeyon.cip.provider.dto.ofd.OfdFileWatermarkDto` |
| `showSeal` | `java.lang.Boolean` |
| `showDownload` | `java.lang.Boolean` |
| `showToolbar` | `java.lang.Boolean` |
| `showPrint` | `java.lang.Boolean` |
| `loginName` | `java.lang.String` |
| `userName` | `java.lang.String` |
| `userAvatar` | `java.lang.String` |
| `showDeleteSeal` | `java.lang.Boolean` |
| `showOpenFile` | `java.lang.Boolean` |
| `checkFileType` | `java.lang.String` |
| `loginType` | `com.seeyon.cip.provider.enums.doc.CipClientTypeEnum` |
| `origin` | `java.lang.String` |

## `MobileTodoRequestDto`（22 字段）

`com.seeyon.cip.connector.dto.mobile.MobileTodoRequestDto`

被这些方法当入参：

- `MobileTodoProviderService.createTodo()`（裸参数）
- `MobileTodoProviderService.updateTodo()`（裸参数）

| 字段 | 类型 |
|---|---|
| `thirdConfigId` | `java.lang.Long` |
| `host` | `java.lang.String` |
| `sourceId` | `java.lang.String` |
| `taskId` | `java.lang.String` |
| `startUserId` | `java.lang.Long` |
| `startUserPhone` | `java.lang.String` |
| `startUserCode` | `java.lang.String` |
| `receiveUserId` | `java.lang.Long` |
| `receiveUserPhone` | `java.lang.String` |
| `receiveUserCode` | `java.lang.String` |
| `webUrl` | `java.lang.String` |
| `mobileUrl` | `java.lang.String` |
| `title` | `java.lang.String` |
| `priority` | `com.seeyon.cip.connector.enums.MobileTodoPriorityEnum` |
| `dueTimestamp` | `java.lang.Long` |
| `done` | `java.lang.Boolean` |
| `delete` | `java.lang.Boolean` |
| `pluginCorpId` | `java.lang.Long` |
| `appName` | `java.lang.String` |
| `createTime` | `java.util.Date` |
| `updateTime` | `java.util.Date` |
| `nodePermissionTypeCode` | `java.lang.String` |

## `MobilePlatformConfigDto`（21 字段）

`com.seeyon.cip.connector.dto.mobile.MobilePlatformConfigDto`

被这些方法当入参：

- `MobileApplicationProviderService.publishApp()`（裸参数）
- `MobileApplicationProviderService.getSignature()`（裸参数）
- `MobileApplicationProviderService.getMobileSsoUserDto()`（裸参数）
- `MobileApplicationProviderService.interfaceStatus()`（裸参数）
- `MobileApplicationProviderService.getOpenId()`（裸参数）
- `MobileApplicationProviderService.getLaunchCode()`（裸参数）
- … 另 23 处

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `id` | `java.lang.Long` |
| `type` | `java.lang.String` |
| `corpId` | `java.lang.String` |
| `corpSecret` | `java.lang.String` |
| `appId` | `java.lang.String` |
| `appKey` | `java.lang.String` |
| `appSecret` | `java.lang.String` |
| `json` | `java.lang.String` |
| `templateId` | `java.lang.String` |
| `templateName` | `java.lang.String` |
| `templateQr` | `java.lang.String` |
| `name` | `java.lang.String` |
| `accessMode` | `com.seeyon.cip.connector.enums.AccessModeEnum` |
| `openCorpId` | `java.lang.String` |
| `enable` | `java.lang.Boolean` |
| `fuse` | `java.lang.Boolean` |
| `thirdApplicationDomain` | `java.lang.String` |
| `defaultApplet` | `java.lang.Boolean` |
| `pluginCorpId` | `java.lang.Long` |
| `curOrgSyncConfigId` | `java.lang.Long` |

## `SignatureFileRequestDto`（20 字段）

`com.seeyon.cip.capability.dto.signature.SignatureFileRequestDto`

被这些方法当入参：

- `SignatureAppService.getSignatureViewUrl()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `storageKey` | `java.lang.String` |
| `fileName` | `java.lang.String` |
| `fileId` | `java.lang.String` |
| `businessId` | `java.lang.String` |
| `fileSize` | `java.lang.Long` |
| `fileType` | `com.seeyon.cip.provider.enums.ofd.OfdFileTypeEnum` |
| `enableSelectText` | `java.lang.Boolean` |
| `isConvertAllPage` | `java.lang.Boolean` |
| `waterMarkText` | `java.lang.String` |
| `ofdFileWatermarkDto` | `com.seeyon.cip.provider.dto.ofd.OfdFileWatermarkDto` |
| `showSeal` | `java.lang.Boolean` |
| `showDownload` | `java.lang.Boolean` |
| `showToolbar` | `java.lang.Boolean` |
| `showPrint` | `java.lang.Boolean` |
| `loginName` | `java.lang.String` |
| `showDeleteSeal` | `java.lang.Boolean` |
| `showOpenFile` | `java.lang.Boolean` |
| `checkFileType` | `java.lang.String` |
| `loginType` | `com.seeyon.cip.provider.enums.doc.CipClientTypeEnum` |

## `ShortMessageTemplateDto`（20 字段）

`com.seeyon.cip.capability.dto.sms.ShortMessageTemplateDto`

被这些方法当入参：

- `ShortMessageTemplateAppService.createShortMessageTemplate()`（包装入参）
- `ShortMessageTemplateAppService.createSMSTemplate()`（包装入参）
- `ShortMessageTemplateAppService.updateTemplate()`（包装入参）
- `ShortMessageTemplateAppService.updateShortMessageTemplate()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `id` | `java.lang.Long` |
| `name` | `java.lang.String` |
| `code` | `java.lang.String` |
| `templateTypeEnumsId` | `java.lang.Long` |
| `templateTypeEnumsName` | `java.lang.String` |
| `templateLanguage` | `java.lang.String` |
| `templateLanguageName` | `java.lang.String` |
| `templateStatusEnum` | `com.seeyon.cip.capability.enums.sms.TemplateStatusEnum` |
| `templateContent` | `java.lang.String` |
| `prepare` | `java.lang.Boolean` |
| `library` | `java.lang.Boolean` |
| `applicationDescription` | `java.lang.String` |
| `auditDescription` | `java.lang.String` |
| `createTime` | `java.util.Date` |
| `interfaceLink` | `java.lang.Boolean` |
| `signId` | `java.lang.Long` |
| `signName` | `java.lang.String` |
| `providerTemplateDtoList` | `java.util.List<com.seeyon.cip.capability.dto.sms.ShortMessageProviderTemplateDto>` |
| `paramsDtos` | `java.util.List<com.seeyon.cip.capability.dto.sms.ShortMessageTemplateParamsDto>` |

## `MobileUserRequestDto`（20 字段）

`com.seeyon.cip.connector.dto.mobile.MobileUserRequestDto`

被这些方法当入参：

- `MobileOrgSyncProviderService.syncUser()`（裸参数）
- `MobileOrgSyncProviderService.updateUser()`（裸参数）
- `MobileOrgSyncProviderService.getUser()`（裸参数）
- `MobileOrgSyncProviderService.removeUser()`（裸参数）

| 字段 | 类型 |
|---|---|
| `id` | `java.lang.Long` |
| `name` | `java.lang.String` |
| `email` | `java.lang.String` |
| `bizEmail` | `java.lang.String` |
| `isEnable` | `java.lang.Boolean` |
| `jobName` | `java.lang.String` |
| `phoneNumber` | `java.lang.String` |
| `orgId` | `java.lang.Long` |
| `thirdOrgId` | `java.lang.String` |
| `gender` | `java.lang.String` |
| `fullName` | `java.lang.String` |
| `mobilePluginId` | `java.lang.Long` |
| `thirdConfigId` | `java.lang.Long` |
| `type` | `java.lang.String` |
| `userId` | `java.lang.String` |
| `userAccount` | `java.lang.String` |
| `loginName` | `java.lang.String` |
| `entryDate` | `java.util.Date` |
| `deptIdList` | `java.util.List<java.lang.String>` |
| `mappingId` | `java.lang.String` |

## `DocViewDto`（19 字段）

`com.seeyon.cip.capability.dto.doc.DocViewDto`

被这些方法当入参：

- `DocOnlineAppService.getOfficeViewUrl()`（包装入参）

| 字段 | 类型 |
|---|---|
| `storageKey` | `java.lang.String` |
| `downloadUrl` | `java.lang.String` |
| `fileName` | `java.lang.String` |
| `fileSize` | `java.lang.Long` |
| `fileId` | `java.lang.String` |
| `businessId` | `java.lang.String` |
| `createTime` | `java.util.Date` |
| `fileType` | `java.lang.String` |
| `userName` | `java.lang.String` |
| `userAvatar` | `java.lang.String` |
| `fileAclDto` | `com.seeyon.cip.provider.dto.doc.FileAclDto` |
| `fileWatermarkDto` | `com.seeyon.cip.provider.dto.doc.FileWatermarkDto` |
| `needLatestType` | `java.lang.Boolean` |
| `wpsPreview` | `java.lang.String` |
| `tokenType` | `java.lang.Boolean` |
| `authorityInfo` | `java.lang.String` |
| `loginType` | `com.seeyon.cip.provider.enums.doc.CipClientTypeEnum` |
| `previewMode` | `java.lang.String` |
| `origin` | `java.lang.String` |

## `AddScheduleDto`（19 字段）

`com.seeyon.cip.provider.dto.schedule.AddScheduleDto`

被这些方法当入参：

- `ScheduleAppService.addSchedule()`（包装入参）

| 字段 | 类型 |
|---|---|
| `title` | `java.lang.String` |
| `startDate` | `java.util.Date` |
| `endDate` | `java.util.Date` |
| `adminUserIds` | `java.util.List<java.lang.Long>` |
| `userIds` | `java.util.List<java.lang.Long>` |
| `remind` | `java.lang.Integer` |
| `remindBeforeEventSecs` | `java.lang.Integer` |
| `remindTimeDiffs` | `java.util.List<java.lang.Integer>` |
| `repeat` | `java.lang.Integer` |
| `repeatType` | `java.lang.Integer` |
| `repeatUntil` | `java.util.Date` |
| `customRepeat` | `java.lang.Integer` |
| `repeatInterval` | `java.lang.Integer` |
| `repeatDayOfWeek` | `java.util.List<java.lang.Integer>` |
| `repeatDayOfMonth` | `java.util.List<java.lang.Integer>` |
| `timezone` | `java.lang.Integer` |
| `description` | `java.lang.String` |
| `wholeDay` | `java.lang.Integer` |
| `map` | `java.util.Map<java.lang.String, java.lang.Object>` |

## `IntelligentPushOfficialReqDto`（18 字段）

`com.seeyon.cip.capability.dto.missive.IntelligentPushOfficialReqDto`

被这些方法当入参：

- `IntelligentMissiveAppService.pushOfficial()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `title` | `java.lang.String` |
| `sourceId` | `java.lang.String` |
| `storageKey` | `java.lang.String` |
| `fileName` | `java.lang.String` |
| `userIds` | `java.lang.String` |
| `officialDocTypeEnum` | `com.seeyon.cip.provider.enums.missive.OfficialDocTypeEnum` |
| `province` | `java.lang.String` |
| `city` | `java.lang.String` |
| `publicationDate` | `java.lang.String` |
| `office` | `java.lang.String` |
| `link` | `java.lang.String` |
| `writeDate` | `java.lang.String` |
| `sendTo` | `java.lang.String` |
| `secretLevelAndKeepPeriod` | `java.lang.String` |
| `urgentLevel` | `java.lang.String` |
| `numberOfCopies` | `java.lang.String` |
| `wordSize` | `java.lang.String` |

## `MobilePluginPlatformConfigDto`（18 字段）

`com.seeyon.cip.provider.dto.mobileplugin.MobilePluginPlatformConfigDto`

被这些方法当入参：

- `MobilePluginConfigAppService.create()`（包装入参）
- `MobilePluginConfigAppService.update()`（包装入参）
- `MobilePluginConfigAppService.updateStatus()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `id` | `java.lang.Long` |
| `type` | `java.lang.String` |
| `corpId` | `java.lang.String` |
| `corpSecret` | `java.lang.String` |
| `appId` | `java.lang.String` |
| `appKey` | `java.lang.String` |
| `appSecret` | `java.lang.String` |
| `json` | `java.lang.String` |
| `templateId` | `java.lang.String` |
| `templateName` | `java.lang.String` |
| `templateQr` | `java.lang.String` |
| `name` | `java.lang.String` |
| `accessMode` | `com.seeyon.cip.provider.enums.mobileplugin.AccessModeEnum` |
| `openCorpId` | `java.lang.String` |
| `enable` | `java.lang.Boolean` |
| `fuse` | `java.lang.Boolean` |
| `thirdApplicationDomain` | `java.lang.String` |

## `CipWarningInfoDto`（16 字段）

`com.seeyon.cip.application.dto.CipWarningInfoDto`

被这些方法当入参：

- `WarningCallBackAppService.redoWarning()`（包装入参）
- `WarningManageAppService.addWarningInfo()`（包装入参）
- `WarningManageAppService.modifyWarningInfo()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `id` | `java.lang.Long` |
| `serviceCaption` | `java.lang.String` |
| `serviceName` | `java.lang.String` |
| `actionId` | `java.lang.String` |
| `serviceType` | `com.seeyon.cip.application.enums.ApplicationTypeEnum` |
| `actionDesc` | `java.lang.String` |
| `startTime` | `java.util.Date` |
| `endTime` | `java.util.Date` |
| `resultType` | `com.seeyon.cip.application.enums.ActionResultTypeEnum` |
| `requestJson` | `java.lang.String` |
| `responseJson` | `java.lang.String` |
| `allowView` | `java.lang.Boolean` |
| `allowIgnore` | `java.lang.Boolean` |
| `allowDelete` | `java.lang.Boolean` |
| `allowRedo` | `java.lang.Boolean` |

## `CipWarningInfoDto`（16 字段）

`com.seeyon.cip.custom.dto.CipWarningInfoDto`

被这些方法当入参：

- `WarningCallBackAppService.redoWarning()`（包装入参）
- `WarningManageAppService.addWarningInfo()`（包装入参）
- `WarningManageAppService.modifyWarningInfo()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `id` | `java.lang.Long` |
| `serviceCaption` | `java.lang.String` |
| `serviceName` | `java.lang.String` |
| `actionId` | `java.lang.String` |
| `serviceType` | `com.seeyon.cip.custom.enums.ApplicationTypeEnum` |
| `actionDesc` | `java.lang.String` |
| `startTime` | `java.util.Date` |
| `endTime` | `java.util.Date` |
| `resultType` | `com.seeyon.cip.custom.enums.ActionResultTypeEnum` |
| `requestJson` | `java.lang.String` |
| `responseJson` | `java.lang.String` |
| `allowView` | `java.lang.Boolean` |
| `allowIgnore` | `java.lang.Boolean` |
| `allowDelete` | `java.lang.Boolean` |
| `allowRedo` | `java.lang.Boolean` |

## `DocEditDto`（15 字段）

`com.seeyon.cip.capability.dto.doc.DocEditDto`

被这些方法当入参：

- `DocOnlineAppService.getOfficeEditUrl()`（包装入参）

| 字段 | 类型 |
|---|---|
| `storageKey` | `java.lang.String` |
| `fileType` | `java.lang.String` |
| `fileName` | `java.lang.String` |
| `fileSize` | `java.lang.Long` |
| `fileId` | `java.lang.String` |
| `fileAclDto` | `com.seeyon.cip.provider.dto.doc.FileAclDto` |
| `fileWatermarkDto` | `com.seeyon.cip.provider.dto.doc.FileWatermarkDto` |
| `userName` | `java.lang.String` |
| `userAvatar` | `java.lang.String` |
| `sceneType` | `java.lang.Integer` |
| `tokenType` | `java.lang.Boolean` |
| `permission` | `java.lang.String` |
| `authorityInfo` | `java.lang.String` |
| `loginType` | `com.seeyon.cip.provider.enums.doc.CipClientTypeEnum` |
| `origin` | `java.lang.String` |

## `EmailConfigTestDto`（15 字段）

`com.seeyon.cip.capability.dto.email.EmailConfigTestDto`

被这些方法当入参：

- `EmailPrivateAppService.testSendEmail()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `emailAccount` | `java.lang.String` |
| `sendHost` | `java.lang.String` |
| `sendSsl` | `java.lang.Boolean` |
| `sendPort` | `java.lang.Integer` |
| `loginName` | `java.lang.String` |
| `loginPassword` | `java.lang.String` |
| `contentWithLink` | `java.lang.Boolean` |
| `linkLogin` | `java.lang.Boolean` |
| `effectiveTime` | `java.lang.Integer` |
| `prefix` | `java.lang.String` |
| `appName` | `java.lang.String` |
| `debugging` | `java.lang.Boolean` |
| `mailTo` | `java.lang.String` |
| `contentLink` | `java.lang.String` |

## `EmailDetailsDto`（15 字段）

`com.seeyon.cip.capability.dto.email.EmailDetailsDto`

被这些方法当入参：

- `EmailAppService.sendNormalEmail()`（包装入参）
- `EmailAppService.sendPersonalEmail()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `userCode` | `java.lang.String` |
| `userName` | `java.lang.String` |
| `to` | `java.util.List<java.lang.String>` |
| `cc` | `java.util.List<java.lang.String>` |
| `bcc` | `java.util.List<java.lang.String>` |
| `subject` | `java.lang.String` |
| `content` | `java.lang.String` |
| `attachments` | `java.util.List<com.seeyon.cip.capability.dto.email.EmailAttachmentDto>` |
| `contentLink` | `java.lang.String` |
| `memberIdList` | `java.util.List<java.lang.String>` |
| `orgIdList` | `java.util.List<java.lang.String>` |
| `upToLimit` | `java.util.List<java.lang.String>` |
| `templateName` | `java.lang.String` |
| `templateContent` | `java.lang.String` |

## `RetrievalReqDto`（14 字段）

`com.seeyon.cip.capability.dto.missive.RetrievalReqDto`

被这些方法当入参：

- `IntelligentMissiveAppService.retrieval()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `pageInfo` | `com.seeyon.boot.transport.PageInfo` |
| `keyword` | `java.lang.String` |
| `elementScope` | `java.lang.Integer` |
| `officialDocTypeEnum` | `com.seeyon.cip.provider.enums.missive.OfficialDocTypeEnum` |
| `subjectClassify` | `java.lang.String` |
| `source` | `java.lang.Integer` |
| `contentType` | `java.lang.Integer` |
| `wordSize` | `java.lang.String` |
| `office` | `java.lang.String` |
| `orderByDate` | `java.lang.Boolean` |
| `startDate` | `java.lang.String` |
| `endDate` | `java.lang.String` |
| `ignoreFlag` | `java.lang.Integer` |

## `ShortMessageSignDto`（14 字段）

`com.seeyon.cip.capability.dto.sms.ShortMessageSignDto`

被这些方法当入参：

- `ShortMessageSignAppService.createShortMessageSign()`（包装入参）
- `ShortMessageSignAppService.updateTemplateSign()`（包装入参）
- `ShortMessageSignAppService.updateShortMessageSign()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `id` | `java.lang.Long` |
| `signName` | `java.lang.String` |
| `templateStatusEnum` | `com.seeyon.cip.capability.enums.sms.TemplateStatusEnum` |
| `applicationDescription` | `java.lang.String` |
| `auditDescription` | `java.lang.String` |
| `prepare` | `java.lang.Boolean` |
| `createTime` | `java.util.Date` |
| `interfaceLink` | `java.lang.Boolean` |
| `qualificationPath` | `java.lang.String` |
| `qualificationFilName` | `java.lang.String` |
| `commissionPath` | `java.lang.String` |
| `commissionFileName` | `java.lang.String` |
| `enableStatus` | `java.lang.Boolean` |

## `CipNotifyMessageDto`（14 字段）

`com.seeyon.cip.openapi.operate.dto.CipNotifyMessageDto`

被这些方法当入参：

- `OpenApiNotifyAppService.batchSaveOpenApiNotify()`（裸参数）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `id` | `java.lang.Long` |
| `requestId` | `java.lang.String` |
| `notifyUrl` | `java.lang.String` |
| `createTime` | `java.util.Date` |
| `header` | `java.lang.String` |
| `body` | `java.lang.String` |
| `appKey` | `java.lang.String` |
| `notifyType` | `com.seeyon.cip.openapi.operate.enums.NotifyTypeEnum` |
| `eventName` | `java.lang.String` |
| `eventKey` | `java.lang.String` |
| `status` | `java.lang.String` |
| `nextTryTime` | `java.util.Date` |
| `sendCount` | `java.lang.Integer` |

## `CapabilityEnumItemDto`（13 字段）

`com.seeyon.cip.capability.dto.info.CapabilityEnumItemDto`

被这些方法当入参：

- `CapabilityEnumAppService.createItem()`（包装入参）
- `CapabilityEnumAppService.updateItem()`（包装入参）

| 字段 | 类型 |
|---|---|
| `NAME_REG_EXP` | static `java.lang.String` |
| `CAPTION_REG_EXP` | static `java.lang.String` |
| `serialVersionUID` | static `long` |
| `id` | `java.lang.Long` |
| `enumId` | `java.lang.Long` |
| `name` | `java.lang.String` |
| `caption` | `java.lang.String` |
| `enable` | `java.lang.Boolean` |
| `orderNo` | `java.lang.Integer` |
| `description` | `java.lang.String` |
| `value` | `java.lang.String` |
| `enumName` | `java.lang.String` |
| `preset` | `java.lang.Boolean` |

## `DatabaseInfoApiDto`（13 字段）

`com.seeyon.cip.connector.dto.db.DatabaseInfoApiDto`

被这些方法当入参：

- `DataBaseExecutorService.executeDetail()`（裸参数）
- `DataBaseExecutorService.executeDetailForCount()`（裸参数）
- `DataBaseExecutorService.getAllTableName()`（裸参数）
- `DataBaseExecutorService.getPageTableName()`（裸参数）
- `DataBaseExecutorService.getAllTableInfo()`（裸参数）
- `DataBaseExecutorService.getConnection()`（裸参数）
- … 另 1 处

| 字段 | 类型 |
|---|---|
| `id` | `java.lang.Long` |
| `caption` | `java.lang.String` |
| `mode` | `com.seeyon.cip.connector.enums.ConfigModeEnum` |
| `type` | `java.lang.String` |
| `status` | `java.lang.Boolean` |
| `url` | `java.lang.String` |
| `driver` | `java.lang.String` |
| `username` | `java.lang.String` |
| `password` | `java.lang.String` |
| `description` | `java.lang.String` |
| `createTime` | `java.util.Date` |
| `property` | `java.lang.String` |
| `topic` | `java.lang.String` |

## `MobileUnitRequestDto`（13 字段）

`com.seeyon.cip.connector.dto.mobile.MobileUnitRequestDto`

被这些方法当入参：

- `MobileOrgSyncProviderService.syncUnit()`（裸参数）
- `MobileOrgSyncProviderService.updateUnit()`（裸参数）
- `MobileOrgSyncProviderService.getUnit()`（裸参数）
- `MobileOrgSyncProviderService.removeUnit()`（裸参数）
- `MobileOrgSyncProviderService.syncUnitNew()`（裸参数）

| 字段 | 类型 |
|---|---|
| `id` | `java.lang.Long` |
| `name` | `java.lang.String` |
| `path` | `java.lang.String` |
| `parentId` | `java.lang.Long` |
| `unitType` | `java.lang.String` |
| `enable` | `java.lang.Boolean` |
| `level` | `java.lang.Integer` |
| `topId` | `java.lang.Long` |
| `thirdConfigId` | `java.lang.Long` |
| `thirdId` | `java.lang.String` |
| `thirdParentId` | `java.lang.String` |
| `type` | `java.lang.String` |
| `ROOT_LEVEL` | static `java.lang.Integer` |

## `VideoMeetingCreateDto`（13 字段）

`com.seeyon.cip.provider.dto.video.request.VideoMeetingCreateDto`

被这些方法当入参：

- `VideoMeetingAppService.createVideoMeeting()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `meetingTitle` | `java.lang.String` |
| `userRoomId` | `java.lang.String` |
| `roomUserId` | `java.lang.String` |
| `password` | `java.lang.String` |
| `hostPassword` | `java.lang.String` |
| `startDate` | `java.util.Date` |
| `endDate` | `java.util.Date` |
| `meetingType` | `com.seeyon.cip.provider.enums.video.VideoMeetingTypeApiEnum` |
| `meetingMediaType` | `com.seeyon.cip.provider.enums.video.VideoMeetingMediaTypeEnum` |
| `attendeeDtoList` | `java.util.List<com.seeyon.cip.provider.dto.video.request.VideoMeetingAttendeeDto>` |
| `recordType` | `java.lang.Integer` |
| `duration` | `java.lang.Integer` |

## `ExpenseReqDto`（11 字段）

`com.seeyon.cip.capability.dto.bankpay.payment.ExpenseReqDto`

被这些方法当入参：

- `BankpayAppService.expensesFinance()`（包装入参）

| 字段 | 类型 |
|---|---|
| `userName` | `java.lang.String` |
| `clientID` | `java.lang.String` |
| `preFlg` | `java.lang.String` |
| `delayDate` | `java.util.Date` |
| `payAccountNo` | `java.lang.String` |
| `recAccountNo` | `java.lang.String` |
| `recAccountName` | `java.lang.String` |
| `tranAmount` | `java.math.BigDecimal` |
| `postscript` | `java.lang.String` |
| `chkNum` | `java.lang.String` |
| `synFlag` | `java.lang.String` |

## `DocFileOperateImageWatermarkDto`（11 字段）

`com.seeyon.cip.capability.dto.doc.DocFileOperateImageWatermarkDto`

被这些方法当入参：

- `DocOnlineAppService.cpsOfficeOperateImageWatermark()`（包装入参）

| 字段 | 类型 |
|---|---|
| `taskId` | `java.lang.String` |
| `storageKey` | `java.lang.String` |
| `fileName` | `java.lang.String` |
| `watermarkStorageKey` | `java.lang.String` |
| `watermarkFilename` | `java.lang.String` |
| `noWashout` | `java.lang.Boolean` |
| `scale` | `java.lang.Float` |
| `tilt` | `java.lang.Boolean` |
| `position` | `java.lang.String` |
| `tiled` | `java.lang.Boolean` |
| `sync` | `java.lang.Boolean` |

## `DocFileOperateTextWatermarkDto`（11 字段）

`com.seeyon.cip.capability.dto.doc.DocFileOperateTextWatermarkDto`

被这些方法当入参：

- `DocOnlineAppService.cpsOfficeOperateTextWatermark()`（包装入参）

| 字段 | 类型 |
|---|---|
| `taskId` | `java.lang.String` |
| `storageKey` | `java.lang.String` |
| `fileName` | `java.lang.String` |
| `content` | `java.lang.String` |
| `size` | `java.lang.Integer` |
| `color` | `java.lang.String` |
| `transparent` | `java.lang.Float` |
| `tilt` | `java.lang.Boolean` |
| `position` | `java.lang.String` |
| `tiled` | `java.lang.Boolean` |
| `sync` | `java.lang.Boolean` |

## `CipEmailConfigDto`（11 字段）

`com.seeyon.cip.capability.dto.email.CipEmailConfigDto`

被这些方法当入参：

- `EmailPrivateAppService.insertOrUpdateEmailConfig()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `emailAccount` | `java.lang.String` |
| `sendHost` | `java.lang.String` |
| `sendPort` | `java.lang.Integer` |
| `sendSsl` | `java.lang.Boolean` |
| `loginName` | `java.lang.String` |
| `loginPassword` | `java.lang.String` |
| `contentWithLink` | `java.lang.Boolean` |
| `linkLogin` | `java.lang.Boolean` |
| `effectiveTime` | `java.lang.Integer` |
| `prefix` | `java.lang.String` |

## `InvoiceImageReqDto`（11 字段）

`com.seeyon.cip.capability.dto.invoice.request.InvoiceImageReqDto`

被这些方法当入参：

- `InvoiceImageAppService.createImageTask()`（包装入参）

| 字段 | 类型 |
|---|---|
| `billTypeCode` | `java.lang.String` |
| `billTypeName` | `java.lang.String` |
| `businessTypeCode` | `java.lang.String` |
| `businessTypeName` | `java.lang.String` |
| `companyCode` | `java.lang.String` |
| `companyName` | `java.lang.String` |
| `billNo` | `java.lang.String` |
| `source` | `java.lang.String` |
| `fileTotalNum` | `java.lang.Integer` |
| `physicalFileNum` | `java.lang.Integer` |
| `summaryId` | `java.lang.String` |

## `DatabaseInfoDto`（11 字段）

`com.seeyon.cip.connector.dto.database.DatabaseInfoDto`

被这些方法当入参：

- `BaseConfigAppService.createDatabase()`（包装入参）
- `BaseConfigAppService.updateDatabase()`（包装入参）
- `BaseConfigAppService.connectorDatabase()`（包装入参）

| 字段 | 类型 |
|---|---|
| `id` | `java.lang.Long` |
| `caption` | `java.lang.String` |
| `type` | `java.lang.String` |
| `status` | `java.lang.Boolean` |
| `url` | `java.lang.String` |
| `driver` | `java.lang.String` |
| `username` | `java.lang.String` |
| `password` | `java.lang.String` |
| `description` | `java.lang.String` |
| `createTime` | `java.util.Date` |
| `property` | `java.lang.String` |

## `MobilePlatformRequestDto`（11 字段）

`com.seeyon.cip.connector.dto.mobile.MobilePlatformRequestDto`

被这些方法当入参：

- `MobileApplicationProviderService.sendMessage()`（裸参数）

| 字段 | 类型 |
|---|---|
| `id` | `java.lang.Long` |
| `appId` | `java.lang.String` |
| `appKey` | `java.lang.String` |
| `appSecret` | `java.lang.String` |
| `corpId` | `java.lang.String` |
| `corpSecret` | `java.lang.String` |
| `accessModeEnum` | `com.seeyon.cip.connector.enums.AccessModeEnum` |
| `type` | `java.lang.String` |
| `json` | `java.lang.String` |
| `thirdApplicationDomain` | `java.lang.String` |
| `interfaceDomain` | `java.lang.String` |

## `AppCreateDto`（11 字段）

`com.seeyon.cip.openapi.operate.dto.AppCreateDto`

被这些方法当入参：

- `OpenCapabilityAppService.createApp()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `appName` | `java.lang.String` |
| `appDescribe` | `java.lang.String` |
| `storageKey` | `java.lang.String` |
| `providerName` | `java.lang.String` |
| `productName` | `java.lang.String` |
| `productVersion` | `java.lang.String` |
| `openingCapabilityDtoList` | `java.util.List<com.seeyon.cip.openapi.operate.dto.OpeningCapabilityDto>` |
| `authTenantList` | `java.util.List<com.seeyon.cip.openapi.operate.dto.KeyValuePairDto>` |
| `authServiceList` | `java.util.List<com.seeyon.cip.openapi.operate.dto.KeyValuePairDto>` |
| `createOrg` | `java.lang.Long` |

## `H5PayOrderParamsDto`（11 字段）

`com.seeyon.cip.provider.dto.pay.H5PayOrderParamsDto`

被这些方法当入参：

- `PayAppService.h5Pay()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `mchid` | `java.lang.String` |
| `outTradeNo` | `java.lang.String` |
| `subject` | `java.lang.String` |
| `description` | `java.lang.String` |
| `timeExpire` | `java.util.Date` |
| `total` | `java.lang.Integer` |
| `type` | `java.lang.String` |
| `payerClientIp` | `java.lang.String` |
| `attach` | `java.lang.String` |
| `appUrl` | `java.lang.String` |

## `CipEmailTemplateDto`（10 字段）

`com.seeyon.cip.capability.dto.email.CipEmailTemplateDto`

被这些方法当入参：

- `EmailPrivateAppService.addEmailTemplate()`（包装入参）
- `EmailPrivateAppService.modifyEmailTemplate()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `id` | `java.lang.Long` |
| `templateCode` | `java.lang.String` |
| `templateName` | `java.lang.String` |
| `emailSubject` | `java.lang.String` |
| `emailContent` | `java.lang.String` |
| `attachments` | `java.util.List<com.seeyon.cip.capability.dto.email.EmailAttachmentDto>` |
| `createTime` | `java.util.Date` |
| `subjectParamsList` | `java.util.List<java.lang.String>` |
| `contentParamsList` | `java.util.List<java.lang.String>` |

## `CapabilityEnumDto`（10 字段）

`com.seeyon.cip.capability.dto.info.CapabilityEnumDto`

被这些方法当入参：

- `CapabilityEnumAppService.create()`（包装入参）
- `CapabilityEnumAppService.update()`（包装入参）

| 字段 | 类型 |
|---|---|
| `NAME_REG_EXP` | static `java.lang.String` |
| `CAPTION_REG_EXP` | static `java.lang.String` |
| `serialVersionUID` | static `long` |
| `id` | `java.lang.Long` |
| `name` | `java.lang.String` |
| `caption` | `java.lang.String` |
| `enable` | `java.lang.Boolean` |
| `orderNo` | `java.lang.Integer` |
| `description` | `java.lang.String` |
| `enumItemDtoList` | `java.util.List<com.seeyon.cip.capability.dto.info.CapabilityEnumItemDto>` |

## `DiffTaskReqDto`（10 字段）

`com.seeyon.cip.capability.dto.missive.DiffTaskReqDto`

被这些方法当入参：

- `IntelligentMissiveAppService.createDocDiffTask()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `sourceStorageKey` | `java.lang.String` |
| `sourceFileName` | `java.lang.String` |
| `targetStorageKey` | `java.lang.String` |
| `targetFileName` | `java.lang.String` |
| `sceneId` | `java.lang.String` |
| `businessId` | `java.lang.String` |
| `taskName` | `java.lang.String` |
| `diffRules` | `java.lang.String` |
| `expandMap` | `java.util.Map<java.lang.String, java.lang.Object>` |

## `ShortMessageProviderTemplateDto`（10 字段）

`com.seeyon.cip.capability.dto.sms.ShortMessageProviderTemplateDto`

被这些方法当入参：

- `ShortMessageProviderTemplateAppService.createShortMessageTemplateContent()`（包装入参）
- `ShortMessageProviderTemplateAppService.updateTemplateContent()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `id` | `java.lang.Long` |
| `templateId` | `java.lang.Long` |
| `signId` | `java.lang.Long` |
| `templateContent` | `java.lang.String` |
| `providerTemplateCode` | `java.lang.String` |
| `provider` | `java.lang.String` |
| `templateStatusEnum` | `com.seeyon.cip.capability.enums.sms.TemplateStatusEnum` |
| `applicationDescription` | `java.lang.String` |
| `auditDescription` | `java.lang.String` |

## `SmsInspectionDto`（10 字段）

`com.seeyon.cip.capability.dto.sms.SmsInspectionDto`

被这些方法当入参：

- `ShortMessageAppService.inspectSms()`（包装入参）

| 字段 | 类型 |
|---|---|
| `messageContent` | `java.lang.String` |
| `templateContent` | `java.lang.String` |
| `templateName` | `java.lang.String` |
| `code` | `java.lang.String` |
| `providerTemplateContent` | `java.lang.String` |
| `sign` | `java.lang.String` |
| `language` | `java.lang.String` |
| `desPhone` | `java.lang.String` |
| `properties` | `java.util.Map<java.lang.String, java.lang.Object>` |
| `templateParams` | `java.util.Map<java.lang.String, java.lang.Object>` |

## `EventMsgDto`（10 字段）

`com.seeyon.cip.capability.dto.trip.EventMsgDto`

被这些方法当入参：

- `BusinessTripAppService.eventCallback()`（包装入参）

| 字段 | 类型 |
|---|---|
| `eventCode` | `java.lang.String` |
| `timeStamp` | `java.lang.String` |
| `corpId` | `java.lang.String` |
| `signature` | `java.lang.String` |
| `bizId` | `java.lang.String` |
| `msgId` | `java.lang.String` |
| `appKey` | `java.lang.String` |
| `nonce` | `java.lang.String` |
| `content` | `java.lang.String` |
| `sendTime` | `java.lang.String` |

## `MobilePublishAppRequestDto`（10 字段）

`com.seeyon.cip.connector.dto.mobile.MobilePublishAppRequestDto`

被这些方法当入参：

- `MobileApplicationProviderService.publishApp()`（裸参数）

| 字段 | 类型 |
|---|---|
| `id` | `java.lang.Long` |
| `name` | `java.lang.String` |
| `appName` | `java.lang.String` |
| `url` | `java.lang.String` |
| `webUrl` | `java.lang.String` |
| `mobileUrl` | `java.lang.String` |
| `mobilePluginId` | `java.lang.Long` |
| `storageKey` | `java.lang.String` |
| `type` | `com.seeyon.cip.connector.enums.ClientScopeEnum` |
| `thirdConfigId` | `java.lang.Long` |

## `VideoMeetingPersonalCreateDto`（10 字段）

`com.seeyon.cip.provider.dto.video.request.VideoMeetingPersonalCreateDto`

被这些方法当入参：

- `VideoMeetingAppService.createPersonalVideoMeeting()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `meetingTitle` | `java.lang.String` |
| `userId` | `java.lang.String` |
| `password` | `java.lang.String` |
| `startDate` | `java.util.Date` |
| `endDate` | `java.util.Date` |
| `meetingType` | `com.seeyon.cip.provider.enums.video.VideoMeetingTypeApiEnum` |
| `meetingMediaType` | `com.seeyon.cip.provider.enums.video.VideoMeetingMediaTypeEnum` |
| `recordType` | `java.lang.Integer` |
| `duration` | `java.lang.Integer` |

## `UserMappingDetailUpdateReqDto`（9 字段）

`com.seeyon.cip.application.dto.mappingconfig.UserMappingDetailUpdateReqDto`

被这些方法当入参：

- `MappingDetailAppService.modifyUserMappingDetail()`（包装入参）

| 字段 | 类型 |
|---|---|
| `code` | `java.lang.String` |
| `innerUserId` | `java.lang.Long` |
| `innerCode` | `java.lang.String` |
| `loginName` | `java.lang.String` |
| `phoneNumber` | `java.lang.String` |
| `outerUserId` | `java.lang.String` |
| `outerUser` | `java.lang.String` |
| `innerUserName` | `java.lang.String` |
| `detailId` | `java.lang.Long` |

## `DocFileOperateBatchTextWatermarkDto`（9 字段）

`com.seeyon.cip.capability.dto.doc.DocFileOperateBatchTextWatermarkDto`

被这些方法当入参：

- `DocOnlineAppService.cpsOfficeOperateBatchTextWatermark()`（包装入参）

| 字段 | 类型 |
|---|---|
| `textWatermarkDetails` | `java.util.List<com.seeyon.cip.capability.dto.doc.DocBatchTextWatermarkDetailDto>` |
| `content` | `java.lang.String` |
| `size` | `java.lang.Integer` |
| `color` | `java.lang.String` |
| `transparent` | `java.lang.Float` |
| `tilt` | `java.lang.Boolean` |
| `position` | `java.lang.String` |
| `tiled` | `java.lang.Boolean` |
| `sync` | `java.lang.Boolean` |

## `MobileUrlProviderDto`（9 字段）

`com.seeyon.cip.connector.dto.mobile.MobileUrlProviderDto`

被这些方法当入参：

- `MobileApplicationProviderService.getMobileUrlDto()`（裸参数）

| 字段 | 类型 |
|---|---|
| `portalDomain` | `java.lang.String` |
| `portalPath` | `java.lang.String` |
| `mobilePathPara` | `java.util.Map<java.lang.String, java.lang.String>` |
| `webPathPara` | `java.util.Map<java.lang.String, java.lang.String>` |
| `corpId` | `java.lang.String` |
| `appId` | `java.lang.String` |
| `appKey` | `java.lang.String` |
| `thirdApplicationDomain` | `java.lang.String` |
| `json` | `java.lang.String` |

## `TenantAppCreateDto`（9 字段）

`com.seeyon.cip.openapi.operate.dto.TenantAppCreateDto`

被这些方法当入参：

- `OpenCapabilityAppService.createTenantApp()`（包装入参）

| 字段 | 类型 |
|---|---|
| `tenantCode` | `java.lang.Long` |
| `originCode` | `java.lang.String` |
| `appName` | `java.lang.String` |
| `appDescribe` | `java.lang.String` |
| `storageKey` | `java.lang.String` |
| `providerName` | `java.lang.String` |
| `productName` | `java.lang.String` |
| `productVersion` | `java.lang.String` |
| `createOrg` | `java.lang.Long` |

## `UserMappingDetailAddReqDto`（8 字段）

`com.seeyon.cip.application.dto.mappingconfig.UserMappingDetailAddReqDto`

被这些方法当入参：

- `MappingDetailAppService.addUserMappingDetail()`（包装入参）

| 字段 | 类型 |
|---|---|
| `code` | `java.lang.String` |
| `innerUserId` | `java.lang.Long` |
| `innerCode` | `java.lang.String` |
| `loginName` | `java.lang.String` |
| `phoneNumber` | `java.lang.String` |
| `outerUserId` | `java.lang.String` |
| `outerUser` | `java.lang.String` |
| `innerUserName` | `java.lang.String` |

## `DocWrapHeaderDto`（8 字段）

`com.seeyon.cip.capability.dto.doc.DocWrapHeaderDto`

被这些方法当入参：

- `DocOnlineAppService.cpsWrapHeader()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `taskId` | `java.lang.String` |
| `templateStorageKey` | `java.lang.String` |
| `templateFilename` | `java.lang.String` |
| `useTemplateSectionProperty` | `java.lang.Boolean` |
| `flattenSourceStyle` | `java.lang.Boolean` |
| `sampleData` | `java.util.List<com.seeyon.cip.provider.dto.doc.FileBookMarkDto>` |
| `sync` | `java.lang.Boolean` |

## `CommonCompanyAccountDto`（8 字段）

`com.seeyon.cip.capability.dto.econtracts.request.CommonCompanyAccountDto`

被这些方法当入参：

- `CompanyAccountServiceAppService.createOrUpdate()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `orgAccountName` | `java.lang.String` |
| `appId` | `java.lang.String` |
| `appKey` | `java.lang.String` |
| `orgAccountId` | `java.lang.Long` |
| `provider` | `java.lang.String` |
| `adminName` | `java.lang.String` |
| `adminClientId` | `java.lang.Long` |

## `EmailTemplateSendDto`（8 字段）

`com.seeyon.cip.capability.dto.email.EmailTemplateSendDto`

被这些方法当入参：

- `EmailAppService.sendTemplateEmail()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `templateCode` | `java.lang.String` |
| `to` | `java.util.List<java.lang.String>` |
| `subjectParams` | `java.util.Map<java.lang.String, java.lang.Object>` |
| `contentParams` | `java.util.Map<java.lang.String, java.lang.Object>` |
| `contentLink` | `java.lang.String` |
| `memberIdList` | `java.util.List<java.lang.String>` |
| `orgIdList` | `java.util.List<java.lang.String>` |

## `CapabilityCycleCountDto`（8 字段）

`com.seeyon.cip.capability.dto.manage.CapabilityCycleCountDto`

被这些方法当入参：

- `CapabilityManageAppService.setCapabilityCycleCount()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `appKey` | `java.lang.String` |
| `capabilityName` | `java.lang.String` |
| `type` | `com.seeyon.cip.capability.enums.StatisticsTypeEnum` |
| `startTime` | `java.util.Date` |
| `endTime` | `java.util.Date` |
| `feautreCodeList` | `java.util.List<com.seeyon.cip.capability.dto.manage.TotalCountDto>` |
| `appName` | `java.lang.String` |

## `ConnectorCallbackRequestDto`（8 字段）

`com.seeyon.cip.connector.dto.callback.ConnectorCallbackRequestDto`

被这些方法当入参：

- `ConnectorCallbackProviderService.doCallback()`（裸参数）
- `MiddleTableOrgSyncSpiListenerService.dataGovernance()`（裸参数）

| 字段 | 类型 |
|---|---|
| `body` | `java.lang.String` |
| `paraMap` | `java.util.Map<java.lang.String, java.lang.String[]>` |
| `headers` | `java.util.Map<java.lang.String, java.lang.Object>` |
| `inputStreamMap` | `java.util.Map<java.lang.String, java.io.InputStream>` |
| `tid` | `java.lang.String` |
| `type` | `java.lang.String` |
| `channel` | `java.lang.String` |
| `action` | `java.lang.String` |

## `CreateUserDto`（8 字段）

`com.seeyon.cip.openapi.operate.dto.CreateUserDto`

被这些方法当入参：

- `OpenCapabilityAppService.getTicket()`（包装入参）

| 字段 | 类型 |
|---|---|
| `tenantCode` | `java.lang.Long` |
| `originCode` | `java.lang.String` |
| `name` | `java.lang.String` |
| `phoneNumber` | `java.lang.String` |
| `admin` | `java.lang.Boolean` |
| `accountStatus` | `java.lang.Integer` |
| `orgId` | `java.lang.Long` |
| `invalidTime` | `java.util.Date` |

## `PhysicalSealApplyDto`（8 字段）

`com.seeyon.cip.provider.dto.physicalseal.PhysicalSealApplyDto`

被这些方法当入参：

- `PhysicalSealAppService.applyAuthorize()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `applyId` | `java.lang.String` |
| `applyNo` | `java.lang.String` |
| `applyerUserName` | `java.lang.String` |
| `title` | `java.lang.String` |
| `remark` | `java.lang.String` |
| `callBackUrl` | `java.lang.String` |
| `usedSealParamList` | `java.util.List<com.seeyon.cip.provider.dto.physicalseal.PhysicalSealParamDto>` |

## `OrganizationDto`（8 字段）

`com.seeyon.cip.provider.dto.signature.org.OrganizationDto`

被这些方法当入参：

- `SignatureAppService.createOrg()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `orgId` | `java.lang.String` |
| `parentOrgId` | `java.lang.String` |
| `name` | `java.lang.String` |
| `organizationType` | `com.seeyon.cip.provider.enums.signature.OrgTypeEnum` |
| `thirdParentCode` | `java.lang.String` |
| `licenseType` | `com.seeyon.cip.provider.enums.signature.OrgLicenseTypeEnum` |
| `licenseNo` | `java.lang.String` |

## `DocSetBookmarkPermissionsDto`（7 字段）

`com.seeyon.cip.capability.dto.doc.DocSetBookmarkPermissionsDto`

被这些方法当入参：

- `DocOnlineAppService.setBookmarkPermissions()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `taskId` | `java.lang.String` |
| `storageKey` | `java.lang.String` |
| `fileName` | `java.lang.String` |
| `allEditable` | `java.lang.Boolean` |
| `bookmarkPermissions` | `java.util.List<com.seeyon.cip.capability.dto.doc.DocSetBookmarkPermissionsDetailDto>` |
| `sync` | `java.lang.Boolean` |

## `CipEmailUserAccountTestDto`（7 字段）

`com.seeyon.cip.capability.dto.email.CipEmailUserAccountTestDto`

被这些方法当入参：

- `EmailAppService.testSendPersonalEmail()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `appName` | `java.lang.String` |
| `debugging` | `java.lang.Boolean` |
| `emailAccount` | `java.lang.String` |
| `authorizationCode` | `java.lang.String` |
| `toEmail` | `java.lang.String` |
| `status` | `java.lang.Integer` |

## `CipAppUpdateDto`（7 字段）

`com.seeyon.cip.capability.dto.manage.appchannel.CipAppUpdateDto`

被这些方法当入参：

- `CapabilityManageAppService.updateApp()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `id` | `java.lang.Long` |
| `name` | `java.lang.String` |
| `code` | `java.lang.String` |
| `open` | `java.lang.Boolean` |
| `source` | `com.seeyon.cip.capability.enums.appchannel.AppSourceEnum` |
| `config` | `java.lang.Boolean` |

## `MerchantDto`（7 字段）

`com.seeyon.cip.capability.dto.pay.MerchantDto`

被这些方法当入参：

- `MerchantAppService.createMerchant()`（包装入参）
- `MerchantAppService.updateMerchant()`（包装入参）

| 字段 | 类型 |
|---|---|
| `id` | `java.lang.Long` |
| `merchantName` | `java.lang.String` |
| `mchid` | `java.lang.String` |
| `appId` | `java.lang.String` |
| `apiv3Key` | `java.lang.String` |
| `merchantSerialNumber` | `java.lang.String` |
| `platformSerialNumber` | `java.lang.String` |

## `SmsSignCloudDto`（7 字段）

`com.seeyon.cip.capability.dto.sms.SmsSignCloudDto`

被这些方法当入参：

- `ShortMessageSignAppService.createSmsSign()`（包装入参）
- `ShortMessageSignAppService.updateSmsSign()`（包装入参）

| 字段 | 类型 |
|---|---|
| `tags` | `java.lang.String` |
| `signName` | `java.lang.String` |
| `remark` | `java.lang.String` |
| `signStatus` | `java.lang.String` |
| `reason` | `java.lang.String` |
| `qualificationFile` | `com.seeyon.cip.capability.dto.sms.SmsSignCloudDto$SignFile` |
| `commissionFile` | `com.seeyon.cip.capability.dto.sms.SmsSignCloudDto$SignFile` |

## `LinkerSignDto`（7 字段）

`com.seeyon.cip.connector.dto.sign.LinkerSignDto`

被这些方法当入参：

- `LinkerSignService.doSign()`（裸参数）

| 字段 | 类型 |
|---|---|
| `mode` | `java.lang.String` |
| `secret` | `java.lang.String` |
| `signName` | `java.lang.String` |
| `signLocation` | `java.lang.String` |
| `signExpression` | `java.lang.String` |
| `signType` | `java.lang.String` |
| `consumes` | `java.lang.String` |

## `RequestParamDto`（7 字段）

`com.seeyon.cip.connector.dto.sign.RequestParamDto`

被这些方法当入参：

- `LinkerSignService.doSign()`（裸参数）

| 字段 | 类型 |
|---|---|
| `type` | `java.lang.String` |
| `requestBody` | `java.lang.Object` |
| `requestQuery` | `java.util.Map<java.lang.String, java.lang.Object>` |
| `requestHeader` | `java.util.Map<java.lang.String, java.lang.Object>` |
| `requestQueryMappingName` | `java.util.Map<java.lang.String, java.lang.Object>` |
| `requestHeaderMappingName` | `java.util.Map<java.lang.String, java.lang.Object>` |
| `userMap` | `java.util.Map<java.lang.String, java.lang.Object>` |

## `AroundSearchDto`（7 字段）

`com.seeyon.cip.provider.dto.location.AroundSearchDto`

被这些方法当入参：

- `LocationAppService.aroundSearch()`（包装入参）

| 字段 | 类型 |
|---|---|
| `keywords` | `java.lang.String` |
| `location` | `java.lang.String` |
| `types` | `java.lang.String` |
| `radius` | `java.lang.String` |
| `pageSize` | `java.lang.String` |
| `pageNum` | `java.lang.String` |
| `callback` | `java.lang.String` |

## `RefundParamsDto`（7 字段）

`com.seeyon.cip.provider.dto.pay.RefundParamsDto`

被这些方法当入参：

- `PayAppService.refund()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `mchid` | `java.lang.String` |
| `outTradeNo` | `java.lang.String` |
| `outRefundNo` | `java.lang.String` |
| `reason` | `java.lang.String` |
| `total` | `java.lang.Long` |
| `refund` | `java.lang.Long` |

## `PhysicalSealImageDto`（7 字段）

`com.seeyon.cip.provider.dto.physicalseal.PhysicalSealImageDto`

被这些方法当入参：

- `PhysicalSealAppService.getImage()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `filename` | `java.lang.String` |
| `url` | `java.lang.String` |
| `urls` | `java.lang.String` |
| `fileType` | `java.lang.String` |
| `type` | `java.lang.String` |
| `userId` | `java.lang.Long` |

## `PhysicalSealReWriteDto`（7 字段）

`com.seeyon.cip.provider.dto.physicalseal.PhysicalSealReWriteDto`

被这些方法当入参：

- `PhysicalSealAppService.reWrite()`（包装入参）
- `PhysicalSealAppService.eventCallback()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `applyId` | `java.lang.String` |
| `sealId` | `java.lang.String` |
| `usedCount` | `java.lang.Integer` |
| `startTime` | `java.lang.String` |
| `address` | `java.lang.String` |
| `operation` | `java.lang.String` |

## `InitiateSignDto`（7 字段）

`com.seeyon.cip.provider.dto.signature.sign.InitiateSignDto`

被这些方法当入参：

- `SignatureAppService.initiateSign()`（包装入参）

| 字段 | 类型 |
|---|---|
| `subject` | `java.lang.String` |
| `signFileList` | `java.util.List<com.seeyon.cip.provider.dto.signature.sign.FileInfoDto>` |
| `attachmentList` | `java.util.List<com.seeyon.cip.provider.dto.signature.sign.FileInfoDto>` |
| `signerInfoList` | `java.util.List<com.seeyon.cip.provider.dto.signature.sign.SignerInfoDto>` |
| `initiatorInfo` | `com.seeyon.cip.provider.dto.signature.sign.InitiatorInfoDto` |
| `signFlowExpireTime` | `java.util.Date` |
| `businessNo` | `java.lang.String` |

## `InitiateSignFreeDto`（7 字段）

`com.seeyon.cip.provider.dto.signature.sign.InitiateSignFreeDto`

被这些方法当入参：

- `SignatureAppService.initiateSignFree()`（包装入参）

| 字段 | 类型 |
|---|---|
| `subject` | `java.lang.String` |
| `signFileList` | `java.util.List<com.seeyon.cip.provider.dto.signature.sign.FileInfoDto>` |
| `attachmentList` | `java.util.List<com.seeyon.cip.provider.dto.signature.sign.FileInfoDto>` |
| `signerInfoList` | `java.util.List<com.seeyon.cip.provider.dto.signature.sign.SignerInfoFreeDto>` |
| `initiatorInfo` | `com.seeyon.cip.provider.dto.signature.sign.InitiatorInfoDto` |
| `signFlowExpireTime` | `java.util.Date` |
| `businessNo` | `java.lang.String` |

## `PluginAffairBatchDto`（6 字段）

`com.seeyon.cip.application.dto.PluginAffairBatchDto`

被这些方法当入参：

- `ApplicationAffairAppService.addModifyPluginAffair()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `capabilityId` | `java.lang.Long` |
| `linkerCode` | `java.lang.String` |
| `affairAction` | `com.seeyon.cip.application.enums.AffairActionEnum` |
| `idType` | `com.seeyon.cip.application.enums.UserIdTypeEnum` |
| `affairList` | `java.util.List<com.seeyon.cip.application.dto.PluginAffairDetailDto>` |

## `OrgMappingDetailUpdateReqDto`（6 字段）

`com.seeyon.cip.application.dto.mappingconfig.OrgMappingDetailUpdateReqDto`

被这些方法当入参：

- `MappingDetailAppService.modifyOrgMappingDetail()`（包装入参）

| 字段 | 类型 |
|---|---|
| `code` | `java.lang.String` |
| `detailId` | `java.lang.Long` |
| `innerId` | `java.lang.Long` |
| `innerCode` | `java.lang.String` |
| `outerId` | `java.lang.String` |
| `outerCode` | `java.lang.String` |

## `UpdateReqDto`（6 字段）

`com.seeyon.cip.basic.dto.card.UpdateReqDto`

被这些方法当入参：

- `OrgIntegrationAppService.updateCardInfo()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `id` | `java.lang.Long` |
| `showTypeEnum` | `com.seeyon.cip.basic.enums.card.ShowTypeEnum` |
| `staffCardDefaultDto` | `com.seeyon.cip.basic.dto.card.StaffCardDefaultDto` |
| `staffCardThirdDto` | `com.seeyon.cip.basic.dto.card.StaffCardThirdDto` |
| `staffCardNativeDto` | `com.seeyon.cip.basic.dto.card.StaffCardNativeDto` |

## `AccountDetailReqDto`（6 字段）

`com.seeyon.cip.capability.dto.bankpay.account.AccountDetailReqDto`

被这些方法当入参：

- `BankpayAppService.accountDetail()`（裸参数）
- `BankpayAppService.accountSummary()`（裸参数）

| 字段 | 类型 |
|---|---|
| `userName` | `java.lang.String` |
| `accountNo` | `java.lang.String` |
| `lowAmount` | `java.math.BigDecimal` |
| `upAmount` | `java.math.BigDecimal` |
| `startDate` | `java.lang.String` |
| `endDate` | `java.lang.String` |

## `PaymentBankInformationReqDto`（6 字段）

`com.seeyon.cip.capability.dto.bankpay.other.PaymentBankInformationReqDto`

被这些方法当入参：

- `BankpayAppService.paymentBankInformation()`（包装入参）

| 字段 | 类型 |
|---|---|
| `userName` | `java.lang.String` |
| `provinceName` | `java.lang.String` |
| `cityName` | `java.lang.String` |
| `bankName` | `java.lang.String` |
| `tgfi` | `java.lang.String` |
| `tgname` | `java.lang.String` |

## `DocFileConvertDto`（6 字段）

`com.seeyon.cip.capability.dto.doc.DocFileConvertDto`

被这些方法当入参：

- `DocOnlineAppService.cpsOfficeConvert()`（包装入参）

| 字段 | 类型 |
|---|---|
| `taskId` | `java.lang.String` |
| `storageKey` | `java.lang.String` |
| `fileName` | `java.lang.String` |
| `targetFileFormat` | `java.lang.String` |
| `sync` | `java.lang.Boolean` |
| `sceneType` | `java.lang.Integer` |

## `DocQueryBookmarkDto`（6 字段）

`com.seeyon.cip.capability.dto.doc.DocQueryBookmarkDto`

被这些方法当入参：

- `DocOnlineAppService.cpsOfficeBookmark()`（包装入参）

| 字段 | 类型 |
|---|---|
| `taskId` | `java.lang.String` |
| `storageKey` | `java.lang.String` |
| `fileName` | `java.lang.String` |
| `sync` | `java.lang.Boolean` |
| `bookmarkType` | `java.lang.String` |
| `bookmarkName` | `java.lang.String` |

## `CipEmailLimitConfigDto`（6 字段）

`com.seeyon.cip.capability.dto.email.CipEmailLimitConfigDto`

被这些方法当入参：

- `EmailPrivateAppService.insertOrUpdateEmailLimitConfig()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `dayLimit` | `java.lang.Integer` |
| `hourLimit` | `java.lang.Integer` |
| `minuteLimit` | `java.lang.Integer` |
| `isLimit` | `java.lang.Boolean` |
| `whiteList` | `java.lang.String` |

## `CipEmailUserAccountDto`（6 字段）

`com.seeyon.cip.capability.dto.email.CipEmailUserAccountDto`

被这些方法当入参：

- `EmailAppService.insertOrUpdate()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `emailAccount` | `java.lang.String` |
| `authorizationCode` | `java.lang.String` |
| `toEmail` | `java.lang.String` |
| `status` | `java.lang.Integer` |
| `captcha` | `java.lang.String` |

## `InvoiceCheckDto`（6 字段）

`com.seeyon.cip.capability.dto.invoice.request.InvoiceCheckDto`

被这些方法当入参：

- `InvoiceAppService.verificationInvoice()`（包装入参）

| 字段 | 类型 |
|---|---|
| `batchNO` | `java.lang.String` |
| `itemDtoList` | `java.util.List<com.seeyon.cip.capability.dto.invoice.request.InvoiceCheckItemDto>` |
| `debugging` | `java.lang.Boolean` |
| `count` | `java.lang.Integer` |
| `externalAppId` | `java.lang.Long` |
| `provider` | `java.lang.String` |

## `InvoiceCheckPageReqDto`（6 字段）

`com.seeyon.cip.capability.dto.invoice.request.InvoiceCheckPageReqDto`

被这些方法当入参：

- `InvoiceAppService.queryCheckPage()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `purchaserRegisterNum` | `java.lang.String` |
| `purchaserName` | `java.lang.String` |
| `batchNO` | `java.lang.String` |
| `invoiceCode` | `java.lang.String` |
| `pageInfo` | `com.seeyon.boot.transport.PageInfo` |

## `AuthConfigDto`（6 字段）

`com.seeyon.cip.capability.dto.manage.AuthConfigDto`

被这些方法当入参：

- `CapabilityManageAppService.authConfigEdit()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `capabilityName` | `java.lang.String` |
| `provider` | `java.lang.String` |
| `type` | `com.seeyon.cip.capability.enums.StatisticsTypeEnum` |
| `startTime` | `java.util.Date` |
| `endTime` | `java.util.Date` |

## `CipAppCreateDto`（6 字段）

`com.seeyon.cip.capability.dto.manage.appchannel.CipAppCreateDto`

被这些方法当入参：

- `CapabilityManageAppService.createApp()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `name` | `java.lang.String` |
| `code` | `java.lang.String` |
| `open` | `java.lang.Boolean` |
| `source` | `com.seeyon.cip.capability.enums.appchannel.AppSourceEnum` |
| `config` | `java.lang.Boolean` |

## `MobilePluginAppletOpenCommitDto`（6 字段）

`com.seeyon.cip.capability.dto.mobileplugin.applet.MobilePluginAppletOpenCommitDto`

被这些方法当入参：

- `MobilePluginAppletAppService.uploadCode()`（包装入参）

| 字段 | 类型 |
|---|---|
| `authAppId` | `java.lang.String` |
| `templateId` | `java.lang.String` |
| `refreshToken` | `java.lang.String` |
| `userVersion` | `java.lang.String` |
| `auditVersionDesc` | `java.lang.String` |
| `commitExtInfo` | `java.lang.String` |

## `OcrRequestDto`（6 字段）

`com.seeyon.cip.capability.dto.ocr.OcrRequestDto`

被这些方法当入参：

- `OcrAppService.getIdCardFrontData()`（包装入参）
- `OcrAppService.getIdCardBackData()`（包装入参）
- `OcrAppService.getBankCardData()`（包装入参）
- `OcrAppService.getBusinessCardData()`（包装入参）
- `OcrAppService.getBusinessLicenseData()`（包装入参）
- `OcrAppService.getTaxInvoiceData()`（包装入参）
- … 另 12 处

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `ocrCapabilityApiEnum` | `com.seeyon.cip.provider.enums.ocr.OcrCapabilityApiEnum` |
| `imageBase64` | `java.lang.String` |
| `imageUrl` | `java.lang.String` |
| `storageKey` | `java.lang.String` |
| `templateCode` | `java.lang.String` |

## `TableInfoDto`（6 字段）

`com.seeyon.cip.connector.dto.database.TableInfoDto`

被这些方法当入参：

- `BaseConfigAppService.selectTableInfo()`（包装入参）

| 字段 | 类型 |
|---|---|
| `id` | `java.lang.Long` |
| `name` | `java.lang.String` |
| `column` | `java.lang.String` |
| `type` | `java.lang.String` |
| `comment` | `java.lang.String` |
| `notNull` | `java.lang.Boolean` |

## `MobilePlatformSignatureDto`（6 字段）

`com.seeyon.cip.connector.dto.mobile.MobilePlatformSignatureDto`

被这些方法当入参：

- `MobileApplicationProviderService.getSignature()`（裸参数）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `appId` | `java.lang.String` |
| `type` | `java.lang.String` |
| `url` | `java.lang.String` |
| `agentType` | `java.lang.Boolean` |
| `agent` | `java.lang.String` |

## `SsoRequestDto`（6 字段）

`com.seeyon.cip.connector.dto.sso.SsoRequestDto`

被这些方法当入参：

- `SsoExecutorAppService.ssoLongin()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `infoId` | `java.lang.Long` |
| `url` | `java.lang.String` |
| `userBind` | `java.lang.Boolean` |
| `clientType` | `com.seeyon.cip.connector.enums.SsoClientTypeEnum` |
| `extendParams` | `java.util.Map<java.lang.String, java.lang.Object>` |

## `PluginAffairBatchDto`（6 字段）

`com.seeyon.cip.plug.dto.PluginAffairBatchDto`

被这些方法当入参：

- `PluginAffairAppService.addModifyPluginAffair()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `capabilityId` | `java.lang.Long` |
| `linkerCode` | `java.lang.String` |
| `affairAction` | `com.seeyon.cip.plug.enums.AffairActionEnum` |
| `idType` | `com.seeyon.cip.plug.enums.UserIdTypeEnum` |
| `affairList` | `java.util.List<com.seeyon.cip.plug.dto.PluginAffairDetailDto>` |

## `PhysicalSealMemberDto`（6 字段）

`com.seeyon.cip.provider.dto.physicalseal.PhysicalSealMemberDto`

被这些方法当入参：

- `PhysicalSealAppService.syncMember()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `id` | `java.lang.String` |
| `username` | `java.lang.String` |
| `realname` | `java.lang.String` |
| `phone` | `java.lang.String` |
| `userDepartList` | `java.util.List<com.seeyon.cip.provider.dto.physicalseal.PhysicalSealUserDepartDto>` |

## `TripApplyApproveRequestDto`（6 字段）

`com.seeyon.cip.provider.dto.trip.TripApplyApproveRequestDto`

被这些方法当入参：

- `BusinessTripAppService.applyApprove()`（包装入参）

| 字段 | 类型 |
|---|---|
| `applyId` | `java.lang.String` |
| `status` | `java.lang.Integer` |
| `userName` | `java.lang.String` |
| `operateTime` | `java.lang.String` |
| `note` | `java.lang.String` |
| `userId` | `java.lang.String` |

## `TripCommonApplySyncRequestDto`（6 字段）

`com.seeyon.cip.provider.dto.trip.TripCommonApplySyncRequestDto`

被这些方法当入参：

- `BusinessTripAppService.commonApplySync()`（包装入参）

| 字段 | 类型 |
|---|---|
| `applyId` | `java.lang.Long` |
| `thirdpartyFlowId` | `java.lang.String` |
| `status` | `java.lang.Integer` |
| `userId` | `java.lang.String` |
| `remark` | `java.lang.String` |
| `bizCategory` | `java.lang.Integer` |

## `TripExceedApplySyncRequestDto`（6 字段）

`com.seeyon.cip.provider.dto.trip.TripExceedApplySyncRequestDto`

被这些方法当入参：

- `BusinessTripAppService.exceedApplySync()`（包装入参）

| 字段 | 类型 |
|---|---|
| `applyId` | `java.lang.Long` |
| `thirdpartyFlowId` | `java.lang.String` |
| `status` | `java.lang.Integer` |
| `userId` | `java.lang.String` |
| `remark` | `java.lang.String` |
| `bizCategory` | `java.lang.Integer` |

## `VideoMeetingRoomResourceDto`（6 字段）

`com.seeyon.cip.provider.dto.video.request.VideoMeetingRoomResourceDto`

被这些方法当入参：

- `VideoMeetingAppService.addMeetingRoomResource()`（包装入参）
- `VideoMeetingAppService.updateMeetingRoomResource()`（包装入参）

| 字段 | 类型 |
|---|---|
| `id` | `java.lang.Long` |
| `meetingRoomId` | `java.lang.String` |
| `userId` | `java.lang.String` |
| `resourceType` | `java.lang.Integer` |
| `meetingRoomName` | `java.lang.String` |
| `manual` | `java.lang.Integer` |

## `VideoMeetingRoomSelectDto`（6 字段）

`com.seeyon.cip.provider.dto.video.request.VideoMeetingRoomSelectDto`

被这些方法当入参：

- `VideoMeetingAppService.selectVideoMeetingRoom()`（包装入参）
- `VideoMeetingAppService.selectMemberMeetingRoom()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `userId` | `java.lang.String` |
| `offset` | `java.lang.Integer` |
| `limit` | `java.lang.Integer` |
| `searchKey` | `java.lang.String` |
| `status` | `java.lang.Integer` |

## `VideoMeetingRoomUpdateDto`（6 字段）

`com.seeyon.cip.provider.dto.video.request.VideoMeetingRoomUpdateDto`

被这些方法当入参：

- `VideoMeetingAppService.updateVideoMeetingRoom()`（包装入参）

| 字段 | 类型 |
|---|---|
| `userRoomId` | `java.lang.String` |
| `roomUserId` | `java.lang.String` |
| `roomName` | `java.lang.String` |
| `allowGustFirst` | `java.lang.Boolean` |
| `chairPwd` | `java.lang.String` |
| `gustPwd` | `java.lang.String` |

## `AppUrlRequestDto`（5 字段）

`com.seeyon.cip.application.dto.AppUrlRequestDto`

被这些方法当入参：

- `ApplicationMobileAppService.getAppUrl()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `tenantCode` | `java.lang.Long` |
| `originCode` | `java.lang.String` |
| `appId` | `java.lang.String` |
| `admin` | `java.lang.Boolean` |

## `OrgMappingDetailAddReqDto`（5 字段）

`com.seeyon.cip.application.dto.mappingconfig.OrgMappingDetailAddReqDto`

被这些方法当入参：

- `MappingDetailAppService.addOrgMappingDetail()`（包装入参）

| 字段 | 类型 |
|---|---|
| `code` | `java.lang.String` |
| `innerId` | `java.lang.Long` |
| `innerCode` | `java.lang.String` |
| `outerId` | `java.lang.String` |
| `outerCode` | `java.lang.String` |

## `AccountInDetailReqDto`（5 字段）

`com.seeyon.cip.capability.dto.bankpay.account.AccountInDetailReqDto`

被这些方法当入参：

- `BankpayAppService.accountInDetail()`（包装入参）

| 字段 | 类型 |
|---|---|
| `userName` | `java.lang.String` |
| `accountNo` | `java.lang.String` |
| `tranDate` | `java.lang.String` |
| `tranNo` | `java.lang.String` |
| `sumTranNo` | `java.lang.String` |

## `DocAuthorityInfoProxyRequestDto`（5 字段）

`com.seeyon.cip.capability.dto.doc.DocAuthorityInfoProxyRequestDto`

被这些方法当入参：

- `DocGeneralizeAppService.getAuthorityInfoProxy()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `storageKey` | `java.lang.String` |
| `userIdList` | `java.util.List<java.lang.Long>` |
| `docOperateEnum` | `com.seeyon.cip.capability.enums.doc.DocOperateEnum` |
| `authorityInfo` | `java.lang.String` |

## `DocAuthorityInfoRequestDto`（5 字段）

`com.seeyon.cip.capability.dto.doc.DocAuthorityInfoRequestDto`

被这些方法当入参：

- `DocOnlineAppService.getAuthorityInfo()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `appName` | `java.lang.String` |
| `storageKey` | `java.lang.String` |
| `userIdList` | `java.util.List<java.lang.Long>` |
| `docOperateEnum` | `com.seeyon.cip.capability.enums.doc.DocOperateEnum` |

## `DocExtractPicReqDto`（5 字段）

`com.seeyon.cip.capability.dto.doc.DocExtractPicReqDto`

被这些方法当入参：

- `DocOnlineAppService.extractPictures()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `taskId` | `java.lang.String` |
| `storageKey` | `java.lang.String` |
| `fileName` | `java.lang.String` |
| `sync` | `java.lang.Boolean` |

## `DocFileOperateCleanDto`（5 字段）

`com.seeyon.cip.capability.dto.doc.DocFileOperateCleanDto`

被这些方法当入参：

- `DocOnlineAppService.cpsOfficeOperateClean()`（包装入参）

| 字段 | 类型 |
|---|---|
| `taskId` | `java.lang.String` |
| `storageKey` | `java.lang.String` |
| `fileName` | `java.lang.String` |
| `cleanOptions` | `java.util.List<java.lang.String>` |
| `sync` | `java.lang.Boolean` |

## `DocFileSingleConvertDto`（5 字段）

`com.seeyon.cip.capability.dto.doc.DocFileSingleConvertDto`

被这些方法当入参：

- `DocOnlineAppService.cpsOfficeConvertPdfToSinglePng()`（包装入参）
- `DocOnlineAppService.cpsOfficeConvertPdfToHtml()`（包装入参）

| 字段 | 类型 |
|---|---|
| `taskId` | `java.lang.String` |
| `storageKey` | `java.lang.String` |
| `fileName` | `java.lang.String` |
| `targetFileFormat` | `java.lang.String` |
| `pageIndex` | `java.lang.Integer` |

## `DocFileVersionPageRequestDto`（5 字段）

`com.seeyon.cip.capability.dto.doc.DocFileVersionPageRequestDto`

被这些方法当入参：

- `DocOnlineAppService.selectDocFileVersionPage()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `appName` | `java.lang.String` |
| `storageKey` | `java.lang.String` |
| `docFileId` | `java.lang.String` |
| `pageInfo` | `com.seeyon.boot.transport.PageInfo` |

## `CapabilityStatisticalRequestDto`（5 字段）

`com.seeyon.cip.capability.dto.log.CapabilityStatisticalRequestDto`

被这些方法当入参：

- `CapabilityAccessLogDbAppService.countByConditions()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `capabilityEnum` | `java.lang.String` |
| `appInfoList` | `java.util.List<com.seeyon.cip.capability.dto.log.AppInfoDto>` |
| `startDate` | `java.lang.String` |
| `endDate` | `java.lang.String` |

## `DiffPageReqDto`（5 字段）

`com.seeyon.cip.capability.dto.missive.DiffPageReqDto`

被这些方法当入参：

- `IntelligentMissiveAppService.queryDocDiffPage()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `sceneId` | `java.lang.String` |
| `businessId` | `java.lang.String` |
| `docName` | `java.lang.String` |
| `pageInfo` | `com.seeyon.boot.transport.PageInfo` |

## `ExtractingTaskReqDto`（5 字段）

`com.seeyon.cip.capability.dto.missive.ExtractingTaskReqDto`

被这些方法当入参：

- `IntelligentMissiveAppService.createExtractingTask()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `storageKey` | `java.lang.String` |
| `fileName` | `java.lang.String` |
| `taskName` | `java.lang.String` |
| `featuresType` | `java.lang.Integer` |

## `ProofreadTaskReqDto`（5 字段）

`com.seeyon.cip.capability.dto.missive.ProofreadTaskReqDto`

被这些方法当入参：

- `IntelligentMissiveAppService.createOnlineProofread()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `text` | `java.lang.String` |
| `storageKey` | `java.lang.String` |
| `fileName` | `java.lang.String` |
| `sync` | `java.lang.Boolean` |

## `InvoiceVerificationRequestDto`（5 字段）

`com.seeyon.cip.capability.dto.ocr.InvoiceVerificationRequestDto`

被这些方法当入参：

- `OcrAppService.verificationInvoice()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `invoiceCode` | `java.lang.String` |
| `invoiceNo` | `java.lang.String` |
| `invoiceDate` | `java.lang.String` |
| `additional` | `java.lang.String` |

## `OfdSealReqDto`（5 字段）

`com.seeyon.cip.capability.dto.ofd.OfdSealReqDto`

被这些方法当入参：

- `OfdAppService.getSealInfo()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `storageKey` | `java.lang.String` |
| `fileName` | `java.lang.String` |
| `fileType` | `com.seeyon.cip.provider.enums.ofd.OfdFileTypeEnum` |
| `loginName` | `java.lang.String` |

## `SignatureSealReqDto`（5 字段）

`com.seeyon.cip.capability.dto.signature.SignatureSealReqDto`

被这些方法当入参：

- `SignatureAppService.getSealInfo()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `storageKey` | `java.lang.String` |
| `fileName` | `java.lang.String` |
| `fileType` | `com.seeyon.cip.provider.enums.ofd.OfdFileTypeEnum` |
| `loginName` | `java.lang.String` |

## `SmsSendDto`（5 字段）

`com.seeyon.cip.capability.dto.sms.SmsSendDto`

被这些方法当入参：

- `ShortMessageAppService.sendShortMessage()`（包装入参）
- `ShortMessageAppService.sendSycShortMessage()`（包装入参）
- `ShortMessageAppService.sendShortMessageAsync()`（裸参数）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `code` | `java.lang.String` |
| `language` | `java.lang.String` |
| `paramsMap` | `java.util.Map<java.lang.String, java.lang.Object>` |
| `desPhone` | `java.lang.String` |

## `AuthenticationDto`（5 字段）

`com.seeyon.cip.connector.dto.authentication.AuthenticationDto`

被这些方法当入参：

- `LinkerSecurityService.doAuthentication()`（裸参数）
- `LinkerSecurityService.doVerification()`（裸参数）

| 字段 | 类型 |
|---|---|
| `authId` | `java.lang.Long` |
| `detailId` | `java.lang.Long` |
| `json` | `java.lang.String` |
| `params` | `java.util.Map<java.lang.String, java.lang.Object>` |
| `user` | `com.seeyon.cip.connector.dto.authentication.AuthenticationUserDto` |

## `ExecuteRequestDto`（5 字段）

`com.seeyon.cip.connector.dto.execute.ExecuteRequestDto`

被这些方法当入参：

- `LinkerAppService.execute()`（包装入参）

| 字段 | 类型 |
|---|---|
| `detailId` | `java.lang.Long` |
| `requestMap` | `java.util.Map<java.lang.String, java.lang.Object>` |
| `invoker` | `java.lang.String` |
| `debugging` | `java.lang.Boolean` |
| `pageInfo` | `com.seeyon.boot.transport.PageInfo` |

## `MobileSsoUserRequestDto`（5 字段）

`com.seeyon.cip.connector.dto.mobile.sso.MobileSsoUserRequestDto`

被这些方法当入参：

- `MobileApplicationProviderService.getMobileSsoUserDto()`（裸参数）

| 字段 | 类型 |
|---|---|
| `type` | `java.lang.String` |
| `appId` | `java.lang.String` |
| `code` | `java.lang.String` |
| `agentId` | `java.lang.String` |
| `extData` | `java.util.Map<java.lang.String, java.lang.String>` |

## `ThirdTemplateDataSpiReqDto`（5 字段）

`com.seeyon.cip.connector.dto.template.ThirdTemplateDataSpiReqDto`

被这些方法当入参：

- `CipThirdAffairService.queryThirdAffairFieldData()`（裸参数）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `linkerCode` | `java.lang.String` |
| `templateCode` | `java.lang.String` |
| `fields` | `java.util.List<java.lang.String>` |
| `thirdIds` | `java.util.List<java.lang.String>` |

## `AppUrlRequestDto`（5 字段）

`com.seeyon.cip.openapi.operate.dto.AppUrlRequestDto`

被这些方法当入参：

- `OpenCapabilityAppService.getAppUrl()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `tenantCode` | `java.lang.Long` |
| `originCode` | `java.lang.String` |
| `appId` | `java.lang.String` |
| `admin` | `java.lang.Boolean` |

## `CipMessageDeliveryDto`（5 字段）

`com.seeyon.cip.openapi.operate.dto.CipMessageDeliveryDto`

被这些方法当入参：

- `CipMessageAppService.deliveryMqMessage()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `serviceName` | `java.lang.String` |
| `messageClass` | `java.lang.String` |
| `eventKey` | `java.lang.String` |
| `eventJson` | `java.lang.String` |

## `KeywordSearchDto`（5 字段）

`com.seeyon.cip.provider.dto.location.KeywordSearchDto`

被这些方法当入参：

- `LocationAppService.keywordSearch()`（包装入参）

| 字段 | 类型 |
|---|---|
| `keywords` | `java.lang.String` |
| `types` | `java.lang.String` |
| `pageSize` | `java.lang.String` |
| `pageNum` | `java.lang.String` |
| `callback` | `java.lang.String` |

## `PhysicalSealDeptDto`（5 字段）

`com.seeyon.cip.provider.dto.physicalseal.PhysicalSealDeptDto`

被这些方法当入参：

- `PhysicalSealAppService.syncDept()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `id` | `java.lang.String` |
| `name` | `java.lang.String` |
| `parentId` | `java.lang.String` |
| `children` | `java.util.List<com.seeyon.cip.provider.dto.physicalseal.PhysicalSealDeptDto>` |

## `OrganizationUpdateDto`（5 字段）

`com.seeyon.cip.provider.dto.signature.org.OrganizationUpdateDto`

被这些方法当入参：

- `SignatureAppService.updateOrg()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `thirdOrgId` | `java.lang.String` |
| `name` | `java.lang.String` |
| `licenseType` | `com.seeyon.cip.provider.enums.signature.OrgLicenseTypeEnum` |
| `licenseNo` | `java.lang.String` |

## `PreSignDto`（5 字段）

`com.seeyon.cip.provider.dto.signature.sign.PreSignDto`

被这些方法当入参：

- `SignatureAppService.preSign()`（包装入参）

| 字段 | 类型 |
|---|---|
| `businessNo` | `java.lang.String` |
| `subject` | `java.lang.String` |
| `userSealsDtos` | `java.util.List<com.seeyon.cip.provider.dto.signature.sign.UserSealsDto>` |
| `fileKeyList` | `java.util.List<java.lang.String>` |
| `isBind` | `java.lang.Boolean` |

## `VideoMeetingUserDto`（5 字段）

`com.seeyon.cip.provider.dto.video.VideoMeetingUserDto`

被这些方法当入参：

- `VideoMeetingAppService.addMeetingUser()`（包装入参）

| 字段 | 类型 |
|---|---|
| `name` | `java.lang.String` |
| `account` | `java.lang.String` |
| `userId` | `java.lang.String` |
| `pwd` | `java.lang.String` |
| `status` | `java.lang.Integer` |

## `VideoMeetingRecordSelectDto`（5 字段）

`com.seeyon.cip.provider.dto.video.request.VideoMeetingRecordSelectDto`

被这些方法当入参：

- `VideoMeetingAppService.getMeetingRecord()`（包装入参）

| 字段 | 类型 |
|---|---|
| `startTime` | `java.util.Date` |
| `endTime` | `java.util.Date` |
| `meetingUUID` | `java.lang.String` |
| `userID` | `java.lang.String` |
| `roomUserId` | `java.lang.String` |

## `PluginAffairGroupDto`（4 字段）

`com.seeyon.cip.application.dto.PluginAffairGroupDto`

被这些方法当入参：

- `ApplicationAffairAppService.processRevoke()`（包装入参）
- `ApplicationAffairAppService.processTerminate()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `capabilityId` | `java.lang.Long` |
| `objectId` | `java.lang.String` |
| `externalAffairId` | `java.lang.String` |

## `PluginMessageBatchDto`（4 字段）

`com.seeyon.cip.application.dto.PluginMessageBatchDto`

被这些方法当入参：

- `ApplicationMessageAppService.syncPluginMessage()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `capabilityId` | `java.lang.Long` |
| `idType` | `com.seeyon.cip.application.enums.UserIdTypeEnum` |
| `messageList` | `java.util.List<com.seeyon.cip.application.dto.PluginMessageDetailDto>` |

## `RetryPushAffairOpenApiDto`（4 字段）

`com.seeyon.cip.application.dto.RetryPushAffairOpenApiDto`

被这些方法当入参：

- `ApplicationAffairAppService.retryPushAffair()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `linkerId` | `java.lang.Long` |
| `todoMode` | `java.lang.String` |
| `affairIds` | `java.util.List<java.lang.Long>` |

## `MiddleTableDeleteReqDto`（4 字段）

`com.seeyon.cip.application.dto.middletable.MiddleTableDeleteReqDto`

被这些方法当入参：

- `MiddleTableAppService.delete()`（包装入参）

| 字段 | 类型 |
|---|---|
| `linkerId` | `java.lang.Long` |
| `code` | `java.lang.String` |
| `thirdId` | `java.lang.String` |
| `dimension` | `com.seeyon.cip.application.enums.MiddleTableDimensionEnum` |

## `AccountNameCheckReqDto`（4 字段）

`com.seeyon.cip.capability.dto.bankpay.other.AccountNameCheckReqDto`

被这些方法当入参：

- `BankpayAppService.accountNameCheck()`（包装入参）

| 字段 | 类型 |
|---|---|
| `userName` | `java.lang.String` |
| `accountNo` | `java.lang.String` |
| `accountName` | `java.lang.String` |
| `accountType` | `java.lang.Integer` |

## `DocCheckContentRequestDto`（4 字段）

`com.seeyon.cip.capability.dto.doc.DocCheckContentRequestDto`

被这些方法当入参：

- `DocOnlineAppService.checkContent()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `compute` | `java.lang.Boolean` |
| `storageKey` | `java.lang.String` |
| `fileName` | `java.lang.String` |

## `DocPdfEncryptRequestDto`（4 字段）

`com.seeyon.cip.capability.dto.doc.DocPdfEncryptRequestDto`

被这些方法当入参：

- `DocOnlineAppService.encryptPdfProtection()`（包装入参）

| 字段 | 类型 |
|---|---|
| `storageKey` | `java.lang.String` |
| `fileName` | `java.lang.String` |
| `ownerPassword` | `java.lang.String` |
| `permission` | `com.seeyon.cip.capability.dto.doc.DocPdfPermissionDto` |

## `DocUserNotifyReqDto`（4 字段）

`com.seeyon.cip.capability.dto.doc.DocUserNotifyReqDto`

被这些方法当入参：

- `DocOnlineAppService.userNotify()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `userId` | `java.lang.String` |
| `loginType` | `com.seeyon.cip.provider.enums.doc.CipClientTypeEnum` |
| `logOutTime` | `java.lang.Long` |

## `BaseContractsRequestDto`（4 字段）

`com.seeyon.cip.capability.dto.econtracts.BaseContractsRequestDto`

被这些方法当入参：

- `ContractsCallBackAppService.callBack()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `contractsCapabilityEnums` | `com.seeyon.cip.capability.enums.econtracts.ContractsCapabilityEnums` |
| `accountId` | `java.lang.Long` |
| `requestParam` | `com.seeyon.cip.capability.dto.econtracts.CommonContractDataDto` |

## `InvoiceImageUploadReqDto`（4 字段）

`com.seeyon.cip.capability.dto.invoice.request.InvoiceImageUploadReqDto`

被这些方法当入参：

- `InvoiceImageAppService.uploadImageFile()`（包装入参）

| 字段 | 类型 |
|---|---|
| `billNo` | `java.lang.String` |
| `source` | `java.lang.String` |
| `summaryId` | `java.lang.String` |
| `fileList` | `java.util.List<com.seeyon.cip.capability.dto.invoice.request.InvoiceImageUploadItemReqDto>` |

## `EventCallbackConfigQueryDto`（4 字段）

`com.seeyon.cip.capability.dto.manage.EventCallbackConfigQueryDto`

被这些方法当入参：

- `CapabilityManageAppService.selectCallbackConfig()`（包装入参）
- `CapabilityManageAppService.refreshEventToken()`（包装入参）
- `CapabilityManageAppService.modifyEventToken()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `capabilityEnum` | `com.seeyon.cip.provider.enums.CapabilityEnum` |
| `provider` | `java.lang.String` |
| `token` | `java.lang.String` |

## `OperateChannelEnableDto`（4 字段）

`com.seeyon.cip.capability.dto.manage.OperateChannelEnableDto`

被这些方法当入参：

- `CapabilityManageAppService.operationEnableChannel()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `capabilityName` | `java.lang.String` |
| `enable` | `java.lang.Boolean` |
| `providerCode` | `java.lang.String` |

## `QueryFeatureWithChannelDto`（4 字段）

`com.seeyon.cip.capability.dto.manage.appchannel.QueryFeatureWithChannelDto`

被这些方法当入参：

- `CapabilityManageAppService.queryFeatureWithChannelByAbilityEnum()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `capabilityEnum` | `java.util.List<com.seeyon.cip.provider.enums.CapabilityEnum>` |
| `appId` | `java.lang.Long` |
| `code` | `java.lang.String` |

## `AssistReadingReqDto`（4 字段）

`com.seeyon.cip.capability.dto.missive.AssistReadingReqDto`

被这些方法当入参：

- `IntelligentMissiveAppService.assistReading()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `storageKey` | `java.lang.String` |
| `fileName` | `java.lang.String` |
| `ignoreFlag` | `java.lang.Integer` |

## `RelatedReqDto`（4 字段）

`com.seeyon.cip.capability.dto.missive.RelatedReqDto`

被这些方法当入参：

- `IntelligentMissiveAppService.queryRelated()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `storageKey` | `java.lang.String` |
| `fileName` | `java.lang.String` |
| `ignoreFlag` | `java.lang.Integer` |

## `ReviewTaskReqDto`（4 字段）

`com.seeyon.cip.capability.dto.missive.ReviewTaskReqDto`

被这些方法当入参：

- `IntelligentMissiveAppService.createReviewTask()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `storageKey` | `java.lang.String` |
| `fileName` | `java.lang.String` |
| `checkPointIdList` | `java.util.List<java.lang.Integer>` |

## `MobilePluginAppletOpenCommonDto`（4 字段）

`com.seeyon.cip.capability.dto.mobileplugin.applet.MobilePluginAppletOpenCommonDto`

被这些方法当入参：

- `MobilePluginAppletAppService.undoCodeAudit()`（包装入参）
- `MobilePluginAppletAppService.releaseAudited()`（包装入参）

| 字段 | 类型 |
|---|---|
| `miniType` | `java.lang.String` |
| `authAppId` | `java.lang.String` |
| `refreshToken` | `java.lang.String` |
| `extraParams` | `java.util.Map<java.lang.String, java.lang.Object>` |

## `MobilePluginAppletOpenPreAuthDto`（4 字段）

`com.seeyon.cip.capability.dto.mobileplugin.applet.MobilePluginAppletOpenPreAuthDto`

被这些方法当入参：

- `MobilePluginAppletAppService.authUrl()`（包装入参）

| 字段 | 类型 |
|---|---|
| `miniType` | `java.lang.String` |
| `redirectUri` | `java.lang.String` |
| `authType` | `java.lang.Integer` |
| `extraParams` | `java.util.Map<java.lang.String, java.lang.Object>` |

## `MobilePluginAppletOpenQueryDto`（4 字段）

`com.seeyon.cip.capability.dto.mobileplugin.applet.MobilePluginAppletOpenQueryDto`

被这些方法当入参：

- `MobilePluginAppletAppService.bindAuth()`（包装入参）
- `MobilePluginAppletAppService.privacySetting()`（包装入参）
- `MobilePluginAppletAppService.submitAudit()`（包装入参）
- `MobilePluginAppletAppService.queryBindAuth()`（包装入参）

| 字段 | 类型 |
|---|---|
| `miniType` | `java.lang.String` |
| `authCode` | `java.lang.String` |
| `refreshToken` | `java.lang.String` |
| `extraParams` | `java.util.Map<java.lang.String, java.lang.Object>` |

## `ExtractContentReqDto`（4 字段）

`com.seeyon.cip.capability.dto.ocr.ExtractContentReqDto`

被这些方法当入参：

- `OcrAppService.extractContent()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `storageKey` | `java.lang.String` |
| `inputStream` | `java.io.InputStream` |
| `fileName` | `java.lang.String` |

## `ExcelSmsImportDto`（4 字段）

`com.seeyon.cip.capability.dto.sms.ExcelSmsImportDto`

被这些方法当入参：

- `ExcelSmsImportAndExportAppService.importExcel()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `storageKey` | `java.lang.String` |
| `excelImportTypeEnum` | `com.seeyon.cip.capability.enums.sms.ExcelImportTypeEnum` |
| `excelSheetEnum` | `com.seeyon.cip.capability.enums.sms.ExcelSheetEnum` |

## `SmsSearchDto`（4 字段）

`com.seeyon.cip.capability.dto.sms.SmsSearchDto`

被这些方法当入参：

- `ShortMessageSignAppService.selectValidSign()`（包装入参）
- `ShortMessageSignAppService.selectPageSignByConditions()`（包装入参）
- `ShortMessageTemplateAppService.selectPageByConditions()`（包装入参）
- `ShortMessageTemplateAppService.selectTemplateTypeListByConditions()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `pageInfo` | `com.seeyon.boot.transport.PageInfo` |
| `params` | `java.util.Map<java.lang.String, java.lang.Object>` |
| `sort` | `com.seeyon.boot.transport.Sort` |

## `ExcelSheetEnum`（4 字段）

`com.seeyon.cip.capability.enums.sms.ExcelSheetEnum`

被这些方法当入参：

- `ExcelSmsImportAndExportAppService.exportExcel()`（包装入参）
- `ExcelSmsImportAndExportAppService.exportExcelTemplate()`（包装入参）

| 字段 | 类型 |
|---|---|
| `TEMPLATE` | static `com.seeyon.cip.capability.enums.sms.ExcelSheetEnum` |
| `SIGN` | static `com.seeyon.cip.capability.enums.sms.ExcelSheetEnum` |
| `code` | `int` |
| `$VALUES` | static `com.seeyon.cip.capability.enums.sms.ExcelSheetEnum[]` |

## `AppSearchApiDto`（4 字段）

`com.seeyon.cip.connector.dto.db.AppSearchApiDto`

被这些方法当入参：

- `DataBaseExecutorService.getPageTableName()`（裸参数）

| 字段 | 类型 |
|---|---|
| `log` | static `org.slf4j.Logger` |
| `id` | `java.lang.Long` |
| `searchContent` | `java.lang.String` |
| `pageInfo` | `com.seeyon.boot.transport.PageInfo` |

## `MqCustomSendDto`（4 字段）

`com.seeyon.cip.connector.dto.execute.MqCustomSendDto`

被这些方法当入参：

- `LinkerAppService.mqCustomSend()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `linkerId` | `java.lang.Long` |
| `name` | `java.lang.String` |
| `data` | `java.util.Map<java.lang.String, java.lang.Object>` |

## `MobileOpenIdDto`（4 字段）

`com.seeyon.cip.connector.dto.mobile.MobileOpenIdDto`

被这些方法当入参：

- `MobileApplicationProviderService.getOpenId()`（裸参数）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `type` | `java.lang.String` |
| `phoneNumber` | `java.lang.String` |
| `appId` | `java.lang.String` |

## `FileDeleteDto`（4 字段）

`com.seeyon.cip.openapi.operate.dto.FileDeleteDto`

被这些方法当入参：

- `CipFileAppService.deleteByStorageKeys()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `taskId` | `java.lang.String` |
| `requestId` | `java.lang.String` |
| `storageKeys` | `java.util.List<java.lang.String>` |

## `PluginAffairGroupDto`（4 字段）

`com.seeyon.cip.plug.dto.PluginAffairGroupDto`

被这些方法当入参：

- `PluginAffairAppService.processRevoke()`（包装入参）
- `PluginAffairAppService.processTerminate()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `capabilityId` | `java.lang.Long` |
| `objectId` | `java.lang.String` |
| `externalAffairId` | `java.lang.String` |

## `PluginMessageBatchDto`（4 字段）

`com.seeyon.cip.plug.dto.PluginMessageBatchDto`

被这些方法当入参：

- `PluginMessageAppService.syncPluginMessage()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `capabilityId` | `java.lang.Long` |
| `idType` | `com.seeyon.cip.plug.enums.UserIdTypeEnum` |
| `messageList` | `java.util.List<com.seeyon.cip.plug.dto.PluginMessageDetailDto>` |

## `MiddleTableDeleteReqDto`（4 字段）

`com.seeyon.cip.plug.dto.midddletable.MiddleTableDeleteReqDto`

被这些方法当入参：

- `MiddleTableOperationAppService.delete()`（包装入参）

| 字段 | 类型 |
|---|---|
| `linkerId` | `java.lang.Long` |
| `code` | `java.lang.String` |
| `thirdId` | `java.lang.String` |
| `dimension` | `com.seeyon.cip.plug.enums.MiddleTableDimensionEnum` |

## `QueryRefundParamsDto`（4 字段）

`com.seeyon.cip.provider.dto.pay.QueryRefundParamsDto`

被这些方法当入参：

- `PayAppService.queryRefund()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `mchid` | `java.lang.String` |
| `refundOrderNo` | `java.lang.String` |
| `outTradeNo` | `java.lang.String` |

## `OuterOrganizationDto`（4 字段）

`com.seeyon.cip.provider.dto.signature.org.outer.OuterOrganizationDto`

被这些方法当入参：

- `SignatureAppService.createOuterOrg()`（包装入参）

| 字段 | 类型 |
|---|---|
| `outerOrgId` | `java.lang.String` |
| `name` | `java.lang.String` |
| `licenseType` | `com.seeyon.cip.provider.enums.signature.OrgLicenseTypeEnum` |
| `licenseNo` | `java.lang.String` |

## `OuterOrganizationUpdateDto`（4 字段）

`com.seeyon.cip.provider.dto.signature.org.outer.OuterOrganizationUpdateDto`

被这些方法当入参：

- `SignatureAppService.updateOuterOrg()`（包装入参）

| 字段 | 类型 |
|---|---|
| `thirdOrgId` | `java.lang.String` |
| `name` | `java.lang.String` |
| `licenseType` | `com.seeyon.cip.provider.enums.signature.OrgLicenseTypeEnum` |
| `licenseNo` | `java.lang.String` |

## `InitPreSignDto`（4 字段）

`com.seeyon.cip.provider.dto.signature.sign.InitPreSignDto`

被这些方法当入参：

- `SignatureAppService.initPreSign()`（包装入参）

| 字段 | 类型 |
|---|---|
| `businessNo` | `java.lang.String` |
| `customAccountNo` | `java.lang.String` |
| `customDepartmentNo` | `java.lang.String` |
| `customOrgNo` | `java.lang.String` |

## `SignAreaConfigDto`（4 字段）

`com.seeyon.cip.provider.dto.signature.sign.SignAreaConfigDto`

被这些方法当入参：

- `SignatureAppService.signToolsConfig()`（包装入参）

| 字段 | 类型 |
|---|---|
| `callbackUrl` | `java.lang.String` |
| `fileKeyList` | `java.util.List<com.seeyon.cip.provider.dto.signature.sign.FileInfoDto>` |
| `signerList` | `java.util.List<com.seeyon.cip.provider.dto.signature.sign.SignerAreaDto>` |
| `contractId` | `java.lang.String` |

## `GeneratePdfDto`（4 字段）

`com.seeyon.cip.provider.dto.signature.template.GeneratePdfDto`

被这些方法当入参：

- `SignatureAppService.generatePdfFile()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `contentsControl` | `java.util.List<com.seeyon.cip.provider.dto.signature.template.ContentsControlValueDto>` |
| `fileName` | `java.lang.String` |
| `templateId` | `java.lang.String` |

## `TripAddressGetBookRequestDto`（4 字段）

`com.seeyon.cip.provider.dto.trip.TripAddressGetBookRequestDto`

被这些方法当入参：

- `BusinessTripAppService.addressGetBook()`（包装入参）

| 字段 | 类型 |
|---|---|
| `userId` | `java.lang.String` |
| `itineraryId` | `java.lang.String` |
| `type` | `java.lang.Integer` |
| `phone` | `java.lang.String` |

## `TripAddressGetOrderRequestDto`（4 字段）

`com.seeyon.cip.provider.dto.trip.TripAddressGetOrderRequestDto`

被这些方法当入参：

- `BusinessTripAppService.addressGetOrder()`（包装入参）

| 字段 | 类型 |
|---|---|
| `userId` | `java.lang.String` |
| `itineraryId` | `java.lang.String` |
| `type` | `java.lang.Integer` |
| `phone` | `java.lang.String` |

## `TripCostCenterQueryRequestDto`（4 字段）

`com.seeyon.cip.provider.dto.trip.TripCostCenterQueryRequestDto`

被这些方法当入参：

- `BusinessTripAppService.costCenterQuery()`（包装入参）

| 字段 | 类型 |
|---|---|
| `userId` | `java.lang.String` |
| `thirdpartId` | `java.lang.String` |
| `needOrgEntity` | `java.lang.Boolean` |
| `title` | `java.lang.String` |

## `VideoMeetingOperateDto`（4 字段）

`com.seeyon.cip.provider.dto.video.request.VideoMeetingOperateDto`

被这些方法当入参：

- `VideoMeetingAppService.cancelVideoMeeting()`（包装入参）
- `VideoMeetingAppService.finishVideoMeeting()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `meetingId` | `java.lang.String` |
| `password` | `java.lang.String` |
| `roomUserId` | `java.lang.String` |

## `AffairBatchQueryDto`（3 字段）

`com.seeyon.cip.application.dto.AffairBatchQueryDto`

被这些方法当入参：

- `ApplicationAffairAppService.queryAffairListByExternalIdList()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `capabilityId` | `java.lang.Long` |
| `externalAffairIdList` | `java.util.List<java.lang.String>` |

## `AffairQueryDto`（3 字段）

`com.seeyon.cip.application.dto.AffairQueryDto`

被这些方法当入参：

- `ApplicationAffairAppService.queryAffairByExternalId()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `capabilityId` | `java.lang.Long` |
| `externalAffairId` | `java.lang.String` |

## `DutyInfoReqDto`（3 字段）

`com.seeyon.cip.application.dto.middletable.DutyInfoReqDto`

被这些方法当入参：

- `MiddleTableAppService.saveDuty()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `linkerId` | `java.lang.Long` |
| `data` | `java.util.List<com.seeyon.cip.application.dto.middletable.DutyInfoDto>` |

## `LevelInfoReqDto`（3 字段）

`com.seeyon.cip.application.dto.middletable.LevelInfoReqDto`

被这些方法当入参：

- `MiddleTableAppService.saveLevel()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `linkerId` | `java.lang.Long` |
| `data` | `java.util.List<com.seeyon.cip.application.dto.middletable.LevelInfoDto>` |

## `MemberInfoReqDto`（3 字段）

`com.seeyon.cip.application.dto.middletable.MemberInfoReqDto`

被这些方法当入参：

- `MiddleTableAppService.saveMember()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `linkerId` | `java.lang.Long` |
| `data` | `java.util.List<com.seeyon.cip.application.dto.middletable.MemberInfoDto>` |

## `PostInfoReqDto`（3 字段）

`com.seeyon.cip.application.dto.middletable.PostInfoReqDto`

被这些方法当入参：

- `MiddleTableAppService.savePost()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `linkerId` | `java.lang.Long` |
| `data` | `java.util.List<com.seeyon.cip.application.dto.middletable.PostInfoDto>` |

## `UnitInfoReqDto`（3 字段）

`com.seeyon.cip.application.dto.middletable.UnitInfoReqDto`

被这些方法当入参：

- `MiddleTableAppService.saveUnit()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `linkerId` | `java.lang.Long` |
| `data` | `java.util.List<com.seeyon.cip.application.dto.middletable.UnitInfoDto>` |

## `QueryReqDto`（3 字段）

`com.seeyon.cip.basic.dto.card.QueryReqDto`

被这些方法当入参：

- `OrgIntegrationAppService.queryCardInfo()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `showTypeEnum` | `com.seeyon.cip.basic.enums.card.ShowTypeEnum` |
| `serviceCode` | `java.lang.String` |

## `CapabilityRechargeDto`（3 字段）

`com.seeyon.cip.capability.dto.CapabilityRechargeDto`

被这些方法当入参：

- `OpenCapabilityAppService.updateAppCharges()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `openAppId` | `java.lang.Long` |
| `rechargeCapabilityDtoList` | `java.util.List<com.seeyon.cip.openapi.operate.dto.RechargeCapabilityDto>` |

## `AiAppInfoDto`（3 字段）

`com.seeyon.cip.capability.dto.ai.AiAppInfoDto`

被这些方法当入参：

- `AiAppService.createThirdApp()`（包装入参）
- `AiAppService.thirdAppIncrease()`（包装入参）

| 字段 | 类型 |
|---|---|
| `appKey` | `java.lang.String` |
| `orgName` | `java.lang.String` |
| `usableNum` | `java.lang.Integer` |

## `AiAppUsageQueryDto`（3 字段）

`com.seeyon.cip.capability.dto.ai.AiAppUsageQueryDto`

被这些方法当入参：

- `AiAppService.queryUsageAmount()`（包装入参）

| 字段 | 类型 |
|---|---|
| `appId` | `java.lang.String` |
| `startTime` | `java.lang.String` |
| `endTime` | `java.lang.String` |

## `TextCensorReqDto`（3 字段）

`com.seeyon.cip.capability.dto.censor.TextCensorReqDto`

被这些方法当入参：

- `CensorAppService.textCensor()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `taskId` | `java.lang.String` |
| `list` | `java.util.List<com.seeyon.cip.capability.dto.censor.TextCensorReqContentDto>` |

## `EnterpriseCreditRequestDto`（3 字段）

`com.seeyon.cip.capability.dto.credit.EnterpriseCreditRequestDto`

被这些方法当入参：

- `EnterpriseCreditAppService.getBasicBusinessInfo()`（包装入参）
- `EnterpriseCreditAppService.pageEnterpriseInfo()`（裸参数）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `enterpriseCreditEnums` | `com.seeyon.cip.provider.enums.credit.EnterpriseCreditApiEnum` |
| `keyWord` | `java.lang.String` |

## `DocEncryptFileRequestDto`（3 字段）

`com.seeyon.cip.capability.dto.doc.DocEncryptFileRequestDto`

被这些方法当入参：

- `DocOnlineAppService.checkAndEncrypt()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `storageKey` | `java.lang.String` |
| `fileName` | `java.lang.String` |

## `DocFileBatchConvertDto`（3 字段）

`com.seeyon.cip.capability.dto.doc.DocFileBatchConvertDto`

被这些方法当入参：

- `DocOnlineAppService.cpsOfficeBatchConvert()`（包装入参）

| 字段 | 类型 |
|---|---|
| `convertDetails` | `java.util.List<com.seeyon.cip.capability.dto.doc.DocBatchConvertDetailDto>` |
| `sync` | `java.lang.Boolean` |
| `sceneType` | `java.lang.Integer` |

## `DocFileInfoRequestDto`（3 字段）

`com.seeyon.cip.capability.dto.doc.DocFileInfoRequestDto`

被这些方法当入参：

- `DocOnlineAppService.getLatestDocFileInfoByStorageKey()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `fileId` | `java.lang.String` |
| `storageKey` | `java.lang.String` |

## `DocFileUrlReqDto`（3 字段）

`com.seeyon.cip.capability.dto.doc.DocFileUrlReqDto`

被这些方法当入参：

- `DocOnlineAppService.getFileUrl()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `storageKey` | `java.lang.String` |
| `fileName` | `java.lang.String` |

## `DocMergeDto`（3 字段）

`com.seeyon.cip.capability.dto.doc.DocMergeDto`

被这些方法当入参：

- `DocOnlineAppService.cpsMerge()`（包装入参）

| 字段 | 类型 |
|---|---|
| `taskId` | `java.lang.String` |
| `mergedFileList` | `java.util.LinkedList<com.seeyon.cip.capability.dto.doc.DocMergedFileDto>` |
| `sync` | `java.lang.Boolean` |

## `LatestPicViewDto`（3 字段）

`com.seeyon.cip.capability.dto.doc.LatestPicViewDto`

被这些方法当入参：

- `DocOnlineAppService.getLatestPicViewUrl()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `storageKey` | `java.lang.String` |
| `sceneType` | `java.lang.Integer` |

## `NotifyReqDto`（3 字段）

`com.seeyon.cip.capability.dto.doc.NotifyReqDto`

被这些方法当入参：

- `DocOnlineAppService.onNotify()`（包装入参）

| 字段 | 类型 |
|---|---|
| `fileId` | `java.lang.String` |
| `fileName` | `java.lang.String` |
| `channelCode` | `java.lang.String` |

## `SealRequestDto`（3 字段）

`com.seeyon.cip.capability.dto.econtracts.request.SealRequestDto`

被这些方法当入参：

- `SealAppService.uploadSeal()`（包装入参）
- `SealAppService.listSeal()`（包装入参）
- `SealAppService.getSealDetails()`（包装入参）
- `SealAppService.authSeal()`（包装入参）
- `SealAppService.cancelAuthSeal()`（包装入参）
- `SealAppService.deleteAuthSeal()`（包装入参）
- … 另 1 处

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `commonSealDto` | `com.seeyon.cip.capability.dto.econtracts.request.CommonSealDto` |
| `accountId` | `java.lang.Long` |

## `EmailAppointAccountDto`（3 字段）

`com.seeyon.cip.capability.dto.email.EmailAppointAccountDto`

被这些方法当入参：

- `EmailAppService.sendNormalEmailByAccount()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `cipEmailConfigDto` | `com.seeyon.cip.capability.dto.email.CipEmailConfigDto` |
| `emailDetailsDto` | `com.seeyon.cip.capability.dto.email.EmailDetailsDto` |

## `InvoiceOcrDto`（3 字段）

`com.seeyon.cip.capability.dto.invoice.request.InvoiceOcrDto`

被这些方法当入参：

- `InvoiceAppService.getOcrInvoiceData()`（包装入参）

| 字段 | 类型 |
|---|---|
| `invokeId` | `java.lang.Long` |
| `storageKeys` | `java.util.List<java.lang.String>` |
| `asyncFlag` | `java.lang.Boolean` |

## `DistanceDto`（3 字段）

`com.seeyon.cip.capability.dto.location.request.DistanceDto`

被这些方法当入参：

- `LocationAppService.getDistance()`（包装入参）

| 字段 | 类型 |
|---|---|
| `startAddress` | `com.seeyon.cip.provider.dto.location.GeocoderRequestDto` |
| `endAddress` | `com.seeyon.cip.provider.dto.location.GeocoderRequestDto` |
| `distanceEnum` | `com.seeyon.cip.capability.enums.location.DistanceEnum` |

## `AllCapabilityCycleCountDto`（3 字段）

`com.seeyon.cip.capability.dto.manage.AllCapabilityCycleCountDto`

被这些方法当入参：

- `CapabilityManageAppService.setAllCapabilityCycleCount()`（包装入参）
- `CapabilityManageAppService.rechargeCapabilityCycleCount()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `appName` | `java.lang.String` |
| `list` | `java.util.List<com.seeyon.cip.capability.dto.manage.CapabilityCycleCountDto>` |

## `BaseInfoParameterDto`（3 字段）

`com.seeyon.cip.capability.dto.manage.BaseInfoParameterDto`

被这些方法当入参：

- `CapabilityManageAppService.selectProviderParameter()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `capabilityName` | `java.lang.String` |
| `provider` | `java.lang.String` |

## `CountQueryDto`（3 字段）

`com.seeyon.cip.capability.dto.manage.CountQueryDto`

被这些方法当入参：

- `CapabilityManageAppService.selectCountByEnum()`（包装入参）
- `CapabilityManageAppService.authConfigQuery()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `capabilityEnum` | `com.seeyon.cip.provider.enums.CapabilityEnum` |
| `provider` | `java.lang.String` |

## `OpenApiSendDto`（3 字段）

`com.seeyon.cip.capability.dto.manage.OpenApiSendDto`

被这些方法当入参：

- `CapabilityManageAppService.sendOpenApiRequest()`（包装入参）
- `CapabilityManageAppService.sendOpenApiRequestPage()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `secondUrl` | `java.lang.String` |
| `data` | `java.lang.Object` |

## `OpenapiCapabilityQueryDto`（3 字段）

`com.seeyon.cip.capability.dto.manage.OpenapiCapabilityQueryDto`

被这些方法当入参：

- `CapabilityManageAppService.selectCloudCount()`（包装入参）
- `CapabilityManageAppService.selectLocalCloudCount()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `capabilityEnum` | `com.seeyon.cip.provider.enums.CapabilityEnum` |
| `appKey` | `java.lang.String` |

## `OpenapiCountQueryDto`（3 字段）

`com.seeyon.cip.capability.dto.manage.OpenapiCountQueryDto`

被这些方法当入参：

- `CapabilityManageAppService.selectOpenapiCount()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `externalAppId` | `java.lang.Long` |
| `appKey` | `java.lang.String` |

## `ProviderParameterRequestDto`（3 字段）

`com.seeyon.cip.capability.dto.manage.ProviderParameterRequestDto`

被这些方法当入参：

- `CapabilityManageAppService.createParamBatch()`（包装入参）

| 字段 | 类型 |
|---|---|
| `providerManagerId` | `java.lang.Long` |
| `parameterList` | `java.util.List<com.seeyon.cip.capability.dto.manage.ProviderParameterDto>` |
| `defaultProvider` | `java.lang.String` |

## `SelectProvicerEnableDto`（3 字段）

`com.seeyon.cip.capability.dto.manage.SelectProvicerEnableDto`

被这些方法当入参：

- `CapabilityManageAppService.operationEnable()`（包装入参）
- `CapabilityManageAppService.updateDefaultProvider()`（包装入参）

| 字段 | 类型 |
|---|---|
| `id` | `java.lang.Long` |
| `enable` | `java.lang.Boolean` |
| `provider` | `java.lang.String` |

## `CipAppEnableDto`（3 字段）

`com.seeyon.cip.capability.dto.manage.appchannel.CipAppEnableDto`

被这些方法当入参：

- `CapabilityManageAppService.appEnable()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `appId` | `java.lang.Long` |
| `open` | `java.lang.Boolean` |

## `CloudConnectPropertiesDto`（3 字段）

`com.seeyon.cip.capability.dto.manager.CloudConnectPropertiesDto`

被这些方法当入参：

- `CapabilityManageAppService.saveLinkProperties()`（包装入参）

| 字段 | 类型 |
|---|---|
| `url` | `java.lang.String` |
| `appKey` | `java.lang.String` |
| `appSecret` | `java.lang.String` |

## `CardRuleReqDto`（3 字段）

`com.seeyon.cip.capability.dto.missive.CardRuleReqDto`

被这些方法当入参：

- `IntelligentMissiveAppService.queryCardRule()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `start` | `java.lang.Integer` |
| `number` | `java.lang.Integer` |

## `ReadingDetailReqDto`（3 字段）

`com.seeyon.cip.capability.dto.missive.ReadingDetailReqDto`

被这些方法当入参：

- `IntelligentMissiveAppService.readingDetail()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `sourceId` | `java.lang.String` |
| `ignoreFlag` | `java.lang.Integer` |

## `RecommendReqDto`（3 字段）

`com.seeyon.cip.capability.dto.missive.RecommendReqDto`

被这些方法当入参：

- `IntelligentMissiveAppService.createRecommend()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `pageInfo` | `com.seeyon.boot.transport.PageInfo` |
| `keyword` | `java.lang.String` |

## `SensitiveWordReqDto`（3 字段）

`com.seeyon.cip.capability.dto.missive.SensitiveWordReqDto`

被这些方法当入参：

- `IntelligentMissiveAppService.checkSensitiveWord()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `storageKey` | `java.lang.String` |
| `fileName` | `java.lang.String` |

## `UploadTempFileReqDto`（3 字段）

`com.seeyon.cip.capability.dto.missive.UploadTempFileReqDto`

被这些方法当入参：

- `IntelligentMissiveAppService.uploadTempFile()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `storageKey` | `java.lang.String` |
| `fileName` | `java.lang.String` |

## `OfdDownReqDto`（3 字段）

`com.seeyon.cip.capability.dto.ofd.OfdDownReqDto`

被这些方法当入参：

- `OfdAppService.downFile()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `fileId` | `java.lang.String` |
| `fileName` | `java.lang.String` |

## `QuerySearchReqDto`（3 字段）

`com.seeyon.cip.capability.dto.search.QuerySearchReqDto`

被这些方法当入参：

- `SearchAppService.querySearchUrl()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `searchKeyword` | `java.lang.String` |
| `clientTypeEnum` | `com.seeyon.cip.provider.enums.search.SearchClientTypeEnum` |

## `SignatureDownReqDto`（3 字段）

`com.seeyon.cip.capability.dto.signature.SignatureDownReqDto`

被这些方法当入参：

- `SignatureAppService.downFile()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `fileId` | `java.lang.String` |
| `fileName` | `java.lang.String` |

## `RepeatTemplateCodeRequestDto`（3 字段）

`com.seeyon.cip.capability.dto.sms.RepeatTemplateCodeRequestDto`

被这些方法当入参：

- `ShortMessageTemplateAppService.checkTemplateCode()`（包装入参）

| 字段 | 类型 |
|---|---|
| `id` | `java.lang.Long` |
| `templateCode` | `java.lang.String` |
| `language` | `java.lang.String` |

## `SmsSetSignDto`（3 字段）

`com.seeyon.cip.capability.dto.sms.SmsSetSignDto`

被这些方法当入参：

- `ShortMessageTemplateAppService.setTemplateSign()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `templateId` | `java.lang.Long` |
| `signId` | `java.lang.Long` |

## `TranslationDto`（3 字段）

`com.seeyon.cip.capability.dto.translation.TranslationDto`

被这些方法当入参：

- `TranslationAppService.translate()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `query` | `java.lang.String` |
| `to` | `java.lang.String` |

## `CreateIntelligentDigestDto`（3 字段）

`com.seeyon.cip.capability.dto.voice.CreateIntelligentDigestDto`

被这些方法当入参：

- `VoiceAppService.createIntelligentDigest()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `taskId` | `java.lang.Long` |
| `content` | `java.lang.String` |

## `AuthEventDto`（3 字段）

`com.seeyon.cip.connector.dto.authentication.AuthEventDto`

被这些方法当入参：

- `LinkerSecurityService.doDecode()`（裸参数）

| 字段 | 类型 |
|---|---|
| `name` | `java.lang.String` |
| `data` | `java.util.Map<java.lang.String, java.lang.Object>` |
| `authId` | `java.lang.Long` |

## `DutyInfoSpiReqDto`（3 字段）

`com.seeyon.cip.connector.dto.midorgsync.DutyInfoSpiReqDto`

被这些方法当入参：

- `MiddleTableOrgSyncDataCallbackService.batchSaveDuty()`（裸参数）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `linkerCode` | `java.lang.String` |
| `data` | `java.util.List<com.seeyon.cip.connector.dto.midorgsync.DutyInfoSpiDto>` |

## `LevelInfoSpiReqDto`（3 字段）

`com.seeyon.cip.connector.dto.midorgsync.LevelInfoSpiReqDto`

被这些方法当入参：

- `MiddleTableOrgSyncDataCallbackService.batchSaveLevel()`（裸参数）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `linkerCode` | `java.lang.String` |
| `data` | `java.util.List<com.seeyon.cip.connector.dto.midorgsync.LevelInfoSpiDto>` |

## `MemberInfoSpiReqDto`（3 字段）

`com.seeyon.cip.connector.dto.midorgsync.MemberInfoSpiReqDto`

被这些方法当入参：

- `MiddleTableOrgSyncDataCallbackService.batchSaveMember()`（裸参数）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `linkerCode` | `java.lang.String` |
| `data` | `java.util.List<com.seeyon.cip.connector.dto.midorgsync.MemberInfoSpiDto>` |

## `PostInfoSpiReqDto`（3 字段）

`com.seeyon.cip.connector.dto.midorgsync.PostInfoSpiReqDto`

被这些方法当入参：

- `MiddleTableOrgSyncDataCallbackService.batchSavePosition()`（裸参数）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `linkerCode` | `java.lang.String` |
| `data` | `java.util.List<com.seeyon.cip.connector.dto.midorgsync.PostInfoSpiDto>` |

## `UnitInfoSpiReqDto`（3 字段）

`com.seeyon.cip.connector.dto.midorgsync.UnitInfoSpiReqDto`

被这些方法当入参：

- `MiddleTableOrgSyncDataCallbackService.batchSaveOrg()`（裸参数）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `linkerCode` | `java.lang.String` |
| `data` | `java.util.List<com.seeyon.cip.connector.dto.midorgsync.UnitInfoSpiDto>` |

## `ConfigInfoApiDto`（3 字段）

`com.seeyon.cip.connector.dto.midorgsync.spi.ConfigInfoApiDto`

被这些方法当入参：

- `MiddleTableOrgSyncSpiPullService.pullAll()`（裸参数）
- `MiddleTableOrgSyncSpiPullService.pullIncrement()`（裸参数）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `linkerCode` | `java.lang.String` |
| `OrgSyncTypeList` | `java.util.List<com.seeyon.cip.connector.enums.midorgsync.OrgSyncTypeSpiEnum>` |

## `MobileBatchResultDto`（3 字段）

`com.seeyon.cip.connector.dto.mobile.batch.MobileBatchResultDto`

被这些方法当入参：

- `MobileOrgSyncBatchProviderService.syncBatchResult()`（裸参数）

| 字段 | 类型 |
|---|---|
| `type` | `java.lang.String` |
| `thirdConfigId` | `java.lang.Long` |
| `jobId` | `java.lang.String` |

## `MobileDepartmentBatchSyncDto`（3 字段）

`com.seeyon.cip.connector.dto.mobile.batch.MobileDepartmentBatchSyncDto`

被这些方法当入参：

- `MobileOrgSyncBatchProviderService.syncUnitBatch()`（裸参数）

| 字段 | 类型 |
|---|---|
| `thirdConfigId` | `java.lang.Long` |
| `type` | `java.lang.String` |
| `unitDtoList` | `java.util.List<com.seeyon.cip.connector.dto.mobile.MobileUnitRequestDto>` |

## `MobileUserBatchSyncDto`（3 字段）

`com.seeyon.cip.connector.dto.mobile.batch.MobileUserBatchSyncDto`

被这些方法当入参：

- `MobileOrgSyncBatchProviderService.userSyncBatch()`（裸参数）

| 字段 | 类型 |
|---|---|
| `thirdConfigId` | `java.lang.Long` |
| `type` | `java.lang.String` |
| `userDtoList` | `java.util.List<com.seeyon.cip.connector.dto.mobile.MobileUserRequestDto>` |

## `DutyInfoReqDto`（3 字段）

`com.seeyon.cip.plug.dto.midddletable.DutyInfoReqDto`

被这些方法当入参：

- `MiddleTableOperationAppService.saveDuty()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `linkerId` | `java.lang.Long` |
| `data` | `java.util.List<com.seeyon.cip.plug.dto.midddletable.DutyInfoDto>` |

## `PostInfoReqDto`（3 字段）

`com.seeyon.cip.plug.dto.midddletable.PostInfoReqDto`

被这些方法当入参：

- `MiddleTableOperationAppService.savePost()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `linkerId` | `java.lang.Long` |
| `data` | `java.util.List<com.seeyon.cip.plug.dto.midddletable.PostInfoDto>` |

## `ArchivingInfoWrapperDto`（3 字段）

`com.seeyon.cip.provider.dto.archives.ArchivingInfoWrapperDto`

被这些方法当入参：

- `ArchivesAppService.startArchiving()`（包装入参）

| 字段 | 类型 |
|---|---|
| `archiveSettingInfoDto` | `com.seeyon.cip.provider.dto.archives.ArchiveSettingInfoDto` |
| `summaryDto` | `com.seeyon.cip.provider.dto.archives.ArchiveContentSummaryDto` |
| `archiveId` | `java.lang.String` |

## `GisTokenRequestDto`（3 字段）

`com.seeyon.cip.provider.dto.gis.request.GisTokenRequestDto`

被这些方法当入参：

- `GisAppService.getToken()`（包装入参）

| 字段 | 类型 |
|---|---|
| `expiration` | `java.lang.String` |
| `resultType` | `java.lang.String` |
| `encrypted` | `java.lang.String` |

## `RegionDto`（3 字段）

`com.seeyon.cip.provider.dto.location.RegionDto`

被这些方法当入参：

- `LocationAppService.regionSearch()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `keyword` | `java.lang.String` |
| `sub` | `com.seeyon.cip.provider.enums.location.RegionSubEnum` |

## `BillDownloadParamsDto`（3 字段）

`com.seeyon.cip.provider.dto.pay.BillDownloadParamsDto`

被这些方法当入参：

- `PayAppService.downloadTradeBill()`（包装入参）
- `PayAppService.downloadFundFlowBill()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `billDate` | `java.lang.String` |
| `mchid` | `java.lang.String` |

## `TransactionParamsDto`（3 字段）

`com.seeyon.cip.provider.dto.pay.TransactionParamsDto`

被这些方法当入参：

- `PayAppService.queryTransactionByOutTradeNo()`（包装入参）
- `PayAppService.closeTransaction()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `mchid` | `java.lang.String` |
| `outTradeNo` | `java.lang.String` |

## `ContractLockRequestDto`（3 字段）

`com.seeyon.cip.provider.dto.signature.contractlock.ContractLockRequestDto`

被这些方法当入参：

- `SignatureAppService.finish()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `contractId` | `java.lang.Long` |
| `bizId` | `java.lang.String` |

## `OrganizationQueryDto`（3 字段）

`com.seeyon.cip.provider.dto.signature.org.OrganizationQueryDto`

被这些方法当入参：

- `SignatureAppService.detailOrg()`（包装入参）
- `SignatureAppService.detailOuterOrg()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `thirdOrgId` | `java.lang.String` |
| `orgId` | `java.lang.String` |

## `QuerySsoReqDto`（3 字段）

`com.seeyon.cip.provider.dto.signature.org.QuerySsoReqDto`

被这些方法当入参：

- `SignatureAppService.querySsoUrl()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `userAccount` | `java.lang.String` |
| `redirectUrl` | `java.lang.String` |

## `UserQueryDto`（3 字段）

`com.seeyon.cip.provider.dto.signature.org.UserQueryDto`

被这些方法当入参：

- `SignatureAppService.userDetail()`（包装入参）
- `SignatureAppService.outerUserDetail()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `customAccountNo` | `java.lang.String` |
| `userCode` | `java.lang.String` |

## `SealQueryDto`（3 字段）

`com.seeyon.cip.provider.dto.signature.seal.SealQueryDto`

被这些方法当入参：

- `SignatureAppService.sealList()`（裸参数）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `userCode` | `java.lang.String` |
| `thirdOrgId` | `java.lang.String` |

## `SealSignerQueryDto`（3 字段）

`com.seeyon.cip.provider.dto.signature.seal.SealSignerQueryDto`

被这些方法当入参：

- `SignatureAppService.sealSigners()`（裸参数）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `sealCode` | `java.lang.String` |
| `sealId` | `java.lang.String` |

## `FileInfoDto`（3 字段）

`com.seeyon.cip.provider.dto.signature.sign.FileInfoDto`

被这些方法当入参：

- `SignatureAppService.downloadFile()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `fileKey` | `java.lang.String` |
| `fileOrder` | `java.lang.Integer` |

## `InvalidFlowReqDto`（3 字段）

`com.seeyon.cip.provider.dto.signature.sign.InvalidFlowReqDto`

被这些方法当入参：

- `SignatureAppService.invalidFlow()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `signFlowId` | `java.lang.String` |
| `reason` | `java.lang.String` |

## `UploadFileDto`（3 字段）

`com.seeyon.cip.provider.dto.signature.sign.UploadFileDto`

被这些方法当入参：

- `SignatureAppService.uploadFile()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `storageKey` | `java.lang.String` |
| `fileName` | `java.lang.String` |

## `VerifySignatureDto`（3 字段）

`com.seeyon.cip.provider.dto.signature.sign.VerifySignatureDto`

被这些方法当入参：

- `SignatureAppService.verifySignature()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `fileFormat` | `java.lang.String` |
| `fileKey` | `java.lang.String` |

## `TripAddressGetH5RequestDto`（3 字段）

`com.seeyon.cip.provider.dto.trip.TripAddressGetH5RequestDto`

被这些方法当入参：

- `BusinessTripAppService.addressGetH5()`（包装入参）

| 字段 | 类型 |
|---|---|
| `userId` | `java.lang.String` |
| `itineraryId` | `java.lang.String` |
| `phone` | `java.lang.String` |

## `TripAddressGetManagerRequestDto`（3 字段）

`com.seeyon.cip.provider.dto.trip.TripAddressGetManagerRequestDto`

被这些方法当入参：

- `BusinessTripAppService.addressGetManager()`（包装入参）

| 字段 | 类型 |
|---|---|
| `userId` | `java.lang.String` |
| `itineraryId` | `java.lang.String` |
| `phone` | `java.lang.String` |

## `VideoMeetingEndedSelectDto`（3 字段）

`com.seeyon.cip.provider.dto.video.request.VideoMeetingEndedSelectDto`

被这些方法当入参：

- `VideoMeetingAppService.getEndedMeetingDetail()`（包装入参）

| 字段 | 类型 |
|---|---|
| `meetingUUID` | `java.lang.String` |
| `userID` | `java.lang.String` |
| `roomUserId` | `java.lang.String` |

## `VideoMeetingRoomOperateDto`（3 字段）

`com.seeyon.cip.provider.dto.video.request.VideoMeetingRoomOperateDto`

被这些方法当入参：

- `VideoMeetingAppService.deleteVideoMeetingRoom()`（包装入参）
- `VideoMeetingAppService.recycleVmwareMeetingRoom()`（包装入参）

| 字段 | 类型 |
|---|---|
| `userId` | `java.lang.String` |
| `roomIds` | `java.util.List<java.lang.String>` |
| `vmrIds` | `java.util.List<java.lang.Long>` |

## `AffairIdMappingQueryDto`（2 字段）

`com.seeyon.cip.application.dto.AffairIdMappingQueryDto`

被这些方法当入参：

- `ApplicationAffairAppService.listExternalIdsByAffairIds()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `affairIdList` | `java.util.List<java.lang.Long>` |

## `OrgInnerIdReqDto`（2 字段）

`com.seeyon.cip.application.dto.mappingconfig.OrgInnerIdReqDto`

被这些方法当入参：

- `MappingDetailAppService.getOrgInnerIdByOuterId()`（包装入参）

| 字段 | 类型 |
|---|---|
| `code` | `java.lang.String` |
| `outerId` | `java.lang.String` |

## `OrgOuterIdReqDto`（2 字段）

`com.seeyon.cip.application.dto.mappingconfig.OrgOuterIdReqDto`

被这些方法当入参：

- `MappingDetailAppService.getOrgOuterIdByInnerId()`（包装入参）

| 字段 | 类型 |
|---|---|
| `code` | `java.lang.String` |
| `innerId` | `java.lang.Long` |

## `UserInnerIdReqDto`（2 字段）

`com.seeyon.cip.application.dto.mappingconfig.UserInnerIdReqDto`

被这些方法当入参：

- `MappingDetailAppService.getUserInnerIdByOuterId()`（包装入参）

| 字段 | 类型 |
|---|---|
| `code` | `java.lang.String` |
| `outerId` | `java.lang.String` |

## `UserOuterIdReqDto`（2 字段）

`com.seeyon.cip.application.dto.mappingconfig.UserOuterIdReqDto`

被这些方法当入参：

- `MappingDetailAppService.getUserOuterIdByInnerId()`（包装入参）

| 字段 | 类型 |
|---|---|
| `code` | `java.lang.String` |
| `innerId` | `java.lang.Long` |

## `RunningOrgSyncNowDto`（2 字段）

`com.seeyon.cip.application.dto.middletable.RunningOrgSyncNowDto`

被这些方法当入参：

- `MiddleTableAppService.runningOrgSyncNowByLinkerCode()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `linkerCode` | `java.lang.String` |

## `QueryRunReqDto`（2 字段）

`com.seeyon.cip.basic.dto.card.QueryRunReqDto`

被这些方法当入参：

- `OrgIntegrationAppService.queryCardRunInfo()`（包装入参）
- `OrgIntegrationAppService.queryDefaultCardInfo()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `userIds` | `java.util.List<java.lang.Long>` |

## `QueryThirdNativeCardReqDto`（2 字段）

`com.seeyon.cip.basic.dto.card.QueryThirdNativeCardReqDto`

被这些方法当入参：

- `OrgIntegrationAppService.queryThirdNativeCardInfo()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `userId` | `java.lang.Long` |

## `BalanceQueryReqDto`（2 字段）

`com.seeyon.cip.capability.dto.bankpay.account.BalanceQueryReqDto`

被这些方法当入参：

- `BankpayAppService.balanceQuery()`（包装入参）

| 字段 | 类型 |
|---|---|
| `userName` | `java.lang.String` |
| `userDataList` | `java.util.List<com.seeyon.cip.capability.dto.bankpay.account.AccountDto>` |

## `TransactionStatusQueryReqDto`（2 字段）

`com.seeyon.cip.capability.dto.bankpay.other.TransactionStatusQueryReqDto`

被这些方法当入参：

- `BankpayAppService.transactionStatusQuery()`（包装入参）

| 字段 | 类型 |
|---|---|
| `userName` | `java.lang.String` |
| `clientID` | `java.lang.String` |

## `PaymentTransferReqDto`（2 字段）

`com.seeyon.cip.capability.dto.bankpay.payment.PaymentTransferReqDto`

被这些方法当入参：

- `BankpayAppService.paymentTransfer()`（包装入参）

| 字段 | 类型 |
|---|---|
| `userName` | `java.lang.String` |
| `details` | `java.util.List<com.seeyon.cip.capability.dto.bankpay.payment.PaymentTransferDto>` |

## `CompositeViewDto`（2 字段）

`com.seeyon.cip.capability.dto.doc.CompositeViewDto`

被这些方法当入参：

- `DocOnlineAppService.getCompositeViewUrl()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `docViewDto` | `com.seeyon.cip.capability.dto.doc.DocViewDto` |

## `DocFileInfoBatchRequestDto`（2 字段）

`com.seeyon.cip.capability.dto.doc.DocFileInfoBatchRequestDto`

被这些方法当入参：

- `DocOnlineAppService.batchGetLatestDocFileInfoByStorageKey()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `docFileInfoBatchRequestDtos` | `java.util.List<com.seeyon.cip.capability.dto.doc.DocFileInfoRequestDto>` |

## `DocQueryTaskDto`（2 字段）

`com.seeyon.cip.capability.dto.doc.DocQueryTaskDto`

被这些方法当入参：

- `DocOnlineAppService.cpsTaskQuery()`（包装入参）

| 字段 | 类型 |
|---|---|
| `taskId` | `java.lang.String` |
| `checkThirdService` | `java.lang.Boolean` |

## `EnterpriseCertificateRequestDto`（2 字段）

`com.seeyon.cip.capability.dto.econtracts.request.EnterpriseCertificateRequestDto`

被这些方法当入参：

- `ContractsAppService.processEnterpriseCertificate()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `commonEnterpriseCertificateDto` | `com.seeyon.cip.capability.dto.econtracts.request.CommonEnterpriseCertificateDto` |

## `FileUploadRequestDto`（2 字段）

`com.seeyon.cip.capability.dto.econtracts.request.FileUploadRequestDto`

被这些方法当入参：

- `ContractsAppService.processFileUpload()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `commonFileUploadDto` | `com.seeyon.cip.capability.dto.econtracts.request.CommonFileUploadDto` |

## `PersonalCertificateRequestDto`（2 字段）

`com.seeyon.cip.capability.dto.econtracts.request.PersonalCertificateRequestDto`

被这些方法当入参：

- `ContractsAppService.processPersonalCertificate()`（包装入参）
- `ContractsAppService.processPersonCertificateInfo()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `commonPersonalCertificateDto` | `com.seeyon.cip.capability.dto.econtracts.request.CommonPersonalCertificateDto` |

## `SignTaskCreateRequestDto`（2 字段）

`com.seeyon.cip.capability.dto.econtracts.request.SignTaskCreateRequestDto`

被这些方法当入参：

- `ContractsAppService.processSignTaskCreate()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `commonSignTaskCreateDto` | `com.seeyon.cip.capability.dto.econtracts.request.CommonSignTaskCreateDto` |

## `SignTaskRequestDto`（2 字段）

`com.seeyon.cip.capability.dto.econtracts.request.SignTaskRequestDto`

被这些方法当入参：

- `ContractsAppService.processSignTaskUrl()`（包装入参）
- `ContractsAppService.processSignTaskDetails()`（包装入参）
- `ContractsAppService.processSignTaskExternal()`（包装入参）
- `ContractsAppService.processSignTaskFile()`（包装入参）
- `ContractsAppService.processSignTaskCancel()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `commonSignTaskDto` | `com.seeyon.cip.capability.dto.econtracts.request.CommonSignTaskDto` |

## `FaceAddReqDto`（2 字段）

`com.seeyon.cip.capability.dto.faceid.FaceAddReqDto`

被这些方法当入参：

- `FaceIdAppService.addFace()`（包装入参）

| 字段 | 类型 |
|---|---|
| `storageKey` | `java.lang.String` |
| `fileName` | `java.lang.String` |

## `FaceIdentifyReqDto`（2 字段）

`com.seeyon.cip.capability.dto.faceid.FaceIdentifyReqDto`

被这些方法当入参：

- `FaceIdAppService.faceCheck()`（包装入参）

| 字段 | 类型 |
|---|---|
| `storageKey` | `java.lang.String` |
| `fileName` | `java.lang.String` |

## `FaceUpdateReqDto`（2 字段）

`com.seeyon.cip.capability.dto.faceid.FaceUpdateReqDto`

被这些方法当入参：

- `FaceIdAppService.updateFace()`（包装入参）

| 字段 | 类型 |
|---|---|
| `storageKey` | `java.lang.String` |
| `fileName` | `java.lang.String` |

## `InvoiceOcrPageReqDto`（2 字段）

`com.seeyon.cip.capability.dto.invoice.request.InvoiceOcrPageReqDto`

被这些方法当入参：

- `InvoiceAppService.queryOcrPage()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `pageInfo` | `com.seeyon.boot.transport.PageInfo` |

## `BatchQueryEnableReqDto`（2 字段）

`com.seeyon.cip.capability.dto.manage.BatchQueryEnableReqDto`

被这些方法当入参：

- `CapabilityManageAppService.batchQueryEnableByEnum()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `capabilityEnums` | `java.util.List<com.seeyon.cip.provider.enums.CapabilityEnum>` |

## `OpenAppQueryDto`（2 字段）

`com.seeyon.cip.capability.dto.manage.OpenAppQueryDto`

被这些方法当入参：

- `CapabilityManageAppService.queryThirdAppInfo()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `appKey` | `java.lang.String` |

## `ProviderChannelRequestDto`（2 字段）

`com.seeyon.cip.capability.dto.manage.ProviderChannelRequestDto`

被这些方法当入参：

- `CapabilityManageAppService.getCurrentCapabilityChannelInfo()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `capabilityEnum` | `com.seeyon.cip.provider.enums.CapabilityEnum` |

## `QueryFeatureDto`（2 字段）

`com.seeyon.cip.capability.dto.manage.QueryFeatureDto`

被这些方法当入参：

- `CapabilityManageAppService.queryFeature()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `featureDetails` | `java.util.List<com.seeyon.cip.capability.dto.manage.QueryFeatureDetailDto>` |

## `QueryParameterReqDto`（2 字段）

`com.seeyon.cip.capability.dto.manage.QueryParameterReqDto`

被这些方法当入参：

- `CapabilityManageAppService.queryParams()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `capabilityEnum` | `com.seeyon.cip.provider.enums.CapabilityEnum` |

## `QueryRegisterAppInfoReqDto`（2 字段）

`com.seeyon.cip.capability.dto.manage.QueryRegisterAppInfoReqDto`

被这些方法当入参：

- `CapabilityManageAppService.queryRegisterAppInfo()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `capabilityEnum` | `com.seeyon.cip.provider.enums.CapabilityEnum` |

## `UseCountQueryDto`（2 字段）

`com.seeyon.cip.capability.dto.manage.UseCountQueryDto`

被这些方法当入参：

- `CapabilityManageAppService.queryUseCount()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `appKey` | `java.lang.String` |

## `DiffDetailReqDto`（2 字段）

`com.seeyon.cip.capability.dto.missive.DiffDetailReqDto`

被这些方法当入参：

- `IntelligentMissiveAppService.queryDocDiffDetail()`（包装入参）
- `IntelligentMissiveAppService.queryDocDiffView()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `taskId` | `java.lang.String` |

## `ExtractingDetailReqDto`（2 字段）

`com.seeyon.cip.capability.dto.missive.ExtractingDetailReqDto`

被这些方法当入参：

- `IntelligentMissiveAppService.queryExtractingDetail()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `taskId` | `java.lang.String` |

## `IntelligentWriteQueryReqDto`（2 字段）

`com.seeyon.cip.capability.dto.missive.IntelligentWriteQueryReqDto`

被这些方法当入参：

- `IntelligentMissiveAppService.queryWrite()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `taskId` | `java.lang.String` |

## `ProofreadTaskDetailReqDto`（2 字段）

`com.seeyon.cip.capability.dto.missive.ProofreadTaskDetailReqDto`

被这些方法当入参：

- `IntelligentMissiveAppService.queryProofreadDetail()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `taskId` | `java.lang.String` |

## `QueryResultReqDto`（2 字段）

`com.seeyon.cip.capability.dto.missive.QueryResultReqDto`

被这些方法当入参：

- `IntelligentMissiveAppService.queryResultByTaskId()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `taskId` | `java.lang.String` |

## `ReviewDetailReqDto`（2 字段）

`com.seeyon.cip.capability.dto.missive.ReviewDetailReqDto`

被这些方法当入参：

- `IntelligentMissiveAppService.queryReviewDetail()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `taskId` | `java.lang.String` |

## `TableDetailReqDto`（2 字段）

`com.seeyon.cip.capability.dto.missive.TableDetailReqDto`

被这些方法当入参：

- `IntelligentMissiveAppService.queryTableDetail()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `taskId` | `java.lang.String` |

## `TableTaskReqDto`（2 字段）

`com.seeyon.cip.capability.dto.missive.TableTaskReqDto`

被这些方法当入参：

- `IntelligentMissiveAppService.createTableTask()`（包装入参）

| 字段 | 类型 |
|---|---|
| `storageKey` | `java.lang.String` |
| `fileName` | `java.lang.String` |

## `MobilePluginAppletReceiveTicketDto`（2 字段）

`com.seeyon.cip.capability.dto.mobileplugin.applet.MobilePluginAppletReceiveTicketDto`

被这些方法当入参：

- `MobilePluginAppletAppService.receiveTicket()`（包装入参）

| 字段 | 类型 |
|---|---|
| `miniType` | `java.lang.String` |
| `extraParams` | `java.util.Map<java.lang.String, java.lang.Object>` |

## `OfdMetaDataReqDto`（2 字段）

`com.seeyon.cip.capability.dto.ofd.OfdMetaDataReqDto`

被这些方法当入参：

- `OfdAppService.getOfdMetaData()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `storageKey` | `java.lang.String` |

## `OfdSealItemReqDto`（2 字段）

`com.seeyon.cip.capability.dto.ofd.OfdSealItemReqDto`

被这些方法当入参：

- `OfdAppService.getSealList()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `loginName` | `java.lang.String` |

## `RepeatSignRequestDto`（2 字段）

`com.seeyon.cip.capability.dto.sms.RepeatSignRequestDto`

被这些方法当入参：

- `ShortMessageSignAppService.checkRepeatSignName()`（包装入参）

| 字段 | 类型 |
|---|---|
| `id` | `java.lang.Long` |
| `signName` | `java.lang.String` |

## `CreateWordsDto`（2 字段）

`com.seeyon.cip.capability.dto.voice.CreateWordsDto`

被这些方法当入参：

- `VoiceAppService.createFileConvertWords()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `details` | `java.util.List<com.seeyon.cip.capability.dto.voice.CreateWordsDetailDto>` |

## `QueryConvertResultDto`（2 字段）

`com.seeyon.cip.capability.dto.voice.QueryConvertResultDto`

被这些方法当入参：

- `VoiceAppService.queryConvertWordsResult()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `convertWordsTaskIds` | `java.util.List<java.lang.String>` |

## `QueryIntelligentDigestDto`（2 字段）

`com.seeyon.cip.capability.dto.voice.QueryIntelligentDigestDto`

被这些方法当入参：

- `VoiceAppService.queryIntelligentDigestResult()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `taskId` | `java.lang.Long` |

## `QueryVoiceFileDto`（2 字段）

`com.seeyon.cip.capability.dto.voice.QueryVoiceFileDto`

被这些方法当入参：

- `VoiceAppService.queryVoiceFileResult()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `voiceFileId` | `java.lang.String` |

## `ExecuteSqlApiDto`（2 字段）

`com.seeyon.cip.connector.dto.db.ExecuteSqlApiDto`

被这些方法当入参：

- `DataBaseExecutorService.executeSql()`（裸参数）

| 字段 | 类型 |
|---|---|
| `dataSourceId` | `java.lang.Long` |
| `sql` | `java.lang.String` |

## `ExecuteSqlDto`（2 字段）

`com.seeyon.cip.connector.dto.execute.ExecuteSqlDto`

被这些方法当入参：

- `LinkerAppService.executeSql()`（包装入参）

| 字段 | 类型 |
|---|---|
| `dataSourceId` | `java.lang.Long` |
| `sql` | `java.lang.String` |

## `LinkMigrationRequestDto`（2 字段）

`com.seeyon.cip.connector.dto.info.LinkMigrationRequestDto`

被这些方法当入参：

- `LinkerMigrationAppService.exportEntityTask()`（包装入参）

| 字段 | 类型 |
|---|---|
| `entityNameList` | `java.util.Map<java.lang.String, java.util.Map<java.lang.String, java.lang.Object>>` |
| `envList` | `java.util.List<java.lang.String>` |

## `MobileLaunchCodeDto`（2 字段）

`com.seeyon.cip.connector.dto.mobile.MobileLaunchCodeDto`

被这些方法当入参：

- `MobileApplicationProviderService.getLaunchCode()`（裸参数）

| 字段 | 类型 |
|---|---|
| `userId` | `java.lang.String` |
| `operatorUserid` | `java.lang.String` |

## `RecallMessageDto`（2 字段）

`com.seeyon.cip.connector.dto.mobile.RecallMessageDto`

被这些方法当入参：

- `MobileApplicationProviderService.recallMessage()`（裸参数）

| 字段 | 类型 |
|---|---|
| `outMsgId` | `java.lang.String` |
| `interfaceDomain` | `java.lang.String` |

## `LevelInfoReqDto`（2 字段）

`com.seeyon.cip.plug.dto.midddletable.LevelInfoReqDto`

被这些方法当入参：

- `MiddleTableOperationAppService.saveLevel()`（包装入参）

| 字段 | 类型 |
|---|---|
| `linkerId` | `java.lang.Long` |
| `data` | `java.util.List<com.seeyon.cip.plug.dto.midddletable.LevelInfoDto>` |

## `MemberInfoReqDto`（2 字段）

`com.seeyon.cip.plug.dto.midddletable.MemberInfoReqDto`

被这些方法当入参：

- `MiddleTableOperationAppService.saveMember()`（包装入参）

| 字段 | 类型 |
|---|---|
| `linkerId` | `java.lang.Long` |
| `data` | `java.util.List<com.seeyon.cip.plug.dto.midddletable.MemberInfoDto>` |

## `UnitInfoReqDto`（2 字段）

`com.seeyon.cip.plug.dto.midddletable.UnitInfoReqDto`

被这些方法当入参：

- `MiddleTableOperationAppService.saveUnit()`（包装入参）

| 字段 | 类型 |
|---|---|
| `linkerId` | `java.lang.Long` |
| `data` | `java.util.List<com.seeyon.cip.plug.dto.midddletable.UnitInfoDto>` |

## `CreditRequestDto`（2 字段）

`com.seeyon.cip.provider.dto.credit.CreditRequestDto`

被这些方法当入参：

- `EnterpriseCreditAppService.getBasicInfo()`（包装入参）
- `EnterpriseCreditAppService.getPartners()`（包装入参）
- `EnterpriseCreditAppService.getCourtNotice()`（包装入参）
- `EnterpriseCreditAppService.getCaseDetailList()`（包装入参）
- `EnterpriseCreditAppService.getAdminPunish()`（包装入参）
- `EnterpriseCreditAppService.getEnvp()`（包装入参）
- … 另 15 处

| 字段 | 类型 |
|---|---|
| `keyword` | `java.lang.String` |
| `skip` | `java.lang.Integer` |

## `CreditRequestExtendDto`（2 字段）

`com.seeyon.cip.provider.dto.credit.CreditRequestExtendDto`

被这些方法当入参：

- `EnterpriseCreditAppService.getEntJusticeScore()`（包装入参）

| 字段 | 类型 |
|---|---|
| `keyword` | `java.lang.String` |
| `riskType` | `java.lang.String` |

## `GeocoderRequestDto`（2 字段）

`com.seeyon.cip.provider.dto.location.GeocoderRequestDto`

被这些方法当入参：

- `LocationAppService.geocoding()`（包装入参）

| 字段 | 类型 |
|---|---|
| `address` | `java.lang.String` |
| `city` | `java.lang.String` |

## `PhysicalSealApplyIdDto`（2 字段）

`com.seeyon.cip.provider.dto.physicalseal.PhysicalSealApplyIdDto`

被这些方法当入参：

- `PhysicalSealAppService.queryApplyRecord()`（包装入参）
- `PhysicalSealAppService.cancelApply()`（包装入参）
- `PhysicalSealAppService.getImageByApplyId()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `applyId` | `java.lang.String` |

## `ResumeRequestDto`（2 字段）

`com.seeyon.cip.provider.dto.resume.request.ResumeRequestDto`

被这些方法当入参：

- `ResumeAppService.analysisResume()`（包装入参）

| 字段 | 类型 |
|---|---|
| `fileName` | `java.lang.String` |
| `storageKey` | `java.lang.String` |

## `ScheduleInfoDto`（2 字段）

`com.seeyon.cip.provider.dto.schedule.ScheduleInfoDto`

被这些方法当入参：

- `ScheduleAppService.cancelSchedule()`（包装入参）
- `ScheduleAppService.detailSchedule()`（包装入参）

| 字段 | 类型 |
|---|---|
| `scheduleId` | `java.lang.String` |
| `map` | `java.util.Map<java.lang.String, java.lang.Object>` |

## `BatchCreateUserDto`（2 字段）

`com.seeyon.cip.provider.dto.signature.org.BatchCreateUserDto`

被这些方法当入参：

- `SignatureAppService.batchCreateUser()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `userDtoList` | `java.util.List<com.seeyon.cip.provider.dto.signature.org.UserDto>` |

## `DeleteInnerUsersReqDto`（2 字段）

`com.seeyon.cip.provider.dto.signature.org.DeleteInnerUsersReqDto`

被这些方法当入参：

- `SignatureAppService.deleteInnerUsers()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `userCode` | `java.lang.String` |

## `UserUpdateDto`（2 字段）

`com.seeyon.cip.provider.dto.signature.org.UserUpdateDto`

被这些方法当入参：

- `SignatureAppService.userUpdate()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `userCode` | `java.lang.String` |

## `SignAreaSelectDto`（2 字段）

`com.seeyon.cip.provider.dto.signature.sign.SignAreaSelectDto`

被这些方法当入参：

- `SignatureAppService.signToolsConfigDetail()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `filePreTaskId` | `java.lang.String` |

## `VerifySealDto`（2 字段）

`com.seeyon.cip.provider.dto.signature.sign.VerifySealDto`

被这些方法当入参：

- `SignatureAppService.verifySeal()`（包装入参）

| 字段 | 类型 |
|---|---|
| `businessNo` | `java.lang.String` |
| `signFlowId` | `java.lang.String` |

## `TemplatePageDto`（2 字段）

`com.seeyon.cip.provider.dto.signature.template.TemplatePageDto`

被这些方法当入参：

- `SignatureAppService.selectPageByConditions()`（裸参数）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `templateName` | `java.lang.String` |

## `SmsTemplateQueryDto`（2 字段）

`com.seeyon.cip.provider.dto.sms.SmsTemplateQueryDto`

被这些方法当入参：

- `ShortMessageTemplateAppService.selectTemplateByCode()`（包装入参）

| 字段 | 类型 |
|---|---|
| `code` | `java.lang.String` |
| `language` | `java.lang.String` |

## `TripInvoiceQueryRequestDto`（2 字段）

`com.seeyon.cip.provider.dto.trip.TripInvoiceQueryRequestDto`

被这些方法当入参：

- `BusinessTripAppService.invoiceSearch()`（包装入参）

| 字段 | 类型 |
|---|---|
| `userId` | `java.lang.String` |
| `title` | `java.lang.String` |

## `VideoMeetingDetailDto`（2 字段）

`com.seeyon.cip.provider.dto.video.request.VideoMeetingDetailDto`

被这些方法当入参：

- `VideoMeetingAppService.getMeetingDetail()`（包装入参）

| 字段 | 类型 |
|---|---|
| `meetingId` | `java.lang.String` |
| `userID` | `java.lang.String` |

## `VideoMeetingRoomAllotDto`（2 字段）

`com.seeyon.cip.provider.dto.video.request.VideoMeetingRoomAllotDto`

被这些方法当入参：

- `VideoMeetingAppService.allotVmwareMeetingRoom()`（包装入参）

| 字段 | 类型 |
|---|---|
| `account` | `java.lang.String` |
| `roomId` | `java.lang.String` |

## `VideoMeetingUpdateDto`（2 字段）

`com.seeyon.cip.provider.dto.video.request.VideoMeetingUpdateDto`

被这些方法当入参：

- `VideoMeetingAppService.updateVideoMeeting()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `meetingId` | `java.lang.String` |

## `OrgMappingDetailDeleteReqDto`（1 字段）

`com.seeyon.cip.application.dto.mappingconfig.OrgMappingDetailDeleteReqDto`

被这些方法当入参：

- `MappingDetailAppService.deleteOrgMappingDetail()`（包装入参）

| 字段 | 类型 |
|---|---|
| `detailId` | `java.lang.Long` |

## `UserMappingDetailDeleteReqDto`（1 字段）

`com.seeyon.cip.application.dto.mappingconfig.UserMappingDetailDeleteReqDto`

被这些方法当入参：

- `MappingDetailAppService.deleteUserMappingDetail()`（包装入参）

| 字段 | 类型 |
|---|---|
| `detailId` | `java.lang.Long` |

## `RecallMsgDto`（1 字段）

`com.seeyon.cip.application.dto.mobile.RecallMsgDto`

被这些方法当入参：

- `ApplicationMobileAppService.recallMessage()`（包装入参）

| 字段 | 类型 |
|---|---|
| `identification` | `java.lang.String` |

## `CapabilityCountQueryDto`（1 字段）

`com.seeyon.cip.capability.dto.CapabilityCountQueryDto`

被这些方法当入参：

- `OpenCapabilityAppService.queryUseCount()`（包装入参）

| 字段 | 类型 |
|---|---|
| `openAppId` | `java.lang.Long` |

## `CityCodeComparisonTableDownloadReqDto`（1 字段）

`com.seeyon.cip.capability.dto.bankpay.other.CityCodeComparisonTableDownloadReqDto`

被这些方法当入参：

- `BankpayAppService.cityCodeComparisonTableDownload()`（包装入参）

| 字段 | 类型 |
|---|---|
| `userName` | `java.lang.String` |

## `CurrencyCodeComparisonTableDownloadReqDto`（1 字段）

`com.seeyon.cip.capability.dto.bankpay.other.CurrencyCodeComparisonTableDownloadReqDto`

被这些方法当入参：

- `BankpayAppService.currencyCodeComparisonTableDownload()`（包装入参）

| 字段 | 类型 |
|---|---|
| `userName` | `java.lang.String` |

## `BpmTemplateValidCheckRequestDto`（1 字段）

`com.seeyon.cip.capability.dto.econtracts.request.BpmTemplateValidCheckRequestDto`

被这些方法当入参：

- `ContractsAppService.processBpmTemplateValidCheck()`（包装入参）

| 字段 | 类型 |
|---|---|
| `commonBpmTemplateValidCheckDto` | `com.seeyon.cip.capability.dto.econtracts.request.CommonBpmTemplateValidCheckDto` |

## `InvoiceOcrAsyncDto`（1 字段）

`com.seeyon.cip.capability.dto.invoice.request.InvoiceOcrAsyncDto`

被这些方法当入参：

- `InvoiceAppService.getOcrAsyncResult()`（包装入参）

| 字段 | 类型 |
|---|---|
| `invokeId` | `java.lang.Long` |

## `CapabilityNameEnumDto`（1 字段）

`com.seeyon.cip.capability.dto.manage.CapabilityNameEnumDto`

被这些方法当入参：

- `CapabilityManageAppService.queryEnable()`（包装入参）

| 字段 | 类型 |
|---|---|
| `capabilityEnum` | `com.seeyon.cip.provider.enums.CapabilityEnum` |

## `CipAppFeatureProviderCreateInDto`（1 字段）

`com.seeyon.cip.capability.dto.manage.appchannel.CipAppFeatureProviderCreateInDto`

被这些方法当入参：

- `CapabilityManageAppService.createAppConfig()`（包装入参）
- `CapabilityManageAppService.updateAppConfig()`（包装入参）

| 字段 | 类型 |
|---|---|
| `featureProviderList` | `java.util.List<com.seeyon.cip.capability.dto.manage.appchannel.CipAppFeatureProviderCreateDto>` |

## `DiffRuleReqDto`（1 字段）

`com.seeyon.cip.capability.dto.missive.DiffRuleReqDto`

被这些方法当入参：

- `IntelligentMissiveAppService.queryDiffRule()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |

## `MobilePluginMobilePluginAppletOpenAuditQueryDto`（1 字段）

`com.seeyon.cip.capability.dto.mobileplugin.applet.MobilePluginMobilePluginAppletOpenAuditQueryDto`

被这些方法当入参：

- `MobilePluginAppletAppService.getAuditStatus()`（包装入参）

| 字段 | 类型 |
|---|---|
| `auditId` | `java.lang.String` |

## `CreateVoiceFileDto`（1 字段）

`com.seeyon.cip.capability.dto.voice.CreateVoiceFileDto`

被这些方法当入参：

- `VoiceAppService.createVoiceFile()`（包装入参）

| 字段 | 类型 |
|---|---|
| `realTimeTaskId` | `java.lang.String` |

## `RealtimeDto`（1 字段）

`com.seeyon.cip.capability.dto.voice.RealtimeDto`

被这些方法当入参：

- `VoiceAppService.createRealTime()`（包装入参）

| 字段 | 类型 |
|---|---|
| `taskId` | `java.lang.String` |

## `ConnectorMigrateImportResponseDto`（1 字段）

`com.seeyon.cip.connector.dto.migrate.ConnectorMigrateImportResponseDto`

被这些方法当入参：

- `LinkerMigrationAppService.importConnectorData()`（包装入参）

| 字段 | 类型 |
|---|---|
| `connectorMigrateDtoList` | `java.util.List<com.seeyon.cip.connector.dto.migrate.ConnectorMigrateDto>` |

## `ConnectorMigrateRequestDto`（1 字段）

`com.seeyon.cip.connector.dto.migrate.ConnectorMigrateRequestDto`

被这些方法当入参：

- `LinkerMigrationAppService.listConnectorData()`（包装入参）

| 字段 | 类型 |
|---|---|
| `linkerNameList` | `java.util.List<java.lang.String>` |

## `CapabilityInfoQueryDto`（1 字段）

`com.seeyon.cip.plug.dto.CapabilityInfoQueryDto`

被这些方法当入参：

- `CipPlugCapabilityAppService.getAndCheckCapability()`（包装入参）

| 字段 | 类型 |
|---|---|
| `ids` | `java.util.List<java.lang.Long>` |

## `RunningOrgSyncNowDto`（1 字段）

`com.seeyon.cip.plug.dto.midddletable.RunningOrgSyncNowDto`

被这些方法当入参：

- `MiddleTableOperationAppService.runningOrgSyncNowByLinkerCode()`（包装入参）

| 字段 | 类型 |
|---|---|
| `linkerCode` | `java.lang.String` |

## `FieldMappingRequestDto`（1 字段）

`com.seeyon.cip.provider.dto.archives.FieldMappingRequestDto`

被这些方法当入参：

- `ArchivesAppService.selectAttributesByTypeIds()`（包装入参）

| 字段 | 类型 |
|---|---|
| `categoryIdList` | `java.util.List<java.lang.String>` |

## `OfflineMessageDto`（1 字段）

`com.seeyon.cip.provider.dto.message.offline.OfflineMessageDto`

被这些方法当入参：

- `OfflineMessageAppService.pushMessage()`（包装入参）

| 字段 | 类型 |
|---|---|
| `offlineUserDtos` | `java.util.Set<com.seeyon.cip.provider.dto.message.offline.OfflineUserDto>` |

## `CertificateReqDto`（1 字段）

`com.seeyon.cip.provider.dto.pay.CertificateReqDto`

被这些方法当入参：

- `PayAppService.getCert()`（包装入参）

| 字段 | 类型 |
|---|---|
| `mchid` | `java.lang.String` |

## `PhysicalSealEmptyDto`（1 字段）

`com.seeyon.cip.provider.dto.physicalseal.PhysicalSealEmptyDto`

被这些方法当入参：

- `PhysicalSealAppService.querySeals()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |

## `UpdateScheduleDto`（1 字段）

`com.seeyon.cip.provider.dto.schedule.UpdateScheduleDto`

被这些方法当入参：

- `ScheduleAppService.updateSchedule()`（包装入参）

| 字段 | 类型 |
|---|---|
| `scheduleId` | `java.lang.String` |

## `OuterBatchCreateUserDto`（1 字段）

`com.seeyon.cip.provider.dto.signature.org.outer.OuterBatchCreateUserDto`

被这些方法当入参：

- `SignatureAppService.batchCreateOuterUser()`（包装入参）

| 字段 | 类型 |
|---|---|
| `userDtoList` | `java.util.List<com.seeyon.cip.provider.dto.signature.org.outer.OuterUserDto>` |

## `OuterUserUpdateDto`（1 字段）

`com.seeyon.cip.provider.dto.signature.org.outer.OuterUserUpdateDto`

被这些方法当入参：

- `SignatureAppService.outerUserUpdate()`（包装入参）

| 字段 | 类型 |
|---|---|
| `userCode` | `java.lang.String` |

## `TemplateBaseDto`（1 字段）

`com.seeyon.cip.provider.dto.signature.template.TemplateBaseDto`

被这些方法当入参：

- `SignatureAppService.getTemplateContents()`（包装入参）

| 字段 | 类型 |
|---|---|
| `templateId` | `java.lang.String` |

## `TripCitySyncRequestDto`（1 字段）

`com.seeyon.cip.provider.dto.trip.TripCitySyncRequestDto`

被这些方法当入参：

- `BusinessTripAppService.isvCitySync()`（包装入参）

| 字段 | 类型 |
|---|---|
| `countryId` | `java.lang.Long` |

## `TripDeptSyncRequestDto`（1 字段）

`com.seeyon.cip.provider.dto.trip.TripDeptSyncRequestDto`

被这些方法当入参：

- `BusinessTripAppService.departmentSync()`（包装入参）

| 字段 | 类型 |
|---|---|
| `departList` | `java.util.List<com.seeyon.cip.provider.dto.trip.TripDeptSyncRequestDto$DeptSyncRequestDepartList>` |

## `TripUserSyncRequestDto`（1 字段）

`com.seeyon.cip.provider.dto.trip.TripUserSyncRequestDto`

被这些方法当入参：

- `BusinessTripAppService.isvUserSync()`（包装入参）

| 字段 | 类型 |
|---|---|
| `userList` | `java.util.List<com.seeyon.cip.provider.dto.trip.TripUserSyncRequestDto$UserSyncRequestDepartDto>` |
