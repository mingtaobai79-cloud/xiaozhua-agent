# 协同（事项/人员/消息）：入参 DTO 字段表

> 自动生成。包前缀 `com.seeyon.ctp`。共 112 个 DTO。
> 字段类型逐字来自 javap；`static` 前缀表示常量而非实例字段。

## `CtpResourceDto`（48 字段）

`com.seeyon.ctp.user.dto.CtpResourceDto`

被这些方法当入参：

- `CtpResourceCoreAppService.register()`（包装入参）
- `CtpResourceCoreAppService.updateByCode()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `id` | `java.lang.Long` |
| `code` | `java.lang.String` |
| `name` | `java.lang.String` |
| `icon` | `java.lang.String` |
| `parentId` | `java.lang.Long` |
| `level` | `java.lang.Integer` |
| `path` | `java.lang.String` |
| `url` | `java.lang.String` |
| `urlParameters` | `java.lang.String` |
| `outParameters` | `java.lang.String` |
| `openType` | `java.lang.String` |
| `restUrl` | `java.lang.String` |
| `admin` | `java.lang.Boolean` |
| `sortNumber` | `java.lang.Integer` |
| `appId` | `java.lang.String` |
| `entityFullName` | `java.lang.String` |
| `appType` | `com.seeyon.ctp.user.enums.ResourceAppTypeEnum` |
| `frontendAppId` | `java.lang.String` |
| `origin` | `com.seeyon.ctp.user.enums.ResourceOriginEnum` |
| `type` | `com.seeyon.ctp.user.enums.ResourceTypeEnum` |
| `clientType` | `com.seeyon.ctp.user.enums.ResourceClientTypeEnum` |
| `dataType` | `java.lang.String` |
| `dataStatus` | `java.lang.Integer` |
| `orgId` | `java.lang.Long` |
| `referId` | `java.lang.Long` |
| `referAppId` | `java.lang.String` |
| `referConfig` | `java.lang.String` |
| `objectId` | `java.lang.Long` |
| `children` | `java.util.List<com.seeyon.ctp.user.dto.CtpResourceDto>` |
| `elements` | `java.util.List<com.seeyon.ctp.user.dto.CtpResourceDto>` |
| `createTime` | `java.util.Date` |
| `updateTime` | `java.util.Date` |
| `groupId` | `java.lang.Long` |
| `countRule` | `java.lang.String` |
| `plugins` | `java.lang.String` |
| `singleSign` | `boolean` |
| `pluginId` | `java.lang.Long` |
| `browserOpenType` | `com.seeyon.ctp.user.enums.BrowserOpenTypeEnum` |
| `packageTime` | `java.lang.Long` |
| `mainAppId` | `java.lang.String` |
| `publicAccess` | `java.lang.Boolean` |
| `countStatus` | `java.lang.Boolean` |
| `countPluginId` | `java.lang.Long` |
| `isVirtual` | `java.lang.Boolean` |
| `adminResource` | `java.lang.Boolean` |
| `edit` | `java.lang.Boolean` |
| `maxAction` | `com.seeyon.ctp.user.enums.ResourceActionEnum` |

## `AffairDto`（38 字段）

`com.seeyon.ctp.affair.dto.table.AffairDto`

被这些方法当入参：

- `AffairSuperviseAppService.updateTemplateAccountId2Affairs()`（裸参数）

| 字段 | 类型 |
|---|---|
| `extInfo` | `java.util.Map<java.lang.String, java.lang.Object>` |
| `propertyInfo` | `java.util.Map<java.lang.String, com.seeyon.ctp.affair.dto.table.AffairPropertyInfoDto>` |
| `extLong1` | `java.lang.Long` |
| `extLong2` | `java.lang.Long` |
| `extLong3` | `java.lang.Long` |
| `extLong4` | `java.lang.Long` |
| `extLong5` | `java.lang.Long` |
| `extLong6` | `java.lang.Long` |
| `extLong7` | `java.lang.Long` |
| `extString1` | `java.lang.String` |
| `extString2` | `java.lang.String` |
| `extString3` | `java.lang.String` |
| `extString4` | `java.lang.String` |
| `extString5` | `java.lang.String` |
| `extString6` | `java.lang.String` |
| `extString7` | `java.lang.String` |
| `extString8` | `java.lang.String` |
| `extString9` | `java.lang.String` |
| `extString10` | `java.lang.String` |
| `extString11` | `java.lang.String` |
| `extString12` | `java.lang.String` |
| `extSmallInt1` | `java.lang.Integer` |
| `extSmallInt2` | `java.lang.Integer` |
| `extSmallInt3` | `java.lang.Integer` |
| `extSmallInt4` | `java.lang.Integer` |
| `extSmallInt5` | `java.lang.Integer` |
| `extDateTime1` | `java.util.Date` |
| `extDateTime2` | `java.util.Date` |
| `extDateTime3` | `java.util.Date` |
| `extDateTime4` | `java.util.Date` |
| `extDateTime5` | `java.util.Date` |
| `extDecimal1` | `java.lang.Double` |
| `extDecimal2` | `java.lang.Double` |
| `extDecimal3` | `java.lang.Double` |
| `extDecimal4` | `java.lang.Double` |
| `extDecimal5` | `java.lang.Double` |
| `currentPendingMemberIds` | `java.lang.String` |
| `currentPendingNodeName` | `java.lang.String` |

## `CtpUserResourceDto`（34 字段）

`com.seeyon.ctp.user.dto.CtpUserResourceDto`

被这些方法当入参：

- `CtpUserResourceCoreAppService.createBatch()`（裸参数）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `id` | `java.lang.Long` |
| `userId` | `java.lang.Long` |
| `orgId` | `java.lang.Long` |
| `memberPostId` | `java.lang.Long` |
| `effectiveTime` | `java.util.Date` |
| `invalidTime` | `java.util.Date` |
| `isEnable` | `java.lang.Boolean` |
| `roleId` | `java.lang.Long` |
| `userName` | `java.lang.String` |
| `originId` | `java.lang.Long` |
| `resourceId` | `java.lang.Long` |
| `resourceCode` | `java.lang.String` |
| `resourceName` | `java.lang.String` |
| `resourceIcon` | `java.lang.String` |
| `resourceParentCode` | `java.lang.String` |
| `resourceParentId` | `java.lang.Long` |
| `resourceLevel` | `java.lang.Integer` |
| `resourcePath` | `java.lang.String` |
| `resourceUrl` | `java.lang.String` |
| `resourceOpenType` | `java.lang.String` |
| `resourceAdmin` | `java.lang.Boolean` |
| `resourceSortNumber` | `java.lang.Integer` |
| `resourceAppId` | `java.lang.String` |
| `resourceType` | `com.seeyon.ctp.user.enums.ResourceTypeEnum` |
| `resourceDataType` | `java.lang.String` |
| `resourcePermissionType` | `java.lang.String` |
| `resourceClientType` | `com.seeyon.ctp.user.enums.ResourceClientTypeEnum` |
| `action` | `com.seeyon.ctp.user.enums.ResourceActionEnum` |
| `resourceOrgId` | `java.lang.Long` |
| `createTime` | `java.util.Date` |
| `creatorId` | `java.lang.Long` |
| `creatorName` | `java.lang.String` |
| `includeChild` | `java.lang.Boolean` |

## `CtpRoleDto`（33 字段）

`com.seeyon.ctp.user.dto.CtpRoleDto`

被这些方法当入参：

- `CtpRoleCoreAppService.create()`（包装入参）
- `CtpRoleCoreAppService.update()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `id` | `java.lang.Long` |
| `code` | `java.lang.String` |
| `name` | `java.lang.String` |
| `description` | `java.lang.String` |
| `orgId` | `java.lang.Long` |
| `system` | `java.lang.Boolean` |
| `admin` | `java.lang.Boolean` |
| `type` | `com.seeyon.ctp.user.enums.RoleTypeEnum` |
| `appId` | `java.lang.String` |
| `appName` | `java.lang.String` |
| `sortNumber` | `java.lang.Integer` |
| `enabled` | `java.lang.Boolean` |
| `resourceList` | `java.util.List<com.seeyon.ctp.user.dto.CtpRoleResourceActionDto>` |
| `appIds` | `java.util.List<java.lang.String>` |
| `creatorId` | `java.lang.Long` |
| `creatorName` | `java.lang.String` |
| `isRoot` | `java.lang.Boolean` |
| `appAdmin` | `java.lang.Boolean` |
| `status` | `com.seeyon.ctp.user.enums.ApprovalStatusEnum` |
| `display` | `java.lang.Boolean` |
| `dataStatus` | `java.lang.Integer` |
| `relationOrgRoleCode` | `java.lang.String` |
| `editPermission` | `java.lang.Boolean` |
| `dataSignSuccess` | `java.lang.Integer` |
| `roleLevel` | `com.seeyon.ctp.user.enums.RoleLevelEnum` |
| `orgScope` | `java.lang.String` |
| `scopeType` | `com.seeyon.ctp.user.enums.OrgScopeEnum` |
| `appList` | `java.util.List<com.seeyon.ctp.user.dto.CtpRoleApplicationResourceDto>` |
| `defaultOrgScop` | `com.seeyon.ctp.user.enums.DefaultOrgScopeEnum` |
| `specifyUnits` | `java.lang.String` |
| `associationRoleCode` | `java.lang.String` |
| `virtual` | `java.lang.Boolean` |

## `CtpUserDto`（31 字段）

`com.seeyon.ctp.user.dto.CtpUserDto`

被这些方法当入参：

- `CtpUserCoreAppService.beforeCreateCheck()`（包装入参）
- `CtpUserCoreAppService.create()`（包装入参）
- `CtpUserCoreAppService.createBatch()`（裸参数）
- `CtpUserCoreAppService.beforeUpdateCheck()`（包装入参）
- `CtpUserCoreAppService.update()`（包装入参）
- `CtpUserCoreAppService.updateBatch()`（裸参数）
- … 另 4 处

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `id` | `java.lang.Long` |
| `tenantId` | `java.lang.Long` |
| `name` | `java.lang.String` |
| `loginName` | `java.lang.String` |
| `password` | `java.lang.String` |
| `expiredTime` | `java.util.Date` |
| `modifyTime` | `java.util.Date` |
| `avatar` | `java.lang.String` |
| `phoneNumber` | `java.lang.String` |
| `email` | `java.lang.String` |
| `code` | `java.lang.String` |
| `admin` | `java.lang.Boolean` |
| `type` | `com.seeyon.ctp.user.enums.UserTypeEnum` |
| `memberId` | `java.lang.Long` |
| `orgId` | `java.lang.Long` |
| `orgName` | `java.lang.String` |
| `pathName` | `java.lang.String` |
| `authOrgIdList` | `java.util.List<java.lang.Long>` |
| `enabled` | `java.lang.Boolean` |
| `locale` | `java.lang.String` |
| `effectiveTime` | `java.util.Date` |
| `invalidTime` | `java.util.Date` |
| `effective` | `java.lang.Boolean` |
| `lastLoginDevice` | `java.lang.String` |
| `lastLoginIp` | `java.lang.String` |
| `lastLoginTime` | `java.util.Date` |
| `createTime` | `java.util.Date` |
| `memberPostId` | `java.lang.Long` |
| `clientLoginTime` | `java.lang.String` |
| `dataSignSuccess` | `java.lang.Integer` |

## `AffairOpenConditionDto`（30 字段）

`com.seeyon.ctp.affair.dto.open.AffairOpenConditionDto`

被这些方法当入参：

- `AffairOpenAppService.selectPageByCondition()`（包装入参）
- `AffairOpenAppService.selectByConditionIgnoreTenant()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `title` | `java.lang.String` |
| `state` | `java.util.List<com.seeyon.ctp.affair.enums.AffairStateEnum>` |
| `subState` | `java.util.List<java.lang.String>` |
| `objectId` | `java.lang.Long` |
| `nodePermissionTypeCode` | `java.lang.String` |
| `objectStates` | `java.util.List<java.lang.Integer>` |
| `notInNodePermissionTypeCodes` | `java.util.List<java.lang.String>` |
| `templateId` | `java.util.List<java.lang.Long>` |
| `templateCode` | `java.lang.String` |
| `templateGuid` | `java.util.List<java.lang.Long>` |
| `startMemberId` | `java.lang.Long` |
| `startMemberIds` | `java.util.List<com.seeyon.ctp.affair.dto.base.AffairUserRelationIdDto>` |
| `receiveMemberId` | `java.lang.Long` |
| `createTimeStart` | `java.util.Date` |
| `createTimeEnd` | `java.util.Date` |
| `dealTimeStart` | `java.util.Date` |
| `dealTimeEnd` | `java.util.Date` |
| `updateTimeStart` | `java.util.Date` |
| `updateTimeEnd` | `java.util.Date` |
| `appNames` | `java.util.List<java.lang.String>` |
| `subAppNames` | `java.util.List<java.lang.String>` |
| `needDelete` | `java.lang.Boolean` |
| `pageInfo` | `com.seeyon.boot.transport.PageInfo` |
| `sort` | `com.seeyon.boot.transport.Sort` |
| `nodeId` | `java.lang.Long` |
| `idStart` | `java.lang.Long` |
| `formRecordCode` | `java.lang.String` |
| `billCode` | `java.lang.String` |
| `agentId` | `java.lang.Long` |

## `AffairNodePermissionDto`（27 字段）

`com.seeyon.ctp.affair.dto.AffairNodePermissionDto`

被这些方法当入参：

- `AffairNodePermissionAppService.createOrUpdate()`（裸参数）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `applicationName` | `java.lang.String` |
| `nodePermissionId` | `java.lang.Long` |
| `nodePermissionName` | `java.lang.String` |
| `nodePermissionCode` | `java.lang.String` |
| `type` | `com.seeyon.ctp.affair.enums.AffairNodePermissionTypeEnum` |
| `nodeType` | `com.seeyon.ctp.affair.enums.NodeTypeEnum` |
| `appName` | `java.lang.String` |
| `systemInit` | `java.lang.Boolean` |
| `systemDefault` | `java.lang.Boolean` |
| `workflow` | `java.lang.Boolean` |
| `createUserId` | `java.lang.Long` |
| `updateUserId` | `java.lang.Long` |
| `enable` | `java.lang.Boolean` |
| `orderNum` | `java.lang.Integer` |
| `designState` | `com.seeyon.ctp.affair.enums.AffairTemplateDesignState` |
| `accountId` | `java.lang.Long` |
| `init` | `java.lang.Byte` |
| `subApp` | `java.lang.String` |
| `mobileFrame` | `java.lang.String` |
| `pcFrame` | `java.lang.String` |
| `dataType` | `java.lang.Boolean` |
| `rootEntityName` | `java.lang.String` |
| `rootEntityId` | `java.lang.Long` |
| `batchAble` | `java.lang.Boolean` |
| `dataSource` | `com.seeyon.ctp.affair.enums.AffairNodeDataSourceEnum` |
| `operationType` | `java.lang.String` |

## `AffairMicroflowInfoDto`（27 字段）

`com.seeyon.ctp.affair.dto.microflow.AffairMicroflowInfoDto`

被这些方法当入参：

- `AffairMicroflowAppService.createAffairByMicroflow()`（包装入参）
- `AffairMicroflowAppService.createAffairByMicroflowReturnIds()`（包装入参）

| 字段 | 类型 |
|---|---|
| `operationType` | `com.seeyon.ctp.affair.enums.AffairOperationTypeEnum` |
| `state` | `com.seeyon.ctp.affair.enums.AffairStateEnum` |
| `subState` | `java.lang.String` |
| `startMemberId` | `java.lang.Long` |
| `receiveMemberIds` | `java.util.List<java.lang.Long>` |
| `startTime` | `java.util.Date` |
| `receiveTime` | `java.util.Date` |
| `title` | `java.lang.String` |
| `appName` | `java.lang.String` |
| `subAppName` | `java.lang.String` |
| `pageAddress` | `java.lang.String` |
| `mobileAddress` | `java.lang.String` |
| `formRecordId` | `java.lang.Long` |
| `formRecordCode` | `java.lang.String` |
| `categoryName` | `java.lang.String` |
| `objectState` | `java.lang.Integer` |
| `objectId` | `java.lang.Long` |
| `handlerId` | `java.lang.Long` |
| `extInfo` | `java.util.Map<java.lang.String, java.lang.Object>` |
| `whereExtInfo` | `java.util.Map<java.lang.String, java.lang.Object>` |
| `secretId` | `java.lang.Long` |
| `secretN` | `java.lang.Integer` |
| `icon` | `java.lang.String` |
| `attachment` | `boolean` |
| `importance` | `java.lang.Integer` |
| `nodePermissionType` | `com.seeyon.ctp.affair.enums.AffairNodePermissionTypeEnum` |
| `nodePermissionId` | `java.lang.Long` |

## `CtpLoginDto`（24 字段）

`com.seeyon.ctp.user.dto.CtpLoginDto`

被这些方法当入参：

- `CtpAuthCoreAppService.authenticate()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `loginName` | `java.lang.String` |
| `password` | `java.lang.String` |
| `captcha` | `java.lang.String` |
| `phoneNumber` | `java.lang.String` |
| `smsCaptcha` | `java.lang.String` |
| `tenantName` | `java.lang.String` |
| `clientType` | `com.seeyon.ctp.user.enums.ClientTypeEnum` |
| `locale` | `java.lang.String` |
| `loginDevice` | `com.seeyon.ctp.user.dto.CtpLoginDeviceDto` |
| `captchaId` | `java.lang.String` |
| `sid` | `java.lang.String` |
| `remoteAddress` | `java.lang.String` |
| `userAgent` | `java.lang.String` |
| `loginFrom` | `com.seeyon.ctp.user.enums.LoginFromEnum` |
| `qrCode` | `java.lang.String` |
| `openId` | `java.lang.String` |
| `ssoAppId` | `java.lang.String` |
| `ssoDomain` | `java.lang.String` |
| `guestUri` | `java.lang.String` |
| `publicAccessKey` | `java.lang.String` |
| `bindApp` | `java.lang.String` |
| `ukCipher` | `java.lang.String` |
| `extAuth` | `java.lang.String` |

## `CtpUserRoleDto`（24 字段）

`com.seeyon.ctp.user.dto.CtpUserRoleDto`

被这些方法当入参：

- `CtpUserRoleCoreAppService.createBatch()`（裸参数）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `id` | `java.lang.Long` |
| `userId` | `java.lang.Long` |
| `memberPostId` | `java.lang.Long` |
| `effectiveTime` | `java.util.Date` |
| `invalidTime` | `java.util.Date` |
| `isEnable` | `java.lang.Boolean` |
| `userName` | `java.lang.String` |
| `userType` | `com.seeyon.ctp.user.enums.UserTypeEnum` |
| `roleId` | `java.lang.Long` |
| `roleCode` | `java.lang.String` |
| `roleName` | `java.lang.String` |
| `roleAdmin` | `java.lang.Boolean` |
| `roleAppAdmin` | `java.lang.Boolean` |
| `orgScope` | `java.lang.String` |
| `orgId` | `java.lang.Long` |
| `orgName` | `java.lang.String` |
| `originId` | `java.lang.Long` |
| `createTime` | `java.util.Date` |
| `creatorId` | `java.lang.Long` |
| `creatorName` | `java.lang.String` |
| `manageScope` | `com.seeyon.ctp.user.enums.ManageScopeEnum` |
| `status` | `com.seeyon.ctp.user.enums.ApprovalStatusEnum` |
| `dataSignSuccess` | `java.lang.Integer` |

## `AffairFixedTemplateConditionDto`（22 字段）

`com.seeyon.ctp.affair.dto.supervise.AffairFixedTemplateConditionDto`

被这些方法当入参：

- `AffairSuperviseAppService.selectPageByFixedTemplate()`（包装入参）

| 字段 | 类型 |
|---|---|
| `onlyTotal` | `java.lang.Boolean` |
| `caseId` | `java.lang.Long` |
| `state` | `com.seeyon.ctp.affair.enums.AffairStateEnum` |
| `objectState` | `java.util.List<java.lang.Integer>` |
| `templateGuid` | `java.lang.Long` |
| `templateGuidList` | `java.util.List<java.lang.Long>` |
| `userIds` | `java.util.List<java.lang.Long>` |
| `title` | `java.lang.String` |
| `startMemberId` | `java.lang.Long` |
| `startMemberName` | `java.lang.String` |
| `startTimeLess` | `java.util.Date` |
| `startDepartmentIds` | `java.util.List<java.lang.Long>` |
| `startTimeGreater` | `java.util.Date` |
| `deadlineLess` | `java.util.Date` |
| `deadlineGreater` | `java.util.Date` |
| `receiveMemberId` | `java.lang.Long` |
| `templateAccountId` | `java.lang.Long` |
| `billCode` | `java.lang.String` |
| `billCodeEqualQuery` | `java.lang.Boolean` |
| `templateAccountIds` | `java.util.List<java.lang.Long>` |
| `startAccountIds` | `java.util.List<java.lang.Long>` |
| `orgScopeList` | `java.util.List<com.seeyon.ctp.affair.dto.supervise.AffairSuperviseScopeDto>` |

## `CtpApplicationRegisterDto`（22 字段）

`com.seeyon.ctp.application.dto.CtpApplicationRegisterDto`

被这些方法当入参：

- `CtpApplicationCommonAppService.register()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `icon` | `java.lang.String` |
| `appName` | `java.lang.String` |
| `appVersion` | `java.lang.String` |
| `description` | `java.lang.String` |
| `developer` | `java.lang.String` |
| `appId` | `java.lang.String` |
| `clientScope` | `com.seeyon.ctp.application.enums.ClientScopeEnum` |
| `mobileIndexPage` | `java.lang.String` |
| `webIndexPage` | `java.lang.String` |
| `adminIndexPage` | `java.lang.String` |
| `mobileAppId` | `java.lang.String` |
| `pluginType` | `com.seeyon.ctp.user.enums.PluginTypeEnum` |
| `guid` | `java.lang.Long` |
| `fromTenantId` | `java.lang.Long` |
| `onlineVersion` | `java.lang.String` |
| `onLine` | `java.lang.Boolean` |
| `systemTenant` | `java.lang.Boolean` |
| `source` | `com.seeyon.ctp.application.enums.AppSourceEnum` |
| `singleSign` | `boolean` |
| `ssoPluginId` | `java.lang.Long` |
| `status` | `java.lang.Boolean` |

## `CtpApplicationAdminCreateDto`（22 字段）

`com.seeyon.ctp.application.dto.application.admin.CtpApplicationAdminCreateDto`

被这些方法当入参：

- `CtpApplicationBaseAppService.create()`（包装入参）
- `CtpApplicationBaseAppService.update()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `id` | `java.lang.Long` |
| `guid` | `java.lang.Long` |
| `appName` | `java.lang.String` |
| `developer` | `java.lang.String` |
| `description` | `java.lang.String` |
| `icon` | `java.lang.String` |
| `adminIndexPage` | `java.lang.String` |
| `mobileIndexPageType` | `com.seeyon.ctp.application.enums.CtpAppHomePageTypeEnum` |
| `mobileIndexPage` | `java.lang.String` |
| `webIndexPageType` | `com.seeyon.ctp.application.enums.CtpAppHomePageTypeEnum` |
| `webIndexPage` | `java.lang.String` |
| `source` | `com.seeyon.ctp.application.enums.AppSourceEnum` |
| `clientScope` | `com.seeyon.ctp.application.enums.ClientScopeEnum` |
| `appId` | `java.lang.String` |
| `color` | `java.lang.String` |
| `singleSign` | `boolean` |
| `ssoPluginId` | `java.lang.Long` |
| `pluginType` | `com.seeyon.ctp.user.enums.PluginTypeEnum` |
| `status` | `java.lang.Boolean` |
| `theme` | `java.lang.Long` |
| `restoreDefault` | `java.lang.Boolean` |

## `CtpApplicationSyncDto`（21 字段）

`com.seeyon.ctp.application.dto.CtpApplicationSyncDto`

被这些方法当入参：

- `CtpApplicationBaseAppService.syncApplication()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `appName` | `java.lang.String` |
| `developer` | `java.lang.String` |
| `appVersion` | `java.lang.String` |
| `description` | `java.lang.String` |
| `icon` | `java.lang.String` |
| `adminIndexPage` | `java.lang.String` |
| `mobileIndexPageType` | `com.seeyon.ctp.application.enums.CtpAppHomePageTypeEnum` |
| `mobileIndexPage` | `java.lang.String` |
| `webIndexPageType` | `com.seeyon.ctp.application.enums.CtpAppHomePageTypeEnum` |
| `webIndexPage` | `java.lang.String` |
| `clientScope` | `com.seeyon.ctp.application.enums.ClientScopeEnum` |
| `appId` | `java.lang.String` |
| `mobileAppId` | `java.lang.String` |
| `color` | `java.lang.String` |
| `singleSign` | `boolean` |
| `ssoPluginId` | `java.lang.Long` |
| `pluginType` | `com.seeyon.ctp.user.enums.PluginTypeEnum` |
| `status` | `java.lang.Boolean` |
| `theme` | `java.lang.Long` |
| `autoFirstMenu` | `java.lang.Boolean` |

## `CtpApplicationAdminSimpleUpdateDto`（19 字段）

`com.seeyon.ctp.application.dto.application.admin.CtpApplicationAdminSimpleUpdateDto`

被这些方法当入参：

- `CtpApplicationBaseAppService.simpleUpdate()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `id` | `java.lang.Long` |
| `guid` | `java.lang.Long` |
| `appName` | `java.lang.String` |
| `developer` | `java.lang.String` |
| `adminIndexPage` | `java.lang.String` |
| `mobileIndexPageType` | `com.seeyon.ctp.application.enums.CtpAppHomePageTypeEnum` |
| `mobileIndexPage` | `java.lang.String` |
| `webIndexPageType` | `com.seeyon.ctp.application.enums.CtpAppHomePageTypeEnum` |
| `webIndexPage` | `java.lang.String` |
| `source` | `com.seeyon.ctp.application.enums.AppSourceEnum` |
| `clientScope` | `com.seeyon.ctp.application.enums.ClientScopeEnum` |
| `appId` | `java.lang.String` |
| `color` | `java.lang.String` |
| `singleSign` | `boolean` |
| `ssoPluginId` | `java.lang.Long` |
| `pluginType` | `com.seeyon.ctp.user.enums.PluginTypeEnum` |
| `status` | `java.lang.Boolean` |
| `theme` | `java.lang.Long` |

## `CtpPermissionApprovalDto`（18 字段）

`com.seeyon.ctp.user.dto.CtpPermissionApprovalDto`

被这些方法当入参：

- `CtpPermissionApprovalOrgAppService.update()`（包装入参）

| 字段 | 类型 |
|---|---|
| `id` | `java.lang.Long` |
| `roleId` | `java.lang.Long` |
| `roleAdmin` | `java.lang.Boolean` |
| `appId` | `java.util.List<java.lang.String>` |
| `authId` | `java.lang.Long` |
| `authValue` | `java.lang.String` |
| `orgId` | `java.lang.Long` |
| `content` | `java.lang.String` |
| `type` | `com.seeyon.ctp.user.enums.ApprovalTypeEnum` |
| `status` | `com.seeyon.ctp.user.enums.ApprovalStatusEnum` |
| `auditorId` | `java.lang.Long` |
| `auditorName` | `java.lang.String` |
| `createTime` | `java.util.Date` |
| `isPass` | `java.lang.Boolean` |
| `memberList` | `java.util.List<com.seeyon.ctp.user.dto.PermissionMemberDto>` |
| `entityList` | `java.util.List<com.seeyon.ctp.user.dto.PermissionEntityDto>` |
| `oldEntityName` | `java.util.List<java.lang.String>` |
| `entityName` | `java.util.List<java.lang.String>` |

## `MessageSendSimpleDto`（17 字段）

`com.seeyon.ctp.message.dto.MessageSendSimpleDto`

被这些方法当入参：

- `CtpMessageOpenApiService.sendMessageSimple()`（包装入参）

| 字段 | 类型 |
|---|---|
| `identification` | `java.lang.String` |
| `paramMode` | `com.seeyon.ctp.message.enums.ParamModeEnum` |
| `title` | `java.lang.String` |
| `senderId` | `java.lang.Long` |
| `messageTypeCode` | `java.lang.String` |
| `messageSourceCode` | `java.lang.String` |
| `messageTime` | `java.lang.Long` |
| `chooseJson` | `java.lang.String` |
| `templateDataMap` | `java.util.Map<java.lang.String, java.lang.String>` |
| `templateKey` | `java.lang.String` |
| `templateSourceCode` | `java.lang.String` |
| `userDtoList` | `java.util.List<com.seeyon.ctp.message.dto.UserDto>` |
| `mobileOpenUrl` | `java.lang.String` |
| `pcOpenUrl` | `java.lang.String` |
| `pcOpenType` | `java.lang.String` |
| `mobileOpenType` | `java.lang.String` |
| `senderType` | `com.seeyon.ctp.message.enums.SenderEnum` |

## `ServiceMetadataDto`（17 字段）

`com.seeyon.ctp.metadata.dto.ServiceMetadataDto`

被这些方法当入参：

- `AppFeatureHandler.getAvailableAppMetaDataList()`（裸参数）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `appName` | `java.lang.String` |
| `mavenInfo` | `com.seeyon.ctp.metadata.dto.model.MavenInfoDto` |
| `dynamicService` | `boolean` |
| `dynamicModuleGroup` | `java.lang.String` |
| `dynamicFeatureType` | `java.lang.String` |
| `hostAppName` | `java.lang.String` |
| `tenantId` | `java.lang.String` |
| `udcDesignVersion` | `java.lang.String` |
| `udcApp` | `boolean` |
| `enableGraphql` | `boolean` |
| `status` | `java.lang.String` |
| `appVersion` | `java.lang.String` |
| `caption` | `java.lang.String` |
| `description` | `java.lang.String` |
| `md5` | `java.lang.String` |
| `depends` | `java.util.List<com.seeyon.boot.context.model.BuildInfo>` |

## `EntityMetadataDto`（16 字段）

`com.seeyon.ctp.metadata.dto.EntityMetadataDto`

被这些方法当入参：

- `RuleDetailRtService.match()`（裸参数）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `tableName` | `java.lang.String` |
| `description` | `java.lang.String` |
| `superClass` | `java.lang.String` |
| `entityType` | `java.lang.String` |
| `historyEntity` | `java.lang.String` |
| `fullTextSearch` | `boolean` |
| `permission` | `boolean` |
| `isPublic` | `boolean` |
| `isLogicDelete` | `boolean` |
| `isExport` | `boolean` |
| `attributes` | `java.util.Map<java.lang.String, com.seeyon.ctp.metadata.dto.EntityAttributeMetadataDto>` |
| `referList` | `java.util.List<com.seeyon.ctp.metadata.dto.ReferMetadataDto>` |
| `indexList` | `java.util.List<com.seeyon.ctp.metadata.dto.model.EntityIndexDto>` |
| `uniqueList` | `java.util.List<com.seeyon.ctp.metadata.dto.model.EntityUniqueDto>` |
| `customs` | `java.util.Map<java.lang.String, java.lang.Object>` |

## `AffairSearchCustomizeDto`（15 字段）

`com.seeyon.ctp.affair.dto.search.AffairSearchCustomizeDto`

被这些方法当入参：

- `AffairCommonAppService.selectPageByCustomizeConditions()`（裸参数）
- `AffairCommonAppService.selectCountByCustomizeConditions()`（包装入参）

| 字段 | 类型 |
|---|---|
| `userId` | `java.lang.Long` |
| `dataRange` | `java.lang.String` |
| `type` | `java.util.List<java.lang.String>` |
| `conditionJsonStr` | `java.lang.String` |
| `fixedConditionJsonStr` | `java.lang.String` |
| `appName` | `java.lang.String` |
| `showType` | `java.util.List<com.seeyon.ctp.affair.enums.AffairStateEnum>` |
| `isOverDue` | `java.lang.Boolean` |
| `isWorkFlow` | `java.lang.Boolean` |
| `isAgent` | `java.lang.Boolean` |
| `subState` | `java.util.List<java.lang.String>` |
| `objectState` | `java.util.List<java.lang.Integer>` |
| `extraConditions` | `java.util.List<com.seeyon.ctp.affair.dto.category.AffairFilterConditionCustomizeDto>` |
| `orextraConditions` | `java.util.List<com.seeyon.ctp.affair.dto.category.AffairFilterConditionCustomizeDto>` |
| `head` | `java.util.List<com.seeyon.ctp.affair.dto.category.AffairColumnDto>` |

## `CtpManagerTenantDto`（15 字段）

`com.seeyon.ctp.manager.dto.CtpManagerTenantDto`

被这些方法当入参：

- `CtpManagerTenantAppService.create()`（包装入参）
- `CtpManagerTenantAppService.updateByUseTenantId()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `useTenantId` | `java.lang.Long` |
| `appNameList` | `java.util.List<java.lang.String>` |
| `replaces` | `java.util.Map<java.lang.String, java.lang.String>` |
| `useTenantDomain` | `java.lang.String` |
| `useTenantSubDomain` | `java.lang.String` |
| `perfix` | `java.lang.String` |
| `useTenantName` | `java.lang.String` |
| `useTenantCode` | `java.lang.String` |
| `remark` | `java.lang.String` |
| `status` | `com.seeyon.ctp.manager.enums.TenantStatusEnum` |
| `locale` | `java.lang.String` |
| `pluginAppNameList` | `java.util.List<java.lang.String>` |
| `createTime` | `java.util.Date` |
| `isDomain` | `java.lang.Boolean` |

## `MessageSendDto`（15 字段）

`com.seeyon.ctp.message.dto.MessageSendDto`

被这些方法当入参：

- `CtpMessageOpenApiService.sendMessage()`（包装入参）

| 字段 | 类型 |
|---|---|
| `messageChannelList` | `java.util.List<com.seeyon.ctp.message.enums.MessageChannelEnum>` |
| `messageTag` | `java.lang.String` |
| `uniqueId` | `java.lang.String` |
| `chooseJson` | `java.lang.String` |
| `templateDataMap` | `java.util.Map<java.lang.String, java.lang.String>` |
| `templateKey` | `java.lang.String` |
| `templateSourceCode` | `java.lang.String` |
| `operateJson` | `java.lang.String` |
| `userDtoList` | `java.util.List<com.seeyon.ctp.message.dto.UserDto>` |
| `mobileOpenUrl` | `java.lang.String` |
| `pcOpenUrl` | `java.lang.String` |
| `pcOpenType` | `java.lang.String` |
| `mobileOpenType` | `java.lang.String` |
| `dialogModule` | `java.lang.String` |
| `senderType` | `com.seeyon.ctp.message.enums.SenderEnum` |

## `CtpThirdPlatformConfigDto`（15 字段）

`com.seeyon.ctp.user.dto.third.CtpThirdPlatformConfigDto`

被这些方法当入参：

- `CtpThirdPlatformConfigCoreAppService.create()`（包装入参）
- `CtpThirdPlatformConfigCoreAppService.update()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `id` | `java.lang.Long` |
| `name` | `java.lang.String` |
| `type` | `com.seeyon.ctp.user.enums.ThirdPlatformTypeEnum` |
| `orgId` | `java.lang.Long` |
| `corpId` | `java.lang.String` |
| `corpSecret` | `java.lang.String` |
| `appId` | `java.lang.String` |
| `appKey` | `java.lang.String` |
| `appSecret` | `java.lang.String` |
| `extAttr1` | `java.lang.String` |
| `extAttr2` | `java.lang.String` |
| `extAttr3` | `java.lang.String` |
| `extAttr4` | `java.lang.String` |
| `extAttr5` | `java.lang.String` |

## `AffairConditionSearchDto`（14 字段）

`com.seeyon.ctp.affair.dto.base.AffairConditionSearchDto`

被这些方法当入参：

- `AffairCommonAppService.selectAffairByFixedUserCondition()`（包装入参）

| 字段 | 类型 |
|---|---|
| `receiveMemberId` | `java.lang.Long` |
| `appName` | `java.lang.String` |
| `subAppName` | `java.lang.String` |
| `state` | `com.seeyon.ctp.affair.enums.AffairStateEnum` |
| `subStates` | `java.util.List<java.lang.String>` |
| `startMemberId` | `java.lang.Long` |
| `stepbackMemberId` | `java.lang.Long` |
| `title` | `java.lang.String` |
| `startTimeStart` | `java.util.Date` |
| `startTimeEnd` | `java.util.Date` |
| `operationTimeStart` | `java.util.Date` |
| `operationTimeEnd` | `java.util.Date` |
| `currentOrgId` | `java.lang.Long` |
| `pageInfo` | `com.seeyon.boot.transport.PageInfo` |

## `CtpOrgAdminConfigDto`（14 字段）

`com.seeyon.ctp.user.dto.CtpOrgAdminConfigDto`

被这些方法当入参：

- `CtpOrgAdminOrgAppService.configAdmin()`（包装入参）
- `CtpOrgAdminOrgAppService.batchConfigOrgAdmin()`（裸参数）
- `CtpOrgAdminOrgAppService.createAdmin()`（包装入参）
- `CtpOrgAdminOrgAppService.updateAdmin()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `id` | `java.lang.Long` |
| `orgId` | `java.lang.Long` |
| `orgName` | `java.lang.String` |
| `orgIsRoot` | `java.lang.Boolean` |
| `manageScope` | `com.seeyon.ctp.user.enums.ManageScopeEnum` |
| `manageType` | `com.seeyon.ctp.user.enums.ManagerTypeEnum` |
| `isTernary` | `java.lang.String` |
| `list` | `java.util.List<com.seeyon.ctp.user.dto.CtpAdminConfigDto>` |
| `checkUserNum` | `java.lang.Boolean` |
| `dataSignSuccess` | `java.lang.Integer` |
| `createOrgId` | `java.lang.Long` |
| `authName` | `java.lang.String` |
| `appList` | `java.util.List<com.seeyon.ctp.user.dto.CtpRoleApplicationResourceDto>` |

## `CtpSecretApprovalDto`（14 字段）

`com.seeyon.ctp.user.dto.CtpSecretApprovalDto`

被这些方法当入参：

- `CtpSecretApprovalOrgAppService.create()`（裸参数）

| 字段 | 类型 |
|---|---|
| `id` | `java.lang.Long` |
| `authId` | `java.lang.Long` |
| `authName` | `java.lang.String` |
| `authValue` | `java.lang.String` |
| `authValueName` | `java.lang.String` |
| `secretValue` | `java.lang.String` |
| `secretValueName` | `java.lang.String` |
| `orgId` | `java.lang.Long` |
| `type` | `com.seeyon.ctp.user.enums.ApprovalTypeEnum` |
| `status` | `com.seeyon.ctp.user.enums.ApprovalStatusEnum` |
| `auditorId` | `java.lang.Long` |
| `auditorName` | `java.lang.String` |
| `createTime` | `java.util.Date` |
| `isPass` | `java.lang.Boolean` |

## `AffairBaseConditionDto`（12 字段）

`com.seeyon.ctp.affair.dto.base.AffairBaseConditionDto`

被这些方法当入参：

- `AffairCommonAppService.selectListByCondition()`（包装入参）
- `AffairCommonAppService.selectAffairSimpleListByCondition()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `receiveMemberId` | `java.lang.Long` |
| `templateId` | `java.lang.Long` |
| `state` | `com.seeyon.ctp.affair.enums.AffairStateEnum` |
| `subState` | `java.lang.String` |
| `objectId` | `java.lang.Long` |
| `subObjectId` | `java.lang.Long` |
| `subObjectIds` | `java.util.List<java.lang.Long>` |
| `nodeIds` | `java.util.List<java.lang.Long>` |
| `formRecordId` | `java.lang.Long` |
| `formRecordCode` | `java.lang.String` |
| `start` | `java.lang.Boolean` |

## `CtpDataAuditDto`（12 字段）

`com.seeyon.ctp.user.dto.CtpDataAuditDto`

被这些方法当入参：

- `CtpDataAuditCoreAppService.create()`（包装入参）

| 字段 | 类型 |
|---|---|
| `objectId` | `java.lang.Long` |
| `traceId` | `java.lang.String` |
| `userId` | `java.lang.Long` |
| `entityFullName` | `java.lang.String` |
| `attributeName` | `java.lang.String` |
| `uniqueAttributeName` | `java.lang.String` |
| `attributeValue` | `java.lang.String` |
| `uniqueAttributeValue` | `java.lang.String` |
| `type` | `com.seeyon.boot.enums.DataChangeType` |
| `time` | `java.util.Date` |
| `appId` | `java.lang.String` |
| `description` | `java.lang.String` |

## `CtpPersonalPlanDto`（11 字段）

`com.seeyon.ctp.application.dto.personalplan.CtpPersonalPlanDto`

被这些方法当入参：

- `CtpPersonalPlanCoreAppService.createRedirectBatch()`（裸参数）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `appName` | `java.lang.String` |
| `customePageUrl` | `java.lang.String` |
| `pageUrl` | `java.lang.String` |
| `title` | `java.lang.String` |
| `terminal` | `com.seeyon.ctp.user.enums.ResourceClientTypeEnum` |
| `authType` | `com.seeyon.ctp.application.enums.PlanAuthTypeEnum` |
| `authId` | `java.lang.Long` |
| `sourceType` | `com.seeyon.ctp.application.enums.CustomPlanSourceTypeEnum` |
| `sourceId` | `java.lang.Long` |
| `customAppCreateTime` | `java.util.Date` |

## `CtpResourcePermissionRegisterDto`（11 字段）

`com.seeyon.ctp.user.dto.CtpResourcePermissionRegisterDto`

被这些方法当入参：

- `CtpResourcePermissionCoreAppService.register()`（包装入参）

| 字段 | 类型 |
|---|---|
| `resourceCode` | `java.lang.String` |
| `roleCode` | `java.lang.String` |
| `appId` | `java.lang.String` |
| `dataType` | `java.lang.String` |
| `permissionType` | `java.lang.String` |
| `resourcePermissionDtoList` | `java.util.List<com.seeyon.ctp.user.dto.CtpResourcePermissionDto>` |
| `userIdList` | `java.util.List<java.lang.Long>` |
| `creatorId` | `java.lang.Long` |
| `isGroup` | `java.lang.Boolean` |
| `orgId` | `java.lang.Long` |
| `resourcePermissionTypeEnum` | `com.seeyon.ctp.user.enums.ResourcePermissionTypeEnum` |

## `CtpUserResourceSearchDto`（11 字段）

`com.seeyon.ctp.user.dto.CtpUserResourceSearchDto`

被这些方法当入参：

- `CtpUserPermissionCommonAppService.selectUserResourceCode()`（包装入参）
- `CtpUserPermissionCommonAppService.checkUserResourceCode()`（包装入参）
- `CtpUserPermissionCommonAppService.selectUserResource()`（包装入参）
- `CtpUserPermissionCommonAppService.selectUserResourceProperties()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `userId` | `java.lang.Long` |
| `resourceAppId` | `java.lang.String` |
| `resourceType` | `com.seeyon.ctp.user.enums.ResourceTypeEnum` |
| `resourceCode` | `java.util.List<java.lang.String>` |
| `resourceDataType` | `java.lang.String` |
| `resourcePermissionType` | `java.lang.String` |
| `resourceId` | `java.lang.Long` |
| `withCommonResource` | `java.lang.Boolean` |
| `resourceUrl` | `java.lang.String` |
| `orgId` | `java.lang.Long` |

## `AffairCustomOperationDto`（10 字段）

`com.seeyon.ctp.affair.dto.AffairCustomOperationDto`

被这些方法当入参：

- `AffairCustomOperationAppService.createAffairCustomOperation()`（包装入参）

| 字段 | 类型 |
|---|---|
| `opCaption` | `java.lang.String` |
| `opInvokeAppname` | `java.lang.String` |
| `opInvokeInterfacename` | `java.lang.String` |
| `opInvokeMethodname` | `java.lang.String` |
| `opFilterPermissiontypecode` | `java.lang.String` |
| `opFilterState` | `java.lang.String` |
| `appName` | `java.lang.String` |
| `opFilterSubapp` | `java.lang.String` |
| `opQuick` | `java.lang.Boolean` |
| `opBatch` | `java.lang.Boolean` |

## `AffairInfoDto`（10 字段）

`com.seeyon.ctp.affair.dto.table.AffairInfoDto`

被这些方法当入参：

- `AffairCommonAppService.updateAffairById()`（包装入参）

| 字段 | 类型 |
|---|---|
| `affairId` | `java.lang.Long` |
| `state` | `com.seeyon.ctp.affair.enums.AffairStateEnum` |
| `subState` | `java.lang.String` |
| `title` | `java.lang.String` |
| `appName` | `java.lang.String` |
| `subAppName` | `java.lang.String` |
| `pageAddress` | `java.lang.String` |
| `mobileAddress` | `java.lang.String` |
| `extInfo` | `java.util.Map<java.lang.String, java.lang.Object>` |
| `whereExtInfo` | `java.util.Map<java.lang.String, java.lang.Object>` |

## `CtpDeviceBindDto`（10 字段）

`com.seeyon.ctp.user.dto.devicebind.CtpDeviceBindDto`

被这些方法当入参：

- `CtpDeviceBindCommonAppService.bindDevice()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `id` | `java.lang.Long` |
| `userId` | `java.lang.Long` |
| `deviceType` | `com.seeyon.ctp.user.enums.DeviceTypeEnum` |
| `deviceOsVersion` | `java.lang.String` |
| `deviceName` | `java.lang.String` |
| `deviceNumber` | `java.lang.String` |
| `objectId` | `java.lang.Long` |
| `appId` | `java.lang.String` |
| `lastLoginTime` | `java.util.Date` |

## `AffairDynamicQueryDto`（9 字段）

`com.seeyon.ctp.affair.dto.search.AffairDynamicQueryDto`

被这些方法当入参：

- `AffairCommonAppService.dynamicQueryAffairDtoPage()`（包装入参）

| 字段 | 类型 |
|---|---|
| `fieldSet` | `java.util.List<java.lang.String>` |
| `dynamicContentJson` | `java.lang.String` |
| `appName` | `java.lang.String` |
| `subAppName` | `java.lang.String` |
| `pageInfo` | `com.seeyon.boot.transport.PageInfo` |
| `orderType` | `com.seeyon.boot.transport.Sort$Direction` |
| `orderBy` | `java.lang.String` |
| `ordersBy` | `java.util.List<com.seeyon.boot.transport.Sort$Order>` |
| `mergeDoneList` | `java.lang.Boolean` |

## `CtpLoginPreConfigDto`（9 字段）

`com.seeyon.ctp.user.dto.CtpLoginPreConfigDto`

被这些方法当入参：

- `CtpLoginPreConfigAppService.createOrUpdate()`（包装入参）
- `CtpLoginPreConfigAppService.hasRepeatName()`（包装入参）

| 字段 | 类型 |
|---|---|
| `orgId` | `java.lang.Long` |
| `tid` | `java.lang.Long` |
| `enabledLoginManage` | `java.lang.Boolean` |
| `enabledLoginPrePortal` | `java.lang.Boolean` |
| `enabledUnifyLoginPortal` | `java.lang.Boolean` |
| `enabledHolidayLoginPortal` | `java.lang.Boolean` |
| `loginManageUri` | `java.lang.String` |
| `isRootUnit` | `java.lang.Boolean` |
| `allowChildCustomDefine` | `java.lang.Boolean` |

## `CtpAuthorizationRuleAllDto`（9 字段）

`com.seeyon.ctp.user.dto.authorization.CtpAuthorizationRuleAllDto`

被这些方法当入参：

- `CtpAuthorizationRuleOrgAppService.create()`（包装入参）
- `CtpAuthorizationRuleOrgAppService.update()`（包装入参）

| 字段 | 类型 |
|---|---|
| `ruleDto` | `com.seeyon.ctp.user.dto.authorization.CtpAuthorizationRuleDto` |
| `objectList` | `java.util.List<com.seeyon.ctp.user.dto.authorization.CtpAuthorizationObjectSaveDto>` |
| `permissionMemberList` | `java.util.List<com.seeyon.ctp.user.dto.PermissionMemberDto>` |
| `isAudit` | `java.lang.Boolean` |
| `oldEntityName` | `java.util.List<java.lang.String>` |
| `deleteDtoList` | `java.util.List<com.seeyon.ctp.user.dto.authorization.CtpAuthorizationRuleDeleteDto>` |
| `currentOrgId` | `java.lang.Long` |
| `deleteRuleFuncIds` | `java.util.List<java.lang.Long>` |
| `oldEntityNameMap` | `java.util.Map<java.lang.Long, java.util.List<java.lang.String>>` |

## `AffairOpenApiNodeDto`（8 字段）

`com.seeyon.ctp.affair.dto.open.AffairOpenApiNodeDto`

被这些方法当入参：

- `AffairOpenAppService.createOrUpdate()`（裸参数）

| 字段 | 类型 |
|---|---|
| `nodePermissionId` | `java.lang.Long` |
| `nodePermissionName` | `java.lang.String` |
| `nodePermissionCode` | `java.lang.String` |
| `type` | `com.seeyon.ctp.affair.enums.AffairNodePermissionTypeEnum` |
| `applicationName` | `java.lang.String` |
| `orderNum` | `java.lang.Integer` |
| `accountId` | `java.lang.Long` |
| `operationType` | `java.lang.String` |

## `CheckResourcePermissionDto`（8 字段）

`com.seeyon.ctp.user.dto.CheckResourcePermissionDto`

被这些方法当入参：

- `CtpUserPermissionCommonAppService.checkUserResource()`（裸参数）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `userId` | `java.lang.Long` |
| `resourceCode` | `java.lang.String` |
| `permissionType` | `java.lang.String` |
| `resourceClientTypeEnum` | `com.seeyon.ctp.user.enums.ResourceClientTypeEnum` |
| `orgId` | `java.lang.Long` |
| `appId` | `java.lang.String` |
| `extendAttr` | `java.util.Map<java.lang.String, java.lang.Object>` |

## `CtpRuleRoleDto`（8 字段）

`com.seeyon.ctp.user.dto.CtpRuleRoleDto`

被这些方法当入参：

- `CtpUserRoleCoreAppService.createUserRule()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `roleId` | `java.lang.Long` |
| `roleCode` | `java.lang.String` |
| `appName` | `java.lang.String` |
| `orgId` | `java.lang.Long` |
| `orgCode` | `java.lang.String` |
| `creatorId` | `java.lang.Long` |
| `list` | `java.util.List<com.seeyon.ctp.user.dto.CtpRuleUserDto>` |

## `AffairBadgeCountQueryDto`（7 字段）

`com.seeyon.ctp.affair.dto.base.AffairBadgeCountQueryDto`

被这些方法当入参：

- `AffairCommonAppService.selectAffairCountForBadge()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `currentUserId` | `java.lang.Long` |
| `appId` | `java.lang.String` |
| `affairState` | `com.seeyon.ctp.affair.enums.AffairStateEnum` |
| `agent` | `java.lang.Boolean` |
| `currentStateOnly` | `java.lang.Boolean` |
| `includeAgent` | `java.lang.Boolean` |

## `WorkflowStopDto`（7 字段）

`com.seeyon.ctp.affair.workflow.dto.WorkflowStopDto`

被这些方法当入参：

- `Affair4WorkflowAppService.stopCase()`（包装入参）

| 字段 | 类型 |
|---|---|
| `objectId` | `java.lang.Long` |
| `subObjectId` | `java.lang.Long` |
| `currentUserId` | `java.lang.Long` |
| `dealAgentId` | `java.lang.Long` |
| `dealAgentName` | `java.lang.String` |
| `nodePermissionTypeCodes` | `java.util.List<java.lang.String>` |
| `needSendMessage` | `java.lang.Boolean` |

## `CtpMessageTypeDto`（7 字段）

`com.seeyon.ctp.message.dto.CtpMessageTypeDto`

被这些方法当入参：

- `CtpMessageSourceTypeAppService.createType()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `id` | `java.lang.Long` |
| `name` | `java.lang.String` |
| `code` | `java.lang.String` |
| `messageSourceCode` | `java.lang.String` |
| `parentCode` | `java.lang.String` |
| `hidden` | `java.lang.Boolean` |

## `KickOfflineDto`（7 字段）

`com.seeyon.ctp.message.dto.KickOfflineDto`

被这些方法当入参：

- `CtpMessageManageAppService.kickOffline()`（包装入参）

| 字段 | 类型 |
|---|---|
| `userId` | `java.lang.Long` |
| `tenantId` | `java.lang.Long` |
| `terminal` | `com.seeyon.ctp.message.enums.TerminalEnum` |
| `msg` | `java.lang.String` |
| `i18nCode` | `java.lang.String` |
| `bId` | `java.lang.String` |
| `tId` | `java.lang.String` |

## `CtpUserMappingQueryRequestDto`（7 字段）

`com.seeyon.ctp.user.dto.CtpUserMappingQueryRequestDto`

被这些方法当入参：

- `CtpUserBindMappingAppService.pageUserMappingByUserIds()`（包装入参）
- `CtpUserBindMappingAppService.listUserMappingByUserIds()`（包装入参）
- `CtpUserBindMappingAppService.listUserMappingForPending()`（包装入参）

| 字段 | 类型 |
|---|---|
| `type` | `java.lang.String` |
| `appId` | `java.lang.String` |
| `agentId` | `java.lang.String` |
| `defaultFlag` | `java.lang.Integer` |
| `pageInfo` | `com.seeyon.boot.transport.PageInfo` |
| `thirdUserId` | `java.lang.String` |
| `userIdList` | `java.util.List<java.lang.Long>` |

## `CtpAuthorizationRuleSyncDto`（7 字段）

`com.seeyon.ctp.user.dto.sync.CtpAuthorizationRuleSyncDto`

被这些方法当入参：

- `CtpUserRoleCoreAppService.roleAuthBatch()`（包装入参）

| 字段 | 类型 |
|---|---|
| `orgCode` | `java.lang.String` |
| `roleCode` | `java.lang.String` |
| `dealType` | `com.seeyon.ctp.user.enums.AuthRuleObjectDealTypeEnum` |
| `coverObjectList` | `java.util.List<com.seeyon.ctp.user.dto.sync.CtpAuthorizationRuleObjectSyncDto>` |
| `mergeAddObjectList` | `java.util.List<com.seeyon.ctp.user.dto.sync.CtpAuthorizationRuleObjectSyncDto>` |
| `mergeDeleteObjectList` | `java.util.List<com.seeyon.ctp.user.dto.sync.CtpAuthorizationRuleObjectSyncDto>` |
| `appId` | `java.lang.String` |

## `AffairBatchDto`（6 字段）

`com.seeyon.ctp.affair.dto.AffairBatchDto`

被这些方法当入参：

- `AbstractThirdAffairService.batchOperateThirdAffair()`（裸参数）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `userId` | `java.lang.Long` |
| `operation` | `java.lang.String` |
| `opinionDto` | `com.seeyon.ctp.affair.dto.OpinionDto` |
| `batchId` | `java.lang.String` |
| `list` | `java.util.List<com.seeyon.ctp.affair.dto.AffairBatchSubDto>` |

## `AffairBadgeCountBatchQueryDto`（6 字段）

`com.seeyon.ctp.affair.dto.base.AffairBadgeCountBatchQueryDto`

被这些方法当入参：

- `AffairCommonAppService.selectAffairCountBatchForBadge()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `currentUserIds` | `java.util.List<java.lang.Long>` |
| `appId` | `java.lang.String` |
| `affairState` | `com.seeyon.ctp.affair.enums.AffairStateEnum` |
| `agent` | `java.lang.Boolean` |
| `includeAgent` | `java.lang.Boolean` |

## `AffairFullCategoryDto`（6 字段）

`com.seeyon.ctp.affair.dto.category.AffairFullCategoryDto`

被这些方法当入参：

- `AffairCommonAppService.createAffairCategory()`（包装入参）
- `AffairCommonAppService.updateAffairCategory()`（包装入参）
- `AffairCommonAppService.searchAffairCategory()`（包装入参）
- `AffairOpenAppService.createOrUpdateCategory()`（包装入参）
- `AffairOpenAppService.selectCategoryByCondition()`（包装入参）

| 字段 | 类型 |
|---|---|
| `id` | `java.lang.Long` |
| `appName` | `java.lang.String` |
| `appCaption` | `java.lang.String` |
| `subAppName` | `java.lang.String` |
| `subAppCaption` | `java.lang.String` |
| `categoryCode` | `java.lang.String` |

## `ClientScopeEnum`（6 字段）

`com.seeyon.ctp.application.enums.ClientScopeEnum`

被这些方法当入参：

- `CtpApplicationCommonAppService.selectCategorySetting()`（包装入参）

| 字段 | 类型 |
|---|---|
| `NONE` | static `com.seeyon.ctp.application.enums.ClientScopeEnum` |
| `WEB` | static `com.seeyon.ctp.application.enums.ClientScopeEnum` |
| `MOBILE` | static `com.seeyon.ctp.application.enums.ClientScopeEnum` |
| `ALL` | static `com.seeyon.ctp.application.enums.ClientScopeEnum` |
| `code` | `int` |
| `$VALUES` | static `com.seeyon.ctp.application.enums.ClientScopeEnum[]` |

## `CtpMessageSourceBaseDto`（6 字段）

`com.seeyon.ctp.message.dto.CtpMessageSourceBaseDto`

被这些方法当入参：

- `CtpMessageSourceTypeAppService.createSource()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `id` | `java.lang.Long` |
| `name` | `java.lang.String` |
| `code` | `java.lang.String` |
| `headUrl` | `java.lang.String` |
| `plugins` | `java.lang.String` |

## `CtpSwitchIdentityDto`（6 字段）

`com.seeyon.ctp.user.dto.CtpSwitchIdentityDto`

被这些方法当入参：

- `CtpAuthCoreAppService.switchAdmin()`（包装入参）
- `CtpAuthCoreAppService.switchUser()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `sid` | `java.lang.String` |
| `accessToken` | `java.lang.String` |
| `password` | `java.lang.String` |
| `orgId` | `java.lang.Long` |
| `locale` | `java.lang.String` |

## `AffairReceiverSearchDto`（5 字段）

`com.seeyon.ctp.affair.dto.base.AffairReceiverSearchDto`

被这些方法当入参：

- `AffairCommonAppService.selectReceiveMemberIdList()`（包装入参）
- `AffairCommonAppService.chooseReceiverAffair()`（包装入参）

| 字段 | 类型 |
|---|---|
| `objectId` | `java.lang.Long` |
| `stateList` | `java.util.List<com.seeyon.ctp.affair.enums.AffairStateEnum>` |
| `memberList` | `java.util.List<java.lang.Long>` |
| `includeAgent` | `java.lang.Boolean` |
| `atTime` | `java.util.Date` |

## `AffairCategorySearchDto`（5 字段）

`com.seeyon.ctp.affair.dto.category.AffairCategorySearchDto`

被这些方法当入参：

- `AffairCategoryAppService.searchAffairCategory()`（包装入参）

| 字段 | 类型 |
|---|---|
| `id` | `java.lang.Long` |
| `appName` | `java.lang.String` |
| `appCaption` | `java.lang.String` |
| `subAppName` | `java.lang.String` |
| `subAppCaption` | `java.lang.String` |

## `AffairProcessingPersonRequestDto`（5 字段）

`com.seeyon.ctp.affair.dto.open.AffairProcessingPersonRequestDto`

被这些方法当入参：

- `AffairCommonAppService.selectProcessingPersonForEachNode()`（包装入参）

| 字段 | 类型 |
|---|---|
| `objectId` | `java.lang.Long` |
| `nodeId` | `java.lang.Long` |
| `nodeIdList` | `java.util.List<java.lang.Long>` |
| `activeBatchId` | `java.lang.Long` |
| `hasRead` | `java.lang.Boolean` |

## `AffairQuickDto`（5 字段）

`com.seeyon.ctp.affair.dto.operation.AffairQuickDto`

被这些方法当入参：

- `AffairCommonAppService.pendingAffairQuick()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `affairId` | `java.lang.Long` |
| `userId` | `java.lang.Long` |
| `operationId` | `java.lang.Long` |
| `opinionContent` | `java.lang.String` |

## `CtpManagerTenantAdminUpdateDto`（5 字段）

`com.seeyon.ctp.manager.dto.CtpManagerTenantAdminUpdateDto`

被这些方法当入参：

- `CtpManagerTenantAppService.updateTenantAdmin()`（包装入参）

| 字段 | 类型 |
|---|---|
| `newAdminLoginName` | `java.lang.String` |
| `newAdminPhoneNumber` | `java.lang.String` |
| `newAdminPassword` | `java.lang.String` |
| `useTenantId` | `java.lang.Long` |
| `adminName` | `java.lang.String` |

## `CheckOrgAdminPermissionDto`（5 字段）

`com.seeyon.ctp.user.dto.CheckOrgAdminPermissionDto`

被这些方法当入参：

- `CtpUserPermissionCommonAppService.checkOrgAdminPermission()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `userId` | `java.lang.Long` |
| `orgId` | `java.lang.Long` |
| `appId` | `java.lang.String` |
| `resourceCodes` | `java.util.List<java.lang.String>` |

## `CtpAuthOrgAdminDto`（5 字段）

`com.seeyon.ctp.user.dto.CtpAuthOrgAdminDto`

被这些方法当入参：

- `CtpUserRoleCoreAppService.authOrgAdmin()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `orgId` | `java.lang.Long` |
| `orgIsRoot` | `java.lang.Boolean` |
| `memberIds` | `java.util.List<java.lang.Long>` |
| `checkUserNum` | `java.lang.Boolean` |

## `CtpAuthorizationDto`（5 字段）

`com.seeyon.ctp.user.dto.CtpAuthorizationDto`

被这些方法当入参：

- `CtpUserRoleCoreAppService.createAuthorizationRule()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `roleList` | `java.util.List<com.seeyon.ctp.user.dto.CtpAuthorizationRuleRoleDto>` |
| `orgId` | `java.lang.Long` |
| `creatorId` | `java.lang.Long` |
| `entityList` | `java.util.List<com.seeyon.ctp.user.dto.CtpAuthorizationRuleEntityDto>` |

## `CtpUserMappingSyncRequestDto`（5 字段）

`com.seeyon.ctp.user.dto.CtpUserMappingSyncRequestDto`

被这些方法当入参：

- `CtpUserBindMappingAppService.saveUpdate()`（包装入参）

| 字段 | 类型 |
|---|---|
| `userIdMapping` | `java.util.Map<java.lang.Long, java.lang.String>` |
| `type` | `java.lang.String` |
| `appId` | `java.lang.String` |
| `agentId` | `java.lang.String` |
| `defaultFlag` | `java.lang.Integer` |

## `AffairCountConditionDto`（4 字段）

`com.seeyon.ctp.affair.dto.base.AffairCountConditionDto`

被这些方法当入参：

- `AffairCommonAppService.countAffairByConditions()`（包装入参）

| 字段 | 类型 |
|---|---|
| `fieldName` | `java.lang.String` |
| `state` | `java.util.List<com.seeyon.ctp.affair.enums.AffairStateEnum>` |
| `receiveMemberId` | `java.lang.Long` |
| `appId` | `java.lang.String` |

## `AffairCategoryHierarchyDto`（4 字段）

`com.seeyon.ctp.affair.dto.category.AffairCategoryHierarchyDto`

被这些方法当入参：

- `AffairOpenAppService.createOrUpdateCategoryHierarchy()`（裸参数）

| 字段 | 类型 |
|---|---|
| `categoryCode` | `java.lang.String` |
| `categoryName` | `java.lang.String` |
| `parentCategoryCode` | `java.lang.String` |
| `childrenList` | `java.util.List<com.seeyon.ctp.affair.dto.category.AffairCategoryHierarchyDto>` |

## `AffairMicroUpdateConditionDto`（4 字段）

`com.seeyon.ctp.affair.dto.microflow.AffairMicroUpdateConditionDto`

被这些方法当入参：

- `AffairMicroflowAppService.updateAffairReadByMicroflow()`（包装入参）
- `AffairMicroflowAppService.updateAffairDoneByMicroflow()`（包装入参）

| 字段 | 类型 |
|---|---|
| `formRecordId` | `java.lang.Long` |
| `formRecordCode` | `java.lang.String` |
| `userId` | `java.lang.Long` |
| `subState` | `java.lang.String` |

## `AffairTrackUpdateDto`（4 字段）

`com.seeyon.ctp.affair.dto.track.AffairTrackUpdateDto`

被这些方法当入参：

- `AffairCommonAppService.updateAffairTrack()`（包装入参）

| 字段 | 类型 |
|---|---|
| `currentUserId` | `java.lang.Long` |
| `affairId` | `java.lang.Long` |
| `caseIds` | `java.util.List<java.lang.Long>` |
| `isTrack` | `java.lang.Boolean` |

## `CtpPersonalPlanPermissionDto`（4 字段）

`com.seeyon.ctp.application.dto.personalplan.CtpPersonalPlanPermissionDto`

被这些方法当入参：

- `CtpPersonalPlanCoreAppService.createOrUpdateBatch()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `personalPlanDtos` | `java.util.List<com.seeyon.ctp.application.dto.personalplan.CtpPersonalPlanDto>` |
| `permissionDtos` | `java.util.List<com.seeyon.ctp.user.message.dto.ResourceAndPermissionMessageDto>` |
| `deletedPersonalPlanIds` | `java.util.List<java.lang.Long>` |

## `CtpMessageTemplateDto`（4 字段）

`com.seeyon.ctp.message.dto.CtpMessageTemplateDto`

被这些方法当入参：

- `CtpMessageOpenApiService.saveMessageTemplate()`（包装入参）

| 字段 | 类型 |
|---|---|
| `messageSourceCode` | `java.lang.String` |
| `templateKey` | `java.lang.String` |
| `templateMap` | `java.util.Map<java.lang.String, java.lang.String>` |
| `optionalVariables` | `java.util.List<java.lang.String>` |

## `AggEntityMetadataDto`（4 字段）

`com.seeyon.ctp.metadata.dto.AggEntityMetadataDto`

被这些方法当入参：

- `RuleDetailRtService.generateTypeDataList()`（裸参数）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `relationType` | `java.lang.String` |
| `children` | `java.util.List<com.seeyon.ctp.metadata.dto.AggEntityMetadataDto>` |
| `relations` | `java.util.List<com.seeyon.ctp.metadata.dto.EntityMetadataDto>` |

## `SearchJsonMetadataDto`（4 字段）

`com.seeyon.ctp.metadata.dto.request.SearchJsonMetadataDto`

被这些方法当入参：

- `LoadJarResourceAppService.getJsonMetadataData()`（包装入参）
- `LoadJarResourceAppService.getRuntimeJsonData()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `appName` | `java.lang.String` |
| `appVersion` | `java.lang.String` |
| `jsonFileName` | `java.lang.String` |

## `SearchEntityManageOrgIdDto`（4 字段）

`com.seeyon.ctp.user.dto.SearchEntityManageOrgIdDto`

被这些方法当入参：

- `CtpApplicationCommonAppService.selectEntityManageOrgIdByAppId()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `appId` | `java.lang.String` |
| `orgId` | `java.lang.Long` |
| `fullName` | `java.lang.String` |

## `SearchMenuAndPortalDto`（4 字段）

`com.seeyon.ctp.user.dto.SearchMenuAndPortalDto`

被这些方法当入参：

- `CtpApplicationCommonAppService.selectUserMenuAndPortal()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `clientType` | `com.seeyon.ctp.user.enums.ResourceClientTypeEnum` |
| `orgId` | `java.lang.Long` |
| `userId` | `java.lang.Long` |

## `AffairSearchSpecifiedFieldDto`（3 字段）

`com.seeyon.ctp.affair.dto.base.AffairSearchSpecifiedFieldDto`

被这些方法当入参：

- `AffairUdcAppService.selectSpecifiedFieldValues()`（包装入参）

| 字段 | 类型 |
|---|---|
| `fieldName` | `java.lang.String` |
| `state` | `java.util.List<com.seeyon.ctp.affair.enums.AffairStateEnum>` |
| `receiveMemberId` | `java.lang.Long` |

## `AffairNodeMoreSearchDto`（3 字段）

`com.seeyon.ctp.affair.dto.open.AffairNodeMoreSearchDto`

被这些方法当入参：

- `AffairOpenAppService.selectSpecifyActivityUnprocessedMember()`（包装入参）

| 字段 | 类型 |
|---|---|
| `objectId` | `java.lang.Long` |
| `nodeId` | `java.lang.Long` |
| `count` | `java.lang.Integer` |

## `CtpManagerTenantStatusDto`（3 字段）

`com.seeyon.ctp.manager.dto.CtpManagerTenantStatusDto`

被这些方法当入参：

- `CtpManagerTenantAppService.updateStatusByUseTenantId()`（包装入参）

| 字段 | 类型 |
|---|---|
| `useTenantId` | `java.lang.Long` |
| `status` | `com.seeyon.ctp.manager.enums.TenantStatusEnum` |
| `errorMap` | `java.util.Map<java.lang.String, java.lang.String>` |

## `CtpMessageManageDto`（3 字段）

`com.seeyon.ctp.message.dto.CtpMessageManageDto`

被这些方法当入参：

- `CtpMessageManageAppService.set()`（包装入参）

| 字段 | 类型 |
|---|---|
| `userId` | `java.lang.Long` |
| `setType` | `com.seeyon.ctp.message.enums.ManageSetTypeEnum` |
| `setValue` | `java.lang.String` |

## `CtpResourcePermissionBatchRegisterDto`（3 字段）

`com.seeyon.ctp.user.dto.CtpResourcePermissionBatchRegisterDto`

被这些方法当入参：

- `CtpResourceCoreAppService.registerResourcePermissionBatch()`（包装入参）

| 字段 | 类型 |
|---|---|
| `resourceList` | `java.util.List<com.seeyon.ctp.user.dto.CtpResourceBatchDto>` |
| `resourcePermissionList` | `java.util.List<com.seeyon.ctp.user.dto.CtpResourceObjectBatchDto>` |
| `orgCode` | `java.lang.String` |

## `CtpUserAppPermissionDto`（3 字段）

`com.seeyon.ctp.user.dto.CtpUserAppPermissionDto`

被这些方法当入参：

- `CtpUserPermissionCommonAppService.checkUserAppPermission()`（包装入参）

| 字段 | 类型 |
|---|---|
| `userId` | `java.lang.Long` |
| `appId` | `java.lang.String` |
| `orgId` | `java.lang.Long` |

## `CtpUserResourceSearchMapDto`（3 字段）

`com.seeyon.ctp.user.dto.CtpUserResourceSearchMapDto`

被这些方法当入参：

- `CtpUserPermissionCommonAppService.selectUserResourceCodesMap()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `userId` | `java.lang.Long` |
| `resourceSearchDtoMap` | `java.util.Map<java.lang.String, com.seeyon.ctp.user.dto.CtpUserResourceSearchDto>` |

## `HasRoleByOrgCodeSearchDto`（3 字段）

`com.seeyon.ctp.user.dto.HasRoleByOrgCodeSearchDto`

被这些方法当入参：

- `CtpUserRoleCommonAppService.hasRoleByOrgCode()`（包装入参）

| 字段 | 类型 |
|---|---|
| `roleCode` | `java.lang.String` |
| `orgId` | `java.lang.Long` |
| `userId` | `java.lang.Long` |

## `CtpUnbindDeviceDto`（3 字段）

`com.seeyon.ctp.user.dto.devicebind.CtpUnbindDeviceDto`

被这些方法当入参：

- `CtpDeviceBindCommonAppService.batchUnbindDevice()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `conditions` | `java.util.Map<java.lang.String, java.lang.Object>` |
| `appId` | `java.lang.String` |

## `AffairUpdateBatchDto`（2 字段）

`com.seeyon.ctp.affair.dto.base.AffairUpdateBatchDto`

被这些方法当入参：

- `AffairCommonAppService.updateBatchAffairByCondition()`（包装入参）

| 字段 | 类型 |
|---|---|
| `updateList` | `java.util.List<com.seeyon.ctp.affair.dto.base.AffairUpdateBatchInfoDto>` |
| `messageList` | `java.util.List<com.seeyon.ctp.message.dto.MessageSendDto>` |

## `AffairDeleteCategoryConditionDto`（2 字段）

`com.seeyon.ctp.affair.dto.category.AffairDeleteCategoryConditionDto`

被这些方法当入参：

- `AffairCommonAppService.deleteAffairCategoryByCondition()`（包装入参）
- `AffairOpenAppService.deleteCategory()`（包装入参）

| 字段 | 类型 |
|---|---|
| `appName` | `java.lang.String` |
| `subAppName` | `java.lang.String` |

## `AffairFullCategorySyncDto`（2 字段）

`com.seeyon.ctp.affair.dto.category.AffairFullCategorySyncDto`

被这些方法当入参：

- `AffairCategoryAppService.syncCategories()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `categories` | `java.util.List<com.seeyon.ctp.affair.dto.category.AffairFullCategoryDto>` |

## `AffairNodeUnprocessedDto`（2 字段）

`com.seeyon.ctp.affair.dto.open.AffairNodeUnprocessedDto`

被这些方法当入参：

- `AffairOpenAppService.selectActivityUnprocessedMember()`（包装入参）

| 字段 | 类型 |
|---|---|
| `objectId` | `java.lang.Long` |
| `nodeIds` | `java.util.List<java.lang.Long>` |

## `AffairCreateMessageDto`（2 字段）

`com.seeyon.ctp.affair.message.dto.AffairCreateMessageDto`

被这些方法当入参：

- `AffairCommonAppService.createAffair()`（包装入参）

| 字段 | 类型 |
|---|---|
| `createList` | `java.util.List<com.seeyon.ctp.affair.message.dto.AffairMessageDto>` |
| `messageList` | `java.util.List<com.seeyon.ctp.message.dto.MessageSendDto>` |

## `AffairUpdateMessageDto`（2 字段）

`com.seeyon.ctp.affair.message.dto.AffairUpdateMessageDto`

被这些方法当入参：

- `AffairCommonAppService.updateAffair()`（包装入参）

| 字段 | 类型 |
|---|---|
| `updateList` | `java.util.List<com.seeyon.ctp.affair.message.dto.AffairMessageDto>` |
| `messageList` | `java.util.List<com.seeyon.ctp.message.dto.MessageSendDto>` |

## `CtpLicenseInfoDto`（2 字段）

`com.seeyon.ctp.manager.dto.CtpLicenseInfoDto`

被这些方法当入参：

- `CtpManagerTenantAppService.activationLicence()`（包装入参）

| 字段 | 类型 |
|---|---|
| `tenantId` | `java.lang.Long` |
| `licenseInfo` | `java.lang.String` |

## `CtpManagerReplenishInitDto`（2 字段）

`com.seeyon.ctp.manager.dto.CtpManagerReplenishInitDto`

被这些方法当入参：

- `CtpManagerTenantAppService.replenishInit()`（包装入参）

| 字段 | 类型 |
|---|---|
| `appName` | `java.lang.String` |
| `useTenantId` | `java.lang.Long` |

## `SearchByFullNamesDto`（2 字段）

`com.seeyon.ctp.metadata.dto.request.SearchByFullNamesDto`

被这些方法当入参：

- `DesignMetadataQueryApi.selectCtpEnumMetadataByFullNames()`（包装入参）
- `DesignMetadataQueryApi.selectEnumMetadataByFullNames()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `fullNames` | `java.util.List<java.lang.String>` |

## `CtpUserRoleSearchDto`（2 字段）

`com.seeyon.ctp.user.dto.CtpUserRoleSearchDto`

被这些方法当入参：

- `CtpUserRoleCommonAppService.selectUserByRoleCodeSearch()`（包装入参）

| 字段 | 类型 |
|---|---|
| `roleCode` | `java.lang.String` |
| `orgId` | `java.lang.Long` |

## `CtpUserRoleSyncDto`（2 字段）

`com.seeyon.ctp.user.dto.CtpUserRoleSyncDto`

被这些方法当入参：

- `CtpUserRoleCoreAppService.createBatchAuthorizationRule()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `userRoles` | `java.util.List<com.seeyon.ctp.user.dto.sync.CtpUserRoleSyncItemDto>` |

## `ThirdCheckResourcePermissionDto`（2 字段）

`com.seeyon.ctp.user.dto.ThirdCheckResourcePermissionDto`

被这些方法当入参：

- `ThirdPermissionAppService.checkPermissionByUser()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `permissions` | `java.util.List<com.seeyon.ctp.user.dto.CheckResourcePermissionDto>` |

## `CtpAuthorizationRuleDeleteDto`（2 字段）

`com.seeyon.ctp.user.dto.authorization.CtpAuthorizationRuleDeleteDto`

被这些方法当入参：

- `CtpAuthorizationRuleOrgAppService.delete()`（包装入参）

| 字段 | 类型 |
|---|---|
| `id` | `java.lang.Long` |
| `oldEntityName` | `java.util.List<java.lang.String>` |

## `CtpAuthorizationSearchDto`（2 字段）

`com.seeyon.ctp.user.dto.authorization.CtpAuthorizationSearchDto`

被这些方法当入参：

- `CtpAuthorizationRuleOrgAppService.selectAuthorizationObject()`（包装入参）

| 字段 | 类型 |
|---|---|
| `ruleId` | `java.lang.Long` |
| `isAudit` | `java.lang.Boolean` |

## `AccessTokenRequestDto`（2 字段）

`com.seeyon.ctp.user.dto.sso.AccessTokenRequestDto`

被这些方法当入参：

- `CtpAuthCoreAppService.getAccessToken()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `authKey` | `java.lang.String` |

## `CtpResourceSyncDto`（2 字段）

`com.seeyon.ctp.user.dto.sync.CtpResourceSyncDto`

被这些方法当入参：

- `CtpResourceCoreAppService.registerBatch()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `resources` | `java.util.List<com.seeyon.ctp.user.dto.sync.CtpResourceSyncItemDto>` |

## `CtpRoleResourceSyncDto`（2 字段）

`com.seeyon.ctp.user.dto.sync.CtpRoleResourceSyncDto`

被这些方法当入参：

- `CtpRoleCoreAppService.syncRoleResource()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `roleResources` | `java.util.List<com.seeyon.ctp.user.dto.sync.CtpRoleResourceSyncItemDto>` |

## `CtpRoleSyncDto`（2 字段）

`com.seeyon.ctp.user.dto.sync.CtpRoleSyncDto`

被这些方法当入参：

- `CtpRoleCoreAppService.saveBatch()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `roles` | `java.util.List<com.seeyon.ctp.user.dto.CtpRoleDto>` |

## `AffairEnumSearchParamDto`（1 字段）

`com.seeyon.ctp.affair.dto.affairenum.AffairEnumSearchParamDto`

被这些方法当入参：

- `AffairCommonAppService.selectEnumItemByEnumCode()`（包装入参）

| 字段 | 类型 |
|---|---|
| `enumCode` | `java.lang.String` |

## `AffairCommonIdsDto`（1 字段）

`com.seeyon.ctp.affair.dto.base.AffairCommonIdsDto`

被这些方法当入参：

- `AffairCommonAppService.deleteAffairByIds()`（包装入参）
- `AffairCommonAppService.deleteAffairByObjectIds()`（包装入参）

| 字段 | 类型 |
|---|---|
| `ids` | `java.util.List<java.lang.Long>` |

## `AffairUpdateBatchIdempotentDto`（1 字段）

`com.seeyon.ctp.affair.dto.base.AffairUpdateBatchIdempotentDto`

被这些方法当入参：

- `AffairCommonAppService.updateBatchAffairByConditionIdempotent()`（包装入参）

| 字段 | 类型 |
|---|---|
| `affairUpdateBatchDto` | `com.seeyon.ctp.affair.dto.base.AffairUpdateBatchDto` |

## `AffairCategoryHierarchyDeleteDto`（1 字段）

`com.seeyon.ctp.affair.dto.category.AffairCategoryHierarchyDeleteDto`

被这些方法当入参：

- `AffairOpenAppService.deleteCategoryHierarchy()`（包装入参）

| 字段 | 类型 |
|---|---|
| `categoryCode` | `java.lang.String` |

## `AffairCategoryHierarchySearchDto`（1 字段）

`com.seeyon.ctp.affair.dto.category.AffairCategoryHierarchySearchDto`

被这些方法当入参：

- `AffairOpenAppService.getCategoryHierarchy()`（包装入参）

| 字段 | 类型 |
|---|---|
| `categoryName` | `java.lang.String` |

## `AffairTrackUpgradeDto`（1 字段）

`com.seeyon.ctp.affair.dto.track.AffairTrackUpgradeDto`

被这些方法当入参：

- `AffairCommonAppService.updateBpmCaseTrackToAffairTrack()`（包装入参）

| 字段 | 类型 |
|---|---|
| `affairIds` | `java.util.List<java.lang.Long>` |

## `AffairCreateMessageIdempotentDto`（1 字段）

`com.seeyon.ctp.affair.message.dto.AffairCreateMessageIdempotentDto`

被这些方法当入参：

- `AffairCommonAppService.createAffairIdempotent()`（包装入参）

| 字段 | 类型 |
|---|---|
| `affairCreateMessageDto` | `com.seeyon.ctp.affair.message.dto.AffairCreateMessageDto` |

## `AffairUpdateMessageIdempotentDto`（1 字段）

`com.seeyon.ctp.affair.message.dto.AffairUpdateMessageIdempotentDto`

被这些方法当入参：

- `AffairCommonAppService.updateAffairIdempotent()`（包装入参）

| 字段 | 类型 |
|---|---|
| `affairUpdateMessageDto` | `com.seeyon.ctp.affair.message.dto.AffairUpdateMessageDto` |

## `UpdateAffairDoneDto`（1 字段）

`com.seeyon.ctp.affair.message.dto.UpdateAffairDoneDto`

被这些方法当入参：

- `AffairCommonAppService.updateAffairDoneIdempotent()`（包装入参）

| 字段 | 类型 |
|---|---|
| `affairId` | `java.lang.Long` |

## `UpdateAffairReadDto`（1 字段）

`com.seeyon.ctp.affair.message.dto.UpdateAffairReadDto`

被这些方法当入参：

- `AffairCommonAppService.updateAffairReadIdempotent()`（包装入参）

| 字段 | 类型 |
|---|---|
| `affairId` | `java.lang.Long` |

## `MessageStatusDto`（1 字段）

`com.seeyon.ctp.message.dto.MessageStatusDto`

被这些方法当入参：

- `CtpMessageManageAppService.getMessageNumber()`（包装入参）

| 字段 | 类型 |
|---|---|
| `statusEnum` | `com.seeyon.ctp.message.enums.MessageStatusEnum` |

## `UdcMessageSendChooseDto`（1 字段）

`com.seeyon.ctp.message.dto.UdcMessageSendChooseDto`

被这些方法当入参：

- `CtpUdcMessageSendAppService.sendMessageByChooseJson()`（包装入参）

| 字段 | 类型 |
|---|---|
| `chooseJson` | `java.lang.String` |

## `UdcMessageSendUserDto`（1 字段）

`com.seeyon.ctp.message.dto.UdcMessageSendUserDto`

被这些方法当入参：

- `CtpUdcMessageSendAppService.sendMessageByUser()`（包装入参）

| 字段 | 类型 |
|---|---|
| `receiveList` | `java.util.List<java.lang.Long>` |

## `CtpAuthorizationRuleCustomDto`（1 字段）

`com.seeyon.ctp.user.dto.authorization.CtpAuthorizationRuleCustomDto`

被这些方法当入参：

- `CtpAuthorizationRuleOrgAppService.selectDuplicateRolesRule()`（包装入参）

| 字段 | 类型 |
|---|---|
| `deleteRuleObjectMap` | `java.util.Map<java.lang.Long, java.util.Map<java.lang.Long, java.lang.String>>` |
