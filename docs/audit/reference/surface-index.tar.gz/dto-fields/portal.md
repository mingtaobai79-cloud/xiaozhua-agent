# 门户：入参 DTO 字段表

> 自动生成。包前缀 `com.seeyon.portal`。共 15 个 DTO。
> 字段类型逐字来自 javap；`static` 前缀表示常量而非实例字段。

## `PortletDefinitionDesignerDto`（20 字段）

`com.seeyon.portal.dto.PortletDefinitionDesignerDto`

被这些方法当入参：

- `PortalPortletAppService.createPortlet()`（包装入参）
- `PortalPortletAppService.updatePortletName()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `id` | `java.lang.Long` |
| `portletId` | `java.lang.String` |
| `name` | `java.lang.String` |
| `defaultName` | `java.lang.String` |
| `appId` | `java.lang.String` |
| `mobileAppId` | `java.lang.String` |
| `enablePc` | `java.lang.Boolean` |
| `enableMobile` | `java.lang.Boolean` |
| `definitionInfo` | `java.lang.String` |
| `mobileDefinitionInfo` | `java.lang.String` |
| `exposeName` | `java.lang.String` |
| `mobileExposeName` | `java.lang.String` |
| `categoryCode` | `java.lang.String` |
| `sortNo` | `java.lang.Integer` |
| `appCode` | `java.lang.String` |
| `categoryPath` | `java.lang.String` |
| `type` | `java.lang.String` |
| `accessControl` | `java.lang.String` |
| `originalAppId` | `java.lang.Long` |

## `PortalSetDesignerDto`（18 字段）

`com.seeyon.portal.dto.PortalSetDesignerDto`

被这些方法当入参：

- `PortalSetAppService.createPortal()`（包装入参）
- `PortalSetAppService.updatePortal()`（包装入参）
- `PortalSetAppService.createPcTemplateData()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `id` | `java.lang.Long` |
| `dataId` | `java.lang.Long` |
| `name` | `java.lang.String` |
| `orgId` | `java.lang.Long` |
| `userId` | `java.lang.Long` |
| `imgId` | `java.lang.String` |
| `enablePc` | `java.lang.Boolean` |
| `enableMobile` | `java.lang.Boolean` |
| `msecurityValue` | `java.lang.String` |
| `usecurityValue` | `java.lang.String` |
| `allowUserDefine` | `java.lang.Boolean` |
| `dataStatus` | `java.lang.Integer` |
| `appCode` | `java.lang.String` |
| `templateId` | `java.lang.Long` |
| `mTemplateId` | `java.lang.Long` |
| `appFrame` | `java.lang.Integer` |
| `originalAppId` | `java.lang.Long` |

## `PortalShortcutDto`（16 字段）

`com.seeyon.portal.dto.PortalShortcutDto`

被这些方法当入参：

- `PortalShortcutAppService.create()`（包装入参）
- `PortalShortcutAppService.update()`（包装入参）

| 字段 | 类型 |
|---|---|
| `id` | `java.lang.Long` |
| `spaceId` | `java.lang.Long` |
| `parentId` | `java.lang.Long` |
| `orgId` | `java.lang.Long` |
| `userId` | `java.lang.Long` |
| `operationType` | `java.lang.String` |
| `property` | `java.lang.String` |
| `shortcutGroupDtoList` | `java.util.List<com.seeyon.portal.dto.PortalShortcutGroupDto>` |
| `portalId` | `java.lang.Long` |
| `portalRoleConfigId` | `java.lang.Long` |
| `resetDefaultFlag` | `java.lang.Boolean` |
| `lastModifyTime` | `java.lang.Long` |
| `updateTime` | `java.util.Date` |
| `timestamp` | `java.lang.Long` |
| `appStatusTimestamp` | `java.lang.String` |
| `etagKey` | `java.lang.String` |

## `PortalSpaceDesignerDto`（16 字段）

`com.seeyon.portal.dto.PortalSpaceDesignerDto`

被这些方法当入参：

- `PortalSpaceAppService.createSpace()`（包装入参）
- `PortalSpaceAppService.updateSpace()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `id` | `java.lang.Long` |
| `dataId` | `java.lang.Long` |
| `name` | `java.lang.String` |
| `portalId` | `java.lang.Long` |
| `sortNo` | `java.lang.Integer` |
| `orgId` | `java.lang.Long` |
| `userId` | `java.lang.Long` |
| `spaceIcon` | `java.lang.String` |
| `msecurityValue` | `java.lang.String` |
| `usecurityValue` | `java.lang.String` |
| `appCode` | `java.lang.String` |
| `dataStatus` | `java.lang.Integer` |
| `type` | `com.seeyon.portal.enums.SpacePortalTypeEnum` |
| `allowUserDefine` | `java.lang.Boolean` |
| `originalAppId` | `java.lang.Long` |

## `PortalDetectionRequestDto`（10 字段）

`com.seeyon.portal.dto.PortalDetectionRequestDto`

被这些方法当入参：

- `PortalSetAppService.detection()`（包装入参）

| 字段 | 类型 |
|---|---|
| `appId` | `java.lang.Long` |
| `appName` | `java.lang.String` |
| `mobileHomeId` | `java.lang.String` |
| `allEnums` | `java.util.List<com.seeyon.portal.dto.PortalDetectionJavaEnumDto>` |
| `allPages` | `java.util.List<com.seeyon.portal.dto.PortalDetectionPageInfoDto>` |
| `allPageSchemas` | `java.util.List<com.seeyon.portal.dto.PortalDetectionPageSchemaDto>` |
| `allEntities` | `java.util.List<com.seeyon.portal.dto.PortalDetectionEntityDto>` |
| `allReports` | `java.util.List<com.seeyon.portal.dto.PortalDetectionReportDto>` |
| `detectionType` | `java.lang.Integer` |
| `pageSchemaStorageKey` | `java.lang.String` |

## `HolidayConfigDto`（9 字段）

`com.seeyon.portal.dto.holiday.HolidayConfigDto`

被这些方法当入参：

- `AbstractHolidayReminderService.remind()`（裸参数）
- `AbstractHolidayReminderService.record()`（裸参数）

| 字段 | 类型 |
|---|---|
| `id` | `java.lang.Long` |
| `title` | `java.lang.String` |
| `remindType` | `java.lang.String` |
| `useScope` | `java.lang.String` |
| `startTime` | `java.util.Date` |
| `endTime` | `java.util.Date` |
| `sortNo` | `java.lang.Integer` |
| `contentType` | `java.lang.String` |
| `content` | `java.util.List<com.seeyon.portal.dto.holiday.HolidayContentDto>` |

## `PortletCategoryDesignerDto`（8 字段）

`com.seeyon.portal.dto.PortletCategoryDesignerDto`

被这些方法当入参：

- `PortalPortletAppService.createCategory()`（包装入参）
- `PortalPortletAppService.updateCategory()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `id` | `java.lang.Long` |
| `categoryCode` | `java.lang.String` |
| `parentCategoryCode` | `java.lang.String` |
| `categoryName` | `java.lang.String` |
| `sortNo` | `java.lang.Integer` |
| `appCode` | `java.lang.String` |
| `originalAppId` | `java.lang.Long` |

## `UdcPortalSpaceAndInstanceDto`（5 字段）

`com.seeyon.portal.dto.UdcPortalSpaceAndInstanceDto`

被这些方法当入参：

- `PortalSpaceAppService.saveAsPortalSpaceCopy()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `spaceDto` | `com.seeyon.portal.dto.PortalSpaceDesignerDto` |
| `pageData` | `java.util.Map<java.lang.String, java.lang.Object>` |
| `orgId` | `java.lang.Long` |
| `userId` | `java.lang.Long` |

## `PortalConfigParamDto`（4 字段）

`com.seeyon.portal.dto.PortalConfigParamDto`

被这些方法当入参：

- `PortalConfigAppService.config()`（包装入参）

| 字段 | 类型 |
|---|---|
| `portalType` | `com.seeyon.portal.enums.SpacePortalTypeEnum` |
| `sid` | `java.lang.String` |
| `pageLoginPageType` | `com.seeyon.portal.enums.PageLoginPageTypeEnum` |
| `uri` | `java.lang.String` |

## `PortletBatchOperateDto`（3 字段）

`com.seeyon.portal.dto.PortletBatchOperateDto`

被这些方法当入参：

- `PortalPortletAppService.deletePortlets()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `appCode` | `java.lang.String` |
| `portletIdList` | `java.util.List<java.lang.String>` |

## `PortalImportParamDto`（2 字段）

`com.seeyon.portal.dto.PortalImportParamDto`

被这些方法当入参：

- `PortalSetAppService.importPortalDesignInfo()`（包装入参）

| 字段 | 类型 |
|---|---|
| `storageKey` | `java.lang.String` |
| `appCode` | `java.lang.String` |

## `PortalPortletParamDto`（2 字段）

`com.seeyon.portal.dto.PortalPortletParamDto`

被这些方法当入参：

- `PortalPortletAppService.getPortalPortlet()`（包装入参）

| 字段 | 类型 |
|---|---|
| `appCode` | `java.lang.String` |
| `portletId` | `java.lang.String` |

## `PortalPortletSortNoParamDto`（2 字段）

`com.seeyon.portal.dto.PortalPortletSortNoParamDto`

被这些方法当入参：

- `PortalPortletAppService.updatePortletSortNos()`（包装入参）

| 字段 | 类型 |
|---|---|
| `portletSortNoMap` | `java.util.Map<java.lang.String, java.lang.Integer>` |
| `appCode` | `java.lang.String` |

## `UdcPortletCategoryListDto`（2 字段）

`com.seeyon.portal.dto.UdcPortletCategoryListDto`

被这些方法当入参：

- `PortalPortletAppService.createBatchCategory()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `categoryDesignerDtoList` | `java.util.List<com.seeyon.portal.dto.PortletCategoryDesignerDto>` |

## `UdcPortletDefinitionListDto`（2 字段）

`com.seeyon.portal.dto.UdcPortletDefinitionListDto`

被这些方法当入参：

- `PortalPortletAppService.createBatchPortlet()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `definitionDesignerDtoList` | `java.util.List<com.seeyon.portal.dto.PortletDefinitionDesignerDto>` |
