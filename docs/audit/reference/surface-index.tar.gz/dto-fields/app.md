# 应用通用：入参 DTO 字段表

> 自动生成。包前缀 `com.seeyon.app`。共 27 个 DTO。
> 字段类型逐字来自 javap；`static` 前缀表示常量而非实例字段。

## `AgentDto`（38 字段）

`com.seeyon.app.common.agent.dto.AgentDto`

被这些方法当入参：

- `AgentCommonAppService.create()`（包装入参）
- `AgentCommonAppService.update()`（包装入参）
- `AgentCoreAppService.create()`（包装入参）
- `AgentCoreAppService.update()`（包装入参）
- `AgentCoreAppService.batch()`（裸参数）

| 字段 | 类型 |
|---|---|
| `id` | `java.lang.Long` |
| `agentId` | `java.lang.Long` |
| `agentCode` | `java.lang.String` |
| `agentName` | `java.lang.String` |
| `agentToId` | `java.lang.Long` |
| `agentToCode` | `java.lang.String` |
| `agentToName` | `java.lang.String` |
| `cancelTime` | `java.util.Date` |
| `cancel` | `java.lang.Boolean` |
| `startTime` | `java.util.Date` |
| `endTime` | `java.util.Date` |
| `agentRemind` | `java.lang.Boolean` |
| `agentToRemind` | `java.lang.Boolean` |
| `agentAccountId` | `java.lang.Long` |
| `agentToAccountId` | `java.lang.Long` |
| `agentOperation` | `com.seeyon.app.common.agent.enums.AgentOperationEnum` |
| `agentContentType` | `com.seeyon.app.common.agent.enums.AgentContentEnum` |
| `agentAllTask` | `java.lang.Boolean` |
| `agentToDeal` | `java.lang.Boolean` |
| `agentToSend` | `java.lang.Boolean` |
| `matterType` | `com.seeyon.app.common.agent.enums.AgentMatterTypeEnum` |
| `showAgent` | `com.seeyon.app.common.agent.enums.AgentIsShowEnum` |
| `signatureArea` | `com.seeyon.app.common.agent.enums.AgentSignatureAreaEnum` |
| `receive` | `java.lang.Boolean` |
| `agentItemShow` | `java.lang.Boolean` |
| `agentDetails` | `java.util.List<com.seeyon.app.common.agent.dto.AgentDetailDto>` |
| `agentScopes` | `java.util.List<com.seeyon.app.common.agent.dto.AgentScopeDto>` |
| `loginIsAdmin` | `java.lang.Boolean` |
| `type` | `com.seeyon.app.common.agent.enums.AgentTypeEnum` |
| `matterExpression` | `java.lang.String` |
| `agentSuffixType` | `com.seeyon.app.common.agent.enums.AgentSuffixTypeEnum` |
| `needChangeMsg` | `java.lang.Boolean` |
| `updateTime` | `java.util.Date` |
| `receiveMessage` | `java.lang.Boolean` |
| `creatorId` | `java.lang.Long` |
| `modifierId` | `java.lang.Long` |
| `creatorName` | `java.lang.String` |
| `modifierName` | `java.lang.String` |

## `IntegralLedgerDto`（27 字段）

`com.seeyon.app.common.integral.dto.IntegralLedgerDto`

被这些方法当入参：

- `IntegralLedgerOprateAppService.create()`（包装入参）
- `IntegralLedgerOprateAppService.createBatch()`（裸参数）
- `IntegralLedgerOprateAppService.selectPageByConditions()`（裸参数）

| 字段 | 类型 |
|---|---|
| `operatorName` | `java.lang.String` |
| `operatorUserName` | `java.lang.String` |
| `operatorId` | `java.lang.Long` |
| `operatorDeptName` | `java.lang.String` |
| `operatorDeptId` | `java.lang.Long` |
| `scorerName` | `java.lang.String` |
| `scorerUserName` | `java.lang.String` |
| `scorerId` | `java.lang.Long` |
| `scorerDeptName` | `java.lang.String` |
| `scorerDeptId` | `java.lang.Long` |
| `appName` | `java.lang.String` |
| `operationId` | `java.lang.Long` |
| `operationName` | `java.lang.String` |
| `score` | `java.lang.Double` |
| `orgId` | `java.lang.Long` |
| `createTime` | `java.util.Date` |
| `updateTime` | `java.util.Date` |
| `deleteStatus` | `java.lang.Boolean` |
| `tenantId` | `java.lang.Long` |
| `entityName` | `java.lang.String` |
| `notes` | `java.lang.String` |
| `path` | `java.lang.String` |
| `startTime` | `java.util.Date` |
| `endTime` | `java.util.Date` |
| `appRealName` | `java.lang.String` |
| `total` | `java.lang.Double` |
| `operationType` | `com.seeyon.app.common.integral.enums.OperationTypeEnum` |

## `CtpMgnAggDataDto`（19 字段）

`com.seeyon.app.common.mgn.dto.CtpMgnAggDataDto`

被这些方法当入参：

- `MgnAggDataInitAppService.create()`（包装入参）
- `MgnAggDataInitAppService.update()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `id` | `java.lang.Long` |
| `tenantId` | `java.lang.Long` |
| `dataType` | `java.lang.String` |
| `contentField` | `java.lang.String` |
| `mainEntity` | `java.lang.String` |
| `mainEntityCh` | `java.lang.String` |
| `orgField` | `java.lang.String` |
| `appName` | `java.lang.String` |
| `appNameCh` | `java.lang.String` |
| `hostAppName` | `java.lang.String` |
| `hostAppNameCh` | `java.lang.String` |
| `conditions` | `java.lang.String` |
| `fieldName` | `java.lang.String` |
| `childrenFieldName` | `java.lang.String` |
| `outType` | `java.lang.Integer` |
| `mgnRelation` | `java.lang.Integer` |
| `isDelete` | `java.lang.Integer` |
| `isShow` | `java.lang.Integer` |

## `MyAttentionDto`（16 字段）

`com.seeyon.app.common.attention.dto.MyAttentionDto`

被这些方法当入参：

- `MyAttentionCommonAppService.create()`（包装入参）
- `MyAttentionCommonAppService.createOrUpdateBatch()`（裸参数）
- `MyAttentionCommonAppService.update()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `objectId` | `java.lang.Long` |
| `objectUserId` | `java.lang.Long` |
| `objectUserName` | `java.lang.String` |
| `objectCreateTime` | `java.util.Date` |
| `title` | `java.lang.String` |
| `appId` | `java.lang.String` |
| `appName` | `java.lang.String` |
| `openTypePc` | `java.lang.String` |
| `openTypeMobile` | `java.lang.String` |
| `openUrlPc` | `java.lang.String` |
| `openUrlMobile` | `java.lang.String` |
| `params` | `java.lang.String` |
| `type` | `com.seeyon.app.common.attention.enums.AttentionTypeEnum` |
| `categoryId` | `java.lang.String` |
| `userId` | `java.lang.Long` |

## `AgentParamDto`（12 字段）

`com.seeyon.app.common.agent.dto.AgentParamDto`

被这些方法当入参：

- `AgentCommonAppService.hasAgent()`（包装入参）
- `AgentCommonAppService.selectByUserIdAndTemplate()`（包装入参）

| 字段 | 类型 |
|---|---|
| `userId` | `java.lang.Long` |
| `startMemberId` | `java.lang.Long` |
| `affairOwnerId` | `java.lang.Long` |
| `departmentId` | `java.lang.Long` |
| `postId` | `java.lang.Long` |
| `orgId` | `java.lang.Long` |
| `templateId` | `java.lang.Long` |
| `agentIds` | `java.util.List<java.lang.Long>` |
| `agentToIds` | `java.util.List<java.lang.Long>` |
| `processorMap` | `java.util.Map<java.lang.Long, java.util.List<java.lang.Long>>` |
| `sendMq` | `java.lang.Boolean` |
| `edocAgentParam` | `com.seeyon.app.common.agent.dto.AgentConditionDto` |

## `ImageDto`（12 字段）

`com.seeyon.app.common.image.dto.ImageDto`

被这些方法当入参：

- `ImageAppService.create()`（裸参数）
- `ImageAppService.update()`（裸参数）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `id` | `java.lang.Long` |
| `orgId` | `java.lang.Long` |
| `userId` | `java.lang.Long` |
| `sysinit` | `java.lang.Boolean` |
| `imagePath` | `java.lang.String` |
| `name` | `java.lang.String` |
| `previewFileId` | `java.lang.String` |
| `categoryId` | `java.lang.Long` |
| `storeId` | `java.lang.Long` |
| `storageKey` | `java.lang.String` |
| `extendName` | `java.lang.String` |

## `ThemeDto`（12 字段）

`com.seeyon.app.common.theme.dto.ThemeDto`

被这些方法当入参：

- `ThemeAppService.create()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `id` | `java.lang.Long` |
| `name` | `java.lang.String` |
| `description` | `java.lang.String` |
| `status` | `java.lang.Boolean` |
| `primaryColor` | `java.lang.String` |
| `globalStyleData` | `java.util.Map<java.lang.String, java.lang.Object>` |
| `themeComponentData` | `java.util.Map<java.lang.String, java.lang.Object>` |
| `publishStatus` | `java.lang.Boolean` |
| `storageKey` | `java.lang.String` |
| `mobileStorageKey` | `java.lang.String` |
| `defaultFlag` | `java.lang.Boolean` |

## `CategoryDto`（10 字段）

`com.seeyon.app.common.category.dto.CategoryDto`

被这些方法当入参：

- `CategoryCommonAppService.create()`（包装入参）
- `CategoryCommonAppService.update()`（包装入参）
- `CategoryCommonAppService.checkCategoryBatch()`（裸参数）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `id` | `java.lang.Long` |
| `originApp` | `java.lang.String` |
| `name` | `java.lang.String` |
| `code` | `java.lang.String` |
| `orderNo` | `java.lang.Integer` |
| `parentId` | `java.lang.Long` |
| `parentCode` | `java.lang.String` |
| `categoryLevel` | `java.lang.Integer` |
| `topId` | `java.lang.Long` |

## `ImageStoreDto`（8 字段）

`com.seeyon.app.common.image.dto.ImageStoreDto`

被这些方法当入参：

- `ImageStoreAppService.save()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `id` | `java.lang.Long` |
| `orgId` | `java.lang.Long` |
| `userId` | `java.lang.Long` |
| `sysinit` | `java.lang.Boolean` |
| `previewFileId` | `java.lang.String` |
| `name` | `java.lang.String` |
| `imageCount` | `java.lang.Integer` |

## `QrCodeCreateDto`（8 字段）

`com.seeyon.app.common.qrcode.dto.QrCodeCreateDto`

被这些方法当入参：

- `QrCodeCommonAppService.create()`（包装入参）

| 字段 | 类型 |
|---|---|
| `appId` | `java.lang.String` |
| `objectId` | `java.lang.Long` |
| `url` | `java.lang.String` |
| `expireTime` | `java.lang.Long` |
| `type` | `com.seeyon.app.common.qrcode.enums.CodeTypeEnum` |
| `linkParams` | `java.lang.String` |
| `interim` | `java.lang.Boolean` |
| `qrCodeParam` | `com.seeyon.app.common.qrcode.dto.QrCodeParamDto` |

## `ImageCategoryDto`（7 字段）

`com.seeyon.app.common.image.dto.ImageCategoryDto`

被这些方法当入参：

- `ImageCategoryAppService.save()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `id` | `java.lang.Long` |
| `orgId` | `java.lang.Long` |
| `userId` | `java.lang.Long` |
| `sysinit` | `java.lang.Boolean` |
| `name` | `java.lang.String` |
| `storeId` | `java.lang.Long` |

## `AutoApplicationDto`（6 字段）

`com.seeyon.app.approval.dto.auto.AutoApplicationDto`

被这些方法当入参：

- `ApprovalAppService.autoGenerateApplication()`（包装入参）

| 字段 | 类型 |
|---|---|
| `id` | `java.lang.Long` |
| `name` | `java.lang.String` |
| `categoryCode` | `java.lang.String` |
| `entities` | `java.util.List<com.seeyon.app.approval.dto.auto.AutoEntityDto>` |
| `templates` | `java.util.List<com.seeyon.app.approval.dto.auto.AutoTemplateDto>` |
| `nodePermissions` | `java.util.List<com.seeyon.app.approval.dto.auto.AutoNodePermissionDto>` |

## `WorkDayRequestDto`（6 字段）

`com.seeyon.app.common.worktime.dto.WorkDayRequestDto`

被这些方法当入参：

- `WorktimeAppService.selectSpecifyWorkDay()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `orgId` | `java.lang.Long` |
| `date` | `java.util.Date` |
| `distance` | `java.lang.Integer` |
| `unit` | `com.seeyon.app.common.worktime.enums.MonthUnitEnum` |
| `direction` | `java.lang.Boolean` |

## `WorktimeSyncSpecialDayDto`（6 字段）

`com.seeyon.app.common.worktime.dto.WorktimeSyncSpecialDayDto`

被这些方法当入参：

- `WorktimeAppService.syncWorktimeSpecialDay()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `aviYear` | `java.lang.Integer` |
| `orgId` | `java.lang.Long` |
| `worktimeSpecials` | `java.util.List<com.seeyon.app.common.worktime.dto.WorktimeSpecialDayDto>` |
| `updateAll` | `java.lang.Boolean` |
| `allOrg` | `java.lang.Boolean` |

## `ApprovalFrameParamDto`（5 字段）

`com.seeyon.app.approval.dto.ApprovalFrameParamDto`

被这些方法当入参：

- `ApprovalFrameApiTransportAppService.exportApprovalFrameInfo()`（包装入参）

| 字段 | 类型 |
|---|---|
| `caption` | `java.lang.String` |
| `applicationId` | `java.lang.Long` |
| `name` | `java.lang.String` |
| `guid` | `java.lang.Long` |
| `orgId` | `java.lang.Long` |

## `ApprovalGraphqlRequestDto`（5 字段）

`com.seeyon.app.approval.dto.ApprovalGraphqlRequestDto`

被这些方法当入参：

- `ApprovalAppService.getFormDataByGraphql()`（包装入参）

| 字段 | 类型 |
|---|---|
| `appName` | `java.lang.String` |
| `appType` | `java.lang.String` |
| `query` | `java.lang.String` |
| `operationName` | `java.lang.String` |
| `variables` | `java.util.Map<java.lang.String, java.lang.Object>` |

## `LabelDepartmentDto`（5 字段）

`com.seeyon.app.common.label.dto.LabelDepartmentDto`

被这些方法当入参：

- `LabelAppService.updateReferenceCount()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `name` | `java.lang.String` |
| `deptId` | `java.lang.Long` |
| `labelId` | `java.lang.Long` |
| `referenceCount` | `java.lang.Integer` |

## `WorktimeAfterTimeDto`（5 字段）

`com.seeyon.app.common.worktime.dto.WorktimeAfterTimeDto`

被这些方法当入参：

- `WorktimeAppService.getWorkEndDate()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `orgId` | `java.lang.Long` |
| `beginDate` | `java.util.Date` |
| `time` | `java.lang.Integer` |
| `timeUnit` | `com.seeyon.app.common.worktime.enums.TimeUnitEnum` |

## `WorktimeBetweenYearDto`（4 字段）

`com.seeyon.app.common.worktime.dto.WorktimeBetweenYearDto`

被这些方法当入参：

- `WorktimeAppService.getWorkTimeBetweenYear()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `beginYear` | `java.lang.Integer` |
| `endYear` | `java.lang.Integer` |
| `orgId` | `java.lang.Long` |

## `WorktimeDateTimeDto`（4 字段）

`com.seeyon.app.common.worktime.dto.WorktimeDateTimeDto`

被这些方法当入参：

- `WorktimeAppService.getWorkTimeBetweenDate()`（包装入参）
- `WorktimeAppService.selectNonWorkDayList()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `orgId` | `java.lang.Long` |
| `beginDate` | `java.util.Date` |
| `endDate` | `java.util.Date` |

## `AgentEffectiveRequestDto`（3 字段）

`com.seeyon.app.common.agent.dto.AgentEffectiveRequestDto`

被这些方法当入参：

- `AgentCommonAppService.selectEffectiveAgentList()`（包装入参）

| 字段 | 类型 |
|---|---|
| `agentId` | `java.lang.Long` |
| `agentToId` | `java.lang.Long` |
| `types` | `java.util.List<com.seeyon.app.common.agent.enums.AgentTypeEnum>` |

## `MyAttentionBatchDeleteDto`（3 字段）

`com.seeyon.app.common.attention.dto.MyAttentionBatchDeleteDto`

被这些方法当入参：

- `MyAttentionCommonAppService.deleteBatchByObjectIds()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `objectId` | `java.util.List<java.lang.Long>` |
| `userId` | `java.lang.Long` |

## `WorktimeDateDto`（3 字段）

`com.seeyon.app.common.worktime.dto.WorktimeDateDto`

被这些方法当入参：

- `WorktimeAppService.getWorkDayType()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `date` | `java.lang.String` |
| `orgId` | `java.lang.Long` |

## `WorktimeYearDto`（3 字段）

`com.seeyon.app.common.worktime.dto.WorktimeYearDto`

被这些方法当入参：

- `WorktimeAppService.selectWorktimeByOrgIdAndYear()`（包装入参）
- `WorktimeAppService.selectByOrgIdAndYear()`（包装入参）
- `WorktimeAppService.getByParentOrgIdAndYear()`（包装入参）
- `WorktimeAppService.getWorkTimeByYear()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `year` | `java.lang.Integer` |
| `orgId` | `java.lang.Long` |

## `LabelUpdateCountDto`（2 字段）

`com.seeyon.app.common.label.dto.LabelUpdateCountDto`

被这些方法当入参：

- `LabelAppService.batchUpdateReferenceCount()`（包装入参）

| 字段 | 类型 |
|---|---|
| `adds` | `java.util.List<java.lang.Long>` |
| `reduces` | `java.util.List<java.lang.Long>` |

## `SealPasswordCheckDto`（2 字段）

`com.seeyon.app.common.seal.dto.SealPasswordCheckDto`

被这些方法当入参：

- `SealCommonAppService.checkSealPassword()`（包装入参）

| 字段 | 类型 |
|---|---|
| `id` | `java.lang.Long` |
| `password` | `java.lang.String` |

## `CategorySyncBatchDto`（1 字段）

`com.seeyon.app.common.category.dto.CategorySyncBatchDto`

被这些方法当入参：

- `CategoryCommonAppService.createBatch()`（包装入参）

| 字段 | 类型 |
|---|---|
| `list` | `java.util.List<com.seeyon.app.common.category.dto.CategoryDto>` |
