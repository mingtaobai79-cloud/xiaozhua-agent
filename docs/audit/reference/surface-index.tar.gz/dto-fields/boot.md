# 平台基础：入参 DTO 字段表

> 自动生成。包前缀 `com.seeyon.boot`。共 85 个 DTO。
> 字段类型逐字来自 javap；`static` 前缀表示常量而非实例字段。

## `OpinionDto`（67 字段）

`com.seeyon.boot.starter.opinion.dto.table.OpinionDto`

被这些方法当入参：

- `OpinionService.create()`（裸参数）
- `OpinionService.update()`（裸参数）
- `OpinionService.updateSilent()`（裸参数）
- `OpinionService.updateBatch()`（裸参数）
- `OpinionService.selectSubOpinionListByIds()`（裸参数）
- `OpinionService.batchCreate()`（裸参数）
- … 另 1 处

| 字段 | 类型 |
|---|---|
| `id` | `java.lang.Long` |
| `createTime` | `java.util.Date` |
| `updateTime` | `java.util.Date` |
| `appName` | `java.lang.String` |
| `objectId` | `java.lang.Long` |
| `subObjectId` | `java.lang.Long` |
| `affairId` | `java.lang.Long` |
| `createUserId` | `java.lang.Long` |
| `createUserName` | `java.lang.String` |
| `createUserPostName` | `java.lang.String` |
| `createUserDeptName` | `java.lang.String` |
| `content` | `java.lang.String` |
| `richContent` | `java.lang.String` |
| `opinion` | `java.lang.String` |
| `opinionName` | `java.lang.String` |
| `operation` | `java.lang.String` |
| `operationName` | `java.lang.String` |
| `hasOperationLog` | `java.lang.Boolean` |
| `replyId` | `java.lang.Long` |
| `replyTopId` | `java.lang.Long` |
| `replyUserId` | `java.lang.Long` |
| `replyUserName` | `java.lang.String` |
| `replyUserDeptName` | `java.lang.String` |
| `replyUserPostName` | `java.lang.String` |
| `anonymous` | `java.lang.Boolean` |
| `opinionHide` | `java.util.List<java.lang.Long>` |
| `praise` | `java.util.List<java.lang.Long>` |
| `praiseName` | `java.util.List<java.lang.String>` |
| `praiseNum` | `java.lang.Long` |
| `currentUserPraise` | `java.lang.Boolean` |
| `deleteFlag` | `java.lang.Boolean` |
| `attachment` | `java.util.List<java.lang.String>` |
| `originAttachment` | `java.lang.String` |
| `associateDocument` | `java.util.List<com.seeyon.boot.starter.opinion.dto.biz.OpinionAssociateDocumentDto>` |
| `activityNodeId` | `java.lang.Long` |
| `activityNodeName` | `java.lang.String` |
| `nodeFirstDelTime` | `java.util.Date` |
| `activityFirstTime` | `java.util.Date` |
| `subOpinions` | `java.util.List<com.seeyon.boot.starter.opinion.dto.table.OpinionDto>` |
| `subOpinionNum` | `int` |
| `agentId` | `java.lang.Long` |
| `sublicenseId` | `java.lang.Long` |
| `sourceNodeId` | `java.lang.Long` |
| `opinionType` | `com.seeyon.boot.starter.opinion.enums.OpinionTypeEnum` |
| `hidden` | `java.lang.Boolean` |
| `showPerson` | `java.lang.String` |
| `permissionId` | `java.lang.Long` |
| `extendImplFlag` | `java.lang.String` |
| `batchId` | `java.lang.Long` |
| `dynamicNodePath` | `java.lang.String` |
| `splitNodeOpinion` | `java.lang.Boolean` |
| `createUserSeal` | `java.lang.String` |
| `actionTime` | `java.util.Date` |
| `extString1` | `java.lang.String` |
| `nodeType` | `java.lang.String` |
| `sourceBatchId` | `java.lang.Long` |
| `forwardCount` | `java.lang.Integer` |
| `createAccountId` | `java.lang.Long` |
| `createDeptId` | `java.lang.Long` |
| `attitudeEnum` | `java.lang.String` |
| `attitudeEnumItem` | `java.lang.String` |
| `userIds` | `java.util.List<java.lang.Long>` |
| `isMentionAll` | `java.lang.Boolean` |
| `atTime` | `java.util.Date` |
| `businessDeptName` | `java.lang.String` |
| `createUserRoleName` | `java.lang.String` |
| `firstDeptName` | `java.lang.String` |

## `UdcAttributeMetaDataDto`（47 字段）

`com.seeyon.boot.starter.extmetadata.dto.UdcAttributeMetaDataDto`

被这些方法当入参：

- `TypeHelper.getDatabaseDataType()`（裸参数）
- `TypeHelper.getJavaType()`（裸参数）
- `TypeHelper.getLength()`（裸参数）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `caption` | `java.lang.String` |
| `description` | `java.lang.String` |
| `dataType` | `java.lang.String` |
| `type` | `java.lang.String` |
| `multiSelect` | `boolean` |
| `relationType` | `java.lang.String` |
| `relationHostAppName` | `java.lang.String` |
| `relationAppName` | `java.lang.String` |
| `relationApp` | `java.lang.String` |
| `relationStarter` | `java.lang.String` |
| `relationAppType` | `com.seeyon.boot.starter.extmetadata.enums.DependentAppTypeEnum` |
| `relationEntity` | `java.lang.String` |
| `relationEntityFullName` | `java.lang.String` |
| `relationCtpEnumCode` | `java.lang.String` |
| `parentEnumAttributeId` | `java.lang.Long` |
| `parentEnumAttributeFullName` | `java.lang.String` |
| `unique` | `boolean` |
| `group` | `java.lang.String` |
| `groupType` | `java.lang.String` |
| `dataI18n` | `boolean` |
| `safety` | `com.seeyon.boot.starter.extmetadata.dto.SafetyMetaDataDto` |
| `columnName` | `java.lang.String` |
| `columnType` | `java.lang.String` |
| `name` | `java.lang.String` |
| `defaultValue` | `java.lang.String` |
| `calculate` | `com.seeyon.boot.starter.extmetadata.enums.AttributeCalculateEnum` |
| `aggregateFunction` | `java.lang.String` |
| `expressionDesignData` | `java.lang.String` |
| `expressionRuntimeData` | `java.lang.String` |
| `defaultValueExpressionDesignData` | `java.lang.String` |
| `defaultValueExpressionRuntimeData` | `java.lang.String` |
| `defaultValueSystemVariable` | `java.lang.String` |
| `enablePermission` | `java.lang.Boolean` |
| `system` | `java.lang.Boolean` |
| `existDto` | `java.lang.Boolean` |
| `entityId` | `java.lang.Long` |
| `orderNo` | `java.lang.Integer` |
| `inCondition` | `java.lang.Boolean` |
| `inDataMapping` | `java.lang.Boolean` |
| `sourceType` | `com.seeyon.boot.starter.extmetadata.enums.AttributeSourceTypeEnum` |
| `defaultValueIsChange` | `java.lang.Boolean` |
| `validation` | `java.util.Map<java.lang.String, java.lang.Object>` |
| `enums` | `java.util.List<java.lang.String>` |
| `enumDtos` | `java.util.List<com.seeyon.boot.starter.extmetadata.dto.UdcJavaEnumItemMetaDataDto>` |
| `customs` | `java.util.Map<java.lang.String, java.lang.Object>` |
| `widgetConfig` | `java.lang.String` |

## `UdcPageMetadataV2Dto`（28 字段）

`com.seeyon.boot.starter.extmetadata.dto.UdcPageMetadataV2Dto`

被这些方法当入参：

- `CustomPlanPageFeatureHandler.pageSupportCustomPlan()`（裸参数）

| 字段 | 类型 |
|---|---|
| `createTime` | `java.util.Date` |
| `appId` | `java.lang.Long` |
| `appName` | `java.lang.String` |
| `groupId` | `java.lang.Long` |
| `relationGroupId` | `java.lang.Long` |
| `menuCode` | `java.lang.String` |
| `name` | `java.lang.String` |
| `caption` | `java.lang.String` |
| `description` | `java.lang.String` |
| `pageType` | `java.lang.String` |
| `handWritten` | `java.lang.Boolean` |
| `defaultOpenType` | `java.lang.String` |
| `urlType` | `java.lang.String` |
| `pageUrl` | `java.lang.String` |
| `inParams` | `java.lang.String` |
| `outParameters` | `java.lang.String` |
| `sortNo` | `java.lang.Integer` |
| `sourceType` | `java.lang.String` |
| `inPortletParams` | `java.lang.String` |
| `pageSchema` | `java.lang.String` |
| `masterEntity` | `java.lang.String` |
| `relationApp` | `java.lang.String` |
| `layout` | `java.lang.String` |
| `clientType` | `java.lang.String` |
| `publicAccess` | `java.lang.Boolean` |
| `isDraftPage` | `java.lang.Boolean` |
| `relationPlan` | `java.lang.String` |
| `jsonFile` | `java.lang.String` |

## `DeductionRtRuleDto`（25 字段）

`com.seeyon.boot.starter.deduction.dto.DeductionRtRuleDto`

被这些方法当入参：

- `DeductionRtRuleAppService.saveRuleNewVersion()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `appId` | `java.lang.Long` |
| `deductionMapId` | `java.lang.Long` |
| `caption` | `java.lang.String` |
| `name` | `java.lang.String` |
| `sourceEntityId` | `java.lang.Long` |
| `targetEntityId` | `java.lang.Long` |
| `sourceEndEntityId` | `java.lang.Long` |
| `targetEndEntityId` | `java.lang.Long` |
| `sourceEntityFullName` | `java.lang.String` |
| `targetEntityFullName` | `java.lang.String` |
| `sourceEndEntityFullName` | `java.lang.String` |
| `targetEndEntityFullName` | `java.lang.String` |
| `searchCondition` | `java.lang.String` |
| `extendInfo` | `java.lang.String` |
| `runtimeModifyState` | `com.seeyon.udc.common.enums.RuntimeModifyStateEnum` |
| `orderNum` | `java.lang.Integer` |
| `combinationAttributeState` | `com.seeyon.boot.starter.deduction.enums.CombinationAttributeStateEnum` |
| `deductionRtRuleDetailDtoList` | `java.util.List<com.seeyon.boot.starter.deduction.dto.DeductionRtRuleDetailDto>` |
| `deductionRtAlgorithmDtoList` | `java.util.List<com.seeyon.boot.starter.deduction.dto.DeductionRtAlgorithmDto>` |
| `deductionRtRuleSearchConditionDtoList` | `java.util.List<com.seeyon.udc.common.dto.DeductionRtRuleSearchConditionDto>` |
| `originalRuleId` | `java.lang.Long` |
| `versionNumber` | `java.lang.String` |
| `extendInfoDto` | `com.seeyon.udc.common.dto.DeductionRuleExtendInfoDto` |
| `startState` | `com.seeyon.udc.common.enums.DeductionStartStateEnum` |

## `CtpEnumItemSimpleDto`（18 字段）

`com.seeyon.boot.starter.enums.dto.CtpEnumItemSimpleDto`

被这些方法当入参：

- `CtpEnumItemFilterInterface.filter()`（裸参数）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `name` | `java.lang.String` |
| `enumCode` | `java.lang.String` |
| `enumId` | `java.lang.Long` |
| `parentId` | `java.lang.Long` |
| `imageKey` | `java.lang.String` |
| `itemLevel` | `java.lang.Integer` |
| `leaf` | `java.lang.Boolean` |
| `itemValue` | `java.lang.String` |
| `appId` | `java.lang.String` |
| `appGuid` | `java.lang.Long` |
| `orderNo` | `java.lang.Integer` |
| `delete` | `java.lang.Boolean` |
| `enable` | `java.lang.Boolean` |
| `originalId` | `java.lang.Long` |
| `preset` | `boolean` |
| `child` | `java.util.List<com.seeyon.boot.starter.enums.dto.CtpEnumItemSimpleDto>` |
| `aggregationAppName` | `java.lang.String` |

## `CtpQrCodeRuleDto`（17 字段）

`com.seeyon.boot.starter.qrcode.dto.CtpQrCodeRuleDto`

被这些方法当入参：

- `CtpQrCodeService.createCtpQrCode()`（裸参数）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `code` | `java.lang.String` |
| `name` | `java.lang.String` |
| `type` | `com.seeyon.boot.starter.qrcode.enums.CtpQrCodeTypeEnum` |
| `linkType` | `com.seeyon.boot.starter.qrcode.enums.CtpQrCodeLinkTypeEnum` |
| `appGuid` | `java.lang.Long` |
| `appId` | `java.lang.Long` |
| `entityFullName` | `java.lang.String` |
| `fieldCode` | `java.lang.String` |
| `pcPagePath` | `java.lang.String` |
| `mobilePagePath` | `java.lang.String` |
| `valueFieldCode` | `java.lang.String` |
| `active` | `java.lang.Boolean` |
| `deleteFlag` | `java.lang.Boolean` |
| `createId` | `java.lang.Long` |
| `updateId` | `java.lang.Long` |
| `releaseState` | `com.seeyon.boot.starter.qrcode.enums.QrCodeReleaseStateEnum` |

## `LicenseDto`（16 字段）

`com.seeyon.boot.starter.license.LicenseDto`

被这些方法当入参：

- `LicenseProcessor.refreshTenantLicense()`（裸参数）

| 字段 | 类型 |
|---|---|
| `checkSum` | `java.lang.String` |
| `ignoreUdcApp` | `boolean` |
| `clientName` | `java.lang.String` |
| `product` | `java.lang.String` |
| `date` | `java.lang.String` |
| `organ` | `int` |
| `regist` | `int` |
| `im` | `int` |
| `online` | `int` |
| `plugins` | `java.util.TreeSet<java.lang.String>` |
| `tenantNum` | `int` |
| `tenantMode` | `boolean` |
| `appPlugins` | `java.util.Map<java.lang.String, java.util.List>` |
| `limitMap` | `java.util.Map<java.lang.String, java.lang.Integer>` |
| `expireDateMap` | `java.util.Map<java.lang.String, java.lang.String>` |
| `extendedMap` | `java.util.Map<java.lang.String, java.util.Map<java.lang.String, java.lang.String>>` |

## `MessageDto`（16 字段）

`com.seeyon.boot.starter.mq.support.dto.MessageDto`

被这些方法当入参：

- `MessageListener.onMessage()`（裸参数）
- `AdvancedMessageProducer.send()`（裸参数）
- `AdvancedMessageProducer.sendBatch()`（裸参数）
- `AdvancedMessageProducer.sendDirectOneTime()`（裸参数）

| 字段 | 类型 |
|---|---|
| `log` | static `org.slf4j.Logger` |
| `serialVersionUID` | static `long` |
| `fromApp` | `java.lang.String` |
| `transferRequestContext` | `com.seeyon.boot.context.TransferRequestContext` |
| `traceId` | `java.lang.String` |
| `secretLevel` | `java.lang.Integer` |
| `tenantId` | `java.lang.Long` |
| `grayTag` | `java.lang.String` |
| `topic` | `java.lang.String` |
| `msgId` | `java.lang.String` |
| `partition` | `java.lang.Integer` |
| `executeTime` | `java.lang.Long` |
| `data` | `java.lang.Object` |
| `customPassThrough` | `java.util.Map<java.lang.String, java.lang.String>` |
| `createTime` | `java.lang.Long` |
| `dataFullName` | `java.lang.String` |

## `EntityDslDto`（15 字段）

`com.seeyon.boot.starter.configmigration.dto.EntityDslDto`

被这些方法当入参：

- `EntityDslHandler.handleDsl()`（裸参数）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `appName` | `java.lang.String` |
| `moduleCode` | `java.lang.String` |
| `stereotype` | `java.lang.String` |
| `moduleCh` | `java.lang.String` |
| `rootModule` | `java.lang.Boolean` |
| `titleField` | `java.lang.String` |
| `orgField` | `java.lang.String` |
| `uniqueField` | `java.lang.String` |
| `codeField` | `java.lang.String` |
| `creatorField` | `java.lang.String` |
| `groupField` | `java.lang.String` |
| `conditions` | `java.lang.String` |
| `forwardRelations` | `java.util.List<com.seeyon.boot.starter.configmigration.dto.FieldRelationDslDto>` |
| `reverseRelations` | `java.util.List<com.seeyon.boot.starter.configmigration.dto.FieldRelationDslDto>` |

## `UdcSerialConfigDto`（15 字段）

`com.seeyon.boot.starter.udcrt.dto.UdcSerialConfigDto`

被这些方法当入参：

- `UdcSerialConfigAppService.update()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `sourceFullName` | `java.lang.String` |
| `sourceCaption` | `java.lang.String` |
| `entityFullName` | `java.lang.String` |
| `entityCaption` | `java.lang.String` |
| `serialId` | `java.lang.Long` |
| `serialCaption` | `java.lang.String` |
| `serialActive` | `java.lang.Boolean` |
| `canEdit` | `java.lang.Boolean` |
| `preset` | `java.lang.Boolean` |
| `appName` | `java.lang.String` |
| `appGuid` | `java.lang.Long` |
| `serialAppName` | `java.lang.String` |
| `serialHostAppName` | `java.lang.String` |
| `serialGuid` | `java.lang.Long` |

## `SchemaStructureDto`（14 字段）

`com.seeyon.boot.starter.formula.dto.variable.SchemaStructureDto`

被这些方法当入参：

- `WidgetExpressionDetectionFunction.doDetection()`（裸参数）
- `Interpreter.isMultiCtpEnumAssign()`（裸参数）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `name` | `java.lang.String` |
| `description` | `java.lang.String` |
| `type` | `java.lang.String` |
| `defaultExpanded` | `java.lang.Boolean` |
| `linkageControlData` | `com.seeyon.boot.starter.formula.dto.ControlData` |
| `extParams` | `java.lang.String` |
| `selectable` | `java.lang.Boolean` |
| `icon` | `java.lang.String` |
| `enableDataI18n` | `boolean` |
| `properties` | `java.util.List<com.seeyon.boot.starter.formula.dto.variable.SchemaStructureDto>` |
| `uniformityParams` | `com.seeyon.boot.starter.formula.dto.runtime.UniformityParams` |
| `items` | `com.seeyon.boot.starter.formula.dto.variable.ArrayItems` |
| `sweepMark` | `boolean` |

## `CtpOBSInfoDto`（12 字段）

`com.seeyon.boot.starter.sharding.dto.CtpOBSInfoDto`

被这些方法当入参：

- `StorageService.check()`（裸参数）

| 字段 | 类型 |
|---|---|
| `id` | `java.lang.Long` |
| `name` | `java.lang.String` |
| `obsType` | `com.seeyon.boot.starter.sharding.enums.OBSType` |
| `accessKeyId` | `java.lang.String` |
| `accessKeySecret` | `java.lang.String` |
| `apiEndpoint` | `java.lang.String` |
| `accessEndpoint` | `java.lang.String` |
| `privateBucketName` | `java.lang.String` |
| `createTime` | `java.util.Date` |
| `updateTime` | `java.util.Date` |
| `isUsed` | `java.lang.Boolean` |
| `useType` | `java.lang.Integer` |

## `PersonalPlanDto`（11 字段）

`com.seeyon.boot.starter.customplan.dto.PersonalPlanDto`

被这些方法当入参：

- `PersonalPlanAppService.createRedirectBatch()`（裸参数）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `appName` | `java.lang.String` |
| `customePageUrl` | `java.lang.String` |
| `pageUrl` | `java.lang.String` |
| `title` | `java.lang.String` |
| `terminal` | `com.seeyon.udc.common.enums.PageUrlTypeEnum` |
| `authType` | `com.seeyon.boot.starter.customplan.enums.AuthTypeEnum` |
| `authId` | `java.lang.Long` |
| `sourceType` | `com.seeyon.boot.starter.customplan.enums.CustomPlanSourceTypeEnum` |
| `sourceId` | `java.lang.Long` |
| `customAppCreateTime` | `java.util.Date` |

## `ScalabilityFieldDto`（11 字段）

`com.seeyon.boot.starter.customplan.dto.ScalabilityFieldDto`

被这些方法当入参：

- `ScalabilityFieldAppService.updateBatch()`（裸参数）
- `ScalabilityFieldAppService.transportIn()`（裸参数）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `id` | `java.lang.Long` |
| `appName` | `java.lang.String` |
| `entityFullName` | `java.lang.String` |
| `entityCaption` | `java.lang.String` |
| `attributeCaption` | `java.lang.String` |
| `attributeName` | `java.lang.String` |
| `dataType` | `java.lang.String` |
| `state` | `com.seeyon.udc.common.enums.UsageStateEnum` |
| `attrValue` | `com.seeyon.udc.common.dto.AttributeDto` |
| `importStrategy` | `java.lang.String` |

## `ProxyJoinParamDto`（11 字段）

`com.seeyon.boot.starter.dynamicsql.dto.ProxyJoinParamDto`

被这些方法当入参：

- `BpmCaseAppService.dynamicJoinSelect()`（包装入参）
- `BpmTemplateAppService.dynamicJoinSelect()`（包装入参）
- `CtpRoleCoreAppService.dynamicJoinSelect()`（包装入参）
- `CtpUserRoleAppService.dynamicJoinSelect()`（包装入参）
- `OrgBusinessBaseAppService.dynamicJoinSelect()`（包装入参）
- `OrgBusinessBaseAppService.dynamicCountJoinSelect()`（包装入参）
- … 另 11 处

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `pageInfo` | `com.seeyon.boot.transport.PageInfo` |
| `sort` | `com.seeyon.boot.transport.Sort` |
| `entityList` | `java.util.List<java.lang.String>` |
| `distinctList` | `java.util.List<java.lang.String>` |
| `fieldMap` | `java.util.Map<java.lang.String, java.util.Set<java.lang.String>>` |
| `fromEntity` | `java.lang.String` |
| `joinParamDtoList` | `java.util.List<com.seeyon.boot.starter.dynamicsql.dto.JoinParamDto>` |
| `groupMap` | `java.util.Map<java.lang.String, java.util.Set<java.lang.String>>` |
| `cond` | `com.seeyon.boot.starter.dynamicsql.dto.DynamicConditionDto` |
| `jdbcDriver` | `java.lang.Boolean` |

## `TaskInfoDto`（10 字段）

`com.seeyon.boot.starter.configmigration.dto.TaskInfoDto`

被这些方法当入参：

- `ExecuteTemplate.executeQuery()`（裸参数）
- `TaskListener.onStart()`（裸参数）
- `TaskListener.beforeExecute()`（裸参数）
- `TaskListener.afterExecute()`（裸参数）
- `TaskListener.onComplete()`（裸参数）
- `TaskListener.onError()`（裸参数）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `taskType` | `com.seeyon.boot.starter.configmigration.enums.TaskType` |
| `packageId` | `java.lang.Long` |
| `taskId` | `java.lang.Long` |
| `appName` | `java.lang.String` |
| `moduleCode` | `java.lang.String` |
| `status` | `com.seeyon.boot.starter.configmigration.enums.TaskStatus` |
| `reason` | `java.lang.String` |
| `condition` | `com.seeyon.boot.starter.configmigration.core.context.condition.QueryCondition` |
| `writeBackDatas` | `java.util.List<com.seeyon.boot.starter.configmigration.dto.DataLogDto>` |

## `AppServiceInvokeDto`（10 字段）

`com.seeyon.boot.starter.dubbo.dto.AppServiceInvokeDto`

被这些方法当入参：

- `AppServiceProxy.invokeAppService()`（包装入参）
- `AppServiceProxy.invokeAppServiceForList()`（包装入参）
- `AppServiceProxy.invokeAppServiceForPage()`（包装入参）
- `CustomerProxyAppService.invokeAppService()`（包装入参）
- `CustomerProxyAppService.invokeAppServiceForList()`（包装入参）
- `CustomerProxyAppService.invokeAppServiceForPage()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `interfaceName` | `java.lang.String` |
| `methodName` | `java.lang.String` |
| `paramType` | `java.lang.String` |
| `genericType` | `java.lang.String` |
| `subGenericType` | `java.lang.String` |
| `paramJson` | `java.lang.String` |
| `beanName` | `java.lang.String` |
| `returnJson` | `java.lang.Boolean` |
| `bodyZip` | `java.lang.Boolean` |

## `UdcMetaDataSearchDto`（10 字段）

`com.seeyon.boot.starter.extmetadata.dto.request.UdcMetaDataSearchDto`

被这些方法当入参：

- `HostAppFunctionInterface.selectDependentApplicationByHostAppName()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `currentAppId` | `java.lang.Long` |
| `appName` | `java.lang.String` |
| `starterName` | `java.lang.String` |
| `version` | `java.lang.String` |
| `containsStarter` | `boolean` |
| `containsNotPublic` | `boolean` |
| `enableExtensionPlan` | `boolean` |
| `extensionPlanGuid` | `java.util.List<java.lang.Long>` |
| `extensionPlanId` | `java.util.List<java.lang.Long>` |

## `StorageKeyDto`（10 字段）

`com.seeyon.boot.starter.file.dto.StorageKeyDto`

被这些方法当入参：

- `StorageKeyGenerator.getStorageKey()`（裸参数）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `temp` | `boolean` |
| `fileId` | `java.lang.Long` |
| `tenantName` | `java.lang.String` |
| `bucketName` | `java.lang.String` |
| `appName` | `java.lang.String` |
| `exclusiveStorage` | `boolean` |
| `runtime` | `boolean` |
| `bizType` | `java.lang.String` |
| `custom` | `java.util.Map<java.lang.String, java.lang.Object>` |

## `ExpressionSaveDto`（10 字段）

`com.seeyon.boot.starter.formula.dto.ExpressionSaveDto`

被这些方法当入参：

- `ControlDataResolver.resolveControlData()`（裸参数）
- `ExpressionValidationFilter.doFilter()`（裸参数）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `resultTypeInfo` | `java.lang.String` |
| `resultTypeFullName` | `java.lang.String` |
| `isMultiSelect` | `java.lang.Boolean` |
| `terminalSupportType` | `com.seeyon.boot.starter.formula.engine.enums.TerminalSupportTypeEnum` |
| `resultRange` | `com.seeyon.boot.starter.formula.dto.ResultRangeDto` |
| `tokens` | `java.util.List<com.seeyon.boot.starter.formula.dto.ExpressionToken>` |
| `schemas` | `java.util.List<com.seeyon.boot.starter.formula.dto.variable.SchemaStructureDto>` |
| `sourceAppName` | `java.lang.String` |
| `version` | `java.lang.String` |

## `VariableSchemaLoadDto`（10 字段）

`com.seeyon.boot.starter.formula.dto.variable.VariableSchemaLoadDto`

被这些方法当入参：

- `ExprOutsideService.loadParamSchemaInfo()`（裸参数）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `appId` | `java.lang.Long` |
| `ids` | `java.util.List<java.lang.Long>` |
| `idsStr` | `java.util.List<java.lang.String>` |
| `idsTuple` | `java.util.List<com.seeyon.boot.starter.formula.domain.service.param.TupleParamDto>` |
| `extension` | `java.lang.String` |
| `paramType` | `java.lang.String` |
| `upsource` | `boolean` |
| `flat` | `java.lang.Boolean` |
| `serverName` | `java.lang.String` |

## `FormParamDto`（10 字段）

`com.seeyon.boot.starter.udcrt.dto.FormParamDto`

被这些方法当入参：

- `FormHandler.dataProcess()`（裸参数）

| 字段 | 类型 |
|---|---|
| `guid` | `java.lang.Long` |
| `groupId` | `java.lang.String` |
| `hostAppName` | `java.lang.String` |
| `artifactId` | `java.lang.String` |
| `version` | `java.lang.String` |
| `jsonStrParam` | `java.lang.String` |
| `aggEntityFullName` | `java.lang.String` |
| `aggEntityAppServiceFullName` | `java.lang.String` |
| `invokeMethod` | `java.lang.String` |
| `uploadFrontendResource` | `boolean` |

## `ArtifactDto`（9 字段）

`com.seeyon.boot.starter.artifact.service.ArtifactDto`

被这些方法当入参：

- `MavenArtifactService.upload()`（裸参数）
- `MavenArtifactService.download()`（裸参数）

| 字段 | 类型 |
|---|---|
| `SNAPSHOT` | static `java.lang.String` |
| `SNAPSHOT_TIMESTAMP` | static `java.util.regex.Pattern` |
| `appId` | `java.lang.String` |
| `groupId` | `java.lang.String` |
| `artifactId` | `java.lang.String` |
| `version` | `java.lang.String` |
| `extension` | `java.lang.String` |
| `file` | `java.io.File` |
| `pomFile` | `java.io.File` |

## `AttachmentQueryDto`（9 字段）

`com.seeyon.boot.starter.attachment.dto.AttachmentQueryDto`

被这些方法当入参：

- `AttachmentExtendApi.getAttachmentList()`（裸参数）
- `AttachmentExtendApi.getAttachmentList()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `id` | `java.lang.Long` |
| `appName` | `java.lang.String` |
| `hostAppName` | `java.lang.String` |
| `entityName` | `java.lang.String` |
| `appServiceImplFullName` | `java.lang.String` |
| `permissionId` | `java.lang.String` |
| `caseId` | `java.lang.Long` |
| `openType` | `java.lang.String` |

## `CBpmNodePermissionRequestDto`（9 字段）

`com.seeyon.boot.starter.customplan.dto.CBpmNodePermissionRequestDto`

被这些方法当入参：

- `UdcPageProcessEventService.selectProcessEventList()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `searchType` | `com.seeyon.boot.starter.customplan.enums.PageBpmEventSearchTypeEnum` |
| `appName` | `java.lang.String` |
| `layoutAppName` | `java.lang.String` |
| `layoutGuId` | `java.lang.Long` |
| `layoutPageType` | `com.seeyon.bpm.enums.PageTypeEnum` |
| `layoutUrl` | `java.lang.String` |
| `buildTime` | `java.lang.Long` |
| `vid` | `java.lang.Long` |

## `SpiUploadRequestDto`（9 字段）

`com.seeyon.boot.starter.file.spi.dto.SpiUploadRequestDto`

被这些方法当入参：

- `StorageSpi.upload()`（裸参数）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `inputStream` | `java.io.InputStream` |
| `bucketName` | `java.lang.String` |
| `fileName` | `java.lang.String` |
| `bizType` | `java.lang.String` |
| `appName` | `java.lang.String` |
| `storageKey` | `java.lang.String` |
| `runtime` | `boolean` |
| `useFileNameAsKey` | `boolean` |

## `AppInstanceDto`（9 字段）

`com.seeyon.boot.starter.nacos.dto.AppInstanceDto`

被这些方法当入参：

- `RegisterServiceSPI.registerInstance()`（裸参数）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `instanceId` | `java.lang.String` |
| `ip` | `java.lang.String` |
| `port` | `int` |
| `weight` | `double` |
| `healthy` | `boolean` |
| `clusterName` | `java.lang.String` |
| `serviceName` | `java.lang.String` |
| `metadata` | `java.util.Map<java.lang.String, java.lang.String>` |

## `OpinionAdminModifyDto`（9 字段）

`com.seeyon.boot.starter.opinion.dto.biz.OpinionAdminModifyDto`

被这些方法当入参：

- `OpinionAdminService.modifyOpinion()`（裸参数）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `content` | `java.lang.String` |
| `richContent` | `java.lang.String` |
| `hidden` | `java.lang.Boolean` |
| `showPerson` | `java.lang.String` |
| `objectId` | `java.lang.Long` |
| `actionTime` | `java.util.Date` |
| `attachmentStorageIds` | `java.util.List<com.seeyon.boot.starter.opinion.dto.biz.OpinionAttachmentStorageDto>` |
| `associateDocument` | `java.util.List<com.seeyon.boot.starter.opinion.dto.biz.OpinionAssociateDocumentDto>` |

## `ProxyParamDto`（8 字段）

`com.seeyon.boot.starter.dynamicsql.dto.ProxyParamDto`

被这些方法当入参：

- `BpmCaseAppService.dynamicSelect()`（包装入参）
- `BpmTemplateAppService.dynamicSelect()`（包装入参）
- `CtpRoleCoreAppService.dynamicSelect()`（包装入参）
- `CtpUserRoleAppService.dynamicSelect()`（包装入参）
- `OrgBusinessBaseAppService.dynamicSelect()`（包装入参）
- `OrgJobBaseAppService.dynamicSelect()`（包装入参）
- … 另 8 处

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `pageInfo` | `com.seeyon.boot.transport.PageInfo` |
| `sort` | `com.seeyon.boot.transport.Sort` |
| `params` | `com.seeyon.boot.starter.dynamicsql.dto.MainConditionDto` |
| `cond` | `com.seeyon.boot.starter.dynamicsql.dto.DynamicConditionDto` |
| `bootDtoFullName` | `java.lang.String` |
| `jdbcDriver` | `java.lang.Boolean` |
| `customPassThroughMap` | `java.util.Map<java.lang.String, java.lang.Object>` |

## `CtpQrCodeCreateNoRuleRequestDto`（8 字段）

`com.seeyon.boot.starter.qrcode.dto.CtpQrCodeCreateNoRuleRequestDto`

被这些方法当入参：

- `CtpQrCodeService.createCtpQrCodeNoRule()`（裸参数）

| 字段 | 类型 |
|---|---|
| `appId` | `java.lang.Long` |
| `appName` | `java.lang.String` |
| `objectId` | `java.lang.Long` |
| `type` | `com.seeyon.boot.starter.qrcode.enums.CtpQrCodeTypeEnum` |
| `qrValue` | `java.lang.String` |
| `expireTime` | `java.lang.Long` |
| `interim` | `java.lang.Boolean` |
| `qrCodeParam` | `com.seeyon.boot.util.qrcode.model.QrCodeParam` |

## `CtpQrCodeCreateRequestDto`（8 字段）

`com.seeyon.boot.starter.qrcode.dto.CtpQrCodeCreateRequestDto`

被这些方法当入参：

- `CtpQrCodeService.createCtpQrCode()`（裸参数）

| 字段 | 类型 |
|---|---|
| `appId` | `java.lang.Long` |
| `appName` | `java.lang.String` |
| `objectId` | `java.lang.Long` |
| `ruleId` | `java.lang.Long` |
| `qrValue` | `java.lang.String` |
| `expireTime` | `java.lang.Long` |
| `params` | `java.lang.String` |
| `extraParams` | `java.lang.String` |

## `ConfigItemSearchDto`（7 字段）

`com.seeyon.boot.starter.configmigration.view.dto.ConfigItemSearchDto`

被这些方法当入参：

- `ConfigServiceInterface.selectConfigItemList()`（裸参数）
- `ConfigServiceInterface.selectPageConfigItemList()`（裸参数）

| 字段 | 类型 |
|---|---|
| `appName` | `java.lang.String` |
| `hostAppName` | `java.lang.String` |
| `moduleCode` | `java.lang.String` |
| `selectType` | `java.lang.Integer` |
| `titleField` | `java.lang.String` |
| `fliedNames` | `java.util.Set<java.lang.String>` |
| `displayFields` | `java.util.List<com.seeyon.boot.starter.configmigration.view.dto.ShowFieldDto>` |

## `ScalabilityFieldQueryDto`（7 字段）

`com.seeyon.boot.starter.customplan.dto.ScalabilityFieldQueryDto`

被这些方法当入参：

- `ScalabilityFieldAppService.listExtFileds()`（包装入参）
- `ScalabilityFieldAppService.selectAvailableDatatype()`（包装入参）
- `ScalabilityFieldAppService.selectAttribute()`（包装入参）

| 字段 | 类型 |
|---|---|
| `appName` | `java.lang.String` |
| `entityFullName` | `java.lang.String` |
| `entityFullNames` | `java.util.List<java.lang.String>` |
| `attributeCaption` | `java.lang.String` |
| `attributeName` | `java.lang.String` |
| `dataType` | `java.lang.String` |
| `state` | `com.seeyon.udc.common.enums.UsageStateEnum` |

## `FillFlowReqDto`（7 字段）

`com.seeyon.boot.starter.dataflow.dto.FillFlowReqDto`

被这些方法当入参：

- `DataFlowForBpmAppService.fillErrorFlowData()`（包装入参）

| 字段 | 类型 |
|---|---|
| `formRecordId` | `java.lang.Long` |
| `caseSenderId` | `java.lang.Long` |
| `appName` | `java.lang.String` |
| `entityId` | `java.lang.Long` |
| `entityFullName` | `java.lang.String` |
| `serviceFullName` | `java.lang.String` |
| `needSend` | `java.lang.Boolean` |

## `QueryConditionDto`（7 字段）

`com.seeyon.boot.starter.dynamicsql.dto.QueryConditionDto`

被这些方法当入参：

- `BpmCaseAppService.selectCascadeByConditions()`（包装入参）
- `BpmCaseAppService.selectCascadeListByConditions()`（包装入参）
- `BpmTemplateAppService.selectCascadeByConditions()`（包装入参）
- `BpmTemplateAppService.selectCascadeListByConditions()`（包装入参）
- `OrgBusinessBaseAppService.selectCascadeByConditions()`（包装入参）
- `OrgBusinessBaseAppService.selectCascadeListByConditions()`（包装入参）
- … 另 16 处

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `queryEntityDto` | `com.seeyon.boot.starter.dynamicsql.dto.QueryEntityDto` |
| `pageInfo` | `com.seeyon.boot.transport.PageInfo` |
| `sort` | `com.seeyon.boot.transport.Sort` |
| `ids` | `java.util.List<java.lang.Long>` |
| `dynamicConditionDto` | `com.seeyon.boot.starter.dynamicsql.dto.DynamicConditionDto` |
| `one2ManyCondition` | `java.util.List<com.seeyon.boot.starter.dynamicsql.dto.QueryConditionDto>` |

## `PartUploadInitRequestDto`（7 字段）

`com.seeyon.boot.starter.file.dto.request.PartUploadInitRequestDto`

被这些方法当入参：

- `StorageService.partUploadInit()`（裸参数）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `fileName` | `java.lang.String` |
| `fileSize` | `java.lang.Long` |
| `pageId` | `java.lang.String` |
| `bizType` | `java.lang.String` |
| `bucketName1` | `java.lang.String` |
| `storageKey` | `java.lang.String` |

## `StorageUploadRequestDto`（7 字段）

`com.seeyon.boot.starter.file.dto.request.StorageUploadRequestDto`

被这些方法当入参：

- `StorageService.upload()`（裸参数）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `inputStream` | `java.io.InputStream` |
| `storageKey` | `java.lang.String` |
| `metadata` | `java.lang.String` |
| `fileName` | `java.lang.String` |
| `bizType` | `java.lang.String` |
| `runtime` | `boolean` |

## `OpinionExtendDto`（7 字段）

`com.seeyon.boot.starter.opinion.dto.biz.OpinionExtendDto`

被这些方法当入参：

- `ExtendComponentManager.sendMessage()`（裸参数）

| 字段 | 类型 |
|---|---|
| `objectId` | `java.lang.Long` |
| `topping` | `java.lang.Boolean` |
| `replyToUserId` | `java.lang.Long` |
| `opinionPersonList` | `java.util.List<java.lang.Long>` |
| `atPersonList` | `java.util.List<java.lang.Long>` |
| `isAll` | `boolean` |
| `anonymous` | `java.lang.Boolean` |

## `PageInfo`（7 字段）

`com.seeyon.boot.transport.PageInfo`

被这些方法当入参：

- `AffairSuperviseAppService.selectPageByFixedTemplate()`（包装入参）
- `AffairSuperviseAppService.selectTemplateAffairPageData()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `pageNumber` | `int` |
| `pageSize` | `int` |
| `pages` | `int` |
| `total` | `int` |
| `needTotal` | `boolean` |
| `needMore` | `boolean` |

## `PersonalQueryDto`（6 字段）

`com.seeyon.boot.starter.customplan.dto.PersonalQueryDto`

被这些方法当入参：

- `PersonalPlanAppService.selectByCondition()`（包装入参）
- `PersonalPlanAppService.selectListByCondition()`（包装入参）

| 字段 | 类型 |
|---|---|
| `appName` | `java.lang.String` |
| `pageUrl` | `java.lang.String` |
| `terminal` | `com.seeyon.udc.common.enums.PageUrlTypeEnum` |
| `userId` | `java.lang.Long` |
| `orgId` | `java.lang.Long` |
| `matchPermission` | `java.lang.Boolean` |

## `DataFlowOriginalMappingQueryDto`（6 字段）

`com.seeyon.boot.starter.dataflow.dto.DataFlowOriginalMappingQueryDto`

被这些方法当入参：

- `DataFlowMappingAppService.selectDetailByCondition()`（包装入参）

| 字段 | 类型 |
|---|---|
| `appId` | `java.lang.Long` |
| `guid` | `java.lang.Long` |
| `terminalType` | `com.seeyon.udc.common.enums.TerminalTypeEnum` |
| `convertDetailDto` | `java.lang.Boolean` |
| `transferListSchema` | `java.lang.Boolean` |
| `convertEntityInfo` | `java.lang.Boolean` |

## `UdcApplicationMetaDataDto`（6 字段）

`com.seeyon.boot.starter.extmetadata.dto.UdcApplicationMetaDataDto`

被这些方法当入参：

- `UdcPageLayoutPluginAppService.filterDependentApplicationList()`（裸参数）

| 字段 | 类型 |
|---|---|
| `entityMetaDataDtos` | `java.util.List<com.seeyon.boot.starter.extmetadata.dto.UdcEntityMetaDataDto>` |
| `dtoMetadataDtos` | `java.util.List<com.seeyon.boot.starter.extmetadata.dto.UdcDtoMetadataDto>` |
| `ctpEnumDtos` | `java.util.List<com.seeyon.boot.starter.enums.dto.CtpEnumDto>` |
| `udcEnumMetadataDtos` | `java.util.List<com.seeyon.boot.starter.extmetadata.dto.UdcJavaEnumMetaDataDto>` |
| `pages` | `java.util.List<com.seeyon.boot.starter.extmetadata.dto.UdcPageMetadataV2Dto>` |
| `functionNodes` | `java.util.List<com.seeyon.boot.starter.extmetadata.dto.UdcMenuWithPageMetaDataDto>` |

## `PartUploadInfoDto`（6 字段）

`com.seeyon.boot.starter.file.dto.response.PartUploadInfoDto`

被这些方法当入参：

- `StorageService.partUpload()`（裸参数）
- `StorageService.partUploadEnd()`（裸参数）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `partUploadId` | `java.lang.String` |
| `bucketName` | `java.lang.String` |
| `storageKey` | `java.lang.String` |
| `time` | `java.lang.Long` |
| `partNumber` | `java.lang.Integer` |

## `GraphqlProxyRequestDto`（6 字段）

`com.seeyon.boot.starter.udcrt.dto.GraphqlProxyRequestDto`

被这些方法当入参：

- `GraphqlProxyAppService.doGraphQL()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `appName` | `java.lang.String` |
| `appType` | `com.seeyon.udc.common.enums.ApplicationSourceEnum` |
| `query` | `java.lang.String` |
| `operationName` | `java.lang.String` |
| `variables` | `java.util.Map<java.lang.String, java.lang.Object>` |

## `CustomPlanSearchDto`（5 字段）

`com.seeyon.boot.starter.customplan.dto.CustomPlanSearchDto`

被这些方法当入参：

- `CustomPlanAppService.selectByComplexCondition()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `sourceId` | `java.lang.String` |
| `appName` | `java.lang.String` |
| `pageID` | `java.lang.Long` |
| `pageGuId` | `java.lang.Long` |

## `AppServiceAsyncInvokeDto`（5 字段）

`com.seeyon.boot.starter.dubbo.dto.AppServiceAsyncInvokeDto`

被这些方法当入参：

- `ParamEscapeService.saveApiLog()`（裸参数）

| 字段 | 类型 |
|---|---|
| `notifyDubboGroup` | `java.lang.String` |
| `notifyDubboVersion` | `java.lang.String` |
| `paramConvertId` | `java.lang.Long` |
| `callBackUrl` | `java.lang.String` |
| `extendParams` | `java.util.Map<java.lang.String, java.lang.Object>` |

## `ExcelImportTransDto`（5 字段）

`com.seeyon.boot.starter.excel.dto.biz.ExcelImportTransDto`

被这些方法当入参：

- `UdcEnumItemAppService.importExcel()`（包装入参）
- `DataTransferService.importEntityInitData()`（裸参数）

| 字段 | 类型 |
|---|---|
| `entityFullName` | `java.lang.String` |
| `uniqueFieldMap` | `java.util.Map<java.lang.String, java.util.List<java.lang.String>>` |
| `dataList` | `java.util.List<java.lang.Object>` |
| `fileStorageKey` | `java.lang.String` |
| `map` | `java.util.Map<java.lang.String, java.lang.Object>` |

## `UdcDtoMetadataDto`（5 字段）

`com.seeyon.boot.starter.extmetadata.dto.UdcDtoMetadataDto`

被这些方法当入参：

- `DataFlowCodeService.deployManuallyMappingCustomDto()`（裸参数）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `type` | `java.lang.String` |
| `entity` | `java.lang.String` |
| `caption` | `java.lang.String` |
| `properties` | `java.util.Map<java.lang.String, com.seeyon.boot.starter.extmetadata.dto.UdcDtoAttributeMetadataDto>` |

## `UdcJavaEnumMetaDataSearchDto`（5 字段）

`com.seeyon.boot.starter.extmetadata.dto.request.UdcJavaEnumMetaDataSearchDto`

被这些方法当入参：

- `UdcMetaDataAppService.selectJavaEnumMetaDataList()`（包装入参）
- `UdcMetaDataAppService.selectJavaEnumItemMetaDataList()`（包装入参）

| 字段 | 类型 |
|---|---|
| `appId` | `java.lang.Long` |
| `containsDepApp` | `boolean` |
| `id` | `java.lang.Long` |
| `enumId` | `java.lang.Long` |
| `excludeNone` | `boolean` |

## `UdcPageInfoSearchV2Dto`（5 字段）

`com.seeyon.boot.starter.extmetadata.dto.request.UdcPageInfoSearchV2Dto`

被这些方法当入参：

- `UdcMetaDataAppService.selectPageSchema4Bpm()`（裸参数）

| 字段 | 类型 |
|---|---|
| `fullName` | `java.lang.String` |
| `pageId` | `java.lang.Long` |
| `pageUrl` | `java.lang.String` |
| `urlType` | `java.lang.String` |
| `pageGuid` | `java.lang.Long` |

## `UdcReferMetaDataSearchDto`（5 字段）

`com.seeyon.boot.starter.extmetadata.dto.request.UdcReferMetaDataSearchDto`

被这些方法当入参：

- `UdcMetaDataAppService.selectReferMetaDataByEntity()`（包装入参）
- `UdcMetaDataAppService.selectReferAndAppMetadataByEntity()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `entityId` | `java.lang.Long` |
| `entityFullName` | `java.lang.String` |
| `referFullName` | `java.lang.String` |
| `terminalType` | `java.lang.String` |

## `PartUploadRequestDto`（5 字段）

`com.seeyon.boot.starter.file.dto.request.PartUploadRequestDto`

被这些方法当入参：

- `StorageService.partUpload()`（裸参数）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `partUploadId` | `java.lang.String` |
| `partSize` | `java.lang.Integer` |
| `partNumber` | `java.lang.Integer` |
| `part` | `org.springframework.web.multipart.MultipartFile` |

## `OpinionSearchRequestDto`（5 字段）

`com.seeyon.boot.starter.opinion.dto.biz.OpinionSearchRequestDto`

被这些方法当入参：

- `OpinionService.searchOpinionNoPage()`（裸参数）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `objectId` | `java.lang.Long` |
| `objectIds` | `java.util.List<java.lang.Long>` |
| `opinionTypeList` | `java.util.List<com.seeyon.boot.starter.opinion.enums.OpinionTypeEnum>` |
| `sort` | `com.seeyon.boot.transport.Sort` |

## `CtpTenantShardingDto`（5 字段）

`com.seeyon.boot.starter.sharding.dto.CtpTenantShardingDto`

被这些方法当入参：

- `ShardingAppServiceInterface.createTenantSharding()`（包装入参）
- `ShardingAppServiceInterface.batchCreateTenantSharding()`（裸参数）
- `ShardingAppServiceInterface.updateTenantSharding()`（包装入参）

| 字段 | 类型 |
|---|---|
| `id` | `java.lang.Long` |
| `useTenantId` | `java.lang.Long` |
| `dataStorageType` | `com.seeyon.boot.starter.sharding.enums.DataStorageType` |
| `resourceId` | `java.lang.Long` |
| `updateTime` | `java.util.Date` |

## `FormLoadParamDto`（5 字段）

`com.seeyon.boot.starter.udcrt.dto.FormLoadParamDto`

被这些方法当入参：

- `FormAppService.loadForm()`（包装入参）

| 字段 | 类型 |
|---|---|
| `guid` | `java.lang.Long` |
| `hostAppName` | `java.lang.String` |
| `groupId` | `java.lang.String` |
| `artifactId` | `java.lang.String` |
| `jarVersion` | `java.lang.String` |

## `InspectionItemDto`（4 字段）

`com.seeyon.boot.inspection.dto.InspectionItemDto`

被这些方法当入参：

- `Inspection.sortInspectionItems()`（裸参数）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `sort` | `int` |
| `name` | `java.lang.String` |
| `caption` | `java.lang.String` |

## `ComponentCheckDto`（4 字段）

`com.seeyon.boot.security.dto.ComponentCheckDto`

被这些方法当入参：

- `ComponentSecurityCheck.check()`（裸参数）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `name` | `java.lang.String` |
| `userId` | `java.lang.Long` |
| `userRoles` | `java.util.Set<java.lang.String>` |

## `SingleConditionDto`（4 字段）

`com.seeyon.boot.starter.condition.dto.SingleConditionDto`

被这些方法当入参：

- `MapOperatorParse.parseOperator()`（裸参数）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `leftParam` | `com.seeyon.boot.starter.condition.dto.SingleConditionDto$LeftParamDto` |
| `operator` | `com.seeyon.boot.starter.condition.dto.SingleConditionDto$ConditionOperatorDto` |
| `rightParams` | `java.util.List<com.seeyon.boot.starter.condition.dto.SingleConditionDto$RightParamDto>` |

## `DataFlowRtMappingSaveDto`（4 字段）

`com.seeyon.boot.starter.dataflow.dto.DataFlowRtMappingSaveDto`

被这些方法当入参：

- `DataFlowMappingAppService.update()`（包装入参）

| 字段 | 类型 |
|---|---|
| `id` | `java.lang.Long` |
| `caption` | `java.lang.String` |
| `sourceHandleType` | `com.seeyon.boot.starter.dataflow.enums.SourceHandleTypeEnum` |
| `mappingArea` | `java.util.List<com.seeyon.udc.common.dto.DataFlowMappingAreaDto>` |

## `OriginalDataFlowMappingListQueryDto`（4 字段）

`com.seeyon.boot.starter.dataflow.dto.OriginalDataFlowMappingListQueryDto`

被这些方法当入参：

- `DataFlowMappingAppService.selectOriginalMappingList()`（包装入参）

| 字段 | 类型 |
|---|---|
| `dataFlowId` | `java.lang.Long` |
| `sourceEntityId` | `java.lang.Long` |
| `targetEntityId` | `java.lang.Long` |
| `caption` | `java.lang.String` |

## `AppServiceReliableInvokeDto`（4 字段）

`com.seeyon.boot.starter.dubbo.dto.AppServiceReliableInvokeDto`

被这些方法当入参：

- `AppServiceProxy.reliableInvokeAppService()`（裸参数）

| 字段 | 类型 |
|---|---|
| `interfaceName` | `java.lang.String` |
| `methodName` | `java.lang.String` |
| `paramType` | `java.lang.String` |
| `param` | `T` |

## `UdcPageLayoutSearchDto`（4 字段）

`com.seeyon.boot.starter.extmetadata.dto.UdcPageLayoutSearchDto`

被这些方法当入参：

- `UdcMetaDataAppService.selectPageLayoutMetaData()`（包装入参）
- `UdcMetaDataAppService.selectAllPageLayoutMetaDataByApp()`（裸参数）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `id` | `java.lang.Long` |
| `appName` | `java.lang.String` |
| `fullName` | `java.lang.String` |

## `BundleChangeMessageDto`（4 字段）

`com.seeyon.boot.starter.i18n.dto.BundleChangeMessageDto`

被这些方法当入参：

- `MetadataI18nResourceLoader.clearI18nCache()`（裸参数）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `bundleNameList` | `java.util.List<java.lang.String>` |
| `tenantId` | `long` |
| `traceId` | `java.lang.String` |

## `InformOpinionQueryDto`（4 字段）

`com.seeyon.boot.starter.opinion.dto.biz.InformOpinionQueryDto`

被这些方法当入参：

- `OpinionService.pageQueryInformOpinion()`（裸参数）

| 字段 | 类型 |
|---|---|
| `pageInfo` | `com.seeyon.boot.transport.PageInfo` |
| `objectId` | `java.lang.Long` |
| `sort` | `com.seeyon.boot.transport.Sort$Direction` |
| `forwardCount` | `java.lang.Integer` |

## `OpinionTransDraftDto`（4 字段）

`com.seeyon.boot.starter.opinion.dto.biz.OpinionTransDraftDto`

被这些方法当入参：

- `OpinionService.transToOpinionDraftByAffairId()`（裸参数）

| 字段 | 类型 |
|---|---|
| `objectId` | `java.lang.Long` |
| `subObjectId` | `java.lang.Long` |
| `affairId` | `java.lang.Long` |
| `createUserId` | `java.lang.Long` |

## `DeductionRtRuleVersionIdQueryDto`（3 字段）

`com.seeyon.boot.starter.deduction.dto.DeductionRtRuleVersionIdQueryDto`

被这些方法当入参：

- `DeductionRtRuleAppService.selectRtRuleVersion()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `sourceEntityId` | `java.lang.Long` |
| `targetEntityId` | `java.lang.Long` |

## `DeductionRtRuleVersionQueryDto`（3 字段）

`com.seeyon.boot.starter.deduction.dto.DeductionRtRuleVersionQueryDto`

被这些方法当入参：

- `DeductionRtRuleAppService.initData()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `sourceEntity` | `com.seeyon.udc.common.dto.EntityInitParam` |
| `targetEntity` | `com.seeyon.udc.common.dto.EntityInitParam` |

## `DesignMetadataRequestDto`（3 字段）

`com.seeyon.boot.starter.excel.dto.DesignMetadataRequestDto`

被这些方法当入参：

- `DesignMetadataQueryApi.selectAggEntityMetadataByFullName()`（包装入参）
- `DesignMetadataQueryApi.selectEntityMetadataByFullName()`（包装入参）
- `DesignMetadataQueryApi.selectDtoMetadataByEntityFullName()`（包装入参）

| 字段 | 类型 |
|---|---|
| `appId` | `java.lang.Long` |
| `appName` | `java.lang.String` |
| `fullName` | `java.lang.String` |

## `ExpressionDefinitionDto`（3 字段）

`com.seeyon.boot.starter.formula.dto.ExpressionDefinitionDto`

被这些方法当入参：

- `ExprConsistencyValidator.validateConsistency()`（裸参数）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `designData` | `com.seeyon.boot.starter.formula.dto.ExpressionDesignDataDto` |
| `runtimeData` | `com.seeyon.boot.starter.formula.dto.runtime.ExprParamResult` |

## `TenantResourceRequestDto`（3 字段）

`com.seeyon.boot.starter.i18n.dto.TenantResourceRequestDto`

被这些方法当入参：

- `I18nResourceAppService.getTenantResourceDtoMap()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `tenantId` | `java.lang.Long` |
| `bundleName` | `java.lang.String` |

## `OpinionRequestDto`（3 字段）

`com.seeyon.boot.starter.opinion.dto.biz.OpinionRequestDto`

被这些方法当入参：

- `OpinionService.selectTopReplyListByObjectId()`（裸参数）

| 字段 | 类型 |
|---|---|
| `objectId` | `java.lang.Long` |
| `subObjectId` | `java.lang.Long` |
| `text` | `java.lang.String` |

## `PartDetectionRequestDto`（3 字段）

`com.seeyon.boot.starter.qrcode.dto.validation.PartDetectionRequestDto`

被这些方法当入参：

- `CtpQrCodeRuleUdcAppService.getRuleListByAppIdAndFullNames()`（包装入参）
- `CtpQrCodeRuleUdcAppService.getRuleListByAppIdAndFieldCodes()`（包装入参）

| 字段 | 类型 |
|---|---|
| `appId` | `java.lang.Long` |
| `entityFullNames` | `java.util.List<java.lang.String>` |
| `fieldCodes` | `java.util.List<java.lang.String>` |

## `AppDraftDto`（3 字段）

`com.seeyon.boot.starter.udcrt.dto.AppDraftDto`

被这些方法当入参：

- `AppDraftAppService.createOrUpdate()`（包装入参）

| 字段 | 类型 |
|---|---|
| `dataId` | `java.lang.String` |
| `draftData` | `java.lang.String` |
| `updateTime` | `java.util.Date` |

## `RestRequestProxyDto`（3 字段）

`com.seeyon.boot.starter.udcrt.dto.RestRequestProxyDto`

被这些方法当入参：

- `GraphqlProxyAppService.doRest()`（包装入参）

| 字段 | 类型 |
|---|---|
| `restUrl` | `java.lang.String` |
| `requestMethod` | `java.lang.String` |
| `body` | `java.lang.String` |

## `DataFlowMappingStateUpdateDto`（2 字段）

`com.seeyon.boot.starter.dataflow.dto.DataFlowMappingStateUpdateDto`

被这些方法当入参：

- `DataFlowMappingAppService.updateMappingState()`（包装入参）

| 字段 | 类型 |
|---|---|
| `id` | `java.lang.Long` |
| `state` | `com.seeyon.udc.common.enums.UsageStateEnum` |

## `DataFlowRtMapQueryDto`（2 字段）

`com.seeyon.boot.starter.dataflow.dto.DataFlowRtMapQueryDto`

被这些方法当入参：

- `DataFlowMapAppService.selectByCondition()`（包装入参）

| 字段 | 类型 |
|---|---|
| `appId` | `java.lang.Long` |
| `caption` | `java.lang.String` |

## `CommandCallbackDto`（2 字段）

`com.seeyon.boot.starter.dubbo.dto.CommandCallbackDto`

被这些方法当入参：

- `AppServiceProxyCallback.callback()`（包装入参）

| 字段 | 类型 |
|---|---|
| `result` | `java.lang.String` |
| `callBackUrl` | `java.lang.String` |

## `UdcGeneralMetaDataSearchDto`（2 字段）

`com.seeyon.boot.starter.extmetadata.dto.request.UdcGeneralMetaDataSearchDto`

被这些方法当入参：

- `UdcMetaDataAppService.selectCtpEnumMetaDataListData()`（包装入参）
- `UdcMetaDataAppService.selectCtpEnumMetaDataListData1()`（包装入参）
- `UdcMetaDataAppService.selectCtpEnumItemList()`（包装入参）

| 字段 | 类型 |
|---|---|
| `id` | `java.lang.Long` |
| `fullName` | `java.lang.String` |

## `BaseTraceableDto`（2 字段）

`com.seeyon.boot.transport.BaseTraceableDto`

被这些方法当入参：

- `ConsistenceDetectionAppService.updateDetection4Dto()`（裸参数）
- `ConsistenceDetectionAppService.deleteDetection()`（裸参数）
- `PartDetectionTask.setSourceDeleteIdDtoMap()`（裸参数）
- `PartDetectionTask.setSourceUpdateIdDtoMap()`（裸参数）

| 字段 | 类型 |
|---|---|
| `id` | `java.lang.Long` |
| `guid` | `java.lang.Long` |

## `UdcCtpEnumMetaDataSearchDto`（1 字段）

`com.seeyon.boot.starter.extmetadata.dto.request.UdcCtpEnumMetaDataSearchDto`

被这些方法当入参：

- `UdcMetaDataAppService.selectParentEnumByCode()`（包装入参）

| 字段 | 类型 |
|---|---|
| `code` | `java.lang.String` |

## `UdcSimpleEntityMetaDataSearchDto`（1 字段）

`com.seeyon.boot.starter.extmetadata.dto.request.UdcSimpleEntityMetaDataSearchDto`

被这些方法当入参：

- `UdcMetaDataAppService.selectSimpleAggEntityMetaDataByAppName()`（包装入参）

| 字段 | 类型 |
|---|---|
| `containsChildEntity` | `boolean` |

## `DataValidCreateFilterDto`（1 字段）

`com.seeyon.boot.starter.udcrt.dto.DataValidCreateFilterDto`

被这些方法当入参：

- `UdcBpmProcessService.validCreateFilterData()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |

## `DataValidUpdateFilterDto`（1 字段）

`com.seeyon.boot.starter.udcrt.dto.DataValidUpdateFilterDto`

被这些方法当入参：

- `UdcBpmProcessService.validUpdateFilterData()`（包装入参）
- `UdcBpmProcessService.validFilterData()`（包装入参）
- `UdcBpmProcessService.updateData()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |

## `BaseDto`（1 字段）

`com.seeyon.boot.transport.BaseDto`

被这些方法当入参：

- `LimitCountCheck.check()`（裸参数）
- `LimitCountCheck.condition()`（裸参数）

| 字段 | 类型 |
|---|---|
| `validate` | `boolean` |

## `Sort`（1 字段）

`com.seeyon.boot.transport.Sort`

被这些方法当入参：

- `AffairSuperviseAppService.selectPageByFixedTemplate()`（包装入参）
- `EventWithDataAppService.selectListWithDataByTerm()`（包装入参）
- `UdcEnumAppService.selectListByTerm()`（包装入参）
- `UdcEnumItemAppService.selectListByTerm()`（包装入参）

| 字段 | 类型 |
|---|---|
| `orders` | `java.util.List<com.seeyon.boot.transport.Sort$Order>` |
