# 组织架构：入参 DTO 字段表

> 自动生成。包前缀 `com.seeyon.organization`。共 102 个 DTO。
> 字段类型逐字来自 javap；`static` 前缀表示常量而非实例字段。

## `OrgMemberPostDto`（43 字段）

`com.seeyon.organization.dto.core.OrgMemberPostDto`

被这些方法当入参：

- `OrgMemberPostBaseAppService.create()`（包装入参）
- `OrgMemberPostBaseAppService.update()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `id` | `java.lang.Long` |
| `businessId` | `java.lang.Long` |
| `businessName` | `java.lang.String` |
| `memberId` | `java.lang.Long` |
| `memberName` | `java.lang.String` |
| `memberCode` | `java.lang.String` |
| `main` | `java.lang.Boolean` |
| `orgId` | `java.lang.Long` |
| `orgName` | `java.lang.String` |
| `orgShortName` | `java.lang.String` |
| `orgCode` | `java.lang.String` |
| `fullName` | `java.lang.String` |
| `path` | `java.lang.String` |
| `institutionId` | `java.lang.Long` |
| `institutionName` | `java.lang.String` |
| `institutionShortName` | `java.lang.String` |
| `institutionCode` | `java.lang.String` |
| `postId` | `java.lang.Long` |
| `postName` | `java.lang.String` |
| `postCode` | `java.lang.String` |
| `levelId` | `java.lang.Long` |
| `levelName` | `java.lang.String` |
| `levelCode` | `java.lang.String` |
| `jobId` | `java.lang.Long` |
| `jobName` | `java.lang.String` |
| `jobCode` | `java.lang.String` |
| `effectiveTime` | `java.util.Date` |
| `invalidTime` | `java.util.Date` |
| `sortId` | `java.lang.Integer` |
| `topSortId` | `java.lang.Integer` |
| `sortNumber` | `java.math.BigDecimal` |
| `orgSortNumber` | `java.math.BigDecimal` |
| `isEnable` | `java.lang.Boolean` |
| `effective` | `java.lang.Boolean` |
| `edit` | `java.lang.Boolean` |
| `createTime` | `java.util.Date` |
| `updateTime` | `java.util.Date` |
| `type` | `com.seeyon.organization.enums.core.UserTypeEnum` |
| `memberType` | `com.seeyon.organization.enums.core.MemberTypeEnum` |
| `outsideInstitutionId` | `java.lang.Long` |
| `dataSignSuccess` | `java.lang.Integer` |
| `thirdId` | `java.lang.String` |

## `OrgCreateMemberBaseDto`（26 字段）

`com.seeyon.organization.dto.core.base.OrgCreateMemberBaseDto`

被这些方法当入参：

- `OrgMemberBaseAppService.create()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `id` | `java.lang.Long` |
| `name` | `java.lang.String` |
| `code` | `java.lang.String` |
| `gender` | `com.seeyon.organization.enums.core.MemberGenderEnum` |
| `birthday` | `java.util.Date` |
| `phoneNumber` | `java.lang.String` |
| `officeNumber` | `java.lang.String` |
| `email` | `java.lang.String` |
| `certificateType` | `java.lang.Long` |
| `certificateNumber` | `java.lang.String` |
| `entryDate` | `java.util.Date` |
| `bankAccount` | `java.lang.String` |
| `bank` | `java.lang.String` |
| `bankOutlets` | `java.lang.String` |
| `effectiveTime` | `java.util.Date` |
| `invalidTime` | `java.util.Date` |
| `sortId` | `java.lang.Integer` |
| `sortNumber` | `java.math.BigDecimal` |
| `isEnable` | `java.lang.Boolean` |
| `description` | `java.lang.String` |
| `memberType` | `com.seeyon.organization.enums.core.MemberTypeEnum` |
| `memberPostList` | `java.util.List<com.seeyon.organization.dto.core.OrgMemberPostDto>` |
| `metadataList` | `com.seeyon.organization.dto.core.OrgMemberMetadataDto` |
| `username` | `java.lang.String` |
| `secretName` | `java.lang.String` |

## `OrgUpdateMemberBaseDto`（26 字段）

`com.seeyon.organization.dto.core.base.OrgUpdateMemberBaseDto`

被这些方法当入参：

- `OrgMemberBaseAppService.update()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `id` | `java.lang.Long` |
| `name` | `java.lang.String` |
| `code` | `java.lang.String` |
| `gender` | `com.seeyon.organization.enums.core.MemberGenderEnum` |
| `birthday` | `java.util.Date` |
| `phoneNumber` | `java.lang.String` |
| `officeNumber` | `java.lang.String` |
| `email` | `java.lang.String` |
| `certificateType` | `java.lang.Long` |
| `certificateNumber` | `java.lang.String` |
| `entryDate` | `java.util.Date` |
| `bankAccount` | `java.lang.String` |
| `bank` | `java.lang.String` |
| `bankOutlets` | `java.lang.String` |
| `effectiveTime` | `java.util.Date` |
| `invalidTime` | `java.util.Date` |
| `sortId` | `java.lang.Integer` |
| `sortNumber` | `java.math.BigDecimal` |
| `isEnable` | `java.lang.Boolean` |
| `description` | `java.lang.String` |
| `memberType` | `com.seeyon.organization.enums.core.MemberTypeEnum` |
| `memberPostList` | `java.util.List<com.seeyon.organization.dto.core.OrgMemberPostDto>` |
| `metadataList` | `com.seeyon.organization.dto.core.OrgMemberMetadataDto` |
| `username` | `java.lang.String` |
| `secretName` | `java.lang.String` |

## `OrgCreateUnitBaseDto`（20 字段）

`com.seeyon.organization.dto.core.base.OrgCreateUnitBaseDto`

被这些方法当入参：

- `OrgUnitBaseAppService.create()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `id` | `java.lang.Long` |
| `name` | `java.lang.String` |
| `shortName` | `java.lang.String` |
| `logo` | `java.lang.String` |
| `code` | `java.lang.String` |
| `type` | `com.seeyon.organization.enums.core.UnitTypeEnum` |
| `parentId` | `java.lang.Long` |
| `address` | `java.lang.String` |
| `officeNumber` | `java.lang.String` |
| `tax` | `java.lang.String` |
| `bankAccount` | `java.lang.String` |
| `bank` | `java.lang.String` |
| `functionType` | `java.lang.Long` |
| `effectiveTime` | `java.util.Date` |
| `invalidTime` | `java.util.Date` |
| `sortId` | `java.lang.Integer` |
| `isEnable` | `java.lang.Boolean` |
| `description` | `java.lang.String` |
| `metadataList` | `com.seeyon.organization.dto.core.response.OrgUnitMetadataDto` |

## `OrgUpdateUnitBaseDto`（20 字段）

`com.seeyon.organization.dto.core.base.OrgUpdateUnitBaseDto`

被这些方法当入参：

- `OrgUnitBaseAppService.update()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `id` | `java.lang.Long` |
| `name` | `java.lang.String` |
| `shortName` | `java.lang.String` |
| `logo` | `java.lang.String` |
| `code` | `java.lang.String` |
| `type` | `com.seeyon.organization.enums.core.UnitTypeEnum` |
| `parentId` | `java.lang.Long` |
| `address` | `java.lang.String` |
| `officeNumber` | `java.lang.String` |
| `tax` | `java.lang.String` |
| `bankAccount` | `java.lang.String` |
| `bank` | `java.lang.String` |
| `functionType` | `java.lang.Long` |
| `effectiveTime` | `java.util.Date` |
| `invalidTime` | `java.util.Date` |
| `sortId` | `java.lang.Integer` |
| `isEnable` | `java.lang.Boolean` |
| `description` | `java.lang.String` |
| `metadataList` | `com.seeyon.organization.dto.core.response.OrgUnitMetadataDto` |

## `OrgPostRequestDto`（18 字段）

`com.seeyon.organization.dto.core.request.OrgPostRequestDto`

被这些方法当入参：

- `OrgPostBaseAppService.create()`（包装入参）
- `OrgPostBaseAppService.update()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `id` | `java.lang.Long` |
| `name` | `java.lang.String` |
| `code` | `java.lang.String` |
| `type` | `java.lang.Long` |
| `orgId` | `java.lang.Long` |
| `businessId` | `java.lang.Long` |
| `category` | `com.seeyon.organization.enums.core.CategoryEnum` |
| `issuedRule` | `com.seeyon.organization.enums.core.ScopeTypeEnum` |
| `sortId` | `java.lang.Integer` |
| `isEnable` | `java.lang.Boolean` |
| `description` | `java.lang.String` |
| `line` | `java.lang.Integer` |
| `isAutoCoding` | `java.lang.Boolean` |
| `orgScope` | `java.lang.String` |
| `thirdId` | `java.lang.String` |
| `secretName` | `java.lang.String` |
| `secretN` | `java.lang.Integer` |

## `WorkFlowMatchRequestDto`（15 字段）

`com.seeyon.organization.dto.api.app.workflow.WorkFlowMatchRequestDto`

被这些方法当入参：

- `OrgWorkFlowAppService.selectMemberPostBySelectPeople()`（包装入参）
- `OrgWorkFlowAppService.selectMemberPostBySelectPeoples()`（裸参数）
- `OrgWorkFlowAppService.selectSplitUnitNodeInfo()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `selectPeopleDataWfDto` | `com.seeyon.organization.dto.api.app.workflow.SelectPeopleDataWfDto` |
| `preMemberPostIds` | `java.util.List<java.lang.Long>` |
| `preNodeInfo` | `java.util.List<com.seeyon.organization.dto.api.app.workflow.WorkFlowPreNodeInfoDto>` |
| `nodeType` | `com.seeyon.organization.enums.core.OrgEntityTypeEnum` |
| `nodeId` | `java.lang.Long` |
| `preEntityIds` | `java.util.Map<java.lang.String, java.lang.String>` |
| `sortEntityField` | `java.lang.String` |
| `sortTypeEnum` | `com.seeyon.organization.enums.workflow.SortTypeEnum` |
| `workFlowOfUpEnum` | `com.seeyon.organization.enums.workflow.WorkFlowOfUpEnum` |
| `preMemberPostTypeEnum` | `com.seeyon.organization.enums.workflow.PreMemberPostTypeEnum` |
| `ofUpTypeEnum` | `com.seeyon.organization.enums.workflow.OfUpTypeEnum` |
| `skipMemberId` | `java.lang.Long` |
| `secretLevelId` | `java.lang.Long` |
| `sortBySelf` | `java.lang.Boolean` |

## `OrgJobRequestDto`（15 字段）

`com.seeyon.organization.dto.core.request.OrgJobRequestDto`

被这些方法当入参：

- `OrgJobBaseAppService.create()`（包装入参）
- `OrgJobBaseAppService.update()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `id` | `java.lang.Long` |
| `name` | `java.lang.String` |
| `code` | `java.lang.String` |
| `orgId` | `java.lang.Long` |
| `businessId` | `java.lang.Long` |
| `category` | `com.seeyon.organization.enums.core.CategoryEnum` |
| `issuedRule` | `com.seeyon.organization.enums.core.ScopeTypeEnum` |
| `sortId` | `java.lang.Integer` |
| `isEnable` | `java.lang.Boolean` |
| `description` | `java.lang.String` |
| `isAutoCoding` | `java.lang.Boolean` |
| `line` | `java.lang.Integer` |
| `orgScope` | `java.lang.String` |
| `thirdId` | `java.lang.String` |

## `SelectPeopleDataDto`（14 字段）

`com.seeyon.organization.dto.common.SelectPeopleDataDto`

被这些方法当入参：

- `OrgWorkFlowAppService.getEntityNameBySelectPeoples()`（裸参数）
- `OrgWorkFlowAppService.selectPeopleCodeDataDto()`（裸参数）
- `OrgWorkFlowAppService.checkSelectPeopleData()`（裸参数）
- `OrgCommonAppService.selectMemberBySelectPeopleData()`（裸参数）
- `OrgCommonAppService.selectPageMemberBySelectPeopleData()`（裸参数）
- `OrgCommonAppService.selectPageMemberBySelectPeopleIdData()`（裸参数）
- … 另 1 处

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `t` | `java.lang.String` |
| `i` | `java.lang.String` |
| `n` | `java.lang.String` |
| `o` | `java.lang.Long` |
| `p` | `java.lang.Long` |
| `ii` | `java.lang.Long` |
| `mp` | `java.lang.Long` |
| `m` | `java.lang.Boolean` |
| `c` | `java.lang.Boolean` |
| `ct` | `java.util.List<com.seeyon.organization.enums.core.IncludeChildTypeEnum>` |
| `st` | `java.lang.String` |
| `si` | `java.lang.String` |
| `sn` | `java.lang.String` |

## `OrgUnitTeamDto`（13 字段）

`com.seeyon.organization.dto.core.request.OrgUnitTeamDto`

被这些方法当入参：

- `OrgUnitTeamCoreAppService.create()`（包装入参）
- `OrgUnitTeamCoreAppService.update()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `id` | `java.lang.Long` |
| `name` | `java.lang.String` |
| `orgId` | `java.lang.Long` |
| `isEnable` | `java.lang.Boolean` |
| `member` | `java.lang.String` |
| `memberName` | `java.lang.String` |
| `memberList` | `java.util.List<java.util.Map<java.lang.Long, java.lang.String>>` |
| `sortId` | `java.lang.Integer` |
| `description` | `java.lang.String` |
| `publicScope` | `java.lang.String` |
| `publicScopeName` | `java.lang.String` |
| `type` | `com.seeyon.organization.enums.core.OrgEntityTypeEnum` |

## `OrgTeamDataDto`（12 字段）

`com.seeyon.organization.dto.sync.OrgTeamDataDto`

被这些方法当入参：

- `OrgTeamSyncAppService.create()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `id` | `java.lang.Long` |
| `name` | `java.lang.String` |
| `code` | `java.lang.String` |
| `type` | `com.seeyon.organization.enums.team.TeamTypeEnum` |
| `isEnable` | `java.lang.Boolean` |
| `isPublic` | `java.lang.Boolean` |
| `orgCode` | `java.lang.String` |
| `members` | `java.util.List<com.seeyon.organization.dto.sync.OrgTeamMemberDataDto>` |
| `managerCodes` | `java.util.List<java.lang.String>` |
| `sortId` | `java.lang.Integer` |
| `description` | `java.lang.String` |

## `OrgRoleBaseDto`（11 字段）

`com.seeyon.organization.dto.core.base.OrgRoleBaseDto`

被这些方法当入参：

- `OrgRoleBaseAppService.createOrUpdateBatch()`（裸参数）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `id` | `java.lang.Long` |
| `name` | `java.lang.String` |
| `code` | `java.lang.String` |
| `type` | `java.lang.Long` |
| `sortId` | `java.lang.Integer` |
| `isEnable` | `java.lang.Boolean` |
| `orgType` | `java.lang.String` |
| `scopeType` | `com.seeyon.organization.enums.core.OrgRoleScopeEnum` |
| `specifyOrgIds` | `java.lang.String` |
| `description` | `java.lang.String` |

## `OrgLevelRequestDto`（11 字段）

`com.seeyon.organization.dto.core.request.OrgLevelRequestDto`

被这些方法当入参：

- `OrgLevelBaseAppService.create()`（包装入参）
- `OrgLevelBaseAppService.update()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `id` | `java.lang.Long` |
| `name` | `java.lang.String` |
| `code` | `java.lang.String` |
| `businessId` | `java.lang.Long` |
| `levelSort` | `java.lang.Integer` |
| `isEnable` | `java.lang.Boolean` |
| `description` | `java.lang.String` |
| `isAutoCoding` | `java.lang.Boolean` |
| `line` | `java.lang.Integer` |
| `thirdId` | `java.lang.String` |

## `SearchMemberApiDto`（10 字段）

`com.seeyon.organization.dto.sync.search.SearchMemberApiDto`

被这些方法当入参：

- `OrgMemberSyncAppService.selectByCondition()`（裸参数）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `code` | `java.lang.String` |
| `includeChild` | `java.lang.Boolean` |
| `effectiveTime` | `java.lang.String` |
| `startTime` | `java.lang.String` |
| `endTime` | `java.lang.String` |
| `includeDisable` | `java.lang.Boolean` |
| `memberType` | `com.seeyon.organization.enums.core.MemberTypeEnum` |
| `thirdId` | `java.lang.String` |
| `useThirdId` | `java.lang.Boolean` |

## `SelectPeopleDataWfDto`（9 字段）

`com.seeyon.organization.dto.api.app.workflow.SelectPeopleDataWfDto`

被这些方法当入参：

- `OrgWorkFlowAppService.isOfUp()`（包装入参）
- `OrgWorkFlowAppService.selectOfUp()`（包装入参）
- `OrgWorkFlowAppService.selectPreParameterKey()`（裸参数）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `t` | `java.lang.String` |
| `i` | `java.lang.String` |
| `o` | `java.lang.Long` |
| `p` | `java.lang.Long` |
| `c` | `java.lang.Boolean` |
| `ct` | `java.util.List<com.seeyon.organization.enums.core.IncludeChildTypeEnum>` |
| `st` | `java.lang.String` |
| `si` | `java.lang.String` |

## `WorkFlowSplitMemberNodeRequestDto`（9 字段）

`com.seeyon.organization.dto.api.app.workflow.WorkFlowSplitMemberNodeRequestDto`

被这些方法当入参：

- `OrgWorkFlowAppService.selectSplitMemberNodeInfo()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `formula` | `com.seeyon.organization.dto.api.app.workflow.SelectPeopleDataWfDto` |
| `condition` | `java.util.List<com.seeyon.organization.dto.api.app.workflow.SelectPeopleDataWfDto>` |
| `preMemberPostIds` | `java.util.List<java.lang.Long>` |
| `preNodeInfo` | `java.util.List<com.seeyon.organization.dto.api.app.workflow.WorkFlowPreNodeInfoDto>` |
| `nodeType` | `com.seeyon.organization.enums.core.OrgEntityTypeEnum` |
| `nodeId` | `java.lang.Long` |
| `preEntityIds` | `java.util.Map<java.lang.String, java.lang.String>` |
| `maxOfUp` | `java.lang.Integer` |

## `OrgUnitMetadataRequestDto`（9 字段）

`com.seeyon.organization.dto.core.request.OrgUnitMetadataRequestDto`

被这些方法当入参：

- `OrgMetadataCoreAppService.selectUnitMetadataPageList()`（裸参数）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `orgId` | `java.lang.Long` |
| `businessId` | `java.lang.Long` |
| `leCreateTime` | `java.util.Date` |
| `geCreateTime` | `java.util.Date` |
| `leUpdateTime` | `java.util.Date` |
| `geUpdateTime` | `java.util.Date` |
| `properties` | `java.lang.String[]` |
| `showAllProperties` | `java.lang.Boolean` |

## `SearchMemberListApiDto`（9 字段）

`com.seeyon.organization.dto.sync.search.SearchMemberListApiDto`

被这些方法当入参：

- `OrgMemberSyncAppService.selectNaturalMemberInfoPageListByCondition()`（裸参数）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `name` | `java.lang.String` |
| `phoneNumber` | `java.lang.String` |
| `certificateNumber` | `java.lang.String` |
| `email` | `java.lang.String` |
| `code` | `java.lang.String` |
| `startTime` | `java.lang.String` |
| `endTime` | `java.lang.String` |
| `isEnable` | `java.lang.Boolean` |

## `SearchPostListApiDto`（9 字段）

`com.seeyon.organization.dto.sync.search.SearchPostListApiDto`

被这些方法当入参：

- `OrgJobSyncAppService.selectPageByConditions()`（裸参数）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `name` | `java.lang.String` |
| `codes` | `java.util.List<java.lang.String>` |
| `orgCode` | `java.lang.String` |
| `isEnable` | `java.lang.Boolean` |
| `category` | `com.seeyon.organization.enums.core.CategoryEnum` |
| `useThirdId` | `java.lang.Boolean` |
| `thirdIds` | `java.util.List<java.lang.String>` |
| `orgThirdId` | `java.lang.String` |

## `SearchUnitListApiDto`（9 字段）

`com.seeyon.organization.dto.sync.search.SearchUnitListApiDto`

被这些方法当入参：

- `OrgUnitSyncAppService.selectPageByConditions()`（裸参数）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `name` | `java.lang.String` |
| `code` | `java.lang.String` |
| `type` | `com.seeyon.organization.enums.core.UnitTypeEnum` |
| `startTime` | `java.lang.String` |
| `endTime` | `java.lang.String` |
| `isEnable` | `java.lang.Boolean` |
| `thirdId` | `java.lang.String` |
| `useThirdId` | `java.lang.Boolean` |

## `OrgMemberMetadataRequestDto`（8 字段）

`com.seeyon.organization.dto.core.request.OrgMemberMetadataRequestDto`

被这些方法当入参：

- `OrgMetadataCoreAppService.selectMemberMetadataPageList()`（裸参数）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `memberId` | `java.lang.Long` |
| `leCreateTime` | `java.util.Date` |
| `geCreateTime` | `java.util.Date` |
| `leUpdateTime` | `java.util.Date` |
| `geUpdateTime` | `java.util.Date` |
| `properties` | `java.lang.String[]` |
| `showAllProperties` | `java.lang.Boolean` |

## `SearchUnitDto`（8 字段）

`com.seeyon.organization.dto.selectpeople.SearchUnitDto`

被这些方法当入参：

- `OrgSelectPeopleForInstAppService.selectFirstChildrenUnits()`（包装入参）

| 字段 | 类型 |
|---|---|
| `orgId` | `java.lang.Long` |
| `businessId` | `java.lang.Long` |
| `type` | `com.seeyon.organization.enums.core.UnitTypeEnum` |
| `appointRootIds` | `java.util.List<java.lang.Long>` |
| `appointRootIncludeChildren` | `java.lang.Boolean` |
| `appointRootAppIds` | `java.util.List<java.lang.String>` |
| `extendMap` | `java.util.Map<java.lang.String, java.lang.Object>` |
| `excludeList` | `java.util.List<com.seeyon.organization.dto.common.SelectPeopleDataDto>` |

## `SelectManageOrgDto`（7 字段）

`com.seeyon.organization.dto.common.SelectManageOrgDto`

被这些方法当入参：

- `OrgCommonAppService.selectManageOrgByRole()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `roleCodes` | `java.util.List<java.lang.String>` |
| `parentId` | `java.lang.Long` |
| `userId` | `java.lang.Long` |
| `type` | `java.util.List<com.seeyon.organization.enums.core.UnitTypeEnum>` |
| `name` | `java.lang.String` |
| `searchScope` | `com.seeyon.organization.enums.core.OrgManagerTreeScopeEnum` |

## `SearchByKeyDto`（7 字段）

`com.seeyon.organization.dto.selectpeople.SearchByKeyDto`

被这些方法当入参：

- `OrgSelectPeopleForMemberAppService.searchMemberByGroup()`（包装入参）

| 字段 | 类型 |
|---|---|
| `key` | `java.lang.String` |
| `appointRootIds` | `java.util.List<java.lang.Long>` |
| `appointRootIncludeChildren` | `java.lang.Boolean` |
| `showDisable` | `java.lang.Boolean` |
| `businessId` | `java.lang.Long` |
| `isFront` | `java.lang.Boolean` |
| `appointRootAppIds` | `java.util.List<java.lang.String>` |

## `SearchUnitApiDto`（7 字段）

`com.seeyon.organization.dto.sync.search.SearchUnitApiDto`

被这些方法当入参：

- `OrgUnitSyncAppService.selectChildrenByCondition()`（包装入参）
- `OrgUnitSyncAppService.selectPageChildrenByCondition()`（裸参数）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `code` | `java.lang.String` |
| `firstLayer` | `java.lang.Boolean` |
| `childType` | `com.seeyon.organization.enums.core.UnitTypeEnum` |
| `effectiveTime` | `java.lang.String` |
| `thirdId` | `java.lang.String` |
| `useThirdId` | `java.lang.Boolean` |

## `WorkFlowConditionMatchRequestDto`（6 字段）

`com.seeyon.organization.dto.api.app.workflow.WorkFlowConditionMatchRequestDto`

被这些方法当入参：

- `OrgWorkFlowAppService.selectListByCondition()`（包装入参）

| 字段 | 类型 |
|---|---|
| `selectPeopleDataWfDto` | `com.seeyon.organization.dto.api.app.workflow.SelectPeopleDataWfDto` |
| `preEntityIds` | `java.util.Map<java.lang.String, java.lang.String>` |
| `senderMemberPostId` | `java.lang.Long` |
| `senderMemberInfo` | `java.util.List<com.seeyon.organization.dto.api.app.workflow.WorkFlowPreNodeInfoDto>` |
| `currentMemberPostId` | `java.lang.Long` |
| `currentMemberInfo` | `java.util.List<com.seeyon.organization.dto.api.app.workflow.WorkFlowPreNodeInfoDto>` |

## `SelectMetadataDto`（6 字段）

`com.seeyon.organization.dto.common.SelectMetadataDto`

被这些方法当入参：

- `OrgCommonAppService.selectOrgMetadataColumnList()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `categoryId` | `com.seeyon.organization.enums.core.OrgEntityTypeEnum` |
| `businessId` | `java.lang.Long` |
| `orgId` | `java.lang.Long` |
| `orgType` | `com.seeyon.organization.enums.core.UnitTypeEnum` |
| `dataType` | `java.util.List<com.seeyon.organization.enums.core.OrgMetadataTypeEnum>` |

## `SearchOrgMemberRoleDto`（6 字段）

`com.seeyon.organization.dto.core.base.SearchOrgMemberRoleDto`

被这些方法当入参：

- `OrgMemberRoleBaseAppService.selectListByCondition()`（包装入参）
- `OrgMemberRoleBaseAppService.selectPageByConditions()`（裸参数）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `orgId` | `java.lang.Long` |
| `roleId` | `java.lang.Long` |
| `roleCode` | `java.lang.String` |
| `businessId` | `java.lang.Long` |
| `memberId` | `java.lang.String` |

## `SearchLevelListApiDto`（6 字段）

`com.seeyon.organization.dto.sync.search.SearchLevelListApiDto`

被这些方法当入参：

- `OrgLevelSyncAppService.selectPageByConditions()`（裸参数）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `name` | `java.lang.String` |
| `codes` | `java.util.List<java.lang.String>` |
| `isEnable` | `java.lang.Boolean` |
| `useThirdId` | `java.lang.Boolean` |
| `thirdIds` | `java.util.List<java.lang.String>` |

## `SearchMemberConditionApiDto`（6 字段）

`com.seeyon.organization.dto.sync.search.SearchMemberConditionApiDto`

被这些方法当入参：

- `OrgMemberSyncAppService.selectByCodes()`（包装入参）
- `OrgMemberSyncAppService.selectByThirdIds()`（包装入参）
- `OrgMemberSyncAppService.selectNaturalMemberByCodes()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `codes` | `java.util.List<java.lang.String>` |
| `includeDisable` | `java.lang.Boolean` |
| `effectiveTime` | `java.lang.String` |
| `useThirdId` | `java.lang.Boolean` |
| `thirdIds` | `java.util.List<java.lang.String>` |

## `SearchTeamListApiDto`（6 字段）

`com.seeyon.organization.dto.sync.search.SearchTeamListApiDto`

被这些方法当入参：

- `OrgTeamSyncAppService.selectPageByConditions()`（裸参数）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `name` | `java.lang.String` |
| `ids` | `java.util.List<java.lang.Long>` |
| `codes` | `java.util.List<java.lang.String>` |
| `orgCode` | `java.lang.String` |
| `isEnable` | `java.lang.Boolean` |

## `SelectPeopleCodeDataDto`（5 字段）

`com.seeyon.organization.dto.api.app.workflow.SelectPeopleCodeDataDto`

被这些方法当入参：

- `OrgWorkFlowAppService.selectPeopleIdsDataDtoFromTransData()`（裸参数）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `t` | `java.lang.String` |
| `i` | `java.lang.String` |
| `c` | `java.lang.String` |
| `oc` | `java.lang.String` |

## `WorkFlowDataTestRequestDto`（5 字段）

`com.seeyon.organization.dto.api.app.workflow.WorkFlowDataTestRequestDto`

被这些方法当入参：

- `OrgWorkFlowAppService.getSelectPeopleDataWfJson()`（裸参数）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `type` | `java.lang.String` |
| `name` | `java.lang.String` |
| `enumItemName` | `java.lang.String` |
| `action` | `java.lang.String` |

## `OrgMemberRoleBaseDto`（5 字段）

`com.seeyon.organization.dto.core.base.OrgMemberRoleBaseDto`

被这些方法当入参：

- `OrgMemberRoleBaseAppService.createOrUpdateBatch()`（裸参数）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `orgId` | `java.lang.Long` |
| `roleId` | `java.lang.Long` |
| `businessId` | `java.lang.Long` |
| `memberIds` | `java.lang.String` |

## `SearchOrgRoleDto`（5 字段）

`com.seeyon.organization.dto.core.base.SearchOrgRoleDto`

被这些方法当入参：

- `OrgRoleBaseAppService.selectListByCondition()`（包装入参）
- `OrgRoleBaseAppService.selectPageByConditions()`（裸参数）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `name` | `java.lang.String` |
| `code` | `java.lang.String` |
| `type` | `java.lang.Long` |
| `isEnable` | `java.lang.Boolean` |

## `SearchUnitConditionApiDto`（5 字段）

`com.seeyon.organization.dto.sync.search.SearchUnitConditionApiDto`

被这些方法当入参：

- `OrgUnitSyncAppService.selectByCodes()`（包装入参）
- `OrgUnitSyncAppService.selectByThirdIds()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `codes` | `java.util.List<java.lang.String>` |
| `includeDisable` | `java.lang.Boolean` |
| `effectiveTime` | `java.lang.String` |
| `thirdIds` | `java.util.List<java.lang.String>` |

## `OrgEntityIdCodeDto`（4 字段）

`com.seeyon.organization.dto.api.app.affair.OrgEntityIdCodeDto`

被这些方法当入参：

- `OrgAffairAppService.selectByIdOrCode()`（裸参数）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `id` | `java.lang.Long` |
| `code` | `java.lang.String` |
| `orgEntityType` | `com.seeyon.organization.enums.core.OrgEntityTypeEnum` |

## `SearchSortDto`（4 字段）

`com.seeyon.organization.dto.api.app.edoc.SearchSortDto`

被这些方法当入参：

- `OrgEdocAppService.selectSortByIds()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `orgIds` | `java.util.List<java.lang.Long>` |
| `levelIds` | `java.util.List<java.lang.Long>` |
| `memberIds` | `java.util.List<java.lang.Long>` |

## `SearchOrgDto`（4 字段）

`com.seeyon.organization.dto.api.app.third.zhonghe.SearchOrgDto`

被这些方法当入参：

- `OrgZhongheService.selectOrgByMetadataCustomizeZBBM()`（包装入参）
- `OrgZhongheService.selectOrgListByMetadata()`（包装入参）
- `OrgZhongheService.selectOrgTreeByMetadata()`（包装入参）
- `OrgZhongheService.selectOrgTreeReceiveDept()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `orgId` | `java.lang.Long` |
| `metadataMap` | `java.util.Map<java.lang.String, java.lang.Object>` |
| `orgName` | `java.lang.String` |

## `FunctionOrgRoleInDto`（4 字段）

`com.seeyon.organization.dto.api.app.workflow.FunctionOrgRoleInDto`

被这些方法当入参：

- `OrgWorkFlowAppService.funcOrgRoleIn()`（包装入参）

| 字段 | 类型 |
|---|---|
| `memberId` | `java.lang.Long` |
| `businessId` | `java.lang.Long` |
| `orgId` | `java.lang.Long` |
| `orgRoles` | `java.util.List<java.lang.String>` |

## `SearchNameDto`（4 字段）

`com.seeyon.organization.dto.api.app.workflow.SearchNameDto`

被这些方法当入参：

- `OrgWorkFlowAppService.selectNamesByIds()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `departmentIds` | `java.util.List<java.lang.Long>` |
| `postIds` | `java.util.List<java.lang.Long>` |
| `memberIds` | `java.util.List<java.lang.Long>` |

## `SupervisorMultipleParams`（4 字段）

`com.seeyon.organization.dto.api.app.workflow.SupervisorMultipleParams`

被这些方法当入参：

- `OrgWorkFlowAppService.selectSupervisorMultipleData()`（包装入参）

| 字段 | 类型 |
|---|---|
| `roleCodes` | `java.util.List<java.lang.String>` |
| `orgRoleCodes` | `java.util.List<java.lang.String>` |
| `postIds` | `java.util.List<java.lang.Long>` |
| `publisherAboutParams` | `com.seeyon.organization.dto.api.app.workflow.PublisherAboutParams` |

## `OrgEntitySearchDto`（4 字段）

`com.seeyon.organization.dto.common.OrgEntitySearchDto`

被这些方法当入参：

- `OrgCommonAppService.selectEntityIdByCode()`（裸参数）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `type` | `java.lang.String` |
| `code` | `java.lang.String` |
| `orgCode` | `java.lang.String` |

## `OrgInScopeDataDto`（4 字段）

`com.seeyon.organization.dto.common.OrgInScopeDataDto`

被这些方法当入参：

- `OrgCommonAppService.selectInOrgScopeIds()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `orgIds` | `java.util.List<java.lang.Long>` |
| `businessIds` | `java.util.List<java.lang.Long>` |
| `orgScopeDataMap` | `java.util.Map<java.lang.Long, com.seeyon.organization.dto.common.OrgScopeDataDto>` |

## `SearchUnitTeamDto`（4 字段）

`com.seeyon.organization.dto.common.SearchUnitTeamDto`

被这些方法当入参：

- `OrgCommonAppService.selectOrgUnitTeamList()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `orgId` | `java.lang.Long` |
| `name` | `java.lang.String` |
| `unitIds` | `java.util.List<java.lang.Long>` |

## `SelectScopeTypeNameDto`（4 字段）

`com.seeyon.organization.dto.common.SelectScopeTypeNameDto`

被这些方法当入参：

- `OrgCommonAppService.selectScopeTypeName()`（裸参数）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `selectId` | `java.lang.String` |
| `orgScope` | `java.lang.String` |
| `showOrgType` | `java.lang.Boolean` |

## `SearchMetadataColumnDto`（4 字段）

`com.seeyon.organization.dto.core.SearchMetadataColumnDto`

被这些方法当入参：

- `OrgMetadataCoreAppService.selectMetadataColumnList()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `categoryId` | `com.seeyon.organization.enums.core.OrgEntityTypeEnum` |
| `label` | `java.lang.String` |
| `locale` | `java.lang.String` |

## `OrgBatchUnitDto`（4 字段）

`com.seeyon.organization.dto.sync.OrgBatchUnitDto`

被这些方法当入参：

- `OrgUnitSyncAppService.createBatch()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `units` | `java.util.List<com.seeyon.organization.dto.sync.OrgUnitDataDto>` |
| `syncChildMetadataValue` | `java.lang.Boolean` |
| `useThirdId` | `java.lang.Boolean` |

## `SearchEntityIdByMetadataValueDto`（4 字段）

`com.seeyon.organization.dto.sync.search.SearchEntityIdByMetadataValueDto`

被这些方法当入参：

- `OrgMetadataCoreAppService.selectEntityIdByMetadataValue()`（包装入参）
- `OrgMetadataCoreAppService.selectEntityIdsByMetadataValue()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `type` | `com.seeyon.organization.enums.core.OrgEntityTypeEnum` |
| `metadataCode` | `java.lang.String` |
| `metadataValue` | `java.lang.String` |

## `SearchOrgIdMetadataInfoDto`（4 字段）

`com.seeyon.organization.dto.sync.search.SearchOrgIdMetadataInfoDto`

被这些方法当入参：

- `OrgMetadataCoreAppService.selectOrgIdByMemberIdInInstitution()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `memberId` | `java.lang.Long` |
| `institutionId` | `java.lang.Long` |
| `metadataCode` | `java.util.List<java.lang.String>` |

## `SearchOutSideManagerApiDto`（4 字段）

`com.seeyon.organization.dto.sync.search.SearchOutSideManagerApiDto`

被这些方法当入参：

- `OrgMemberSyncAppService.selectOutSideInstitutionManagerPageByCondition()`（裸参数）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `startTime` | `java.lang.String` |
| `endTime` | `java.lang.String` |
| `outsideInstitutionCode` | `java.lang.String` |

## `FunctionInDto`（3 字段）

`com.seeyon.organization.dto.api.app.workflow.FunctionInDto`

被这些方法当入参：

- `OrgWorkFlowAppService.funcMemberIn()`（包装入参）
- `OrgWorkFlowAppService.funcOrgIn()`（包装入参）
- `OrgWorkFlowAppService.funcMultMemberIn()`（包装入参）
- `OrgWorkFlowAppService.funcMultOrgIn()`（包装入参）

| 字段 | 类型 |
|---|---|
| `param1` | `java.util.List<java.lang.Long>` |
| `param2` | `java.util.List<java.lang.Long>` |
| `param3` | `java.util.List<java.lang.String>` |

## `SelectPeopleTransDataDto`（3 字段）

`com.seeyon.organization.dto.api.app.workflow.SelectPeopleTransDataDto`

被这些方法当入参：

- `OrgWorkFlowAppService.selectPeopleDataDtoFromTransData()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `selectPeopleCodeDataDtos` | `java.util.List<com.seeyon.organization.dto.api.app.workflow.SelectPeopleCodeDataDto>` |
| `selectPeopleDataDtoMap` | `java.util.Map<java.lang.Long, java.util.List<com.seeyon.organization.dto.common.SelectPeopleDataDto>>` |

## `SuperviseConditionDto`（3 字段）

`com.seeyon.organization.dto.api.app.workflow.SuperviseConditionDto`

被这些方法当入参：

- `OrgWorkFlowAppService.selectMemberOfUnitMetadataOfMemberIds()`（裸参数）
- `OrgWorkFlowAppService.selectMemberOfMemberMetadataOfMemberIds()`（裸参数）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `memberId` | `java.lang.Long` |
| `metadataName` | `java.lang.String` |

## `SuperviseMetadataConditionDto`（3 字段）

`com.seeyon.organization.dto.api.app.workflow.SuperviseMetadataConditionDto`

被这些方法当入参：

- `OrgWorkFlowAppService.selectMetadataListOfUnitMetadataOfMemberId()`（包装入参）
- `OrgWorkFlowAppService.selectMetadataListOfMemberMetadataOfMemberId()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `memberId` | `java.lang.Long` |
| `metadataNames` | `java.util.List<java.lang.String>` |

## `WorkFlowConditionMetaMatchRequestDto`（3 字段）

`com.seeyon.organization.dto.api.app.workflow.WorkFlowConditionMetaMatchRequestDto`

被这些方法当入参：

- `OrgWorkFlowAppService.selectListByMetaCondition()`（裸参数）

| 字段 | 类型 |
|---|---|
| `condition` | `java.lang.String` |
| `preEntityIds` | `java.util.Map<java.lang.String, java.util.Map<java.lang.String, java.lang.String>>` |
| `showI18nName` | `java.lang.Boolean` |

## `WorkFlowMatchRequestCustomModeDto`（3 字段）

`com.seeyon.organization.dto.api.app.workflow.WorkFlowMatchRequestCustomModeDto`

被这些方法当入参：

- `OrgWorkFlowAppService.selectMemberPostBySelectPeoplesReturnFile()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `workFlowMatchRequestDtos` | `java.util.Map<java.lang.Long, java.util.List<com.seeyon.organization.dto.api.app.workflow.WorkFlowMatchRequestDto>>` |
| `selectModeEnum` | `com.seeyon.organization.enums.workflow.SelectModeEnum` |

## `WorkFlowSortRequestDto`（3 字段）

`com.seeyon.organization.dto.api.app.workflow.WorkFlowSortRequestDto`

被这些方法当入参：

- `OrgWorkFlowAppService.selectSortField()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `selectPeopleDataWfDto` | `com.seeyon.organization.dto.api.app.workflow.SelectPeopleDataWfDto` |
| `fieldSelectDataSize` | `java.util.Map<java.lang.String, com.seeyon.organization.enums.workflow.FieldSelectDataSizeEnum>` |

## `MemberInSelectPeopleDataDto`（3 字段）

`com.seeyon.organization.dto.common.MemberInSelectPeopleDataDto`

被这些方法当入参：

- `OrgCommonAppService.isMemberInSelectPeopleDataJson()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `memberId` | `java.lang.Long` |
| `selectPeopleData` | `java.lang.String` |

## `OrgMemberManagePermissionDto`（3 字段）

`com.seeyon.organization.dto.common.OrgMemberManagePermissionDto`

被这些方法当入参：

- `OrgCommonAppService.canManage()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `managerId` | `java.lang.Long` |
| `memberId` | `java.lang.Long` |

## `SelectPeopleContainsAnyDto`（3 字段）

`com.seeyon.organization.dto.common.SelectPeopleContainsAnyDto`

被这些方法当入参：

- `OrgCommonAppService.containsAny()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `list1` | `java.util.List<com.seeyon.organization.dto.common.SelectPeopleDataDto>` |
| `list2` | `java.util.List<com.seeyon.organization.dto.common.SelectPeopleDataDto>` |

## `SelectSecretMemberDto`（3 字段）

`com.seeyon.organization.dto.common.SelectSecretMemberDto`

被这些方法当入参：

- `OrgCommonAppService.selectSecretMemberIds()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `memberIds` | `java.util.List<java.lang.Long>` |
| `secret` | `java.lang.String` |

## `SelectSensitiveFileMemberDto`（3 字段）

`com.seeyon.organization.dto.common.SelectSensitiveFileMemberDto`

被这些方法当入参：

- `OrgCommonAppService.selectSensitiveFieldMember()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `ids` | `java.util.List<java.lang.Long>` |
| `fields` | `java.util.List<com.seeyon.organization.enums.core.OrgSensitiveFieldEnum>` |

## `SimpleConditionByIdsDto`（3 字段）

`com.seeyon.organization.dto.core.SimpleConditionByIdsDto`

被这些方法当入参：

- `OrgJobBaseAppService.selectJobListPropertiesByJobIds()`（包装入参）
- `OrgJobCoreAppService.selectJobListPropertiesByJobIds()`（包装入参）
- `OrgLevelBaseAppService.selectLevelListPropertiesByLevelIds()`（包装入参）
- `OrgLevelCoreAppService.selectLevelListPropertiesByLevelIds()`（包装入参）
- `OrgMemberBaseAppService.selectMemberListPropertiesByMemberIds()`（包装入参）
- `OrgMemberCoreAppService.selectMemberListPropertiesByMemberIds()`（包装入参）
- … 另 6 处

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `ids` | `java.util.List<java.lang.Long>` |
| `properties` | `java.lang.String[]` |

## `SimpleConditionByParamsDto`（3 字段）

`com.seeyon.organization.dto.core.SimpleConditionByParamsDto`

被这些方法当入参：

- `OrgJobBaseAppService.selectJobPageListPropertiesByCondition()`（裸参数）
- `OrgLevelBaseAppService.selectLevelPageListPropertiesByCondition()`（裸参数）
- `OrgMemberBaseAppService.selectMemberPageListPropertiesByCondition()`（裸参数）
- `OrgMemberPostBaseAppService.selectMemberPostPageListPropertiesByCondition()`（裸参数）
- `OrgPostBaseAppService.selectPostPageListPropertiesByCondition()`（裸参数）
- `OrgUnitBaseAppService.selectOrgPageListPropertiesByCondition()`（裸参数）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `params` | `java.util.Map<java.lang.String, java.lang.Object>` |
| `properties` | `java.lang.String[]` |

## `OrgDomainIdDto`（3 字段）

`com.seeyon.organization.dto.domainid.OrgDomainIdDto`

被这些方法当入参：

- `OrgCommonAppService.selectDomainIdsByMemberId()`（包装入参）
- `OrgCommonAppService.selectDomainMapByMemberId()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `userId` | `java.lang.Long` |
| `orgDomainTypeEnumList` | `java.util.List<com.seeyon.organization.enums.domainid.OrgDomainTypeEnum>` |

## `SearchDepartmentTree`（3 字段）

`com.seeyon.organization.dto.selectpeople.SearchDepartmentTree`

被这些方法当入参：

- `OrgSelectPeopleForDeptAppService.departmentTree()`（包装入参）

| 字段 | 类型 |
|---|---|
| `businessId` | `java.lang.Long` |
| `parentId` | `java.lang.Long` |
| `isFront` | `java.lang.Boolean` |

## `SearchUnitByKeyDto`（3 字段）

`com.seeyon.organization.dto.selectpeople.SearchUnitByKeyDto`

被这些方法当入参：

- `OrgSelectPeopleForInstAppService.searchInstitution()`（包装入参）

| 字段 | 类型 |
|---|---|
| `maxLevel` | `java.lang.Integer` |
| `appointRootAppIds` | `java.util.List<java.lang.String>` |
| `excludeList` | `java.util.List<com.seeyon.organization.dto.common.SelectPeopleDataDto>` |

## `OrgBatchJobDto`（3 字段）

`com.seeyon.organization.dto.sync.OrgBatchJobDto`

被这些方法当入参：

- `OrgJobSyncAppService.createBatch()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `jobs` | `java.util.List<com.seeyon.organization.dto.sync.OrgJobDataDto>` |
| `useThirdId` | `java.lang.Boolean` |

## `OrgBatchLevelDto`（3 字段）

`com.seeyon.organization.dto.sync.OrgBatchLevelDto`

被这些方法当入参：

- `OrgLevelSyncAppService.createBatch()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `levels` | `java.util.List<com.seeyon.organization.dto.sync.OrgLevelDataDto>` |
| `useThirdId` | `java.lang.Boolean` |

## `OrgBatchMemberDto`（3 字段）

`com.seeyon.organization.dto.sync.OrgBatchMemberDto`

被这些方法当入参：

- `OrgMemberSyncAppService.createBatch()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `members` | `java.util.List<com.seeyon.organization.dto.sync.OrgMemberDataDto>` |
| `useThirdId` | `java.lang.Boolean` |

## `OrgBatchMemberPostDto`（3 字段）

`com.seeyon.organization.dto.sync.OrgBatchMemberPostDto`

被这些方法当入参：

- `OrgMemberSyncAppService.createBatchMemberPost()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `memberPosts` | `java.util.List<com.seeyon.organization.dto.sync.OrgBatchMemberPostDataDto>` |
| `useThirdId` | `java.lang.Boolean` |

## `OrgBatchMetadataDto`（3 字段）

`com.seeyon.organization.dto.sync.OrgBatchMetadataDto`

被这些方法当入参：

- `OrgMemberSyncAppService.createBatchMemberMetadata()`（包装入参）
- `OrgUnitSyncAppService.createBatchUnitMetadata()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `metadatas` | `java.util.List<com.seeyon.organization.dto.sync.OrgBatchMetadataDataDto>` |
| `useThirdId` | `java.lang.Boolean` |

## `OrgBatchPostDto`（3 字段）

`com.seeyon.organization.dto.sync.OrgBatchPostDto`

被这些方法当入参：

- `OrgPostSyncAppService.createBatch()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `posts` | `java.util.List<com.seeyon.organization.dto.sync.OrgPostDataDto>` |
| `useThirdId` | `java.lang.Boolean` |

## `OrgDisableUnitDto`（3 字段）

`com.seeyon.organization.dto.sync.OrgDisableUnitDto`

被这些方法当入参：

- `OrgUnitSyncAppService.disableOrganization()`（包装入参）

| 字段 | 类型 |
|---|---|
| `orgId` | `java.lang.Long` |
| `thirdId` | `java.lang.String` |
| `useThirdId` | `java.lang.Boolean` |

## `MultiOrgDepSyncSearchChildDto`（3 字段）

`com.seeyon.organization.dto.sync.multi.MultiOrgDepSyncSearchChildDto`

被这些方法当入参：

- `MultiOrgDepSyncService.selectPageChildrenByCondition()`（裸参数）

| 字段 | 类型 |
|---|---|
| `currentMultiOrgCode` | `java.lang.String` |
| `multiOrgDeptCode` | `java.lang.String` |
| `includeChild` | `java.lang.Boolean` |

## `MultiOrgMemberSyncSearchByOrgCodeDto`（3 字段）

`com.seeyon.organization.dto.sync.multi.MultiOrgMemberSyncSearchByOrgCodeDto`

被这些方法当入参：

- `MultiOrgMemberSyncService.selectByCodes()`（裸参数）

| 字段 | 类型 |
|---|---|
| `multiOrgCode` | `java.lang.String` |
| `multiOrgDeptCode` | `java.lang.String` |
| `includeChild` | `java.lang.Boolean` |

## `SearchJobApiDto`（3 字段）

`com.seeyon.organization.dto.sync.search.SearchJobApiDto`

被这些方法当入参：

- `OrgJobSyncAppService.selectByCodes()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `unitCode` | `java.lang.String` |
| `codes` | `java.util.List<java.lang.String>` |

## `SearchJobByThirdIdApiDto`（3 字段）

`com.seeyon.organization.dto.sync.search.SearchJobByThirdIdApiDto`

被这些方法当入参：

- `OrgJobSyncAppService.selectByThirds()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `unitThirdId` | `java.lang.String` |
| `thirdIds` | `java.util.List<java.lang.String>` |

## `SearchMemberMetadataDto`（3 字段）

`com.seeyon.organization.dto.sync.search.SearchMemberMetadataDto`

被这些方法当入参：

- `OrgMetadataCoreAppService.selectMemberMetadataInfo()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `memberIds` | `java.util.List<java.lang.Long>` |
| `metadataCode` | `java.lang.String` |

## `SearchPostApiDto`（3 字段）

`com.seeyon.organization.dto.sync.search.SearchPostApiDto`

被这些方法当入参：

- `OrgPostSyncAppService.selectByCodes()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `unitCode` | `java.lang.String` |
| `codes` | `java.util.List<java.lang.String>` |

## `SearchPostByThirdIdApiDto`（3 字段）

`com.seeyon.organization.dto.sync.search.SearchPostByThirdIdApiDto`

被这些方法当入参：

- `OrgPostSyncAppService.selectByThirdIds()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `unitThirdId` | `java.lang.String` |
| `thirdIds` | `java.util.List<java.lang.String>` |

## `SearchUnitMetadataDto`（3 字段）

`com.seeyon.organization.dto.sync.search.SearchUnitMetadataDto`

被这些方法当入参：

- `OrgMetadataCoreAppService.selectOrgMetadataInfo()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `orgIds` | `java.util.List<java.lang.Long>` |
| `metadataCode` | `java.lang.String` |

## `SearchUnitMetadatasDto`（3 字段）

`com.seeyon.organization.dto.sync.search.SearchUnitMetadatasDto`

被这些方法当入参：

- `OrgMetadataCoreAppService.selectOrgMetadataInfos()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `orgIds` | `java.util.List<java.lang.Long>` |
| `metadataCodes` | `java.util.List<java.lang.String>` |

## `AuthorizationResourceAndPermissionDto`（2 字段）

`com.seeyon.organization.dto.api.app.authorization.AuthorizationResourceAndPermissionDto`

被这些方法当入参：

- `AuthorizationAppService.registerAppResourceAndPermission()`（包装入参）

| 字段 | 类型 |
|---|---|
| `resourceMessageDto` | `com.seeyon.organization.dto.api.app.authorization.AuthorizationResourceDto` |
| `resourcePermissionMessageDto` | `com.seeyon.organization.dto.api.app.authorization.AuthorizationResourcePermissionDto` |

## `OrgUnitTeamSearchDto`（2 字段）

`com.seeyon.organization.dto.api.app.third.zhonghe.OrgUnitTeamSearchDto`

被这些方法当入参：

- `OrgZhongheService.getOrgUnitTeamOrgCount()`（包装入参）

| 字段 | 类型 |
|---|---|
| `unitType` | `com.seeyon.organization.enums.core.OrgEntityTypeEnum` |
| `key` | `java.lang.String` |

## `SelectPeopleIdsTransDataDto`（2 字段）

`com.seeyon.organization.dto.api.app.workflow.SelectPeopleIdsTransDataDto`

被这些方法当入参：

- `OrgWorkFlowAppService.selectPeopleIdsCodeData()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `typeIdMap` | `java.util.Map<java.lang.String, java.util.List<java.lang.Long>>` |

## `WorkFlowSelectStorageKeyRequestDto`（2 字段）

`com.seeyon.organization.dto.api.app.workflow.WorkFlowSelectStorageKeyRequestDto`

被这些方法当入参：

- `OrgWorkFlowAppService.selectReturnFileByKey()`（包装入参）
- `OrgWorkFlowAppService.deleteReturnFileByKey()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `fileKey` | `java.lang.String` |

## `SelectSensitiveFieldPermissionDto`（2 字段）

`com.seeyon.organization.dto.common.SelectSensitiveFieldPermissionDto`

被这些方法当入参：

- `OrgCommonAppService.selectSensitiveFieldInfo()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `fields` | `java.util.List<com.seeyon.organization.enums.core.OrgSensitiveFieldEnum>` |

## `OrgModifyMemberInfoSelfDto`（2 字段）

`com.seeyon.organization.dto.core.base.OrgModifyMemberInfoSelfDto`

被这些方法当入参：

- `OrgMemberCoreAppService.modifyMemberInfoBySelf()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `map` | `java.util.Map<java.lang.String, java.lang.String>` |

## `OrgBatchMemberRoleDto`（2 字段）

`com.seeyon.organization.dto.sync.OrgBatchMemberRoleDto`

被这些方法当入参：

- `OrgMemberRoleSyncService.createBatch()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `memberRoles` | `java.util.List<com.seeyon.organization.dto.sync.OrgMemberRoleDataDto>` |

## `OrgBatchNaturalMemberDto`（2 字段）

`com.seeyon.organization.dto.sync.OrgBatchNaturalMemberDto`

被这些方法当入参：

- `OrgMemberSyncAppService.createBatchNaturalMember()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `members` | `java.util.List<com.seeyon.organization.dto.sync.OrgNaturalMemberSyncDto>` |

## `OrgBatchOrgRoleDto`（2 字段）

`com.seeyon.organization.dto.sync.OrgBatchOrgRoleDto`

被这些方法当入参：

- `OrgRoleSyncService.createBatch()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `roles` | `java.util.List<com.seeyon.organization.dto.sync.OrgRoleDataDto>` |

## `OrgBatchTeamDto`（2 字段）

`com.seeyon.organization.dto.sync.OrgBatchTeamDto`

被这些方法当入参：

- `OrgTeamSyncAppService.createBatch()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `teams` | `java.util.List<com.seeyon.organization.dto.sync.OrgTeamDataDto>` |

## `MultiOrgDepSyncBatchDto`（2 字段）

`com.seeyon.organization.dto.sync.multi.MultiOrgDepSyncBatchDto`

被这些方法当入参：

- `MultiOrgDepSyncService.multiOrgCreateBatch()`（包装入参）

| 字段 | 类型 |
|---|---|
| `currentMultiOrgCode` | `java.lang.String` |
| `multiOrgSyncs` | `java.util.List<com.seeyon.organization.dto.sync.multi.MultiOrgDepSync>` |

## `MultiOrgMemberSyncBatchDto`（2 字段）

`com.seeyon.organization.dto.sync.multi.MultiOrgMemberSyncBatchDto`

被这些方法当入参：

- `MultiOrgMemberSyncService.MultiOrgMemberCreateBatch()`（包装入参）

| 字段 | 类型 |
|---|---|
| `multiOrgMembers` | `java.util.List<com.seeyon.organization.dto.sync.multi.MultiOrgMember>` |
| `currentMultiOrgCode` | `java.lang.String` |

## `SearchLevelApiDto`（2 字段）

`com.seeyon.organization.dto.sync.search.SearchLevelApiDto`

被这些方法当入参：

- `OrgLevelSyncAppService.selectByCodes()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `codes` | `java.util.List<java.lang.String>` |

## `SearchLevelByThirdIdApiDto`（2 字段）

`com.seeyon.organization.dto.sync.search.SearchLevelByThirdIdApiDto`

被这些方法当入参：

- `OrgLevelSyncAppService.selectByThirdIds()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `thirdIds` | `java.util.List<java.lang.String>` |

## `OrgMemberConditionDto`（1 字段）

`com.seeyon.organization.dto.core.OrgMemberConditionDto`

被这些方法当入参：

- `OrgMemberBaseAppService.selectInfoListByExtendCode()`（包装入参）

| 字段 | 类型 |
|---|---|
| `metadataConditions` | `java.util.List<com.seeyon.organization.dto.common.OrgMetadataValueDto>` |

## `OrgUserFixDto`（1 字段）

`com.seeyon.organization.dto.sync.OrgUserFixDto`

被这些方法当入参：

- `OrgMemberSyncAppService.fixCtpUserId()`（包装入参）

| 字段 | 类型 |
|---|---|
| `codes` | `java.util.List<java.lang.String>` |

## `MultiOrgSyncBatchDto`（1 字段）

`com.seeyon.organization.dto.sync.multi.MultiOrgSyncBatchDto`

被这些方法当入参：

- `MultiOrgSyncService.multiOrgCreateBatch()`（包装入参）

| 字段 | 类型 |
|---|---|
| `multiOrgSync` | `java.util.List<com.seeyon.organization.dto.sync.multi.MultiOrgSync>` |

## `MultiOrgSyncSearchDto`（1 字段）

`com.seeyon.organization.dto.sync.multi.MultiOrgSyncSearchDto`

被这些方法当入参：

- `MultiOrgSyncService.selectByCodes()`（包装入参）

| 字段 | 类型 |
|---|---|
| `orgCode` | `java.lang.String` |
