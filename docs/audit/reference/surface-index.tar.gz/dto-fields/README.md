# AppService 入参 DTO 字段表（索引）

> 自动生成，勿手改。`tools/core/platform/emit_dto_fields.py` 重跑即可。
> 用法：方法签名里看到 `SingleRequest<XxxDto>` → 到本目录对应域文件查 `XxxDto` 的字段。

| 域 | 文件 | DTO 数 | 被引用的方法数 |
|---|---|---|---|
| 连接器 | `cip.md` | 346 | 520 |
| BPM 流程 | `bpm.md` | 129 | 161 |
| 协同（事项/人员/消息） | `ctp.md` | 112 | 151 |
| UDC 低代码 | `udc.md` | 106 | 323 |
| 组织架构 | `organization.md` | 102 | 151 |
| 平台基础 | `boot.md` | 85 | 187 |
| 应用通用 | `app.md` | 27 | 44 |
| 数据平台 | `cdp.md` | 25 | 31 |
| 移动端 | `m5.md` | 17 | 19 |
| 门户 | `portal.md` | 15 | 22 |
| 研发运维 | `devops.md` | 5 | 19 |

合计 **969 个 DTO**；15 个 DTO 在索引里查不到字段（多为外部 jar 或纯接口，按需反编译）。