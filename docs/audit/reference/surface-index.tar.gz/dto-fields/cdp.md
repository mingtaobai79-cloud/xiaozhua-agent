# 数据平台：入参 DTO 字段表

> 自动生成。包前缀 `com.seeyon.cdp`。共 25 个 DTO。
> 字段类型逐字来自 javap；`static` 前缀表示常量而非实例字段。

## `SearchConditionDto`（15 字段）

`com.seeyon.cdp.index.dto.search.SearchConditionDto`

被这些方法当入参：

- `IndexAppService.search()`（裸参数）
- `IndexParamsResetServiceSpi.paramsReset()`（裸参数）

| 字段 | 类型 |
|---|---|
| `currentUserId` | `java.lang.Long` |
| `apps` | `java.util.List<com.seeyon.cdp.index.dto.search.IndexAppInfoDto>` |
| `fieldScopes` | `java.util.List<com.seeyon.cdp.index.enums.SearchScope>` |
| `timeScope` | `com.seeyon.cdp.index.enums.SearchTimeScope` |
| `customStartTime` | `java.lang.String` |
| `customStopTime` | `java.lang.String` |
| `queryString` | `java.lang.String` |
| `sender` | `java.lang.String` |
| `searchMode` | `com.seeyon.cdp.index.enums.SearchMode` |
| `types` | `java.util.List<com.seeyon.cdp.index.enums.IndexDataType>` |
| `terminals` | `java.util.List<com.seeyon.cdp.index.enums.TerminalType>` |
| `formats` | `java.util.List<com.seeyon.cdp.index.enums.IndexDocFormat>` |
| `categoryDto` | `com.seeyon.cdp.index.dto.search.IndexCategoryDto` |
| `edocUnit` | `java.util.List<java.lang.String>` |
| `edocType` | `java.lang.String` |

## `CdpCascadeHandleEntityDto`（10 字段）

`com.seeyon.cdp.common.dto.validation.part.CdpCascadeHandleEntityDto`

被这些方法当入参：

- `CdpBiz4UdcAppService.cascadeHandleEntityForDataset()`（裸参数）

| 字段 | 类型 |
|---|---|
| `id` | `java.lang.Long` |
| `targetEntityFullName` | `java.lang.String` |
| `rootEntityFullName` | `java.lang.String` |
| `belongRootEntity` | `java.lang.Boolean` |
| `fullNameChange` | `com.seeyon.cdp.common.dto.validation.part.CascadeChange<java.lang.String>` |
| `entityNameChange` | `com.seeyon.cdp.common.dto.validation.part.CascadeChange<java.lang.String>` |
| `entityCaptionChange` | `com.seeyon.cdp.common.dto.validation.part.CascadeChange<java.lang.String>` |
| `attrNameChanges` | `java.util.List<com.seeyon.cdp.common.dto.validation.part.CascadeChange<java.lang.String>>` |
| `attrCaptionChanges` | `java.util.List<com.seeyon.cdp.common.dto.validation.part.CascadeChange<java.lang.String>>` |
| `attrTypeChanges` | `java.util.List<com.seeyon.cdp.common.dto.validation.part.CascadeChange<com.seeyon.boot.enums.DataType>>` |

## `IndexBpmDataDto`（9 字段）

`com.seeyon.cdp.index.dto.IndexBpmDataDto`

被这些方法当入参：

- `IndexStoreAppService.saveIndexBpmData()`（包装入参）

| 字段 | 类型 |
|---|---|
| `appName` | `java.lang.String` |
| `creatorId` | `java.lang.Long` |
| `creatorName` | `java.lang.String` |
| `title` | `java.lang.String` |
| `objectId` | `java.lang.Long` |
| `caseId` | `java.lang.Long` |
| `addAuthorIds` | `java.util.List<java.lang.Long>` |
| `deleteAuthorIds` | `java.util.List<java.lang.Long>` |
| `opinions` | `java.util.List<com.seeyon.cdp.index.dto.IndexOpinionDto>` |

## `ReportResultRequestDto`（8 字段）

`com.seeyon.cdp.bi.dto.ReportResultRequestDto`

被这些方法当入参：

- `ReportOpenApiAppService.getReportResult()`（包装入参）

| 字段 | 类型 |
|---|---|
| `reportId` | `java.lang.Long` |
| `reportGuid` | `java.lang.Long` |
| `componentId` | `java.lang.Long` |
| `terminal` | `java.lang.String` |
| `filterParams` | `java.util.List<com.seeyon.cdp.common.dto.model.FilterParamDto>` |
| `sortInfos` | `java.util.List<com.seeyon.cdp.common.dto.model.SortInfo>` |
| `pageInfo` | `com.seeyon.boot.transport.PageInfo` |
| `detailResult` | `java.lang.Boolean` |

## `CdpEtlSourceParamsDto`（5 字段）

`com.seeyon.cdp.etl.dto.CdpEtlSourceParamsDto`

被这些方法当入参：

- `CdpEtlSourceAppService.getSource()`（包装入参）

| 字段 | 类型 |
|---|---|
| `key` | `java.lang.String` |
| `isUdcApp` | `java.lang.Boolean` |
| `sandBoxId` | `java.lang.Long` |
| `type` | `com.seeyon.cdp.etl.enums.CdpEtlSourceType` |
| `tenantId` | `java.lang.Long` |

## `IndexUpdateAuthDto`（5 字段）

`com.seeyon.cdp.index.dto.IndexUpdateAuthDto`

被这些方法当入参：

- `IndexStoreAppService.updateIndexAuth()`（包装入参）

| 字段 | 类型 |
|---|---|
| `objectId` | `java.lang.Long` |
| `caseId` | `java.lang.Long` |
| `authorIds` | `java.util.List<java.lang.Long>` |
| `authIds` | `java.util.List<java.lang.String>` |
| `guid` | `java.lang.Long` |

## `TransportOutRequestDto`（4 字段）

`com.seeyon.cdp.common.dto.transport.TransportOutRequestDto`

被这些方法当入参：

- `CdpBiz4UdcAppService.transportOut()`（包装入参）
- `CdpBiz4UdcAppService.transportOutV2()`（包装入参）

| 字段 | 类型 |
|---|---|
| `caption` | `java.lang.String` |
| `appType` | `java.lang.String` |
| `deployType` | `java.lang.String` |
| `outType` | `com.seeyon.cdp.common.enums.TransportOutType` |

## `CdpEtlRunDto`（4 字段）

`com.seeyon.cdp.etl.dto.CdpEtlRunDto`

被这些方法当入参：

- `CdpEtlRunAppService.jobSuccess()`（包装入参）

| 字段 | 类型 |
|---|---|
| `objectId` | `java.lang.Long` |
| `cdpBizType` | `com.seeyon.cdp.etl.enums.CdpBizType` |
| `jobFinishedTime` | `java.util.Date` |
| `cdpBizParam` | `java.util.Map<java.lang.String, java.lang.Object>` |

## `ReportDetailRequestDto`（3 字段）

`com.seeyon.cdp.bi.dto.ReportDetailRequestDto`

被这些方法当入参：

- `ReportOpenApiAppService.getReportDetail()`（包装入参）

| 字段 | 类型 |
|---|---|
| `reportId` | `java.lang.Long` |
| `reportGuid` | `java.lang.Long` |
| `terminal` | `java.lang.String` |

## `PublishParamsDto`（3 字段）

`com.seeyon.cdp.common.dto.publish.PublishParamsDto`

被这些方法当入参：

- `CdpBiz4UdcAppService.deploy()`（包装入参）

| 字段 | 类型 |
|---|---|
| `caption` | `java.lang.String` |
| `appType` | `java.lang.String` |
| `DeployType` | `java.lang.String` |

## `UdcReportRequestDto`（2 字段）

`com.seeyon.cdp.common.dto.report.UdcReportRequestDto`

被这些方法当入参：

- `CdpBiz4UdcAppService.getReportList()`（包装入参）

| 字段 | 类型 |
|---|---|
| `appName` | `java.lang.String` |
| `appId` | `java.lang.Long` |

## `CdpDetectionEntityDto`（2 字段）

`com.seeyon.cdp.common.dto.validation.part.CdpDetectionEntityDto`

被这些方法当入参：

- `CdpBiz4UdcAppService.detectionPartEntityForDataset()`（包装入参）
- `CdpBiz4UdcAppService.detectionPartEntityForStream()`（包装入参）

| 字段 | 类型 |
|---|---|
| `deleteEntityList` | `java.util.List<com.seeyon.cdp.common.dto.validation.part.EntityDetectionDto>` |
| `updateEntityList` | `java.util.List<com.seeyon.cdp.common.dto.validation.part.EntityDetectionDto>` |

## `CdpDetectionIndicatorRequestDto`（2 字段）

`com.seeyon.cdp.common.dto.validation.part.CdpDetectionIndicatorRequestDto`

被这些方法当入参：

- `CdpBiz4UdcAppService.detectionPartIndicatorForTable()`（包装入参）

| 字段 | 类型 |
|---|---|
| `deleteIndicatorIdList` | `java.util.List<java.lang.Long>` |
| `updateIndicatorIdList` | `java.util.List<java.lang.Long>` |

## `CdpDetectionModelRequestDto`（2 字段）

`com.seeyon.cdp.common.dto.validation.part.CdpDetectionModelRequestDto`

被这些方法当入参：

- `CdpBiz4UdcAppService.detectionPartModelForStream()`（包装入参）
- `CdpBiz4UdcAppService.detectionPartModelForIndicator()`（包装入参）
- `CdpBiz4UdcAppService.detectionPartModelForReport()`（包装入参）

| 字段 | 类型 |
|---|---|
| `deleteModelIdList` | `java.util.List<java.lang.Long>` |
| `updateModelIdList` | `java.util.List<java.lang.Long>` |

## `DatasetModelRequestDto`（2 字段）

`com.seeyon.cdp.dataset.dto.DatasetModelRequestDto`

被这些方法当入参：

- `DatasetOpenApiAppService.getDatasetModel()`（包装入参）

| 字段 | 类型 |
|---|---|
| `datasetId` | `java.lang.Long` |
| `datasetGuid` | `java.lang.Long` |

## `DatasetResultRequestDto`（2 字段）

`com.seeyon.cdp.dataset.dto.DatasetResultRequestDto`

被这些方法当入参：

- `DatasetOpenApiAppService.getDatasetResult()`（包装入参）

| 字段 | 类型 |
|---|---|
| `datasetId` | `java.lang.Long` |
| `datasetGuid` | `java.lang.Long` |

## `IndexDeleteDto`（2 字段）

`com.seeyon.cdp.index.dto.IndexDeleteDto`

被这些方法当入参：

- `IndexStoreAppService.delete()`（包装入参）
- `IndexStoreAppService.batchDelete()`（包装入参）

| 字段 | 类型 |
|---|---|
| `objectIds` | `java.util.List<java.lang.Long>` |
| `guids` | `java.util.List<java.lang.Long>` |

## `IndicatorModelRequestDto`（2 字段）

`com.seeyon.cdp.indicator.dto.IndicatorModelRequestDto`

被这些方法当入参：

- `IndicatorOpenApiAppService.getIndicatorModel()`（包装入参）

| 字段 | 类型 |
|---|---|
| `indicatorId` | `java.lang.Long` |
| `indicatorGuid` | `java.lang.Long` |

## `IndicatorResultRequestDto`（2 字段）

`com.seeyon.cdp.indicator.dto.IndicatorResultRequestDto`

被这些方法当入参：

- `IndicatorOpenApiAppService.getIndicatorResult()`（包装入参）

| 字段 | 类型 |
|---|---|
| `indicatorId` | `java.lang.Long` |
| `indicatorGuid` | `java.lang.Long` |

## `StreamModelRequestDto`（2 字段）

`com.seeyon.cdp.stream.dto.StreamModelRequestDto`

被这些方法当入参：

- `StreamOpenApiAppService.getStreamModel()`（包装入参）

| 字段 | 类型 |
|---|---|
| `streamId` | `java.lang.Long` |
| `streamGuid` | `java.lang.Long` |

## `StreamResultRequestDto`（2 字段）

`com.seeyon.cdp.stream.dto.StreamResultRequestDto`

被这些方法当入参：

- `StreamOpenApiAppService.getStreamResult()`（包装入参）

| 字段 | 类型 |
|---|---|
| `streamId` | `java.lang.Long` |
| `streamGuid` | `java.lang.Long` |

## `CdpEtlDatasetMetadataRequest`（1 字段）

`com.seeyon.cdp.etl.dto.CdpEtlDatasetMetadataRequest`

被这些方法当入参：

- `CdpEtlSourceAppService.getDatasetPublishMetadata()`（包装入参）

| 字段 | 类型 |
|---|---|
| `datasetId` | `java.lang.Long` |

## `IndexStoreDto`（1 字段）

`com.seeyon.cdp.index.dto.IndexStoreDto`

被这些方法当入参：

- `IndexStoreAppService.save()`（包装入参）

| 字段 | 类型 |
|---|---|
| `data` | `java.util.List<com.seeyon.cdp.index.dto.IndexDataDto>` |

## `SearchHistoryConditionDto`（1 字段）

`com.seeyon.cdp.index.dto.search.SearchHistoryConditionDto`

被这些方法当入参：

- `IndexAppService.searchHistory()`（包装入参）

| 字段 | 类型 |
|---|---|
| `currentUserId` | `java.lang.Long` |

## `SuggestConditionDto`（1 字段）

`com.seeyon.cdp.index.dto.search.SuggestConditionDto`

被这些方法当入参：

- `IndexAppService.suggest()`（包装入参）

| 字段 | 类型 |
|---|---|
| `text` | `java.lang.String` |
