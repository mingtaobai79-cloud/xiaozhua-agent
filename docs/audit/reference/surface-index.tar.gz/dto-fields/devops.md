# 研发运维：入参 DTO 字段表

> 自动生成。包前缀 `com.seeyon.devops`。共 5 个 DTO。
> 字段类型逐字来自 javap；`static` 前缀表示常量而非实例字段。

## `ControlsDto`（15 字段）

`com.seeyon.devops.starter.artifact.npm.dto.ControlsDto`

被这些方法当入参：

- `NpmSyncDataService.checkControls()`（裸参数）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `name` | `java.lang.String` |
| `description` | `java.lang.String` |
| `type` | `java.lang.String` |
| `bizCategory` | `java.lang.String` |
| `group` | `java.lang.String` |
| `order` | `java.lang.Integer` |
| `icon` | `java.lang.String` |
| `terminalType` | `java.lang.String` |
| `uiModel` | `java.lang.String` |
| `designModule` | `com.seeyon.devops.starter.artifact.npm.dto.ModuleDto` |
| `runtimeModule` | `com.seeyon.devops.starter.artifact.npm.dto.ModuleDto` |
| `schemaModule` | `com.seeyon.devops.starter.artifact.npm.dto.ModuleDto` |
| `dataTypes` | `java.util.List<com.seeyon.devops.starter.artifact.npm.dto.SupportDataTypeDto>` |
| `isHiddenOnPagePrint` | `java.lang.Boolean` |

## `ArtifactDto`（9 字段）

`com.seeyon.devops.starter.artifact.dto.ArtifactDto`

被这些方法当入参：

- `ArtifactService.upload()`（裸参数）
- `ArtifactService.download()`（裸参数）
- `ArtifactService.delete()`（裸参数）
- `ArtifactService.exist()`（裸参数）
- `ArtifactService.lambda$null$1()`（裸参数）
- `AbstractArtifactManager.downloadForFerryboat()`（裸参数）
- … 另 5 处

| 字段 | 类型 |
|---|---|
| `SNAPSHOT` | static `java.lang.String` |
| `SNAPSHOT_TIMESTAMP` | static `java.util.regex.Pattern` |
| `appId` | `java.lang.String` |
| `groupId` | `java.lang.String` |
| `artifactId` | `java.lang.String` |
| `version` | `java.lang.String` |
| `extension` | `java.lang.String` |
| `time` | `java.lang.String` |
| `file` | `java.io.File` |

## `PackageInfoDto`（8 字段）

`com.seeyon.devops.starter.artifact.npm.dto.PackageInfoDto`

被这些方法当入参：

- `NpmSyncDataService.getPackageLocalPath()`（裸参数）
- `NpmSyncDataService.filterData()`（裸参数）
- `NpmSyncDataService.parseControls()`（裸参数）
- `NpmSyncDataService.checkControls()`（裸参数）
- `NpmSyncDataService.npmSyncControl()`（裸参数）

| 字段 | 类型 |
|---|---|
| `name` | `java.lang.String` |
| `version` | `java.lang.String` |
| `profile` | `java.lang.String` |
| `majorVersion` | `java.lang.String` |
| `buildTime` | `java.util.Date` |
| `description` | `java.lang.String` |
| `tarball` | `java.lang.String` |
| `mfUrl` | `java.lang.String` |

## `FrontPackageDto`（5 字段）

`com.seeyon.devops.starter.artifact.npm.dto.FrontPackageDto`

被这些方法当入参：

- `NpmService.parsePackage()`（裸参数）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `hostAppName` | `java.lang.String` |
| `name` | `java.lang.String` |
| `version` | `java.lang.String` |
| `filePath` | `java.lang.String` |

## `VersionRangeArtifactDto`（3 字段）

`com.seeyon.devops.starter.artifact.dto.VersionRangeArtifactDto`

被这些方法当入参：

- `ArtifactService.resolveVersionRange()`（裸参数）

| 字段 | 类型 |
|---|---|
| `lowerVersion` | `java.lang.String` |
| `upperVersion` | `java.lang.String` |
| `ignoreSnapshot` | `boolean` |
