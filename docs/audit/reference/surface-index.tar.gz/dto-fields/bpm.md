# BPM 流程：入参 DTO 字段表

> 自动生成。包前缀 `com.seeyon.bpm`。共 129 个 DTO。
> 字段类型逐字来自 javap；`static` 前缀表示常量而非实例字段。

## `BpmTemplateDto`（78 字段）

`com.seeyon.bpm.dto.BpmTemplateDto`

被这些方法当入参：

- `BpmTemplateAppService.createOrUpdate()`（包装入参）
- `BpmTemplateAppService.updateByAppName()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `id` | `java.lang.Long` |
| `appName` | `java.lang.String` |
| `rootEntityName` | `java.lang.String` |
| `rootEntityId` | `java.lang.Long` |
| `pageUrl` | `java.lang.String` |
| `mobilePageUrl` | `java.lang.String` |
| `donePageUrl` | `java.lang.String` |
| `doneMobilePageUrl` | `java.lang.String` |
| `helpPage` | `java.lang.String` |
| `pageGroupId` | `java.lang.Long` |
| `applicationId` | `java.lang.Long` |
| `appId` | `java.lang.Long` |
| `applicationName` | `java.lang.String` |
| `dynamicTitle` | `java.lang.String` |
| `templateType` | `com.seeyon.bpm.enums.TemplateTypeEnum` |
| `code` | `java.lang.String` |
| `createAccountId` | `java.lang.String` |
| `createUserId` | `java.lang.Long` |
| `effectTime` | `java.util.Date` |
| `invalidTime` | `java.util.Date` |
| `templateVersion` | `java.lang.Integer` |
| `updateUserId` | `java.lang.Long` |
| `subject` | `java.lang.String` |
| `categoryId` | `java.lang.Long` |
| `state` | `com.seeyon.bpm.enums.TemplateStateEnum` |
| `description` | `java.lang.String` |
| `desStorageKey` | `java.lang.String` |
| `versionGroupId` | `java.lang.Long` |
| `authorized` | `java.lang.String` |
| `tagNames` | `java.util.List<java.lang.String>` |
| `forward` | `java.lang.Boolean` |
| `outsideProcess` | `java.lang.Boolean` |
| `designState` | `com.seeyon.bpm.enums.BpmTemplateDesignState` |
| `sourceType` | `com.seeyon.bpm.enums.BpmTemplateSourceType` |
| `liablePersons` | `java.lang.String` |
| `liableOrganizations` | `java.lang.String` |
| `contactPersons` | `java.lang.String` |
| `createUser` | `com.seeyon.bpm.dto.BpmTemplateReferUserDto` |
| `createAccount` | `com.seeyon.bpm.dto.BpmTemplateReferOrgUnitDto` |
| `processVersion` | `java.lang.Integer` |
| `enable` | `java.lang.Boolean` |
| `allowedSend` | `java.lang.Boolean` |
| `tags` | `java.lang.String` |
| `published` | `java.lang.Boolean` |
| `shortName` | `java.lang.String` |
| `docStorageKey` | `java.lang.String` |
| `subApp` | `java.lang.String` |
| `pageParameter` | `java.lang.String` |
| `mobilePageParameter` | `java.lang.String` |
| `pcSubPage` | `java.lang.String` |
| `mobileSubPage` | `java.lang.String` |
| `applicationVersion` | `java.lang.String` |
| `singleSign` | `java.lang.Boolean` |
| `pluginId` | `java.lang.Long` |
| `nodePermissionId` | `java.lang.Long` |
| `entityGuid` | `java.lang.Long` |
| `formPermissionId` | `java.lang.Long` |
| `allowReliveAfterFinish` | `java.lang.Boolean` |
| `allowReliveAfterStop` | `java.lang.Boolean` |
| `nodePermScope` | `java.lang.String` |
| `saveFormDataInterface` | `java.lang.String` |
| `gray` | `java.lang.Boolean` |
| `overtimeCompute` | `com.seeyon.bpm.enums.TemplateOvertimeComputeEnum` |
| `permissionCode` | `com.seeyon.bpm.enums.BpmFormPermissionCodeEnum` |
| `freeFlow` | `java.lang.Boolean` |
| `draftVersion` | `java.lang.String` |
| `canDeleteTemplateNode` | `java.lang.Boolean` |
| `evaluationType` | `com.seeyon.bpm.enums.BpmTemplateEvaluationTypeEnum` |
| `templateLevel` | `com.seeyon.bpm.enums.BpmTemplateLevelEnum` |
| `interfaceInfo` | `java.lang.String` |
| `appBusinessData` | `java.lang.String` |
| `dynamicTitleGenerationMethod` | `com.seeyon.bpm.enums.DynamicTitleGenerationMethodEnum` |
| `postApprovalSetting` | `java.lang.String` |
| `allowHierarchicalControl` | `java.lang.Boolean` |
| `canDisableHierarchicalControl` | `java.lang.Boolean` |
| `addNodeImmediate` | `java.lang.Boolean` |
| `extensionPlan` | `java.lang.String` |

## `BpmOpinionDataDto`（56 字段）

`com.seeyon.bpm.dto.opinion.BpmOpinionDataDto`

被这些方法当入参：

- `BpmOpinionAppService.create()`（包装入参）
- `BpmOpinionAppService.createBatchOpinion()`（裸参数）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `id` | `java.lang.Long` |
| `createTime` | `java.util.Date` |
| `updateTime` | `java.util.Date` |
| `appName` | `java.lang.String` |
| `objectId` | `java.lang.Long` |
| `subObjectId` | `java.lang.Long` |
| `affairId` | `java.lang.Long` |
| `createUserId` | `java.lang.Long` |
| `createUserName` | `java.lang.String` |
| `createUserPostName` | `java.lang.String` |
| `createUserDeptName` | `java.lang.String` |
| `content` | `java.lang.String` |
| `richContent` | `java.lang.String` |
| `opinion` | `java.lang.String` |
| `opinionName` | `java.lang.String` |
| `operation` | `java.lang.String` |
| `operationName` | `java.lang.String` |
| `hasOperationLog` | `java.lang.Boolean` |
| `replyId` | `java.lang.Long` |
| `replyTopId` | `java.lang.Long` |
| `replyUserId` | `java.lang.Long` |
| `replyUserName` | `java.lang.String` |
| `replyUserDeptName` | `java.lang.String` |
| `replyUserPostName` | `java.lang.String` |
| `anonymous` | `java.lang.Boolean` |
| `opinionHide` | `java.util.List<java.lang.Long>` |
| `praise` | `java.util.List<java.lang.Long>` |
| `praiseName` | `java.util.List<java.lang.String>` |
| `praiseNum` | `java.lang.Long` |
| `currentUserPraise` | `java.lang.Boolean` |
| `deleteFlag` | `java.lang.Boolean` |
| `attachment` | `java.util.List<java.lang.String>` |
| `originAttachment` | `java.lang.String` |
| `associateDocument` | `java.lang.String` |
| `activityNodeId` | `java.lang.Long` |
| `activityNodeName` | `java.lang.String` |
| `nodeFirstDelTime` | `java.util.Date` |
| `activityFirstTime` | `java.util.Date` |
| `subOpinions` | `java.lang.String` |
| `subOpinionNum` | `int` |
| `agentId` | `java.lang.Long` |
| `sublicenseId` | `java.lang.Long` |
| `sourceNodeId` | `java.lang.Long` |
| `opinionType` | `java.lang.Integer` |
| `hidden` | `java.lang.Boolean` |
| `showPerson` | `java.lang.String` |
| `permissionId` | `java.lang.Long` |
| `extendImplFlag` | `java.lang.String` |
| `batchId` | `java.lang.Long` |
| `dynamicNodePath` | `java.lang.String` |
| `splitNodeOpinion` | `java.lang.Boolean` |
| `createUserSeal` | `java.lang.String` |
| `actionTime` | `java.util.Date` |
| `extString1` | `java.lang.String` |
| `nodeType` | `java.lang.String` |

## `BpmCaseDto`（51 字段）

`com.seeyon.bpm.dto.BpmCaseDto`

被这些方法当入参：

- `BpmCaseAppService.create()`（包装入参）
- `BpmCaseAppService.createBatch()`（裸参数）
- `BpmCaseAppService.updateCase()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `id` | `java.lang.Long` |
| `createMemberId` | `java.lang.Long` |
| `updateMemberId` | `java.lang.Long` |
| `createMemberName` | `java.lang.String` |
| `subject` | `java.lang.String` |
| `templateId` | `java.lang.Long` |
| `diagramStorageKey` | `java.lang.String` |
| `accountId` | `java.lang.Long` |
| `state` | `com.seeyon.bpm.enums.CaseStateEnum` |
| `appName` | `java.lang.String` |
| `startOrgInfo` | `java.lang.Long` |
| `stepBackCount` | `java.lang.Integer` |
| `toStartActivityId` | `java.lang.Long` |
| `lastWorkItemId` | `java.lang.Long` |
| `processType` | `com.seeyon.bpm.enums.CaseTypeEnum` |
| `approvalState` | `com.seeyon.bpm.enums.CaseApprovalState` |
| `businessId` | `java.lang.Long` |
| `formRecordId` | `java.lang.Long` |
| `formRecordCode` | `java.lang.String` |
| `paramDataStorageId` | `java.lang.String` |
| `applicationName` | `java.lang.String` |
| `applicationId` | `java.lang.Long` |
| `startTime` | `java.util.Date` |
| `processId` | `java.lang.Long` |
| `startFormUrl` | `java.lang.String` |
| `rootEntityName` | `java.lang.String` |
| `templateType` | `com.seeyon.bpm.enums.TemplateTypeEnum` |
| `runningDuration` | `java.lang.Long` |
| `suspendTime` | `java.util.Date` |
| `suspendDuration` | `java.lang.Long` |
| `createDeptId` | `java.lang.Long` |
| `postId` | `java.lang.Long` |
| `competitionStart` | `java.lang.Boolean` |
| `caseDeadline` | `java.util.Date` |
| `finishDate` | `java.util.Date` |
| `templateGuid` | `java.lang.Long` |
| `overTime` | `java.lang.Long` |
| `approvalDisagreeIds` | `java.lang.String` |
| `paramDataMd5` | `java.lang.String` |
| `overdue` | `java.lang.Boolean` |
| `extString1` | `java.lang.String` |
| `applicationVersion` | `java.lang.String` |
| `sourceType` | `com.seeyon.bpm.enums.DataSourceTypeEnum` |
| `importance` | `com.seeyon.bpm.enums.ImportanceEnum` |
| `isFreeFlow` | `java.lang.Boolean` |
| `secretId` | `java.lang.String` |
| `currentPendingMemberName` | `java.lang.String` |
| `currentPendingNodeName` | `java.lang.String` |
| `processExtentType` | `com.seeyon.bpm.enums.BpmProcessTypeEnum` |
| `templateName` | `java.lang.String` |

## `BpmWorkItemDto`（46 字段）

`com.seeyon.bpm.dto.BpmWorkItemDto`

被这些方法当入参：

- `BpmWorkItemAppService.create()`（包装入参）
- `BpmWorkItemAppService.createBatch()`（裸参数）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `actionState` | `java.lang.String` |
| `activityId` | `java.lang.Long` |
| `activityName` | `java.lang.String` |
| `activityCode` | `java.lang.String` |
| `activityPermissionId` | `java.lang.Long` |
| `activityPermissionTypeCode` | `java.lang.String` |
| `addedFromId` | `java.lang.Long` |
| `batch` | `java.lang.Long` |
| `changeType` | `com.seeyon.bpm.enums.ChangeTypeEnum` |
| `expireTime` | `java.util.Date` |
| `finisher` | `java.lang.Long` |
| `informNode` | `java.lang.Boolean` |
| `mergeDealType` | `com.seeyon.bpm.enums.BpmSeeyonPolicySetting$MergeDealTypeEnum` |
| `nextNodeId` | `java.lang.String` |
| `oldState` | `java.lang.Integer` |
| `orgInfo` | `java.lang.String` |
| `owner` | `java.lang.Long` |
| `ownerName` | `java.lang.String` |
| `ownerDeptId` | `java.lang.Long` |
| `ownerPostId` | `java.lang.Long` |
| `ownerAccountId` | `java.lang.Long` |
| `postMatch` | `java.lang.String` |
| `preWorkItemId` | `java.lang.Long` |
| `caseId` | `java.lang.Long` |
| `relativeToRepeatMerge` | `java.lang.String` |
| `serialNextItemId` | `java.lang.Long` |
| `serialPreItemId` | `java.lang.Long` |
| `sort` | `java.lang.Integer` |
| `dealTime` | `java.util.Date` |
| `state` | `java.lang.Integer` |
| `subState` | `com.seeyon.bpm.enums.WorkItemActionStateEnum` |
| `isRead` | `java.lang.Boolean` |
| `createType` | `java.lang.Integer` |
| `effectProcessFlow` | `java.lang.Boolean` |
| `sourceType` | `com.seeyon.bpm.enums.DataSourceTypeEnum` |
| `receiveTime` | `java.util.Date` |
| `transfer` | `java.lang.Boolean` |
| `readOnly` | `java.lang.Boolean` |
| `nodeGroupId` | `java.lang.Long` |
| `mobileNotAllowed` | `java.lang.Boolean` |
| `sourceNodeId` | `java.lang.Long` |
| `formPermissionId` | `java.lang.Long` |
| `agentExt` | `java.lang.String` |
| `haveConsult` | `java.lang.Boolean` |
| `isDelete` | `java.lang.Boolean` |

## `BpmEdocSummaryDetailParamDto`（34 字段）

`com.seeyon.bpm.dto.edoc.BpmEdocSummaryDetailParamDto`

被这些方法当入参：

- `BpmDetailAppService.selectDetail()`（包装入参）

| 字段 | 类型 |
|---|---|
| `templateId` | `java.lang.Long` |
| `templateGuid` | `java.lang.Long` |
| `processType` | `com.seeyon.bpm.enums.edoc.EdocViewProcessTypeEnum` |
| `fromCaseId` | `java.lang.Long` |
| `mainNodeId` | `java.lang.Long` |
| `affairId` | `java.lang.Long` |
| `caseId` | `java.lang.Long` |
| `userId` | `java.lang.Long` |
| `orgId` | `java.lang.Long` |
| `detailType` | `com.seeyon.bpm.enums.BpmDetailTypeEnum` |
| `fullText` | `java.lang.Boolean` |
| `rootEntityName` | `java.lang.String` |
| `pageUrl` | `java.lang.String` |
| `personalPageUrl` | `java.lang.String` |
| `pageType` | `com.seeyon.bpm.enums.PageTypeEnum` |
| `layoutType` | `com.seeyon.bpm.enums.PageTypeEnum` |
| `contentPageUrl` | `java.lang.String` |
| `pageGuid` | `java.lang.Long` |
| `permissionId` | `java.lang.Long` |
| `appName` | `java.lang.String` |
| `personalAppName` | `java.lang.String` |
| `pageParameter` | `java.lang.String` |
| `layoutAppName` | `java.lang.String` |
| `layoutGuid` | `java.lang.Long` |
| `layoutUrl` | `java.lang.String` |
| `vid` | `java.lang.Long` |
| `activityId` | `java.lang.Long` |
| `authObjectId` | `java.lang.String` |
| `authAppName` | `java.lang.String` |
| `systemSettingCodes` | `java.util.List<java.lang.String>` |
| `personalTemplateId` | `java.lang.Long` |
| `groupId` | `java.lang.Long` |
| `queryConfigId` | `java.lang.Long` |
| `formRecordId` | `java.lang.Long` |

## `BpmNodePermissionFullFieldDto`（31 字段）

`com.seeyon.bpm.dto.BpmNodePermissionFullFieldDto`

被这些方法当入参：

- `BpmApiNodePermissionAppService.createOrUpdateNodePermissionBatch()`（裸参数）

| 字段 | 类型 |
|---|---|
| `id` | `java.lang.Long` |
| `guid` | `java.lang.Long` |
| `createTime` | `java.util.Date` |
| `updateTime` | `java.util.Date` |
| `originalId` | `java.lang.Long` |
| `applicationId` | `java.lang.Long` |
| `applicationName` | `java.lang.String` |
| `code` | `java.lang.String` |
| `name` | `java.lang.String` |
| `type` | `com.seeyon.bpm.enums.BpmNodePermissionTypeEnum` |
| `nodeType` | `com.seeyon.bpm.enums.NodeTypeEnum` |
| `appName` | `java.lang.String` |
| `systemInit` | `java.lang.Boolean` |
| `systemDefault` | `java.lang.Boolean` |
| `createUserId` | `java.lang.Long` |
| `updateUserId` | `java.lang.Long` |
| `enable` | `java.lang.Boolean` |
| `orderNum` | `java.lang.Integer` |
| `designState` | `com.seeyon.bpm.enums.BpmTemplateDesignState` |
| `accountId` | `java.lang.Long` |
| `init` | `java.lang.Byte` |
| `subApp` | `java.lang.String` |
| `mobileFrame` | `java.lang.String` |
| `pcFrame` | `java.lang.String` |
| `dataType` | `java.lang.Boolean` |
| `rootEntityName` | `java.lang.String` |
| `rootEntityId` | `java.lang.Long` |
| `entityGuid` | `java.lang.Long` |
| `batchAble` | `java.lang.Boolean` |
| `operationEntities` | `java.util.List<com.seeyon.bpm.dto.BpmNodePermissionOperationFullFieldDto>` |
| `contentEntities` | `java.util.List<com.seeyon.bpm.dto.BpmFormPermissionContentFullFiledDto>` |

## `BpmProcessLogDto`（26 字段）

`com.seeyon.bpm.dto.BpmProcessLogDto`

被这些方法当入参：

- `BpmProcessLogAppService.create()`（包装入参）
- `BpmProcessLogAppService.createBatch()`（裸参数）
- `BpmProcessLogAppService.createBatchProcessLog()`（裸参数）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `id` | `java.lang.Long` |
| `caseId` | `java.lang.Long` |
| `nodeId` | `java.lang.Long` |
| `nodeName` | `java.lang.String` |
| `workItemId` | `java.lang.Long` |
| `actionUserId` | `java.lang.Long` |
| `actionUserName` | `java.lang.String` |
| `actionTime` | `java.util.Date` |
| `actionType` | `java.lang.String` |
| `actionDetail` | `java.lang.String` |
| `receiveTime` | `java.util.Date` |
| `dealTime` | `java.lang.String` |
| `dealTermTime` | `java.lang.String` |
| `hasExpire` | `java.lang.Boolean` |
| `expireTime` | `java.lang.String` |
| `hasDetail` | `java.lang.Boolean` |
| `tenantId` | `java.lang.Long` |
| `bpmProcessDetailLogList` | `java.util.List<com.seeyon.bpm.dto.BpmProcessDetailLogDto>` |
| `affairId` | `java.lang.Long` |
| `opinionId` | `java.lang.Long` |
| `dealTermTimeValue` | `java.lang.Integer` |
| `dealTermTimeUnit` | `java.lang.String` |
| `dealTermTimeParam` | `java.lang.String` |
| `dealMinute` | `java.lang.Integer` |
| `needCheckAuth` | `java.lang.Boolean` |

## `BpmFormPermissionDto`（25 字段）

`com.seeyon.bpm.dto.BpmFormPermissionDto`

被这些方法当入参：

- `BpmApiFormPermissionAppService.create()`（包装入参）
- `BpmApiFormPermissionAppService.update()`（包装入参）
- `BpmApiFormPermissionAppService.createOrUpdateBatch()`（裸参数）
- `BpmApiFormPermissionAppService.checkFormPermissionBatch()`（裸参数）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `caption` | `java.lang.String` |
| `templateId` | `java.lang.Long` |
| `pageUrl` | `java.lang.String` |
| `pageGroupId` | `java.lang.Long` |
| `pageCaption` | `java.lang.String` |
| `sourceType` | `com.seeyon.bpm.enums.BpmFormPermissionSourceTypeEnum` |
| `permissionsCode` | `com.seeyon.bpm.enums.BpmFormPermissionCodeEnum` |
| `mobilePageUrl` | `java.lang.String` |
| `mobilePageCaption` | `java.lang.String` |
| `pageParameter` | `java.lang.String` |
| `mobilePageParameter` | `java.lang.String` |
| `pcSubPage` | `java.lang.String` |
| `mobileSubPage` | `java.lang.String` |
| `isFieldSame` | `java.lang.Boolean` |
| `rootEntityName` | `java.lang.String` |
| `applicationName` | `java.lang.String` |
| `designState` | `com.seeyon.bpm.enums.BpmTemplateDesignState` |
| `state` | `com.seeyon.bpm.enums.TemplateStateEnum` |
| `appId` | `java.lang.Long` |
| `accountId` | `java.lang.Long` |
| `currentVersion` | `java.lang.String` |
| `permissionType` | `com.seeyon.bpm.enums.BpmFormPermissionTypeEnum` |
| `extendParamJson` | `java.lang.String` |
| `switchMobilePage` | `java.lang.Boolean` |

## `BpmFormPermissionContentDto`（21 字段）

`com.seeyon.bpm.dto.BpmFormPermissionContentDto`

被这些方法当入参：

- `BpmApiFormPermissionAppService.createBatchOrUpdateContent()`（裸参数）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `permissionId` | `java.lang.Long` |
| `widgetId` | `java.lang.String` |
| `fieldId` | `java.lang.Long` |
| `fieldName` | `java.lang.String` |
| `type` | `com.seeyon.bpm.enums.BpmFormPermissionContentTypeEnum` |
| `widgetDeviceType` | `com.seeyon.bpm.enums.BpmDeviceTypeEnum` |
| `content` | `java.lang.String` |
| `fieldPath` | `java.lang.String` |
| `pageAuth` | `java.lang.Boolean` |
| `required` | `java.lang.Boolean` |
| `requiredExpr` | `java.lang.String` |
| `widgetStatus` | `java.lang.String` |
| `widgetStatusExpr` | `java.lang.String` |
| `initValue` | `java.lang.String` |
| `initValueExpr` | `java.lang.String` |
| `title` | `java.lang.String` |
| `desensitized` | `com.seeyon.bpm.enums.BpmFormDesensitizedTypeEnum` |
| `dataStatus` | `java.lang.String` |
| `sendButton` | `java.lang.Boolean` |
| `initValueTriggerConditionEnum` | `com.seeyon.bpm.enums.BpmFormPermissionContentInitValueTriggerConditionEnum` |

## `BpmNodePermissionAddDto`（21 字段）

`com.seeyon.bpm.dto.BpmNodePermissionAddDto`

被这些方法当入参：

- `BpmApiNodePermissionAppService.savePermission()`（包装入参）
- `BpmApiNodePermissionAppService.savePermissionList()`（裸参数）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `appName` | `java.lang.String` |
| `applicationName` | `java.lang.String` |
| `applicationId` | `java.lang.Long` |
| `name` | `java.lang.String` |
| `type` | `com.seeyon.bpm.enums.BpmNodePermissionTypeEnum` |
| `operationList` | `java.util.List<com.seeyon.bpm.dto.BpmNodeOperationSaveDto>` |
| `designState` | `com.seeyon.bpm.enums.BpmTemplateDesignState` |
| `userId` | `java.lang.Long` |
| `dataLevel` | `com.seeyon.bpm.enums.BpmNodePermissionDataLevelEnum` |
| `orgId` | `java.lang.Long` |
| `subApp` | `java.lang.String` |
| `mobileFrame` | `java.lang.String` |
| `pcFrame` | `java.lang.String` |
| `orderNum` | `java.lang.Integer` |
| `systemInit` | `java.lang.Boolean` |
| `fromDubbo` | `java.lang.Boolean` |
| `contentDtos` | `java.util.List<com.seeyon.bpm.dto.BpmFormPermissionContentDto>` |
| `assembleList` | `java.util.List<com.seeyon.bpm.dto.BpmNodePermissionSaveAssembleDto>` |
| `batchAble` | `java.lang.Boolean` |
| `bpmOrgScopeDto` | `com.seeyon.bpm.dto.BpmOrgScopeDto` |

## `BpmThirdTemplateCreateOrUpdateDto`（19 字段）

`com.seeyon.bpm.dto.BpmThirdTemplateCreateOrUpdateDto`

被这些方法当入参：

- `BpmThirdTemplateSyncAppService.createBatch()`（裸参数）
- `BpmThirdTemplateSyncAppService.updateBatch()`（裸参数）

| 字段 | 类型 |
|---|---|
| `id` | `java.lang.Long` |
| `guid` | `java.lang.Long` |
| `sourceType` | `com.seeyon.bpm.enums.ThirdTemplateTypeEnum` |
| `subject` | `java.lang.String` |
| `code` | `java.lang.String` |
| `pageUrl` | `java.lang.String` |
| `mobilePageUrl` | `java.lang.String` |
| `state` | `com.seeyon.bpm.enums.TemplateStateEnum` |
| `authorized` | `java.lang.String` |
| `formPicStorageKey` | `java.lang.String` |
| `diagramPicStorageKey` | `java.lang.String` |
| `categoryId` | `java.lang.Long` |
| `tags` | `java.lang.String` |
| `description` | `java.lang.String` |
| `createAccountId` | `java.lang.Long` |
| `docStorageKey` | `java.lang.String` |
| `desStorageKey` | `java.lang.String` |
| `interfaceInfo` | `java.lang.String` |
| `isEnable` | `java.lang.Boolean` |

## `BpmProcessTrackReqDto`（16 字段）

`com.seeyon.bpm.dto.BpmProcessTrackReqDto`

被这些方法当入参：

- `BpmProcessTrackAppService.selectProcessTrackList()`（包装入参）
- `BpmProcessTrackAppService.countAttentionForBadge()`（包装入参）

| 字段 | 类型 |
|---|---|
| `caseTitle` | `java.lang.String` |
| `startMemberId` | `java.lang.Long` |
| `startMemberIds` | `java.util.List<java.lang.Long>` |
| `startTimeLess` | `java.util.Date` |
| `startTimeGreater` | `java.util.Date` |
| `userId` | `java.lang.Long` |
| `billCode` | `java.lang.String` |
| `loginOrgId` | `java.lang.Long` |
| `appNameList` | `java.util.List<java.lang.String>` |
| `templateGuids` | `java.util.List<java.lang.Long>` |
| `caseIds` | `java.util.List<java.lang.Long>` |
| `objectStateList` | `java.util.List<java.lang.Integer>` |
| `onlyShowCurrentOrgData` | `boolean` |
| `conditionRelation` | `boolean` |
| `pageInfo` | `com.seeyon.boot.transport.PageInfo` |
| `sort` | `com.seeyon.boot.transport.Sort` |

## `BpmStopDto`（16 字段）

`com.seeyon.bpm.dto.BpmStopDto`

被这些方法当入参：

- `BpmUdcApiService.stopForUdc()`（包装入参）

| 字段 | 类型 |
|---|---|
| `isStartNode` | `java.lang.Boolean` |
| `workItemId` | `java.lang.Long` |
| `caseId` | `java.lang.Long` |
| `subProcessStopIfGoNext` | `java.lang.Boolean` |
| `check` | `java.lang.Boolean` |
| `stopType` | `com.seeyon.bpm.enums.BpmStopType` |
| `bindParameters` | `java.util.Map<java.lang.String, java.lang.Object>` |
| `currentUserId` | `java.lang.Long` |
| `currentAccountId` | `java.lang.Long` |
| `formRecordId` | `java.lang.Long` |
| `formAppId` | `java.lang.Long` |
| `appTemplateId` | `java.lang.Long` |
| `extendParam` | `java.util.Map<java.lang.String, java.lang.Object>` |
| `opinion` | `java.lang.String` |
| `attitude` | `java.lang.Integer` |
| `opinionId` | `java.lang.Long` |

## `BpmSaveDraftUdcDto`（16 字段）

`com.seeyon.bpm.dto.approval.BpmSaveDraftUdcDto`

被这些方法当入参：

- `BpmUdcApiService.saveDraft()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `templateId` | `java.lang.Long` |
| `rootEntityId` | `java.lang.Long` |
| `rootEntityName` | `java.lang.String` |
| `userId` | `java.lang.Long` |
| `commentDto` | `com.seeyon.bpm.dto.BpmCommentDto` |
| `formData` | `java.util.Map<java.lang.String, java.lang.Object>` |
| `formRecordId` | `java.lang.Long` |
| `templateGuid` | `java.lang.Long` |
| `pageUrl` | `java.lang.String` |
| `pageType` | `com.seeyon.bpm.enums.PageTypeEnum` |
| `pageGuid` | `java.lang.Long` |
| `bpmOperationNodeDto` | `com.seeyon.bpm.dto.BpmOperationNodeDto` |
| `pageParameter` | `java.lang.String` |
| `affairId` | `java.lang.Long` |
| `trackRequestDto` | `com.seeyon.bpm.dto.TrackRequestDto` |

## `BpmSendUdcDto`（16 字段）

`com.seeyon.bpm.dto.approval.BpmSendUdcDto`

被这些方法当入参：

- `BpmUdcApiService.sendForUdc()`（包装入参）

| 字段 | 类型 |
|---|---|
| `templateId` | `java.lang.Long` |
| `rootEntityId` | `java.lang.Long` |
| `rootEntityName` | `java.lang.String` |
| `caseId` | `java.lang.Long` |
| `userId` | `java.lang.Long` |
| `commentDto` | `com.seeyon.bpm.dto.BpmCommentDto` |
| `preMatchRequestDto` | `com.seeyon.bpm.dto.PreMatchRequestDto` |
| `formData` | `java.util.Map<java.lang.String, java.lang.Object>` |
| `formRecordId` | `java.lang.Long` |
| `applicationName` | `java.lang.String` |
| `startFormUrl` | `java.lang.String` |
| `changeNodeRequestDtos` | `java.util.List<com.seeyon.bpm.dto.ChangeNodeRequestDto>` |
| `informAddSelectPeoples` | `java.lang.String` |
| `commentRequired` | `boolean` |
| `affairId` | `java.lang.Long` |
| `trackRequestDto` | `com.seeyon.bpm.dto.TrackRequestDto` |

## `BpmInputOpinionDto`（16 字段）

`com.seeyon.bpm.dto.opinion.BpmInputOpinionDto`

被这些方法当入参：

- `BpmOpinionAppService.createBatch()`（裸参数）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `id` | `java.lang.Long` |
| `objectId` | `java.lang.Long` |
| `actionTime` | `java.util.Date` |
| `extString1` | `java.lang.String` |
| `affairId` | `java.lang.Long` |
| `appName` | `java.lang.String` |
| `userId` | `java.lang.Long` |
| `orgId` | `java.lang.Long` |
| `content` | `java.lang.String` |
| `richContent` | `java.lang.String` |
| `attachmentStorageIds` | `java.util.List<com.seeyon.bpm.dto.BpmAttachmentStorageDto>` |
| `associateDocumentDtoList` | `java.util.List<com.seeyon.bpm.dto.opinion.BpmOpinionAssociateDocumentDto>` |
| `needAtUser` | `java.lang.Boolean` |
| `isMentionAll` | `java.lang.Boolean` |
| `userIds` | `java.util.List<java.lang.Long>` |

## `BpmNodePermissionRequestDto`（15 字段）

`com.seeyon.bpm.dto.approval.BpmNodePermissionRequestDto`

被这些方法当入参：

- `BpmUdcApiService.getNodePermissionOperation()`（包装入参）
- `BpmUdcApiService.getNodePermission()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `affairId` | `java.lang.Long` |
| `templateId` | `java.lang.Long` |
| `workItemId` | `java.lang.Long` |
| `detailType` | `com.seeyon.bpm.enums.BpmDetailTypeEnum` |
| `templateGuid` | `java.lang.Long` |
| `rootEntityName` | `java.lang.String` |
| `pageUrl` | `java.lang.String` |
| `pageType` | `com.seeyon.bpm.enums.PageTypeEnum` |
| `pageGuId` | `java.lang.Long` |
| `userId` | `java.lang.Long` |
| `caseId` | `java.lang.Long` |
| `permissionId` | `java.lang.Long` |
| `pageParameter` | `java.lang.String` |
| `vid` | `java.lang.Long` |

## `BaseBpmHandlerParamDto`（14 字段）

`com.seeyon.bpm.dto.BaseBpmHandlerParamDto`

被这些方法当入参：

- `BpmTemplateAppService.selectEffectedDiagramListByAppName()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `check` | `java.lang.Boolean` |
| `hasOvertime` | `java.lang.Boolean` |
| `bindParameters` | `java.util.Map<java.lang.String, java.lang.Object>` |
| `currentUserId` | `java.lang.Long` |
| `currentAccountId` | `java.lang.Long` |
| `objectId` | `java.lang.Long` |
| `formRecordId` | `java.lang.Long` |
| `formAppId` | `java.lang.Long` |
| `applicationName` | `java.lang.String` |
| `appTemplateId` | `java.lang.Long` |
| `extendParam` | `java.util.Map<java.lang.String, java.lang.Object>` |
| `opinion` | `java.lang.String` |
| `agent` | `java.lang.Boolean` |

## `BpmTriggerFlowUdcRequestDto`（14 字段）

`com.seeyon.bpm.dto.approval.BpmTriggerFlowUdcRequestDto`

被这些方法当入参：

- `BpmUdcApiService.triggerFlowForUdc()`（裸参数）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `templateId` | `java.lang.Long` |
| `rootEntityId` | `java.lang.Long` |
| `rootEntityName` | `java.lang.String` |
| `userId` | `java.lang.Long` |
| `commentDto` | `com.seeyon.bpm.dto.BpmCommentDto` |
| `formData` | `java.util.Map<java.lang.String, java.lang.Object>` |
| `formRecordId` | `java.lang.Long` |
| `templateGuid` | `java.lang.Long` |
| `pageUrl` | `java.lang.String` |
| `pageType` | `com.seeyon.bpm.enums.PageTypeEnum` |
| `pageGuid` | `java.lang.Long` |
| `needSend` | `java.lang.Boolean` |
| `pageParameter` | `java.lang.String` |

## `BpmActivitySubmitDto`（12 字段）

`com.seeyon.bpm.dto.activity.BpmActivitySubmitDto`

被这些方法当入参：

- `BpmActionAppService.activitySubmit()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `caseId` | `java.lang.Long` |
| `activityId` | `java.lang.Long` |
| `currentUserId` | `java.lang.Long` |
| `currentAccountId` | `java.lang.Long` |
| `formData` | `java.util.Map<java.lang.String, java.lang.Object>` |
| `preMatchRequestDto` | `com.seeyon.bpm.dto.PreMatchRequestDto` |
| `activityCode` | `java.lang.String` |
| `finishType` | `com.seeyon.bpm.enums.BpmFinishType` |
| `opinionContent` | `java.lang.String` |
| `deleteDone` | `java.lang.Boolean` |
| `mainPreMatchRequestDto` | `com.seeyon.bpm.dto.PreMatchRequestDto` |

## `BpmForwardDataHandlerReqDto`（12 字段）

`com.seeyon.bpm.subscribe.dto.BpmForwardDataHandlerReqDto`

被这些方法当入参：

- `BpmForwardDataSubscribe.handler()`（包装入参）

| 字段 | 类型 |
|---|---|
| `caseId` | `java.lang.Long` |
| `pageType` | `com.seeyon.bpm.enums.PageTypeEnum` |
| `originAppName` | `java.lang.String` |
| `originCaseId` | `java.lang.Long` |
| `originAffairId` | `java.lang.Long` |
| `originFormRecordId` | `java.lang.Long` |
| `originRootEntityName` | `java.lang.String` |
| `originData` | `java.lang.Object` |
| `originPageGuid` | `java.lang.Long` |
| `originPageUrl` | `java.lang.String` |
| `userId` | `java.lang.Long` |
| `orgId` | `java.lang.Long` |

## `BpmActivityRunDto`（11 字段）

`com.seeyon.bpm.dto.BpmActivityRunDto`

被这些方法当入参：

- `BpmActivityAppService.create()`（包装入参）
- `BpmActivityAppService.createBatch()`（裸参数）

| 字段 | 类型 |
|---|---|
| `processId` | `java.lang.Long` |
| `activityId` | `java.lang.Long` |
| `activityName` | `java.lang.String` |
| `activityCode` | `java.lang.String` |
| `activityType` | `com.seeyon.bpm.enums.BpmActivityTypeEnum` |
| `caseId` | `java.lang.Long` |
| `state` | `com.seeyon.bpm.enums.ActivityStateEnum` |
| `oldState` | `com.seeyon.bpm.enums.ActivityStateEnum` |
| `delete` | `java.lang.Boolean` |
| `nodeName` | `java.lang.String` |
| `nodeCode` | `java.lang.String` |

## `BpmApplicationOperateLogInfoDto`（11 字段）

`com.seeyon.bpm.dto.BpmApplicationOperateLogInfoDto`

被这些方法当入参：

- `BpmApplicationOperateLogAppService.saveApplicationOperateLog()`（包装入参）
- `BpmApplicationOperateLogAppService.updateAppLogs()`（裸参数）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `operateType` | `java.lang.String` |
| `content` | `java.lang.String` |
| `applicationId` | `java.lang.Long` |
| `operateUserName` | `java.lang.String` |
| `operateUserId` | `java.lang.Long` |
| `orgId` | `java.lang.Long` |
| `createTime` | `java.util.Date` |
| `updateTime` | `java.util.Date` |
| `id` | `java.lang.Long` |
| `extraInfo` | `java.lang.String` |

## `BpmStepBackDto`（11 字段）

`com.seeyon.bpm.dto.operation.openapi.BpmStepBackDto`

被这些方法当入参：

- `BpmAppService.stepBack()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `affairId` | `java.lang.Long` |
| `caseId` | `java.lang.Long` |
| `pendingNodeId` | `java.lang.String` |
| `currentUserId` | `java.lang.Long` |
| `bpmCommentDto` | `com.seeyon.bpm.dto.BpmCommentDto` |
| `formData` | `java.util.Map<java.lang.String, java.lang.Object>` |
| `submitStyleAfterStepBack` | `com.seeyon.bpm.enums.AppointStepBackStyleEnum` |
| `nodeToMeItem` | `com.seeyon.bpm.enums.StepBackNodeToMeSubmitModeEnum` |
| `selectTargetNodeId` | `java.lang.String` |
| `targetNodePeopleNeedReMatch` | `java.lang.Boolean` |

## `BpmSaveAsDto`（11 字段）

`com.seeyon.bpm.dto.transport.BpmSaveAsDto`

被这些方法当入参：

- `BpmApiTransportAppService.saveAs()`（包装入参）

| 字段 | 类型 |
|---|---|
| `currentApplicationId` | `java.lang.Long` |
| `oldApplicationName` | `java.lang.String` |
| `newApplicationName` | `java.lang.String` |
| `oldBasePackage` | `java.lang.String` |
| `newBasePackage` | `java.lang.String` |
| `formPermissionIdMap` | `java.util.Map<java.lang.Long, java.lang.Long>` |
| `oldEntityNameToNewEntityName` | `java.util.Map<java.lang.String, java.lang.String>` |
| `entityCodeMap` | `java.util.Map<java.lang.String, java.lang.String>` |
| `extProps` | `java.util.Map<java.lang.String, java.lang.Object>` |
| `guidMap` | `java.util.Map<java.lang.String, java.lang.String>` |
| `applicationVersion` | `java.lang.String` |

## `BpmAppInfoDto`（10 字段）

`com.seeyon.bpm.dto.BpmAppInfoDto`

被这些方法当入参：

- `BpmApiPermissionAppService.checkApplicationPermission()`（裸参数）
- `BpmDeployAppService.autoDeployStartAndAuth()`（包装入参）
- `BpmDeployAppService.usedFrames()`（包装入参）
- `BpmTemplateAppService.publishCheckByAppInfo()`（包装入参）
- `BpmTemplateAppService.publishLockByAppInfo()`（包装入参）
- `BpmTemplateManageAppService.closeLowerVersionGrayAndStarted()`（裸参数）
- … 另 1 处

| 字段 | 类型 |
|---|---|
| `deployId` | `java.lang.String` |
| `appId` | `java.lang.Long` |
| `appGuid` | `java.lang.Long` |
| `appCaption` | `java.lang.String` |
| `appName` | `java.lang.String` |
| `appVersion` | `java.lang.String` |
| `showVersion` | `java.lang.String` |
| `currentVersion` | `java.lang.String` |
| `orgId` | `java.lang.Long` |
| `categoryId` | `java.lang.Long` |

## `BpmApprovalResultData`（10 字段）

`com.seeyon.bpm.dto.message.BpmApprovalResultData`

被这些方法当入参：

- `UdcBpmProcessService.processBpmApproval()`（包装入参）
- `UdcBpmProcessService.processBpmTakeBack()`（包装入参）

| 字段 | 类型 |
|---|---|
| `caseId` | `java.lang.Long` |
| `subject` | `java.lang.String` |
| `appName` | `java.lang.String` |
| `currentUserId` | `java.lang.Long` |
| `caseState` | `com.seeyon.bpm.enums.CaseStateEnum` |
| `approvalState` | `com.seeyon.bpm.enums.CaseApprovalState` |
| `rootEntityFullName` | `java.lang.String` |
| `formRecordId` | `java.lang.Long` |
| `formRecordCode` | `java.lang.String` |
| `commentDto` | `com.seeyon.bpm.dto.BpmCommentDto` |

## `BpmSendDto`（10 字段）

`com.seeyon.bpm.dto.operation.openapi.BpmSendDto`

被这些方法当入参：

- `BpmAppService.send()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `templateCode` | `java.lang.String` |
| `templateId` | `java.lang.Long` |
| `currentUserId` | `java.lang.Long` |
| `orgId` | `java.lang.Long` |
| `bpmCommentDto` | `com.seeyon.bpm.dto.BpmCommentDto` |
| `formRecordId` | `java.lang.String` |
| `parameterData` | `java.util.Map<java.lang.String, java.lang.Object>` |
| `caseId` | `java.lang.Long` |
| `sendPolicy` | `java.lang.String` |

## `BpmSubmitDto`（10 字段）

`com.seeyon.bpm.dto.operation.openapi.BpmSubmitDto`

被这些方法当入参：

- `BpmAppService.submit()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `affairId` | `java.lang.Long` |
| `currentUserId` | `java.lang.Long` |
| `orgId` | `java.lang.Long` |
| `bpmCommentDto` | `com.seeyon.bpm.dto.BpmCommentDto` |
| `formData` | `java.util.Map<java.lang.String, java.lang.Object>` |
| `changeNodeRequestDtos` | `java.util.List<com.seeyon.bpm.dto.ChangeNodeRequestDto>` |
| `preMatchRequestDto` | `com.seeyon.bpm.dto.PreMatchRequestDto` |
| `onlyCheck` | `java.lang.Boolean` |
| `operationType` | `com.seeyon.bpm.enums.OperationEnum` |

## `BpmOpinionUpdateDto`（10 字段）

`com.seeyon.bpm.dto.opinion.BpmOpinionUpdateDto`

被这些方法当入参：

- `BpmOpinionAppService.updateOpinion()`（包装入参）

| 字段 | 类型 |
|---|---|
| `userId` | `java.lang.Long` |
| `id` | `java.lang.Long` |
| `objectId` | `java.lang.Long` |
| `content` | `java.lang.String` |
| `richContent` | `java.lang.String` |
| `attachmentStorageIds` | `java.util.List<com.seeyon.bpm.dto.BpmAttachmentStorageDto>` |
| `associateDocument` | `java.util.List<com.seeyon.bpm.dto.opinion.BpmOpinionAssociateDocumentDto>` |
| `hidden` | `java.lang.Boolean` |
| `showPerson` | `java.lang.String` |
| `actionTime` | `java.util.Date` |

## `BpmTransportRequestDto`（10 字段）

`com.seeyon.bpm.dto.transport.BpmTransportRequestDto`

被这些方法当入参：

- `BpmApiTransportAppService.asyncTransportRequest()`（包装入参）

| 字段 | 类型 |
|---|---|
| `operationEnum` | `com.seeyon.bpm.enums.BpmTransportOperationEnum` |
| `conflictType` | `com.seeyon.bpm.enums.TransportConflictTypeEnum` |
| `ossKey` | `java.lang.String` |
| `cover` | `java.lang.Boolean` |
| `userId` | `java.lang.Long` |
| `appLogId` | `java.lang.Long` |
| `taskId` | `java.lang.Long` |
| `metadataStorageKey` | `java.lang.String` |
| `fileDtoStorageKey` | `java.lang.String` |
| `publishTemplateList` | `java.util.List<java.lang.Long>` |

## `BpmFormPermissionSearchRequestDto`（9 字段）

`com.seeyon.bpm.dto.BpmFormPermissionSearchRequestDto`

被这些方法当入参：

- `BpmApiFormPermissionAppService.selectFormPermissionList()`（包装入参）
- `BpmApiFormPermissionAppService.selectFormPermissionIncludeContentList()`（裸参数）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `appId` | `java.lang.Long` |
| `applicationName` | `java.lang.String` |
| `rootEntityName` | `java.lang.String` |
| `designState` | `com.seeyon.bpm.enums.BpmTemplateDesignState` |
| `state` | `com.seeyon.bpm.enums.TemplateStateEnum` |
| `orgId` | `java.lang.Long` |
| `pcSubPage` | `java.lang.String` |
| `currentVersion` | `java.lang.String` |

## `BpmPrefixForUdcDto`（9 字段）

`com.seeyon.bpm.dto.BpmPrefixForUdcDto`

被这些方法当入参：

- `BpmUdcApiService.prefixForUdc()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `templateId` | `java.lang.Long` |
| `templateGuid` | `java.lang.Long` |
| `rootEntityName` | `java.lang.String` |
| `pageUrl` | `java.lang.String` |
| `pageType` | `com.seeyon.bpm.enums.PageTypeEnum` |
| `pageGuid` | `java.lang.Long` |
| `pageParameter` | `java.lang.String` |
| `caseId` | `java.lang.Long` |

## `BpmAddExecuteUserDto`（9 字段）

`com.seeyon.bpm.dto.operation.openapi.BpmAddExecuteUserDto`

被这些方法当入参：

- `BpmAppService.addExecuteMember()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `caseId` | `java.lang.Long` |
| `activityId` | `java.lang.Long` |
| `currentUserId` | `java.lang.Long` |
| `currentUserName` | `java.lang.String` |
| `mobileFrame` | `java.lang.String` |
| `pcFrame` | `java.lang.String` |
| `executeUserList` | `java.util.List<com.seeyon.bpm.dto.match.BpmUserDto>` |
| `allowDuplicateAdditions` | `java.lang.Boolean` |

## `BpmTemplateAppSearchDto`（8 字段）

`com.seeyon.bpm.dto.BpmTemplateAppSearchDto`

被这些方法当入参：

- `BpmTemplateAppService.selectTemplateBySearchDto()`（包装入参）

| 字段 | 类型 |
|---|---|
| `name` | `java.lang.String` |
| `orgId` | `java.lang.Long` |
| `applicationName` | `java.lang.String` |
| `designState` | `com.seeyon.bpm.enums.BpmTemplateDesignState` |
| `state` | `com.seeyon.bpm.enums.TemplateStateEnum` |
| `draftVersion` | `java.lang.String` |
| `enabled` | `java.lang.Boolean` |
| `rootEntityName` | `java.lang.String` |

## `BpmTriggerFlowUdcFinishDto`（8 字段）

`com.seeyon.bpm.dto.BpmTriggerFlowUdcFinishDto`

被这些方法当入参：

- `DataFlowForBpmAppService.asyncTriggerFlowForBpm()`（包装入参）

| 字段 | 类型 |
|---|---|
| `entityFullName` | `java.lang.String` |
| `currentRunAppName` | `java.lang.String` |
| `appName` | `java.lang.String` |
| `appCaption` | `java.lang.String` |
| `serviceFullName` | `java.lang.String` |
| `autoProcess` | `boolean` |
| `storageKey` | `java.lang.String` |
| `responseDtoList` | `java.util.List<com.seeyon.bpm.dto.approval.BpmTriggerFlowUdcResponseDto>` |

## `BpmAsyncTriggerFlowUdcRequestDto`（8 字段）

`com.seeyon.bpm.dto.approval.BpmAsyncTriggerFlowUdcRequestDto`

被这些方法当入参：

- `BpmUdcApiService.asyncTriggerFlowForUdc()`（包装入参）

| 字段 | 类型 |
|---|---|
| `entityFullName` | `java.lang.String` |
| `currentRunAppName` | `java.lang.String` |
| `appName` | `java.lang.String` |
| `appCaption` | `java.lang.String` |
| `serviceFullName` | `java.lang.String` |
| `autoProcess` | `boolean` |
| `storageKey` | `java.lang.String` |
| `requestDtoList` | `java.util.List<com.seeyon.bpm.dto.approval.BpmTriggerFlowUdcRequestDto>` |

## `BpmAutoApprovalUpdateDto`（8 字段）

`com.seeyon.bpm.dto.autoapproval.BpmAutoApprovalUpdateDto`

被这些方法当入参：

- `BpmAutoApprovalAppService.designerUpdate()`（包装入参）

| 字段 | 类型 |
|---|---|
| `id` | `java.lang.Long` |
| `user` | `java.lang.Long` |
| `templateId` | `java.lang.Long` |
| `processId` | `java.lang.Long` |
| `activityId` | `java.lang.Long` |
| `defaultExpression` | `java.lang.String` |
| `userId` | `java.lang.Long` |
| `orgId` | `java.lang.Long` |

## `BpmNodePermissionSearchRequestDto`（8 字段）

`com.seeyon.bpm.dto.nodepermission.BpmNodePermissionSearchRequestDto`

被这些方法当入参：

- `BpmApiNodePermissionAppService.queryPermissionList()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `applicationName` | `java.lang.String` |
| `loginOrgId` | `java.lang.Long` |
| `nodeName` | `java.lang.String` |
| `needNoTemplatePermission` | `java.lang.Boolean` |
| `applicationId` | `java.lang.Long` |
| `needOperation` | `java.lang.Boolean` |
| `needContent` | `java.lang.Boolean` |

## `BpmInformDto`（8 字段）

`com.seeyon.bpm.dto.operation.openapi.BpmInformDto`

被这些方法当入参：

- `BpmAppService.inform()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `affairId` | `java.lang.Long` |
| `informUsers` | `java.util.List<com.seeyon.bpm.dto.operation.openapi.SelectPeopleInfoDto>` |
| `informUsersFromOrg` | `java.lang.String` |
| `comments` | `java.lang.String` |
| `userId` | `java.lang.Long` |
| `formPermissionId` | `java.lang.Long` |
| `extParam` | `java.util.Map` |

## `BpmRepealDto`（8 字段）

`com.seeyon.bpm.dto.operation.openapi.BpmRepealDto`

被这些方法当入参：

- `BpmAppService.repeal()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `affairId` | `java.lang.Long` |
| `caseId` | `java.lang.Long` |
| `currentUserId` | `java.lang.Long` |
| `bpmCommentDto` | `com.seeyon.bpm.dto.BpmCommentDto` |
| `formData` | `java.util.Map<java.lang.String, java.lang.Object>` |
| `needCheckAuth` | `java.lang.Boolean` |
| `needCheckPermission` | `java.lang.Boolean` |

## `BpmSaveDraftDto`（8 字段）

`com.seeyon.bpm.dto.operation.openapi.BpmSaveDraftDto`

被这些方法当入参：

- `BpmAppService.saveDraft()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `templateCode` | `java.lang.String` |
| `templateId` | `java.lang.Long` |
| `currentUserId` | `java.lang.Long` |
| `bpmCommentDto` | `com.seeyon.bpm.dto.BpmCommentDto` |
| `formRecordId` | `java.lang.String` |
| `formData` | `java.util.Map<java.lang.String, java.lang.Object>` |
| `caseId` | `java.lang.Long` |

## `BpmActivityResponsibilityDto`（7 字段）

`com.seeyon.bpm.dto.BpmActivityResponsibilityDto`

被这些方法当入参：

- `BpmThirdTemplateSyncAppService.createActivityResponsibilities()`（裸参数）

| 字段 | 类型 |
|---|---|
| `templateId` | `java.lang.String` |
| `activityName` | `java.lang.String` |
| `activityPermissionName` | `java.lang.String` |
| `activityPermissionType` | `com.seeyon.bpm.enums.BpmNodePermissionTypeEnum` |
| `dealTime` | `java.lang.String` |
| `activityDesc` | `java.lang.String` |
| `sortNum` | `java.lang.Integer` |

## `BpmDetectionEntityDto`（7 字段）

`com.seeyon.bpm.dto.BpmDetectionEntityDto`

被这些方法当入参：

- `BpmApiDetectionService.cascadeHandleAffectedForEntity()`（包装入参）

| 字段 | 类型 |
|---|---|
| `id` | `java.lang.Long` |
| `oldFullName` | `java.lang.String` |
| `newFullName` | `java.lang.String` |
| `isRootEntity` | `java.lang.Boolean` |
| `oldCode` | `java.lang.String` |
| `newCode` | `java.lang.String` |
| `rootEntityFullName` | `java.lang.String` |

## `BpmStartTemplateDto`（7 字段）

`com.seeyon.bpm.dto.BpmStartTemplateDto`

被这些方法当入参：

- `BpmTemplateAppService.startCheck()`（包装入参）
- `BpmTemplateAppService.startByTemplateId()`（包装入参）
- `BpmTemplateAppService.startByTemplateIdWithoutAuth()`（包装入参）
- `BpmTemplateAppService.updateEffectTimeByTemplateId()`（包装入参）

| 字段 | 类型 |
|---|---|
| `templateId` | `java.lang.Long` |
| `applicationName` | `java.lang.String` |
| `effectTime` | `java.util.Date` |
| `invalidTime` | `java.util.Date` |
| `forceStart` | `java.lang.Boolean` |
| `appName` | `java.lang.String` |
| `appVersion` | `java.lang.String` |

## `SimpleChangeProcessRequestDto`（7 字段）

`com.seeyon.bpm.dto.SimpleChangeProcessRequestDto`

被这些方法当入参：

- `BpmAppService.counterSignNode()`（包装入参）
- `BpmAppService.addNode()`（包装入参）

| 字段 | 类型 |
|---|---|
| `processId` | `java.lang.Long` |
| `processJson` | `java.lang.String` |
| `saveProcess` | `boolean` |
| `currentActivityId` | `java.lang.String` |
| `workItemId` | `java.lang.String` |
| `needInsertLog` | `boolean` |
| `simpleChangeNodeParameterDto` | `com.seeyon.bpm.dto.SimpleChangeNodeParameterDto` |

## `BpmBatchReqDto`（7 字段）

`com.seeyon.bpm.dto.approval.BpmBatchReqDto`

被这些方法当入参：

- `BpmAppService.batchDeal()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `userId` | `java.lang.Long` |
| `comment` | `java.lang.String` |
| `affairIdList` | `java.util.List<java.lang.Long>` |
| `subDataList` | `java.util.List<com.seeyon.bpm.dto.approval.BpmBatchSubReqDto>` |
| `pageType` | `com.seeyon.bpm.enums.PageTypeEnum` |
| `operationCaption` | `java.lang.String` |

## `BpmAutoApprovalCreateDto`（7 字段）

`com.seeyon.bpm.dto.autoapproval.BpmAutoApprovalCreateDto`

被这些方法当入参：

- `BpmAutoApprovalAppService.designerCreate()`（包装入参）

| 字段 | 类型 |
|---|---|
| `user` | `java.lang.Long` |
| `templateId` | `java.lang.Long` |
| `processId` | `java.lang.Long` |
| `activityId` | `java.lang.Long` |
| `defaultExpression` | `java.lang.String` |
| `currentUserId` | `java.lang.Long` |
| `orgId` | `java.lang.Long` |

## `BpmStopEvent`（7 字段）

`com.seeyon.bpm.dto.message.event.BpmStopEvent`

被这些方法当入参：

- `UdcBpmProcessService.processBpmStop()`（包装入参）

| 字段 | 类型 |
|---|---|
| `caseStartTime` | `java.util.Date` |
| `caseFinishTime` | `java.util.Date` |
| `currentActivityId` | `java.lang.Long` |
| `currentActivityName` | `java.lang.String` |
| `commentDto` | `com.seeyon.bpm.dto.BpmCommentDto` |
| `eventName` | `java.lang.String` |
| `formOperationId` | `java.lang.Long` |

## `BpmMultipleReplaceDto`（7 字段）

`com.seeyon.bpm.dto.operation.openapi.BpmMultipleReplaceDto`

被这些方法当入参：

- `BpmAppService.multipleReplace()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `caseId` | `java.lang.Long` |
| `activityId` | `java.lang.String` |
| `originalPersonData` | `java.util.List<com.seeyon.bpm.dto.operation.openapi.SelectPeopleInfoDto>` |
| `currentUserId` | `java.lang.Long` |
| `comment` | `java.lang.String` |
| `selectPeopleDatas` | `java.util.List<com.seeyon.bpm.dto.operation.openapi.SelectPeopleInfoDto>` |

## `BpmReliveFullDto`（7 字段）

`com.seeyon.bpm.dto.operation.openapi.BpmReliveFullDto`

被这些方法当入参：

- `BpmAppService.superviseReliveFull()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `needCheckAuth` | `java.lang.Boolean` |
| `activityId` | `java.lang.Long` |
| `userDtoList` | `java.util.List<com.seeyon.bpm.dto.match.BpmUserDto>` |
| `selectPeople` | `java.lang.String` |
| `afterReliveType` | `com.seeyon.bpm.enums.BpmAfterReliveTypeEnum` |
| `appCategory` | `java.lang.String` |

## `BpmSkipDto`（7 字段）

`com.seeyon.bpm.dto.operation.openapi.BpmSkipDto`

被这些方法当入参：

- `BpmSuperviseAppService.skip()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `affairId` | `java.lang.Long` |
| `activityId` | `java.lang.Long` |
| `caseId` | `java.lang.Long` |
| `currentUserId` | `java.lang.Long` |
| `commentContent` | `java.lang.String` |
| `formData` | `java.util.Map<java.lang.String, java.lang.Object>` |

## `BpmStopDto`（7 字段）

`com.seeyon.bpm.dto.operation.openapi.BpmStopDto`

被这些方法当入参：

- `BpmAppService.stop()`（包装入参）

| 字段 | 类型 |
|---|---|
| `affairId` | `java.lang.Long` |
| `caseId` | `java.lang.Long` |
| `currentUserId` | `java.lang.Long` |
| `bpmCommentDto` | `com.seeyon.bpm.dto.BpmCommentDto` |
| `formData` | `java.util.Map<java.lang.String, java.lang.Object>` |
| `needCheckAuth` | `java.lang.Boolean` |
| `needCheckPermission` | `java.lang.Boolean` |

## `BpmNodePermissionQueryConditionDto`（6 字段）

`com.seeyon.bpm.dto.nodepermission.BpmNodePermissionQueryConditionDto`

被这些方法当入参：

- `BpmApiNodePermissionAppService.selectNodePermissionListByConditions()`（包装入参）

| 字段 | 类型 |
|---|---|
| `ids` | `java.util.List<java.lang.Long>` |
| `orgIds` | `java.util.List<java.lang.Long>` |
| `applicationNames` | `java.util.List<java.lang.String>` |
| `applicationIds` | `java.util.List<java.lang.Long>` |
| `needOperation` | `java.lang.Boolean` |
| `needContent` | `java.lang.Boolean` |

## `BpmPauseDto`（6 字段）

`com.seeyon.bpm.dto.operation.openapi.BpmPauseDto`

被这些方法当入参：

- `BpmAppService.pause()`（包装入参）
- `BpmAppService.cancelPause()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `caseIds` | `java.util.List<java.lang.Long>` |
| `currentUserId` | `java.lang.Long` |
| `orgId` | `java.lang.Long` |
| `comment` | `java.lang.String` |
| `sendMessage` | `java.lang.Boolean` |

## `BpmInitParamDto`（6 字段）

`com.seeyon.bpm.dto.transport.BpmInitParamDto`

被这些方法当入参：

- `BpmDeployAppService.afterFormAppDataInit()`（包装入参）
- `BpmApiTransportAppService.getApplicationInitData()`（包装入参）
- `BpmApiTransportAppService.getApplicationInitDataAsync()`（包装入参）

| 字段 | 类型 |
|---|---|
| `sourceType` | `com.seeyon.bpm.enums.BpmTemplateSourceType` |
| `deployType` | `com.seeyon.bpm.enums.DeployTypeEnum` |
| `isRePublish` | `java.lang.Boolean` |
| `isAcross` | `java.lang.Boolean` |
| `isExport` | `java.lang.Boolean` |
| `affectRunningCase` | `java.lang.Boolean` |

## `ProcessPredictionDto`（6 字段）

`com.seeyon.bpm.simulation.dto.ProcessPredictionDto`

被这些方法当入参：

- `BpmApiSimulationAppService.selectProcessPredictionResult()`（包装入参）

| 字段 | 类型 |
|---|---|
| `templateCode` | `java.lang.String` |
| `affairId` | `java.lang.Long` |
| `caseId` | `java.lang.Long` |
| `startUserId` | `java.lang.Long` |
| `parameterData` | `java.util.Map<java.lang.String, java.lang.Object>` |
| `immediatelyExecute` | `java.lang.Boolean` |

## `BpmNormalMultiVersionSearchDto`（5 字段）

`com.seeyon.bpm.dto.BpmNormalMultiVersionSearchDto`

被这些方法当入参：

- `BpmTemplateAppService.selectNormalMultiVersionDraft()`（包装入参）

| 字段 | 类型 |
|---|---|
| `applicationName` | `java.lang.String` |
| `draftVersion` | `java.lang.String` |
| `simulation` | `java.lang.Boolean` |
| `orgId` | `java.lang.Long` |
| `rootEntityNameList` | `java.util.List<java.lang.String>` |

## `BpmTemplateParamDto`（5 字段）

`com.seeyon.bpm.dto.BpmTemplateParamDto`

被这些方法当入参：

- `BpmTemplateAppService.selectTemplateByParams()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `rootEntityName` | `java.lang.String` |
| `pageUrl` | `java.lang.String` |
| `pageType` | `com.seeyon.bpm.enums.PageTypeEnum` |
| `userId` | `java.lang.Long` |

## `DetectionFullInfoRequestDto`（5 字段）

`com.seeyon.bpm.dto.detection.DetectionFullInfoRequestDto`

被这些方法当入参：

- `BpmApiDetectionService.detection()`（包装入参）

| 字段 | 类型 |
|---|---|
| `allEnums` | `java.util.List<com.seeyon.bpm.dto.BpmDetectionCtpEnumDto>` |
| `allPages` | `java.util.List<com.seeyon.bpm.dto.BpmDetectionPageInfoDto>` |
| `allEntities` | `java.util.List<com.seeyon.bpm.dto.BpmDetectionEntityDto>` |
| `allUdcEnums` | `java.util.List<com.seeyon.bpm.dto.BpmDetectionUdcEnumDto>` |
| `allMicroFlow` | `java.util.List<java.util.Map>` |

## `BpmReliveDto`（5 字段）

`com.seeyon.bpm.dto.operation.openapi.BpmReliveDto`

被这些方法当入参：

- `BpmAppService.superviseRelive()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `caseId` | `java.lang.Long` |
| `currentUserId` | `java.lang.Long` |
| `orgId` | `java.lang.Long` |
| `comment` | `java.lang.String` |

## `BpmReplaceDto`（5 字段）

`com.seeyon.bpm.dto.operation.openapi.BpmReplaceDto`

被这些方法当入参：

- `BpmAppService.replace()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `affairId` | `java.lang.Long` |
| `currentUserId` | `java.lang.Long` |
| `bpmCommentDto` | `com.seeyon.bpm.dto.BpmCommentDto` |
| `selectPeopleDatas` | `java.lang.String` |

## `BpmTemplateOwnerSearchDto`（5 字段）

`com.seeyon.bpm.dto.operation.openapi.BpmTemplateOwnerSearchDto`

被这些方法当入参：

- `BpmTemplateAppService.selectBpmTemplateOwnerPageList()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `userId` | `java.lang.Long` |
| `sort` | `com.seeyon.boot.transport.Sort` |
| `pageInfo` | `com.seeyon.boot.transport.PageInfo` |
| `templateName` | `java.lang.String` |

## `BpmOpinionRequestDto`（5 字段）

`com.seeyon.bpm.dto.opinion.BpmOpinionRequestDto`

被这些方法当入参：

- `BpmOpinionAppService.selectOpinionGroupByActivityNodeWithObjectId()`（裸参数）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `objectId` | `java.lang.Long` |
| `dimension` | `com.seeyon.bpm.enums.BpmDimensionEnum` |
| `currentUserId` | `java.lang.Long` |
| `showPostScriptInOpinion` | `java.lang.Boolean` |

## `AppDeleteDto`（4 字段）

`com.seeyon.bpm.dto.AppDeleteDto`

被这些方法当入参：

- `BpmTemplateAppService.deleteByApps()`（裸参数）

| 字段 | 类型 |
|---|---|
| `id` | `java.lang.Long` |
| `applicationGuid` | `java.lang.Long` |
| `applicationName` | `java.lang.String` |
| `sourceType` | `com.seeyon.bpm.enums.BpmTemplateSourceType` |

## `BpmNodePermissionMaxOrderNumQueryDto`（4 字段）

`com.seeyon.bpm.dto.BpmNodePermissionMaxOrderNumQueryDto`

被这些方法当入参：

- `BpmApiNodePermissionAppService.getMaxOrderNumber()`（包装入参）

| 字段 | 类型 |
|---|---|
| `applicationName` | `java.lang.String` |
| `designState` | `com.seeyon.bpm.enums.BpmTemplateDesignState` |
| `dataLevel` | `com.seeyon.bpm.enums.BpmNodePermissionDataLevelEnum` |
| `orgId` | `java.lang.Long` |

## `BpmNodeSearchDto`（4 字段）

`com.seeyon.bpm.dto.BpmNodeSearchDto`

被这些方法当入参：

- `BpmNodeAppService.selectByTemplateAndActivityType()`（包装入参）

| 字段 | 类型 |
|---|---|
| `templateGuid` | `java.lang.Long` |
| `designState` | `com.seeyon.bpm.enums.BpmTemplateDesignState` |
| `templateId` | `java.lang.Long` |
| `activityType` | `com.seeyon.bpm.enums.BpmActivityTypeEnum` |

## `BpmUpdateCategoryDto`（4 字段）

`com.seeyon.bpm.dto.BpmUpdateCategoryDto`

被这些方法当入参：

- `BpmTemplateAppService.updateCategoryByApplicationId()`（包装入参）

| 字段 | 类型 |
|---|---|
| `applicationId` | `java.lang.Long` |
| `applicationName` | `java.lang.String` |
| `categoryId` | `java.lang.Long` |
| `oldCategoryId` | `java.lang.Long` |

## `BpmActivityTakeBackDto`（4 字段）

`com.seeyon.bpm.dto.activity.BpmActivityTakeBackDto`

被这些方法当入参：

- `BpmActionAppService.activityStepBack()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `caseId` | `java.lang.Long` |
| `activityId` | `java.lang.Long` |
| `currentUserId` | `java.lang.Long` |

## `BpmAutoApprovalSelectDto`（4 字段）

`com.seeyon.bpm.dto.autoapproval.BpmAutoApprovalSelectDto`

被这些方法当入参：

- `BpmAutoApprovalAppService.designerSelect()`（裸参数）

| 字段 | 类型 |
|---|---|
| `userName` | `java.lang.String` |
| `templateName` | `java.lang.String` |
| `currentUserId` | `java.lang.Long` |
| `orgId` | `java.lang.Long` |

## `BpmCaseLogSelectDto`（4 字段）

`com.seeyon.bpm.dto.caselog.BpmCaseLogSelectDto`

被这些方法当入参：

- `BpmCaseLogAppService.selectByDto()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `caseId` | `java.lang.Long` |
| `operationTypes` | `java.util.List<java.lang.String>` |
| `workItemId` | `java.lang.Long` |

## `DetectionAttrUpdateDto`（4 字段）

`com.seeyon.bpm.dto.detection.DetectionAttrUpdateDto`

被这些方法当入参：

- `BpmApiDetectionService.cascadeHandleAffectedForAttr()`（包装入参）

| 字段 | 类型 |
|---|---|
| `oldNewNames` | `java.util.List<com.seeyon.bpm.dto.detection.OldNewInfoDto>` |
| `rootEntityFullName` | `java.lang.String` |
| `attrBelongEntityName` | `java.lang.String` |
| `belongRootEntity` | `java.lang.Boolean` |

## `UserTemplateListRequestDto`（4 字段）

`com.seeyon.bpm.dto.formtemplate.UserTemplateListRequestDto`

被这些方法当入参：

- `BpmTemplateAppService.selectUserTemplatePageList()`（包装入参）

| 字段 | 类型 |
|---|---|
| `userId` | `java.lang.Long` |
| `keywords` | `java.lang.String` |
| `pageInfo` | `com.seeyon.boot.transport.PageInfo` |
| `categoryCode` | `java.lang.String` |

## `BpmCancelEvent`（4 字段）

`com.seeyon.bpm.dto.message.event.BpmCancelEvent`

被这些方法当入参：

- `UdcBpmProcessService.processBpmCancel()`（包装入参）

| 字段 | 类型 |
|---|---|
| `currentActivityId` | `java.lang.Long` |
| `currentActivityName` | `java.lang.String` |
| `eventName` | `java.lang.String` |
| `formOperationId` | `java.lang.Long` |

## `BpmNodePermissionBindDto`（4 字段）

`com.seeyon.bpm.dto.nodepermission.BpmNodePermissionBindDto`

被这些方法当入参：

- `BpmApiNodePermissionAppService.configNodePermissionBind()`（裸参数）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `templateId` | `java.lang.Long` |
| `nodePermissionId` | `java.lang.Long` |
| `formPermissionId` | `java.lang.Long` |

## `BpmNodePermissionOperationRequestDto`（4 字段）

`com.seeyon.bpm.dto.nodepermission.BpmNodePermissionOperationRequestDto`

被这些方法当入参：

- `BpmNodePermissionOperationAppService.getNodePermissionOperation()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `affairId` | `java.lang.Long` |
| `templateId` | `java.lang.Long` |
| `userId` | `java.lang.Long` |

## `BpmCancelItemDto`（4 字段）

`com.seeyon.bpm.dto.operation.openapi.BpmCancelItemDto`

被这些方法当入参：

- `BpmAppService.cancelItems()`（包装入参）

| 字段 | 类型 |
|---|---|
| `currentUserId` | `java.lang.Long` |
| `currentUserName` | `java.lang.String` |
| `itemIdList` | `java.util.List<java.lang.Long>` |
| `commentDto` | `com.seeyon.bpm.dto.BpmCommentDto` |

## `BpmConsultDto`（4 字段）

`com.seeyon.bpm.dto.operation.openapi.BpmConsultDto`

被这些方法当入参：

- `BpmAppService.consult()`（包装入参）

| 字段 | 类型 |
|---|---|
| `affairId` | `java.lang.Long` |
| `users` | `java.util.List<com.seeyon.bpm.dto.operation.openapi.BpmConsultantDto>` |
| `comments` | `java.lang.String` |
| `userId` | `java.lang.Long` |

## `BpmHastenDto`（4 字段）

`com.seeyon.bpm.dto.operation.openapi.BpmHastenDto`

被这些方法当入参：

- `BpmAppService.hasten()`（包装入参）

| 字段 | 类型 |
|---|---|
| `affairIds` | `java.util.List<java.lang.Long>` |
| `userId` | `java.lang.Long` |
| `hastenEnum` | `com.seeyon.bpm.enums.BpmHastenEnum` |
| `content` | `java.lang.String` |

## `BpmMonitorRunDto`（4 字段）

`com.seeyon.bpm.dto.operation.openapi.BpmMonitorRunDto`

被这些方法当入参：

- `BpmAppService.monitorNodeRun()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `caseId` | `java.lang.Long` |
| `activityId` | `java.lang.Long` |
| `data` | `java.util.Map<java.lang.String, java.lang.Object>` |

## `BpmTakeBackDto`（4 字段）

`com.seeyon.bpm.dto.operation.openapi.BpmTakeBackDto`

被这些方法当入参：

- `BpmAppService.takeBack()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `affairId` | `java.lang.Long` |
| `currentUserId` | `java.lang.Long` |
| `bpmCommentDto` | `com.seeyon.bpm.dto.BpmCommentDto` |

## `BpmPathTableDefineSearchDto`（4 字段）

`com.seeyon.bpm.dto.pathtable.BpmPathTableDefineSearchDto`

被这些方法当入参：

- `BpmTemplateAppService.selectPathTableCondition()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `applicationIds` | `java.util.List<java.lang.Long>` |
| `pageInfo` | `com.seeyon.boot.transport.PageInfo` |
| `searchName` | `java.lang.String` |

## `UdcExtensionPlanRequestDto`（4 字段）

`com.seeyon.bpm.dto.upgrade.UdcExtensionPlanRequestDto`

被这些方法当入参：

- `BpmUpgrade51To52AppService.upgradeExtensionPlan()`（裸参数）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `applicationName` | `java.lang.String` |
| `rootEntityName` | `java.lang.String` |
| `extensionPlanMap` | `java.util.Map<java.lang.String, java.lang.Long>` |

## `AppOperateLogQueryDto`（3 字段）

`com.seeyon.bpm.dto.AppOperateLogQueryDto`

被这些方法当入参：

- `BpmApplicationOperateLogAppService.selectNewestLogInfo()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `applicationId` | `java.lang.Long` |
| `orgId` | `java.lang.Long` |

## `BpmDeleteCaseDto`（3 字段）

`com.seeyon.bpm.dto.BpmDeleteCaseDto`

被这些方法当入参：

- `BpmCaseAppService.deleteCaseByIds()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `id` | `java.lang.Long` |
| `userId` | `java.lang.Long` |

## `BpmFormDesensitizedQueryDto`（3 字段）

`com.seeyon.bpm.dto.BpmFormDesensitizedQueryDto`

被这些方法当入参：

- `BpmApiFormPermissionAppService.selectFormDesensitizedList()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `formPermissionId` | `java.lang.Long` |
| `pageType` | `com.seeyon.bpm.enums.PageTypeEnum` |

## `BpmFormPermissionDeleteRequestDto`（3 字段）

`com.seeyon.bpm.dto.BpmFormPermissionDeleteRequestDto`

被这些方法当入参：

- `BpmApiFormPermissionAppService.deleteFormPermisionForceEntityDraft()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `applicationName` | `java.lang.String` |
| `formpermissionIdList` | `java.util.List<java.lang.Long>` |

## `BpmImportDto`（3 字段）

`com.seeyon.bpm.dto.BpmImportDto`

被这些方法当入参：

- `BpmApiTransportAppService.importTemplateInfo()`（包装入参）

| 字段 | 类型 |
|---|---|
| `storeKey` | `java.lang.String` |
| `needReplaceId` | `java.lang.Boolean` |
| `attachmentFileList` | `java.lang.String` |

## `BpmParameterDataDto`（3 字段）

`com.seeyon.bpm.dto.BpmParameterDataDto`

被这些方法当入参：

- `BpmApiParamAppService.saveParamData()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `processId` | `java.lang.Long` |
| `data` | `java.util.Map<java.lang.String, java.lang.Object>` |

## `BpmPreNodeSearchDto`（3 字段）

`com.seeyon.bpm.dto.BpmPreNodeSearchDto`

被这些方法当入参：

- `BpmNodeAppService.selectRunningProcessPreNode()`（包装入参）

| 字段 | 类型 |
|---|---|
| `caseId` | `java.lang.Long` |
| `currentActivityId` | `java.lang.String` |
| `currentActivityCode` | `java.lang.String` |

## `BpmTemplateAuthorizationDto`（3 字段）

`com.seeyon.bpm.dto.BpmTemplateAuthorizationDto`

被这些方法当入参：

- `BpmTemplateAppService.updateAuthorized()`（裸参数）

| 字段 | 类型 |
|---|---|
| `templateId` | `java.lang.Long` |
| `templateGuid` | `java.lang.Long` |
| `authorization` | `java.lang.String` |

## `BpmTemplateNodePerScopeDto`（3 字段）

`com.seeyon.bpm.dto.BpmTemplateNodePerScopeDto`

被这些方法当入参：

- `BpmTemplateManageAppService.configNodePermissionScope()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `templateId` | `java.lang.Long` |
| `nodePermScope` | `java.lang.String` |

## `FormalAuthTemplateQueryDto`（3 字段）

`com.seeyon.bpm.dto.FormalAuthTemplateQueryDto`

被这些方法当入参：

- `BpmTemplateManageAppService.selectFormalAuthTemplateListByQueryDto()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `appGuid` | `java.lang.Long` |
| `orgId` | `java.lang.Long` |

## `SecurityCheckDto`（3 字段）

`com.seeyon.bpm.dto.SecurityCheckDto`

被这些方法当入参：

- `BpmAppService.check()`（包装入参）

| 字段 | 类型 |
|---|---|
| `caseId` | `java.lang.Long` |
| `userId` | `java.lang.Long` |
| `affairId` | `java.lang.Long` |

## `SuperviseCancelFocusDto`（3 字段）

`com.seeyon.bpm.dto.SuperviseCancelFocusDto`

被这些方法当入参：

- `BpmSuperviseAppService.cancelFocus()`（包装入参）

| 字段 | 类型 |
|---|---|
| `vid` | `java.lang.Long` |
| `reason` | `java.lang.String` |
| `currentUserId` | `java.lang.Long` |

## `UpgradeInfoDto`（3 字段）

`com.seeyon.bpm.dto.UpgradeInfoDto`

被这些方法当入参：

- `BpmDeployAppService.upgradeCommon()`（包装入参）

| 字段 | 类型 |
|---|---|
| `exeId` | `java.lang.String` |
| `type` | `java.lang.String` |
| `param` | `java.lang.String` |

## `BpmNodeDetailReqDto`（3 字段）

`com.seeyon.bpm.dto.approval.BpmNodeDetailReqDto`

被这些方法当入参：

- `BpmTemplateAppService.selectNodeDetail()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `caseId` | `java.lang.Long` |
| `activityId` | `java.lang.Long` |

## `BpmOperationRepealUdcDto`（3 字段）

`com.seeyon.bpm.dto.approval.BpmOperationRepealUdcDto`

被这些方法当入参：

- `BpmUdcApiService.repealForUdc()`（包装入参）

| 字段 | 类型 |
|---|---|
| `commentDto` | `com.seeyon.bpm.dto.BpmCommentDto` |
| `parameterData` | `java.util.Map<java.lang.String, java.lang.Object>` |
| `caseId` | `java.lang.Long` |

## `BpmAutoApprovalDeleteDto`（3 字段）

`com.seeyon.bpm.dto.autoapproval.BpmAutoApprovalDeleteDto`

被这些方法当入参：

- `BpmAutoApprovalAppService.designerDelete()`（包装入参）

| 字段 | 类型 |
|---|---|
| `ids` | `java.util.List<java.lang.Long>` |
| `currentUserId` | `java.lang.Long` |
| `orgId` | `java.lang.Long` |

## `BpmDiagramDetailRequestDto`（3 字段）

`com.seeyon.bpm.dto.operation.openapi.BpmDiagramDetailRequestDto`

被这些方法当入参：

- `BpmApiProcessAppService.selectDiagramDetailByTemplateCodeAndVersion()`（包装入参）

| 字段 | 类型 |
|---|---|
| `templateCode` | `java.lang.String` |
| `applicationVersion` | `java.lang.String` |
| `templateState` | `com.seeyon.bpm.enums.TemplateStateEnum` |

## `BpmInitDataDto`（3 字段）

`com.seeyon.bpm.dto.transport.BpmInitDataDto`

被这些方法当入参：

- `BpmApiTransportAppService.exportTemplateInfo()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `isCopy` | `java.lang.Boolean` |
| `transportType` | `com.seeyon.bpm.enums.BpmTransportTypeEnum` |

## `BpmPublishResult`（3 字段）

`com.seeyon.bpm.dto.transport.BpmPublishResult`

被这些方法当入参：

- `BpmTemplateAppService.publishFinish()`（包装入参）

| 字段 | 类型 |
|---|---|
| `success` | `java.lang.Boolean` |
| `across` | `boolean` |
| `pushEv` | `java.lang.String` |

## `BpmAppOrgReplaceDto`（2 字段）

`com.seeyon.bpm.dto.BpmAppOrgReplaceDto`

被这些方法当入参：

- `BpmAppOrgReplaceService.replace()`（包装入参）

| 字段 | 类型 |
|---|---|
| `appGuid` | `java.lang.Long` |
| `targetOrgId` | `java.lang.Long` |

## `BpmNodePermissionInitDto`（2 字段）

`com.seeyon.bpm.dto.BpmNodePermissionInitDto`

被这些方法当入参：

- `BpmApiNodePermissionAppService.bpmNodePermissionHandel()`（包装入参）

| 字段 | 类型 |
|---|---|
| `applicationName` | `java.lang.String` |
| `accountId` | `java.lang.Long` |

## `BpmNodePermissionQueryDto`（2 字段）

`com.seeyon.bpm.dto.BpmNodePermissionQueryDto`

被这些方法当入参：

- `BpmApiNodePermissionAppService.selectNodePermissionById()`（包装入参）
- `BpmApiNodePermissionAppService.selectNodePermissionListByIds()`（包装入参）

| 字段 | 类型 |
|---|---|
| `id` | `java.lang.Long` |
| `ids` | `java.util.List<java.lang.Long>` |

## `BpmParameterDefineDto`（2 字段）

`com.seeyon.bpm.dto.BpmParameterDefineDto`

被这些方法当入参：

- `BpmApiParamAppService.saveParamSchema()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `bpmParameterSettingDtoList` | `java.util.List<com.seeyon.bpm.dto.BpmParameterSettingDto>` |

## `BpmTemplateCategorySearchDto`（2 字段）

`com.seeyon.bpm.dto.BpmTemplateCategorySearchDto`

被这些方法当入参：

- `BpmTemplateAppService.selectTemplateByCategoryIds()`（包装入参）

| 字段 | 类型 |
|---|---|
| `categoryIds` | `java.util.List<java.lang.Long>` |
| `enable` | `java.lang.Boolean` |

## `BpmTemplateExtendUpdateDto`（2 字段）

`com.seeyon.bpm.dto.BpmTemplateExtendUpdateDto`

被这些方法当入参：

- `BpmTemplateAppService.updateTemplateExtend()`（包装入参）

| 字段 | 类型 |
|---|---|
| `id` | `java.lang.Long` |
| `appBusinessData` | `java.lang.String` |

## `BpmTemplateRecentDto`（2 字段）

`com.seeyon.bpm.dto.BpmTemplateRecentDto`

被这些方法当入参：

- `BpmThirdTemplateSyncAppService.createTemplateRecent()`（包装入参）

| 字段 | 类型 |
|---|---|
| `memberId` | `java.lang.Long` |
| `templateId` | `java.lang.Long` |

## `BpmUpdateApplicationToSpecifiedInstitutionDto`（2 字段）

`com.seeyon.bpm.dto.BpmUpdateApplicationToSpecifiedInstitutionDto`

被这些方法当入参：

- `BpmNormalAppMultiVersionAppService.updateNormalApplicationToSpecifiedInstitution()`（包装入参）

| 字段 | 类型 |
|---|---|
| `appName` | `java.lang.String` |
| `institutionId` | `java.lang.Long` |

## `CurrentHighestVersionRequestDto`（2 字段）

`com.seeyon.bpm.dto.CurrentHighestVersionRequestDto`

被这些方法当入参：

- `BpmNormalAppMultiVersionAppService.selectCurrentHighestVersionBatch()`（包装入参）

| 字段 | 类型 |
|---|---|
| `applicationName` | `java.lang.String` |
| `orgIdList` | `java.util.List<java.lang.Long>` |

## `DeleteDraftReqDto`（2 字段）

`com.seeyon.bpm.dto.DeleteDraftReqDto`

被这些方法当入参：

- `BpmAppService.deleteDraftAffair()`（包装入参）

| 字段 | 类型 |
|---|---|
| `affairId` | `java.lang.Long` |
| `userId` | `java.lang.Long` |

## `SearchProcessLogInfoDto`（2 字段）

`com.seeyon.bpm.dto.SearchProcessLogInfoDto`

被这些方法当入参：

- `BpmProcessLogAppService.selectLogOriginalListByCaseIds()`（包装入参）

| 字段 | 类型 |
|---|---|
| `caseIds` | `java.util.List<java.lang.Long>` |
| `actionType` | `java.lang.String` |

## `BpmCaseFullInfoSearch`（2 字段）

`com.seeyon.bpm.dto.fullinfo.BpmCaseFullInfoSearch`

被这些方法当入参：

- `BpmAppService.selectFullCaseInfo()`（包装入参）

| 字段 | 类型 |
|---|---|
| `caseId` | `java.lang.Long` |
| `containsInvalidAffair` | `java.lang.Boolean` |

## `BpmCaseInfoSearchDto`（2 字段）

`com.seeyon.bpm.dto.operation.openapi.BpmCaseInfoSearchDto`

被这些方法当入参：

- `BpmCaseAppService.selectBpmCaseByFormRecordId()`（包装入参）

| 字段 | 类型 |
|---|---|
| `formRecordId` | `java.lang.Long` |
| `currentMemberId` | `java.lang.Long` |

## `BpmDeleteOpinionDto`（2 字段）

`com.seeyon.bpm.dto.opinion.BpmDeleteOpinionDto`

被这些方法当入参：

- `BpmOpinionAppService.deleteOpinion()`（包装入参）

| 字段 | 类型 |
|---|---|
| `opinionType` | `java.lang.Integer` |
| `affairId` | `java.lang.Long` |

## `BpmBatchAuthDto`（1 字段）

`com.seeyon.bpm.dto.BpmBatchAuthDto`

被这些方法当入参：

- `BpmTemplateManageAppService.updateAuth()`（包装入参）

| 字段 | 类型 |
|---|---|
| `authorization` | `java.util.List<com.seeyon.bpm.dto.BpmTemplateAuthorizationDto>` |

## `BpmCaseActivitySearchDto`（1 字段）

`com.seeyon.bpm.dto.BpmCaseActivitySearchDto`

被这些方法当入参：

- `BpmActivityAppService.selectBpmCaseActivityByCaseId()`（包装入参）

| 字段 | 类型 |
|---|---|
| `caseId` | `java.lang.Long` |

## `BpmGrayUpdateDto`（1 字段）

`com.seeyon.bpm.dto.BpmGrayUpdateDto`

被这些方法当入参：

- `BpmTemplateManageAppService.grayAuthTemplate()`（包装入参）

| 字段 | 类型 |
|---|---|
| `authorization` | `java.util.List<com.seeyon.bpm.dto.BpmTemplateAuthorizationDto>` |

## `SeachTemplateInfoDto`（1 字段）

`com.seeyon.bpm.dto.SeachTemplateInfoDto`

被这些方法当入参：

- `BpmTemplateAppService.selectTemplateById()`（包装入参）

| 字段 | 类型 |
|---|---|
| `templateCode` | `java.lang.String` |

## `DetectionAttrDeleteRequestDto`（1 字段）

`com.seeyon.bpm.dto.detection.DetectionAttrDeleteRequestDto`

被这些方法当入参：

- `BpmApiDetectionService.detectionForAttributeDelete()`（包装入参）

| 字段 | 类型 |
|---|---|
| `deletedParamOriginMarks` | `java.util.List<java.lang.String>` |

## `DetectionAttrUpdateRequestDto`（1 字段）

`com.seeyon.bpm.dto.detection.DetectionAttrUpdateRequestDto`

被这些方法当入参：

- `BpmApiDetectionService.detectionForAttributeUpdate()`（包装入参）

| 字段 | 类型 |
|---|---|
| `changedParams` | `java.util.Map<com.seeyon.bpm.dto.BpmDetectionParameterDto, com.seeyon.bpm.dto.BpmDetectionParameterDto>` |

## `DetectionCtpEnumDeleteRequestDto`（1 字段）

`com.seeyon.bpm.dto.detection.DetectionCtpEnumDeleteRequestDto`

被这些方法当入参：

- `BpmApiDetectionService.detectionForCtpEnumDelete()`（包装入参）

| 字段 | 类型 |
|---|---|
| `deletedCtpEnum` | `java.util.List<com.seeyon.bpm.dto.BpmDetectionCtpEnumDto>` |

## `DetectionEntityDeleteRequestDto`（1 字段）

`com.seeyon.bpm.dto.detection.DetectionEntityDeleteRequestDto`

被这些方法当入参：

- `BpmApiDetectionService.detectionForEntityDelete()`（包装入参）

| 字段 | 类型 |
|---|---|
| `deletedEntities` | `java.util.List<com.seeyon.bpm.dto.BpmDetectionEntityDto>` |

## `DetectionPageDeleteRequestDto`（1 字段）

`com.seeyon.bpm.dto.detection.DetectionPageDeleteRequestDto`

被这些方法当入参：

- `BpmApiDetectionService.detectionForPageDelete()`（包装入参）

| 字段 | 类型 |
|---|---|
| `deletedPages` | `java.util.List<com.seeyon.bpm.dto.BpmDetectionPageInfoDto>` |

## `DetectionPageUpdateRequestDto`（1 字段）

`com.seeyon.bpm.dto.detection.DetectionPageUpdateRequestDto`

被这些方法当入参：

- `BpmApiDetectionService.detectionForPageUpdate()`（包装入参）

| 字段 | 类型 |
|---|---|
| `updatePages` | `java.util.List<com.seeyon.bpm.dto.BpmDetectionPageInfoDto>` |

## `BpmTemplateSearchConditionDto`（1 字段）

`com.seeyon.bpm.dto.operation.openapi.BpmTemplateSearchConditionDto`

被这些方法当入参：

- `BpmTemplateAppService.selectTemplateListByCondition()`（包装入参）

| 字段 | 类型 |
|---|---|
| `templateCodes` | `java.util.List<java.lang.String>` |

## `NodePolicySearchDto`（1 字段）

`com.seeyon.bpm.dto.policy.NodePolicySearchDto`

被这些方法当入参：

- `BpmNodeAppService.selectNodePolicy()`（包装入参）

| 字段 | 类型 |
|---|---|
| `activityIds` | `java.util.List<java.lang.String>` |

## `BpmSplitPrepareDto`（1 字段）

`com.seeyon.bpm.dto.splitimport.BpmSplitPrepareDto`

被这些方法当入参：

- `BpmApiSplitImportAppService.prepareApp()`（包装入参）

| 字段 | 类型 |
|---|---|
| `templateIds` | `java.util.List<java.lang.Long>` |
