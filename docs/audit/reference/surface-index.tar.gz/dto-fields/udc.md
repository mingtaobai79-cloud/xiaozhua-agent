# UDC 低代码：入参 DTO 字段表

> 自动生成。包前缀 `com.seeyon.udc`。共 106 个 DTO。
> 字段类型逐字来自 javap；`static` 前缀表示常量而非实例字段。

## `ApplicationDto`（45 字段）

`com.seeyon.udc.common.dto.ApplicationDto`

被这些方法当入参：

- `UdcDataBaseSqlGenerator.getChangeList()`（裸参数）
- `UdcDataBaseSqlGenerator.getDropChangeList()`（裸参数）
- `CodeExecutor.execute()`（裸参数）
- `CodeExecutor.executeSegment()`（裸参数）
- `CodeParamInterceptor.filter()`（裸参数）
- `UdcAuditLogService.createLog4ApplicationDelete()`（裸参数）
- … 另 30 处

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `name` | `java.lang.String` |
| `deployType` | `com.seeyon.udc.common.enums.DeployTypeEnum` |
| `caption` | `java.lang.String` |
| `icon` | `java.lang.String` |
| `iconBgColor` | `java.lang.String` |
| `basePackage` | `java.lang.String` |
| `appVersion` | `java.lang.String` |
| `copVersion` | `java.lang.String` |
| `customAppVersion` | `java.lang.String` |
| `style` | `java.lang.String` |
| `description` | `java.lang.String` |
| `terminalType` | `com.seeyon.udc.common.enums.TerminalTypeEnum` |
| `minResolution` | `java.lang.String` |
| `sourceType` | `com.seeyon.udc.common.enums.ApplicationSourceEnum` |
| `featureType` | `com.seeyon.udc.common.enums.ApplicationFeatureEnum` |
| `hostAppName` | `java.lang.String` |
| `scalabilityOptionId` | `java.lang.Long` |
| `dependentApplicationDtos` | `java.util.List<com.seeyon.udc.common.dto.DependentApplicationDto>` |
| `appFrame` | `java.lang.Integer` |
| `pcAppModel` | `java.lang.Long` |
| `mobileAppModel` | `java.lang.Long` |
| `portalId` | `java.lang.Long` |
| `pcThumbnail` | `java.lang.String` |
| `mobileThumbnail` | `java.lang.String` |
| `saveAs` | `java.lang.Boolean` |
| `template` | `java.lang.Boolean` |
| `categoryId` | `java.lang.Long` |
| `sourceAppId` | `java.lang.Long` |
| `sourceAppVersion` | `java.lang.String` |
| `creator` | `java.lang.Long` |
| `orgId` | `java.lang.Long` |
| `updateTime` | `java.util.Date` |
| `createTime` | `java.util.Date` |
| `jsonPrefab` | `java.lang.Boolean` |
| `deployTime` | `java.util.Date` |
| `deployId` | `java.lang.Long` |
| `deployVersion` | `java.lang.String` |
| `deployState` | `com.seeyon.udc.common.enums.DeployStateEnum` |
| `failReason` | `java.lang.String` |
| `appOwner` | `java.lang.Long` |
| `systemTheme` | `java.lang.Boolean` |
| `appTheme` | `java.lang.Long` |
| `enableRelationEntitySelect` | `boolean` |
| `enableEditEntityTableName` | `boolean` |

## `AttributeDto`（45 字段）

`com.seeyon.udc.common.dto.AttributeDto`

被这些方法当入参：

- `TypeUpdateAuthChecker.preCheck()`（裸参数）
- `TypeUpdateAuthChecker.matchTypeChangeRule()`（裸参数）
- `TypeUpdateAuthChecker.doAttributeFieldChangeCheck()`（裸参数）
- `TypeChangeSqlResolver.match()`（裸参数）
- `TypeChangeSqlResolver.registrySql()`（裸参数）
- `TypeChangeSqlResolver.dropAndAddColumn()`（裸参数）
- … 另 11 处

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `appId` | `java.lang.Long` |
| `uniqueness` | `java.lang.Boolean` |
| `dataFormat` | `java.lang.String` |
| `expressionDesignData` | `java.lang.String` |
| `expressionRuntimeData` | `java.lang.String` |
| `defaultValueExpressionDesignData` | `java.lang.String` |
| `defaultValueExpressionRuntimeData` | `java.lang.String` |
| `defaultValueIsChange` | `java.lang.Boolean` |
| `defaultValueSystemVariable` | `java.lang.String` |
| `defaultValueCaption` | `java.lang.String` |
| `valueScopeExpression` | `java.lang.String` |
| `calculate` | `com.seeyon.boot.starter.extmetadata.enums.AttributeCalculateEnum` |
| `attributeGroup` | `java.lang.String` |
| `attributeGroupId` | `java.lang.Long` |
| `permission` | `java.lang.Boolean` |
| `auditLog` | `java.lang.Boolean` |
| `enableEncryption` | `java.lang.Boolean` |
| `encryption` | `com.seeyon.boot.annotation.enums.EncryptionType` |
| `enableDesensitization` | `java.lang.Boolean` |
| `desensitization` | `com.seeyon.boot.annotation.enums.MaskType` |
| `system` | `java.lang.Boolean` |
| `hidden` | `java.lang.Boolean` |
| `edit` | `java.lang.Boolean` |
| `entityId` | `java.lang.Long` |
| `orderNo` | `java.lang.Integer` |
| `inCondition` | `java.lang.Boolean` |
| `existDto` | `java.lang.Boolean` |
| `inDataMapping` | `java.lang.Boolean` |
| `sourceType` | `com.seeyon.boot.starter.extmetadata.enums.AttributeSourceTypeEnum` |
| `sourceId` | `java.lang.Long` |
| `serialNumberName` | `java.lang.String` |
| `serialNumberCode` | `java.lang.String` |
| `serialNumberGuid` | `java.lang.Long` |
| `parentEnumAttributeId` | `java.lang.Long` |
| `dataI18n` | `java.lang.Boolean` |
| `attributeFullName` | `java.lang.String` |
| `attribute4DtoFullName` | `java.lang.String` |
| `uniqueKey` | `java.lang.String` |
| `relationCtpEnum` | `com.seeyon.udc.common.dto.RelationCtpEnumDto` |
| `widgetConfig` | `java.lang.String` |
| `enableOpenApiEncrypt` | `java.lang.Boolean` |
| `enableSensitiveWordCheck` | `java.lang.Boolean` |
| `columnName` | `java.lang.String` |
| `useSnapshot` | `java.lang.Boolean` |

## `MicroFlowDefinitionDto`（28 字段）

`com.seeyon.udc.microflow.dto.definition.MicroFlowDefinitionDto`

被这些方法当入参：

- `MicroflowNodeParser.parse()`（裸参数）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `name` | `java.lang.String` |
| `appId` | `java.lang.Long` |
| `versionCode` | `int` |
| `caption` | `java.lang.String` |
| `creationMethod` | `com.seeyon.udc.common.enums.CreationMethodEnum` |
| `type` | `com.seeyon.udc.common.enums.MicroFlowTypeEnum` |
| `triggerType` | `com.seeyon.udc.common.enums.MicroFlowTriggerTypeEnum` |
| `groupType` | `com.seeyon.udc.common.enums.GroupTypeEnum` |
| `description` | `java.lang.String` |
| `scheduleCaption` | `java.lang.String` |
| `businessEventCaption` | `java.lang.String` |
| `orderNum` | `java.lang.Integer` |
| `state` | `com.seeyon.udc.common.enums.MicroFlowDataStateEnum` |
| `sourceId` | `java.lang.String` |
| `jsonSchema` | `java.lang.String` |
| `microFlowGroupId` | `java.lang.Long` |
| `dataSchema` | `java.lang.String` |
| `createTime` | `java.util.Date` |
| `updateTime` | `java.util.Date` |
| `serviceInterface` | `java.lang.String` |
| `openApi` | `com.seeyon.udc.common.enums.MicroFlowOpenApiStateTypeEnum` |
| `operationLog` | `com.seeyon.udc.operationlog.dto.OperationLogDetailsDto` |
| `restApi` | `com.seeyon.udc.common.enums.MicroFlowRestApiStateEnum` |
| `restPath` | `java.lang.String` |
| `lastVersionMetadataState` | `com.seeyon.udc.common.enums.MicroFlowLastVersionMetadataStateEnum` |
| `lastEnableTime` | `java.util.Date` |
| `lastEnableVersion` | `java.lang.String` |

## `BaseUdcAttributeDto`（27 字段）

`com.seeyon.udc.common.dto.BaseUdcAttributeDto`

被这些方法当入参：

- `TypeHelper.getDatabaseDataType()`（裸参数）
- `TypeHelper.getJavaType()`（裸参数）
- `TypeHelper.getLength()`（裸参数）
- `TypeHelper.getDefaultMaxLength()`（裸参数）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `actionType` | `com.seeyon.udc.common.enums.AttributeActionType` |
| `createTime` | `java.util.Date` |
| `updateTime` | `java.util.Date` |
| `name` | `java.lang.String` |
| `caption` | `java.lang.String` |
| `dataType` | `java.lang.String` |
| `dataTypeDisplayName` | `java.lang.String` |
| `notNull` | `java.lang.Boolean` |
| `description` | `java.lang.String` |
| `minLength` | `java.lang.Integer` |
| `maxLength` | `java.lang.Integer` |
| `decimalDigits` | `java.lang.Integer` |
| `multiSelect` | `java.lang.Boolean` |
| `relationEntity` | `java.lang.String` |
| `relationEntityCategory` | `com.seeyon.boot.starter.extmetadata.enums.EntityCategoryEnum` |
| `relationEntityName` | `java.lang.String` |
| `relationCode` | `java.lang.String` |
| `relationType` | `com.seeyon.boot.annotation.enums.RelationType` |
| `relationApp` | `java.lang.String` |
| `relationStarter` | `java.lang.String` |
| `defaultValue` | `java.lang.String` |
| `min` | `java.lang.String` |
| `max` | `java.lang.String` |
| `pattern` | `java.lang.String` |
| `patternMessage` | `java.lang.String` |
| `searchable` | `java.lang.Boolean` |

## `DependentApplicationDto`（27 字段）

`com.seeyon.udc.common.dto.DependentApplicationDto`

被这些方法当入参：

- `DependencyAnalysisService.analysis()`（裸参数）
- `ApplicationAppService.createDepApp()`（包装入参）
- `ApplicationAppService.createDepAppBatch()`（裸参数）
- `ApplicationAppService.updateDepApp()`（包装入参）
- `ApplicationAppService.updateDepAppBatch()`（裸参数）
- `UdcCtpEnumProxyAppService.selectByEnumItemByDependentApp()`（裸参数）
- … 另 3 处

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `appId` | `java.lang.Long` |
| `depAppName` | `java.lang.String` |
| `depAppCaption` | `java.lang.String` |
| `dynamicModuleGroup` | `java.lang.String` |
| `depAppBasePackage` | `java.lang.String` |
| `depAppVersion` | `java.lang.String` |
| `description` | `java.lang.String` |
| `dynamicService` | `boolean` |
| `enableDelete` | `boolean` |
| `dependentAppType` | `com.seeyon.boot.starter.extmetadata.enums.DependentAppTypeEnum` |
| `terminalType` | `com.seeyon.udc.common.enums.TerminalTypeEnum` |
| `sort` | `int` |
| `needGenerate` | `java.lang.Boolean` |
| `supportUpgrade` | `java.lang.Boolean` |
| `versionEdit` | `java.lang.Boolean` |
| `defaultLastVersion` | `java.lang.Boolean` |
| `updateTime` | `java.util.Date` |
| `versionTypeEnum` | `com.seeyon.udc.common.enums.VersionTypeEnum` |
| `enable` | `java.lang.Boolean` |
| `sourceType` | `com.seeyon.udc.common.dto.ComponentSourceTypeEnum` |
| `preSet` | `java.lang.Boolean` |
| `udcApp` | `java.lang.Boolean` |
| `depAppHostAppName` | `java.lang.String` |
| `belongToPlatform` | `java.lang.Boolean` |
| `dynamicDependency` | `com.seeyon.boot.starter.extmetadata.enums.DynamicDependencyTypeEnum` |
| `packageType` | `com.seeyon.boot.starter.extmetadata.enums.FrontendPackageTypeEnum` |

## `PageInfoItemDto`（24 字段）

`com.seeyon.udc.common.dto.PageInfoItemDto`

被这些方法当入参：

- `WidgetExpressionDetectionFunction.doDetection()`（裸参数）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `appId` | `java.lang.Long` |
| `createTime` | `java.util.Date` |
| `groupId` | `java.lang.Long` |
| `relationGroupId` | `java.lang.Long` |
| `layoutId` | `java.lang.Long` |
| `layoutInfo` | `java.lang.String` |
| `name` | `java.lang.String` |
| `caption` | `java.lang.String` |
| `description` | `java.lang.String` |
| `pageType` | `java.lang.String` |
| `handWritten` | `java.lang.Boolean` |
| `defaultOpenType` | `java.lang.String` |
| `urlType` | `com.seeyon.udc.common.enums.PageUrlTypeEnum` |
| `pageUrl` | `java.lang.String` |
| `sortNo` | `java.lang.Integer` |
| `sourceType` | `com.seeyon.boot.starter.extmetadata.enums.PageSourceTypeEnum` |
| `sourceId` | `java.lang.Long` |
| `masterEntityIds` | `java.lang.String` |
| `includeEntityIds` | `java.lang.String` |
| `openWay` | `com.seeyon.boot.starter.extmetadata.enums.OpenWayEnum` |
| `referConfigParameters` | `java.util.List<com.seeyon.udc.common.dto.PageReferDto>` |
| `publicAccess` | `java.lang.Boolean` |
| `schemaState` | `com.seeyon.udc.common.enums.PageSchemaStateEnum` |

## `EventDto`（23 字段）

`com.seeyon.udc.common.dto.EventDto`

被这些方法当入参：

- `EventAppService.create()`（包装入参）
- `EventAppService.update()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `name` | `java.lang.String` |
| `caption` | `java.lang.String` |
| `source` | `com.seeyon.udc.common.enums.EventSourceEnum` |
| `messageType` | `com.seeyon.udc.common.enums.MessageTypeEnum` |
| `sourceId` | `java.lang.Long` |
| `appId` | `java.lang.Long` |
| `appName` | `java.lang.String` |
| `expDesignData` | `java.lang.String` |
| `expRuntimeData` | `java.lang.String` |
| `actionType` | `com.seeyon.udc.common.enums.EventActionTypeEnum` |
| `triggerType` | `com.seeyon.udc.common.enums.EventTriggerTypeEnum` |
| `enabled` | `java.lang.Boolean` |
| `type` | `com.seeyon.udc.common.enums.EventTypeEnum` |
| `eventDataType` | `com.seeyon.udc.common.enums.ObjectTypeEnum` |
| `eventData` | `java.lang.Long` |
| `eventDataFullName` | `java.lang.String` |
| `numberFiredOnce` | `java.lang.String` |
| `createTime` | `java.util.Date` |
| `description` | `java.lang.String` |
| `messageTopic` | `java.lang.String` |
| `messageTags` | `java.lang.String` |
| `className` | `java.lang.String` |

## `EntityAutoCodeDto`（23 字段）

`com.seeyon.udc.dto.EntityAutoCodeDto`

被这些方法当入参：

- `DataFlowCodeService.deployManuallyMappingCustomDto()`（裸参数）

| 字段 | 类型 |
|---|---|
| `log` | static `org.slf4j.Logger` |
| `serialVersionUID` | static `long` |
| `entityId` | `java.lang.String` |
| `entityName` | `java.lang.String` |
| `entityFullName` | `java.lang.String` |
| `appServiceFullName` | `java.lang.String` |
| `appServiceMethodNames` | `java.util.List<java.lang.String>` |
| `entityCaption` | `java.lang.String` |
| `outEntity` | `boolean` |
| `udcApp` | `boolean` |
| `rootEntity` | `boolean` |
| `third` | `boolean` |
| `appUrl` | `java.lang.String` |
| `pageUrl` | `java.lang.String` |
| `pageName` | `java.lang.String` |
| `pageUrlType` | `com.seeyon.udc.common.enums.PageUrlTypeEnum` |
| `entityRequestMapping` | `java.lang.String` |
| `treeEntity` | `boolean` |
| `controllerName` | `java.lang.String` |
| `customDtoName` | `java.lang.String` |
| `mobilePage` | `boolean` |
| `appMetaDataDto` | `com.seeyon.boot.starter.extmetadata.dto.UdcBaseApplicationMetaDataDto` |
| `dynamicService` | `boolean` |

## `UdcResourceRegisterDto`（21 字段）

`com.seeyon.udc.dto.user.UdcResourceRegisterDto`

被这些方法当入参：

- `PluginPageInfoAppService.getResourceByCondition()`（包装入参）
- `ResourceAppService.registerResourceBatch()`（裸参数）
- `ResourceAppService.registerResource()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `id` | `java.lang.Long` |
| `code` | `java.lang.String` |
| `name` | `java.lang.String` |
| `icon` | `java.lang.String` |
| `url` | `java.lang.String` |
| `admin` | `java.lang.Boolean` |
| `parentCode` | `java.lang.String` |
| `refCode` | `java.lang.String` |
| `appId` | `java.lang.Long` |
| `dataStatus` | `java.lang.Integer` |
| `type` | `com.seeyon.ctp.user.enums.ResourceTypeEnum` |
| `dataType` | `java.lang.String` |
| `clientType` | `java.lang.String` |
| `openType` | `java.lang.String` |
| `entityFullName` | `java.lang.String` |
| `urlParameters` | `java.lang.String` |
| `outParameters` | `java.lang.String` |
| `sortNumber` | `java.lang.String` |
| `publicAccess` | `java.lang.Boolean` |
| `dataSource` | `java.lang.String` |

## `ReferConfigDto`（20 字段）

`com.seeyon.udc.dto.ReferConfigDto`

被这些方法当入参：

- `ReferConfigAppService.create()`（包装入参）
- `ReferConfigAppService.createOrUpdate()`（包装入参）
- `ReferConfigAppService.update()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `id` | `java.lang.Long` |
| `caption` | `java.lang.String` |
| `type` | `java.lang.String` |
| `displayName` | `java.lang.String` |
| `pullDisplayName` | `java.lang.String` |
| `detailPage` | `java.lang.String` |
| `detailPageId` | `java.lang.Long` |
| `configInfo` | `java.lang.String` |
| `isDefault` | `java.lang.Boolean` |
| `appId` | `java.lang.Long` |
| `entityId` | `java.lang.Long` |
| `terminalType` | `com.seeyon.udc.common.enums.TerminalTypeEnum` |
| `groupId` | `java.lang.Long` |
| `sourceType` | `com.seeyon.udc.common.enums.ReferConfigSourceTypeEnum` |
| `pageId` | `java.lang.Long` |
| `relationApp` | `java.lang.String` |
| `relationEntity` | `java.lang.String` |
| `sourceRefer` | `java.lang.String` |
| `actionType` | `com.seeyon.boot.enums.ActionType` |

## `EntityDto`（19 字段）

`com.seeyon.udc.common.dto.EntityDto`

被这些方法当入参：

- `TypeChangeSqlResolver.registrySql()`（裸参数）
- `TypeChangeSqlResolver.dropAndAddColumn()`（裸参数）
- `TypeChangeSqlResolver.migrateColumnDate()`（裸参数）
- `UdcAuditLogService.createLog4EntityDelete()`（裸参数）
- `PresetTemplateHandler.generate()`（裸参数）
- `PresetTemplateHandler.generateByName()`（裸参数）
- … 另 12 处

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `capFirstName` | `java.lang.String` |
| `unCapFirstName` | `java.lang.String` |
| `fullName` | `java.lang.String` |
| `dtoFullName` | `java.lang.String` |
| `attributes` | `java.util.List<com.seeyon.udc.common.dto.AttributeDto>` |
| `parent` | `com.seeyon.udc.common.dto.EntityDto` |
| `children` | `java.util.List<com.seeyon.udc.common.dto.EntityDto>` |
| `events` | `java.util.List<com.seeyon.udc.common.dto.EventQueryResultDto>` |
| `hasChild` | `java.lang.Boolean` |
| `hasValidateRule` | `java.lang.Boolean` |
| `hasAssignValueRule` | `java.lang.Boolean` |
| `hasDefaultValueRule` | `java.lang.Boolean` |
| `generateAggregateValidateClass` | `java.lang.Boolean` |
| `generateAggregateAssignClass` | `java.lang.Boolean` |
| `generateAggregateDefaultValueClass` | `java.lang.Boolean` |
| `hasOrderNo` | `java.lang.Boolean` |
| `hasDefaultValueSystemVariable` | `java.lang.Boolean` |
| `indexes` | `java.util.List<com.seeyon.udc.common.dto.IndexDto>` |

## `MicroFlowLogDetailsSearchDto`（19 字段）

`com.seeyon.udc.common.dto.MicroFlowLogDetailsSearchDto`

被这些方法当入参：

- `UdcSandBoxAppService.searchDetails()`（裸参数）
- `UdcSandBoxAppService.searchDetails4FlowLog()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `traceId` | `java.lang.String` |
| `requestId` | `java.lang.String` |
| `subModuleType` | `com.seeyon.udc.common.enums.ModuleSubTypeEnum` |
| `subMicroFlowId` | `java.lang.String` |
| `activityType` | `com.seeyon.udc.common.enums.MicroFlowActivityTypeEnum` |
| `nodeCaption` | `java.lang.String` |
| `microFlowCaption` | `java.lang.String` |
| `paramKey` | `java.lang.String` |
| `errorKey` | `java.lang.String` |
| `success` | `java.lang.Boolean` |
| `microFlowCode` | `java.lang.String` |
| `logStartTime` | `java.lang.Long` |
| `logEndTime` | `java.lang.Long` |
| `nodeId` | `java.lang.String` |
| `forPath` | `java.lang.String` |
| `appId` | `java.lang.Long` |
| `needOuterForLog` | `java.lang.Boolean` |
| `signatureUuid` | `java.lang.Long` |

## `DataTransferObjectDto`（18 字段）

`com.seeyon.udc.common.dto.DataTransferObjectDto`

被这些方法当入参：

- `DataTransferObjectAppService.create()`（包装入参）
- `DataTransferObjectAppService.createDtoWithAttrs()`（包装入参）
- `DataTransferObjectAppService.update()`（包装入参）
- `DataTransferObjectAppService.updateDtoWithAttrs()`（包装入参）
- `DataTransferObjectAppService.createDtoWithAttrsAndRefDtos()`（裸参数）
- `DataTransferObjectAppService.updateDtoWithAttrsAndRefDtos()`（裸参数）
- … 另 2 处

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `name` | `java.lang.String` |
| `caption` | `java.lang.String` |
| `source` | `com.seeyon.udc.common.enums.DtoSourceEnum` |
| `sourceType` | `com.seeyon.udc.common.enums.DtoSourceTypeEnum` |
| `isRoot` | `java.lang.Boolean` |
| `parentEntityId` | `java.lang.Long` |
| `batchId` | `java.lang.Long` |
| `appId` | `java.lang.Long` |
| `appName` | `java.lang.String` |
| `appCaption` | `java.lang.String` |
| `sourceId` | `java.lang.Long` |
| `isCommandDto` | `java.lang.Boolean` |
| `attributes` | `java.util.List<com.seeyon.udc.common.dto.DtoAttributeDto>` |
| `description` | `java.lang.String` |
| `isMetaData` | `java.lang.Boolean` |
| `fullName` | `java.lang.String` |
| `refId` | `java.lang.Long` |

## `UdcPortalSetDesignerDto`（18 字段）

`com.seeyon.udc.common.dto.UdcPortalSetDesignerDto`

被这些方法当入参：

- `UdcPortalSetAppService.createPcTemplateData()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `id` | `java.lang.Long` |
| `dataId` | `java.lang.Long` |
| `name` | `java.lang.String` |
| `orgId` | `java.lang.Long` |
| `userId` | `java.lang.Long` |
| `imgId` | `java.lang.String` |
| `enablePc` | `java.lang.Boolean` |
| `enableMobile` | `java.lang.Boolean` |
| `msecurityValue` | `java.lang.String` |
| `usecurityValue` | `java.lang.String` |
| `allowUserDefine` | `java.lang.Boolean` |
| `dataStatus` | `java.lang.Integer` |
| `appCode` | `java.lang.String` |
| `templateId` | `java.lang.Long` |
| `mTemplateId` | `java.lang.Long` |
| `appFrame` | `java.lang.Integer` |
| `originalAppId` | `java.lang.Long` |

## `UdcRtPageLogSearchDto`（18 字段）

`com.seeyon.udc.common.dto.UdcRtPageLogSearchDto`

被这些方法当入参：

- `UdcSandBoxAppService.searchPageLog()`（裸参数）
- `UdcSandBoxAppService.searchPageLogNonMetadata()`（裸参数）

| 字段 | 类型 |
|---|---|
| `appId` | `java.lang.String` |
| `startTime` | `java.lang.Long` |
| `endTime` | `java.lang.Long` |
| `traceId` | `java.lang.String` |
| `name` | `java.lang.String` |
| `type` | `java.lang.String` |
| `userID` | `java.lang.Long` |
| `appName` | `java.lang.String` |
| `pageName` | `java.lang.String` |
| `userName` | `java.lang.String` |
| `sessionId` | `java.lang.String` |
| `componentId` | `java.lang.String` |
| `sourceId` | `java.lang.String` |
| `operationType` | `java.lang.String` |
| `caption` | `java.lang.String` |
| `pageId` | `java.lang.String` |
| `traceIds` | `java.util.List<java.lang.String>` |
| `sourceIds` | `java.util.List<java.lang.String>` |

## `ConsistenceDetectionDto`（18 字段）

`com.seeyon.udc.detection.dto.ConsistenceDetectionDto`

被这些方法当入参：

- `WidgetExpressionDetectionFunction.doDetection()`（裸参数）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `detectionType` | `java.lang.String` |
| `code` | `java.lang.String` |
| `moduleType` | `com.seeyon.udc.common.enums.ModuleTypeEnum` |
| `interpolatedModuleType` | `java.lang.String` |
| `domainEntityId` | `java.lang.Long` |
| `document` | `java.lang.Object[]` |
| `interpolatedDocument` | `java.lang.String` |
| `element` | `java.lang.Object[]` |
| `interpolatedElement` | `java.lang.String` |
| `message` | `java.lang.Object[]` |
| `interpolatedMessage` | `java.lang.String` |
| `route` | `java.lang.String` |
| `elementType` | `com.seeyon.udc.common.enums.ElementTypeEnum` |
| `moduleProperty` | `java.util.Map<java.lang.String, java.lang.Object>` |
| `elementProperty` | `java.util.Map<java.lang.String, java.lang.Object>` |
| `path` | `java.lang.String` |
| `orderNum` | `java.lang.Integer` |

## `MicroFlowParameterDefDto`（18 字段）

`com.seeyon.udc.microflow.dto.definition.MicroFlowParameterDefDto`

被这些方法当入参：

- `BaseTrigger.setInput()`（裸参数）
- `BaseTrigger.setOutput()`（裸参数）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `inApp` | `java.lang.Boolean` |
| `udcApp` | `java.lang.Boolean` |
| `hasPagination` | `boolean` |
| `dataType` | `java.lang.String` |
| `javaType` | `java.lang.String` |
| `type` | `java.lang.String` |
| `name` | `java.lang.String` |
| `description` | `java.lang.String` |
| `id` | `java.lang.String` |
| `paramType` | `java.lang.String` |
| `bodyType` | `java.lang.String` |
| `required` | `boolean` |
| `appName` | `java.lang.String` |
| `relationEntity` | `java.lang.String` |
| `dtoType` | `java.lang.String` |
| `relationEntityFullName` | `java.lang.String` |
| `entityServiceName` | `java.lang.String` |

## `UdcPortalPortletDefinitionDto`（15 字段）

`com.seeyon.udc.common.dto.UdcPortalPortletDefinitionDto`

被这些方法当入参：

- `UdcPortalPortletAppService.createOrUpdatePortlet()`（包装入参）
- `UdcPortalPortletAppService.updatePortletName()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `portletId` | `java.lang.String` |
| `name` | `java.lang.String` |
| `appId` | `java.lang.String` |
| `originalAppId` | `java.lang.Long` |
| `mobileAppId` | `java.lang.String` |
| `enablePc` | `java.lang.Boolean` |
| `enableMobile` | `java.lang.Boolean` |
| `definitionInfo` | `java.lang.String` |
| `mobileDefinitionInfo` | `java.lang.String` |
| `exposeName` | `java.lang.String` |
| `mobileExposeName` | `java.lang.String` |
| `categoryCode` | `java.lang.String` |
| `sortNo` | `java.lang.Integer` |
| `appCode` | `java.lang.String` |

## `ApplicationExportDto`（14 字段）

`com.seeyon.udc.common.dto.ApplicationExportDto`

被这些方法当入参：

- `DeployNoticeService.deployNotice()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `deployTime` | `java.util.Date` |
| `operationTime` | `java.util.Date` |
| `deployType` | `com.seeyon.udc.common.enums.DeployTypeEnum` |
| `artifactSource` | `com.seeyon.udc.common.enums.ArtifactSourceEnum` |
| `businessType` | `com.seeyon.udc.common.enums.DeployBusinessTypeEnum` |
| `showVersion` | `java.lang.String` |
| `jarVersion` | `java.lang.String` |
| `tenantId` | `java.lang.Long` |
| `appOwner` | `java.lang.Long` |
| `memberCore` | `java.lang.String` |
| `orgCore` | `java.lang.String` |
| `pushEnv` | `java.lang.String` |
| `dependencies` | `java.util.List<com.seeyon.ctp.metadata.dto.model.MavenInfoDto>` |

## `BaseEntityActionDto`（14 字段）

`com.seeyon.udc.common.dto.BaseEntityActionDto`

被这些方法当入参：

- `UpdateService.lambda$updateNoEvents$3()`（裸参数）
- `UpdateService.lambda$update$2()`（裸参数）
- `UpdateService.lambda$create$0()`（裸参数）

| 字段 | 类型 |
|---|---|
| `UNKNOWN_POSITION_INDEX` | static `java.lang.String` |
| `id` | `java.lang.Long` |
| `actionType` | `com.seeyon.boot.enums.ActionType` |
| `createTime` | `java.util.Date` |
| `updateTime` | `java.util.Date` |
| `draft` | `java.lang.Boolean` |
| `version` | `java.lang.Integer` |
| `sort_i_no` | `java.lang.Integer` |
| `extendMap` | `java.util.Map<java.lang.String, java.lang.Object>` |
| `positionIndex` | `java.lang.String` |
| `__key` | `java.lang.String` |
| `__emptyFields` | `java.util.List<java.lang.String>` |
| `__updatedFields` | `java.util.List<java.lang.String>` |
| `errorInfoList` | `java.util.Set<com.seeyon.udc.common.bo.ErrorObject>` |

## `UdcEnumDto`（14 字段）

`com.seeyon.udc.dto.UdcEnumDto`

被这些方法当入参：

- `UdcEnumAppService.create()`（包装入参）
- `UdcEnumAppService.update()`（包装入参）
- `EnumMetadataDtoConverter.postProcessUdcEnumMetaData()`（裸参数）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `name` | `java.lang.String` |
| `caption` | `java.lang.String` |
| `state` | `com.seeyon.udc.common.enums.UdcDataStateEnum` |
| `appId` | `java.lang.Long` |
| `categoryId` | `java.lang.Long` |
| `enable` | `java.lang.Boolean` |
| `edit` | `java.lang.Boolean` |
| `orderNo` | `java.lang.Integer` |
| `description` | `java.lang.String` |
| `fullName` | `java.lang.String` |
| `iconDisplay` | `java.lang.Boolean` |
| `udcEnumType` | `com.seeyon.udc.common.enums.UdcEnumTypeEnum` |
| `udcEnumItemDtoList` | `java.util.List<com.seeyon.udc.dto.UdcEnumItemDto>` |

## `UdcEnumItemDto`（14 字段）

`com.seeyon.udc.dto.UdcEnumItemDto`

被这些方法当入参：

- `UdcEnumItemAppService.create()`（包装入参）
- `UdcEnumItemAppService.update()`（包装入参）
- `UdcEnumItemAppService.operateBatch()`（裸参数）
- `EnumMetadataDtoConverter.postProcessUdcEnumItemMetaData()`（裸参数）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `appId` | `java.lang.Long` |
| `name` | `java.lang.String` |
| `code` | `java.lang.Integer` |
| `caption` | `java.lang.String` |
| `orderNo` | `java.lang.Integer` |
| `enable` | `java.lang.Boolean` |
| `edit` | `java.lang.Boolean` |
| `enumId` | `java.lang.Long` |
| `actionType` | `com.seeyon.boot.enums.ActionType` |
| `description` | `java.lang.String` |
| `icon` | `java.lang.String` |
| `color` | `java.lang.String` |
| `fullName` | `java.lang.String` |

## `IndexDto`（12 字段）

`com.seeyon.udc.common.dto.IndexDto`

被这些方法当入参：

- `IndexAppService.create()`（包装入参）
- `IndexAppService.update()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `appId` | `java.lang.Long` |
| `caption` | `java.lang.String` |
| `name` | `java.lang.String` |
| `code` | `java.lang.String` |
| `fieldIds` | `java.lang.String` |
| `fieldNames` | `java.lang.String` |
| `fieldCaptions` | `java.lang.String` |
| `remark` | `java.lang.String` |
| `indexSource` | `com.seeyon.udc.common.enums.IndexSourceEnum` |
| `entityId` | `java.lang.Long` |
| `type` | `com.seeyon.udc.common.enums.IndexTypeEnum` |

## `EntityPresetDto`（12 字段）

`com.seeyon.udc.dto.EntityPresetDto`

被这些方法当入参：

- `EntityPresetAppService.create()`（包装入参）
- `EntityPresetAppService.update()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `id` | `java.lang.Long` |
| `entityId` | `java.lang.Long` |
| `appId` | `java.lang.Long` |
| `entityCaption` | `java.lang.String` |
| `entityFullName` | `java.lang.String` |
| `fileStorageKey` | `java.lang.String` |
| `errorFileStorageKey` | `java.lang.String` |
| `dataFileStorageKey` | `java.lang.String` |
| `dataSize` | `java.lang.Integer` |
| `dataInfo` | `java.lang.String` |
| `validateState` | `com.seeyon.udc.common.enums.ValidateStateEnum` |

## `CreateOnlyPageApplicationDto`（12 字段）

`com.seeyon.udc.dto.form.CreateOnlyPageApplicationDto`

被这些方法当入参：

- `ApplicationManagerAppService.createOnlyPageApplication()`（包装入参）
- `AsyncAppService.createOnlyPageApplicationAsync()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `hostAppName` | `java.lang.String` |
| `caption` | `java.lang.String` |
| `pageUrl` | `java.lang.String` |
| `originAppName` | `java.lang.String` |
| `originPageGuid` | `java.lang.Long` |
| `originPageUrl` | `java.lang.String` |
| `authJson` | `java.lang.String` |
| `copySchema` | `java.lang.Boolean` |
| `masterEntity` | `java.lang.String` |
| `pageUrlTypeEnum` | `com.seeyon.udc.common.enums.PageUrlTypeEnum` |
| `spiltTerminal` | `java.lang.Boolean` |

## `AttributeGroupDto`（11 字段）

`com.seeyon.udc.common.dto.AttributeGroupDto`

被这些方法当入参：

- `AttributeGroupAppService.create()`（包装入参）
- `AttributeGroupAppService.update()`（包装入参）
- `AttributeGroupAppService.cancel()`（包装入参）
- `AttributeGroupAppService.remove()`（包装入参）
- `AttributeGroupAppService.swap()`（裸参数）
- `AttributeGroupAppService.operateBatch()`（裸参数）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `caption` | `java.lang.String` |
| `orderNo` | `java.lang.Integer` |
| `preset` | `java.lang.Boolean` |
| `entityId` | `java.lang.Long` |
| `appId` | `java.lang.Long` |
| `virtual` | `java.lang.Boolean` |
| `attributeDtoList` | `java.util.List<com.seeyon.udc.common.dto.AttributeDto>` |
| `actionType` | `com.seeyon.udc.common.enums.AttributeActionType` |
| `sourceId` | `java.lang.Long` |
| `uniqueKey` | `java.lang.String` |

## `MicroFlowLogSearchDto`（10 字段）

`com.seeyon.udc.common.dto.MicroFlowLogSearchDto`

被这些方法当入参：

- `UdcSandBoxAppService.search()`（裸参数）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `caption` | `java.lang.String` |
| `code` | `java.lang.String` |
| `subModuleType` | `com.seeyon.udc.common.enums.ModuleSubTypeEnum` |
| `sourceCaption` | `java.lang.String` |
| `startTime` | `java.util.Date` |
| `endTime` | `java.util.Date` |
| `success` | `java.lang.Boolean` |
| `appId` | `java.lang.Long` |
| `appName` | `java.lang.String` |

## `AttributeSetDto`（10 字段）

`com.seeyon.udc.dto.AttributeSetDto`

被这些方法当入参：

- `AttributeSetAppService.create()`（包装入参）
- `AttributeSetAppService.createBatch()`（裸参数）
- `AttributeSetAppService.update()`（包装入参）

| 字段 | 类型 |
|---|---|
| `NULL_ID` | static `java.lang.Long` |
| `serialVersionUID` | static `long` |
| `id` | `java.lang.Long` |
| `appId` | `java.lang.Long` |
| `name` | `java.lang.String` |
| `caption` | `java.lang.String` |
| `description` | `java.lang.String` |
| `attributes` | `java.util.List<com.seeyon.udc.common.dto.AttributeDto>` |
| `sourceType` | `com.seeyon.udc.common.enums.AttributeSetSourceTypeEnum` |
| `orderNo` | `int` |

## `DataFlowMappingRowDto`（9 字段）

`com.seeyon.udc.common.dto.DataFlowMappingRowDto`

被这些方法当入参：

- `MappingMode.processingMapping()`（裸参数）

| 字段 | 类型 |
|---|---|
| `source` | `com.seeyon.udc.common.dto.DataFlowMappingFieldDto` |
| `mappingMode` | `java.lang.String` |
| `target` | `com.seeyon.udc.common.dto.DataFlowMappingFieldDto` |
| `personalization` | `java.lang.Boolean` |
| `uuid` | `java.lang.String` |
| `rowConditionJson` | `java.lang.String` |
| `sourceEntityName` | `java.lang.String` |
| `targetEntityName` | `java.lang.String` |
| `rowCondition` | `com.seeyon.boot.starter.formula.dto.ExpressionDefinitionDto` |

## `ScalabilityDto`（9 字段）

`com.seeyon.udc.dto.ScalabilityDto`

被这些方法当入参：

- `ScalabilityAppService.create()`（包装入参）
- `ScalabilityAppService.update()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `id` | `java.lang.Long` |
| `appId` | `java.lang.Long` |
| `optionId` | `java.lang.Long` |
| `prefix` | `java.lang.String` |
| `caption` | `java.lang.String` |
| `count` | `java.lang.Integer` |
| `dataType` | `java.lang.String` |
| `dataTypeProperties` | `java.lang.String` |

## `DependentUpdateDto`（8 字段）

`com.seeyon.udc.common.dto.DependentUpdateDto`

被这些方法当入参：

- `ApplicationAppService.updateBatchDepAppVersion()`（裸参数）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `appId` | `java.lang.Long` |
| `sourceDepAppName` | `java.lang.String` |
| `targetDepAppName` | `java.lang.String` |
| `targetDepAppVersion` | `java.lang.String` |
| `defaultLastVersion` | `java.lang.Boolean` |
| `terminalType` | `com.seeyon.udc.common.enums.TerminalTypeEnum` |
| `dependentAppType` | `com.seeyon.boot.starter.extmetadata.enums.DependentAppTypeEnum` |

## `DeployVersionDto`（8 字段）

`com.seeyon.udc.common.dto.DeployVersionDto`

被这些方法当入参：

- `AppDeployContext.lambda$getJarVersion$0()`（裸参数）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `sourceVersion` | `java.lang.String` |
| `jarVersion` | `java.lang.String` |
| `showVersion` | `java.lang.String` |
| `buildVersion` | `java.lang.String` |
| `currentVersionFirstDeploy` | `java.lang.Boolean` |
| `lastSuccessTime` | `java.util.Date` |
| `imageUrl` | `java.lang.String` |

## `UdcSerialSchemeCreateDto`（8 字段）

`com.seeyon.udc.common.dto.UdcSerialSchemeCreateDto`

被这些方法当入参：

- `UdcSerialSchemeAppService.createEasyScheme()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `hostAppName` | `java.lang.String` |
| `code` | `java.lang.String` |
| `name` | `java.lang.String` |
| `appGuid` | `java.lang.String` |
| `appId` | `java.lang.String` |
| `id` | `java.lang.Long` |
| `guid` | `java.lang.Long` |

## `ApplicationCopyDto`（7 字段）

`com.seeyon.udc.common.dto.ApplicationCopyDto`

被这些方法当入参：

- `ApplicationManagerAppService.copyOnlyPageApp()`（包装入参）
- `ApplicationManagerAppService.copyLayoutApp()`（包装入参）
- `ApplicationManagerAppService.copyApp()`（包装入参）
- `ApplicationManagerAppService.copyAppAsync()`（包装入参）
- `ApplicationManagerAppService.importFormValidate()`（裸参数）
- `ApplicationManagerAppService.importFormApp()`（裸参数）
- … 另 4 处

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `applicationId` | `java.lang.Long` |
| `name` | `java.lang.String` |
| `caption` | `java.lang.String` |
| `appVersion` | `java.lang.String` |
| `creator` | `java.lang.Long` |
| `orgId` | `java.lang.Long` |

## `DtoAttributeDto`（7 字段）

`com.seeyon.udc.common.dto.DtoAttributeDto`

被这些方法当入参：

- `DtoAttributeAppService.create()`（包装入参）
- `DtoAttributeAppService.createBatch()`（裸参数）
- `DtoAttributeAppService.update()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `appId` | `java.lang.Long` |
| `dtoId` | `java.lang.Long` |
| `dataTypeCategory` | `com.seeyon.udc.common.enums.DataTypeCategoryEnum` |
| `type` | `com.seeyon.udc.common.enums.ObjectTypeEnum` |
| `mappingId` | `java.lang.Long` |
| `fullName` | `java.lang.String` |

## `UdcPortalPortletCategoryDto`（7 字段）

`com.seeyon.udc.common.dto.UdcPortalPortletCategoryDto`

被这些方法当入参：

- `UdcPortalPortletAppService.createCategory()`（包装入参）
- `UdcPortalPortletAppService.updateCategory()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `categoryCode` | `java.lang.String` |
| `categoryName` | `java.lang.String` |
| `sortNo` | `java.lang.Integer` |
| `appCode` | `java.lang.String` |
| `parentCategoryCode` | `java.lang.String` |
| `originalAppId` | `java.lang.Long` |

## `UdcSerialSchemeSearchDto`（7 字段）

`com.seeyon.udc.common.dto.UdcSerialSchemeSearchDto`

被这些方法当入参：

- `UdcSerialSchemeAppService.selectSerialScheme()`（包装入参）
- `UdcSerialSchemeAppService.selectSerialSchemeById()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `hostAppName` | `java.lang.String` |
| `appId` | `java.lang.Long` |
| `appGuid` | `java.lang.Long` |
| `id` | `java.lang.Long` |
| `selectAllFlag` | `java.lang.Boolean` |
| `active` | `java.lang.Boolean` |

## `EntityCopyDto`（7 字段）

`com.seeyon.udc.dto.EntityCopyDto`

被这些方法当入参：

- `InnerEntityAppService.copyEntity()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `appId` | `java.lang.Long` |
| `copyInfo` | `com.seeyon.udc.dto.EntityCopyInfoDto` |
| `entityGroupId` | `java.lang.Long` |
| `moduleList` | `java.util.List<com.seeyon.udc.enums.EntityCopyModuleEnum>` |
| `copyChildEntity` | `java.lang.Boolean` |
| `childEntityInfoList` | `java.util.List<com.seeyon.udc.dto.EntityCopyInfoDto>` |

## `ReferConfigInfoDto`（7 字段）

`com.seeyon.udc.dto.ReferConfigInfoDto`

被这些方法当入参：

- `ReferConfigGroupAppService.createConfigInfo()`（包装入参）
- `ReferConfigGroupAppService.updateConfigInfo()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `caption` | `java.lang.String` |
| `appId` | `java.lang.Long` |
| `entityId` | `java.lang.Long` |
| `type` | `java.lang.String` |
| `referConfigDetail` | `java.util.List<com.seeyon.udc.dto.ReferConfigDto>` |
| `operationLog` | `com.seeyon.udc.operationlog.dto.OperationLogDetailsDto` |

## `ScalabilityOptionDto`（7 字段）

`com.seeyon.udc.dto.ScalabilityOptionDto`

被这些方法当入参：

- `ScalabilityOptionAppService.create()`（包装入参）
- `ScalabilityOptionAppService.update()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `id` | `java.lang.Long` |
| `appId` | `java.lang.Long` |
| `name` | `java.lang.String` |
| `caption` | `java.lang.String` |
| `scalabilityDtoList` | `java.util.List<com.seeyon.udc.dto.ScalabilityDto>` |
| `attributeDtoList` | `java.util.List<com.seeyon.udc.common.dto.AttributeDto>` |

## `UdcApplicationMetaDataSearchDto`（7 字段）

`com.seeyon.udc.dto.UdcApplicationMetaDataSearchDto`

被这些方法当入参：

- `UdcMetaDataAppService.selectAppMetaListData()`（包装入参）

| 字段 | 类型 |
|---|---|
| `SEARCH_TYPE_ENTITY` | static `java.lang.String` |
| `SEARCH_TYPE_DTO` | static `java.lang.String` |
| `SEARCH_TYPE_CTP_ENUM` | static `java.lang.String` |
| `SEARCH_TYPE_ENUM` | static `java.lang.String` |
| `appId` | `java.lang.Long` |
| `searchType` | `java.util.List<java.lang.String>` |
| `needAll` | `java.lang.Boolean` |

## `UdcEnumCategoryDto`（7 字段）

`com.seeyon.udc.dto.UdcEnumCategoryDto`

被这些方法当入参：

- `UdcEnumCategoryAppService.create()`（包装入参）
- `UdcEnumCategoryAppService.update()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `name` | `java.lang.String` |
| `parentId` | `java.lang.Long` |
| `orderNo` | `java.lang.Integer` |
| `appId` | `java.lang.Long` |
| `description` | `java.lang.String` |
| `preset` | `java.lang.Boolean` |

## `AttributeTransferDto`（7 字段）

`com.seeyon.udc.entity.dto.AttributeTransferDto`

被这些方法当入参：

- `InnerEntityAppService.attributeTransfer()`（包装入参）
- `AttributeTransferDispatcher.dispatch()`（裸参数）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `attributeIds` | `java.util.List<java.lang.Long>` |
| `transferEntityIds` | `java.util.List<java.lang.Long>` |
| `createEntityDto` | `com.seeyon.udc.common.dto.EntityDto` |
| `transferPattern` | `com.seeyon.udc.enums.AttributeTransferPatternEnum` |
| `copyAndTransfer` | `java.lang.Boolean` |
| `appId` | `java.lang.Long` |

## `AppInfoDto`（6 字段）

`com.seeyon.udc.common.dto.AppInfoDto`

被这些方法当入参：

- `AppStartUpProcessor.onStartLoad()`（裸参数）
- `AppStartUpProcessor.onCompleteMetadataRegister()`（裸参数）
- `AppStartUpProcessor.onCompleteDdlInit()`（裸参数）
- `AppStartUpProcessor.onCompleteTenantInit()`（裸参数）
- `AppStartUpProcessor.onCompleteLoad()`（裸参数）
- `AppStartUpProcessor.onUnLoad()`（裸参数）

| 字段 | 类型 |
|---|---|
| `classLoader` | `java.net.URLClassLoader` |
| `appType` | `com.seeyon.udc.common.enums.ApplicationSourceEnum` |
| `tenantId` | `java.lang.Long` |
| `group` | `java.lang.String` |
| `appName` | `java.lang.String` |
| `appVersion` | `java.lang.String` |

## `ApplicationSaveAsDto`（6 字段）

`com.seeyon.udc.common.dto.ApplicationSaveAsDto`

被这些方法当入参：

- `ApplicationAppService.saveAsNormalNewDesign()`（裸参数）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `sourceAppId` | `java.lang.Long` |
| `newCaption` | `java.lang.String` |
| `newAppVersion` | `java.lang.String` |
| `newDescription` | `java.lang.String` |
| `copVersion` | `java.lang.String` |

## `DmlFileDto`（5 字段）

`com.seeyon.udc.common.autocode.db.change.DmlFileDto`

被这些方法当入参：

- `SqlResolver.outputDmlFile()`（裸参数）
- `ConfigurableCodeContext.registerDmlFileInfo()`（裸参数）
- `TransportHandler.buildDmlFileDto()`（裸参数）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `appName` | `java.lang.String` |
| `entityFullName` | `java.lang.String` |
| `dmlData` | `java.util.List<? extends com.seeyon.boot.domain.entity.BaseEntity>` |
| `dmlDataJson` | `java.lang.String` |

## `EntityGroupDto`（5 字段）

`com.seeyon.udc.common.dto.EntityGroupDto`

被这些方法当入参：

- `EntityGroupAppService.create()`（包装入参）
- `EntityGroupAppService.update()`（包装入参）
- `EntityGroupAppService.updateBatch()`（裸参数）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `caption` | `java.lang.String` |
| `orderNo` | `java.lang.Integer` |
| `preset` | `java.lang.Boolean` |
| `appId` | `java.lang.Long` |

## `EventQueryParamDto`（5 字段）

`com.seeyon.udc.common.dto.EventQueryParamDto`

被这些方法当入参：

- `EventAppService.selectBusinessEvent()`（包装入参）
- `EventAppService.selectEvents()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `appId` | `java.lang.Long` |
| `entityId` | `java.lang.Long` |
| `sourceTypes` | `java.util.List<com.seeyon.udc.common.enums.EventSourceEnum>` |
| `eventTypes` | `java.util.List<com.seeyon.udc.common.enums.EventTypeEnum>` |

## `UdcBaseEntityDto`（5 字段）

`com.seeyon.udc.common.dto.UdcBaseEntityDto`

被这些方法当入参：

- `AuthCheck.check()`（裸参数）

| 字段 | 类型 |
|---|---|
| `publishState` | `com.seeyon.udc.common.enums.PublishStateEnum` |
| `ownerCode` | `java.lang.String` |
| `backupCode` | `java.lang.String` |
| `createTime` | `java.util.Date` |
| `updateTime` | `java.util.Date` |

## `UdcCtpEnumSearchDto`（5 字段）

`com.seeyon.udc.common.dto.UdcCtpEnumSearchDto`

被这些方法当入参：

- `UdcCtpEnumAppService.selectParentByCode()`（包装入参）
- `UdcCtpEnumAppService.selectListByConditionsNoLevel()`（包装入参）

| 字段 | 类型 |
|---|---|
| `code` | `java.lang.String` |
| `codes` | `java.util.List<java.lang.String>` |
| `enumId` | `java.lang.Long` |
| `param` | `java.util.Map<java.lang.String, java.lang.Object>` |
| `enumIds` | `java.util.List<java.lang.Long>` |

## `UdcTreeQueryDto`（5 字段）

`com.seeyon.udc.common.dto.tree.UdcTreeQueryDto`

被这些方法当入参：

- `UdcTreeQueryService.selectTreeData()`（包装入参）

| 字段 | 类型 |
|---|---|
| `currentAppName` | `java.lang.String` |
| `appName` | `java.lang.String` |
| `proxyJoinParamDto` | `com.seeyon.boot.starter.dynamicsql.dto.ProxyJoinParamDto` |
| `entityFullName` | `java.lang.String` |
| `loadAll` | `java.lang.Boolean` |

## `CompatibilitySchemaDto`（5 字段）

`com.seeyon.udc.compatibility.generator.schema.dto.CompatibilitySchemaDto`

被这些方法当入参：

- `CompatibilityOutput.output()`（裸参数）

| 字段 | 类型 |
|---|---|
| `actionType` | `com.seeyon.udc.compatibility.ActionTypeEnum` |
| `modelName` | `java.lang.String` |
| `modelCaption` | `java.lang.String` |
| `fields` | `java.util.List<com.seeyon.udc.compatibility.generator.schema.dto.FieldSchemaDto>` |
| `wheres` | `java.util.List<com.seeyon.udc.compatibility.generator.schema.dto.WhereSchemaDto>` |

## `DeployCallbackDto`（5 字段）

`com.seeyon.udc.dto.DeployCallbackDto`

被这些方法当入参：

- `DeployFinishService.callback()`（裸参数）

| 字段 | 类型 |
|---|---|
| `businessType` | `com.seeyon.udc.common.enums.DeployBusinessTypeEnum` |
| `applicationDto` | `com.seeyon.udc.common.dto.ApplicationDto` |
| `deployState` | `com.seeyon.udc.common.enums.DeployStateEnum` |
| `deployType` | `com.seeyon.udc.common.enums.DeployTypeEnum` |
| `pushEnv` | `java.lang.String` |

## `PublishStateUpdateDto`（5 字段）

`com.seeyon.udc.dto.PublishStateUpdateDto`

被这些方法当入参：

- `PublishStateAppService.updateState()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `entityClassName` | `java.lang.String` |
| `ids` | `java.util.List<java.lang.Long>` |
| `publishState` | `com.seeyon.udc.common.enums.PublishStateEnum` |
| `password` | `java.lang.String` |

## `UdcLateralCheckDto`（5 字段）

`com.seeyon.udc.dto.auth.UdcLateralCheckDto`

被这些方法当入参：

- `UdcLateralAuthCheckAppService.check()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `appName` | `java.lang.String` |
| `userId` | `java.lang.Long` |
| `appGuid` | `java.lang.Long` |
| `appId` | `java.lang.Long` |

## `LayoutApplicationDto`（5 字段）

`com.seeyon.udc.dto.form.LayoutApplicationDto`

被这些方法当入参：

- `ApplicationManagerAppService.createLayoutApplication()`（包装入参）
- `AsyncAppService.createLayoutApplicationAsync()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `layoutAppName` | `java.lang.String` |
| `layoutGuids` | `java.util.List<java.lang.Long>` |
| `pageUrlTypeEnum` | `com.seeyon.udc.common.enums.TerminalTypeEnum` |
| `layoutInfos` | `java.util.List<com.seeyon.udc.common.dto.PageInfoItemDto>` |

## `NewLayoutCreateAfterCallDto`（5 字段）

`com.seeyon.udc.dto.form.NewLayoutCreateAfterCallDto`

被这些方法当入参：

- `ApplicationManagerAppService.createNewLayoutAfterCall()`（包装入参）

| 字段 | 类型 |
|---|---|
| `appIds` | `java.util.List<java.lang.Long>` |
| `newLayoutPCSchema` | `java.lang.String` |
| `newLayoutMobileSchema` | `java.lang.String` |
| `newLayoutPCInParams` | `java.lang.String` |
| `newLayoutMobileInParams` | `java.lang.String` |

## `LastVersionMetadataSearchDto`（5 字段）

`com.seeyon.udc.dto.user.LastVersionMetadataSearchDto`

被这些方法当入参：

- `LastVersionMetadataManagerService.fetchLastVersionMetadataFromDbIfNotExist()`（裸参数）
- `LastVersionMetadataManagerService.getRelationModulePublishState()`（裸参数）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `relationId` | `java.lang.Long` |
| `relationType` | `com.seeyon.udc.common.enums.LastVersionMetaDataRelationType` |
| `module` | `com.seeyon.udc.common.enums.LastVersionMetadataModuleEnum` |
| `appId` | `java.lang.Long` |

## `StaticFileDto`（4 字段）

`com.seeyon.udc.common.autocode.file.StaticFileDto`

被这些方法当入参：

- `FileResolver.outputStaticFile()`（裸参数）
- `ConfigurableCodeContext.registerStaticFileInfo()`（裸参数）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `appName` | `java.lang.String` |
| `terminalType` | `com.seeyon.udc.common.enums.TerminalTypeEnum` |
| `fileData` | `java.util.List<com.seeyon.boot.starter.file.dto.FileDto>` |

## `DynamicExecuteExtendDto`（4 字段）

`com.seeyon.udc.common.dto.DynamicExecuteExtendDto`

被这些方法当入参：

- `MappingMode.processingMapping()`（裸参数）

| 字段 | 类型 |
|---|---|
| `defaultEntityFunction` | `java.util.function.Function<java.lang.String, java.lang.Object>` |
| `idMappingDtoList` | `java.util.List<com.seeyon.udc.common.dto.DataFlowIdMappingBaseDto>` |
| `targetRootDto` | `com.seeyon.udc.common.dto.BaseEntityActionDto` |
| `sourceRootEntityName` | `java.lang.String` |

## `UdcCtpEnumBaseSearchDto`（4 字段）

`com.seeyon.udc.common.dto.UdcCtpEnumBaseSearchDto`

被这些方法当入参：

- `UdcCtpEnumAppService.selectCategoryByAppGuid()`（包装入参）
- `UdcCtpEnumAppService.selectCategoryAndEnum()`（包装入参）
- `UdcCtpEnumAppService.selectCtpEnum()`（包装入参）
- `UdcCtpEnumAppService.selectCtpEnumItemByAppInfo()`（包装入参）

| 字段 | 类型 |
|---|---|
| `hostAppName` | `java.lang.String` |
| `appId` | `java.lang.Long` |
| `appName` | `java.lang.String` |
| `appGuid` | `java.lang.Long` |

## `VersionSearchDto`（4 字段）

`com.seeyon.udc.common.dto.VersionSearchDto`

被这些方法当入参：

- `ApplicationAppService.selectMultiVersion()`（包装入参）

| 字段 | 类型 |
|---|---|
| `appId` | `java.lang.Long` |
| `names` | `java.util.List<java.lang.String>` |
| `dependentAppType` | `com.seeyon.boot.starter.extmetadata.enums.DependentAppTypeEnum` |
| `terminalType` | `com.seeyon.udc.common.enums.TerminalTypeEnum` |

## `DataTransferRequest`（4 字段）

`com.seeyon.udc.common.transfer.DataTransferRequest`

被这些方法当入参：

- `UdcSandBoxAppService.dataTransfer()`（包装入参）
- `DataTransferAppService.dataTransfer()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `appId` | `java.lang.Long` |
| `appName` | `java.lang.String` |
| `entityFullNameCondition` | `java.util.Map<java.lang.String, java.util.Map<java.lang.String, java.lang.Object>>` |

## `DataTransferObjectQueryDto`（4 字段）

`com.seeyon.udc.dto.DataTransferObjectQueryDto`

被这些方法当入参：

- `DataTransferObjectAppService.searchSelectableDtoList()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `appId` | `java.lang.Long` |
| `source` | `com.seeyon.udc.common.enums.DtoSourceEnum` |
| `currentDtoFullName` | `java.lang.String` |

## `ExtendAppAuthCheckInfoDto`（4 字段）

`com.seeyon.udc.dto.ExtendAppAuthCheckInfoDto`

被这些方法当入参：

- `ExtendAppOperationAuthCheck.hasRight()`（裸参数）

| 字段 | 类型 |
|---|---|
| `appInfo` | `com.seeyon.udc.common.dto.ApplicationDto` |
| `memberIds` | `java.util.List<java.lang.Long>` |
| `authorizationEnum` | `com.seeyon.udc.collaboration.enums.AuthorizationEnum` |
| `memberRights` | `java.util.List<java.lang.String>` |

## `BaseApplicationSearchDto`（4 字段）

`com.seeyon.udc.dto.app.BaseApplicationSearchDto`

被这些方法当入参：

- `ApplicationManagerAppService.getDependsLayoutAppInfo()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `appId` | `java.lang.Long` |
| `guid` | `java.lang.Long` |
| `appName` | `java.lang.String` |

## `QueryFormInfoDto`（4 字段）

`com.seeyon.udc.dto.form.QueryFormInfoDto`

被这些方法当入参：

- `ApplicationManagerAppService.selectAppDeployState()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `appId` | `java.lang.Long` |
| `deployType` | `com.seeyon.udc.common.enums.DeployTypeEnum` |
| `appVersion` | `java.lang.String` |

## `AppHanoverDto`（4 字段）

`com.seeyon.udc.dto.member.AppHanoverDto`

被这些方法当入参：

- `AppCollaborationAppService.handoverApp()`（包装入参）
- `ApplicationManagerAppService.handoverApp()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `appId` | `java.lang.Long` |
| `memberId` | `java.lang.Long` |
| `memberName` | `java.lang.String` |

## `SearchDesignMetadataDto`（4 字段）

`com.seeyon.udc.dto.meta.SearchDesignMetadataDto`

被这些方法当入参：

- `DesignMetadataQueryAppService.selectServiceMetadata()`（包装入参）
- `DesignMetadataQueryAppService.selectEntityMetadata()`（包装入参）
- `DesignMetadataQueryAppService.selectEntityMetadataExcludeBoot()`（包装入参）
- `DesignMetadataQueryAppService.selectAggMetadata()`（包装入参）
- `DesignMetadataQueryAppService.selectAggMetadataExcludeBoot()`（包装入参）
- `DesignMetadataQueryAppService.selectRestApiMetadata()`（包装入参）
- … 另 12 处

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `appName` | `java.lang.String` |
| `appId` | `java.lang.Long` |
| `appVersion` | `java.lang.String` |

## `PageProcessEventSearchDto`（4 字段）

`com.seeyon.udc.dto.page.PageProcessEventSearchDto`

被这些方法当入参：

- `PageProcessEventAppService.selectListByCondition()`（包装入参）
- `UdcPageProcessEventService.selectProcessEventListByCondition()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `appName` | `java.lang.String` |
| `pageGuId` | `java.lang.Long` |
| `pageType` | `java.lang.String` |

## `ShelfDependRequestDto`（4 字段）

`com.seeyon.udc.dto.shelf.ShelfDependRequestDto`

被这些方法当入参：

- `ApplicationManagerAppService.getShelfDepend()`（包装入参）

| 字段 | 类型 |
|---|---|
| `appId` | `java.lang.Long` |
| `appName` | `java.lang.String` |
| `appVersion` | `java.lang.String` |
| `tenantConstraint` | `boolean` |

## `AppDbInfoDto`（3 字段）

`com.seeyon.udc.common.dto.AppDbInfoDto`

被这些方法当入参：

- `UdcDataBaseSqlGenerator.getChangeList()`（裸参数）
- `UdcDataBaseSqlGenerator.getDropChangeList()`（裸参数）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `catalogName` | `java.lang.String` |
| `schemaName` | `java.lang.String` |

## `AppInfoExportDto`（3 字段）

`com.seeyon.udc.common.dto.AppInfoExportDto`

被这些方法当入参：

- `ApplicationManagerAppService.exportAppInfos()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `hostAppName` | `java.lang.String` |
| `appGuid` | `java.lang.Long` |

## `ApplicationImportDto`（3 字段）

`com.seeyon.udc.common.dto.ApplicationImportDto`

被这些方法当入参：

- `ApplicationManagerAppService.importAppWithDto()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `storageKey` | `java.lang.String` |
| `params` | `java.util.Map<java.lang.String, java.lang.Object>` |

## `DataTypeQueryParamDto`（3 字段）

`com.seeyon.udc.common.dto.DataTypeQueryParamDto`

被这些方法当入参：

- `DataTypeAppService.selectDataTypeByParams()`（包装入参）

| 字段 | 类型 |
|---|---|
| `dataTypeCategories` | `java.util.List<com.seeyon.udc.common.enums.DataTypeCategoryEnum>` |
| `appId` | `java.lang.Long` |
| `sourceId` | `java.lang.Long` |

## `DeployFormDto`（3 字段）

`com.seeyon.udc.common.dto.DeployFormDto`

被这些方法当入参：

- `ApplicationManagerAppService.deployForm()`（包装入参）
- `ApplicationAppService.deployForm()`（包装入参）

| 字段 | 类型 |
|---|---|
| `businessType` | `com.seeyon.udc.common.enums.DeployBusinessTypeEnum` |
| `republish` | `java.lang.Boolean` |
| `sandboxId` | `java.lang.Long` |

## `DeployNormalDto`（3 字段）

`com.seeyon.udc.common.dto.DeployNormalDto`

被这些方法当入参：

- `ApplicationManagerAppService.deployNormal()`（包装入参）
- `ApplicationAppService.deployNormal()`（包装入参）

| 字段 | 类型 |
|---|---|
| `lockCompatibility` | `boolean` |
| `generateLog` | `boolean` |
| `entityFullNameCondition` | `java.util.Map<java.lang.String, java.util.Map<java.lang.String, java.lang.Object>>` |

## `EventAndDataDto`（3 字段）

`com.seeyon.udc.common.dto.EventAndDataDto`

被这些方法当入参：

- `DataTransferObjectAppService.createDtoWithAttrs4EntityEvent()`（包装入参）
- `DataTransferObjectAppService.updateDtoWithAttrs4EntityEvent()`（包装入参）
- `EventWithDataAppService.createWithEventData()`（包装入参）
- `EventWithDataAppService.updateWithEventData()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `eventDataList` | `java.util.List<com.seeyon.udc.common.dto.DataTransferObjectDto>` |
| `sourceType` | `com.seeyon.udc.common.enums.DtoSourceTypeEnum` |

## `QueryRuleByEntityDto`（3 字段）

`com.seeyon.udc.common.dto.QueryRuleByEntityDto`

被这些方法当入参：

- `UdcRuleAppService.selectRuleByEntity()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `appName` | `java.lang.String` |
| `sourceEntityFullName` | `java.lang.String` |

## `UdcCtpEnumItemSearchDto`（3 字段）

`com.seeyon.udc.common.dto.UdcCtpEnumItemSearchDto`

被这些方法当入参：

- `UdcCtpEnumAppService.selectCtpEnumItemById()`（包装入参）
- `UdcCtpEnumAppService.selectCtpEnumItemByEnumId()`（包装入参）
- `UdcCtpEnumAppService.selectCtpEnumItemByAppNameAndEnumCode()`（包装入参）
- `UdcCtpEnumAppService.selectCtpEnumItemSimpleByAppNameAndEnumCode()`（包装入参）
- `UdcCtpEnumAppService.selectCtpEnumItemSimpleByAppNameAndEnumCodes()`（包装入参）
- `UdcCtpEnumAppService.selectByEnumIds()`（包装入参）
- … 另 3 处

| 字段 | 类型 |
|---|---|
| `enumItemId` | `java.lang.Long` |
| `dataStatus` | `java.lang.Boolean` |
| `needParent` | `java.lang.Boolean` |

## `UdcPortalPortletSortNoParamDto`（3 字段）

`com.seeyon.udc.common.dto.UdcPortalPortletSortNoParamDto`

被这些方法当入参：

- `UdcPortalPortletAppService.updatePortletSortNos()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `portletSortNoMap` | `java.util.Map<java.lang.String, java.lang.Integer>` |
| `appCode` | `java.lang.String` |

## `UdcPortletBatchOperateDto`（3 字段）

`com.seeyon.udc.common.dto.UdcPortletBatchOperateDto`

被这些方法当入参：

- `UdcPortalPortletAppService.deletePortletByIds()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `appCode` | `java.lang.String` |
| `portletIdList` | `java.util.List<java.lang.String>` |

## `UdcSerialRangeSearchDto`（3 字段）

`com.seeyon.udc.common.dto.UdcSerialRangeSearchDto`

被这些方法当入参：

- `UdcSerialSchemeAppService.selectSerialRange()`（包装入参）

| 字段 | 类型 |
|---|---|
| `hostAppName` | `java.lang.String` |
| `serialSchemeIds` | `java.util.List<java.lang.Long>` |
| `selectAllFlag` | `java.lang.Boolean` |

## `PageMetaDataSearch4PageDto`（3 字段）

`com.seeyon.udc.dto.PageMetaDataSearch4PageDto`

被这些方法当入参：

- `UdcMetaDataAppService.selectPageMetaData()`（包装入参）
- `UdcMetaDataAppService.selectPageLayoutInfoMetaData()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `appId` | `java.lang.Long` |
| `id` | `java.lang.Long` |

## `PagesMetaDataSearch4PageDto`（3 字段）

`com.seeyon.udc.dto.PagesMetaDataSearch4PageDto`

被这些方法当入参：

- `UdcMetaDataAppService.selectPageInfoMetaData()`（包装入参）
- `UdcMetaDataAppService.selectPageMetaDataByMasterApp()`（包装入参）
- `UdcMetaDataAppService.selectAllLayoutMetaDataByAppIncludeHost()`（包装入参）
- `UdcMetaDataAppService.selectFunctionNodeWithPageInfoDtoTreeByApp()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `appId` | `java.lang.Long` |
| `id` | `java.util.List<java.lang.Long>` |

## `ApplicationSearchDto`（3 字段）

`com.seeyon.udc.dto.app.ApplicationSearchDto`

被这些方法当入参：

- `ApplicationManagerAppService.selectAppByUser()`（包装入参）
- `ApplicationManagerAppService.selectAppByUserAndGuid()`（包装入参）
- `ApplicationManagerAppService.selectAppByUserAndId()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `collaboratorsType` | `com.seeyon.udc.enums.QueryCollaboratorsTypeEnum` |
| `pageInfo` | `com.seeyon.boot.transport.PageInfo` |

## `OnlyPageApplicationUpgradeDto`（3 字段）

`com.seeyon.udc.dto.form.OnlyPageApplicationUpgradeDto`

被这些方法当入参：

- `ApplicationManagerAppService.upgradeOnlyPageApplication()`（包装入参）
- `AsyncAppService.upgradeOnlyPageApplicationAsync()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `ids` | `java.util.List<java.lang.Long>` |
| `upgradeInfos` | `java.util.List<com.seeyon.udc.dto.form.OnlyPageApplicationUpgradeInfoDto>` |

## `AppBatchHandoverDto`（3 字段）

`com.seeyon.udc.dto.member.AppBatchHandoverDto`

被这些方法当入参：

- `AppCollaborationAppService.batchHandoverApp()`（包装入参）

| 字段 | 类型 |
|---|---|
| `appGuidList` | `java.util.List<java.lang.Long>` |
| `memberId` | `java.lang.Long` |
| `memberName` | `java.lang.String` |

## `MemberAddDto`（3 字段）

`com.seeyon.udc.dto.member.MemberAddDto`

被这些方法当入参：

- `ApplicationManagerAppService.createMember()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `appId` | `java.lang.Long` |
| `members` | `java.util.List<com.seeyon.udc.dto.member.UdcMemberDto>` |

## `UdcRoleRegisterDto`（3 字段）

`com.seeyon.udc.dto.user.UdcRoleRegisterDto`

被这些方法当入参：

- `ResourceAppService.registerRole()`（包装入参）

| 字段 | 类型 |
|---|---|
| `code` | `java.lang.String` |
| `name` | `java.lang.String` |
| `appId` | `java.lang.Long` |

## `DataFlowMappingInitQueryDto`（2 字段）

`com.seeyon.udc.common.dto.DataFlowMappingInitQueryDto`

被这些方法当入参：

- `DataFlowMappingAppService.selectMappingInitData()`（包装入参）

| 字段 | 类型 |
|---|---|
| `sourceEntity` | `com.seeyon.udc.common.dto.EntityInitParam` |
| `targetEntity` | `com.seeyon.udc.common.dto.EntityInitParam` |

## `DeployFerryDto`（2 字段）

`com.seeyon.udc.common.dto.DeployFerryDto`

被这些方法当入参：

- `ApplicationManagerAppService.migrationApp()`（包装入参）

| 字段 | 类型 |
|---|---|
| `appName` | `java.lang.String` |
| `appVersion` | `java.lang.String` |

## `TemplateApplicationDto`（2 字段）

`com.seeyon.udc.common.dto.TemplateApplicationDto`

被这些方法当入参：

- `ApplicationAppService.createFromTemplate()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `templateAppName` | `java.lang.String` |

## `UdcCtpEnumsSearchDto`（2 字段）

`com.seeyon.udc.common.dto.UdcCtpEnumsSearchDto`

被这些方法当入参：

- `UdcCtpEnumAppService.selectCtpEnumByIds()`（包装入参）

| 字段 | 类型 |
|---|---|
| `code` | `java.util.List<java.lang.String>` |
| `enumId` | `java.util.List<java.lang.Long>` |

## `EntityMetaDataSearch4PageDto`（2 字段）

`com.seeyon.udc.dto.EntityMetaDataSearch4PageDto`

被这些方法当入参：

- `UdcMetaDataAppService.selectEntityMetaData()`（包装入参）
- `UdcMetaDataAppService.selectAggEntityIncludeAssociation()`（包装入参）
- `UdcMetaDataAppService.selectAggEntity()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `id` | `java.lang.Long` |

## `UdcReferMetaDataSearch4PageDto`（2 字段）

`com.seeyon.udc.dto.UdcReferMetaDataSearch4PageDto`

被这些方法当入参：

- `UdcMetaDataAppService.mergeReferMetaData()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `customReferId` | `java.lang.String` |

## `AppCategoryDto`（2 字段）

`com.seeyon.udc.dto.member.AppCategoryDto`

被这些方法当入参：

- `ApplicationManagerAppService.updateAppCategoryBatch()`（包装入参）

| 字段 | 类型 |
|---|---|
| `oldCategoryId` | `java.lang.Long` |
| `newCategoryId` | `java.lang.Long` |

## `SearchDesignMetadataByFullNameDto`（2 字段）

`com.seeyon.udc.dto.meta.SearchDesignMetadataByFullNameDto`

被这些方法当入参：

- `DesignMetadataQueryAppService.selectEntityMetadataByFullName()`（包装入参）
- `DesignMetadataQueryAppService.selectAggMetadataByFullName()`（包装入参）
- `DesignMetadataQueryAppService.selectEntityListByAgg()`（包装入参）
- `DesignMetadataQueryAppService.selectRestApiMetadataByFullName()`（包装入参）
- `DesignMetadataQueryAppService.selectDtoMetadataByFullName()`（包装入参）
- `DesignMetadataQueryAppService.selectEnumMetadataByFullName()`（包装入参）
- … 另 9 处

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `fullName` | `java.lang.String` |

## `SearchDesignMetadataByFullNamesDto`（2 字段）

`com.seeyon.udc.dto.meta.SearchDesignMetadataByFullNamesDto`

被这些方法当入参：

- `DesignMetadataQueryAppService.selectEntityMetadataByFullNames()`（包装入参）
- `DesignMetadataQueryAppService.selectAggMetadataByFullNames()`（包装入参）
- `DesignMetadataQueryAppService.selectRestApiMetadataByFullNames()`（包装入参）
- `DesignMetadataQueryAppService.selectDtoMetadataByFullNames()`（包装入参）
- `DesignMetadataQueryAppService.selectEnumMetadataByFullNames()`（包装入参）
- `DesignMetadataQueryAppService.selectAggEntityMetadataByFullNames()`（包装入参）
- … 另 5 处

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `fullNames` | `java.util.List<java.lang.String>` |

## `ShelfCompatibilityLockRequestDto`（2 字段）

`com.seeyon.udc.dto.shelf.ShelfCompatibilityLockRequestDto`

被这些方法当入参：

- `ApplicationManagerAppService.shelfCompatibilityLock()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
| `appId` | `java.lang.Long` |

## `ThirdServiceQueryDto`（2 字段）

`com.seeyon.udc.microflow.dto.ThirdServiceQueryDto`

被这些方法当入参：

- `MicroFlowUpgradeAppService.upgradeThirdServiceByNames()`（包装入参）

| 字段 | 类型 |
|---|---|
| `appId` | `java.lang.String` |
| `serviceName` | `java.lang.String` |

## `IntegrationApplicationDto`（1 字段）

`com.seeyon.udc.dto.form.IntegrationApplicationDto`

被这些方法当入参：

- `ApplicationManagerAppService.createIntegrationApplication()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |

## `ApplicationWithMemberDto`（1 字段）

`com.seeyon.udc.dto.member.ApplicationWithMemberDto`

被这些方法当入参：

- `ApplicationManagerAppService.updateWithMember()`（包装入参）

| 字段 | 类型 |
|---|---|
| `memberList` | `java.util.List<com.seeyon.udc.dto.member.UdcMemberDto>` |

## `UdcAppMetaDataQueryDto`（1 字段）

`com.seeyon.udc.dto.meta.UdcAppMetaDataQueryDto`

被这些方法当入参：

- `BaseDesignMetadataQueryService.selectByCondition()`（裸参数）
- `DesignMetadataQueryAppService.selectAggEntityMetadataByCondition()`（包装入参）

| 字段 | 类型 |
|---|---|
| `appId` | `java.lang.Long` |

## `UdcResourceDeleteDto`（1 字段）

`com.seeyon.udc.dto.user.UdcResourceDeleteDto`

被这些方法当入参：

- `ResourceAppService.deleteByRef()`（包装入参）
- `ResourceAppService.deleteByPage()`（包装入参）

| 字段 | 类型 |
|---|---|
| `deleteCode` | `java.util.List<java.lang.String>` |

## `UdcParameterDto`（1 字段）

`com.seeyon.udc.parameter.dto.UdcParameterDto`

被这些方法当入参：

- `ParameterAppService.create()`（包装入参）
- `ParameterAppService.update()`（包装入参）

| 字段 | 类型 |
|---|---|
| `serialVersionUID` | static `long` |
