# 表达式：接口与方法签名

> 自动生成，勿手改。`tools/core/platform/emit_domain_surfaces.py` 重跑即可。
> 用途：表达式引擎：函数、解析、语义、脚本构建
> 规模：242 类 / 21 接口 / 15 个关键类 / 1547 方法。包前缀 `com.seeyon.boot.starter.formula`。
> 签名逐字来自 javap 原文，已去掉 `public` 等修饰前缀与 `throws`。

## 一、接口（21）

### `Function`（7 方法） extends Annotation

`com.seeyon.boot.starter.formula.engine.annotation.Function`

```java
    int category();
    java.lang.String displayName();
    java.lang.String description();
    int sort();
    boolean hidden();
    com.seeyon.boot.starter.formula.engine.enums.TerminalSupportTypeEnum terminalSupport();
    boolean customAggFunction();
```

### `ReturnValue`（4 方法） extends Annotation

`com.seeyon.boot.starter.formula.engine.annotation.ReturnValue`

```java
    int dataType();
    java.lang.String description();
    java.lang.String appName();
    java.lang.String fullName();
```

### `Parameter`（3 方法） extends Annotation

`com.seeyon.boot.starter.formula.engine.annotation.Parameter`

```java
    java.lang.String displayName();
    java.lang.String description();
    com.seeyon.boot.enums.DataType dataType();
```

### `Caller`（3 方法）

`com.seeyon.boot.starter.formula.engine.extension.Caller`

```java
    java.lang.Object call(java.lang.Object[]);
    java.lang.Object callWithType(java.lang.Object[], java.lang.String, java.lang.String);
    java.lang.String getOperator();
```

### `ScriptBuilderInterceptor`（3 方法）

`com.seeyon.boot.starter.formula.parser.scriptbuilder.ScriptBuilderInterceptor`

```java
    default void before(com.seeyon.boot.starter.formula.parser.ast.ASTNode, com.seeyon.boot.starter.formula.parser.scriptbuilder.ScriptBuildContext);
    default void after(com.seeyon.boot.starter.formula.parser.ast.ASTNode, com.seeyon.boot.starter.formula.parser.scriptbuilder.ScriptBuildContext);
    com.seeyon.boot.starter.formula.parser.ast.ASTNodeType getNodeType();
```

### `CallerSemanticAnalyzer`（3 方法）

`com.seeyon.boot.starter.formula.parser.semantic.caller.CallerSemanticAnalyzer`

```java
    com.seeyon.boot.starter.formula.dto.ExpressionDataType analyze(com.seeyon.boot.starter.formula.parser.ast.ASTNode, com.seeyon.boot.starter.formula.parser.semantic.SemanticAnalyzer);
    java.lang.String getOperatorName();
    default com.seeyon.boot.starter.formula.enums.CallerAnalyzeStrategy getAnalyzeStrategy();
```

### `ParamLoadService`（2 方法） extends Annotation

`com.seeyon.boot.starter.formula.common.annotation.ParamLoadService`

```java
    java.lang.String type();
    boolean useCustom();
```

### `ExprConsistencyValidator`（2 方法）

`com.seeyon.boot.starter.formula.domain.validation.ExprConsistencyValidator`

```java
    com.seeyon.boot.starter.formula.dto.consistency.ConsistencyValidateResult validateConsistency(com.seeyon.boot.starter.formula.dto.ExpressionDefinitionDto);
    com.seeyon.boot.starter.formula.dto.consistency.ConsistencyValidateResult validateConsistency(com.seeyon.boot.starter.formula.dto.consistency.ConsistencyValidateConfig);
```

### `ParamLinkage`（2 方法） extends Annotation

`com.seeyon.boot.starter.formula.engine.annotation.ParamLinkage`

```java
    boolean isLinkage();
    int linkageIndex();
```

### `ExpressionFilter`（1 方法） extends Annotation

`com.seeyon.boot.starter.formula.common.annotation.ExpressionFilter`

```java
    int order();
```

### `ControlDataResolver`（1 方法）

`com.seeyon.boot.starter.formula.domain.controldata.ControlDataResolver`

```java
    void resolveControlData(com.seeyon.boot.starter.formula.dto.ExpressionToken, java.lang.StringBuilder, com.seeyon.boot.starter.formula.dto.ExpressionSaveDto);
```

### `ExprOutsideService`（1 方法）

`com.seeyon.boot.starter.formula.domain.service.param.ExprOutsideService`

```java
    java.util.List<com.seeyon.boot.starter.formula.dto.variable.SchemaStructureDto> loadParamSchemaInfo(com.seeyon.boot.starter.formula.dto.variable.VariableSchemaLoadDto);
```

### `ExpressionValidationFilter`（1 方法）

`com.seeyon.boot.starter.formula.domain.validation.filter.ExpressionValidationFilter`

```java
    void doFilter(com.seeyon.boot.starter.formula.dto.ExpressionSaveDto, com.seeyon.boot.starter.formula.domain.validation.filter.FilterChain);
```

### `Parameters`（1 方法） extends Annotation

`com.seeyon.boot.starter.formula.engine.annotation.Parameters`

```java
    com.seeyon.boot.starter.formula.engine.annotation.Parameter[] value();
```

### `FunctionSupporter`（1 方法） extends Annotation

`com.seeyon.boot.starter.formula.init.FunctionSupporter`

```java
    java.lang.String[] functions();
```

### `ExprHOF`（1 方法）

`com.seeyon.boot.starter.formula.parser.ExprHOF`

```java
    com.seeyon.boot.starter.formula.parser.ast.ASTNode hoc()
```

### `ExpressionScriptBuilder`（1 方法）

`com.seeyon.boot.starter.formula.parser.scriptbuilder.ExpressionScriptBuilder`

```java
    java.lang.String build(com.seeyon.boot.starter.formula.parser.ast.ASTNode, com.seeyon.boot.starter.formula.parser.scriptbuilder.ScriptBuildContext);
```

### `FunctionSemanticAnalyzer`（1 方法）

`com.seeyon.boot.starter.formula.parser.semantic.function.FunctionSemanticAnalyzer`

```java
    com.seeyon.boot.starter.formula.dto.ExpressionDataType analyze(com.seeyon.boot.starter.formula.parser.ast.ASTNode, com.seeyon.boot.starter.formula.parser.semantic.SemanticAnalyzer);
```

### `FormulaDao`（0 方法） extends CtpFormula>

`com.seeyon.boot.starter.formula.domain.dao.FormulaDao`

```java
```

### `FunctionClass`（0 方法） extends Annotation

`com.seeyon.boot.starter.formula.engine.annotation.FunctionClass`

```java
```

### `ExtensionFunctionScriptBuilder`（0 方法） extends ExpressionScriptBuilder

`com.seeyon.boot.starter.formula.parser.scriptbuilder.ExtensionFunctionScriptBuilder`

```java
```

## 二、关键类（15）

### `ExpressionCommonUtil`（41 方法）

`com.seeyon.boot.starter.formula.utils.ExpressionCommonUtil`

```java
    static com.seeyon.boot.starter.formula.dto.variable.SchemaStructureDto getPreSchema(com.seeyon.boot.starter.formula.dto.ExpressionToken, java.util.Map<java.lang.String, com.seeyon.boot.starter.formula.dto.variable.SchemaStructureDto>);
    static com.seeyon.boot.starter.formula.dto.variable.SchemaStructureDto getPreSchema(java.lang.String, java.util.Map<java.lang.String, com.seeyon.boot.starter.formula.dto.variable.SchemaStructureDto>);
    static java.lang.String[] getVariableArray(java.lang.String);
    static java.lang.String getSystemVaribleFunction(java.lang.String);
    static java.util.Map<java.lang.String, com.seeyon.boot.starter.formula.dto.variable.SchemaStructureDto> getSchemaMap(java.util.List<com.seeyon.boot.starter.formula.dto.variable.SchemaStructureDto>);
    static com.seeyon.boot.starter.formula.dto.variable.SchemaStructureDto getCurrentSchema(com.seeyon.boot.starter.formula.dto.ExpressionToken, com.seeyon.boot.starter.formula.dto.variable.SchemaStructureDto);
    static com.seeyon.boot.starter.formula.dto.variable.SchemaStructureDto getCurrentSchema(java.lang.String, com.seeyon.boot.starter.formula.dto.variable.SchemaStructureDto);
    static com.seeyon.boot.starter.formula.dto.variable.SchemaStructureDto getCurrentSchema(java.lang.String[], com.seeyon.boot.starter.formula.dto.variable.SchemaStructureDto);
    static com.seeyon.boot.starter.formula.dto.variable.SchemaStructureDto getCurrentSchema(com.seeyon.boot.starter.formula.dto.ExpressionToken, java.util.Map<java.lang.String, com.seeyon.boot.starter.formula.dto.variable.SchemaStructureDto>);
    static com.seeyon.boot.starter.formula.dto.variable.SchemaStructureDto getCurrentSchema(java.lang.String, java.util.Map<java.lang.String, com.seeyon.boot.starter.formula.dto.variable.SchemaStructureDto>);
    static com.seeyon.boot.starter.formula.dto.variable.SchemaStructureDto getCurrentSchema(java.lang.String, java.util.List<com.seeyon.boot.starter.formula.dto.variable.SchemaStructureDto>);
    static java.lang.String getTokenRootName(com.seeyon.boot.starter.formula.dto.ExpressionToken);
    static java.lang.String getTokenRootName(java.lang.String);
    static java.util.List<com.seeyon.boot.starter.formula.dto.ExpressionToken> getVariableTokens(java.util.List<com.seeyon.boot.starter.formula.dto.ExpressionToken>);
    static java.util.List<com.seeyon.boot.starter.formula.dto.ExpressionToken> getVariableTokensIgnoreAppParam(java.util.List<com.seeyon.boot.starter.formula.dto.ExpressionToken>, java.util.List<com.seeyon.boot.starter.formula.dto.variable.SchemaStructureDto>);
    static java.util.List<com.seeyon.boot.starter.formula.dto.ExpressionToken> getAllAppParamTokens(java.util.List<com.seeyon.boot.starter.formula.dto.ExpressionToken>, java.util.List<com.seeyon.boot.starter.formula.dto.variable.SchemaStructureDto>);
    static private static void getAppParameterTokens(java.util.List<com.seeyon.boot.starter.formula.dto.ExpressionToken>, java.util.List<com.seeyon.boot.starter.formula.dto.ExpressionToken>, java.util.Map<java.lang.String, com.seeyon.boot.starter.formula.dto.variable.SchemaStructureDto>);
    static java.util.Map<java.lang.String, com.seeyon.boot.starter.formula.engine.dto.FunctionDto> getFunctionMap();
    static java.util.List<com.seeyon.boot.starter.formula.dto.variable.SchemaStructureDto> getSimpleSchemas(java.util.List<com.seeyon.boot.starter.formula.dto.ExpressionToken>, java.util.List<com.seeyon.boot.starter.formula.dto.variable.SchemaStructureDto>);
    static java.util.List<com.seeyon.boot.starter.formula.dto.ExpressionToken> getUdcEnumConstantTokens(java.util.List<com.seeyon.boot.starter.formula.dto.ExpressionToken>);
    static java.util.List<com.seeyon.boot.starter.formula.dto.ExpressionToken> getAllConstantTokens(java.util.List<com.seeyon.boot.starter.formula.dto.ExpressionToken>);
    static private static void markTreeNode(com.seeyon.boot.starter.formula.dto.variable.SchemaStructureDto, java.lang.String[]);
    static private static void clearUnMarkedNode(com.seeyon.boot.starter.formula.dto.variable.SchemaStructureDto);
    static private static void getVariableTokens(java.util.List<com.seeyon.boot.starter.formula.dto.ExpressionToken>, java.util.List<com.seeyon.boot.starter.formula.dto.ExpressionToken>);
    static private static void getVariableTokensIgnoreAppParam(java.util.List<com.seeyon.boot.starter.formula.dto.ExpressionToken>, java.util.List<com.seeyon.boot.starter.formula.dto.ExpressionToken>, java.util.Map<java.lang.String, com.seeyon.boot.starter.formula.dto.variable.SchemaStructureDto>);
    static private static boolean isParameter(com.seeyon.boot.starter.formula.dto.variable.SchemaStructureDto);
    static java.lang.String getI18nValueBySystemDefault(java.lang.String);
    static boolean isDefaultValueNullFunctionToken(com.seeyon.boot.starter.formula.dto.ExpressionToken, java.util.Map<java.lang.String, com.seeyon.boot.starter.formula.dto.variable.SchemaStructureDto>);
    static boolean isDefaultValueNullFunctionToken(com.seeyon.boot.starter.formula.parser.ast.ASTNode, java.util.Map<java.lang.String, com.seeyon.boot.starter.formula.dto.variable.SchemaStructureDto>);
    static java.lang.String getExecutableExpression(com.seeyon.boot.starter.formula.dto.ExpressionSaveDto, com.seeyon.boot.starter.formula.parser.ast.ASTNode, java.util.Map<java.lang.String, com.seeyon.boot.starter.formula.dto.variable.SchemaStructureDto>);
    static java.lang.String getConstantCtpEnumFullName(com.seeyon.boot.starter.formula.dto.ExpressionToken);
    static java.lang.String getVariableCtpEnumFullName(com.seeyon.boot.starter.formula.dto.variable.SchemaStructureDto);
    static java.lang.String getConstantEntityFullName(com.seeyon.boot.starter.formula.dto.ExpressionToken);
    static java.lang.String getVariableEntityFullName(com.seeyon.boot.starter.formula.dto.variable.SchemaStructureDto);
    static private static java.lang.String getCtpEnumUniqueFullName(com.seeyon.boot.starter.formula.dto.ControlData);
    static private static java.lang.String getEntityUniqueFullName(com.seeyon.boot.starter.formula.dto.ControlData);
    static private static boolean isI18nJsonString(java.lang.String);
    static private static void getUdcEnumConstantTokens(java.util.List<com.seeyon.boot.starter.formula.dto.ExpressionToken>, java.util.List<com.seeyon.boot.starter.formula.dto.ExpressionToken>);
    static private static void getAllConstantTokens(java.util.List<com.seeyon.boot.starter.formula.dto.ExpressionToken>, java.util.List<com.seeyon.boot.starter.formula.dto.ExpressionToken>);
```

### `ExpressionService`（37 方法）

`com.seeyon.boot.starter.formula.domain.service.ExpressionService`

```java
    com.seeyon.boot.starter.formula.dto.operator.QuickSymbolDto getQuickSymbols();
    com.seeyon.boot.starter.formula.dto.preset.PresetInfoDto loadSystemPresetVariable();
    com.seeyon.boot.starter.formula.dto.preset.PresetInfoDto loadSystemPresetVariableByCondition(com.seeyon.boot.starter.formula.dto.preset.PresetLoadConditionDto);
    com.seeyon.boot.starter.formula.dto.preset.SystemPresetVariableDto loadSystemVariable(java.lang.String);
    java.util.List<com.seeyon.boot.starter.formula.dto.preset.FunctionCategoryDto> loadFunctionInfo(com.seeyon.boot.starter.formula.dto.preset.PresetLoadConditionDto);
    private void setParamType(com.seeyon.boot.starter.formula.dto.preset.FunctionExtension, com.seeyon.boot.starter.formula.engine.dto.FunctionDto);
    private java.util.Map<java.lang.String, com.seeyon.boot.starter.formula.dto.preset.SystemVariableItems> getSystemFunctionName();
    java.util.List<com.seeyon.boot.starter.formula.dto.variable.SchemaStructureDto> selectSchemaByParamType(com.seeyon.boot.starter.formula.dto.variable.VariableSchemaLoadDto);
    com.seeyon.boot.starter.formula.dto.ExpressionDefinitionDto transform(com.seeyon.boot.starter.formula.dto.ExpressionSaveDto);
    java.lang.Boolean check(com.seeyon.boot.starter.formula.dto.ExpressionSaveDto);
    private java.lang.String getExprTranslation(java.util.List<com.seeyon.boot.starter.formula.dto.ExpressionToken>);
    private java.lang.String translateFunctionToken(com.seeyon.boot.starter.formula.dto.ExpressionToken);
    private java.lang.String getRuledFunctionTranslation(com.seeyon.boot.starter.formula.dto.ExpressionToken, com.seeyon.boot.starter.formula.engine.dto.FunctionDto);
    private void buildFunctionParamTranslation(com.seeyon.boot.starter.formula.dto.ExpressionToken, java.lang.StringBuilder);
    protected com.seeyon.boot.starter.formula.dto.runtime.ExprParamResult getExpressionStatement(com.seeyon.boot.starter.formula.dto.ExpressionSaveDto, com.seeyon.boot.starter.formula.parser.ast.ASTNode);
    java.util.Map<java.lang.String, java.lang.Object> getSystemVariableResult(java.lang.String);
    java.util.Map<java.lang.String, java.lang.Object> getSystemVariableResult();
    java.lang.Object getSystemVariableResultByName(java.lang.String);
    java.util.List<com.seeyon.boot.starter.formula.dto.preset.SystemPresetVariableDto> listSystemVariable();
    java.util.List<com.seeyon.boot.starter.formula.dto.preset.SystemPresetVariableDto> listSystemVariableByCondition(java.util.Map<java.lang.String, java.lang.Object>);
    private com.seeyon.boot.starter.formula.dto.ExpressionDesignDataDto copyToDesignDataDto(com.seeyon.boot.starter.formula.dto.ExpressionSaveDto);
    private com.seeyon.boot.starter.formula.dto.runtime.ExprParamResult getRuntimeParam(com.seeyon.boot.starter.formula.dto.ExpressionSaveDto);
    private boolean isControlDataOperator(com.seeyon.boot.starter.formula.dto.ExpressionToken);
    private boolean functionJumpable(com.seeyon.boot.starter.formula.engine.dto.FunctionDto, com.seeyon.boot.starter.formula.dto.preset.PresetLoadConditionDto);
    private java.lang.String getI18nValueByKey(java.lang.String);
    private java.util.List<com.seeyon.boot.starter.formula.dto.preset.SystemPresetVariableDto> getI18nSystemVariables();
    private java.util.Map<java.lang.String, com.seeyon.boot.starter.formula.dto.preset.FunctionDetailsDto> getFunctionMap(java.util.List<com.seeyon.boot.starter.formula.dto.preset.FunctionCategoryDto>);
```

### `ExprDateUtil`（17 方法）

`com.seeyon.boot.starter.formula.utils.ExprDateUtil`

```java
    static java.lang.String getFirstDateOfWeek();
    static java.lang.String getLastDateOfWeek();
    static java.lang.String getNextFirstDateOfWeek();
    static java.lang.String getNextLastDateOfWeek();
    static java.lang.String getPreFirstDateOfWeek();
    static java.lang.String getPreLastDateOfWeek();
    static java.time.LocalDateTime getLocalDateTime(java.util.Date);
    static void check(java.util.Date);
    static boolean isNullDate(java.util.Date);
    static boolean isDatePattern(java.lang.String);
    static boolean isDateTimePattern(java.lang.String);
    static boolean isTimePattern(java.lang.String);
    static boolean isTimeWithSecondPattern(java.lang.String);
    static boolean isTimeWithoutSecondPattern(java.lang.String);
    static boolean isLegalDatePattern(java.lang.String);
    static java.util.Date getNullDate();
    static java.lang.Long getSecondsOfTime(java.lang.String);
```

### `FormulaService`（16 方法）

`com.seeyon.boot.starter.formula.domain.service.FormulaService`

```java
    com.seeyon.boot.starter.formula.dto.FormulaOpResultDto validate(com.seeyon.boot.starter.formula.dto.FormulaDto);
    java.util.List<com.seeyon.boot.starter.formula.enums.FormulaFunctionCategoryEnum> getFormulaCategoryList();
    java.util.List<com.seeyon.boot.starter.formula.enums.FormulaDataTypeEnum> getFormulaDateTypeList();
    com.seeyon.boot.starter.formula.dto.FormulaOpResultDto create(com.seeyon.boot.starter.formula.dto.FormulaDto);
    private void addFunction(com.seeyon.boot.starter.formula.dto.FormulaDto);
    private void removeFunction(java.lang.String);
    com.seeyon.boot.starter.formula.engine.dto.FunctionDto formula2function(com.seeyon.boot.starter.formula.dto.FormulaDto);
    com.seeyon.boot.starter.formula.dto.FormulaOpResultDto update(com.seeyon.boot.starter.formula.dto.FormulaDto);
    com.seeyon.boot.starter.formula.dto.FormulaDto selectById(java.lang.Long);
    java.util.List<com.seeyon.boot.starter.formula.dto.FormulaDto> selectByIds(java.util.List<java.lang.Long>);
    com.seeyon.boot.transport.PageData<com.seeyon.boot.starter.formula.dto.FormulaDto> selectPageByCondition(com.seeyon.boot.transport.PageInfo, java.util.Map<java.lang.String, java.lang.Object>, com.seeyon.boot.transport.Sort);
    boolean exists(java.lang.String);
    com.seeyon.boot.starter.formula.dto.FormulaDto selectByName(java.lang.String);
    int deleteById(java.lang.Long);
    int deleteByIds(java.util.List<java.lang.Long>);
    java.util.List<com.seeyon.boot.starter.formula.dto.GrammarDto> getGrammarList();
```

### `ListFunctionUtil`（16 方法）

`com.seeyon.boot.starter.formula.utils.ListFunctionUtil`

```java
    static java.lang.String buildListFunction(com.seeyon.boot.starter.formula.dto.ExpressionToken, java.util.Map<java.lang.String, com.seeyon.boot.starter.formula.dto.variable.SchemaStructureDto>, com.seeyon.boot.starter.formula.dto.ExpressionSaveDto);
    static private static java.lang.String buildNormalAggFunction(java.lang.String, java.lang.String, java.lang.String);
    static private static java.lang.String buildLineMatchFunction(java.lang.String, java.lang.String, java.lang.String, java.lang.String);
    static private static java.lang.String buildConditionAggFunction(java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String);
    static private static java.lang.String buildListCountFunction(java.lang.String, java.lang.String, java.lang.String, java.lang.String);
    static private static java.lang.String buildConditionExpression(com.seeyon.boot.starter.formula.dto.ExpressionToken, java.lang.String, java.lang.String, java.util.Map<java.lang.String, com.seeyon.boot.starter.formula.dto.variable.SchemaStructureDto>, com.seeyon.boot.starter.formula.dto.ExpressionSaveDto);
    static private static void buildVariable(java.lang.StringBuilder, com.seeyon.boot.starter.formula.dto.ExpressionToken, java.lang.String, java.lang.String, java.util.Map<java.lang.String, com.seeyon.boot.starter.formula.dto.variable.SchemaStructureDto>);
    static java.lang.String getFunctionExprStr(com.seeyon.boot.starter.formula.dto.ExpressionToken, java.lang.String, java.lang.String, java.util.Map<java.lang.String, com.seeyon.boot.starter.formula.dto.variable.SchemaStructureDto>, com.seeyon.boot.starter.formula.dto.ExpressionSaveDto);
    static java.lang.String getAggPropertyName(com.seeyon.boot.starter.formula.dto.ExpressionToken, com.seeyon.boot.starter.formula.dto.preset.FunctionExtension);
    static java.lang.String getListTableName(java.util.List<java.util.List<com.seeyon.boot.starter.formula.dto.ExpressionToken>>, java.lang.Integer, java.util.Map<java.lang.String, com.seeyon.boot.starter.formula.dto.variable.SchemaStructureDto>);
    static private static java.lang.String getListTableName(java.util.List<com.seeyon.boot.starter.formula.dto.ExpressionToken>, java.util.Map<java.lang.String, com.seeyon.boot.starter.formula.dto.variable.SchemaStructureDto>);
    static java.lang.String getConditionExpression(com.seeyon.boot.starter.formula.dto.ExpressionToken, int, java.lang.String, java.lang.String, java.util.Map<java.lang.String, com.seeyon.boot.starter.formula.dto.variable.SchemaStructureDto>, com.seeyon.boot.starter.formula.dto.ExpressionSaveDto);
    static java.lang.String getListVariableName(java.util.List<java.util.List<com.seeyon.boot.starter.formula.dto.ExpressionToken>>, java.lang.Integer);
    static private static java.lang.String getListVariableName(java.util.List<com.seeyon.boot.starter.formula.dto.ExpressionToken>);
    static private static java.lang.String getAggPropertyParamKey(com.seeyon.boot.starter.formula.dto.ExpressionToken);
    static private static java.lang.String getDefaultNullFunction(com.seeyon.boot.starter.formula.dto.ExpressionToken, java.lang.String, java.lang.String, java.util.Map<java.lang.String, com.seeyon.boot.starter.formula.dto.variable.SchemaStructureDto>);
```

### `FormulaAppService`（12 方法）

`com.seeyon.boot.starter.formula.appservice.FormulaAppService`

```java
    com.seeyon.boot.transport.SingleResponse<com.seeyon.boot.starter.formula.dto.FormulaOpResultDto> validate(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.formula.dto.FormulaDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.boot.starter.formula.dto.FormulaOpResultDto> create(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.formula.dto.FormulaDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.boot.starter.formula.dto.FormulaOpResultDto> update(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.formula.dto.FormulaDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> deleteById(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> deleteByIds(com.seeyon.boot.transport.SingleRequest<java.util.List<java.lang.Long>>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.boot.starter.formula.enums.FormulaFunctionCategoryEnum> getFormulaCategoryList();
    com.seeyon.boot.transport.ListResponse<com.seeyon.boot.starter.formula.enums.FormulaDataTypeEnum> getFormulaDateTypeList();
    com.seeyon.boot.transport.SingleResponse<java.lang.Boolean> exists(com.seeyon.boot.transport.SingleRequest<java.lang.String>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.boot.starter.formula.dto.FormulaDto> selectById(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.boot.starter.formula.dto.FormulaDto> selectByIds(com.seeyon.boot.transport.SingleRequest<java.util.List<java.lang.Long>>);
    com.seeyon.boot.transport.PageResponse<com.seeyon.boot.starter.formula.dto.FormulaDto> selectPageByCondition(com.seeyon.boot.transport.PageRequest);
    com.seeyon.boot.transport.ListResponse<com.seeyon.boot.starter.formula.dto.GrammarDto> getGrammarList();
```

### `CallerDataTypeHelper`（12 方法）

`com.seeyon.boot.starter.formula.caller.CallerDataTypeHelper`

```java
    static java.lang.Integer getNumberTypeByObject(java.lang.Object);
    static java.lang.Integer getNumberTypeBiggerPriority(java.lang.Integer, java.lang.Integer);
    static boolean isNumberType(java.lang.Object);
    static java.lang.String getNumberStringValue(java.lang.Object);
    static boolean isZero(java.lang.Object);
    static int compareTo(java.lang.Object, java.lang.Object);
    static boolean isNumberTypeByString(java.lang.String);
    static boolean isFloat(java.lang.String);
    static boolean isInteger(java.lang.String);
    static boolean isNormalInteger(java.lang.String);
    static boolean isExceedInteger(java.lang.String);
    static boolean isExceedLong(java.lang.String);
```

### `ExpressionAppService`（11 方法）

`com.seeyon.boot.starter.formula.appservice.ExpressionAppService`

```java
    com.seeyon.boot.transport.SingleResponse<com.seeyon.boot.starter.formula.dto.operator.QuickSymbolDto> getQuickSymbols();
    com.seeyon.boot.transport.SingleResponse<com.seeyon.boot.starter.formula.dto.ExpressionDefinitionDto> transform(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.formula.dto.ExpressionSaveDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Boolean> check(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.formula.dto.ExpressionSaveDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.boot.starter.formula.dto.preset.PresetInfoDto> loadSystemPresetVariableByCondition(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.formula.dto.preset.PresetLoadConditionDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.boot.starter.formula.dto.preset.SystemPresetVariableDto> loadSystemVariable(com.seeyon.boot.transport.SingleRequest<java.lang.String>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.boot.starter.formula.dto.variable.SchemaStructureDto> selectSchemaByParamType(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.formula.dto.variable.VariableSchemaLoadDto>);
    com.seeyon.boot.transport.SingleResponse<java.util.Map<java.lang.String, java.lang.Object>> getSystemVariableResult(com.seeyon.boot.transport.SingleRequest<java.lang.String>);
    com.seeyon.boot.transport.SingleResponse<java.util.Map<java.lang.String, java.lang.Object>> getSystemVariableResult();
    com.seeyon.boot.transport.SingleResponse<java.lang.Object> getSystemVariableResultBySystemFunctionName(com.seeyon.boot.transport.SingleRequest<java.lang.String>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.boot.starter.formula.dto.preset.SystemPresetVariableDto> listSystemVariable();
    com.seeyon.boot.transport.ListResponse<com.seeyon.boot.starter.formula.dto.preset.SystemPresetVariableDto> listSystemVariableByCondition(com.seeyon.boot.transport.SingleRequest<java.util.Map<java.lang.String, java.lang.Object>>);
```

### `ExprSchemaReplaceUtil`（10 方法）

`com.seeyon.boot.starter.formula.utils.ExprSchemaReplaceUtil`

```java
    static com.seeyon.boot.starter.formula.dto.ExpressionDefinitionDto replaceForBpm(com.seeyon.boot.starter.formula.dto.ExpressionDefinitionDto, java.lang.String, java.lang.String);
    static void batchReplaceBpmRuntimeCtpEnumId(java.util.Map<java.lang.String, com.seeyon.boot.starter.formula.dto.ExpressionDefinitionDto>, java.lang.String);
    static void replaceBpmRuntimeExpressionCtpEnumId(com.seeyon.boot.starter.formula.dto.ExpressionDefinitionDto, java.lang.String);
    static private static com.seeyon.boot.starter.formula.dto.ExpressionDefinitionDto replaceExpressionCtpEnumId(com.seeyon.boot.starter.formula.dto.ExpressionDefinitionDto, java.util.Map<java.lang.String, java.lang.Object>, java.lang.String);
    static private static void replaceCtpEnumToken(java.lang.String, java.util.Map<java.lang.String, java.lang.Object>, com.seeyon.boot.starter.formula.dto.ExpressionToken);
    static private static java.util.Map<java.lang.String, java.lang.Object> getCtpEnumItemIdsRuntimeMetadata(java.lang.String);
    static java.lang.String replaceSingleCtpEnumItemId(java.lang.String, java.util.Map<java.lang.String, java.lang.Object>);
    static java.lang.String replaceMultiCtpEnumItemId(java.lang.String, java.util.Map<java.lang.String, java.lang.Object>);
```

### `ExprSchemaUtil`（10 方法）

`com.seeyon.boot.starter.formula.utils.ExprSchemaUtil`

```java
    static java.lang.String buildReferenceProperties(java.lang.String, java.lang.String, boolean);
    static java.lang.String buildInnerReferenceProperties(java.lang.Long, java.lang.String, boolean);
    static java.lang.String buildJavaEnumProperties(java.util.List<com.seeyon.boot.starter.formula.utils.ExprSchemaUtil$JavaEnumItem>, boolean);
    static java.lang.String buildJavaEnumProperties(java.util.List<com.seeyon.boot.starter.formula.utils.ExprSchemaUtil$JavaEnumItem>, boolean, java.lang.String);
    static java.lang.String buildCtpEnumProperties(java.lang.Long, java.lang.String, java.lang.String, java.lang.Long, boolean);
    static boolean isSingleReference(com.seeyon.boot.starter.formula.dto.variable.SchemaStructureDto);
    static boolean isSingleJavaEnum(com.seeyon.boot.starter.formula.dto.variable.SchemaStructureDto);
    static boolean isSingleCtpEnum(com.seeyon.boot.starter.formula.dto.variable.SchemaStructureDto);
    static boolean isDateOrDatetimeSchema(com.seeyon.boot.starter.formula.dto.variable.SchemaStructureDto);
    static private static boolean hasControlData(com.seeyon.boot.starter.formula.dto.variable.SchemaStructureDto);
```

### `ListFunctionParamUtil`（8 方法）

`com.seeyon.boot.starter.formula.parser.util.ListFunctionParamUtil`

```java
    static java.lang.String getConditionExpression4ListFunction(java.util.List<com.seeyon.boot.starter.formula.dto.ExpressionToken>, com.seeyon.boot.starter.formula.parser.ast.ASTNode, java.util.Map<java.lang.String, com.seeyon.boot.starter.formula.dto.variable.SchemaStructureDto>, java.lang.String, com.seeyon.boot.starter.formula.dto.ExpressionSaveDto);
    static java.lang.String getFieldPathByListableName(com.seeyon.boot.starter.formula.dto.ExpressionToken, java.lang.String);
    static java.lang.String getListTableVariableNameFromParam(com.seeyon.boot.starter.formula.dto.ExpressionToken, java.util.Map<java.lang.String, com.seeyon.boot.starter.formula.dto.variable.SchemaStructureDto>);
    static java.lang.String getListTableNameFromAggPropertyParam(com.seeyon.boot.starter.formula.parser.ast.ASTNode, java.util.Map<java.lang.String, com.seeyon.boot.starter.formula.dto.variable.SchemaStructureDto>);
    static java.lang.String getListTableNameByVariableName(java.lang.String);
    static boolean isAttributeOfListable(com.seeyon.boot.starter.formula.parser.ast.ASTNode, java.util.Map<java.lang.String, com.seeyon.boot.starter.formula.dto.variable.SchemaStructureDto>);
    static private static boolean isListTableVariable(com.seeyon.boot.starter.formula.dto.variable.SchemaStructureDto);
    static private static boolean isListTable(com.seeyon.boot.starter.formula.dto.variable.SchemaStructureDto);
```

### `FormulaResultTypeUtil`（6 方法）

`com.seeyon.boot.starter.formula.engine.utils.FormulaResultTypeUtil`

```java
    static boolean isInteger(java.lang.String);
    static boolean isFloat(java.lang.String);
    static java.lang.Object dataTypeTransfer(java.lang.Object, java.lang.String);
    static private static boolean isNull2Long(java.lang.Object, java.lang.String);
    static private static java.lang.String getResultTypeCaption(java.lang.Object);
```

### `ExpressionEncryptUtil`（6 方法）

`com.seeyon.boot.starter.formula.util.ExpressionEncryptUtil`

```java
    static java.lang.String encrypt(java.lang.String);
    static java.lang.String decrypt(java.lang.String);
    static java.lang.String AESEncrypt(java.lang.String);
    static java.lang.String AESDecrypt(java.lang.String, boolean);
    static java.lang.String decryptAlwaysSuccess(java.lang.String);
    static boolean isBase64Encoded(java.lang.String);
```

### `FunctionBeanUseService`（5 方法）

`com.seeyon.boot.starter.formula.domain.service.FunctionBeanUseService`

```java
    com.seeyon.ctp.metadata.api.MetadataQueryAppService getMetadataQueryAppService();
    com.seeyon.boot.starter.proxy.appservice.AppServiceReliableInvoker getAppServiceReliableInvoker();
    com.seeyon.boot.starter.parameter.domain.service.CtpParameterDefinitionService getCtpParameterDefinitionService();
    com.seeyon.boot.starter.parameter.domain.service.CtpParameterService getCtpParameterService();
    com.seeyon.ctp.metadata.api.LoadJarResourceAppService getLoadJarResourceAppService();
```

### `ParamSchemaStrategyService`（5 方法）

`com.seeyon.boot.starter.formula.domain.service.param.ParamSchemaStrategyService`

```java
    java.util.List<com.seeyon.boot.starter.formula.dto.variable.SchemaStructureDto> loadParamSchemaInfo(com.seeyon.boot.starter.formula.dto.variable.VariableSchemaLoadDto);
    private com.seeyon.boot.starter.formula.domain.service.param.ExprOutsideService getService(java.lang.String, java.lang.String);
    private com.seeyon.boot.starter.formula.domain.service.param.ExprOutsideService findAdaptorByServerName(java.util.List<com.seeyon.boot.starter.formula.domain.service.param.ExprOutsideService>, java.lang.String);
```
