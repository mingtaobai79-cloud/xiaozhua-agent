# 事项：接口与方法签名

> 自动生成，勿手改。`tools/core/platform/emit_domain_surfaces.py` 重跑即可。
> 用途：事项发起与流转（UDC 侧入口）
> 规模：122 类 / 13 接口 / 2 个关键类 / 1442 方法。包前缀 `com.seeyon.ctp.affair`。
> 签名逐字来自 javap 原文，已去掉 `public` 等修饰前缀与 `throws`。

## 一、接口（13）

### `AffairCommonAppService`（47 方法）

`com.seeyon.ctp.affair.api.common.AffairCommonAppService`

```java
    default com.seeyon.boot.transport.SingleResponse<com.seeyon.ctp.affair.dto.table.AffairDto> selectAffairById(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    default com.seeyon.boot.transport.SingleResponse<java.lang.Void> updateAffairDone(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Void> updateAffairDoneIdempotent(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.affair.message.dto.UpdateAffairDoneDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.ctp.affair.dto.table.AffairDto> selectListByCondition(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.affair.dto.base.AffairBaseConditionDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.ctp.affair.dto.base.AffairCountDto> countAffairByConditions(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.affair.dto.base.AffairCountConditionDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Void> createAffair(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.affair.message.dto.AffairCreateMessageDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Void> createAffairIdempotent(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.affair.message.dto.AffairCreateMessageIdempotentDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Void> updateAffair(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.affair.message.dto.AffairUpdateMessageDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Void> updateAffairIdempotent(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.affair.message.dto.AffairUpdateMessageIdempotentDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Void> updateAffairRead(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Void> updateAffairReadIdempotent(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.affair.message.dto.UpdateAffairReadDto>);
    default com.seeyon.boot.transport.SingleResponse<java.lang.Void> updateAffairTrack(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.affair.dto.track.AffairTrackUpdateDto>);
    default com.seeyon.boot.transport.SingleResponse<java.lang.Void> updateBpmCaseTrackToAffairTrack(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.affair.dto.track.AffairTrackUpgradeDto>);
    default com.seeyon.boot.transport.SingleResponse<java.lang.Void> updateBatchAffairByCondition(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.affair.dto.base.AffairUpdateBatchDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Void> updateBatchAffairByConditionIdempotent(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.affair.dto.base.AffairUpdateBatchIdempotentDto>);
    default com.seeyon.boot.transport.SingleResponse<com.seeyon.ctp.affair.dto.table.AffairSimpleDto> selectAffairSimpleById(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    default com.seeyon.boot.transport.ListResponse<com.seeyon.ctp.affair.dto.table.AffairSimpleDto> selectAffairSimpleByIds(com.seeyon.boot.transport.SingleRequest<java.util.List<java.lang.Long>>);
    default com.seeyon.boot.transport.ListResponse<com.seeyon.ctp.affair.dto.table.AffairSimpleDto> selectAffairSimpleListByCondition(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.affair.dto.base.AffairBaseConditionDto>);
    default com.seeyon.boot.transport.ListResponse<com.seeyon.ctp.affair.dto.table.AffairPropertyInfoDto> selectAffairPropertyInfoByCondition(com.seeyon.boot.transport.SingleRequest<java.util.Map<java.lang.String, java.lang.Object>>);
    default com.seeyon.boot.transport.PageResponse<com.seeyon.ctp.affair.dto.table.AffairDto> selectPageByCustomizeConditions(com.seeyon.boot.transport.PageDtoRequest<com.seeyon.ctp.affair.dto.search.AffairSearchCustomizeDto>);
    default com.seeyon.boot.transport.SingleResponse<java.util.Map<java.lang.String, java.lang.Object>> selectCountByCustomizeConditions(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.affair.dto.search.AffairSearchCustomizeDto>);
    default com.seeyon.boot.transport.ListResponse<com.seeyon.ctp.affair.dto.base.AffairOverTimeMsgDto> selectOvertimePendingAffair();
    default com.seeyon.boot.transport.SingleResponse<java.lang.Void> updateAffairById(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.affair.dto.table.AffairInfoDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.ctp.affair.dto.table.AffairSubmitInfoDto> selectSubmitInfoDtoById(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    default com.seeyon.boot.transport.SingleResponse<java.lang.Long> createAffairCategory(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.affair.dto.category.AffairFullCategoryDto>);
    default com.seeyon.boot.transport.SingleResponse<java.lang.Void> updateAffairCategory(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.affair.dto.category.AffairFullCategoryDto>);
    default com.seeyon.boot.transport.ListResponse<com.seeyon.ctp.affair.dto.category.AffairFullCategoryDto> searchAffairCategory(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.affair.dto.category.AffairFullCategoryDto>);
    default com.seeyon.boot.transport.PageResponse<com.seeyon.ctp.affair.dto.category.AffairFullCategoryDto> searchAffairCategoryPage(com.seeyon.boot.transport.PageRequest);
    default com.seeyon.boot.transport.SingleResponse<java.lang.Void> deleteAffairCategoryById(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    default com.seeyon.boot.transport.SingleResponse<java.lang.Void> deleteAffairCategoryByCondition(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.affair.dto.category.AffairDeleteCategoryConditionDto>);
    default com.seeyon.boot.transport.PageResponse<java.lang.Object> dynamicQueryAffairDtoPage(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.affair.dto.search.AffairDynamicQueryDto>);
    default com.seeyon.boot.transport.PageResponse<com.seeyon.ctp.affair.dto.table.AffairDto> selectPageByConditions(com.seeyon.boot.transport.PageRequest);
    default com.seeyon.boot.transport.PageResponse<com.seeyon.ctp.affair.dto.table.AffairDto> selectAffairPageByConditions(com.seeyon.boot.transport.PageRequest);
    default com.seeyon.boot.transport.SingleResponse<java.lang.Void> deleteAffairByIds(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.affair.dto.base.AffairCommonIdsDto>);
    default com.seeyon.boot.transport.SingleResponse<java.lang.Void> deleteAffairByObjectIds(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.affair.dto.base.AffairCommonIdsDto>);
    default com.seeyon.boot.transport.PageResponse<com.seeyon.ctp.affair.dto.open.AffairProcessingPersonResponseDto> selectProcessingPersonInfo(com.seeyon.boot.transport.PageRequest);
    default com.seeyon.boot.transport.ListResponse<com.seeyon.ctp.affair.dto.open.AffairProcessingPersonResponseDto> selectProcessingPersonForEachNode(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.affair.dto.open.AffairProcessingPersonRequestDto>);
    default com.seeyon.boot.transport.ListResponse<com.seeyon.ctp.affair.dto.table.AffairDto> selectFlowProcessingNodeInfo(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    default com.seeyon.boot.transport.PageResponse<com.seeyon.ctp.affair.dto.table.AffairDto> selectAffairByFixedUserCondition(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.affair.dto.base.AffairConditionSearchDto>);
    default com.seeyon.boot.transport.ListResponse<com.seeyon.ctp.affair.dto.affairenum.AffairEnumResponseDto> selectEnumItemByEnumCode(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.affair.dto.affairenum.AffairEnumSearchParamDto>);
    default com.seeyon.boot.transport.ListResponse<java.lang.Long> selectReceiveMemberIdList(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.affair.dto.base.AffairReceiverSearchDto>);
    default com.seeyon.boot.transport.ListResponse<com.seeyon.ctp.affair.dto.table.AffairSimpleDto> chooseReceiverAffair(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.affair.dto.base.AffairReceiverSearchDto>);
    default com.seeyon.boot.transport.SingleResponse<java.lang.Boolean> isBillCodeOpened();
    default com.seeyon.boot.transport.SingleResponse<java.lang.Integer> selectAffairCountForBadge(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.affair.dto.base.AffairBadgeCountQueryDto>);
    default com.seeyon.boot.transport.ListResponse<java.lang.Long> selectFormPermissionListForCase(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    default com.seeyon.boot.transport.ListResponse<com.seeyon.ctp.affair.dto.base.AffairBadgeCountResultDto> selectAffairCountBatchForBadge(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.affair.dto.base.AffairBadgeCountBatchQueryDto>);
    default com.seeyon.boot.transport.SingleResponse<com.seeyon.ctp.affair.dto.AffairBatchResponseDto> pendingAffairQuick(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.affair.dto.operation.AffairQuickDto>);
```

### `AffairOpenAppService`（12 方法）

`com.seeyon.ctp.affair.api.openApi.AffairOpenAppService`

```java
    com.seeyon.boot.transport.PageResponse<com.seeyon.ctp.affair.dto.table.AffairDto> selectPageByCondition(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.affair.dto.open.AffairOpenConditionDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.ctp.affair.dto.search.AffairSearchResultDto> selectByConditionIgnoreTenant(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.affair.dto.open.AffairOpenConditionDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.ctp.affair.dto.open.AffairUnprocessedMemberInfoDto> selectActivityUnprocessedMember(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.affair.dto.open.AffairNodeUnprocessedDto>);
    default com.seeyon.boot.transport.SingleResponse<com.seeyon.ctp.affair.dto.open.AffairUnprocessedMemberInfoDto> selectSpecifyActivityUnprocessedMember(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.affair.dto.open.AffairNodeMoreSearchDto>);
    default com.seeyon.boot.transport.SingleResponse<java.lang.Integer> createOrUpdate(com.seeyon.boot.transport.SingleRequest<java.util.List<com.seeyon.ctp.affair.dto.open.AffairOpenApiNodeDto>>);
    default com.seeyon.boot.transport.PageResponse<com.seeyon.ctp.affair.dto.open.AffairOpenApiNodeDto> selectNodePermissionPageByCondition(com.seeyon.boot.transport.PageRequest);
    default com.seeyon.boot.transport.SingleResponse<java.lang.Void> createOrUpdateCategory(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.affair.dto.category.AffairFullCategoryDto>);
    default com.seeyon.boot.transport.SingleResponse<java.util.List<com.seeyon.ctp.affair.dto.category.AffairFullCategoryDto>> selectCategoryByCondition(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.affair.dto.category.AffairFullCategoryDto>);
    default com.seeyon.boot.transport.SingleResponse<java.lang.Void> deleteCategory(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.affair.dto.category.AffairDeleteCategoryConditionDto>);
    default com.seeyon.boot.transport.SingleResponse<java.lang.Integer> createOrUpdateCategoryHierarchy(com.seeyon.boot.transport.SingleRequest<java.util.List<com.seeyon.ctp.affair.dto.category.AffairCategoryHierarchyDto>>);
    default com.seeyon.boot.transport.SingleResponse<java.lang.Void> deleteCategoryHierarchy(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.affair.dto.category.AffairCategoryHierarchyDeleteDto>);
    default com.seeyon.boot.transport.SingleResponse<java.util.List<com.seeyon.ctp.affair.dto.category.AffairCategoryHierarchyDto>> getCategoryHierarchy(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.affair.dto.category.AffairCategoryHierarchySearchDto>);
```

### `AffairNodePermissionAppService`（5 方法）

`com.seeyon.ctp.affair.api.common.AffairNodePermissionAppService`

```java
    default com.seeyon.boot.transport.SingleResponse<java.lang.Integer> deleteByIds(com.seeyon.boot.transport.SingleRequest<java.util.List<java.lang.Long>>);
    default com.seeyon.boot.transport.SingleResponse<java.lang.Integer> logicDelete(com.seeyon.boot.transport.SingleRequest<java.util.List<java.lang.Long>>);
    default com.seeyon.boot.transport.PageResponse<com.seeyon.ctp.affair.dto.AffairNodePermissionDto> selectPageByCondition(com.seeyon.boot.transport.PageRequest);
    default com.seeyon.boot.transport.SingleResponse<java.lang.Integer> createOrUpdate(com.seeyon.boot.transport.SingleRequest<java.util.List<com.seeyon.ctp.affair.dto.AffairNodePermissionDto>>);
    default com.seeyon.boot.transport.SingleResponse<java.lang.String> publish(com.seeyon.boot.transport.SingleRequest<java.lang.String>);
```

### `AffairSummaryDto`（5 方法）

`com.seeyon.ctp.affair.dto.summary.AffairSummaryDto`

```java
    java.lang.Long getId();
    java.lang.String getAppName();
    java.lang.String getSubAppName();
    java.lang.String getApplicationName();
    java.lang.String getFormRecordCode();
```

### `AffairMicroflowAppService`（4 方法）

`com.seeyon.ctp.affair.api.microflow.AffairMicroflowAppService`

```java
    default com.seeyon.boot.transport.SingleResponse<java.lang.Void> createAffairByMicroflow(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.affair.dto.microflow.AffairMicroflowInfoDto>);
    default com.seeyon.boot.transport.ListResponse<java.lang.Long> createAffairByMicroflowReturnIds(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.affair.dto.microflow.AffairMicroflowInfoDto>);
    default com.seeyon.boot.transport.SingleResponse<java.lang.Void> updateAffairReadByMicroflow(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.affair.dto.microflow.AffairMicroUpdateConditionDto>);
    default com.seeyon.boot.transport.SingleResponse<java.lang.Void> updateAffairDoneByMicroflow(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.affair.dto.microflow.AffairMicroUpdateConditionDto>);
```

### `AffairCategoryAppService`（3 方法）

`com.seeyon.ctp.affair.api.common.AffairCategoryAppService`

```java
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> syncCategories(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.affair.dto.category.AffairFullCategorySyncDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.ctp.affair.dto.category.AffairAppSimpleInfoDto> getAllAppAndSubAppInfoRegisterAffair();
    com.seeyon.boot.transport.ListResponse<com.seeyon.ctp.affair.dto.category.AffairCategoryTreeDto> searchAffairCategory(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.affair.dto.category.AffairCategorySearchDto>);
```

### `AffairSuperviseAppService`（3 方法）

`com.seeyon.ctp.affair.api.supervise.AffairSuperviseAppService`

```java
    default com.seeyon.boot.transport.PageResponse<com.seeyon.ctp.affair.dto.table.AffairDto> selectPageByFixedTemplate(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.affair.dto.supervise.AffairFixedTemplateConditionDto>, com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.transport.PageInfo>, com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.transport.Sort>);
    com.seeyon.boot.transport.PageResponse<com.seeyon.ctp.affair.dto.table.AffairDto> selectTemplateAffairPageData(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.transport.PageInfo>);
    void updateTemplateAccountId2Affairs(com.seeyon.boot.transport.SingleRequest<java.util.List<com.seeyon.ctp.affair.dto.table.AffairDto>>);
```

### `AffairCustomOperationAppService`（1 方法）

`com.seeyon.ctp.affair.api.common.AffairCustomOperationAppService`

```java
    default com.seeyon.boot.transport.SingleResponse<java.lang.Long> createAffairCustomOperation(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.affair.dto.AffairCustomOperationDto>);
```

### `AffairDataScopeAppService`（1 方法）

`com.seeyon.ctp.affair.api.common.AffairDataScopeAppService`

```java
    default com.seeyon.boot.transport.SingleResponse<com.seeyon.ctp.affair.dto.base.AffairDataScopeDto> getDataScope();
```

### `AffairUdcAppService`（1 方法）

`com.seeyon.ctp.affair.api.udc.AffairUdcAppService`

```java
    default com.seeyon.boot.transport.ListResponse<java.lang.String> selectSpecifiedFieldValues(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.affair.dto.base.AffairSearchSpecifiedFieldDto>);
```

### `AbstractAffairSearchService`（1 方法）

`com.seeyon.ctp.affair.spi.AbstractAffairSearchService`

```java
    default com.seeyon.boot.transport.Sort getSearchOrder(com.seeyon.boot.transport.Sort);
```

### `AbstractThirdAffairService`（1 方法）

`com.seeyon.ctp.affair.spi.third.AbstractThirdAffairService`

```java
    java.util.List<com.seeyon.ctp.affair.dto.AffairBatchResponseDto> batchOperateThirdAffair(com.seeyon.ctp.affair.dto.AffairBatchDto);
```

### `Affair4WorkflowAppService`（1 方法）

`com.seeyon.ctp.affair.workflow.api.Affair4WorkflowAppService`

```java
    default com.seeyon.boot.transport.SingleResponse<java.lang.Void> stopCase(com.seeyon.boot.transport.SingleRequest<com.seeyon.ctp.affair.workflow.dto.WorkflowStopDto>);
```

## 二、关键类（2）

### `AffairFixedTemplateConditionDto`（44 方法）

`com.seeyon.ctp.affair.dto.supervise.AffairFixedTemplateConditionDto`

```java
    void setOnlyTotal(java.lang.Boolean);
    void setCaseId(java.lang.Long);
    void setState(com.seeyon.ctp.affair.enums.AffairStateEnum);
    void setObjectState(java.util.List<java.lang.Integer>);
    void setTemplateGuid(java.lang.Long);
    void setTemplateGuidList(java.util.List<java.lang.Long>);
    void setUserIds(java.util.List<java.lang.Long>);
    void setTitle(java.lang.String);
    void setStartMemberId(java.lang.Long);
    void setStartMemberName(java.lang.String);
    void setStartTimeLess(java.util.Date);
    void setStartDepartmentIds(java.util.List<java.lang.Long>);
    void setStartTimeGreater(java.util.Date);
    void setDeadlineLess(java.util.Date);
    void setDeadlineGreater(java.util.Date);
    void setReceiveMemberId(java.lang.Long);
    void setTemplateAccountId(java.lang.Long);
    void setBillCode(java.lang.String);
    void setBillCodeEqualQuery(java.lang.Boolean);
    void setTemplateAccountIds(java.util.List<java.lang.Long>);
    void setStartAccountIds(java.util.List<java.lang.Long>);
    void setOrgScopeList(java.util.List<com.seeyon.ctp.affair.dto.supervise.AffairSuperviseScopeDto>);
    java.lang.Boolean getOnlyTotal();
    java.lang.Long getCaseId();
    com.seeyon.ctp.affair.enums.AffairStateEnum getState();
    java.util.List<java.lang.Integer> getObjectState();
    java.lang.Long getTemplateGuid();
    java.util.List<java.lang.Long> getTemplateGuidList();
    java.util.List<java.lang.Long> getUserIds();
    java.lang.String getTitle();
    java.lang.Long getStartMemberId();
    java.lang.String getStartMemberName();
    java.util.Date getStartTimeLess();
    java.util.List<java.lang.Long> getStartDepartmentIds();
    java.util.Date getStartTimeGreater();
    java.util.Date getDeadlineLess();
    java.util.Date getDeadlineGreater();
    java.lang.Long getReceiveMemberId();
    java.lang.Long getTemplateAccountId();
    java.lang.String getBillCode();
    java.lang.Boolean getBillCodeEqualQuery();
    java.util.List<java.lang.Long> getTemplateAccountIds();
    java.util.List<java.lang.Long> getStartAccountIds();
    java.util.List<com.seeyon.ctp.affair.dto.supervise.AffairSuperviseScopeDto> getOrgScopeList();
```

### `AffairDefaultUtil`（6 方法）

`com.seeyon.ctp.affair.utils.AffairDefaultUtil`

```java
    static java.lang.Long getLongDefault();
    static java.lang.Long getLongZeroDefault();
    static java.lang.Integer getIntegerDefault();
    static java.lang.Integer getIntegerZeroDefault();
    static java.util.Date getDateDefault();
    static java.lang.String getStringDefault();
```
