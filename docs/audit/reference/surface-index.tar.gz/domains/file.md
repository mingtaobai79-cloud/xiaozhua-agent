# 文件存储：接口与方法签名

> 自动生成，勿手改。`tools/core/platform/emit_domain_surfaces.py` 重跑即可。
> 用途：附件/文件上传下载、存储桶
> 规模：89 类 / 8 接口 / 20 个关键类 / 1045 方法。包前缀 `com.seeyon.boot.starter.file`。
> 签名逐字来自 javap 原文，已去掉 `public` 等修饰前缀与 `throws`。

## 一、接口（8）

### `StorageService`（14 方法）

`com.seeyon.boot.starter.file.storage.StorageService`

```java
    java.lang.String getStorageType();
    void init(com.seeyon.boot.starter.file.storage.StorageProperties, java.lang.String);
    void shutdown();
    default boolean delete(java.lang.String);
    default com.seeyon.boot.starter.file.dto.response.UploadResultDto upload(com.seeyon.boot.starter.file.dto.request.StorageUploadRequestDto);
    default java.io.InputStream download(java.lang.String);
    default void download(java.lang.String, javax.servlet.http.HttpServletResponse);
    default boolean exist(java.lang.String);
    default void copy(java.lang.String, java.lang.String);
    default boolean enablePartUpload();
    default com.seeyon.boot.starter.file.dto.response.PartUploadInitResultDto partUploadInit(com.seeyon.boot.starter.file.dto.request.PartUploadInitRequestDto);
    default boolean partUpload(com.seeyon.boot.starter.file.dto.response.PartUploadInfoDto, com.seeyon.boot.starter.file.dto.request.PartUploadRequestDto);
    default com.seeyon.boot.starter.file.dto.response.UploadResultDto partUploadEnd(com.seeyon.boot.starter.file.dto.response.PartUploadInfoDto);
    default boolean check(com.seeyon.boot.starter.sharding.dto.CtpOBSInfoDto);
```

### `StorageSpi`（9 方法）

`com.seeyon.boot.starter.file.spi.StorageSpi`

```java
    java.lang.String getPrivateBucketName();
    java.lang.String getPublicBucketName();
    java.lang.String getFerryboatBucketName();
    com.seeyon.boot.starter.file.dto.response.UploadResultDto upload(com.seeyon.boot.starter.file.spi.dto.SpiUploadRequestDto);
    void download(java.lang.String, java.lang.String, javax.servlet.http.HttpServletResponse);
    java.io.InputStream download(java.lang.String, java.lang.String);
    java.lang.String copy(java.lang.String, java.lang.String, java.lang.String, java.lang.String);
    boolean exist(java.lang.String, java.lang.String);
    default boolean delete(java.lang.String, java.lang.String);
```

### `StorageKeyGenerator`（4 方法）

`com.seeyon.boot.starter.file.keygener.StorageKeyGenerator`

```java
    java.lang.String getName();
    java.lang.String getStorageKey(com.seeyon.boot.starter.file.dto.StorageKeyDto);
    com.seeyon.boot.starter.file.dto.StorageKeyDto parseStorageKey(java.lang.String);
    default java.lang.String getTenantName();
```

### `V5StorageSpi`（4 方法）

`com.seeyon.boot.starter.file.spi.V5StorageSpi`

```java
    void download(java.lang.String, javax.servlet.http.HttpServletResponse);
    java.io.InputStream download(java.lang.String);
    boolean exist(java.lang.String);
    com.seeyon.boot.starter.file.dto.StorageKeyDto parseKey(java.lang.String);
```

### `ICoder`（3 方法）

`com.seeyon.boot.starter.file.encrypt.ICoder`

```java
    void initKey(java.lang.String);
    void encode(java.io.InputStream, java.io.OutputStream)
    void decode(java.io.InputStream, java.io.OutputStream)
```

### `FileInfoProxy`（1 方法）

`com.seeyon.boot.starter.file.appservice.proxy.FileInfoProxy`

```java
    com.seeyon.boot.transport.ListResponse<com.seeyon.boot.starter.file.dto.FileDto> selectByIds(com.seeyon.boot.transport.SingleRequest<java.util.List<java.lang.Long>>);
```

### `WaterMarkControl`（1 方法）

`com.seeyon.boot.starter.file.biz.WaterMarkControl`

```java
    boolean noWaterMarkDownload(java.lang.String);
```

### `FileDao`（0 方法） extends CtpFile>

`com.seeyon.boot.starter.file.domain.dao.FileDao`

```java
```

## 二、关键类（20）

### `FileService`（91 方法）

`com.seeyon.boot.starter.file.FileService`

```java
    private void init();
    java.util.Map<java.lang.String, com.seeyon.boot.starter.file.dto.response.FileConfigDto> getAllAppFileConfig();
    void updateConfig(boolean);
    private java.lang.String fileConfigRedisKey();
    java.lang.Long getFileIdByStorageKey(java.lang.String);
    com.seeyon.boot.starter.file.dto.FileDto selectById(java.lang.Long);
    java.util.List<com.seeyon.boot.starter.file.dto.FileDto> selectByIds(java.util.List<java.lang.Long>);
    com.seeyon.boot.starter.file.dto.FileDto upload(java.lang.String, com.seeyon.boot.starter.file.dto.request.UploadRequestDto);
    com.seeyon.boot.starter.file.dto.response.UploadResultDto uploadForPublicNoDB(java.io.InputStream, java.lang.String);
    private boolean publicPrefixCheck(java.lang.String);
    private boolean privatePrefixCheck(java.lang.String);
    com.seeyon.boot.starter.file.dto.response.UploadResultDto uploadForPublicNoDB(java.lang.String, java.lang.String);
    com.seeyon.boot.starter.file.dto.response.UploadResultDto uploadForPrivateNoDB(java.io.InputStream, java.lang.String);
    com.seeyon.boot.starter.file.dto.response.UploadResultDto uploadForPrivateNoDB(java.lang.String, java.lang.String);
    java.lang.String copy(com.seeyon.boot.starter.file.dto.FileDto);
    private java.lang.String cp(com.seeyon.boot.starter.file.dto.FileDto);
    java.util.Map<java.lang.String, java.lang.String> copyBatch(java.util.List<com.seeyon.boot.starter.file.dto.FileDto>);
    java.lang.String enableTempStorageKey(java.lang.String);
    com.seeyon.boot.starter.file.dto.FileDto upload(java.io.InputStream, com.seeyon.boot.starter.file.dto.request.UploadRequestDto);
    boolean saveFileSecret(com.seeyon.boot.starter.file.dto.FileSecretDto);
    boolean saveFileSecret(java.util.List<com.seeyon.boot.starter.file.dto.FileSecretDto>);
    private java.util.List<com.seeyon.boot.starter.file.dto.FileDto> fileSecretFilter(java.util.List<com.seeyon.boot.starter.file.dto.FileDto>);
    com.seeyon.boot.starter.file.dto.FileDto upload(java.net.URL, com.seeyon.boot.starter.file.dto.request.UploadRequestDto);
    com.seeyon.boot.starter.file.dto.response.PartUploadInfoDto partUploadInit(com.seeyon.boot.starter.file.dto.request.PartUploadInitRequestDto);
    com.seeyon.boot.starter.file.dto.response.PartUploadResultDto partUpload(com.seeyon.boot.starter.file.dto.request.PartUploadRequestDto);
    private com.seeyon.boot.starter.file.dto.response.PartUploadInfoDto getPartUploadInfo(java.lang.String);
    private void setPartUploadInfo(java.lang.String, com.seeyon.boot.starter.file.dto.response.PartUploadInfoDto);
    com.seeyon.boot.starter.file.dto.FileDto partUploadEnd(java.lang.String);
    java.io.InputStream download(java.lang.String);
    java.io.InputStream downloadForPrivate(java.lang.String);
    java.io.InputStream downloadForPublic(java.lang.String);
    private java.io.InputStream download(com.seeyon.boot.starter.file.storage.dto.StorageServiceDto, java.lang.String)
    void download(java.lang.String, javax.servlet.http.HttpServletResponse);
    java.lang.String getFerryboatBucketName();
    com.seeyon.boot.starter.file.dto.response.UploadResultDto uploadForFerryboat(java.io.InputStream, java.lang.String);
    boolean uploadForProduct(java.io.InputStream, java.lang.String);
    boolean existForFerryboat(java.lang.String);
    boolean enableFerryboat();
    void deleteForFerryboat(java.lang.String);
    java.io.InputStream downloadForFerryboat(java.lang.String);
    void downloadThumbnail(com.seeyon.boot.starter.file.dto.request.ThumbnailRequestDto, javax.servlet.http.HttpServletResponse);
    void avatar(com.seeyon.boot.starter.file.dto.request.ThumbnailRequestDto, javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse);
    private java.lang.String downloadUrlCacheKey(java.lang.String);
    private java.lang.String shareSignCacheKey(java.lang.String);
    private java.lang.String getDownloadSignParamStr(java.lang.String);
    boolean checkShareUrlSign(java.lang.String, java.lang.String);
    java.lang.String generateDownloadUrl(java.lang.String);
    java.lang.String generateBackendDownloadUrl(java.lang.String);
    boolean check(com.seeyon.boot.starter.sharding.dto.CtpOBSInfoDto);
    java.lang.String generateBackendDownloadUrlByExpire(java.lang.String);
    private java.lang.String getDownloadUrlToken(java.lang.String);
    java.lang.String generateShareUrl(java.lang.String);
    java.lang.String generateDownloadUrlByExpire(java.lang.String);
    java.util.Map<java.lang.String, java.lang.String> generateDownloadUrls(java.util.List<java.lang.String>);
    boolean exist(java.lang.String);
    private java.lang.String thumbnailUrlCacheKey(com.seeyon.boot.starter.file.dto.request.ThumbnailRequestDto);
    boolean isPublic(java.lang.String);
    java.lang.String generateThumbnailUrl(com.seeyon.boot.starter.file.dto.request.ThumbnailRequestDto);
    private boolean thumbnailUseOrig(com.seeyon.boot.starter.file.dto.request.ThumbnailRequestDto);
    java.lang.String generateThumbnailBase64(com.seeyon.boot.starter.file.dto.request.ThumbnailRequestDto);
    private java.lang.String thumbnailRedisKey(java.lang.String);
    private java.lang.String getThumbnailStorageKey(com.seeyon.boot.starter.file.dto.request.ThumbnailRequestDto);
    java.util.Map<java.lang.String, java.lang.String> generateThumbnailUrls(java.util.List<com.seeyon.boot.starter.file.dto.request.ThumbnailRequestDto>);
    com.seeyon.boot.starter.file.dto.FileDto selectByStorageKey(java.lang.String);
    com.seeyon.boot.starter.file.dto.FileDto selectOrigFileByStorageKey(java.lang.String);
    boolean deleteByStorageKeys(java.util.List<java.lang.String>);
    private void delete(java.lang.String, com.seeyon.boot.starter.file.storage.StorageService);
    boolean deleteByStorageKey(java.lang.String);
    private void selectOrigFileByStorageKeys(java.util.Map<java.lang.String, com.seeyon.boot.starter.file.dto.FileDto>, java.util.Map<java.lang.String, java.lang.String>, java.util.List<java.lang.Long>);
    java.util.List<com.seeyon.boot.starter.file.dto.FileDto> selectOrigFileByStorageKeys(java.util.List<java.lang.String>);
    private java.util.List<com.seeyon.boot.starter.file.dto.FileDto> selectByStorageKeys(java.util.List<java.lang.Long>, java.util.List<com.seeyon.boot.starter.file.dto.StorageKeyDto>);
    java.util.List<com.seeyon.boot.starter.file.dto.FileDto> selectByStorageKeys(java.util.List<java.lang.String>);
    private java.util.List<com.seeyon.boot.starter.file.dto.FileDto> otherAppSelect(java.lang.String, java.util.List<java.lang.Long>);
    com.seeyon.boot.starter.file.dto.response.FileConfigDto getFileConfigDto();
    java.lang.String getStorageType();
    private com.seeyon.boot.starter.file.dto.FileDto saveFileInfo(com.seeyon.boot.starter.file.dto.request.UploadRequestDto, com.seeyon.boot.starter.file.dto.response.UploadResultDto);
    private void checkFerryboat();
    com.seeyon.boot.starter.file.dto.response.UploadResultDto uploadNoDB(java.lang.String, com.seeyon.boot.starter.file.dto.request.UploadRequestDto);
    com.seeyon.boot.starter.file.dto.response.UploadResultDto uploadNoDB(java.io.InputStream, com.seeyon.boot.starter.file.dto.request.UploadRequestDto);
    com.seeyon.boot.starter.file.dto.FileDto uploadForPrivate(java.io.InputStream, java.lang.String, java.lang.String);
    com.seeyon.boot.starter.file.dto.FileDto uploadForPrivate(java.lang.String, java.lang.String, java.lang.String);
    com.seeyon.boot.starter.file.dto.FileDto uploadForPublic(java.io.InputStream, java.lang.String);
    com.seeyon.boot.starter.file.dto.FileDto uploadForPublic(java.lang.String, java.lang.String);
    java.lang.String copyNoDb(java.lang.String);
    java.util.Map<java.lang.String, java.lang.String> copyBatchNoDb(java.util.List<java.lang.String>);
```

### `NfsService`（32 方法）

`com.seeyon.boot.starter.file.storage.nfs.service.NfsService`

```java
    void init(com.seeyon.boot.starter.file.storage.StorageProperties, java.lang.String);
    void shutdown();
    java.lang.String getStorageType();
    private void checkStorageKey(java.lang.String);
    private java.lang.String getFerryboatPath();
    private java.lang.String getRealPath(java.lang.String);
    private java.lang.String getRootPath();
    private java.io.File getFile(java.lang.String);
    private java.io.File getFerryboatFile(java.lang.String);
    private java.io.File getMetaFile(java.lang.String);
    com.seeyon.boot.starter.file.dto.response.UploadResultDto upload(com.seeyon.boot.starter.file.dto.request.StorageUploadRequestDto);
    private com.seeyon.boot.starter.file.dto.response.UploadResultDto uploadForFerryboat(java.io.InputStream, java.lang.String);
    private java.lang.String getFileCrc32(java.io.File);
    private boolean existForFerryboat(java.lang.String);
    private java.io.InputStream downloadForFerryboat(java.lang.String);
    private com.seeyon.boot.starter.file.dto.response.UploadResultDto upload(java.io.InputStream, java.lang.String, java.lang.String, java.lang.String);
    private void upload(java.io.InputStream, java.lang.String, java.io.File, java.lang.String, java.lang.String)
    private java.lang.String metadataJson(java.lang.String, java.lang.String);
    private boolean isPublic(java.lang.String);
    java.io.InputStream download(java.lang.String);
    void download(java.lang.String, javax.servlet.http.HttpServletResponse);
    boolean exist(java.lang.String);
    void copy(java.lang.String, java.lang.String);
    private java.lang.String getFileName(java.lang.String);
    private void copy(java.lang.String, java.lang.String, java.lang.String, java.lang.String);
    boolean enablePartUpload();
    private java.io.File getPartUploadDir(java.lang.String);
    com.seeyon.boot.starter.file.dto.response.PartUploadInitResultDto partUploadInit(com.seeyon.boot.starter.file.dto.request.PartUploadInitRequestDto);
    boolean delete(java.lang.String);
    boolean partUpload(com.seeyon.boot.starter.file.dto.response.PartUploadInfoDto, com.seeyon.boot.starter.file.dto.request.PartUploadRequestDto);
    void clearPartUploadTempDir();
    com.seeyon.boot.starter.file.dto.response.UploadResultDto partUploadEnd(com.seeyon.boot.starter.file.dto.response.PartUploadInfoDto);
```

### `FileDownloadService`（23 方法）

`com.seeyon.boot.starter.file.domain.service.FileDownloadService`

```java
    boolean systemWaterMarkEnable(java.lang.String);
    private boolean supportWaterMark(java.lang.String);
    private java.lang.Object invoke(java.lang.String, java.lang.String, java.lang.String, java.lang.Object, java.lang.String);
    com.seeyon.boot.starter.file.dto.response.BatchZipStatusDto getZipFileStatus(java.lang.String);
    java.lang.String asyncFileBatchZip(java.util.List<java.lang.String>, java.lang.String, java.lang.String);
    private java.lang.String getSupportWaterMarkFileType();
    com.seeyon.boot.starter.file.dto.response.FileWaterMarkResultDto getWaterMarkStorageKey(java.lang.String, java.lang.String, java.lang.String)
    com.seeyon.boot.starter.file.dto.response.FileWaterMarkResultDto getWaterMarkStorageKey(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse, java.lang.String, java.lang.String)
    private void sleep(int);
    private java.util.Map<java.lang.String, java.lang.Object> taskStatus(java.lang.String);
    private java.util.Map<java.lang.String, java.lang.Object> getMemberInfo();
    private void buildMember(java.util.Map<java.lang.String, java.lang.Object>);
    private java.lang.String getMemberName(java.util.Map<java.lang.String, java.lang.Object>);
    private java.lang.String getMemberTel(java.util.Map<java.lang.String, java.lang.Object>);
    private java.lang.String getMemberNum(java.util.Map<java.lang.String, java.lang.Object>);
    private java.lang.String getOrgSimpleName(java.util.Map<java.lang.String, java.lang.Object>);
    private java.lang.String getDeptSimpleName(java.util.Map<java.lang.String, java.lang.Object>);
    private java.lang.String getDateTime();
    private java.util.Map<java.lang.String, com.seeyon.boot.starter.file.biz.WaterMarkControl> getWaterMarkBeanMap();
    boolean noWaterMarkDownload(java.lang.String);
```

### `StorageSelectService`（21 方法）

`com.seeyon.boot.starter.file.storage.StorageSelectService`

```java
    com.seeyon.boot.starter.file.storage.dto.StorageServiceDto getSystemPublicStorageService();
    com.seeyon.boot.starter.file.storage.dto.StorageServiceDto getSystemPrivateStorageService();
    com.seeyon.boot.starter.file.storage.dto.StorageServiceDto getFerryboatStorageService();
    com.seeyon.boot.starter.file.storage.dto.StorageServiceDto getSystemProductStorageService();
    private com.seeyon.boot.starter.file.storage.dto.StorageServiceDto getSystemRuntimeStorageService();
    com.seeyon.boot.starter.file.storage.dto.StorageServiceDto getTenantStorageService(com.seeyon.boot.starter.sharding.dto.CtpOBSInfoDto);
    com.seeyon.boot.starter.file.storage.dto.StorageServiceDto getStorageService(boolean, boolean);
    private com.seeyon.boot.starter.file.storage.dto.StorageServiceDto getV5FileService();
    com.seeyon.boot.starter.file.storage.dto.StorageServiceDto getStorageServiceByStorageKey(java.lang.String);
    com.seeyon.boot.starter.file.storage.dto.StorageServiceDto getStorageServiceByStorageKey(com.seeyon.boot.starter.file.dto.StorageKeyDto);
    private boolean isSystemBucketName(java.lang.String);
    private com.seeyon.boot.starter.file.storage.dto.StorageServiceDto findSystemRuntimeStorageServiceByBucket(java.lang.String);
    private com.seeyon.boot.starter.file.storage.dto.StorageServiceDto findSystemPrivateStorageServiceByBucket(java.lang.String);
    private com.seeyon.boot.starter.file.storage.dto.StorageServiceDto findSystemPublicStorageServiceByBucket(java.lang.String);
    private java.util.Map<java.lang.String, java.lang.String> bucketMappingMap(java.lang.String);
    private java.util.Map<java.lang.String, com.seeyon.boot.starter.file.storage.StorageProperties> getStorageProperties();
    private boolean clientConfigChange(java.lang.String, java.lang.String, java.lang.String, java.lang.String);
    void putStorageCache(java.lang.String, java.lang.String, java.lang.String, java.lang.String, com.seeyon.boot.starter.file.storage.dto.StorageServiceDto);
    private com.seeyon.boot.starter.file.storage.StorageService newStorageService(java.lang.String);
    private com.seeyon.boot.starter.file.storage.StorageProperties newStorageProperties(java.lang.String);
```

### `OssService`（21 方法）

`com.seeyon.boot.starter.file.storage.oss.service.OssService`

```java
    private com.aliyun.oss.OSS client();
    private com.aliyun.oss.OSS client(com.seeyon.boot.starter.sharding.dto.CtpOBSInfoDto);
    void init(com.seeyon.boot.starter.file.storage.StorageProperties, java.lang.String);
    void shutdown();
    java.lang.String getStorageType();
    com.seeyon.boot.starter.file.dto.response.UploadResultDto upload(com.seeyon.boot.starter.file.dto.request.StorageUploadRequestDto);
    boolean delete(java.lang.String);
    private com.seeyon.boot.starter.file.dto.response.UploadResultDto upload(com.aliyun.oss.OSS, java.io.InputStream, java.lang.String, java.lang.String, java.lang.String, java.lang.String);
    java.io.InputStream download(java.lang.String);
    void download(java.lang.String, javax.servlet.http.HttpServletResponse);
    private int getErrorStatus(java.lang.String);
    private int throwOssException(com.aliyun.oss.OSSException);
    boolean exist(java.lang.String);
    private boolean exist(com.aliyun.oss.OSS, java.lang.String, java.lang.String);
    void copy(java.lang.String, java.lang.String);
    private void copy(java.lang.String, java.lang.String, java.lang.String, java.lang.String);
    boolean enablePartUpload();
    com.seeyon.boot.starter.file.dto.response.PartUploadInitResultDto partUploadInit(com.seeyon.boot.starter.file.dto.request.PartUploadInitRequestDto);
    boolean partUpload(com.seeyon.boot.starter.file.dto.response.PartUploadInfoDto, com.seeyon.boot.starter.file.dto.request.PartUploadRequestDto);
    com.seeyon.boot.starter.file.dto.response.UploadResultDto partUploadEnd(com.seeyon.boot.starter.file.dto.response.PartUploadInfoDto);
    boolean check(com.seeyon.boot.starter.sharding.dto.CtpOBSInfoDto);
```

### `MinIoService`（19 方法）

`com.seeyon.boot.starter.file.storage.minio.service.MinIoService`

```java
    java.lang.String getStorageType();
    private com.seeyon.boot.starter.file.storage.minio.client.SeeyonMinioClient client(java.lang.String, java.lang.String, java.lang.String);
    private com.seeyon.boot.starter.file.storage.minio.client.SeeyonMinioClient client();
    void init(com.seeyon.boot.starter.file.storage.StorageProperties, java.lang.String);
    void shutdown();
    com.seeyon.boot.starter.file.dto.response.UploadResultDto upload(com.seeyon.boot.starter.file.dto.request.StorageUploadRequestDto);
    boolean delete(java.lang.String);
    private com.seeyon.boot.starter.file.dto.response.UploadResultDto upload(io.minio.MinioAsyncClient, java.io.InputStream, java.lang.String, java.lang.String, java.lang.String, java.lang.String);
    java.io.InputStream download(java.lang.String);
    private java.util.Map<java.lang.String, java.lang.Object> getHeaders(okhttp3.Headers);
    void download(java.lang.String, javax.servlet.http.HttpServletResponse);
    boolean exist(java.lang.String);
    void copy(java.lang.String, java.lang.String);
    private void copy(java.lang.String, java.lang.String, java.lang.String, java.lang.String);
    boolean enablePartUpload();
    com.seeyon.boot.starter.file.dto.response.PartUploadInitResultDto partUploadInit(com.seeyon.boot.starter.file.dto.request.PartUploadInitRequestDto);
    boolean partUpload(com.seeyon.boot.starter.file.dto.response.PartUploadInfoDto, com.seeyon.boot.starter.file.dto.request.PartUploadRequestDto);
    com.seeyon.boot.starter.file.dto.response.UploadResultDto partUploadEnd(com.seeyon.boot.starter.file.dto.response.PartUploadInfoDto);
    boolean check(com.seeyon.boot.starter.sharding.dto.CtpOBSInfoDto);
```

### `ObsService`（19 方法）

`com.seeyon.boot.starter.file.storage.obs.service.ObsService`

```java
    private com.obs.services.ObsClient client();
    java.lang.String getStorageType();
    void init(com.seeyon.boot.starter.file.storage.StorageProperties, java.lang.String);
    void shutdown();
    com.seeyon.boot.starter.file.dto.response.UploadResultDto upload(com.seeyon.boot.starter.file.dto.request.StorageUploadRequestDto);
    boolean delete(java.lang.String);
    private com.seeyon.boot.starter.file.dto.response.UploadResultDto upload(com.obs.services.ObsClient, java.io.InputStream, java.lang.String, java.lang.String, java.lang.String, java.lang.String);
    java.io.InputStream download(java.lang.String);
    void download(java.lang.String, javax.servlet.http.HttpServletResponse);
    boolean exist(java.lang.String);
    private boolean exist(com.obs.services.ObsClient, java.lang.String, java.lang.String);
    void copy(java.lang.String, java.lang.String);
    private void copy(java.lang.String, java.lang.String, java.lang.String, java.lang.String);
    boolean enablePartUpload();
    com.seeyon.boot.starter.file.dto.response.PartUploadInitResultDto partUploadInit(com.seeyon.boot.starter.file.dto.request.PartUploadInitRequestDto);
    boolean partUpload(com.seeyon.boot.starter.file.dto.response.PartUploadInfoDto, com.seeyon.boot.starter.file.dto.request.PartUploadRequestDto);
    com.seeyon.boot.starter.file.dto.response.UploadResultDto partUploadEnd(com.seeyon.boot.starter.file.dto.response.PartUploadInfoDto);
    private com.obs.services.ObsClient client(com.seeyon.boot.starter.sharding.dto.CtpOBSInfoDto);
    boolean check(com.seeyon.boot.starter.sharding.dto.CtpOBSInfoDto);
```

### `FileAppService`（14 方法）

`com.seeyon.boot.starter.file.appservice.FileAppService`

```java
    com.seeyon.boot.transport.SingleResponse<java.lang.String> getDownloadUrl(com.seeyon.boot.transport.SingleRequest<java.lang.String>);
    com.seeyon.boot.transport.SingleResponse<java.lang.String> getBackendDownloadUrl(com.seeyon.boot.transport.SingleRequest<java.lang.String>);
    com.seeyon.boot.transport.SingleResponse<java.util.Map<java.lang.String, java.lang.String>> getDownloadUrls(com.seeyon.boot.transport.SingleRequest<java.util.List<java.lang.String>>);
    com.seeyon.boot.transport.SingleResponse<java.lang.String> getThumbnailUrl(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.file.dto.request.ThumbnailRequestDto>);
    com.seeyon.boot.transport.SingleResponse<java.util.Map<java.lang.String, java.lang.String>> getThumbnailUrls(com.seeyon.boot.transport.SingleRequest<java.util.List<com.seeyon.boot.starter.file.dto.request.ThumbnailRequestDto>>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.boot.starter.file.dto.FileDto> selectByStorageKey(com.seeyon.boot.transport.SingleRequest<java.lang.String>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.boot.starter.file.dto.FileDto> selectByStorageKeys(com.seeyon.boot.transport.SingleRequest<java.util.List<java.lang.String>>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.boot.starter.file.dto.FileDto> saveFileInfo(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.file.dto.FileDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> saveFileInfos(com.seeyon.boot.transport.SingleRequest<java.util.List<com.seeyon.boot.starter.file.dto.FileDto>>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.boot.starter.file.dto.response.FileConfigDto> getFileConfig();
    com.seeyon.boot.transport.SingleResponse<java.util.Map<java.lang.String, com.seeyon.boot.starter.file.dto.response.FileConfigDto>> getAllAppFileConfig();
    com.seeyon.boot.transport.SingleResponse<java.lang.String> copy(com.seeyon.boot.transport.SingleRequest<java.lang.String>);
    com.seeyon.boot.transport.SingleResponse<java.lang.String> generateShareUrl(com.seeyon.boot.transport.SingleRequest<java.lang.String>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.boot.starter.file.dto.FileDto> modifyFileName(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.file.dto.request.ModifyFileNameDto>);
```

### `ZipFileService`（14 方法）

`com.seeyon.boot.starter.file.domain.service.ZipFileService`

```java
    private java.lang.String zipFileStatusRedisKey(java.lang.String);
    com.seeyon.boot.starter.file.dto.response.BatchZipStatusDto getZipFileStatus(java.lang.String);
    java.lang.String asyncFileBatchZip(java.util.List<java.lang.String>, java.lang.String, java.lang.String);
    java.lang.String asyncFileBatchZip(javax.servlet.http.HttpServletRequest, java.util.List<java.lang.String>, java.util.List<java.lang.String>, java.lang.String, java.lang.String);
    java.lang.String asyncFileBatchZip(javax.servlet.http.HttpServletRequest, java.util.List<java.lang.String>, java.lang.String, java.lang.String);
    java.lang.String asyncZipSpecifyDir(java.util.List<com.seeyon.boot.starter.file.dto.request.ZipFileDto>, java.lang.String, java.lang.String);
    java.lang.String asyncZipSpecifyDir(javax.servlet.http.HttpServletRequest, java.util.List<com.seeyon.boot.starter.file.dto.request.ZipFileDto>, java.lang.String, java.lang.String);
    java.io.File syncFileBatchZip(java.util.List<com.seeyon.boot.starter.file.dto.request.ZipFileDto>)
    java.io.File syncFileBatchZip(java.util.List<com.seeyon.boot.starter.file.dto.request.ZipFileDto>, java.lang.String)
    java.io.File syncFileBatchZip(java.lang.String, java.util.List<com.seeyon.boot.starter.file.dto.request.ZipFileDto>, java.lang.String)
    java.io.File syncFileBatchZip(javax.servlet.http.HttpServletRequest, java.util.List<com.seeyon.boot.starter.file.dto.request.ZipFileDto>, java.lang.String)
```

### `FileInfoService`（13 方法）

`com.seeyon.boot.starter.file.domain.service.FileInfoService`

```java
    com.seeyon.boot.starter.file.dto.FileDto modifyFileName(com.seeyon.boot.starter.file.dto.request.ModifyFileNameDto);
    com.seeyon.boot.starter.file.dto.FileDto enableTempStorageKey(java.lang.Long);
    java.util.List<com.seeyon.boot.starter.file.dto.FileDto> enableTempStorageKey(java.util.List<java.lang.Long>);
    java.util.List<java.lang.String> selectClearFileInfoList();
    com.seeyon.boot.starter.file.dto.FileDto save(com.seeyon.boot.starter.file.dto.FileDto);
    int saveBatch(java.util.List<com.seeyon.boot.starter.file.dto.FileDto>);
    com.seeyon.boot.starter.file.dto.FileDto selectById(java.lang.Long);
    java.util.List<com.seeyon.boot.starter.file.dto.FileDto> selectByBusinessKey(java.lang.String);
    java.util.List<com.seeyon.boot.starter.file.dto.FileDto> selectBySubBusinessKey(java.lang.String);
    void delete(java.lang.Long);
    void delete(java.util.List<java.lang.Long>);
    java.util.List<com.seeyon.boot.starter.file.dto.FileDto> selectByIds(java.util.List<java.lang.Long>);
    private java.util.List<java.util.List<java.lang.Long>> splitList(java.util.List<java.lang.Long>, int);
```

### `DownloadUtils`（13 方法）

`com.seeyon.boot.starter.file.storage.util.DownloadUtils`

```java
    static java.io.File zip(java.util.Collection<java.io.File>);
    static java.io.File zip(java.util.Map<java.io.File, java.lang.String>);
    static java.lang.String getDownloadContentDispositionStr(java.lang.String)
    static private static java.lang.String fileDownloadEtag(java.lang.String);
    static private static boolean needWriteEtag(java.lang.String);
    static private static java.lang.String getContentType(java.util.Map<java.lang.String, java.lang.Object>);
    static void writeETag(javax.servlet.http.HttpServletResponse, java.util.Map<java.lang.String, java.lang.Object>, java.lang.String);
    static void writeETag(javax.servlet.http.HttpServletResponse, java.lang.String, java.lang.String);
    static boolean checkEtag(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse, java.lang.String);
    static void success(java.io.InputStream, java.util.Map<java.lang.String, java.lang.Object>, javax.servlet.http.HttpServletResponse);
    static void fail(javax.servlet.http.HttpServletResponse, int, java.lang.String);
    static void fail(javax.servlet.http.HttpServletResponse, java.lang.String);
    static void setHeaders(java.util.Map<java.lang.String, java.lang.Object>, javax.servlet.http.HttpServletResponse);
```

### `StorageUtils`（11 方法）

`com.seeyon.boot.starter.file.storage.util.StorageUtils`

```java
    static com.seeyon.boot.starter.file.spi.V5StorageSpi getV5Spi();
    static com.seeyon.boot.starter.file.spi.StorageSpi getSpi();
    static void checkFileMetadata(java.io.InputStream, java.lang.String);
    static void checkFileName(java.lang.String);
    static boolean isV5File(java.lang.String);
    static boolean isPublicBucket(java.lang.String);
    static private static com.seeyon.boot.starter.file.FileProperties getFileProperties();
    static boolean migrated(java.lang.String);
    static com.seeyon.boot.starter.file.storage.StorageProperties getStorageProperties();
    static void initSpi();
    static private static void init();
```

### `StorageServiceDto`（10 方法）

`com.seeyon.boot.starter.file.storage.dto.StorageServiceDto`

```java
    boolean isSystemStorage();
    com.seeyon.boot.starter.file.storage.StorageService getStorageService();
    java.lang.String getBucketName();
    void setSystemStorage(boolean);
    void setStorageService(com.seeyon.boot.starter.file.storage.StorageService);
    void setBucketName(java.lang.String);
    boolean equals(java.lang.Object);
    protected boolean canEqual(java.lang.Object);
    int hashCode();
    java.lang.String toString();
```

### `SFOssService`（10 方法）

`com.seeyon.boot.starter.file.storage.sfoss.service.SFOssService`

```java
    java.lang.String getStorageType();
    private swiftsdk.SfOssClient client();
    void init(com.seeyon.boot.starter.file.storage.StorageProperties, java.lang.String);
    void shutdown();
    com.seeyon.boot.starter.file.dto.response.UploadResultDto upload(com.seeyon.boot.starter.file.dto.request.StorageUploadRequestDto);
    private com.seeyon.boot.starter.file.dto.response.UploadResultDto upload(java.io.InputStream, java.lang.String, java.lang.String, java.lang.String, java.lang.String);
    java.io.InputStream download(java.lang.String);
    void download(java.lang.String, javax.servlet.http.HttpServletResponse);
    boolean exist(java.lang.String);
    void copy(java.lang.String, java.lang.String);
```

### `CoderFactory`（9 方法）

`com.seeyon.boot.starter.file.encrypt.CoderFactory`

```java
    static com.seeyon.boot.starter.file.encrypt.CoderFactory getInstance();
    private java.lang.String getEncryptVersion();
    private com.seeyon.boot.starter.file.encrypt.ICoder getICoder(java.lang.String);
    private void encrypt(java.io.InputStream, java.io.OutputStream, java.lang.String)
    static private static void setDownloadHeaders(java.util.Map<java.lang.String, java.lang.Object>, javax.servlet.http.HttpServletResponse);
    void download(java.io.InputStream, java.util.Map<java.lang.String, java.lang.Object>, javax.servlet.http.HttpServletResponse);
    private void directOutput(java.io.InputStream, java.io.OutputStream)
    java.io.File decryptFileToTemp(java.io.File)
    void encryptFile(java.io.InputStream, java.io.File)
```

### `StorageSpiService`（9 方法）

`com.seeyon.boot.starter.file.storage.spi.StorageSpiService`

```java
    void init(com.seeyon.boot.starter.file.storage.StorageProperties, java.lang.String);
    void shutdown();
    java.lang.String getStorageType();
    com.seeyon.boot.starter.file.dto.response.UploadResultDto upload(com.seeyon.boot.starter.file.dto.request.StorageUploadRequestDto);
    java.io.InputStream download(java.lang.String);
    void download(java.lang.String, javax.servlet.http.HttpServletResponse);
    boolean exist(java.lang.String);
    void copy(java.lang.String, java.lang.String);
    boolean delete(java.lang.String);
```

### `V5StorageSpiService`（9 方法）

`com.seeyon.boot.starter.file.storage.v5.V5StorageSpiService`

```java
    void init(com.seeyon.boot.starter.file.storage.StorageProperties, java.lang.String);
    void shutdown();
    java.lang.String getStorageType();
    com.seeyon.boot.starter.file.dto.response.UploadResultDto upload(com.seeyon.boot.starter.file.dto.request.StorageUploadRequestDto);
    java.io.InputStream download(java.lang.String);
    void download(java.lang.String, javax.servlet.http.HttpServletResponse);
    boolean exist(java.lang.String);
    void copy(java.lang.String, java.lang.String);
    boolean delete(java.lang.String);
```

### `StorageKeyService`（7 方法）

`com.seeyon.boot.starter.file.storage.StorageKeyService`

```java
    private com.seeyon.boot.starter.file.keygener.StorageKeyGenerator getKeyGenerator();
    com.seeyon.boot.starter.file.dto.StorageKeyDto parseStorageKey(java.lang.String);
    private com.seeyon.boot.starter.file.dto.StorageKeyDto parseV5StorageKey(java.lang.String);
    com.seeyon.boot.starter.file.keygener.StorageKeyGenerator getStorageKeyGenerator();
    java.lang.String generateStorageKey(com.seeyon.boot.starter.file.dto.StorageKeyDto);
    java.lang.Long getFileIdByStorageKey(java.lang.String);
    java.util.List<java.lang.Long> getFileIdByStorageKeys(java.util.List<java.lang.String>);
```

### `EncryptConfigService`（5 方法）

`com.seeyon.boot.starter.file.config.EncryptConfigService`

```java
    private void init();
    void publish(com.seeyon.boot.conifg.EncryptConfigProperties);
    com.seeyon.boot.conifg.EncryptConfigProperties getConfig();
    private void notice();
    private java.lang.String redisKey();
```

### `QrcodeUploadService`（5 方法）

`com.seeyon.boot.starter.file.qrcode.service.QrcodeUploadService`

```java
    java.lang.String createQrCodeBase64(com.seeyon.boot.starter.file.qrcode.dto.QrCodeUploadRequestDto);
    java.lang.String token();
    private java.lang.String tokenRedisKey();
    java.lang.String getTokenValue(java.lang.String);
    java.lang.Boolean sendMessageByWebsocket(com.seeyon.boot.starter.file.dto.request.PushWebSocketDto);
```
