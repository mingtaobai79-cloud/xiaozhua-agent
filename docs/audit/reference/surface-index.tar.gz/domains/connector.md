# 连接器：接口与方法签名

> 自动生成，勿手改。`tools/core/platform/emit_domain_surfaces.py` 重跑即可。
> 用途：连接器应用、配置、认证、数据库执行器、移动端 Provider
> 规模：155 类 / 28 接口 / 4 个关键类 / 1971 方法。包前缀 `com.seeyon.cip.connector`。
> 签名逐字来自 javap 原文，已去掉 `public` 等修饰前缀与 `throws`。

## 一、接口（28）

### `DataBaseExecutorService`（14 方法）

`com.seeyon.cip.connector.api.db.DataBaseExecutorService`

```java
    com.seeyon.cip.connector.enums.DbTypeEnum getDbTypeEnum();
    java.lang.String getName();
    com.seeyon.cip.connector.dto.db.ExecutorResultApiDto executeDetail(com.seeyon.cip.connector.dto.db.DatabaseInfoApiDto, com.seeyon.cip.connector.dto.db.LinkerDetailApiDto, java.util.Map<java.lang.String, java.lang.Object>);
    java.lang.Integer executeDetailForCount(com.seeyon.cip.connector.dto.db.DatabaseInfoApiDto, com.seeyon.cip.connector.dto.db.LinkerDetailApiDto, java.util.Map<java.lang.String, java.lang.Object>);
    java.lang.String transformByType(java.lang.Object, java.lang.String);
    java.util.List<java.lang.String> getAllTableName(com.seeyon.cip.connector.dto.db.DatabaseInfoApiDto);
    com.seeyon.boot.transport.PageData<java.lang.String> getPageTableName(com.seeyon.cip.connector.dto.db.DatabaseInfoApiDto, com.seeyon.cip.connector.dto.db.AppSearchApiDto);
    java.lang.String getDriver();
    java.util.List<com.seeyon.cip.connector.dto.db.TableInfoApiDto> getAllTableInfo(com.seeyon.cip.connector.dto.db.DatabaseInfoApiDto, java.lang.String);
    java.lang.String generateSql(com.seeyon.cip.connector.dto.db.LinkerDetailApiDto);
    java.lang.String generateSql(com.seeyon.cip.connector.dto.db.LinkerDetailApiDto, java.lang.Boolean);
    java.sql.Connection getConnection(com.seeyon.cip.connector.dto.db.DatabaseInfoApiDto);
    java.lang.String getVersion();
    default com.seeyon.cip.connector.dto.db.SqlResultApiDto executeSql(com.seeyon.cip.connector.dto.db.ExecuteSqlApiDto, com.seeyon.cip.connector.dto.db.DatabaseInfoApiDto);
```

### `MobileConfigProviderService`（14 方法） extends MobileProviderService

`com.seeyon.cip.connector.api.mobile.MobileConfigProviderService`

```java
    void jsonCheck(java.lang.String);
    java.lang.String getName();
    java.lang.String getTypeCaption();
    java.lang.Integer getSortNo();
    java.lang.String getPageJson();
    java.lang.String getAppId(java.lang.String);
    java.lang.String getAppSecret(java.lang.String);
    java.lang.String getAppName(java.lang.String);
    java.lang.String getAdminUrl();
    default java.lang.String getThirdApplicationDomain(com.seeyon.cip.connector.dto.mobile.MobilePlatformConfigDto);
    default java.util.Map<java.lang.String, java.lang.Object> getThirdConfigCondition(java.lang.String, java.lang.String, java.lang.String, java.lang.String);
    default java.lang.String getMobileCorpId(java.lang.String, java.lang.String, java.lang.String);
    boolean isPrivateApp();
    default java.lang.Boolean isOnlyBaseInfo();
```

### `LinkerAppService`（12 方法）

`com.seeyon.cip.connector.api.core.LinkerAppService`

```java
    com.seeyon.boot.transport.PageResponse<com.seeyon.cip.connector.dto.info.LinkerInfoDto> selectPageByCondition(com.seeyon.boot.transport.PageRequest);
    com.seeyon.boot.transport.ListResponse<com.seeyon.cip.connector.dto.info.LinkerInfoDto> selectAll();
    com.seeyon.boot.transport.ListResponse<com.seeyon.cip.connector.dto.info.LinkerDetailDto> selectDetailsByInfoId(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.cip.connector.dto.info.LinkerParameterDisplayDto> selectLinkerDetailParameterDisplay(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.cip.connector.dto.info.LinkerEventDetailDto> selectEventDetailsByInfoId(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.connector.dto.info.LinkerEventDetailDto> selectEventDetailById(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.PageResponse<com.seeyon.cip.connector.dto.info.LinkerDetailDto> selectPageDetailByCondition(com.seeyon.boot.transport.PageRequest);
    com.seeyon.boot.transport.PageResponse<com.seeyon.cip.connector.dto.info.LinkerEventDetailDto> selectPageEventDetailByCondition(com.seeyon.boot.transport.PageRequest);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.connector.dto.info.LinkerDetailDto> selectDetailById(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.connector.dto.execute.ExecuteResponseDto> execute(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.connector.dto.execute.ExecuteRequestDto>);
    default com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.connector.dto.execute.MqCustomSendResultDto> mqCustomSend(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.connector.dto.execute.MqCustomSendDto>);
    default com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.connector.dto.execute.SqlResultDto> executeSql(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.connector.dto.execute.ExecuteSqlDto>);
```

### `BaseConfigAppService`（11 方法）

`com.seeyon.cip.connector.api.core.BaseConfigAppService`

```java
    com.seeyon.boot.transport.SingleResponse<java.lang.Long> createDatabase(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.connector.dto.database.DatabaseInfoDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> updateDatabase(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.connector.dto.database.DatabaseInfoDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> deleteDatabaseById(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.cip.connector.dto.database.DatabaseInfoDto> selectDatabaseById(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.cip.connector.dto.database.DatabaseInfoDto> selectDatabaseByIds(com.seeyon.boot.transport.SingleRequest<java.util.List<java.lang.Long>>);
    com.seeyon.boot.transport.PageResponse<com.seeyon.cip.connector.dto.database.DatabaseInfoDto> selectPageDatabaseByCondition(com.seeyon.boot.transport.PageRequest);
    com.seeyon.boot.transport.SingleResponse<java.lang.String> connectorDatabase(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.connector.dto.database.DatabaseInfoDto>);
    com.seeyon.boot.transport.ListResponse<java.lang.String> selectAllDatabaseType();
    com.seeyon.boot.transport.SingleResponse<java.util.Map<java.lang.String, java.util.List<com.seeyon.cip.connector.dto.database.TableInfoDto>>> selectAllTableInfo(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.ListResponse<java.lang.String> selectAllTableNameById(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.cip.connector.dto.database.TableInfoDto> selectTableInfo(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.connector.dto.database.TableInfoDto>);
```

### `MobileApplicationProviderService`（10 方法） extends MobileProviderService

`com.seeyon.cip.connector.api.mobile.MobileApplicationProviderService`

```java
    com.seeyon.cip.connector.dto.mobile.MobileUrlDto getMobileUrlDto(com.seeyon.cip.connector.dto.mobile.MobileUrlProviderDto);
    java.lang.String explainLinkInfo();
    java.lang.Long publishApp(com.seeyon.cip.connector.dto.mobile.MobilePublishAppRequestDto, com.seeyon.cip.connector.dto.mobile.MobilePlatformConfigDto);
    com.seeyon.cip.connector.dto.mobile.MobilePlatformSignatureResultDto getSignature(com.seeyon.cip.connector.dto.mobile.MobilePlatformConfigDto, com.seeyon.cip.connector.dto.mobile.MobilePlatformSignatureDto);
    void sendMessage(boolean, com.seeyon.cip.connector.dto.mobile.MobileMessageRequestDto, com.seeyon.cip.connector.dto.mobile.MobilePlatformRequestDto);
    com.seeyon.cip.connector.dto.mobile.sso.MobileSsoUserDto getMobileSsoUserDto(com.seeyon.cip.connector.dto.mobile.MobilePlatformConfigDto, com.seeyon.cip.connector.dto.mobile.sso.MobileSsoUserRequestDto);
    default com.seeyon.cip.connector.dto.mobile.MobileInterfaceStatusDto interfaceStatus(com.seeyon.cip.connector.dto.mobile.MobilePlatformConfigDto);
    java.lang.String getOpenId(com.seeyon.cip.connector.dto.mobile.MobilePlatformConfigDto, com.seeyon.cip.connector.dto.mobile.MobileOpenIdDto);
    default java.lang.String getLaunchCode(com.seeyon.cip.connector.dto.mobile.MobilePlatformConfigDto, com.seeyon.cip.connector.dto.mobile.MobileLaunchCodeDto);
    default com.seeyon.cip.connector.dto.mobile.RecallResultDto recallMessage(com.seeyon.cip.connector.dto.mobile.MobilePlatformConfigDto, com.seeyon.cip.connector.dto.mobile.RecallMessageDto);
```

### `LinkerSecurityService`（9 方法）

`com.seeyon.cip.connector.api.authentication.LinkerSecurityService`

```java
    java.lang.String getName();
    java.lang.String getTypeCaption();
    com.seeyon.cip.connector.enums.AuthInfoModeEnum getMode();
    java.util.Map<java.lang.String, java.lang.Object> doAuthentication(com.seeyon.cip.connector.dto.authentication.AuthenticationDto)
    com.seeyon.cip.connector.dto.authentication.AuthEventDto doDecode(java.lang.String, com.seeyon.cip.connector.dto.authentication.AuthEventDto)
    java.lang.String getPageJson();
    java.lang.Integer getSortNo();
    void jsonCheck(java.lang.String);
    default java.lang.Boolean doVerification(com.seeyon.cip.connector.dto.authentication.AuthenticationDto);
```

### `MobileOrgSyncProviderService`（9 方法） extends MobileProviderService

`com.seeyon.cip.connector.api.mobile.MobileOrgSyncProviderService`

```java
    java.lang.Long syncUnit(com.seeyon.cip.connector.dto.mobile.MobileUnitRequestDto, com.seeyon.cip.connector.dto.mobile.MobilePlatformConfigDto);
    void updateUnit(com.seeyon.cip.connector.dto.mobile.MobileUnitRequestDto, com.seeyon.cip.connector.dto.mobile.MobilePlatformConfigDto);
    java.lang.String getUnit(com.seeyon.cip.connector.dto.mobile.MobileUnitRequestDto, com.seeyon.cip.connector.dto.mobile.MobilePlatformConfigDto);
    void removeUnit(com.seeyon.cip.connector.dto.mobile.MobileUnitRequestDto, com.seeyon.cip.connector.dto.mobile.MobilePlatformConfigDto);
    java.lang.String syncUser(com.seeyon.cip.connector.dto.mobile.MobileUserRequestDto, com.seeyon.cip.connector.dto.mobile.MobilePlatformConfigDto);
    java.lang.String updateUser(com.seeyon.cip.connector.dto.mobile.MobileUserRequestDto, com.seeyon.cip.connector.dto.mobile.MobilePlatformConfigDto);
    com.seeyon.cip.connector.dto.mobile.MobileUserResponseDto getUser(com.seeyon.cip.connector.dto.mobile.MobileUserRequestDto, com.seeyon.cip.connector.dto.mobile.MobilePlatformConfigDto);
    com.seeyon.cip.connector.dto.mobile.MobileUserResponseDto removeUser(com.seeyon.cip.connector.dto.mobile.MobileUserRequestDto, com.seeyon.cip.connector.dto.mobile.MobilePlatformConfigDto);
    default com.seeyon.cip.connector.dto.mobile.MobileOrgDto syncUnitNew(com.seeyon.cip.connector.dto.mobile.MobileUnitRequestDto, com.seeyon.cip.connector.dto.mobile.MobilePlatformConfigDto);
```

### `SsoService`（7 方法）

`com.seeyon.cip.connector.api.sso.SsoService`

```java
    java.lang.String getName();
    java.lang.String getTypeCaption();
    java.lang.String login(java.lang.String, java.lang.String, java.util.Map<java.lang.String, java.lang.Object>, com.seeyon.cip.connector.enums.SsoClientTypeEnum, java.util.Map<java.lang.String, java.lang.Object>);
    void check(java.lang.String);
    java.lang.String getPageJson();
    java.lang.Integer getSortNo();
    boolean needUserBind();
```

### `MobileTodoProviderService`（6 方法） extends MobileProviderService

`com.seeyon.cip.connector.api.mobile.MobileTodoProviderService`

```java
    java.lang.String createTodo(com.seeyon.cip.connector.dto.mobile.MobilePlatformConfigDto, com.seeyon.cip.connector.dto.mobile.MobileTodoRequestDto);
    void updateTodo(com.seeyon.cip.connector.dto.mobile.MobilePlatformConfigDto, com.seeyon.cip.connector.dto.mobile.MobileTodoRequestDto);
    default void doneTodo(com.seeyon.cip.connector.dto.mobile.MobilePlatformConfigDto, java.lang.Long, java.lang.String);
    default void deleteTodo(com.seeyon.cip.connector.dto.mobile.MobilePlatformConfigDto, java.lang.Long, java.lang.String);
    default java.lang.String doneTodo(com.seeyon.cip.connector.dto.mobile.MobilePlatformConfigDto, com.seeyon.cip.connector.dto.mobile.MobileTodoTaskDto);
    default java.lang.String deleteTodo(com.seeyon.cip.connector.dto.mobile.MobilePlatformConfigDto, com.seeyon.cip.connector.dto.mobile.MobileTodoTaskDto);
```

### `MiddleTableOrgSyncDataCallbackService`（5 方法）

`com.seeyon.cip.connector.api.midorgsync.callback.MiddleTableOrgSyncDataCallbackService`

```java
    java.lang.Integer batchSaveOrg(com.seeyon.cip.connector.dto.midorgsync.UnitInfoSpiReqDto);
    java.lang.Integer batchSavePosition(com.seeyon.cip.connector.dto.midorgsync.PostInfoSpiReqDto);
    java.lang.Integer batchSaveDuty(com.seeyon.cip.connector.dto.midorgsync.DutyInfoSpiReqDto);
    java.lang.Integer batchSaveLevel(com.seeyon.cip.connector.dto.midorgsync.LevelInfoSpiReqDto);
    java.lang.Integer batchSaveMember(com.seeyon.cip.connector.dto.midorgsync.MemberInfoSpiReqDto);
```

### `MobileOrgSyncPullProviderService`（5 方法） extends MobileProviderService

`com.seeyon.cip.connector.api.mobile.MobileOrgSyncPullProviderService`

```java
    java.util.List<com.seeyon.cip.connector.dto.mobile.MobileSyncPullOrgResponseDto> listSyncOrg(com.seeyon.cip.connector.dto.mobile.MobilePlatformConfigDto, java.lang.String);
    java.util.List<com.seeyon.cip.connector.dto.mobile.MobileSyncPullUserResponseDto> listSyncUser(com.seeyon.cip.connector.dto.mobile.MobilePlatformConfigDto, java.lang.String);
    default java.util.List<com.seeyon.cip.connector.dto.mobile.MobileSyncPullPostDto> listSyncPost(com.seeyon.cip.connector.dto.mobile.MobilePlatformConfigDto, java.lang.String);
    default java.util.List<com.seeyon.cip.connector.dto.mobile.MobileSyncPullJobDto> listSyncJob(com.seeyon.cip.connector.dto.mobile.MobilePlatformConfigDto, java.lang.String);
    default java.util.List<com.seeyon.cip.connector.dto.mobile.MobileSyncPullLevelDto> listSyncLevel(com.seeyon.cip.connector.dto.mobile.MobilePlatformConfigDto, java.lang.String);
```

### `LinkerMigrationAppService`（4 方法）

`com.seeyon.cip.connector.api.core.LinkerMigrationAppService`

```java
    com.seeyon.boot.transport.SingleResponse<java.lang.String> exportEntityTask(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.connector.dto.info.LinkMigrationRequestDto>);
    com.seeyon.boot.transport.SingleResponse<java.util.Map<java.lang.String, java.lang.String>> initDataJsonByNames(com.seeyon.boot.transport.SingleRequest<java.util.List<java.lang.String>>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.cip.connector.dto.migrate.ConnectorMigrateDto> listConnectorData(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.connector.dto.migrate.ConnectorMigrateRequestDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Void> importConnectorData(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.connector.dto.migrate.ConnectorMigrateImportResponseDto>);
```

### `LinkerSignService`（4 方法）

`com.seeyon.cip.connector.api.sign.LinkerSignService`

```java
    java.lang.String getName();
    java.lang.String getCaption();
    com.seeyon.cip.connector.dto.sign.RequestParamDto doSign(com.seeyon.cip.connector.dto.sign.LinkerSignDto, com.seeyon.cip.connector.dto.sign.RequestParamDto);
    java.lang.Integer getSortNo();
```

### `MobileOrgSyncBatchProviderService`（3 方法） extends MobileProviderService

`com.seeyon.cip.connector.api.mobile.MobileOrgSyncBatchProviderService`

```java
    java.lang.String syncUnitBatch(com.seeyon.cip.connector.dto.mobile.batch.MobileDepartmentBatchSyncDto, com.seeyon.cip.connector.dto.mobile.MobilePlatformConfigDto);
    java.lang.String userSyncBatch(com.seeyon.cip.connector.dto.mobile.batch.MobileUserBatchSyncDto, com.seeyon.cip.connector.dto.mobile.MobilePlatformConfigDto);
    com.seeyon.cip.connector.dto.mobile.batch.MobileContactBatchResultDto syncBatchResult(com.seeyon.cip.connector.dto.mobile.batch.MobileBatchResultDto, com.seeyon.cip.connector.dto.mobile.MobilePlatformConfigDto);
```

### `CipConnectorComment`（2 方法） extends Annotation

`com.seeyon.cip.connector.annotation.CipConnectorComment`

```java
    java.lang.String value();
    java.lang.String example();
```

### `ConnectorChannelRouter`（2 方法） extends Annotation

`com.seeyon.cip.connector.annotation.ConnectorChannelRouter`

```java
    java.lang.String[] value();
    java.lang.String desc();
```

### `MiddleTableChannelRouter`（2 方法） extends Annotation

`com.seeyon.cip.connector.annotation.MiddleTableChannelRouter`

```java
    java.lang.String[] value();
    java.lang.String description();
```

### `ConnectorCallbackMessageSendService`（2 方法） extends BaseDto>

`com.seeyon.cip.connector.api.callback.ConnectorCallbackMessageSendService`

```java
    void sendMsgAsync(T);
    void sendMsgSync(T);
```

### `MiddleTableOrgSyncSpiPullService`（2 方法）

`com.seeyon.cip.connector.api.midorgsync.MiddleTableOrgSyncSpiPullService`

```java
    void pullAll(com.seeyon.cip.connector.dto.midorgsync.spi.ConfigInfoApiDto, com.seeyon.cip.connector.api.midorgsync.callback.MiddleTableOrgSyncDataCallbackService, com.seeyon.cip.connector.api.midorgsync.callback.MiddleTableOrgSyncMarkCallbackService, com.seeyon.cip.connector.api.midorgsync.callback.MiddleTableOrgSyncExecuteCallbackService);
    void pullIncrement(com.seeyon.cip.connector.dto.midorgsync.spi.ConfigInfoApiDto, com.seeyon.cip.connector.api.midorgsync.callback.MiddleTableOrgSyncDataCallbackService, com.seeyon.cip.connector.api.midorgsync.callback.MiddleTableOrgSyncExecuteCallbackService);
```

### `CipThirdAffairService`（1 方法）

`com.seeyon.cip.connector.api.affair.CipThirdAffairService`

```java
    java.util.List<com.seeyon.cip.connector.dto.template.ThirdTemplateDataSpiReturnDto> queryThirdAffairFieldData(com.seeyon.cip.connector.dto.template.ThirdTemplateDataSpiReqDto);
```

### `ConnectorCallbackProviderService`（1 方法）

`com.seeyon.cip.connector.api.callback.ConnectorCallbackProviderService`

```java
    Res doCallback(com.seeyon.cip.connector.dto.callback.ConnectorCallbackRequestDto, com.seeyon.cip.connector.api.callback.ConnectorCallbackMessageSendService<T>);
```

### `LinkerEnumAppService`（1 方法）

`com.seeyon.cip.connector.api.core.LinkerEnumAppService`

```java
    com.seeyon.boot.transport.ListResponse<com.seeyon.cip.connector.dto.info.LinkerEnumItemDto> selectItemList(com.seeyon.boot.transport.ListRequest);
```

### `SsoExecutorAppService`（1 方法）

`com.seeyon.cip.connector.api.core.SsoExecutorAppService`

```java
    com.seeyon.boot.transport.SingleResponse<java.lang.String> ssoLongin(com.seeyon.boot.transport.SingleRequest<com.seeyon.cip.connector.dto.sso.SsoRequestDto>);
```

### `MiddleTableOrgSyncSpiListenerService`（1 方法）

`com.seeyon.cip.connector.api.midorgsync.MiddleTableOrgSyncSpiListenerService`

```java
    java.lang.Object dataGovernance(com.seeyon.cip.connector.dto.callback.ConnectorCallbackRequestDto, com.seeyon.cip.connector.api.midorgsync.callback.MiddleTableOrgSyncDataCallbackService, com.seeyon.cip.connector.api.midorgsync.callback.MiddleTableOrgSyncMarkCallbackService, com.seeyon.cip.connector.api.midorgsync.callback.MiddleTableOrgSyncExecuteCallbackService);
```

### `MiddleTableOrgSyncExecuteCallbackService`（1 方法）

`com.seeyon.cip.connector.api.midorgsync.callback.MiddleTableOrgSyncExecuteCallbackService`

```java
    java.lang.Boolean executeSyncToOrgModel(java.lang.String);
```

### `MiddleTableOrgSyncMarkCallbackService`（1 方法）

`com.seeyon.cip.connector.api.midorgsync.callback.MiddleTableOrgSyncMarkCallbackService`

```java
    java.lang.String markComplete(java.lang.String);
```

### `MobileCallBackProviderService`（0 方法）

`com.seeyon.cip.connector.api.mobile.MobileCallBackProviderService`

```java
```

### `MobileProviderService`（0 方法）

`com.seeyon.cip.connector.api.mobile.MobileProviderService`

```java
```

## 二、关键类（4）

### `ExecutorResultApiDto`（12 方法）

`com.seeyon.cip.connector.dto.db.ExecutorResultApiDto`

```java
    java.lang.Object getParam();
    java.lang.Object getResult();
    java.lang.Object getHttpRequest();
    java.lang.Object getHttpResponse();
    com.seeyon.boot.exception.BusinessException getException();
    com.seeyon.boot.transport.PageInfo getPageInfo();
    void setParam(java.lang.Object);
    void setResult(java.lang.Object);
    void setHttpRequest(java.lang.Object);
    void setHttpResponse(java.lang.Object);
    void setException(com.seeyon.boot.exception.BusinessException);
    void setPageInfo(com.seeyon.boot.transport.PageInfo);
```

### `MobileUrlProviderDto`（10 方法）

`com.seeyon.cip.connector.dto.mobile.MobileUrlProviderDto`

```java
    static com.seeyon.cip.connector.dto.mobile.MobileUrlProviderDto$MobileUrlProviderDtoBuilder builder();
    java.lang.String getPortalDomain();
    java.lang.String getPortalPath();
    java.util.Map<java.lang.String, java.lang.String> getMobilePathPara();
    java.util.Map<java.lang.String, java.lang.String> getWebPathPara();
    java.lang.String getCorpId();
    java.lang.String getAppId();
    java.lang.String getAppKey();
    java.lang.String getThirdApplicationDomain();
    java.lang.String getJson();
```

### `ThirdTemplateDataSpiReqDto`（8 方法）

`com.seeyon.cip.connector.dto.template.ThirdTemplateDataSpiReqDto`

```java
    java.lang.String getLinkerCode();
    java.lang.String getTemplateCode();
    java.util.List<java.lang.String> getFields();
    java.util.List<java.lang.String> getThirdIds();
    void setLinkerCode(java.lang.String);
    void setTemplateCode(java.lang.String);
    void setFields(java.util.List<java.lang.String>);
    void setThirdIds(java.util.List<java.lang.String>);
```

### `CipConnectorSpiUtils`（6 方法）

`com.seeyon.cip.connector.common.CipConnectorSpiUtils`

```java
    private void CipConnectorSpiUtils();
    static <T> T getInstance(java.lang.Class<T>);
    static <T> T getBean(java.lang.Class<T>);
    static <T> T getBean(java.lang.String, java.lang.Class<T>);
    static <T> T invokeBean(java.lang.String, java.lang.String, java.lang.Object...);
    static java.lang.String getPropertyByName(java.lang.String);
```
