# BPM 流程：接口与方法签名

> 自动生成，勿手改。`tools/core/platform/emit_domain_surfaces.py` 重跑即可。
> 用途：流程发起/提交/退回/终止/暂停、模板、表单权限、节点权限
> 规模：533 类 / 40 接口 / 24 个关键类 / 5893 方法。包前缀 `com.seeyon.bpm`。
> 签名逐字来自 javap 原文，已去掉 `public` 等修饰前缀与 `throws`。

## 一、接口（40）

### `BpmTemplateAppService`（55 方法）

`com.seeyon.bpm.api.common.BpmTemplateAppService`

```java
    com.seeyon.boot.transport.SingleResponse<java.lang.Long> createOrUpdate(com.seeyon.boot.transport.SingleRequest<com.seeyon.bpm.dto.BpmTemplateDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Void> deleteById(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Void> updateCategoryByApplicationId(com.seeyon.boot.transport.SingleRequest<com.seeyon.bpm.dto.BpmUpdateCategoryDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Void> publishCheck(com.seeyon.boot.transport.SingleRequest<java.lang.String>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Void> publishCheckByAppInfo(com.seeyon.boot.transport.SingleRequest<com.seeyon.bpm.dto.BpmAppInfoDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Void> publishLock(com.seeyon.boot.transport.SingleRequest<java.lang.String>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Void> publishLockByAppInfo(com.seeyon.boot.transport.SingleRequest<com.seeyon.bpm.dto.BpmAppInfoDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Void> publishFinish(com.seeyon.boot.transport.SingleRequest<com.seeyon.bpm.dto.transport.BpmPublishResult>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Void> cleanCacheByApplicationName(com.seeyon.boot.transport.SingleRequest<java.lang.String>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.bpm.dto.BpmTemplateDto> startCheck(com.seeyon.boot.transport.SingleRequest<com.seeyon.bpm.dto.BpmStartTemplateDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Void> start(com.seeyon.boot.transport.SingleRequest<java.lang.String>, com.seeyon.boot.transport.SingleRequest<java.lang.String>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.bpm.dto.BpmTemplateDto> startByTemplateId(com.seeyon.boot.transport.SingleRequest<com.seeyon.bpm.dto.BpmStartTemplateDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.bpm.dto.BpmTemplateDto> startByTemplateIdWithoutAuth(com.seeyon.boot.transport.SingleRequest<com.seeyon.bpm.dto.BpmStartTemplateDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Void> stop(com.seeyon.boot.transport.SingleRequest<java.lang.String>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Void> stopByTemplateId(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Void> deleteByApps(com.seeyon.boot.transport.SingleRequest<java.util.List<com.seeyon.bpm.dto.AppDeleteDto>>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.bpm.dto.BpmTemplateDto> selectByApplicationName(com.seeyon.boot.transport.SingleRequest<java.lang.String>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.bpm.dto.BpmTemplateDto> updateEffectTimeByTemplateId(com.seeyon.boot.transport.SingleRequest<com.seeyon.bpm.dto.BpmStartTemplateDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Void> updateEffectTime(com.seeyon.boot.transport.SingleRequest<java.lang.String>, com.seeyon.boot.transport.SingleRequest<java.util.Date>, com.seeyon.boot.transport.SingleRequest<java.util.Date>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Void> updateAuthorized(com.seeyon.boot.transport.SingleRequest<java.util.List<com.seeyon.bpm.dto.BpmTemplateAuthorizationDto>>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.bpm.dto.BpmTemplateDto> selectById(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    default com.seeyon.boot.transport.ListResponse<com.seeyon.bpm.dto.BpmTemplateDto> selectTemplateListByCondition(com.seeyon.boot.transport.SingleRequest<com.seeyon.bpm.dto.operation.openapi.BpmTemplateSearchConditionDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.bpm.dto.BpmTemplateSimpleDto> selectByTemplateUrlId(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.bpm.dto.BpmAppTemplateDto> selectEffectedDiagramListByAppName(com.seeyon.boot.transport.SingleRequest<com.seeyon.bpm.dto.BaseBpmHandlerParamDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.bpm.dto.BpmTemplateUserGuidInfo> selectTemplateUserGuidInfo(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.bpm.dto.BpmTemplateInfoDto> selectTemplateById(com.seeyon.boot.transport.SingleRequest<com.seeyon.bpm.dto.SeachTemplateInfoDto>);
    default com.seeyon.boot.transport.PageResponse<com.seeyon.bpm.dto.pathtable.BpmPathTableDefineBaseDto> selectPathTableCondition(com.seeyon.boot.transport.SingleRequest<com.seeyon.bpm.dto.pathtable.BpmPathTableDefineSearchDto>);
    com.seeyon.boot.transport.ListResponse<java.lang.Long> selectTemplateIdsByName(com.seeyon.boot.transport.SingleRequest<java.lang.String>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.bpm.dto.BpmTemplateDto> selectTemplateByRootEntityId(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.bpm.dto.BpmTemplateDto> selectTemplateByParams(com.seeyon.boot.transport.SingleRequest<com.seeyon.bpm.dto.BpmTemplateParamDto>);
    default com.seeyon.boot.transport.ListResponse<com.seeyon.bpm.dto.BpmTemplateDto> selectTemplateByRootEntityName(com.seeyon.boot.transport.SingleRequest<java.lang.String>);
    default com.seeyon.boot.transport.SingleResponse<java.lang.Boolean> hasDesignTemplateByEntityName(com.seeyon.boot.transport.SingleRequest<java.lang.String>);
    default com.seeyon.boot.transport.ListResponse<com.seeyon.bpm.dto.BpmTemplateDto> selectByIds(com.seeyon.boot.transport.SingleRequest<java.util.List<java.lang.Long>>);
    com.seeyon.boot.transport.PageResponse<com.seeyon.bpm.dto.formtemplate.UserTemplateDto> selectUserTemplatePageList(com.seeyon.boot.transport.SingleRequest<com.seeyon.bpm.dto.formtemplate.UserTemplateListRequestDto>);
    com.seeyon.boot.transport.ListResponse<java.lang.Long> selectTemplateGuidByCategoryCode(com.seeyon.boot.transport.SingleRequest<java.lang.String>);
    default com.seeyon.boot.transport.PageResponse<com.seeyon.bpm.dto.BpmTemplateOwnerDto> selectBpmTemplateOwnerPageList(com.seeyon.boot.transport.SingleRequest<com.seeyon.bpm.dto.operation.openapi.BpmTemplateOwnerSearchDto>);
    default com.seeyon.boot.transport.ListResponse<java.lang.String> filterEnableTemplateAppName(com.seeyon.boot.transport.SingleRequest<java.util.List<java.lang.String>>);
    default com.seeyon.boot.transport.SingleResponse<com.seeyon.bpm.dto.BpmTemplateDto> selectCascadeById(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    default com.seeyon.boot.transport.ListResponse<com.seeyon.bpm.dto.BpmTemplateDto> selectCascadeByIds(com.seeyon.boot.transport.SingleRequest<java.util.List<java.lang.Long>>);
    default com.seeyon.boot.transport.PageResponse<com.seeyon.bpm.dto.BpmTemplateDto> dynamicSelect(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.dynamicsql.dto.ProxyParamDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> updateByAppName(com.seeyon.boot.transport.SingleRequest<com.seeyon.bpm.dto.BpmTemplateDto>);
    default com.seeyon.boot.transport.PageResponse<com.seeyon.bpm.dto.BpmTemplateDto> dynamicJoinSelect(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.dynamicsql.dto.ProxyJoinParamDto>);
    default com.seeyon.boot.transport.SingleResponse<com.seeyon.bpm.dto.BpmTemplateDto> selectCascadeByConditions(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.dynamicsql.dto.QueryConditionDto>);
    default com.seeyon.boot.transport.ListResponse<com.seeyon.bpm.dto.BpmTemplateDto> selectCascadeListByConditions(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.dynamicsql.dto.QueryConditionDto>);
    default com.seeyon.boot.transport.ListResponse<java.lang.Long> selectTemplateIdListByGuid(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.bpm.dto.approval.BpmNodeDetailDto> selectNodeDetail(com.seeyon.boot.transport.SingleRequest<com.seeyon.bpm.dto.approval.BpmNodeDetailReqDto>);
    default com.seeyon.boot.transport.SingleResponse<com.seeyon.bpm.dto.BpmTemplateDto> selectByIdDisplayName(com.seeyon.boot.transport.SingleRequest<java.lang.Long>, com.seeyon.boot.transport.SingleRequest<java.util.Set<java.lang.String>>);
    default com.seeyon.boot.transport.ListResponse<com.seeyon.bpm.dto.BpmTemplateDto> selectByIdsDisplayName(com.seeyon.boot.transport.SingleRequest<java.util.List<java.lang.Long>>, com.seeyon.boot.transport.SingleRequest<java.util.Set<java.lang.String>>);
    default com.seeyon.boot.transport.ListResponse<java.lang.Long> selectTemplateBySearchDto(com.seeyon.boot.transport.SingleRequest<com.seeyon.bpm.dto.BpmTemplateAppSearchDto>);
    default com.seeyon.boot.transport.ListResponse<java.lang.Long> selectTemplateByCategoryIds(com.seeyon.boot.transport.SingleRequest<com.seeyon.bpm.dto.BpmTemplateCategorySearchDto>);
    default com.seeyon.boot.transport.SingleResponse<java.lang.Long> updateTemplateExtend(com.seeyon.boot.transport.SingleRequest<com.seeyon.bpm.dto.BpmTemplateExtendUpdateDto>);
    default com.seeyon.boot.transport.ListResponse<com.seeyon.bpm.dto.BpmTemplateDto> selectNormalMultiVersionDraft(com.seeyon.boot.transport.SingleRequest<com.seeyon.bpm.dto.BpmNormalMultiVersionSearchDto>);
    default com.seeyon.boot.transport.SingleResponse<com.seeyon.bpm.dto.BpmTemplateDto> getCascadeDefaultValue(com.seeyon.boot.transport.SingleRequest<java.lang.Void>);
    default com.seeyon.boot.transport.SingleResponse<com.seeyon.bpm.dto.BpmTemplateDto> getCascadeDefaultValue();
    default com.seeyon.boot.transport.ListResponse<com.seeyon.bpm.dto.BpmTemplateDto> selectLatestTemplateByGuids(com.seeyon.boot.transport.SingleRequest<java.util.List<java.lang.Long>>);
```

### `BpmAppService`（26 方法）

`com.seeyon.bpm.api.common.BpmAppService`

```java
    com.seeyon.boot.transport.SingleResponse<com.seeyon.bpm.dto.operation.openapi.BpmSendResultDto> send(com.seeyon.boot.transport.SingleRequest<com.seeyon.bpm.dto.operation.openapi.BpmSendDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.bpm.dto.operation.openapi.BpmSaveDraftResultDto> saveDraft(com.seeyon.boot.transport.SingleRequest<com.seeyon.bpm.dto.operation.openapi.BpmSaveDraftDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.bpm.dto.operation.openapi.BpmSubmitResultDto> submit(com.seeyon.boot.transport.SingleRequest<com.seeyon.bpm.dto.operation.openapi.BpmSubmitDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.bpm.dto.CommonResultDto> stepBack(com.seeyon.boot.transport.SingleRequest<com.seeyon.bpm.dto.operation.openapi.BpmStepBackDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.bpm.dto.CommonResultDto> repeal(com.seeyon.boot.transport.SingleRequest<com.seeyon.bpm.dto.operation.openapi.BpmRepealDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.bpm.dto.CommonResultDto> stop(com.seeyon.boot.transport.SingleRequest<com.seeyon.bpm.dto.operation.openapi.BpmStopDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.bpm.dto.CommonResultDto> takeBack(com.seeyon.boot.transport.SingleRequest<com.seeyon.bpm.dto.operation.openapi.BpmTakeBackDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.bpm.dto.CommonResultDto> replace(com.seeyon.boot.transport.SingleRequest<com.seeyon.bpm.dto.operation.openapi.BpmReplaceDto>);
    default com.seeyon.boot.transport.SingleResponse<com.seeyon.bpm.dto.CommonResultDto> consult(com.seeyon.boot.transport.SingleRequest<com.seeyon.bpm.dto.operation.openapi.BpmConsultDto>);
    default com.seeyon.boot.transport.ListResponse<com.seeyon.bpm.dto.operation.openapi.BpmHastenResponseDto> hasten(com.seeyon.boot.transport.SingleRequest<com.seeyon.bpm.dto.operation.openapi.BpmHastenDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.bpm.dto.CommonResultDto> multipleReplace(com.seeyon.boot.transport.SingleRequest<com.seeyon.bpm.dto.operation.openapi.BpmMultipleReplaceDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.bpm.dto.operation.openapi.BpmPauseResponseDto> pause(com.seeyon.boot.transport.SingleRequest<com.seeyon.bpm.dto.operation.openapi.BpmPauseDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.bpm.dto.operation.openapi.BpmPauseResponseDto> cancelPause(com.seeyon.boot.transport.SingleRequest<com.seeyon.bpm.dto.operation.openapi.BpmPauseDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.bpm.dto.CommonResultDto> superviseRelive(com.seeyon.boot.transport.SingleRequest<com.seeyon.bpm.dto.operation.openapi.BpmReliveDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.bpm.dto.CommonResultDto> superviseReliveFull(com.seeyon.boot.transport.SingleRequest<com.seeyon.bpm.dto.operation.openapi.BpmReliveFullDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.bpm.dto.CommonResultDto> inform(com.seeyon.boot.transport.SingleRequest<com.seeyon.bpm.dto.operation.openapi.BpmInformDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.bpm.dto.message.msg.BpmItemInfoDto> addExecuteMember(com.seeyon.boot.transport.SingleRequest<com.seeyon.bpm.dto.operation.openapi.BpmAddExecuteUserDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.bpm.dto.CommonResultDto> cancelItems(com.seeyon.boot.transport.SingleRequest<com.seeyon.bpm.dto.operation.openapi.BpmCancelItemDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.bpm.dto.approval.BpmBatchResponseDto> batchDeal(com.seeyon.boot.transport.SingleRequest<com.seeyon.bpm.dto.approval.BpmBatchReqDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.bpm.dto.fullinfo.BpmCaseFullInfo> selectFullCaseInfo(com.seeyon.boot.transport.SingleRequest<com.seeyon.bpm.dto.fullinfo.BpmCaseFullInfoSearch>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.bpm.dto.ChangeNodeResponseDto> counterSignNode(com.seeyon.boot.transport.SingleRequest<com.seeyon.bpm.dto.SimpleChangeProcessRequestDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.bpm.dto.ChangeNodeResponseDto> addNode(com.seeyon.boot.transport.SingleRequest<com.seeyon.bpm.dto.SimpleChangeProcessRequestDto>);
    default com.seeyon.boot.transport.SingleResponse<com.seeyon.bpm.dto.operation.openapi.BpmMonitorRunResultDto> monitorNodeRun(com.seeyon.boot.transport.SingleRequest<com.seeyon.bpm.dto.operation.openapi.BpmMonitorRunDto>);
    default com.seeyon.boot.transport.SingleResponse<java.lang.Boolean> check(com.seeyon.boot.transport.SingleRequest<com.seeyon.bpm.dto.SecurityCheckDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Void> deleteDraft(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Void> deleteDraftAffair(com.seeyon.boot.transport.SingleRequest<com.seeyon.bpm.dto.DeleteDraftReqDto>);
```

### `BpmCaseAppService`（23 方法）

`com.seeyon.bpm.api.common.BpmCaseAppService`

```java
    com.seeyon.boot.transport.SingleResponse<com.seeyon.bpm.dto.BpmCaseDto> selectCaseById(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Long> selectMainCaseBySubCaseId(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    default com.seeyon.boot.transport.SingleResponse<java.lang.String> deleteCaseByIds(com.seeyon.boot.transport.SingleRequest<com.seeyon.bpm.dto.BpmDeleteCaseDto>);
    default com.seeyon.boot.transport.SingleResponse<com.seeyon.bpm.dto.BpmCaseDto> selectById(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    default com.seeyon.boot.transport.ListResponse<com.seeyon.bpm.dto.BpmCaseDto> selectByIds(com.seeyon.boot.transport.SingleRequest<java.util.List<java.lang.Long>>);
    default com.seeyon.boot.transport.SingleResponse<com.seeyon.bpm.dto.BpmCaseDto> selectBpmCaseByFormRecordId(com.seeyon.boot.transport.SingleRequest<com.seeyon.bpm.dto.operation.openapi.BpmCaseInfoSearchDto>);
    default com.seeyon.boot.transport.PageResponse<com.seeyon.bpm.dto.BpmCaseDto> selectByPageCondition(com.seeyon.boot.transport.PageRequest);
    default com.seeyon.boot.transport.SingleResponse<com.seeyon.bpm.dto.BpmCaseDto> selectCascadeById(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    default com.seeyon.boot.transport.ListResponse<com.seeyon.bpm.dto.BpmCaseDto> selectCascadeByIds(com.seeyon.boot.transport.SingleRequest<java.util.List<java.lang.Long>>);
    default com.seeyon.boot.transport.PageResponse<com.seeyon.bpm.dto.BpmCaseDto> dynamicSelect(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.dynamicsql.dto.ProxyParamDto>);
    default com.seeyon.boot.transport.PageResponse<com.seeyon.bpm.dto.BpmCaseDto> dynamicJoinSelect(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.dynamicsql.dto.ProxyJoinParamDto>);
    default com.seeyon.boot.transport.PageResponse<com.seeyon.bpm.dto.BpmCaseDto> selectPageByConditions(com.seeyon.boot.transport.PageRequest);
    default com.seeyon.boot.transport.SingleResponse<java.lang.String> refreshCaseTitleById(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    default com.seeyon.boot.transport.SingleResponse<com.seeyon.bpm.dto.BpmCaseDto> selectCascadeByConditions(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.dynamicsql.dto.QueryConditionDto>);
    default com.seeyon.boot.transport.ListResponse<com.seeyon.bpm.dto.BpmCaseDto> selectCascadeListByConditions(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.dynamicsql.dto.QueryConditionDto>);
    default com.seeyon.boot.transport.SingleResponse<com.seeyon.bpm.dto.BpmCaseDto> getCascadeDefaultValue(com.seeyon.boot.transport.SingleRequest<java.lang.Void>);
    default com.seeyon.boot.transport.ListResponse<java.lang.String> selectCaseAttachmentList(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    default com.seeyon.boot.transport.SingleResponse<java.lang.Integer> create(com.seeyon.boot.transport.SingleRequest<com.seeyon.bpm.dto.BpmCaseDto>);
    default com.seeyon.boot.transport.SingleResponse<java.lang.Integer> createBatch(com.seeyon.boot.transport.SingleRequest<java.util.List<com.seeyon.bpm.dto.BpmCaseDto>>);
    default com.seeyon.boot.transport.SingleResponse<com.seeyon.bpm.dto.BpmCaseDto> selectByIdDisplayName(com.seeyon.boot.transport.SingleRequest<java.lang.Long>, com.seeyon.boot.transport.SingleRequest<java.util.Set<java.lang.String>>);
    default com.seeyon.boot.transport.ListResponse<com.seeyon.bpm.dto.BpmCaseDto> selectByIdsDisplayName(com.seeyon.boot.transport.SingleRequest<java.util.List<java.lang.Long>>, com.seeyon.boot.transport.SingleRequest<java.util.Set<java.lang.String>>);
    default com.seeyon.boot.transport.SingleResponse<java.lang.Void> updateCase(com.seeyon.boot.transport.SingleRequest<com.seeyon.bpm.dto.BpmCaseDto>);
    default com.seeyon.boot.transport.SingleResponse<com.seeyon.bpm.dto.expression.BpmExpressionDto> selectExpression(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
```

### `BpmApiFormPermissionAppService`（18 方法）

`com.seeyon.bpm.api.common.BpmApiFormPermissionAppService`

```java
    com.seeyon.boot.transport.SingleResponse<java.lang.Long> create(com.seeyon.boot.transport.SingleRequest<com.seeyon.bpm.dto.BpmFormPermissionDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Void> update(com.seeyon.boot.transport.SingleRequest<com.seeyon.bpm.dto.BpmFormPermissionDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Void> deleteById(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.bpm.dto.BpmFormPermissionDto> selectByTemplateId(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.bpm.dto.BpmFormPermissionDto> selectById(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.bpm.dto.BpmFormPermissionIncludeContentDto> selectPermissionIncludeContentById(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.bpm.dto.BpmFormPermissionDto> selectByApplicationName(com.seeyon.boot.transport.SingleRequest<java.lang.String>);
    default com.seeyon.boot.transport.SingleResponse<com.seeyon.bpm.dto.ThirdFormPermissionDto> selectThirdPermissionByTemplateId(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.bpm.dto.BpmFormPermissionDto> selectByIds(com.seeyon.boot.transport.SingleRequest<java.util.List<java.lang.Long>>);
    default com.seeyon.boot.transport.ListResponse<com.seeyon.bpm.dto.BpmFormDesensitizedDto> selectFormDesensitizedList(com.seeyon.boot.transport.SingleRequest<com.seeyon.bpm.dto.BpmFormDesensitizedQueryDto>);
    default com.seeyon.boot.transport.SingleResponse<com.seeyon.bpm.dto.ThirdFormPermissionDto> selectThirdFormPermissionById(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    default com.seeyon.boot.transport.ListResponse<com.seeyon.bpm.dto.BpmFormPermissionDto> selectFormPermissionList(com.seeyon.boot.transport.SingleRequest<com.seeyon.bpm.dto.BpmFormPermissionSearchRequestDto>);
    default com.seeyon.boot.transport.SingleResponse<java.lang.Void> deleteFormPermisionForceEntityDraft(com.seeyon.boot.transport.SingleRequest<com.seeyon.bpm.dto.BpmFormPermissionDeleteRequestDto>);
    default com.seeyon.boot.transport.ListResponse<com.seeyon.bpm.dto.BpmFormPermissionIncludeContentDto> selectFormPermissionIncludeContentList(com.seeyon.boot.transport.SingleRequest<java.util.List<com.seeyon.bpm.dto.BpmFormPermissionSearchRequestDto>>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Void> createOrUpdateBatch(com.seeyon.boot.transport.SingleRequest<java.util.List<com.seeyon.bpm.dto.BpmFormPermissionDto>>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Void> createBatchOrUpdateContent(com.seeyon.boot.transport.SingleRequest<java.util.List<com.seeyon.bpm.dto.BpmFormPermissionContentDto>>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.bpm.dto.BpmFormPermissionContentSimpleDto> selectContentListByPermissionIds(com.seeyon.boot.transport.SingleRequest<java.util.List<java.lang.Long>>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.bpm.dto.CheckFormPermissionRespDto> checkFormPermissionBatch(com.seeyon.boot.transport.SingleRequest<java.util.List<com.seeyon.bpm.dto.BpmFormPermissionDto>>);
```

### `BpmSupportOperation`（16 方法）

`com.seeyon.bpm.api.ext.activity.BpmSupportOperation`

```java
    java.lang.String getConfigId();
    java.util.Map<java.lang.String, java.lang.Object> getParameters();
    void setParameter(java.lang.String, java.lang.Object);
    java.lang.Object getConfigurationValue(java.lang.String);
    java.util.Map<java.lang.String, java.lang.Object> getAllConfigurationValues();
    java.lang.Long getCaseId();
    java.lang.Long getActivityId();
    java.lang.String getActivityPolicyId();
    java.lang.String getAppName();
    java.lang.Long getTemplateId();
    java.lang.String getFormRecordId();
    java.lang.String getRootEntityName();
    java.lang.String getApplicationName();
    java.lang.String getSubject();
    java.lang.Long getStartUserId();
    java.lang.Long getCurrentUserId();
```

### `BpmApiNodePermissionAppService`（11 方法）

`com.seeyon.bpm.api.common.BpmApiNodePermissionAppService`

```java
    com.seeyon.boot.transport.SingleResponse<java.lang.Void> bpmNodePermissionHandel(com.seeyon.boot.transport.SingleRequest<com.seeyon.bpm.dto.BpmNodePermissionInitDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.bpm.dto.BpmNodePermissionDetailDto> selectNodePermissionById(com.seeyon.boot.transport.SingleRequest<com.seeyon.bpm.dto.BpmNodePermissionQueryDto>);
    default com.seeyon.boot.transport.ListResponse<com.seeyon.bpm.dto.BpmNodePermissionDetailDto> selectNodePermissionListByIds(com.seeyon.boot.transport.SingleRequest<com.seeyon.bpm.dto.BpmNodePermissionQueryDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Long> savePermission(com.seeyon.boot.transport.SingleRequest<com.seeyon.bpm.dto.BpmNodePermissionAddDto>);
    com.seeyon.boot.transport.ListResponse<java.lang.Long> savePermissionList(com.seeyon.boot.transport.SingleRequest<java.util.List<com.seeyon.bpm.dto.BpmNodePermissionAddDto>>);
    default com.seeyon.boot.transport.ListResponse<com.seeyon.bpm.dto.nodepermission.BpmNodePermissionSearchResponseDto> queryPermissionList(com.seeyon.boot.transport.SingleRequest<com.seeyon.bpm.dto.nodepermission.BpmNodePermissionSearchRequestDto>);
    default com.seeyon.boot.transport.SingleResponse<java.lang.Void> configNodePermissionBind(com.seeyon.boot.transport.SingleRequest<java.util.List<com.seeyon.bpm.dto.nodepermission.BpmNodePermissionBindDto>>);
    default com.seeyon.boot.transport.ListResponse<com.seeyon.bpm.dto.BpmNodePermissionDetailDto> selectNodePermissionDetailListByIds(com.seeyon.boot.transport.SingleRequest<java.util.List<java.lang.Long>>);
    default com.seeyon.boot.transport.ListResponse<com.seeyon.bpm.dto.BpmNodePermissionFullFieldDto> selectNodePermissionListByConditions(com.seeyon.boot.transport.SingleRequest<com.seeyon.bpm.dto.nodepermission.BpmNodePermissionQueryConditionDto>);
    default com.seeyon.boot.transport.SingleResponse<java.lang.Void> createOrUpdateNodePermissionBatch(com.seeyon.boot.transport.SingleRequest<java.util.List<com.seeyon.bpm.dto.BpmNodePermissionFullFieldDto>>);
    default com.seeyon.boot.transport.SingleResponse<java.lang.Integer> getMaxOrderNumber(com.seeyon.boot.transport.SingleRequest<com.seeyon.bpm.dto.BpmNodePermissionMaxOrderNumQueryDto>);
```

### `BpmTemplateManageAppService`（11 方法）

`com.seeyon.bpm.api.common.BpmTemplateManageAppService`

```java
    com.seeyon.boot.transport.SingleResponse<java.lang.Void> grayAuthTemplate(com.seeyon.boot.transport.SingleRequest<com.seeyon.bpm.dto.BpmGrayUpdateDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Void> closeLowerVersionGrayAndStarted(com.seeyon.boot.transport.SingleRequest<java.util.List<com.seeyon.bpm.dto.BpmAppInfoDto>>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Void> startByAppName(com.seeyon.boot.transport.SingleRequest<com.seeyon.bpm.dto.BpmAppInfoDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.bpm.dto.BpmTemplateDto> selectFormalAuthTemplateList(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.bpm.dto.BpmTemplateDto> selectFormalAuthTemplateListByQueryDto(com.seeyon.boot.transport.SingleRequest<com.seeyon.bpm.dto.FormalAuthTemplateQueryDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.bpm.dto.BpmTemplateDto> selectGrayAuthTemplateList(com.seeyon.boot.transport.SingleRequest<java.lang.String>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Void> updateAuth(com.seeyon.boot.transport.SingleRequest<com.seeyon.bpm.dto.BpmBatchAuthDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Void> invalidAppTemplatesByAppGuid(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    default com.seeyon.boot.transport.SingleResponse<java.lang.Void> configNodePermissionScope(com.seeyon.boot.transport.SingleRequest<com.seeyon.bpm.dto.BpmTemplateNodePerScopeDto>);
    default com.seeyon.boot.transport.SingleResponse<java.lang.Void> framePublish(com.seeyon.boot.transport.SingleRequest<java.lang.String>);
    default com.seeyon.boot.transport.SingleResponse<java.lang.Void> clearDefaultFrameCache(com.seeyon.boot.transport.SingleRequest<java.lang.String>);
```

### `BpmUdcApiService`（10 方法）

`com.seeyon.bpm.api.udc.BpmUdcApiService`

```java
    com.seeyon.boot.transport.SingleResponse<com.seeyon.bpm.dto.approval.BpmApiSendApiResponseDto> sendForUdc(com.seeyon.boot.transport.SingleRequest<com.seeyon.bpm.dto.approval.BpmSendUdcDto>);
    default com.seeyon.boot.transport.SingleResponse<com.seeyon.bpm.dto.approval.BpmSaveDraftUdcResponseDto> saveDraft(com.seeyon.boot.transport.SingleRequest<com.seeyon.bpm.dto.approval.BpmSaveDraftUdcDto>);
    default com.seeyon.boot.transport.ListResponse<com.seeyon.bpm.dto.approval.BpmTriggerFlowUdcResponseDto> triggerFlowForUdc(com.seeyon.boot.transport.SingleRequest<java.util.List<com.seeyon.bpm.dto.approval.BpmTriggerFlowUdcRequestDto>>);
    default com.seeyon.boot.transport.SingleResponse<com.seeyon.bpm.dto.approval.BpmPrefixForUdcResponseDto> prefixForUdc(com.seeyon.boot.transport.SingleRequest<com.seeyon.bpm.dto.BpmPrefixForUdcDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Void> repealForUdc(com.seeyon.boot.transport.SingleRequest<com.seeyon.bpm.dto.approval.BpmOperationRepealUdcDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.bpm.dto.CommonResultDto> stopForUdc(com.seeyon.boot.transport.SingleRequest<com.seeyon.bpm.dto.BpmStopDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Void> deleteCaseByIdForUdc(com.seeyon.boot.transport.SingleRequest<java.lang.Long>, com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    default com.seeyon.boot.transport.ListResponse<com.seeyon.bpm.dto.approval.BpmNodePermissionResponseDto> getNodePermissionOperation(com.seeyon.boot.transport.SingleRequest<com.seeyon.bpm.dto.approval.BpmNodePermissionRequestDto>);
    default com.seeyon.boot.transport.SingleResponse<com.seeyon.bpm.dto.BpmNodePermission4PageDto> getNodePermission(com.seeyon.boot.transport.SingleRequest<com.seeyon.bpm.dto.approval.BpmNodePermissionRequestDto>);
    default com.seeyon.boot.transport.SingleResponse<java.lang.Void> asyncTriggerFlowForUdc(com.seeyon.boot.transport.SingleRequest<com.seeyon.bpm.dto.approval.BpmAsyncTriggerFlowUdcRequestDto>);
```

### `BpmApiDetectionService`（9 方法）

`com.seeyon.bpm.api.udc.BpmApiDetectionService`

```java
    com.seeyon.boot.transport.ListResponse<com.seeyon.bpm.dto.BpmConsistenceDetectionDto> detectionForAttributeDelete(com.seeyon.boot.transport.SingleRequest<com.seeyon.bpm.dto.detection.DetectionAttrDeleteRequestDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.bpm.dto.BpmConsistenceDetectionDto> detectionForAttributeUpdate(com.seeyon.boot.transport.SingleRequest<com.seeyon.bpm.dto.detection.DetectionAttrUpdateRequestDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.bpm.dto.BpmConsistenceDetectionDto> detectionForCtpEnumDelete(com.seeyon.boot.transport.SingleRequest<com.seeyon.bpm.dto.detection.DetectionCtpEnumDeleteRequestDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Void> cascadeHandleAffectedForEntity(com.seeyon.boot.transport.SingleRequest<com.seeyon.bpm.dto.BpmDetectionEntityDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Void> cascadeHandleAffectedForAttr(com.seeyon.boot.transport.SingleRequest<com.seeyon.bpm.dto.detection.DetectionAttrUpdateDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.bpm.dto.BpmConsistenceDetectionDto> detectionForEntityDelete(com.seeyon.boot.transport.SingleRequest<com.seeyon.bpm.dto.detection.DetectionEntityDeleteRequestDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.bpm.dto.BpmConsistenceDetectionDto> detectionForPageDelete(com.seeyon.boot.transport.SingleRequest<com.seeyon.bpm.dto.detection.DetectionPageDeleteRequestDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.bpm.dto.BpmConsistenceDetectionDto> detectionForPageUpdate(com.seeyon.boot.transport.SingleRequest<com.seeyon.bpm.dto.detection.DetectionPageUpdateRequestDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.bpm.dto.BpmConsistenceDetectionDto> detection(com.seeyon.boot.transport.SingleRequest<com.seeyon.bpm.dto.detection.DetectionFullInfoRequestDto>);
```

### `ActivityBehavior`（8 方法） extends Comparable

`com.seeyon.bpm.api.ext.activity.ActivityBehavior`

```java
    default int order();
    java.lang.String getConfigId();
    boolean preMatch(com.seeyon.bpm.api.ext.activity.BpmSupportOperation, com.seeyon.bpm.api.ext.activity.ActivityBehaviorChain);
    boolean onActivityReady(com.seeyon.bpm.api.ext.activity.BpmSupportOperation, com.seeyon.bpm.api.ext.activity.ActivityBehaviorChain);
    boolean onActivityFinish(com.seeyon.bpm.api.ext.activity.BpmSupportOperation, com.seeyon.bpm.api.ext.activity.ActivityBehaviorChain);
    boolean onActivityCanceled(com.seeyon.bpm.api.ext.activity.BpmSupportOperation, com.seeyon.bpm.api.ext.activity.ActivityBehaviorChain);
    boolean validateActivityAction(com.seeyon.bpm.api.ext.activity.BpmSupportOperation, com.seeyon.bpm.api.ext.activity.ActivityBehaviorChain);
    default int compareTo(java.lang.Object);
```

### `BpmApiParamAppService`（8 方法）

`com.seeyon.bpm.api.udc.BpmApiParamAppService`

```java
    com.seeyon.boot.transport.SingleResponse<java.lang.Void> saveParamSchema(com.seeyon.boot.transport.SingleRequest<com.seeyon.bpm.dto.BpmParameterDefineDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Void> saveParamData(com.seeyon.boot.transport.SingleRequest<com.seeyon.bpm.dto.BpmParameterDataDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.bpm.dto.BpmParameterSettingDto> loadParamSchema(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.bpm.dto.BpmDataTypeDto> loadParamTypes(com.seeyon.boot.transport.SingleRequest<java.lang.Void>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.bpm.dto.BpmParameterSettingDto> loadParamSchemaByOrigin(com.seeyon.boot.transport.SingleRequest<java.lang.String>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Void> deleteSettingByIds(com.seeyon.boot.transport.SingleRequest<java.util.List<java.lang.Long>>);
    default com.seeyon.boot.transport.ListResponse<com.seeyon.bpm.dto.BpmParameterSettingDto> selectParameterUsedByTemplateId(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    default com.seeyon.boot.transport.ListResponse<java.lang.String> selectUsedParameterPathName(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
```

### `BpmOpinionAppService`（7 方法）

`com.seeyon.bpm.api.common.BpmOpinionAppService`

```java
    com.seeyon.boot.transport.ListResponse<com.seeyon.bpm.dto.opinion.BpmOpinionOpenApiNodeResponseDto> selectOpinionGroupByActivityNodeWithObjectId(com.seeyon.boot.transport.PageDtoRequest<com.seeyon.bpm.dto.opinion.BpmOpinionRequestDto>);
    default com.seeyon.boot.transport.SingleResponse<java.lang.Integer> createBatch(com.seeyon.boot.transport.SingleRequest<java.util.List<com.seeyon.bpm.dto.opinion.BpmInputOpinionDto>>);
    default com.seeyon.boot.transport.SingleResponse<java.lang.Integer> create(com.seeyon.boot.transport.SingleRequest<com.seeyon.bpm.dto.opinion.BpmOpinionDataDto>);
    default com.seeyon.boot.transport.SingleResponse<java.lang.Integer> createBatchOpinion(com.seeyon.boot.transport.SingleRequest<java.util.List<com.seeyon.bpm.dto.opinion.BpmOpinionDataDto>>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> deleteOpinion(com.seeyon.boot.transport.SingleRequest<com.seeyon.bpm.dto.opinion.BpmDeleteOpinionDto>);
    default com.seeyon.boot.transport.SingleResponse<java.lang.Void> updateOpinion(com.seeyon.boot.transport.SingleRequest<com.seeyon.bpm.dto.opinion.BpmOpinionUpdateDto>);
    default com.seeyon.boot.transport.SingleResponse<java.lang.Void> adminDeleteOpinion(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
```

### `BpmProcessLogAppService`（7 方法）

`com.seeyon.bpm.api.common.BpmProcessLogAppService`

```java
    com.seeyon.boot.transport.SingleResponse<java.lang.Long> create(com.seeyon.boot.transport.SingleRequest<com.seeyon.bpm.dto.BpmProcessLogDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Integer> createBatch(com.seeyon.boot.transport.SingleRequest<java.util.List<com.seeyon.bpm.dto.BpmProcessLogDto>>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.bpm.dto.BpmProcessLogDto> selectLogList(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    default com.seeyon.boot.transport.SingleResponse<java.lang.Integer> createBatchProcessLog(com.seeyon.boot.transport.SingleRequest<java.util.List<com.seeyon.bpm.dto.BpmProcessLogDto>>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.bpm.dto.BpmProcessLogDto> selectOriginalI18nLogList(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.bpm.dto.BpmProcessLogDto> selectLogOriginalListByCaseIds(com.seeyon.boot.transport.SingleRequest<com.seeyon.bpm.dto.SearchProcessLogInfoDto>);
    default com.seeyon.boot.transport.PageResponse<com.seeyon.bpm.dto.BpmProcessLogDto> selectPageByConditions(com.seeyon.boot.transport.PageRequest);
```

### `BpmApiTransportAppService`（7 方法）

`com.seeyon.bpm.api.udc.BpmApiTransportAppService`

```java
    com.seeyon.boot.transport.SingleResponse<java.lang.Void> saveAs(com.seeyon.boot.transport.SingleRequest<com.seeyon.bpm.dto.transport.BpmSaveAsDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.bpm.dto.transport.BpmExportInitDataDto> getApplicationInitData(com.seeyon.boot.transport.SingleRequest<com.seeyon.bpm.dto.transport.BpmInitParamDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.String> getApplicationInitDataAsync(com.seeyon.boot.transport.SingleRequest<com.seeyon.bpm.dto.transport.BpmInitParamDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.String> exportTemplateInfo(com.seeyon.boot.transport.SingleRequest<com.seeyon.bpm.dto.transport.BpmInitDataDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Void> importTemplateInfo(com.seeyon.boot.transport.SingleRequest<com.seeyon.bpm.dto.BpmImportDto>);
    default com.seeyon.boot.transport.ListResponse<java.lang.String> selectUsedConnectorByAppName(com.seeyon.boot.transport.SingleRequest<java.lang.String>);
    com.seeyon.boot.transport.SingleResponse<java.lang.String> asyncTransportRequest(com.seeyon.boot.transport.SingleRequest<com.seeyon.bpm.dto.transport.BpmTransportRequestDto>);
```

### `BpmDeployAppService`（6 方法）

`com.seeyon.bpm.api.common.BpmDeployAppService`

```java
    com.seeyon.boot.transport.SingleResponse<com.seeyon.bpm.dto.transport.BpmExportInitDataDto> upgradeBpmTemplateVersion(com.seeyon.boot.transport.SingleRequest<java.lang.String>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.bpm.dto.transport.BpmExportInitDataDto> deployBpmTemplatesIndependent(com.seeyon.boot.transport.SingleRequest<java.lang.String>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Void> afterFormAppDataInit(com.seeyon.boot.transport.SingleRequest<com.seeyon.bpm.dto.transport.BpmInitParamDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.String> upgradeCommon(com.seeyon.boot.transport.SingleRequest<com.seeyon.bpm.dto.UpgradeInfoDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.String> autoDeployStartAndAuth(com.seeyon.boot.transport.SingleRequest<com.seeyon.bpm.dto.BpmAppInfoDto>);
    com.seeyon.boot.transport.ListResponse<java.lang.String> usedFrames(com.seeyon.boot.transport.SingleRequest<com.seeyon.bpm.dto.BpmAppInfoDto>);
```

### `BpmActivityAppService`（4 方法）

`com.seeyon.bpm.api.common.BpmActivityAppService`

```java
    default com.seeyon.boot.transport.ListResponse<com.seeyon.bpm.dto.BpmActivityRunDto> selectAllByCaseId(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    default com.seeyon.boot.transport.ListResponse<com.seeyon.bpm.dto.BpmCaseActivityDto> selectBpmCaseActivityByCaseId(com.seeyon.boot.transport.SingleRequest<com.seeyon.bpm.dto.BpmCaseActivitySearchDto>);
    default com.seeyon.boot.transport.SingleResponse<java.lang.Integer> create(com.seeyon.boot.transport.SingleRequest<com.seeyon.bpm.dto.BpmActivityRunDto>);
    default com.seeyon.boot.transport.SingleResponse<java.lang.Integer> createBatch(com.seeyon.boot.transport.SingleRequest<java.util.List<com.seeyon.bpm.dto.BpmActivityRunDto>>);
```

### `BpmAutoApprovalAppService`（4 方法）

`com.seeyon.bpm.api.common.BpmAutoApprovalAppService`

```java
    com.seeyon.boot.transport.SingleResponse<java.lang.Long> designerCreate(com.seeyon.boot.transport.SingleRequest<com.seeyon.bpm.dto.autoapproval.BpmAutoApprovalCreateDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Boolean> designerUpdate(com.seeyon.boot.transport.SingleRequest<com.seeyon.bpm.dto.autoapproval.BpmAutoApprovalUpdateDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Boolean> designerDelete(com.seeyon.boot.transport.SingleRequest<com.seeyon.bpm.dto.autoapproval.BpmAutoApprovalDeleteDto>);
    com.seeyon.boot.transport.PageResponse<com.seeyon.bpm.dto.autoapproval.BpmAutoApprovalDto> designerSelect(com.seeyon.boot.transport.PageDtoRequest<com.seeyon.bpm.dto.autoapproval.BpmAutoApprovalSelectDto>);
```

### `BpmNodeAppService`（4 方法）

`com.seeyon.bpm.api.common.BpmNodeAppService`

```java
    default com.seeyon.boot.transport.PageResponse<com.seeyon.bpm.dto.BpmNodeDto> selectPageByConditions(com.seeyon.boot.transport.PageRequest);
    default com.seeyon.boot.transport.ListResponse<com.seeyon.bpm.dto.BpmNodeDto> selectByTemplateAndActivityType(com.seeyon.boot.transport.SingleRequest<com.seeyon.bpm.dto.BpmNodeSearchDto>);
    default com.seeyon.boot.transport.ListResponse<com.seeyon.bpm.dto.BpmNodeSimpleDto> selectRunningProcessPreNode(com.seeyon.boot.transport.SingleRequest<com.seeyon.bpm.dto.BpmPreNodeSearchDto>);
    default com.seeyon.boot.transport.ListResponse<com.seeyon.bpm.dto.policy.NodeProperties> selectNodePolicy(com.seeyon.boot.transport.SingleRequest<com.seeyon.bpm.dto.policy.NodePolicySearchDto>);
```

### `BpmThirdTemplateSyncAppService`（4 方法）

`com.seeyon.bpm.api.common.BpmThirdTemplateSyncAppService`

```java
    com.seeyon.boot.transport.ListResponse<com.seeyon.bpm.dto.BpmThirdTemplateCreateOrUpdateDto> createBatch(com.seeyon.boot.transport.SingleRequest<java.util.List<com.seeyon.bpm.dto.BpmThirdTemplateCreateOrUpdateDto>>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Void> updateBatch(com.seeyon.boot.transport.SingleRequest<java.util.List<com.seeyon.bpm.dto.BpmThirdTemplateCreateOrUpdateDto>>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Void> createActivityResponsibilities(com.seeyon.boot.transport.SingleRequest<java.util.List<com.seeyon.bpm.dto.BpmActivityResponsibilityDto>>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Void> createTemplateRecent(com.seeyon.boot.transport.SingleRequest<com.seeyon.bpm.dto.BpmTemplateRecentDto>);
```

### `BpmWorkItemAppService`（4 方法）

`com.seeyon.bpm.api.common.BpmWorkItemAppService`

```java
    default com.seeyon.boot.transport.SingleResponse<java.lang.Integer> create(com.seeyon.boot.transport.SingleRequest<com.seeyon.bpm.dto.BpmWorkItemDto>);
    default com.seeyon.boot.transport.SingleResponse<java.lang.Integer> createBatch(com.seeyon.boot.transport.SingleRequest<java.util.List<com.seeyon.bpm.dto.BpmWorkItemDto>>);
    default com.seeyon.boot.transport.SingleResponse<com.seeyon.bpm.dto.BpmWorkItemDto> selectById(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    default com.seeyon.boot.transport.ListResponse<com.seeyon.bpm.dto.BpmWorkItemDto> selectByCaseId(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
```

### `BpmApiPermissionAppService`（3 方法）

`com.seeyon.bpm.api.common.BpmApiPermissionAppService`

```java
    default boolean checkApplicationPermission(com.seeyon.bpm.dto.BpmAppInfoDto);
    default java.util.List<java.lang.Long> getCurrentOrgHierarchicalAppGuid();
    default boolean isProcessFragmentEnabled();
```

### `BpmApplicationOperateLogAppService`（3 方法）

`com.seeyon.bpm.api.common.BpmApplicationOperateLogAppService`

```java
    com.seeyon.boot.transport.SingleResponse<java.lang.Void> saveApplicationOperateLog(com.seeyon.boot.transport.SingleRequest<com.seeyon.bpm.dto.BpmApplicationOperateLogInfoDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.bpm.dto.BpmApplicationOperateLogInfoDto> selectNewestLogInfo(com.seeyon.boot.transport.SingleRequest<com.seeyon.bpm.dto.AppOperateLogQueryDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Void> updateAppLogs(com.seeyon.boot.transport.SingleRequest<java.util.List<com.seeyon.bpm.dto.BpmApplicationOperateLogInfoDto>>);
```

### `BpmSuperviseAppService`（3 方法）

`com.seeyon.bpm.api.common.BpmSuperviseAppService`

```java
    com.seeyon.boot.transport.ListResponse<com.seeyon.bpm.dto.BpmVipSuperviseRunDto> search(com.seeyon.boot.transport.ListRequest);
    com.seeyon.boot.transport.SingleResponse<java.lang.Void> cancelFocus(com.seeyon.boot.transport.SingleRequest<com.seeyon.bpm.dto.SuperviseCancelFocusDto>);
    com.seeyon.boot.transport.SingleResponse<com.seeyon.bpm.dto.CommonResultDto> skip(com.seeyon.boot.transport.SingleRequest<com.seeyon.bpm.dto.operation.openapi.BpmSkipDto>);
```

### `ActivityBehaviorFactory`（3 方法）

`com.seeyon.bpm.api.ext.activity.ActivityBehaviorFactory`

```java
    java.util.List<com.seeyon.bpm.api.ext.activity.ActivityBehavior> getActivityBehaviors(java.lang.String);
    java.lang.String getActivityConfiguration(java.lang.String);
    java.util.Set<java.lang.String> supportActivities();
```

### `BpmApiSplitImportAppService`（3 方法）

`com.seeyon.bpm.api.udc.BpmApiSplitImportAppService`

```java
    com.seeyon.boot.transport.ListResponse<com.seeyon.bpm.dto.splitimport.BpmTemplateBaseDto> selectTemplateByAppName(com.seeyon.boot.transport.SingleRequest<java.lang.String>);
    com.seeyon.boot.transport.SingleResponse<java.lang.String> prepareApp(com.seeyon.boot.transport.SingleRequest<com.seeyon.bpm.dto.splitimport.BpmSplitPrepareDto>);
    com.seeyon.boot.transport.SingleResponse<java.lang.Void> splitImport(com.seeyon.boot.transport.SingleRequest<java.lang.String>);
```

### `BpmActionAppService`（2 方法）

`com.seeyon.bpm.api.common.BpmActionAppService`

```java
    default com.seeyon.boot.transport.SingleResponse<com.seeyon.bpm.dto.operation.openapi.BpmSubmitResultDto> activitySubmit(com.seeyon.boot.transport.SingleRequest<com.seeyon.bpm.dto.activity.BpmActivitySubmitDto>);
    default com.seeyon.boot.transport.SingleResponse<java.lang.Void> activityStepBack(com.seeyon.boot.transport.SingleRequest<com.seeyon.bpm.dto.activity.BpmActivityTakeBackDto>);
```

### `BpmCaseLogAppService`（2 方法）

`com.seeyon.bpm.api.common.BpmCaseLogAppService`

```java
    com.seeyon.boot.transport.ListResponse<com.seeyon.bpm.dto.caselog.BpmCaseLogDto> selectByCaseId(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.bpm.dto.caselog.BpmCaseLogDto> selectByDto(com.seeyon.boot.transport.SingleRequest<com.seeyon.bpm.dto.caselog.BpmCaseLogSelectDto>);
```

### `BpmNodePermissionOperationAppService`（2 方法）

`com.seeyon.bpm.api.common.BpmNodePermissionOperationAppService`

```java
    com.seeyon.boot.transport.SingleResponse<com.seeyon.bpm.dto.nodepermission.BpmNodePermissionFilterResponseDto> getNodePermissionOperation(com.seeyon.boot.transport.SingleRequest<com.seeyon.bpm.dto.nodepermission.BpmNodePermissionOperationRequestDto>);
    com.seeyon.boot.transport.ListResponse<com.seeyon.bpm.dto.approval.BpmNodePermissionOperationSimpleDto> selectOperationSimpleByPermissionIds(com.seeyon.boot.transport.SingleRequest<java.util.List<java.lang.Long>>);
```

### `BpmNormalAppMultiVersionAppService`（2 方法）

`com.seeyon.bpm.api.common.BpmNormalAppMultiVersionAppService`

```java
    com.seeyon.boot.transport.ListResponse<com.seeyon.bpm.dto.CurrentHighestVersionResponseDto> selectCurrentHighestVersionBatch(com.seeyon.boot.transport.SingleRequest<com.seeyon.bpm.dto.CurrentHighestVersionRequestDto>);
    default com.seeyon.boot.transport.SingleResponse<java.lang.Void> updateNormalApplicationToSpecifiedInstitution(com.seeyon.boot.transport.SingleRequest<com.seeyon.bpm.dto.BpmUpdateApplicationToSpecifiedInstitutionDto>);
```

### `BpmProcessTrackAppService`（2 方法）

`com.seeyon.bpm.api.common.BpmProcessTrackAppService`

```java
    com.seeyon.boot.transport.PageResponse<com.seeyon.bpm.dto.BpmProcessTrackResDto> selectProcessTrackList(com.seeyon.boot.transport.SingleRequest<com.seeyon.bpm.dto.BpmProcessTrackReqDto>);
    default com.seeyon.boot.transport.SingleResponse<java.lang.Integer> countAttentionForBadge(com.seeyon.boot.transport.SingleRequest<com.seeyon.bpm.dto.BpmProcessTrackReqDto>);
```

### `ActivityBehaviorChain`（2 方法）

`com.seeyon.bpm.api.ext.activity.ActivityBehaviorChain`

```java
    <T> T doBehaviorChain(com.seeyon.bpm.api.ext.activity.BpmSupportOperation, java.lang.Class<T>);
    boolean hasNext();
```

### `BpmApiSimulationAppService`（2 方法）

`com.seeyon.bpm.simulation.api.BpmApiSimulationAppService`

```java
    com.seeyon.boot.transport.SingleResponse<com.seeyon.bpm.simulation.dto.ProcessPredictionResultDto> selectProcessPredictionResult(com.seeyon.boot.transport.SingleRequest<com.seeyon.bpm.simulation.dto.ProcessPredictionDto>);
    default com.seeyon.boot.transport.SingleResponse<java.lang.String> selectSimulationLinkByGuid(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
```

### `BpmDetailViewSpi`（2 方法）

`com.seeyon.bpm.spi.BpmDetailViewSpi`

```java
    com.seeyon.bpm.spi.dto.detail.BpmForwardResp forwardAffair(com.seeyon.bpm.spi.dto.detail.BpmForwardReq);
    com.seeyon.bpm.spi.dto.detail.BpmNodePermissionMergeResp mergeNodePermission(com.seeyon.bpm.spi.dto.detail.BpmNodePermissionMergeReq);
```

### `BpmApiProcessAppService`（1 方法）

`com.seeyon.bpm.api.common.BpmApiProcessAppService`

```java
    com.seeyon.boot.transport.ListResponse<com.seeyon.bpm.dto.operation.openapi.BpmDiagramDetailInfoDto> selectDiagramDetailByTemplateCodeAndVersion(com.seeyon.boot.transport.SingleRequest<com.seeyon.bpm.dto.operation.openapi.BpmDiagramDetailRequestDto>);
```

### `BpmAppOrgReplaceService`（1 方法）

`com.seeyon.bpm.api.common.BpmAppOrgReplaceService`

```java
    com.seeyon.boot.transport.SingleResponse<java.lang.Void> replace(com.seeyon.boot.transport.SingleRequest<com.seeyon.bpm.dto.BpmAppOrgReplaceDto>);
```

### `BpmCoMiAppService`（1 方法）

`com.seeyon.bpm.api.common.BpmCoMiAppService`

```java
    default com.seeyon.boot.transport.SingleResponse<com.seeyon.bpm.dto.comi.CoMiDetailInfoDto> getDetailInfo(com.seeyon.boot.transport.SingleRequest<java.lang.Long>);
```

### `BpmDetailAppService`（1 方法）

`com.seeyon.bpm.api.common.BpmDetailAppService`

```java
    com.seeyon.boot.transport.SingleResponse<com.seeyon.bpm.dto.edoc.BpmEdocDetailResponseDto> selectDetail(com.seeyon.boot.transport.SingleRequest<com.seeyon.bpm.dto.edoc.BpmEdocSummaryDetailParamDto>);
```

### `BpmUpgrade51To52AppService`（1 方法）

`com.seeyon.bpm.api.upgrade.BpmUpgrade51To52AppService`

```java
    com.seeyon.boot.transport.SingleResponse<java.lang.Void> upgradeExtensionPlan(com.seeyon.boot.transport.SingleRequest<java.util.List<com.seeyon.bpm.dto.upgrade.UdcExtensionPlanRequestDto>>);
```

### `BpmOperationSpi`（1 方法）

`com.seeyon.bpm.spi.BpmOperationSpi`

```java
    com.seeyon.bpm.spi.dto.operation.BpmCheckNodePermissionResp checkNodePermission(com.seeyon.bpm.spi.dto.operation.BpmCheckNodePermissionReq);
```

### `BpmForwardDataSubscribe`（1 方法）

`com.seeyon.bpm.subscribe.BpmForwardDataSubscribe`

```java
    com.seeyon.boot.transport.SingleResponse<com.seeyon.bpm.subscribe.dto.BpmForwardDataHandlerResponseDto> handler(com.seeyon.boot.transport.SingleRequest<com.seeyon.bpm.subscribe.dto.BpmForwardDataHandlerReqDto>);
```

## 二、关键类（24）

### `BpmTemplateDto`（155 方法）

`com.seeyon.bpm.dto.BpmTemplateDto`

```java
    void setCanDeleteTemplateNode(java.lang.Boolean);
    boolean isInterfaceWorkflow();
    java.lang.Long getId();
    java.lang.String getAppName();
    java.lang.String getRootEntityName();
    java.lang.Long getRootEntityId();
    java.lang.String getPageUrl();
    java.lang.String getMobilePageUrl();
    java.lang.String getDonePageUrl();
    java.lang.String getDoneMobilePageUrl();
    java.lang.String getHelpPage();
    java.lang.Long getPageGroupId();
    java.lang.Long getApplicationId();
    java.lang.Long getAppId();
    java.lang.String getApplicationName();
    java.lang.String getDynamicTitle();
    com.seeyon.bpm.enums.TemplateTypeEnum getTemplateType();
    java.lang.String getCode();
    java.lang.String getCreateAccountId();
    java.lang.Long getCreateUserId();
    java.util.Date getEffectTime();
    java.util.Date getInvalidTime();
    java.lang.Integer getTemplateVersion();
    java.lang.Long getUpdateUserId();
    java.lang.String getSubject();
    java.lang.Long getCategoryId();
    com.seeyon.bpm.enums.TemplateStateEnum getState();
    java.lang.String getDescription();
    java.lang.String getDesStorageKey();
    java.lang.Long getVersionGroupId();
    java.lang.String getAuthorized();
    java.util.List<java.lang.String> getTagNames();
    java.lang.Boolean getForward();
    java.lang.Boolean getOutsideProcess();
    com.seeyon.bpm.enums.BpmTemplateDesignState getDesignState();
    com.seeyon.bpm.enums.BpmTemplateSourceType getSourceType();
    java.lang.String getLiablePersons();
    java.lang.String getLiableOrganizations();
    java.lang.String getContactPersons();
    com.seeyon.bpm.dto.BpmTemplateReferUserDto getCreateUser();
    com.seeyon.bpm.dto.BpmTemplateReferOrgUnitDto getCreateAccount();
    java.lang.Integer getProcessVersion();
    java.lang.Boolean getEnable();
    java.lang.Boolean getAllowedSend();
    java.lang.String getTags();
    java.lang.Boolean getPublished();
    java.lang.String getShortName();
    java.lang.String getDocStorageKey();
    java.lang.String getSubApp();
    java.lang.String getPageParameter();
    java.lang.String getMobilePageParameter();
    java.lang.String getPcSubPage();
    java.lang.String getMobileSubPage();
    java.lang.String getApplicationVersion();
    java.lang.Boolean getSingleSign();
    java.lang.Long getPluginId();
    java.lang.Long getNodePermissionId();
    java.lang.Long getEntityGuid();
    java.lang.Long getFormPermissionId();
    java.lang.Boolean getAllowReliveAfterFinish();
    java.lang.Boolean getAllowReliveAfterStop();
    java.lang.String getNodePermScope();
    java.lang.String getSaveFormDataInterface();
    java.lang.Boolean getGray();
    com.seeyon.bpm.enums.TemplateOvertimeComputeEnum getOvertimeCompute();
    com.seeyon.bpm.enums.BpmFormPermissionCodeEnum getPermissionCode();
    java.lang.Boolean getFreeFlow();
    java.lang.String getDraftVersion();
    java.lang.Boolean getCanDeleteTemplateNode();
    com.seeyon.bpm.enums.BpmTemplateEvaluationTypeEnum getEvaluationType();
    com.seeyon.bpm.enums.BpmTemplateLevelEnum getTemplateLevel();
    java.lang.String getInterfaceInfo();
    java.lang.String getAppBusinessData();
    com.seeyon.bpm.enums.DynamicTitleGenerationMethodEnum getDynamicTitleGenerationMethod();
    java.lang.String getPostApprovalSetting();
    java.lang.Boolean getAllowHierarchicalControl();
    java.lang.Boolean getCanDisableHierarchicalControl();
    java.lang.Boolean getAddNodeImmediate();
    java.lang.String getExtensionPlan();
    void setId(java.lang.Long);
    void setAppName(java.lang.String);
    void setRootEntityName(java.lang.String);
    void setRootEntityId(java.lang.Long);
    void setPageUrl(java.lang.String);
    void setMobilePageUrl(java.lang.String);
    void setDonePageUrl(java.lang.String);
    void setDoneMobilePageUrl(java.lang.String);
    void setHelpPage(java.lang.String);
    void setPageGroupId(java.lang.Long);
    void setApplicationId(java.lang.Long);
    void setAppId(java.lang.Long);
    void setApplicationName(java.lang.String);
    void setDynamicTitle(java.lang.String);
    void setTemplateType(com.seeyon.bpm.enums.TemplateTypeEnum);
    void setCode(java.lang.String);
    void setCreateAccountId(java.lang.String);
    void setCreateUserId(java.lang.Long);
    void setEffectTime(java.util.Date);
    void setInvalidTime(java.util.Date);
    void setTemplateVersion(java.lang.Integer);
    void setUpdateUserId(java.lang.Long);
    void setSubject(java.lang.String);
    void setCategoryId(java.lang.Long);
    void setState(com.seeyon.bpm.enums.TemplateStateEnum);
    void setDescription(java.lang.String);
    void setDesStorageKey(java.lang.String);
    void setVersionGroupId(java.lang.Long);
    void setAuthorized(java.lang.String);
    void setTagNames(java.util.List<java.lang.String>);
    void setForward(java.lang.Boolean);
    void setOutsideProcess(java.lang.Boolean);
    void setDesignState(com.seeyon.bpm.enums.BpmTemplateDesignState);
    void setSourceType(com.seeyon.bpm.enums.BpmTemplateSourceType);
    void setLiablePersons(java.lang.String);
    void setLiableOrganizations(java.lang.String);
    void setContactPersons(java.lang.String);
    void setCreateUser(com.seeyon.bpm.dto.BpmTemplateReferUserDto);
    void setCreateAccount(com.seeyon.bpm.dto.BpmTemplateReferOrgUnitDto);
    void setProcessVersion(java.lang.Integer);
    void setEnable(java.lang.Boolean);
    void setAllowedSend(java.lang.Boolean);
    void setTags(java.lang.String);
    void setPublished(java.lang.Boolean);
    void setShortName(java.lang.String);
    void setDocStorageKey(java.lang.String);
    void setSubApp(java.lang.String);
    void setPageParameter(java.lang.String);
    void setMobilePageParameter(java.lang.String);
    void setPcSubPage(java.lang.String);
    void setMobileSubPage(java.lang.String);
    void setApplicationVersion(java.lang.String);
    void setSingleSign(java.lang.Boolean);
    void setPluginId(java.lang.Long);
    void setNodePermissionId(java.lang.Long);
    void setEntityGuid(java.lang.Long);
    void setFormPermissionId(java.lang.Long);
    void setAllowReliveAfterFinish(java.lang.Boolean);
    void setAllowReliveAfterStop(java.lang.Boolean);
    void setNodePermScope(java.lang.String);
    void setSaveFormDataInterface(java.lang.String);
    void setGray(java.lang.Boolean);
    void setOvertimeCompute(com.seeyon.bpm.enums.TemplateOvertimeComputeEnum);
    void setPermissionCode(com.seeyon.bpm.enums.BpmFormPermissionCodeEnum);
    void setFreeFlow(java.lang.Boolean);
    void setDraftVersion(java.lang.String);
    void setEvaluationType(com.seeyon.bpm.enums.BpmTemplateEvaluationTypeEnum);
    void setTemplateLevel(com.seeyon.bpm.enums.BpmTemplateLevelEnum);
    void setInterfaceInfo(java.lang.String);
    void setAppBusinessData(java.lang.String);
    void setDynamicTitleGenerationMethod(com.seeyon.bpm.enums.DynamicTitleGenerationMethodEnum);
    void setPostApprovalSetting(java.lang.String);
    void setAllowHierarchicalControl(java.lang.Boolean);
    void setCanDisableHierarchicalControl(java.lang.Boolean);
    void setAddNodeImmediate(java.lang.Boolean);
    void setExtensionPlan(java.lang.String);
```

### `BpmThirdTemplateCreateOrUpdateDto`（38 方法）

`com.seeyon.bpm.dto.BpmThirdTemplateCreateOrUpdateDto`

```java
    java.lang.Long getId();
    java.lang.Long getGuid();
    com.seeyon.bpm.enums.ThirdTemplateTypeEnum getSourceType();
    java.lang.String getSubject();
    java.lang.String getCode();
    java.lang.String getPageUrl();
    java.lang.String getMobilePageUrl();
    com.seeyon.bpm.enums.TemplateStateEnum getState();
    java.lang.String getAuthorized();
    java.lang.String getFormPicStorageKey();
    java.lang.String getDiagramPicStorageKey();
    java.lang.Long getCategoryId();
    java.lang.String getTags();
    java.lang.String getDescription();
    java.lang.Long getCreateAccountId();
    java.lang.String getDocStorageKey();
    java.lang.String getDesStorageKey();
    java.lang.String getInterfaceInfo();
    java.lang.Boolean getIsEnable();
    void setId(java.lang.Long);
    void setGuid(java.lang.Long);
    void setSourceType(com.seeyon.bpm.enums.ThirdTemplateTypeEnum);
    void setSubject(java.lang.String);
    void setCode(java.lang.String);
    void setPageUrl(java.lang.String);
    void setMobilePageUrl(java.lang.String);
    void setState(com.seeyon.bpm.enums.TemplateStateEnum);
    void setAuthorized(java.lang.String);
    void setFormPicStorageKey(java.lang.String);
    void setDiagramPicStorageKey(java.lang.String);
    void setCategoryId(java.lang.Long);
    void setTags(java.lang.String);
    void setDescription(java.lang.String);
    void setCreateAccountId(java.lang.Long);
    void setDocStorageKey(java.lang.String);
    void setDesStorageKey(java.lang.String);
    void setInterfaceInfo(java.lang.String);
    void setIsEnable(java.lang.Boolean);
```

### `BpmTemplateInfoDto`（34 方法）

`com.seeyon.bpm.dto.BpmTemplateInfoDto`

```java
    java.lang.Long getId();
    java.lang.Long getGuid();
    java.lang.String getAppName();
    java.lang.String getRootEntityName();
    java.lang.Long getApplicationId();
    java.lang.String getApplicationName();
    java.lang.String getCode();
    java.lang.Long getCreateAccountId();
    java.lang.Long getCreateUserId();
    java.util.Date getEffectTime();
    java.util.Date getInvalidTime();
    java.lang.Boolean getHasEffected();
    java.lang.Integer getProcessVersion();
    java.lang.String getSubject();
    com.seeyon.bpm.enums.TemplateStateEnum getState();
    java.lang.String getDescription();
    java.lang.String getAuthorized();
    void setId(java.lang.Long);
    void setGuid(java.lang.Long);
    void setAppName(java.lang.String);
    void setRootEntityName(java.lang.String);
    void setApplicationId(java.lang.Long);
    void setApplicationName(java.lang.String);
    void setCode(java.lang.String);
    void setCreateAccountId(java.lang.Long);
    void setCreateUserId(java.lang.Long);
    void setEffectTime(java.util.Date);
    void setInvalidTime(java.util.Date);
    void setHasEffected(java.lang.Boolean);
    void setProcessVersion(java.lang.Integer);
    void setSubject(java.lang.String);
    void setState(com.seeyon.bpm.enums.TemplateStateEnum);
    void setDescription(java.lang.String);
    void setAuthorized(java.lang.String);
```

### `UserTemplateDto`（24 方法）

`com.seeyon.bpm.dto.formtemplate.UserTemplateDto`

```java
    java.lang.Long getTemplateId();
    java.lang.String getTemplateCode();
    java.lang.String getSubject();
    java.lang.Long getCreateAccountId();
    java.lang.String getCreateAccountName();
    java.lang.Long getCreateUserId();
    java.lang.String getCreateUserName();
    java.lang.Long getCategoryId();
    java.util.Date getCreateTime();
    java.lang.String getDescription();
    java.lang.String getUrl();
    java.lang.String getMobileUrl();
    void setTemplateId(java.lang.Long);
    void setTemplateCode(java.lang.String);
    void setSubject(java.lang.String);
    void setCreateAccountId(java.lang.Long);
    void setCreateAccountName(java.lang.String);
    void setCreateUserId(java.lang.Long);
    void setCreateUserName(java.lang.String);
    void setCategoryId(java.lang.Long);
    void setCreateTime(java.util.Date);
    void setDescription(java.lang.String);
    void setUrl(java.lang.String);
    void setMobileUrl(java.lang.String);
```

### `BpmTemplateAuthEvent`（22 方法）

`com.seeyon.bpm.dto.message.event.BpmTemplateAuthEvent`

```java
    java.lang.Long getTemplateId();
    java.lang.Long getTemplateGuid();
    java.lang.String getTemplateCode();
    com.seeyon.bpm.enums.TemplateStateEnum getState();
    java.lang.String getApplicationName();
    java.lang.String getSubject();
    java.util.Date getEffectTime();
    java.util.Date getInvalidTime();
    java.lang.String getAuthorized();
    java.lang.String getAppName();
    java.lang.Long getApplicationId();
    void setTemplateId(java.lang.Long);
    void setTemplateGuid(java.lang.Long);
    void setTemplateCode(java.lang.String);
    void setState(com.seeyon.bpm.enums.TemplateStateEnum);
    void setApplicationName(java.lang.String);
    void setSubject(java.lang.String);
    void setEffectTime(java.util.Date);
    void setInvalidTime(java.util.Date);
    void setAuthorized(java.lang.String);
    void setAppName(java.lang.String);
    void setApplicationId(java.lang.Long);
```

### `BpmTemplateSimpleDto`（20 方法）

`com.seeyon.bpm.dto.BpmTemplateSimpleDto`

```java
    java.lang.String getTitle();
    java.lang.Long getId();
    java.lang.Boolean getFreeCollaboration();
    java.lang.Boolean getThirdTemplate();
    java.lang.String getUrl();
    java.lang.String getMobileUrl();
    java.lang.String getDoneUrl();
    java.lang.String getDoneMobileUrl();
    int getT();
    java.lang.Long getPti();
    void setTitle(java.lang.String);
    void setId(java.lang.Long);
    void setFreeCollaboration(java.lang.Boolean);
    void setThirdTemplate(java.lang.Boolean);
    void setUrl(java.lang.String);
    void setMobileUrl(java.lang.String);
    void setDoneUrl(java.lang.String);
    void setDoneMobileUrl(java.lang.String);
    void setT(int);
    void setPti(java.lang.Long);
```

### `BpmAllStartTemplateDto`（18 方法）

`com.seeyon.bpm.dto.BpmAllStartTemplateDto`

```java
    java.util.List<java.lang.Long> getTemplateIds();
    java.lang.String getApplicationName();
    com.seeyon.bpm.enums.BpmTemplateSourceType getTemplateSourceType();
    java.util.Date getEffectTime();
    java.util.Date getInvalidTime();
    java.lang.Boolean getForceStart();
    java.lang.String getAppVersion();
    java.lang.String getCurrentVersion();
    java.lang.Long getOrgId();
    void setTemplateIds(java.util.List<java.lang.Long>);
    void setApplicationName(java.lang.String);
    void setTemplateSourceType(com.seeyon.bpm.enums.BpmTemplateSourceType);
    void setEffectTime(java.util.Date);
    void setInvalidTime(java.util.Date);
    void setForceStart(java.lang.Boolean);
    void setAppVersion(java.lang.String);
    void setCurrentVersion(java.lang.String);
    void setOrgId(java.lang.Long);
```

### `BpmTemplateStartOrStopEvent`（18 方法）

`com.seeyon.bpm.dto.message.event.BpmTemplateStartOrStopEvent`

```java
    java.lang.Long getTemplateId();
    java.lang.Long getTemplateGuid();
    java.lang.String getTemplateCode();
    com.seeyon.bpm.enums.TemplateStateEnum getState();
    java.lang.String getApplicationName();
    java.lang.String getSubject();
    java.util.Date getEffectTime();
    java.util.Date getInvalidTime();
    java.lang.String getAuthorized();
    void setTemplateId(java.lang.Long);
    void setTemplateGuid(java.lang.Long);
    void setTemplateCode(java.lang.String);
    void setState(com.seeyon.bpm.enums.TemplateStateEnum);
    void setApplicationName(java.lang.String);
    void setSubject(java.lang.String);
    void setEffectTime(java.util.Date);
    void setInvalidTime(java.util.Date);
    void setAuthorized(java.lang.String);
```

### `BpmTemplateAppSearchDto`（16 方法）

`com.seeyon.bpm.dto.BpmTemplateAppSearchDto`

```java
    java.lang.String getName();
    java.lang.Long getOrgId();
    java.lang.String getApplicationName();
    com.seeyon.bpm.enums.BpmTemplateDesignState getDesignState();
    com.seeyon.bpm.enums.TemplateStateEnum getState();
    java.lang.String getDraftVersion();
    java.lang.Boolean getEnabled();
    java.lang.String getRootEntityName();
    void setName(java.lang.String);
    void setOrgId(java.lang.Long);
    void setApplicationName(java.lang.String);
    void setDesignState(com.seeyon.bpm.enums.BpmTemplateDesignState);
    void setState(com.seeyon.bpm.enums.TemplateStateEnum);
    void setDraftVersion(java.lang.String);
    void setEnabled(java.lang.Boolean);
    void setRootEntityName(java.lang.String);
```

### `BpmTemplateParamSearchDto`（16 方法）

`com.seeyon.bpm.dto.BpmTemplateParamSearchDto`

```java
    java.lang.Long getId();
    java.lang.String getAppName();
    com.seeyon.bpm.enums.TemplateTypeEnum getTemplateType();
    java.lang.Long getApplicationId();
    java.lang.String getApplicationName();
    java.lang.String getRootEntityName();
    java.lang.Long getRootEntityId();
    java.lang.Long getFormRecordId();
    void setId(java.lang.Long);
    void setAppName(java.lang.String);
    void setTemplateType(com.seeyon.bpm.enums.TemplateTypeEnum);
    void setApplicationId(java.lang.Long);
    void setApplicationName(java.lang.String);
    void setRootEntityName(java.lang.String);
    void setRootEntityId(java.lang.Long);
    void setFormRecordId(java.lang.Long);
```

### `BpmAllTemplateStartOrStopEvent`（16 方法）

`com.seeyon.bpm.dto.message.event.BpmAllTemplateStartOrStopEvent`

```java
    java.util.List<com.seeyon.bpm.dto.message.event.BpmTemplateBasicInfoDto> getTemplates();
    java.util.List<com.seeyon.bpm.dto.message.event.BpmTemplateBasicInfoDto> getIncrementalTemplates();
    com.seeyon.bpm.enums.TemplateStateEnum getState();
    java.util.Date getEffectTime();
    java.util.Date getInvalidTime();
    java.lang.String getApplicationName();
    java.lang.String getAppVersion();
    java.lang.Long getOrgId();
    void setTemplates(java.util.List<com.seeyon.bpm.dto.message.event.BpmTemplateBasicInfoDto>);
    void setIncrementalTemplates(java.util.List<com.seeyon.bpm.dto.message.event.BpmTemplateBasicInfoDto>);
    void setState(com.seeyon.bpm.enums.TemplateStateEnum);
    void setEffectTime(java.util.Date);
    void setInvalidTime(java.util.Date);
    void setApplicationName(java.lang.String);
    void setAppVersion(java.lang.String);
    void setOrgId(java.lang.Long);
```

### `BpmAppTemplateDto`（14 方法）

`com.seeyon.bpm.dto.BpmAppTemplateDto`

```java
    java.lang.Long getId();
    java.lang.String getSubject();
    java.lang.String getDiagramStorageKey();
    java.lang.Long getFormAppId();
    java.lang.String getStartConditionJson();
    java.lang.String getDiagram();
    java.lang.Long getStartActivityId();
    void setId(java.lang.Long);
    void setSubject(java.lang.String);
    void setDiagramStorageKey(java.lang.String);
    void setFormAppId(java.lang.Long);
    void setStartConditionJson(java.lang.String);
    void setDiagram(java.lang.String);
    void setStartActivityId(java.lang.Long);
```

### `BpmStartTemplateDto`（14 方法）

`com.seeyon.bpm.dto.BpmStartTemplateDto`

```java
    java.lang.Long getTemplateId();
    java.lang.String getApplicationName();
    java.util.Date getEffectTime();
    java.util.Date getInvalidTime();
    java.lang.Boolean getForceStart();
    java.lang.String getAppName();
    java.lang.String getAppVersion();
    void setTemplateId(java.lang.Long);
    void setApplicationName(java.lang.String);
    void setEffectTime(java.util.Date);
    void setInvalidTime(java.util.Date);
    void setForceStart(java.lang.Boolean);
    void setAppName(java.lang.String);
    void setAppVersion(java.lang.String);
```

### `BpmTemplateReferUserDto`（12 方法）

`com.seeyon.bpm.dto.BpmTemplateReferUserDto`

```java
    java.lang.Long getId();
    java.lang.String getName();
    java.lang.String getCode();
    java.lang.String getPhoneNumber();
    java.lang.String getOfficeNumber();
    java.lang.String getEmail();
    void setId(java.lang.Long);
    void setName(java.lang.String);
    void setCode(java.lang.String);
    void setPhoneNumber(java.lang.String);
    void setOfficeNumber(java.lang.String);
    void setEmail(java.lang.String);
```

### `BpmTemplateBasicInfoDto`（10 方法）

`com.seeyon.bpm.dto.message.event.BpmTemplateBasicInfoDto`

```java
    java.lang.Long getTemplateId();
    java.lang.Long getTemplateGuid();
    java.lang.String getTemplateCode();
    java.lang.String getSubject();
    com.seeyon.bpm.enums.TemplateStateEnum getTemplateState();
    void setTemplateId(java.lang.Long);
    void setTemplateGuid(java.lang.Long);
    void setTemplateCode(java.lang.String);
    void setSubject(java.lang.String);
    void setTemplateState(com.seeyon.bpm.enums.TemplateStateEnum);
```

### `BpmTemplateBaseDto`（10 方法）

`com.seeyon.bpm.dto.splitimport.BpmTemplateBaseDto`

```java
    java.lang.Long getId();
    java.lang.Long getGuid();
    java.lang.Long getAppId();
    java.lang.String getApplicationName();
    java.lang.String getRootEntityName();
    void setId(java.lang.Long);
    void setGuid(java.lang.Long);
    void setAppId(java.lang.Long);
    void setApplicationName(java.lang.String);
    void setRootEntityName(java.lang.String);
```

### `BpmTemplateOwnerDto`（8 方法）

`com.seeyon.bpm.dto.BpmTemplateOwnerDto`

```java
    java.lang.Long getId();
    java.lang.Long getUserId();
    java.lang.Long getTemplateGuId();
    java.lang.String getTemplateName();
    void setId(java.lang.Long);
    void setUserId(java.lang.Long);
    void setTemplateGuId(java.lang.Long);
    void setTemplateName(java.lang.String);
```

### `BpmTemplateParamDto`（8 方法）

`com.seeyon.bpm.dto.BpmTemplateParamDto`

```java
    void setRootEntityName(java.lang.String);
    void setPageUrl(java.lang.String);
    void setPageType(com.seeyon.bpm.enums.PageTypeEnum);
    void setUserId(java.lang.Long);
    java.lang.String getRootEntityName();
    java.lang.String getPageUrl();
    com.seeyon.bpm.enums.PageTypeEnum getPageType();
    java.lang.Long getUserId();
```

### `BpmTemplateReferOrgUnitDto`（8 方法）

`com.seeyon.bpm.dto.BpmTemplateReferOrgUnitDto`

```java
    java.lang.Long getId();
    java.lang.String getCode();
    java.lang.String getName();
    java.lang.String getShortName();
    void setId(java.lang.Long);
    void setCode(java.lang.String);
    void setName(java.lang.String);
    void setShortName(java.lang.String);
```

### `BpmTemplateUserGuidInfo`（8 方法）

`com.seeyon.bpm.dto.BpmTemplateUserGuidInfo`

```java
    java.lang.Long getId();
    java.lang.String getAppName();
    java.lang.String getEntityName();
    java.lang.Long getGuid();
    void setId(java.lang.Long);
    void setAppName(java.lang.String);
    void setEntityName(java.lang.String);
    void setGuid(java.lang.Long);
```

### `UserTemplateListRequestDto`（8 方法）

`com.seeyon.bpm.dto.formtemplate.UserTemplateListRequestDto`

```java
    java.lang.Long getUserId();
    java.lang.String getKeywords();
    com.seeyon.boot.transport.PageInfo getPageInfo();
    java.lang.String getCategoryCode();
    void setUserId(java.lang.Long);
    void setKeywords(java.lang.String);
    void setPageInfo(com.seeyon.boot.transport.PageInfo);
    void setCategoryCode(java.lang.String);
```

### `BpmTemplateOwnerSearchDto`（8 方法）

`com.seeyon.bpm.dto.operation.openapi.BpmTemplateOwnerSearchDto`

```java
    java.lang.Long getUserId();
    com.seeyon.boot.transport.Sort getSort();
    com.seeyon.boot.transport.PageInfo getPageInfo();
    java.lang.String getTemplateName();
    void setUserId(java.lang.Long);
    void setSort(com.seeyon.boot.transport.Sort);
    void setPageInfo(com.seeyon.boot.transport.PageInfo);
    void setTemplateName(java.lang.String);
```

### `BpmTemplateAuthorizationDto`（6 方法）

`com.seeyon.bpm.dto.BpmTemplateAuthorizationDto`

```java
    java.lang.Long getTemplateId();
    java.lang.Long getTemplateGuid();
    java.lang.String getAuthorization();
    void setTemplateId(java.lang.Long);
    void setTemplateGuid(java.lang.Long);
    void setAuthorization(java.lang.String);
```

### `BpmThirdTemplateResponseDto`（6 方法）

`com.seeyon.bpm.dto.BpmThirdTemplateResponseDto`

```java
    java.lang.Long getId();
    java.lang.Boolean getSuccess();
    java.lang.String getMessage();
    void setId(java.lang.Long);
    void setSuccess(java.lang.Boolean);
    void setMessage(java.lang.String);
```
