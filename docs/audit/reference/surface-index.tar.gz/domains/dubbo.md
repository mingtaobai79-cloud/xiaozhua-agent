# Dubbo 跨服务调用：接口与方法签名

> 自动生成，勿手改。`tools/core/platform/emit_domain_surfaces.py` 重跑即可。
> 用途：跨应用/跨服务调用：工厂、代理、灰度、可靠投递
> 规模：48 类 / 4 接口 / 6 个关键类 / 220 方法。包前缀 `com.seeyon.boot.starter.dubbo`。
> 签名逐字来自 javap 原文，已去掉 `public` 等修饰前缀与 `throws`。

## 一、接口（4）

### `DubboFactory`（5 方法）

`com.seeyon.boot.starter.dubbo.DubboFactory`

```java
    <T> T getProxy(java.lang.Class<T>, java.lang.String, java.lang.String, int);
    <T> T getProxy(java.lang.Class<T>, java.lang.String, java.lang.String);
    <T> T getProxy(java.lang.Class<T>, java.lang.String, int);
    <T> T getProxy(java.lang.Class<T>, java.lang.String);
    <T> T getProxy(java.lang.Class<T>);
```

### `AppServiceProxy`（4 方法）

`com.seeyon.boot.starter.dubbo.api.AppServiceProxy`

```java
    com.seeyon.boot.transport.SingleResponse<java.lang.Object> invokeAppService(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.dubbo.dto.AppServiceInvokeDto>);
    default com.seeyon.boot.transport.ListResponse<java.lang.Object> invokeAppServiceForList(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.dubbo.dto.AppServiceInvokeDto>);
    default com.seeyon.boot.transport.PageResponse<java.lang.Object> invokeAppServiceForPage(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.dubbo.dto.AppServiceInvokeDto>);
    <T> com.seeyon.boot.transport.SingleResponse reliableInvokeAppService(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.dubbo.dto.AppServiceReliableInvokeDto<T>>);
```

### `AppServiceProxyCallback`（1 方法）

`com.seeyon.boot.starter.dubbo.api.AppServiceProxyCallback`

```java
    com.seeyon.boot.transport.SingleResponse<java.lang.String> callback(com.seeyon.boot.transport.SingleRequest<com.seeyon.boot.starter.dubbo.dto.CommandCallbackDto>);
```

### `DubboComponent`（0 方法） extends Annotation

`com.seeyon.boot.starter.dubbo.annotation.DubboComponent`

```java
```

## 二、关键类（6）

### `AppServiceInvokeDto`（18 方法）

`com.seeyon.boot.starter.dubbo.dto.AppServiceInvokeDto`

```java
    java.lang.String getInterfaceName();
    java.lang.String getMethodName();
    java.lang.String getParamType();
    java.lang.String getGenericType();
    java.lang.String getSubGenericType();
    java.lang.String getParamJson();
    java.lang.String getBeanName();
    java.lang.Boolean getReturnJson();
    java.lang.Boolean getBodyZip();
    void setInterfaceName(java.lang.String);
    void setMethodName(java.lang.String);
    void setParamType(java.lang.String);
    void setGenericType(java.lang.String);
    void setSubGenericType(java.lang.String);
    void setParamJson(java.lang.String);
    void setBeanName(java.lang.String);
    void setReturnJson(java.lang.Boolean);
    void setBodyZip(java.lang.Boolean);
```

### `AppServiceAsyncInvokeDto`（10 方法）

`com.seeyon.boot.starter.dubbo.dto.AppServiceAsyncInvokeDto`

```java
    java.lang.String getNotifyDubboGroup();
    java.lang.String getNotifyDubboVersion();
    java.lang.Long getParamConvertId();
    java.lang.String getCallBackUrl();
    java.util.Map<java.lang.String, java.lang.Object> getExtendParams();
    void setNotifyDubboGroup(java.lang.String);
    void setNotifyDubboVersion(java.lang.String);
    void setParamConvertId(java.lang.Long);
    void setCallBackUrl(java.lang.String);
    void setExtendParams(java.util.Map<java.lang.String, java.lang.Object>);
```

### `SeeyonEagerThreadPoolExecutor`（9 方法）

`com.seeyon.boot.starter.dubbo.threadpool.SeeyonEagerThreadPoolExecutor`

```java
    java.util.TreeSet<com.seeyon.boot.starter.dubbo.threadpool.SeeyonEagerThreadPoolExecutor$TaskPrint> getRunningTasks();
    protected void beforeExecute(java.lang.Thread, java.lang.Runnable);
    protected void afterExecute(java.lang.Runnable, java.lang.Throwable);
    void execute(java.lang.Runnable);
    private java.util.TreeSet<com.seeyon.boot.starter.dubbo.threadpool.SeeyonEagerThreadPoolExecutor$TaskPrint> getRunningTasks(java.util.List<java.lang.Object>);
    private void printQueue(java.lang.String, java.util.List<java.lang.Object>);
    private java.lang.String runnableToString(java.lang.Object);
```

### `AppServiceReliableInvokeDto`（8 方法）

`com.seeyon.boot.starter.dubbo.dto.AppServiceReliableInvokeDto`

```java
    java.lang.String getInterfaceName();
    java.lang.String getMethodName();
    java.lang.String getParamType();
    T getParam();
    void setInterfaceName(java.lang.String);
    void setMethodName(java.lang.String);
    void setParamType(java.lang.String);
    void setParam(T);
```

### `DubboFactoryImpl`（7 方法）

`com.seeyon.boot.starter.dubbo.DubboFactoryImpl`

```java
    void setApplicationContext(org.springframework.context.ApplicationContext)
    <T> T getProxy(java.lang.Class<T>, java.lang.String, java.lang.String, int);
    <T> T getProxy(java.lang.Class<T>, java.lang.String, int);
    <T> T getProxy(java.lang.Class<T>, java.lang.String, java.lang.String);
    <T> T getProxy(java.lang.Class<T>, java.lang.String);
    <T> T getProxy(java.lang.Class<T>);
    void destroy();
```

### `ProxyServiceBeanPostProcessor`（6 方法）

`com.seeyon.boot.starter.dubbo.ProxyServiceBeanPostProcessor`

```java
    java.lang.Object postProcessAfterInitialization(java.lang.Object, java.lang.String)
    void afterPropertiesSet()
    com.seeyon.boot.starter.dubbo.api.AppServiceProxy getAppServiceProxy();
    java.util.Set<java.lang.Class<?>> getClassesDubboComponent();
    void setAppServiceProxy(com.seeyon.boot.starter.dubbo.api.AppServiceProxy);
    void setClassesDubboComponent(java.util.Set<java.lang.Class<?>>);
```
