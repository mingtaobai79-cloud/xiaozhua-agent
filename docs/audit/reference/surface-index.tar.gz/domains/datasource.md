# 数据源：接口与方法签名

> 自动生成，勿手改。`tools/core/platform/emit_domain_surfaces.py` 重跑即可。
> 用途：数据源装配、多库路由
> 规模：29 类 / 2 接口 / 4 个关键类 / 622 方法。包前缀 `com.seeyon.boot.starter.datasource`。
> 签名逐字来自 javap 原文，已去掉 `public` 等修饰前缀与 `throws`。

## 一、接口（2）

### `IConnectionPoolProxy`（15 方法）

`com.seeyon.boot.starter.datasource.dbpool.IConnectionPoolProxy`

```java
    void init(com.seeyon.boot.starter.datasource.dbpool.DBConProviderConfig, java.util.Properties)
    com.seeyon.boot.starter.datasource.dbpool.DBConProviderConfig getSJConProviderConfig();
    void clearExceedConnInfos();
    int getNoUseCount();
    java.util.Set<com.seeyon.boot.starter.datasource.dbpool.ConInfo> getUseList();
    java.sql.Connection getConnection()
    void releaseConnection(com.seeyon.boot.starter.datasource.dbpool.ConInfo);
    void clearPool();
    int getPeakConnectionCount();
    int getBusyConnectionCount();
    java.util.Date getActivePeakTime();
    void printInfo(java.io.PrintWriter);
    void printInUseList(java.io.PrintWriter);
    int getBianhao();
    int getTotalConnection();
```

### `ConnectionCallback`（3 方法）

`com.seeyon.boot.starter.datasource.dbpool.ConnectionCallback`

```java
    void commit(com.seeyon.boot.starter.datasource.dbpool.ProxyConnection);
    void rollback(com.seeyon.boot.starter.datasource.dbpool.ProxyConnection);
    void setAutoCommit(boolean, com.seeyon.boot.starter.datasource.dbpool.ProxyConnection);
```

## 二、关键类（4）

### `DBConProviderConfig`（35 方法）

`com.seeyon.boot.starter.datasource.dbpool.DBConProviderConfig`

```java
    protected final boolean isEmptyString(java.lang.String);
    protected final void initDefaultPName();
    protected final void initPName(java.util.Properties);
    protected final java.util.Properties readDefineProperties(java.lang.String);
    private final void putDefaultConfig();
    void readConfig(java.util.Properties);
    java.lang.String getName();
    java.lang.String getSQLdriver();
    java.lang.String getSQLUrl();
    java.lang.String getUserName();
    java.lang.String getPassWord();
    java.lang.String getConnectionPool();
    int getMaxWaitMillis();
    int getMinCount();
    int getMaxCount();
    int getTryCount();
    int getTryWait();
    int getConnectionThreshold();
    int getValidateOnGet();
    java.lang.String getValidateQuery();
    int getValidateTimeout();
    long getValidateInterval();
    long getTimeBetweenEvictionRunsMillis();
    double getRateLimit();
    static long getSqlConsThreshold();
    java.lang.String getConnectionPoolPName();
    java.lang.String getDriverPName();
    java.lang.String getSQLUrlPName();
    java.lang.String getUserNamePName();
    java.lang.String getPassWordPName();
    java.lang.String getMinCountPName();
    java.lang.String getMaxCountPName();
    java.lang.String getTryCountPName();
    java.lang.String getTryWaitPName();
    boolean isOverflowMonitorEnabled();
```

### `DBConProvider`（31 方法）

`com.seeyon.boot.starter.datasource.dbpool.DBConProvider`

```java
    void setDeadConnectionTimeout(long);
    long getDeadConnectionTimeout();
    final boolean inited();
    int getDoReconnectTime();
    private boolean checkConfig()
    private boolean checkWeakPwd();
    synchronized void init(java.lang.String, java.util.Properties)
    void clearExceedConnInfos();
    void clearSlowConnInfos();
    int getNoUseCount();
    java.util.Set<com.seeyon.boot.starter.datasource.dbpool.ConInfo> getUseList();
    private void clearPool();
    private void testLink(java.lang.String, java.lang.String)
    void printInfo(java.io.PrintWriter);
    void printInUseList(java.io.PrintWriter);
    java.sql.Connection getConnection()
    void releaseConnection(com.seeyon.boot.starter.datasource.dbpool.ConInfo);
    void unInit();
    int getPeakConnectionCount();
    int getBusyConnectionCount();
    int getTotalCount();
    void monitor();
    java.lang.String getUserName();
    java.lang.String getSQLdriver();
    java.lang.String getSQLUrl();
    int getMinCount();
    int getMaxCount();
    java.lang.String getPassword();
```

### `DataSourceConProvider`（21 方法）

`com.seeyon.boot.starter.datasource.dbpool.DataSourceConProvider`

```java
    void init(java.lang.String, java.util.Properties)
    void init()
    void setName(java.lang.String)
    java.lang.String getName();
    void setConfigProperties(java.util.Properties)
    void close()
    java.sql.Connection getConnection(java.lang.String, java.lang.String)
    java.sql.Connection getConnection()
    java.io.PrintWriter getLogWriter()
    int getLoginTimeout()
    void setLogWriter(java.io.PrintWriter)
    void setLoginTimeout(int)
    com.seeyon.boot.starter.datasource.dbpool.DBConProvider getFProvider();
    static java.util.List<com.seeyon.boot.starter.datasource.dbpool.DataSourceConProvider> getDataSources();
    static private static synchronized void startDBConnectionPoolingMonitor();
    static private static java.util.Date getTodayLastTime();
    <T> T unwrap(java.lang.Class<T>)
    boolean isWrapperFor(java.lang.Class<?>)
    java.util.logging.Logger getParentLogger()
```

### `DataSourceScriptUtils`（13 方法）

`com.seeyon.boot.starter.datasource.util.DataSourceScriptUtils`

```java
    static java.lang.String executeSqlScript(java.sql.Connection, org.springframework.core.io.support.EncodedResource, boolean, boolean, java.lang.String, java.lang.String, java.lang.String, java.lang.String)
    static java.lang.String executeSqlScript(java.sql.Connection, org.springframework.core.io.support.EncodedResource, boolean, boolean, java.lang.String[], java.lang.String, java.lang.String, java.lang.String)
    static static java.lang.String readScript(org.springframework.core.io.support.EncodedResource, java.lang.String, java.lang.String[], java.lang.String)
    static java.lang.String readScript(java.io.LineNumberReader, java.lang.String, java.lang.String, java.lang.String)
    static java.lang.String readScript(java.io.LineNumberReader, java.lang.String[], java.lang.String, java.lang.String)
    static private static void appendSeparatorToScriptIfNecessary(java.lang.StringBuilder, java.lang.String);
    static boolean containsSqlScriptDelimiters(java.lang.String, java.lang.String);
    static private static boolean containsStatementSeparator(org.springframework.core.io.support.EncodedResource, java.lang.String, java.lang.String, java.lang.String[], java.lang.String, java.lang.String)
    static void splitSqlScript(java.lang.String, char, java.util.List<java.lang.String>)
    static void splitSqlScript(java.lang.String, java.lang.String, java.util.List<java.lang.String>)
    static void splitSqlScript(org.springframework.core.io.support.EncodedResource, java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.util.List<java.lang.String>)
    static void splitSqlScript(org.springframework.core.io.support.EncodedResource, java.lang.String, java.lang.String, java.lang.String[], java.lang.String, java.lang.String, java.util.List<java.lang.String>)
    static private static boolean startsWithAny(java.lang.String, java.lang.String[], int);
```
