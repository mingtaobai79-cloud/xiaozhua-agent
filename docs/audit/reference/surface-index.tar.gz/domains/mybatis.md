# MyBatis / Dao：接口与方法签名

> 自动生成，勿手改。`tools/core/platform/emit_domain_surfaces.py` 重跑即可。
> 用途：通用 Dao、条件查询、分页、方言
> 规模：138 类 / 44 接口 / 18 个关键类 / 878 方法。包前缀 `com.seeyon.boot.starter.mybatis`。
> 签名逐字来自 javap 原文，已去掉 `public` 等修饰前缀与 `throws`。

## 一、接口（44）

### `AllInOneBaseDao`（41 方法） extends BaseDao<T>

`com.seeyon.boot.starter.mybatis.inone.dao.AllInOneBaseDao`

```java
    int create(T);
    int createBatch(java.util.List<T>);
    int update(T);
    int versionNoUpdateIgnoreVersion(T);
    int updateColumns(T, java.util.Set<java.lang.String>);
    int updateColumnsIgnoreVersion(T, java.util.Set<java.lang.String>);
    int updateBatch(java.util.List<T>);
    int versionNoUpdateBatchIgnoreVersion(java.util.List<T>);
    int deleteById(java.lang.Long);
    int deleteByIds(java.util.List<java.lang.Long>);
    int deleteByCondition(java.lang.String, java.lang.Object);
    int deleteByConditions(java.util.Map<java.lang.String, java.lang.Object>);
    T selectById(java.lang.Long);
    java.util.List<T> selectByIds(java.util.List<java.lang.Long>);
    T selectOneByCondition(java.lang.String, java.lang.Object);
    T selectOneByConditions(java.util.Map<java.lang.String, java.lang.Object>);
    int selectCountByCondition(java.lang.String, java.lang.Object);
    int selectCountByConditions(java.util.Map<java.lang.String, java.lang.Object>);
    java.util.List<T> selectListByCondition(java.lang.String, java.lang.Object, com.seeyon.boot.transport.Sort);
    java.util.List<T> selectListByConditions(java.util.Map<java.lang.String, java.lang.Object>, com.seeyon.boot.transport.Sort);
    java.util.List<T> selectListPropertiesByConditions(java.lang.String[], java.util.Map<java.lang.String, java.lang.Object>, com.seeyon.boot.transport.Sort);
    java.util.List<T> selectListExcludeByConditions(java.lang.String[], java.util.Map<java.lang.String, java.lang.Object>, com.seeyon.boot.transport.Sort);
    com.seeyon.boot.transport.PageData<T> selectPageByCondition(com.seeyon.boot.transport.PageInfo, java.lang.String, java.lang.Object, com.seeyon.boot.transport.Sort);
    com.seeyon.boot.transport.PageData<T> selectPageByConditions(com.seeyon.boot.transport.PageInfo, java.util.Map<java.lang.String, java.lang.Object>, com.seeyon.boot.transport.Sort);
    com.seeyon.boot.transport.PageData<T> selectPagePropertiesByConditions(com.seeyon.boot.transport.PageInfo, java.lang.String[], java.util.Map<java.lang.String, java.lang.Object>, com.seeyon.boot.transport.Sort);
    com.seeyon.boot.transport.PageData<T> selectPageExcludeByConditions(com.seeyon.boot.transport.PageInfo, java.lang.String[], java.util.Map<java.lang.String, java.lang.Object>, com.seeyon.boot.transport.Sort);
    int selectCountByComplexConditions(java.util.LinkedHashMap<java.lang.String, java.lang.Object>);
    java.util.List<T> selectListByComplexConditions(java.util.LinkedHashMap<java.lang.String, java.lang.Object>, com.seeyon.boot.transport.Sort);
    com.seeyon.boot.transport.PageData<T> selectPageByComplexConditions(com.seeyon.boot.transport.PageInfo, java.util.LinkedHashMap<java.lang.String, java.lang.Object>, com.seeyon.boot.transport.Sort);
    java.lang.String selectListFuncByComplexConditions(java.util.LinkedHashMap<java.lang.String, java.lang.Object>, com.seeyon.boot.transport.Sort, java.lang.String, java.util.List<java.lang.String>);
    int deleteByComplexConditions(java.util.Map<java.lang.String, java.lang.Object>);
    int selectCountByDynamicConditions(java.util.LinkedHashMap<java.lang.String, java.lang.Object>);
    java.util.List<T> selectListByDynamicConditions(java.util.LinkedHashMap<java.lang.String, java.lang.Object>, com.seeyon.boot.transport.Sort);
    com.seeyon.boot.transport.PageData<T> selectPageByDynamicConditions(com.seeyon.boot.transport.PageInfo, java.util.LinkedHashMap<java.lang.String, java.lang.Object>, com.seeyon.boot.transport.Sort);
    java.lang.String selectListFuncByDynamicConditions(java.util.LinkedHashMap<java.lang.String, java.lang.Object>, com.seeyon.boot.transport.Sort, java.lang.String, java.util.List<java.lang.String>);
    int deleteByDynamicConditions(java.util.Map<java.lang.String, java.lang.Object>);
    int selectCountByDynamicConditions(java.util.List<com.seeyon.boot.starter.mybatis.util.SeeyonKeyMap>);
    java.util.List<T> selectListByDynamicConditions(java.util.List<com.seeyon.boot.starter.mybatis.util.SeeyonKeyMap>, com.seeyon.boot.transport.Sort);
    com.seeyon.boot.transport.PageData<T> selectPageByDynamicConditions(com.seeyon.boot.transport.PageInfo, java.util.List<com.seeyon.boot.starter.mybatis.util.SeeyonKeyMap>, com.seeyon.boot.transport.Sort);
    java.lang.String selectListFuncByDynamicConditions(java.util.List<com.seeyon.boot.starter.mybatis.util.SeeyonKeyMap>, com.seeyon.boot.transport.Sort, java.lang.String, java.util.List<java.lang.String>);
    int deleteByDynamicConditions(java.util.List<com.seeyon.boot.starter.mybatis.util.SeeyonKeyMap>);
```

### `BaseMybatisDao`（16 方法）

`com.seeyon.boot.starter.mybatis.BaseMybatisDao`

```java
    default int updateBatch(java.util.List<T>);
    default int updateBatchIgnoreTime(java.util.List<T>);
    default int updateBatchIgnoreVersion(java.util.List<T>);
    default int versionNoUpdateBatchIgnoreVersion(java.util.List<T>);
    default int createBatch(java.util.List<T>);
    default int createBatchNoClob(java.util.List<T>);
    default int createBatchIgnoreTime(java.util.List<T>);
    default int getFieldCount(java.util.List);
    default int deleteByIds(java.util.List<java.lang.Long>);
    default int deleteByCondition(java.lang.String, java.lang.Object);
    default T selectOneByCondition(java.lang.String, java.lang.Object);
    default T selectOneByConditions(java.util.Map<java.lang.String, java.lang.Object>);
    default int selectCountByCondition(java.lang.String, java.lang.Object);
    default java.util.List<T> selectListByCondition(java.lang.String, java.lang.Object, com.seeyon.boot.transport.Sort);
    default com.seeyon.boot.transport.PageData<T> selectPageByCondition(com.seeyon.boot.transport.PageInfo, java.lang.String, java.lang.Object, com.seeyon.boot.transport.Sort);
    default T selectOneByWrapper(com.seeyon.boot.domain.dao.Wrapper);
```

### `AllInOneSelectByConditionMapper`（7 方法）

`com.seeyon.boot.starter.mybatis.inone.mapper.AllInOneSelectByConditionMapper`

```java
    int inOneSelectCountByConditions(java.util.Map<java.lang.String, java.lang.Object>);
    java.util.List<T> inOneSelectListByConditions(java.util.Map<java.lang.String, java.lang.Object>, com.seeyon.boot.transport.Sort);
    java.util.List<T> inOneSelectListPropertiesByConditions(java.lang.String[], java.util.Map<java.lang.String, java.lang.Object>, com.seeyon.boot.transport.Sort);
    java.util.List<T> inOneSelectListExcludeByConditions(java.lang.String[], java.util.Map<java.lang.String, java.lang.Object>, com.seeyon.boot.transport.Sort);
    com.seeyon.boot.transport.PageData<T> inOneSelectPageByConditions(com.seeyon.boot.transport.PageInfo, java.util.Map<java.lang.String, java.lang.Object>, com.seeyon.boot.transport.Sort);
    com.seeyon.boot.transport.PageData<T> inOneSelectPagePropertiesByConditions(com.seeyon.boot.transport.PageInfo, java.lang.String[], java.util.Map<java.lang.String, java.lang.Object>, com.seeyon.boot.transport.Sort);
    com.seeyon.boot.transport.PageData<T> inOneSelectPageExcludeByConditions(com.seeyon.boot.transport.PageInfo, java.lang.String[], java.util.Map<java.lang.String, java.lang.Object>, com.seeyon.boot.transport.Sort);
```

### `SelectByConditionMapper`（7 方法）

`com.seeyon.boot.starter.mybatis.mapper.SelectByConditionMapper`

```java
    int selectCountByConditions(java.util.Map<java.lang.String, java.lang.Object>);
    java.util.List<T> selectListByConditions(java.util.Map<java.lang.String, java.lang.Object>, com.seeyon.boot.transport.Sort);
    java.util.List<T> selectListPropertiesByConditions(java.lang.String[], java.util.Map<java.lang.String, java.lang.Object>, com.seeyon.boot.transport.Sort);
    java.util.List<T> selectListExcludeByConditions(java.lang.String[], java.util.Map<java.lang.String, java.lang.Object>, com.seeyon.boot.transport.Sort);
    com.seeyon.boot.transport.PageData<T> selectPageByConditions(com.seeyon.boot.transport.PageInfo, java.util.Map<java.lang.String, java.lang.Object>, com.seeyon.boot.transport.Sort);
    com.seeyon.boot.transport.PageData<T> selectPagePropertiesByConditions(com.seeyon.boot.transport.PageInfo, java.lang.String[], java.util.Map<java.lang.String, java.lang.Object>, com.seeyon.boot.transport.Sort);
    com.seeyon.boot.transport.PageData<T> selectPageExcludeByConditions(com.seeyon.boot.transport.PageInfo, java.lang.String[], java.util.Map<java.lang.String, java.lang.Object>, com.seeyon.boot.transport.Sort);
```

### `UpdateMapper`（4 方法）

`com.seeyon.boot.starter.mybatis.mapper.UpdateMapper`

```java
    int update(T);
    int updateIgnoreTime(T);
    int updateColumns(T, java.util.Set<java.lang.String>);
    int updateColumnsIgnoreVersion(T, java.util.Set<java.lang.String>);
```

### `AllInOneSelectByComplexConditionMapper`（3 方法）

`com.seeyon.boot.starter.mybatis.inone.mapper.AllInOneSelectByComplexConditionMapper`

```java
    java.lang.Integer inOneSelectCountByComplexConditions(java.util.Map<java.lang.String, java.lang.Object>);
    java.util.List<T> inOneSelectListByComplexConditions(java.util.LinkedHashMap<java.lang.String, java.lang.Object>, com.seeyon.boot.transport.Sort);
    com.seeyon.boot.transport.PageData<T> inOneSelectPageByComplexConditions(com.seeyon.boot.transport.PageInfo, java.util.LinkedHashMap<java.lang.String, java.lang.Object>, com.seeyon.boot.transport.Sort);
```

### `AllInOneSelectByDynamicConditionMapper`（3 方法）

`com.seeyon.boot.starter.mybatis.inone.mapper.AllInOneSelectByDynamicConditionMapper`

```java
    int inOneSelectCountByDynamicConditions(java.util.LinkedHashMap<java.lang.String, java.lang.Object>);
    java.util.List<T> inOneSelectListByDynamicConditions(java.util.LinkedHashMap<java.lang.String, java.lang.Object>, com.seeyon.boot.transport.Sort);
    com.seeyon.boot.transport.PageData<T> inOneSelectPageByDynamicConditions(com.seeyon.boot.transport.PageInfo, java.util.LinkedHashMap<java.lang.String, java.lang.Object>, com.seeyon.boot.transport.Sort);
```

### `SelectByComplexConditionMapper`（3 方法）

`com.seeyon.boot.starter.mybatis.mapper.SelectByComplexConditionMapper`

```java
    int selectCountByComplexConditions(java.util.Map<java.lang.String, java.lang.Object>);
    java.util.List<T> selectListByComplexConditions(java.util.LinkedHashMap<java.lang.String, java.lang.Object>, com.seeyon.boot.transport.Sort);
    com.seeyon.boot.transport.PageData<T> selectPageByComplexConditions(com.seeyon.boot.transport.PageInfo, java.util.LinkedHashMap<java.lang.String, java.lang.Object>, com.seeyon.boot.transport.Sort);
```

### `SelectByDynamicConditionMapper`（3 方法）

`com.seeyon.boot.starter.mybatis.mapper.SelectByDynamicConditionMapper`

```java
    int selectCountByDynamicConditions(java.util.LinkedHashMap<java.lang.String, java.lang.Object>);
    java.util.List<T> selectListByDynamicConditions(java.util.LinkedHashMap<java.lang.String, java.lang.Object>, com.seeyon.boot.transport.Sort);
    com.seeyon.boot.transport.PageData<T> selectPageByDynamicConditions(com.seeyon.boot.transport.PageInfo, java.util.LinkedHashMap<java.lang.String, java.lang.Object>, com.seeyon.boot.transport.Sort);
```

### `SelectByWrapperMapper`（3 方法）

`com.seeyon.boot.starter.mybatis.mapper.SelectByWrapperMapper`

```java
    int selectCountByWrapper(com.seeyon.boot.domain.dao.Wrapper);
    java.util.List<T> selectListByWrapper(com.seeyon.boot.domain.dao.Wrapper);
    com.seeyon.boot.transport.PageData<T> selectPageByWrapper(com.seeyon.boot.transport.PageInfo, com.seeyon.boot.domain.dao.Wrapper);
```

### `UpdateBatchMapper`（3 方法）

`com.seeyon.boot.starter.mybatis.mapper.UpdateBatchMapper`

```java
    int updateBatchInternal(java.util.List<T>);
    int updateBatchInternalIgnoreTime(java.util.List<T>);
    int updateColumnsBatch(java.util.List<T>, java.util.Set<java.lang.String>);
```

### `DatabaseDialect`（2 方法）

`com.seeyon.boot.starter.mybatis.dialect.DatabaseDialect`

```java
    java.lang.String pageSql(com.seeyon.boot.transport.PageInfo, java.lang.String);
    com.seeyon.boot.domain.dao.support.DatabaseType getDatabaseType();
```

### `AllInOneDeleteByIdMapper`（2 方法）

`com.seeyon.boot.starter.mybatis.inone.mapper.AllInOneDeleteByIdMapper`

```java
    int inOneDeleteById(java.lang.Long);
    int inOneDeleteByIds(java.util.List<java.lang.Long>);
```

### `AllInOneSelectByIdMapper`（2 方法）

`com.seeyon.boot.starter.mybatis.inone.mapper.AllInOneSelectByIdMapper`

```java
    T inOneSelectById(java.lang.Long);
    java.util.List<T> inOneSelectByIds(java.util.List<java.lang.Long>);
```

### `AllInOneUpdateBatchMapper`（2 方法）

`com.seeyon.boot.starter.mybatis.inone.mapper.AllInOneUpdateBatchMapper`

```java
    int inOneUpdateBatchInternal(java.util.List<T>);
    int inOneVersionNoUpdateBatchInternalIgnoreVersion(java.util.List<T>);
```

### `AllInOneUpdateIgnoreVersionMapper`（2 方法）

`com.seeyon.boot.starter.mybatis.inone.mapper.AllInOneUpdateIgnoreVersionMapper`

```java
    int inOneUpdateIgnoreVersion(java.lang.Object);
    int inOneVersionNoUpdateIgnoreVersion(java.lang.Object);
```

### `AllInOneUpdateMapper`（2 方法）

`com.seeyon.boot.starter.mybatis.inone.mapper.AllInOneUpdateMapper`

```java
    int inOneUpdate(java.lang.Object);
    int inOneUpdateColumns(java.lang.Object, java.util.Set<java.lang.String>);
```

### `CreateBatchMapper`（2 方法）

`com.seeyon.boot.starter.mybatis.mapper.CreateBatchMapper`

```java
    int createBatchInternal(java.util.List<T>);
    int createBatchInternalIgnoreTime(java.util.List<T>);
```

### `CreateMapper`（2 方法）

`com.seeyon.boot.starter.mybatis.mapper.CreateMapper`

```java
    int create(T);
    int createIgnoreTime(T);
```

### `DeleteByIdMapper`（2 方法）

`com.seeyon.boot.starter.mybatis.mapper.DeleteByIdMapper`

```java
    int deleteById(java.lang.Long);
    int deleteByIdsInternal(java.util.List<java.lang.Long>);
```

### `SelectByIdMapper`（2 方法）

`com.seeyon.boot.starter.mybatis.mapper.SelectByIdMapper`

```java
    T selectById(java.lang.Long);
    java.util.List<T> selectByIds(java.util.List<java.lang.Long>);
```

### `UpdateBatchIgnoreVersionMapper`（2 方法）

`com.seeyon.boot.starter.mybatis.mapper.UpdateBatchIgnoreVersionMapper`

```java
    int updateBatchInternalIgnoreVersion(java.util.List<T>);
    int versionNoUpdateBatchInternalIgnoreVersion(java.util.List<T>);
```

### `UpdateByWrapperMapper`（2 方法）

`com.seeyon.boot.starter.mybatis.mapper.UpdateByWrapperMapper`

```java
    int updateByWrapper(T, java.lang.Object);
    int updateByWrapperSelective(T, java.lang.Object);
```

### `UpdateIgnoreVersionMapper`（2 方法）

`com.seeyon.boot.starter.mybatis.mapper.UpdateIgnoreVersionMapper`

```java
    int updateIgnoreVersion(T);
    int versionNoUpdateIgnoreVersion(T);
```

### `DataPermissionCheck`（1 方法）

`com.seeyon.boot.starter.mybatis.DataPermissionCheck`

```java
    java.util.List<java.util.Map<java.lang.String, java.lang.String>> check(java.lang.String);
```

### `CountSql`（1 方法） extends Annotation

`com.seeyon.boot.starter.mybatis.annotation.CountSql`

```java
    java.lang.String value();
```

### `AllInOneCreateBatchMapper`（1 方法）

`com.seeyon.boot.starter.mybatis.inone.mapper.AllInOneCreateBatchMapper`

```java
    int inOneCreateBatchInternal(java.util.List<T>);
```

### `AllInOneCreateMapper`（1 方法）

`com.seeyon.boot.starter.mybatis.inone.mapper.AllInOneCreateMapper`

```java
    int inOneCreate(java.lang.Object);
```

### `AllInOneDeleteByComplexConditionMapper`（1 方法）

`com.seeyon.boot.starter.mybatis.inone.mapper.AllInOneDeleteByComplexConditionMapper`

```java
    int inOneDeleteByComplexConditions(java.util.Map<java.lang.String, java.lang.Object>);
```

### `AllInOneDeleteByConditionMapper`（1 方法）

`com.seeyon.boot.starter.mybatis.inone.mapper.AllInOneDeleteByConditionMapper`

```java
    int inOneDeleteByConditions(java.util.Map<java.lang.String, java.lang.Object>);
```

### `AllInOneDeleteByDynamicConditionMapper`（1 方法）

`com.seeyon.boot.starter.mybatis.inone.mapper.AllInOneDeleteByDynamicConditionMapper`

```java
    int inOneDeleteByDynamicConditions(java.util.Map<java.lang.String, java.lang.Object>);
```

### `AllInOneSelectFuncByComplexConditionMapper`（1 方法）

`com.seeyon.boot.starter.mybatis.inone.mapper.AllInOneSelectFuncByComplexConditionMapper`

```java
    java.lang.String inOneSelectListFuncByComplexConditions(java.util.LinkedHashMap<java.lang.String, java.lang.Object>, com.seeyon.boot.transport.Sort, java.lang.String, java.util.List<java.lang.String>);
```

### `AllInOneSelectFuncByDynamicConditionMapper`（1 方法）

`com.seeyon.boot.starter.mybatis.inone.mapper.AllInOneSelectFuncByDynamicConditionMapper`

```java
    java.lang.String inOneSelectListFuncByDynamicConditions(java.util.LinkedHashMap<java.lang.String, java.lang.Object>, com.seeyon.boot.transport.Sort, java.lang.String, java.util.List<java.lang.String>);
```

### `DeleteByComplexConditionMapper`（1 方法）

`com.seeyon.boot.starter.mybatis.mapper.DeleteByComplexConditionMapper`

```java
    int deleteByComplexConditions(java.util.Map<java.lang.String, java.lang.Object>);
```

### `DeleteByConditionMapper`（1 方法）

`com.seeyon.boot.starter.mybatis.mapper.DeleteByConditionMapper`

```java
    int deleteByConditions(java.util.Map<java.lang.String, java.lang.Object>);
```

### `DeleteByDynamicConditionMapper`（1 方法）

`com.seeyon.boot.starter.mybatis.mapper.DeleteByDynamicConditionMapper`

```java
    int deleteByDynamicConditions(java.util.Map<java.lang.String, java.lang.Object>);
```

### `DeleteByWrapperMapper`（1 方法）

`com.seeyon.boot.starter.mybatis.mapper.DeleteByWrapperMapper`

```java
    int deleteByWrapper(com.seeyon.boot.domain.dao.Wrapper);
```

### `SelectFuncByComplexConditionMapper`（1 方法）

`com.seeyon.boot.starter.mybatis.mapper.SelectFuncByComplexConditionMapper`

```java
    java.lang.String selectListFuncByComplexConditions(java.util.LinkedHashMap<java.lang.String, java.lang.Object>, com.seeyon.boot.transport.Sort, java.lang.String, java.util.List<java.lang.String>);
```

### `SelectFuncByConditionMapper`（1 方法）

`com.seeyon.boot.starter.mybatis.mapper.SelectFuncByConditionMapper`

```java
    java.lang.String selectFuncByConditions(java.util.Map<java.lang.String, java.lang.Object>, com.seeyon.boot.transport.Sort, java.lang.String, java.util.List<java.lang.String>);
```

### `SelectFuncByDynamicConditionMapper`（1 方法）

`com.seeyon.boot.starter.mybatis.mapper.SelectFuncByDynamicConditionMapper`

```java
    java.lang.String selectListFuncByDynamicConditions(java.util.LinkedHashMap<java.lang.String, java.lang.Object>, com.seeyon.boot.transport.Sort, java.lang.String, java.util.List<java.lang.String>);
```

### `UpdateByConditionMapper`（1 方法）

`com.seeyon.boot.starter.mybatis.mapper.UpdateByConditionMapper`

```java
    int updateByConditions(T, java.util.Set<java.lang.String>, java.util.Map<java.lang.String, java.lang.Object>);
```

### `SeeyonSensitive`（1 方法）

`com.seeyon.boot.starter.mybatis.sensitive.SeeyonSensitive`

```java
    java.lang.String sensitiveProcess(java.lang.String);
```

### `DateParser`（1 方法）

`com.seeyon.boot.starter.mybatis.util.DateParser`

```java
    default java.lang.Object parser(java.lang.Object);
```

### `AllInOneBaseMybatisDao`（0 方法）

`com.seeyon.boot.starter.mybatis.inone.dao.AllInOneBaseMybatisDao`

```java
```

## 二、关键类（18）

### `AbstractAllInOneBaseDao`（55 方法）

`com.seeyon.boot.starter.mybatis.AbstractAllInOneBaseDao`

```java
    static private static void notSupportedException();
    private void putThreadContext();
    private java.lang.Class<T> getT();
    private void removeThreadContext();
    int create(java.lang.Object);
    int createBatch(java.util.List);
    int createBatchNoClob(java.util.List);
    int createBatchIgnoreTime(java.util.List);
    int update(java.lang.Object);
    int versionNoUpdateIgnoreVersion(java.lang.Object);
    int updateColumns(java.lang.Object, java.util.Set);
    int updateColumnsIgnoreVersion(java.lang.Object, java.util.Set);
    int updateBatch(java.util.List);
    int updateBatchIgnoreTime(java.util.List);
    int updateBatchIgnoreVersion(java.util.List);
    int versionNoUpdateBatchIgnoreVersion(java.util.List);
    int deleteById(java.lang.Long);
    int deleteByIds(java.util.List);
    int deleteByConditions(java.util.Map);
    int deleteByCondition(java.lang.String, java.lang.Object);
    int deleteByWrapper(com.seeyon.boot.domain.dao.Wrapper);
    T selectById(java.lang.Long);
    java.util.List selectByIds(java.util.List);
    T selectOneByCondition(java.lang.String, java.lang.Object);
    T selectOneByConditions(java.util.Map);
    int selectCountByCondition(java.lang.String, java.lang.Object);
    int selectCountByConditions(java.util.Map);
    java.util.List selectListByCondition(java.lang.String, java.lang.Object, com.seeyon.boot.transport.Sort);
    java.util.List selectListByConditions(java.util.Map, com.seeyon.boot.transport.Sort);
    com.seeyon.boot.transport.PageData selectPageByCondition(com.seeyon.boot.transport.PageInfo, java.lang.String, java.lang.Object, com.seeyon.boot.transport.Sort);
    java.lang.Object selectOneByWrapper(com.seeyon.boot.domain.dao.Wrapper);
    int selectCountByWrapper(com.seeyon.boot.domain.dao.Wrapper);
    java.util.List selectListByWrapper(com.seeyon.boot.domain.dao.Wrapper);
    com.seeyon.boot.transport.PageData selectPageByWrapper(com.seeyon.boot.transport.PageInfo, com.seeyon.boot.domain.dao.Wrapper);
    com.seeyon.boot.transport.PageData selectPageByConditions(com.seeyon.boot.transport.PageInfo, java.util.Map, com.seeyon.boot.transport.Sort);
    com.seeyon.boot.transport.PageData selectPageExcludeByConditions(com.seeyon.boot.transport.PageInfo, java.lang.String[], java.util.Map, com.seeyon.boot.transport.Sort);
    com.seeyon.boot.transport.PageData selectPagePropertiesByConditions(com.seeyon.boot.transport.PageInfo, java.lang.String[], java.util.Map, com.seeyon.boot.transport.Sort);
    java.util.List selectListExcludeByConditions(java.lang.String[], java.util.Map, com.seeyon.boot.transport.Sort);
    java.util.List selectListPropertiesByConditions(java.lang.String[], java.util.Map, com.seeyon.boot.transport.Sort);
    int selectCountByComplexConditions(java.util.LinkedHashMap);
    java.util.List selectListByComplexConditions(java.util.LinkedHashMap, com.seeyon.boot.transport.Sort);
    com.seeyon.boot.transport.PageData selectPageByComplexConditions(com.seeyon.boot.transport.PageInfo, java.util.LinkedHashMap, com.seeyon.boot.transport.Sort);
    java.lang.String selectListFuncByComplexConditions(java.util.LinkedHashMap, com.seeyon.boot.transport.Sort, java.lang.String, java.util.List);
    int deleteByComplexConditions(java.util.Map);
    int selectCountByDynamicConditions(java.util.LinkedHashMap);
    java.util.List selectListByDynamicConditions(java.util.LinkedHashMap, com.seeyon.boot.transport.Sort);
    com.seeyon.boot.transport.PageData selectPageByDynamicConditions(com.seeyon.boot.transport.PageInfo, java.util.LinkedHashMap, com.seeyon.boot.transport.Sort);
    java.lang.String selectListFuncByDynamicConditions(java.util.LinkedHashMap, com.seeyon.boot.transport.Sort, java.lang.String, java.util.List);
    int deleteByDynamicConditions(java.util.Map);
    private int getFieldCount(java.util.List);
    int selectCountByDynamicConditions(java.util.List);
    java.util.List selectListByDynamicConditions(java.util.List, com.seeyon.boot.transport.Sort);
    com.seeyon.boot.transport.PageData selectPageByDynamicConditions(com.seeyon.boot.transport.PageInfo, java.util.List, com.seeyon.boot.transport.Sort);
    java.lang.String selectListFuncByDynamicConditions(java.util.List, com.seeyon.boot.transport.Sort, java.lang.String, java.util.List);
    int deleteByDynamicConditions(java.util.List);
```

### `DynamicAllInOneDaoService`（44 方法）

`com.seeyon.boot.starter.mybatis.service.DynamicAllInOneDaoService`

```java
    void onApplicationEvent(com.seeyon.boot.event.ModuleUnloadEvent);
    java.lang.Class<?> getT(java.lang.String, java.lang.String);
    int create(java.lang.Object, java.lang.String, java.lang.String);
    int createBatch(java.util.List, java.lang.String, java.lang.String);
    int update(java.lang.Object, java.lang.String, java.lang.String);
    int versionNoUpdateIgnoreVersion(java.lang.Object, java.lang.String, java.lang.String);
    int updateColumns(java.lang.Object, java.util.Set, java.lang.String, java.lang.String);
    int updateBatch(java.util.List, java.lang.String, java.lang.String);
    int versionNoUpdateBatchIgnoreVersion(java.util.List, java.lang.String, java.lang.String);
    int deleteById(java.lang.Long, java.lang.String, java.lang.String);
    int deleteByIds(java.util.List, java.lang.String, java.lang.String);
    int deleteByConditions(java.util.Map, java.lang.String, java.lang.String);
    int deleteByCondition(java.lang.String, java.lang.Object, java.lang.String, java.lang.String);
    java.lang.Object selectById(java.lang.Long, java.lang.String, java.lang.String);
    java.util.List selectByIds(java.util.List, java.lang.String, java.lang.String);
    java.lang.Object selectOneByCondition(java.lang.String, java.lang.Object, java.lang.String, java.lang.String);
    java.lang.Object selectOneByConditions(java.util.Map, java.lang.String, java.lang.String);
    int selectCountByCondition(java.lang.String, java.lang.Object, java.lang.String, java.lang.String);
    int selectCountByConditions(java.util.Map, java.lang.String, java.lang.String);
    java.util.List selectListByCondition(java.lang.String, java.lang.Object, com.seeyon.boot.transport.Sort, java.lang.String, java.lang.String);
    java.util.List selectListByConditions(java.util.Map, com.seeyon.boot.transport.Sort, java.lang.String, java.lang.String);
    com.seeyon.boot.transport.PageData selectPageByCondition(com.seeyon.boot.transport.PageInfo, java.lang.String, java.lang.Object, com.seeyon.boot.transport.Sort, java.lang.String, java.lang.String);
    com.seeyon.boot.transport.PageData selectPageByConditions(com.seeyon.boot.transport.PageInfo, java.util.Map, com.seeyon.boot.transport.Sort, java.lang.String, java.lang.String);
    com.seeyon.boot.transport.PageData selectPageExcludeByConditions(com.seeyon.boot.transport.PageInfo, java.lang.String[], java.util.Map, com.seeyon.boot.transport.Sort, java.lang.String, java.lang.String);
    com.seeyon.boot.transport.PageData selectPagePropertiesByConditions(com.seeyon.boot.transport.PageInfo, java.lang.String[], java.util.Map, com.seeyon.boot.transport.Sort, java.lang.String, java.lang.String);
    java.util.List selectListExcludeByConditions(java.lang.String[], java.util.Map, com.seeyon.boot.transport.Sort, java.lang.String, java.lang.String);
    java.util.List selectListPropertiesByConditions(java.lang.String[], java.util.Map, com.seeyon.boot.transport.Sort, java.lang.String, java.lang.String);
    int selectCountByComplexConditions(java.util.LinkedHashMap, java.lang.String, java.lang.String);
    java.util.List selectListByComplexConditions(java.util.LinkedHashMap, com.seeyon.boot.transport.Sort, java.lang.String, java.lang.String);
    java.lang.String selectListFuncByComplexConditions(java.util.LinkedHashMap, com.seeyon.boot.transport.Sort, java.lang.String, java.util.List, java.lang.String, java.lang.String);
    com.seeyon.boot.transport.PageData selectPageByComplexConditions(com.seeyon.boot.transport.PageInfo, java.util.LinkedHashMap, com.seeyon.boot.transport.Sort, java.lang.String, java.lang.String);
    int deleteByComplexConditions(java.util.Map, java.lang.String, java.lang.String);
    int selectCountByDynamicConditions(java.util.LinkedHashMap, java.lang.String, java.lang.String);
    java.util.List selectListByDynamicConditions(java.util.LinkedHashMap, com.seeyon.boot.transport.Sort, java.lang.String, java.lang.String);
    com.seeyon.boot.transport.PageData selectPageByDynamicConditions(com.seeyon.boot.transport.PageInfo, java.util.LinkedHashMap, com.seeyon.boot.transport.Sort, java.lang.String, java.lang.String);
    java.lang.String selectListFuncByDynamicConditions(java.util.LinkedHashMap, com.seeyon.boot.transport.Sort, java.lang.String, java.util.List, java.lang.String, java.lang.String);
    int deleteByDynamicConditions(java.util.Map, java.lang.String, java.lang.String);
    int selectCountByDynamicConditions(java.util.List, java.lang.String, java.lang.String);
    java.util.List selectListByDynamicConditions(java.util.List, com.seeyon.boot.transport.Sort, java.lang.String, java.lang.String);
    com.seeyon.boot.transport.PageData selectPageByDynamicConditions(com.seeyon.boot.transport.PageInfo, java.util.List, com.seeyon.boot.transport.Sort, java.lang.String, java.lang.String);
    java.lang.String selectListFuncByDynamicConditions(java.util.List, com.seeyon.boot.transport.Sort, java.lang.String, java.util.List, java.lang.String, java.lang.String);
    int deleteByDynamicConditions(java.util.List, java.lang.String, java.lang.String);
    private int getFieldCount(java.util.List);
    void onApplicationEvent(org.springframework.context.ApplicationEvent);
```

### `AllInOneJdbcDao`（43 方法）

`com.seeyon.boot.starter.mybatis.service.AllInOneJdbcDao`

```java
    int create(java.lang.Object, java.lang.Class<?>);
    int createBatch(java.util.List, java.lang.Class<?>);
    int update(java.lang.Object, java.lang.Class<?>);
    int updateColumns(java.lang.Object, java.util.Set, java.lang.Class<?>);
    int updateColumnsIgnoreVersion(java.lang.Object, java.util.Set, java.lang.Class<?>);
    int versionNoUpdateIgnoreVersion(java.lang.Object, java.lang.Class<?>);
    int updateBatch(java.util.List, java.lang.Class<?>);
    int versionNoUpdateBatchIgnoreVersion(java.util.List, java.lang.Class<?>);
    int deleteById(java.lang.Long, java.lang.Class<?>);
    int deleteByCondition(java.lang.String, java.lang.Object, java.lang.Class<?>);
    int deleteByConditions(java.util.Map<java.lang.String, java.lang.Object>, java.lang.Class<?>);
    int deleteByIds(java.util.List, java.lang.Class<?>);
    java.lang.Object selectById(java.lang.Long, java.lang.Class<?>);
    java.lang.Object selectOneByCondition(java.lang.String, java.lang.Object, java.lang.Class<?>);
    int selectCountByCondition(java.lang.String, java.lang.Object, java.lang.Class<?>);
    java.util.List selectListByCondition(java.lang.String, java.lang.Object, com.seeyon.boot.transport.Sort, java.lang.Class<?>);
    com.seeyon.boot.transport.PageData selectPageByCondition(com.seeyon.boot.transport.PageInfo, java.lang.String, java.lang.Object, com.seeyon.boot.transport.Sort, java.lang.Class<?>);
    com.seeyon.boot.transport.PageData selectPageExcludeByConditions(com.seeyon.boot.transport.PageInfo, java.lang.String[], java.util.Map, com.seeyon.boot.transport.Sort, java.lang.Class<?>);
    com.seeyon.boot.transport.PageData selectPagePropertiesByConditions(com.seeyon.boot.transport.PageInfo, java.lang.String[], java.util.Map, com.seeyon.boot.transport.Sort, java.lang.Class<?>);
    com.seeyon.boot.transport.PageData selectPageByConditions(com.seeyon.boot.transport.PageInfo, java.util.Map, com.seeyon.boot.transport.Sort, java.lang.Class<?>);
    java.util.List selectListExcludeByConditions(java.lang.String[], java.util.Map, com.seeyon.boot.transport.Sort, java.lang.Class<?>);
    java.util.List selectListPropertiesByConditions(java.lang.String[], java.util.Map, com.seeyon.boot.transport.Sort, java.lang.Class<?>);
    java.util.List selectListByConditions(java.util.Map, com.seeyon.boot.transport.Sort, java.lang.Class<?>);
    int selectCountByConditions(java.util.Map, java.lang.Class<?>);
    java.lang.Object selectOneByConditions(java.util.Map, java.lang.Class<?>);
    java.util.List selectByIds(java.util.List, java.lang.Class<?>);
    int selectCountByComplexConditions(java.util.LinkedHashMap, java.lang.Class<?>);
    java.util.List selectListByComplexConditions(java.util.LinkedHashMap, com.seeyon.boot.transport.Sort, java.lang.Class<?>);
    com.seeyon.boot.transport.PageData selectPageByComplexConditions(com.seeyon.boot.transport.PageInfo, java.util.LinkedHashMap, com.seeyon.boot.transport.Sort, java.lang.Class<?>);
    java.lang.String selectListFuncByComplexConditions(java.util.LinkedHashMap, com.seeyon.boot.transport.Sort, java.lang.String, java.util.List, java.lang.Class<?>);
    int deleteByComplexConditions(java.util.Map, java.lang.Class<?>);
    int selectCountByDynamicConditions(java.util.LinkedHashMap, java.lang.Class<?>);
    java.util.List selectListByDynamicConditions(java.util.LinkedHashMap, com.seeyon.boot.transport.Sort, java.lang.Class<?>);
    com.seeyon.boot.transport.PageData selectPageByDynamicConditions(com.seeyon.boot.transport.PageInfo, java.util.LinkedHashMap, com.seeyon.boot.transport.Sort, java.lang.Class<?>);
    java.lang.String selectListFuncByDynamicConditions(java.util.LinkedHashMap, com.seeyon.boot.transport.Sort, java.lang.String, java.util.List, java.lang.Class<?>);
    int deleteByDynamicConditions(java.util.Map, java.lang.Class<?>);
    int selectCountByDynamicConditions(java.util.List<com.seeyon.boot.starter.mybatis.util.SeeyonKeyMap>, java.lang.Class<?>);
    java.util.List selectListByDynamicConditions(java.util.List<com.seeyon.boot.starter.mybatis.util.SeeyonKeyMap>, com.seeyon.boot.transport.Sort, java.lang.Class<?>);
    com.seeyon.boot.transport.PageData selectPageByDynamicConditions(com.seeyon.boot.transport.PageInfo, java.util.List<com.seeyon.boot.starter.mybatis.util.SeeyonKeyMap>, com.seeyon.boot.transport.Sort, java.lang.Class<?>);
    java.lang.String selectListFuncByDynamicConditions(java.util.List<com.seeyon.boot.starter.mybatis.util.SeeyonKeyMap>, com.seeyon.boot.transport.Sort, java.lang.String, java.util.List, java.lang.Class<?>);
    int deleteByDynamicConditions(java.util.List<com.seeyon.boot.starter.mybatis.util.SeeyonKeyMap>, java.lang.Class<?>);
    private java.lang.String[] excludeColumns(java.lang.String[], java.util.Map<java.lang.String, java.lang.String>);
    private void secretCheck(java.lang.Object);
```

### `AllInOneDBUtil`（22 方法）

`com.seeyon.boot.starter.mybatis.service.AllInOneDBUtil`

```java
    int insertBatch(java.util.List, java.lang.Class<?>, java.lang.Boolean);
    int updateBatchByIds(java.util.List, java.util.Set<java.lang.String>, java.lang.Boolean, java.lang.Boolean, java.lang.Class<?>);
    int delete(java.util.Map<java.lang.String, java.lang.Object>, java.lang.Boolean, java.lang.Class<?>);
    int deleteIds(java.util.List<java.lang.Long>, java.lang.Class<?>);
    java.util.List<java.util.Map<java.lang.String, java.lang.Object>> selectSql(com.seeyon.boot.transport.PageInfo, java.lang.String, java.util.Map<java.lang.String, java.lang.Object>);
    java.util.List<java.lang.Object> selectBatch(java.lang.String[], java.util.Map<java.lang.String, java.lang.Object>, java.lang.Boolean, com.seeyon.boot.transport.PageInfo, com.seeyon.boot.transport.Sort, java.lang.Class<?>);
    java.util.List<java.lang.Object> selectBatch(java.lang.String[], java.util.Map<java.lang.String, java.lang.Object>, java.lang.Boolean, com.seeyon.boot.transport.PageInfo, com.seeyon.boot.transport.Sort, java.lang.Class<?>, java.lang.String);
    java.util.List<java.lang.Object> selectBatchAsync(java.lang.String[], java.util.Map<java.lang.String, java.lang.Object>, com.seeyon.boot.transport.PageInfo, com.seeyon.boot.transport.Sort, java.lang.Class<?>, java.lang.String);
    private java.util.List<java.lang.String> getSqlSplitList(java.lang.String);
    int selectCount(java.util.Map<java.lang.String, java.lang.Object>, java.lang.Boolean, java.lang.Class<?>);
    private void jdbcCondition(java.lang.StringBuilder, java.util.Map<java.lang.String, java.lang.Object>, java.util.Map<java.lang.String, java.lang.Object>, java.lang.Class<?>);
    private java.lang.String whereMatcher(java.lang.String);
    private java.lang.String buildQueryString(java.lang.String, java.lang.String[], java.util.Map<java.lang.String, java.lang.String>, java.lang.String, com.seeyon.boot.transport.PageInfo, com.seeyon.boot.transport.Sort, java.lang.Class<?>);
    private java.lang.String buildCountQueryString(java.lang.String, java.lang.String);
    private void getSortSql(com.seeyon.boot.transport.Sort, java.lang.StringBuilder, java.lang.Class<?>);
    private java.lang.String getPageSql(com.seeyon.boot.transport.PageInfo, java.lang.String);
    private void appendClause(java.lang.StringBuilder, java.lang.String);
    private void appendColumns(java.lang.StringBuilder, java.lang.String[], java.util.Map<java.lang.String, java.lang.String>);
    private void appendColumns(java.lang.StringBuilder, java.util.Map<java.lang.String, java.lang.String>);
    private void copyMap(java.util.Map<java.lang.String, java.lang.Object>, java.util.Map<java.lang.String, java.lang.Object>, java.util.Map<java.lang.String, java.lang.String>);
```

### `SeeyonScriptUtils`（16 方法）

`com.seeyon.boot.starter.mybatis.util.SeeyonScriptUtils`

```java
    static void executeSqlScript(java.sql.Connection, org.springframework.core.io.Resource)
    static void executeSqlScript(java.sql.Connection, org.springframework.core.io.support.EncodedResource)
    static java.util.List<java.util.Map<java.lang.String, java.lang.String>> executeSqlScript(java.sql.Connection, org.springframework.core.io.support.EncodedResource, boolean)
    static java.util.List<java.util.Map<java.lang.String, java.lang.String>> executeSqlScript(java.sql.Connection, org.springframework.core.io.support.EncodedResource, boolean, boolean, boolean, java.lang.String, java.lang.String, java.lang.String, java.lang.String)
    static java.util.List<java.util.Map<java.lang.String, java.lang.String>> executeSqlScript(java.sql.Connection, org.springframework.core.io.support.EncodedResource, boolean, boolean, boolean, java.lang.String[], java.lang.String, java.lang.String, java.lang.String)
    static java.lang.String readScript(org.springframework.core.io.support.EncodedResource, java.lang.String, java.lang.String[], java.lang.String)
    static java.lang.String readScript(java.io.LineNumberReader, java.lang.String, java.lang.String, java.lang.String)
    static java.lang.String readScript(java.io.LineNumberReader, java.lang.String[], java.lang.String, java.lang.String)
    static private static void appendSeparatorToScriptIfNecessary(java.lang.StringBuilder, java.lang.String);
    static boolean containsSqlScriptDelimiters(java.lang.String, java.lang.String);
    static private static boolean containsStatementSeparator(org.springframework.core.io.support.EncodedResource, java.lang.String, java.lang.String, java.lang.String[], java.lang.String, java.lang.String)
    static void splitSqlScript(java.lang.String, char, java.util.List<java.lang.String>)
    static void splitSqlScript(java.lang.String, java.lang.String, java.util.List<java.lang.String>)
    static void splitSqlScript(org.springframework.core.io.support.EncodedResource, java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.util.List<java.lang.String>)
    static void splitSqlScript(org.springframework.core.io.support.EncodedResource, java.lang.String, java.lang.String, java.lang.String[], java.lang.String, java.lang.String, java.util.List<java.lang.String>)
    static private static boolean startsWithAny(java.lang.String, java.lang.String[], int);
```

### `AllInOneDBComplexUtil`（15 方法）

`com.seeyon.boot.starter.mybatis.service.AllInOneDBComplexUtil`

```java
    java.util.List<java.lang.Object> selectComplex(java.lang.String[], java.util.Map<java.lang.String, java.lang.Object>, java.lang.Boolean, com.seeyon.boot.transport.PageInfo, com.seeyon.boot.transport.Sort, java.lang.Class<?>);
    int selectComplexCount(java.util.Map<java.lang.String, java.lang.Object>, java.lang.Boolean, com.seeyon.boot.transport.PageInfo, com.seeyon.boot.transport.Sort, java.lang.Class<?>);
    java.lang.String selectComplexFunc(java.util.Map<java.lang.String, java.lang.Object>, java.lang.Boolean, com.seeyon.boot.transport.PageInfo, com.seeyon.boot.transport.Sort, java.lang.String, java.util.List, java.lang.Class<?>);
    int deleteComplex(java.util.Map<java.lang.String, java.lang.Object>, java.lang.Boolean, java.lang.Class<?>);
    private void tenantAdd(java.util.Map<java.lang.String, java.lang.Object>, java.lang.Boolean);
    private void jdbcComplexCondition(java.lang.StringBuilder, java.util.Map<java.lang.String, java.lang.Object>, java.util.Map<java.lang.String, java.lang.Object>, java.lang.Class<?>);
    private java.lang.String whereMatcher(java.lang.String);
    private java.lang.String buildQueryString(java.lang.String, java.lang.String[], java.util.Map<java.lang.String, java.lang.String>, java.lang.String, com.seeyon.boot.transport.PageInfo, com.seeyon.boot.transport.Sort, java.lang.Class<?>);
    private java.lang.String buildFuncQueryString(java.lang.String, java.lang.String, com.seeyon.boot.transport.PageInfo, com.seeyon.boot.transport.Sort, java.lang.String, java.util.List, java.lang.Class<?>);
    private java.lang.String buildCountQueryString(java.lang.String, java.lang.String, com.seeyon.boot.transport.PageInfo, com.seeyon.boot.transport.Sort, java.lang.Class<?>);
    private void getSortSql(com.seeyon.boot.transport.Sort, java.lang.StringBuilder, java.lang.Class<?>);
    private java.lang.String getPageSql(com.seeyon.boot.transport.PageInfo, java.lang.String);
    private void appendClause(java.lang.StringBuilder, java.lang.String);
    private void appendColumns(java.lang.StringBuilder, java.lang.String[], java.util.Map<java.lang.String, java.lang.String>);
    private void appendColumns(java.lang.StringBuilder, java.util.Map<java.lang.String, java.lang.String>);
```

### `AllInOneDBDynamicSeeyonKeyMapUtil`（15 方法）

`com.seeyon.boot.starter.mybatis.service.AllInOneDBDynamicSeeyonKeyMapUtil`

```java
    java.util.List<java.lang.Object> selectDynamic(java.lang.String[], java.util.List<com.seeyon.boot.starter.mybatis.util.SeeyonKeyMap>, java.lang.Boolean, com.seeyon.boot.transport.PageInfo, com.seeyon.boot.transport.Sort, java.lang.Class<?>);
    int selectDynamicCount(java.util.List<com.seeyon.boot.starter.mybatis.util.SeeyonKeyMap>, java.lang.Boolean, com.seeyon.boot.transport.PageInfo, com.seeyon.boot.transport.Sort, java.lang.Class<?>);
    java.lang.String selectDynamicFunc(java.util.List<com.seeyon.boot.starter.mybatis.util.SeeyonKeyMap>, java.lang.Boolean, com.seeyon.boot.transport.PageInfo, com.seeyon.boot.transport.Sort, java.lang.String, java.util.List, java.lang.Class<?>);
    int deleteDynamic(java.util.List<com.seeyon.boot.starter.mybatis.util.SeeyonKeyMap>, java.lang.Boolean, java.lang.Class<?>);
    private void tenantAdd(java.util.List<com.seeyon.boot.starter.mybatis.util.SeeyonKeyMap>, java.lang.Boolean);
    private void jdbcDynamicCondition(java.lang.StringBuilder, java.util.List<com.seeyon.boot.starter.mybatis.util.SeeyonKeyMap>, java.util.Map<java.lang.String, java.lang.Object>, java.lang.Class<?>, com.seeyon.boot.starter.mybatis.util.SeeyonInteger);
    private java.lang.String whereMatcher(java.lang.String);
    private java.lang.String buildQueryString(java.lang.String, java.lang.String[], java.util.Map<java.lang.String, java.lang.String>, java.lang.String, com.seeyon.boot.transport.PageInfo, com.seeyon.boot.transport.Sort, java.lang.Class<?>);
    private java.lang.String buildFuncQueryString(java.lang.String, java.lang.String, com.seeyon.boot.transport.PageInfo, com.seeyon.boot.transport.Sort, java.lang.String, java.util.List, java.lang.Class<?>);
    private java.lang.String buildCountQueryString(java.lang.String, java.lang.String, com.seeyon.boot.transport.PageInfo, com.seeyon.boot.transport.Sort, java.lang.Class<?>);
    private void getSortSql(com.seeyon.boot.transport.Sort, java.lang.StringBuilder, java.lang.Class<?>);
    private java.lang.String getPageSql(com.seeyon.boot.transport.PageInfo, java.lang.String);
    private void appendClause(java.lang.StringBuilder, java.lang.String);
    private void appendColumns(java.lang.StringBuilder, java.lang.String[], java.util.Map<java.lang.String, java.lang.String>);
    private void appendColumns(java.lang.StringBuilder, java.util.Map<java.lang.String, java.lang.String>);
```

### `AllInOneDBDynamicUtil`（15 方法）

`com.seeyon.boot.starter.mybatis.service.AllInOneDBDynamicUtil`

```java
    java.util.List<java.lang.Object> selectDynamic(java.lang.String[], java.util.Map<java.lang.String, java.lang.Object>, java.lang.Boolean, com.seeyon.boot.transport.PageInfo, com.seeyon.boot.transport.Sort, java.lang.Class<?>);
    int selectDynamicCount(java.util.Map<java.lang.String, java.lang.Object>, java.lang.Boolean, com.seeyon.boot.transport.PageInfo, com.seeyon.boot.transport.Sort, java.lang.Class<?>);
    java.lang.String selectDynamicFunc(java.util.Map<java.lang.String, java.lang.Object>, java.lang.Boolean, com.seeyon.boot.transport.PageInfo, com.seeyon.boot.transport.Sort, java.lang.String, java.util.List, java.lang.Class<?>);
    int deleteDynamic(java.util.Map<java.lang.String, java.lang.Object>, java.lang.Boolean, java.lang.Class<?>);
    private void tenantAdd(java.util.Map<java.lang.String, java.lang.Object>, java.lang.Boolean);
    private void jdbcDynamicCondition(java.lang.StringBuilder, java.util.Map<java.lang.String, java.lang.Object>, java.util.Map<java.lang.String, java.lang.Object>, java.lang.Class<?>, com.seeyon.boot.starter.mybatis.util.SeeyonInteger);
    private java.lang.String whereMatcher(java.lang.String);
    private java.lang.String buildQueryString(java.lang.String, java.lang.String[], java.util.Map<java.lang.String, java.lang.String>, java.lang.String, com.seeyon.boot.transport.PageInfo, com.seeyon.boot.transport.Sort, java.lang.Class<?>);
    private java.lang.String buildFuncQueryString(java.lang.String, java.lang.String, com.seeyon.boot.transport.PageInfo, com.seeyon.boot.transport.Sort, java.lang.String, java.util.List, java.lang.Class<?>);
    private java.lang.String buildCountQueryString(java.lang.String, java.lang.String, com.seeyon.boot.transport.PageInfo, com.seeyon.boot.transport.Sort, java.lang.Class<?>);
    private void getSortSql(com.seeyon.boot.transport.Sort, java.lang.StringBuilder, java.lang.Class<?>);
    private java.lang.String getPageSql(com.seeyon.boot.transport.PageInfo, java.lang.String);
    private void appendClause(java.lang.StringBuilder, java.lang.String);
    private void appendColumns(java.lang.StringBuilder, java.lang.String[], java.util.Map<java.lang.String, java.lang.String>);
    private void appendColumns(java.lang.StringBuilder, java.util.Map<java.lang.String, java.lang.String>);
```

### `PermissionCheckUtil`（11 方法）

`com.seeyon.boot.starter.mybatis.util.PermissionCheckUtil`

```java
    static protected static boolean sqlValidate(java.lang.String);
    static java.lang.String convertSql(java.lang.String, java.lang.String, java.lang.String);
    static private static java.lang.String buildSqlConditionItem(java.lang.Object, java.lang.String, java.lang.String);
    static private static java.lang.String buildSqlForOrAnd(java.lang.Object, java.lang.String, java.lang.String, java.lang.String);
    static private static java.lang.String buildSqlForOrAndGetItemKey(java.lang.Object);
    static private static java.lang.Object buildSqlForOrAndGetItemValue(java.lang.Object);
    static private static java.lang.String buildSqlForAttribute(java.lang.String, java.lang.String, java.lang.String, java.lang.String);
    static java.lang.Object dateParser(java.lang.Class<?>, java.lang.String, java.lang.String);
    static private static java.lang.Class<?> getTableColumnType(java.lang.String, java.lang.String);
    static private static java.lang.String getTableColumnName(java.lang.String, java.lang.String);
```

### `DataSignRuleService`（10 方法）

`com.seeyon.boot.starter.mybatis.service.DataSignRuleService`

```java
    com.seeyon.boot.starter.mybatis.model.DataSignRuleMessageModel getMessageRule(java.lang.String);
    java.lang.String getRule();
    java.util.LinkedList<java.lang.String> getSignField(java.lang.String);
    java.lang.Boolean enable();
    void update();
    void run()
    void ruleCacheUpdate();
    void enableCacheUpdate();
    private java.lang.String getEnableKey();
    private java.lang.String getRuleKey();
```

### `ExSqlHelper`（10 方法）

`com.seeyon.boot.starter.mybatis.util.ExSqlHelper`

```java
    static java.lang.String wherePKColumns(java.lang.Class<?>, java.lang.String, boolean);
    static java.lang.String whereVersion(java.lang.Class<?>, java.lang.String);
    static java.lang.String exampleSelectColumns(java.lang.Class<?>);
    static java.lang.String exampleCountColumn(java.lang.Class<?>);
    static java.lang.String exampleOrderBy(java.lang.Class<?>);
    static java.lang.String exampleOrderBy(java.lang.String, java.lang.Class<?>);
    static java.lang.String exampleForUpdate();
    static java.lang.String exampleCheck(java.lang.Class<?>);
    static java.lang.String exampleWhereClause();
    static java.lang.String updateByExampleWhereClause();
```

### `AllInOneDataParseUtil`（7 方法）

`com.seeyon.boot.starter.mybatis.service.AllInOneDataParseUtil`

```java
    java.util.List<java.lang.Object> parseData(java.util.List<java.util.Map<java.lang.String, java.lang.Object>>, java.lang.Class<?>, java.util.Map<java.lang.String, java.lang.reflect.Field>);
    private void process(java.lang.Object, java.util.List<com.seeyon.boot.starter.mybatis.support.SafeField>);
    private void reversibleDecrypt(com.seeyon.boot.starter.mybatis.support.SafeField, java.lang.Object);
    java.lang.Object fieldParse(java.lang.Object, java.lang.Class<?>, java.lang.String, java.util.Map<java.lang.String, java.lang.reflect.Field>);
    private java.lang.Object dataParser(java.lang.Class<?>, java.lang.Object, java.lang.String, java.lang.Class<?>);
    private java.lang.Object parseIntegerField(java.lang.Class, java.lang.Object);
```

### `SeeyonSqlHelper`（7 方法）

`com.seeyon.boot.starter.mybatis.util.SeeyonSqlHelper`

```java
    static java.lang.Object valueParser(java.lang.Object, tk.mybatis.mapper.entity.EntityColumn);
    static java.lang.Object valueParser(java.lang.Object, java.lang.Class<?>);
    static java.lang.String updateSetColumns(java.lang.Class<?>, java.lang.String, boolean, boolean);
    static java.lang.String updateSetColumns(java.lang.Class<?>, java.lang.String, boolean, boolean, java.util.Set<java.lang.String>);
    static java.lang.String getIfNotNull(java.lang.String, tk.mybatis.mapper.entity.EntityColumn, java.lang.String, boolean);
    static java.lang.String logicDeleteColumnEqualsValue(tk.mybatis.mapper.entity.EntityColumn, boolean);
    static int getLogicDeletedValue(tk.mybatis.mapper.entity.EntityColumn, boolean);
```

### `DataSignService`（6 方法）

`com.seeyon.boot.starter.mybatis.encrypt.DataSignService`

```java
    java.lang.Boolean envEnable();
    java.util.Map<java.lang.String, java.lang.String> SignatureList(java.util.List<java.lang.String>);
    java.lang.String Signature(java.lang.String);
    java.lang.Boolean Verify(java.lang.String, java.lang.String);
    java.util.Map<java.lang.String, java.lang.Boolean> VerifyList(java.util.Map<java.lang.String, java.lang.String>);
    void setDataSignExecution(com.seeyon.boot.spi.DataSignExecution);
```

### `ObjToMapUtil`（6 方法）

`com.seeyon.boot.starter.mybatis.util.ObjToMapUtil`

```java
    static void remove(java.lang.Class);
    static java.util.Map<java.lang.String, java.lang.Object> objectToMap(java.lang.Object);
    static private static java.lang.String lowerFirst(java.lang.String);
    static java.util.Map<java.lang.String, java.lang.Object> objectToMap(java.lang.Object, java.lang.Boolean);
    static <T> T mapToObject(java.util.Map<java.lang.String, java.lang.Object>, java.lang.Class<T>);
    static private static <T> void setFieldValue(T, java.lang.String, java.lang.Object)
```

### `SQLWildcardUtil`（6 方法）

`com.seeyon.boot.starter.mybatis.util.SQLWildcardUtil`

```java
    static private static void initEscape();
    static java.lang.String escape(java.lang.String);
    static boolean requireEscape(java.lang.String);
    static java.lang.String setEscapeCharacter();
    static java.lang.String likeLowerCase(java.lang.String);
    static java.lang.String chineseOrderBy(java.lang.String);
```

### `ThreadLocalUtil`（6 方法）

`com.seeyon.boot.starter.mybatis.util.ThreadLocalUtil`

```java
    static <T> T get(java.lang.String);
    static <T> T get(java.lang.String, T);
    static void set(java.lang.String, java.lang.Object);
    static void remove();
```

### `DataSignMybatisService`（5 方法）

`com.seeyon.boot.starter.mybatis.encrypt.DataSignMybatisService`

```java
    java.lang.String sign(java.lang.Object);
    void verify(java.util.List);
    private void sendMessage(java.lang.Object);
    private java.lang.String getSignStr(java.lang.Object);
    private boolean enable();
```
