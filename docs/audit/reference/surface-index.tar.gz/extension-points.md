# UDC 扩展点落地表：接口 × 平台实现

> 自动生成，勿手改。`tools/core/platform/emit_extension_points.py` 重跑即可。
> 共 151 个带 abstract 的 UDC 接口，其中 **128 个是真接口**：**101 个平台已有实现**（可继承或参照），**27 个是纯扩展位**（零实现，自己全写）。
> 另 **23 个是注解（@interface）**，不是 implements 的对象，见文末。
> 「abstract」= 必须实现的方法个数；「impl」= 平台自带实现类个数。
> 重名接口（如 `BaseNode` / `BaseTrigger` / `Functor`）出现在不同包，implements 时认全名。

## 一、平台已有实现（101 个）—— 优先看 impl 多的，那是族主

| 接口 | abstract | impl | 代表实现类 | 接口所在包 |
|---|---|---|---|---|
| `CodeTask` | 1 | 52 | `AppBeanNameModifyerTask`, `AppBuildInfoTask`, `AppDependenciesTask` …+49 | `com.seeyon.udc.common.autocode` |
| `TransportHandler` | 1 | 32 | `AppCollaborationTransportHandler`, `AttributeGroupTransportHandler`, `AttributeSetTransportHandler` …+29 | `com.seeyon.udc.common.autocode.transport` |
| `Importable` | 1 | 29 | `ApplicationImporterBase`, `AttributeGroupImporterBase`, `AttributeSetImporterBase` …+26 | `com.seeyon.udc.common.autocode.transport.upgrade` |
| `AppMetaDataContextPostProcess` | 1 | 27 | `AppCollaborationPostProcessor`, `AppDependentMetaDataPostProcessor`, `BasicDataMetaDataPostProcessor` …+24 | `com.seeyon.udc.common.metadata` |
| `ElementRepository` | 3 | 21 | `ApplicationRepository`, `AttributeRepository`, `AttributeSetRepository` …+18 | `com.seeyon.udc.model` |
| `SaveAsHandler` | 1 | 17 | `AboutToEntitySaveAsHandler`, `AboutToSupportSaveAsHandler`, `ApplicationSaveAsHandler` …+14 | `com.seeyon.udc.common.autocode.transport.saveas` |
| `BaseDesignMetadataQueryService` | 6 | 11 | `AbstractDesignMetadataQueryService`, `AggDesignMetadataQueryService`, `AggEntityDesignMetadataQueryService` …+8 | `com.seeyon.udc.metadata.query` |
| `DetectionMetadataAware` | 1 | 9 | `CtpJobDetectionMetadataAware`, `CtpParameterDetectionMetadataAware`, `CtpSerialSchemaDetectionMetadataAware` …+6 | `com.seeyon.udc.detection.context.metadata` |
| `Interpreter` | 1 | 9 | `BinaryInterpreter`, `EntityVariableInterpreter`, `ExpressionInterpreter` …+6 | `com.seeyon.udc.expression.codegen.interpreter` |
| `LastVersionMetadataManagerService` | 3 | 8 | `AttributeLastVersionMetadataService`, `AttributeSetAttributeLastVersionMetadataService`, `DefaultLastVersionMetadataService` …+5 | `com.seeyon.udc.api` |
| `DeployBeforeService` | 1 | 7 | `DependAppJarCheckService`, `DependAppVersionCheckService`, `DeployEnumCheckService` …+4 | `com.seeyon.udc.api` |
| `CopyHandler` | 2 | 7 | `AttributeCopyHandler`, `EntityCopyHandler`, `EntityRuleCopyHandler` …+4 | `com.seeyon.udc.entity.copy` |
| `MicroFlowSimpleComponentCascadeHandler` | 1 | 6 | `BaseSimpleArrayComponentCascadeHandler`, `BaseSimpleComponentCascadeHandler`, `DataMappingFieldCascadeHandler` …+3 | `com.seeyon.udc.microflow.cascade` |
| `TypeChangeSqlResolver` | 2 | 5 | `Date2DateTimeSqlResolver`, `Decimal2CurrencySqlResolver`, `MultiRelationType2MultiLineLongTextSqlResolver` …+2 | `com.seeyon.udc.autocode.db.resolver` |
| `CodeContextAware` | 1 | 5 | `BaseInfoCodeContextAware`, `DependCodeContextAware`, `DtoCodeContextAware` …+2 | `com.seeyon.udc.common.autocode.metadata` |
| `SplitHandler` | 1 | 5 | `ApplicationSplitHandler`, `CtpCommonSplitHandler`, `EntitySplitHandler` …+2 | `com.seeyon.udc.common.autocode.transport.coli` |
| `DetectionTask` | 2 | 5 | `AssociateDetectionTask`, `GanttChartDetectionTask`, `CtpQrCodeDetectionTask` …+2 | `com.seeyon.udc.detection` |
| `FrontDeployDetectionTask` | 1 | 5 | `AbstractPageFrontDeployDetectionTask`, `CtpEnumFrontDeployDetectionTask`, `CtpParameterDefinitionFrontDeployDetectionTask` …+2 | `com.seeyon.udc.detection` |
| `SourceDetectionSupport` | 3 | 5 | `CtpEnumSourceDetectionSupport`, `CtpSerialSourceDetectionSupport`, `EntitySourceDetectionSupport` …+2 | `com.seeyon.udc.detection.task.source` |
| `OperationRecordService` | 6 | 5 | `Entity4RecordService`, `FunctionNode4RecordService`, `PageInfo4RecordService` …+2 | `com.seeyon.udc.operationlog` |
| `TypeUpdateAuthChecker` | 2 | 4 | `Date2DateTimeTypeUpdateAuthChecker`, `Decimal2CurrencyTypeUpdateAuthChecker`, `SingleAttachment2MultiAttachmentUpdateChecker` …+1 | `com.seeyon.udc.auth.common.typechange` |
| `ConnectorFullNameExtractor` | 1 | 4 | `BusinessEventActivity`, `MapOperationActivity`, `AbstractCallMethodActivity` …+1 | `com.seeyon.udc.microflow.domain.bo.flow.activity.base` |
| `DynamicDependencyFullNameModifier` | 2 | 4 | `CallAppServiceActivity`, `ChangeVariableActivity`, `AbstractCreateActivity` …+1 | `com.seeyon.udc.microflow.domain.bo.flow.activity.base` |
| `ExtendAppOperationAuthCheck` | 1 | 3 | `FormAppHostAdminAuthCheck`, `RoleResourceAndDataPermissionAuthCheck`, `UdcDefaultExtendAppOperationAuthCheck` | `com.seeyon.udc.api` |
| `AppFeatureHandler` | 14 | 3 | `AbstractFormlAppFeatureHandler`, `AbstractNormalAppFeatureHandler`, `AppFeatureHandlerFacade` | `com.seeyon.udc.common.application.feature.handler` |
| `I18nHandler` | 1 | 3 | `MicroFlowBoI18nHandler`, `UdcEnumDtoI18nHandler`, `UdcEnumItemDtoI18nHandler` | `com.seeyon.udc.common.autocode.i18n` |
| `LambdaMeta` | 2 | 3 | `IdeaProxyLambdaMeta`, `ReflectLambdaMeta`, `ShadowLambdaMeta` | `com.seeyon.udc.common.support` |
| `DetectionRuleSupport` | 2 | 3 | `AbstractAttributeSetPartDetection`, `AbstractCtpParameterPartDetection`, `AbstractScalabilityOptionPartDetection` | `com.seeyon.udc.detection.task.rule` |
| `SourceDetectionSupportWrapper` | 1 | 3 | `AbstractAttributeSetPartDetection`, `AbstractCtpParameterPartDetection`, `AbstractScalabilityOptionPartDetection` | `com.seeyon.udc.detection.task.source` |
| `Code` | 2 | 3 | `Clazz`, `Method`, `Snippet` | `com.seeyon.udc.entity.stereotype.generator` |
| `Schema` | 2 | 3 | `Annotation`, `Field`, `Import` | `com.seeyon.udc.entity.stereotype.generator` |
| `DependencyAppServiceApiActivity` | 1 | 3 | `CallAppServiceActivity`, `CreateVariableActivity`, `AbstractEntityActivity` | `com.seeyon.udc.microflow.domain.bo.flow.activity.base` |
| `TenantDataFilter` | 1 | 2 | `DefaultTenantDataFilter`, `PageTenantDataFilter` | `com.seeyon.udc.common.autocode.transport` |
| `TypeHelper` | 6 | 2 | `DefaultTypeHelper`, `DecimalDataTypeHelper` | `com.seeyon.udc.common.datatype` |
| `MappingMode` | 11 | 2 | `AbstractGroupingFunctionMappingMode`, `AbstractMappingMode` | `com.seeyon.udc.common.mappingmode` |
| `AppContext` | 1 | 2 | `AppMetaDatableContext`, `AppSchemaContext` | `com.seeyon.udc.common.metadata` |
| `DataDictionaryBuilder` | 7 | 2 | `HtmlBuilder`, `MarkdownBuilder` | `com.seeyon.udc.document` |
| `MicroFlowLastVersionMetadataEnabler` | 4 | 2 | `MicroFlowEntity`, `MicroFlowDefinitionDto` | `com.seeyon.udc.domain` |
| `MicroFlowSchemaDeterminer` | 12 | 2 | `MicroFlowEntity`, `MicroFlowDefinitionDto` | `com.seeyon.udc.domain` |
| `Template` | 29 | 2 | `ExprCodeGenFullNameTemplate`, `ExprCodeGenTemplate` | `com.seeyon.udc.expression.codegen.common` |
| `MicroFlowSubComponentHandler` | 4 | 2 | `BaseSimpleArrayComponentCascadeHandler`, `BaseSimpleComponentCascadeHandler` | `com.seeyon.udc.microflow.cascade` |
| `BaseNode` | 18 | 2 | `AbstractBaseNode`, `AbstractBaseNode` | `com.seeyon.udc.microflow.domain.bo` |
| `BaseTrigger` | 18 | 2 | `AbstractBaseTrigger`, `AbstractBaseTrigger` | `com.seeyon.udc.microflow.domain.bo` |
| `BaseNodeContext` | 47 | 2 | `ImmutableNodeContext`, `NodeContext` | `com.seeyon.udc.microflow.domain.bo.check` |
| `HandleNull` | 4 | 2 | `MapOperationActivity`, `RetrieveEntityActivity` | `com.seeyon.udc.microflow.domain.bo.flow.activity.base` |
| `ApplicationShelfService` | 1 | 1 | `ApplicationShelf4UdcServiceImpl` | `com.seeyon.udc.api` |
| `ExprConsistencyValidator` | 1 | 1 | `EntityExprConsistencyValidationImpl` | `com.seeyon.udc.api` |
| `LateralAuthChecker` | 2 | 1 | `UdcLateralAuthChecker` | `com.seeyon.udc.api` |
| `MetadataHandleService` | 1 | 1 | `DeltaPageMetadataTask` | `com.seeyon.udc.api` |
| `UdcDataBaseSqlGenerator` | 3 | 1 | `UdcEntityDataBaseSqlGeneratorImpl` | `com.seeyon.udc.api` |
| `AuthCheck` | 3 | 1 | `AbstractAuthCheck` | `com.seeyon.udc.auth` |
| `LazyCacheAdapter` | 2 | 1 | `TemplateLazyCacheAdapter` | `com.seeyon.udc.cache` |
| `Schemable` | 1 | 1 | `AbstractSchemable` | `com.seeyon.udc.common` |
| `AppFeature` | 4 | 1 | `AbstractAppFeature` | `com.seeyon.udc.common.application.feature` |
| `CodeExecutor` | 2 | 1 | `AutoCodeExecutor` | `com.seeyon.udc.common.autocode` |
| `CodeContext` | 12 | 1 | `AppCodeContext` | `com.seeyon.udc.common.autocode.context` |
| `DbCodeHandler` | 1 | 1 | `Mysql57DbCodeHandler` | `com.seeyon.udc.common.autocode.db` |
| `SqlResolver` | 3 | 1 | `CodeSqlResolver` | `com.seeyon.udc.common.autocode.db.change` |
| `CodeParamInterceptor` | 1 | 1 | `BaseAppCodeParamInterceptor` | `com.seeyon.udc.common.autocode.extension.param` |
| `FileResolver` | 1 | 1 | `StaticFileResolver` | `com.seeyon.udc.common.autocode.file` |
| `UdcDataType` | 20 | 1 | `AbstractDataType` | `com.seeyon.udc.common.datatype` |
| `DeductionSearchMethodType` | 4 | 1 | `AbstractDeductionSearchMethodType` | `com.seeyon.udc.common.deduction.searchmethod` |
| `AppDeployContext` | 1 | 1 | `PipeLineContext` | `com.seeyon.udc.common.metadata` |
| `ContextListener` | 2 | 1 | `DeployContextListener` | `com.seeyon.udc.common.metadata` |
| `SchemaGenerator` | 1 | 1 | `AbstractSchemaGenerator` | `com.seeyon.udc.compatibility.generator.schema` |
| `CompatibilityOutput` | 1 | 1 | `AbstractCompatibilityOutput` | `com.seeyon.udc.compatibility.output` |
| `DetectionMetadataRepository` | 3 | 1 | `DetectionMetadataRepositoryImpl` | `com.seeyon.udc.detection` |
| `PartDetectionTask` | 14 | 1 | `AbstractPartDetectionTask` | `com.seeyon.udc.detection` |
| `DetectionContext` | 5 | 1 | `AppDetectionContext` | `com.seeyon.udc.detection.context` |
| `FrontDeployDetectionContext` | 5 | 1 | `AppFrontDeployDetectionContext` | `com.seeyon.udc.detection.context` |
| `LastFrontMetaDataContextPostProcess` | 2 | 1 | `AbstractLastFrontMetaDataContextPostProcess` | `com.seeyon.udc.detection.context.metadata` |
| `TableColumn` | 3 | 1 | `DefaultTableColumn` | `com.seeyon.udc.document` |
| `Stereotype` | 11 | 1 | `AbstractStereotype` | `com.seeyon.udc.entity` |
| `EntityCopyResolver` | 2 | 1 | `DefaultEntityCopyResolver` | `com.seeyon.udc.entity.copy.resolver` |
| `ConfigurationLoader` | 3 | 1 | `DefaultConfigurationLoader` | `com.seeyon.udc.entity.stereotype` |
| `EntitySaveProcessor` | 3 | 1 | `AbstractProcessor` | `com.seeyon.udc.entity.stereotype` |
| `Feature` | 16 | 1 | `AbstractFeature` | `com.seeyon.udc.entity.stereotype` |
| `SqlProcessor` | 2 | 1 | `AbstractProcessor` | `com.seeyon.udc.entity.stereotype` |
| `AttributeTransferDispatcher` | 1 | 1 | `DefaultAttributeTransferDispatcher` | `com.seeyon.udc.entity.transfer` |
| `AttributeTransferHandler` | 2 | 1 | `DefaultAttributeTransferHandler` | `com.seeyon.udc.entity.transfer.handler` |
| `ExprConsistencyFilter` | 1 | 1 | `ExprConsistencyFilterChain` | `com.seeyon.udc.expression.domain.service.detection.filter` |
| `LimitCountCheck` | 4 | 1 | `AbstractLimitCountCheck` | `com.seeyon.udc.limit` |
| `LogService` | 2 | 1 | `SLSService` | `com.seeyon.udc.log` |
| `UdcAuditLogService` | 3 | 1 | `UdcAuditLogServiceImpl` | `com.seeyon.udc.log.api` |
| `AggDtoConvertor` | 1 | 1 | `AbstractAggDtoMetadataDtoConvertor` | `com.seeyon.udc.metadata.convert.aggdto` |
| `AggDtoMetadataDtoConvertor` | 4 | 1 | `AbstractAggDtoMetadataDtoConvertor` | `com.seeyon.udc.metadata.convert.aggdto` |
| `EnumMetadataDtoConverter` | 1 | 1 | `AbstractAggDtoMetadataDtoConvertor` | `com.seeyon.udc.metadata.convert.enums` |
| `MicroFlowComponentCascadeHandlerDispatcher` | 1 | 1 | `DefaultMicroFlowComponentCascadeHandlerDispatcher` | `com.seeyon.udc.microflow.cascade` |
| `ComponentLookup` | 1 | 1 | `BaseComponentLookup` | `com.seeyon.udc.microflow.cascade.lookup` |
| `NodeParser` | 1 | 1 | `AbstractBaseNode` | `com.seeyon.udc.microflow.domain.bo` |
| `DataMappingFieldTypeDeterminer` | 3 | 1 | `MfFullAggDtoAttributeMetadataDto` | `com.seeyon.udc.microflow.dto.metadata` |
| `PresetTemplateHandler` | 6 | 1 | `AbstractPresetTemplateHandler` | `com.seeyon.udc.microflow.preset` |
| `ReferenceComponentProcessor` | 3 | 1 | `BaseReferenceComponentProcessor` | `com.seeyon.udc.microflow.refactor.processor` |
| `ReferenceParser` | 3 | 1 | `AbstractReferenceParser` | `com.seeyon.udc.model` |
| `ReferenceStore` | 9 | 1 | `DefaultReferenceStore` | `com.seeyon.udc.model` |
| `ChannelPlugin` | 1 | 1 | `AutoCodeHandler` | `com.seeyon.udc.pipeline` |
| `DeployService` | 12 | 1 | `AbstractDeployService` | `com.seeyon.udc.pipeline` |
| `PipeLineService` | 3 | 1 | `PipeLineManager` | `com.seeyon.udc.pipeline` |
| `PluginExecutor` | 4 | 1 | `AbstractPluginExecutor` | `com.seeyon.udc.plugin` |
| `PluginHandler` | 1 | 1 | `CommonSchemaImportPluginHandlerAdapter` | `com.seeyon.udc.plugin.handler` |
| `NpmSyncDataService` | 7 | 1 | `AbstractNpmSyncDataService` | `com.seeyon.udc.system.sync` |

## 二、纯扩展位（27 个）—— 零实现，自己从零写

| 接口 | abstract | 接口所在包 |
|---|---|---|
| `PluginDefinition` | 2 | `com.seeyon.udc` |
| `ApplicationInnerReference` | 3 | `com.seeyon.udc.autocode` |
| `DataFlowCodeService` | 1 | `com.seeyon.udc.autocode` |
| `DependencyAnalysisService` | 1 | `com.seeyon.udc.autocode` |
| `BaseNode` | 18 | `com.seeyon.udc.autocode.v27.microflow.bo` |
| `BaseTrigger` | 18 | `com.seeyon.udc.autocode.v27.microflow.bo` |
| `UdcTreeQueryService` | 1 | `com.seeyon.udc.common.api` |
| `ApplicationInnerReference` | 14 | `com.seeyon.udc.common.autocode` |
| `Recoverable` | 1 | `com.seeyon.udc.common.autocode` |
| `ConfigurableCodeContext` | 5 | `com.seeyon.udc.common.autocode.config` |
| `Lifecycle` | 3 | `com.seeyon.udc.common.autocode.context` |
| `Compatible` | 1 | `com.seeyon.udc.common.autocode.transport.compare` |
| `SchemaFilter` | 2 | `com.seeyon.udc.common.transport` |
| `Functor` | 1 | `com.seeyon.udc.common.utils` |
| `ConsistenceDetection` | 3 | `com.seeyon.udc.detection` |
| `WidgetExpressionDetectionFunction` | 1 | `com.seeyon.udc.detection.task.util` |
| `OperationLogSchema` | 1 | `com.seeyon.udc.domain` |
| `Functor` | 1 | `com.seeyon.udc.expression.codegen.util` |
| `ConvertorTypeDeterminer` | 1 | `com.seeyon.udc.metadata.convert` |
| `ComponentIdentity` | 1 | `com.seeyon.udc.microflow.cascade` |
| `MicroFlowComponentHandler` | 8 | `com.seeyon.udc.microflow.cascade` |
| `FullNameExtractor` | 1 | `com.seeyon.udc.microflow.domain.bo.flow.activity.base` |
| `SFunction` | 1 | `com.seeyon.udc.microflow.util` |
| `MicroflowNodeParser` | 1 | `com.seeyon.udc.model.parser` |
| `MigrateCallback` | 1 | `com.seeyon.udc.repo` |
| `TaskCallable` | 1 | `com.seeyon.udc.task` |
| `Consumer3` | 1 | `com.seeyon.udc.utils` |

## 三、注解（23 个）—— 贴在代码上，不是 implements

| 注解 | 参数 | 所在包 |
|---|---|---|
| `AuthModel` | name | `com.seeyon.udc.auth` |
| `AuthOperation` | operationType | `com.seeyon.udc.auth` |
| `AppOpsAuth` | type, appId | `com.seeyon.udc.collaboration.annotations` |
| `TypeMapping` | sourceType, targetType, isFormulaResult | `com.seeyon.udc.common.annotation` |
| `ComparedSchema` | value | `com.seeyon.udc.common.autocode.transport.compare` |
| `Importer` | source, model | `com.seeyon.udc.common.autocode.transport.upgrade` |
| `ExclusivePermit` | value, sourceName | `com.seeyon.udc.common.concurrent` |
| `UpgradeMethod` | sourceVersion, targetVersion, group | `com.seeyon.udc.common.transport.upgrade` |
| `DateValidation` | message, groups, payload, minDate | `com.seeyon.udc.common.validation.annotation` |
| `TimeValidation` | message, groups, payload, minTime | `com.seeyon.udc.common.validation.annotation` |
| `AttrTypeMatch` | message, groups, payload, values | `com.seeyon.udc.common.validation.constraints` |
| `AttributeExist` | message, groups, payload | `com.seeyon.udc.common.validation.constraints` |
| `EntityExist` | message, groups, payload | `com.seeyon.udc.common.validation.constraints` |
| `AppIdRef` | obtainType, index | `com.seeyon.udc.dataaware.annotation` |
| `DataChangeAware` | appIdRef | `com.seeyon.udc.dataaware.annotation` |
| `ConsistencyDetection` | service | `com.seeyon.udc.detection` |
| `DelDetection` | ids, domainObject, serviceObject, isDraft | `com.seeyon.udc.detection.annotation` |
| `UpdateDetection` | dtoList, domainObject, serviceObject, isDraft | `com.seeyon.udc.detection.annotation` |
| `ExprConsistency` | order | `com.seeyon.udc.expression.domain.service.detection.filter` |
| `LimitCountOperation` | modelName, appId | `com.seeyon.udc.limit` |
| `LogDefault` | domainService, domainCaptionField, domainAppIdField, getDomainObjByIdsMethod | `com.seeyon.udc.operationlog.annotations` |
| `LogDefaultUpdate` | attributeName, attributeField, valueType | `com.seeyon.udc.operationlog.annotations` |
| `OperationLog` | operationType, module, subModule, requestDto | `com.seeyon.udc.operationlog.annotations` |
