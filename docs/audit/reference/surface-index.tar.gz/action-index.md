# 业务动作索引：要做什么 → 调哪个方法 → 传什么 → 背后发生什么

> 自动生成，勿手改。`tools/core/platform/emit_action_index.py` 重跑即可。
> 数据源：`interfaces.json`（327 个 AppService / 2300 个方法）+ `service-flow-20261103/`（方法体调用链）。

## 覆盖现实（先看这段，别指望全部能追）

| 项 | 数量 | 说明 |
|---|---|---|
| AppService 方法总数 | **2300** | 322 个接口 |
| 仓库里有实现类 | **2210** | 68 个接口（46 个在 udc-biz） |
| 能追到方法体流转 | **1665** | 其余实现在平台服务端，jar 里只有接口 |

⇒ **BPM / 组织架构 / 事项 / 连接器 的实现在平台服务端**，仓库里只有接口 jar，
流转追不到。这些域只能给「接口 + 入参 DTO」，具体动作要实测或看平台日志。
**UDC 域（46 个 AppService）能追全链**。

## 动作分布

| 动作 | 方法数 | 有实现 | 有流转 |
|---|---|---|---|
| 创建 | 240 | 231 | 192 |
| 修改 | 161 | 154 | 126 |
| 删除 | 141 | 131 | 107 |
| 流程 | 23 | 23 | 13 |
| 发布 | 29 | 29 | 26 |
| 导入导出 | 35 | 35 | 32 |
| 校验 | 42 | 42 | 30 |
| 启用禁用 | 11 | 11 | 9 |
| 查询 | 1218 | 1187 | 849 |
| 其他 | 400 | 367 | 281 |

## 创建（240）

| 动作方法 | 接口 | 入参 DTO | 实现 | 流转（第一步） |
|---|---|---|---|---|
| `createAffair` | `AffairCommonAppService` | `AffairCreateMessageDto` | `AffairCommonAppServiceImpl` | Service:AffairInvokeAppService(affairCreate) |
| `createAffairCategory` | `AffairCommonAppService` | `AffairFullCategoryDto` | `AffairCommonAppServiceImpl` | Service:AffairCategoryService(createCategory) |
| `createAffairIdempotent` | `AffairCommonAppService` | `AffairCreateMessageIdempotentDto` | `AffairCommonAppServiceImpl` | Other:SingleRequest(getData) |
| `createAffairCustomOperation` | `AffairCustomOperationAppService` | `AffairCustomOperationDto` | `AffairCustomOperationAppServiceImpl` | Service:AffairCustomOperationService(createCustomOperation) |
| `createAffairByMicroflow` | `AffairMicroflowAppService` | `AffairMicroflowInfoDto` | `AffairMicroflowAppServiceImpl` | Service:AffairService(dealMicroflowAffair) |
| `createAffairByMicroflowReturnIds` | `AffairMicroflowAppService` | `AffairMicroflowInfoDto` | `AffairMicroflowAppServiceImpl` | Service:AffairService(dealMicroflowAffair) |
| `createOrUpdate` | `AffairNodePermissionAppService` | — | `AffairNodePermissionAppServiceImpl` | Service:AffairNodePermissionService(createOrUpdate) |
| `createOrUpdate` | `AffairOpenAppService` | — | `AffairOpenApiAppServiceImpl` | Service:AffairNodePermissionService(selectByNodePermissionIds) |
| `createOrUpdateCategory` | `AffairOpenAppService` | `AffairFullCategoryDto` | `AffairOpenApiAppServiceImpl` | Service:AffairCategoryService(createOrUpdateCategory) |
| `createOrUpdateCategoryHierarchy` | `AffairOpenAppService` | — | `AffairOpenApiAppServiceImpl` | Service:AffairCategoryHierarchyService(createOrUpdateCategoryHierarchy) |
| `create` | `AgentCommonAppService` | `AgentDto` | `AgentCommonAppServiceImpl` | Service:AgentService(create) |
| `createThirdApp` | `AiAppService` | `AiAppInfoDto` | `AiAppServiceImpl` | Service:AiService(createThirdApp) |
| `addModifyPluginAffair` | `ApplicationAffairAppService` | `PluginAffairBatchDto` | `ApplicationAffairAppServiceImpl` | Service:AffairSynchronizeService(addModifyPluginAffair) |
| `create` | `ApplicationAppService` | `ApplicationDto` | `ApplicationAppServiceImpl` | Service:ApplicationService(create) |
| `createDepApp` | `ApplicationAppService` | `DependentApplicationDto` | `ApplicationAppServiceImpl` | Service:DependentApplicationService(create) |
| `createDepAppBatch` | `ApplicationAppService` | — | `ApplicationAppServiceImpl` | Service:DependentApplicationService(createBatch) |
| `createFromTemplate` | `ApplicationAppService` | `TemplateApplicationDto` | `ApplicationAppServiceImpl` | Service:ApplicationService(selectTemplateAppListByConditions) |
| `saveAsNewDesign` | `ApplicationAppService` | — | `ApplicationAppServiceImpl` | Service:ApplicationService(saveAsNewDesign) |
| `saveAsNormalNewDesign` | `ApplicationAppService` | — | `ApplicationAppServiceImpl` | Service:ApplicationService(saveAsNormalNewDesign) |
| `saveAsTemplate` | `ApplicationAppService` | `ApplicationCopyDto` | `ApplicationAppServiceImpl` | Other:SingleRequest(getData) |
| `create` | `ApplicationManagerAppService` | `ApplicationDto` | `ApplicationManagerAppServiceImpl` | Service:ApplicationService(create) |
| `createEntity` | `ApplicationManagerAppService` | `EntityDto` | `ApplicationManagerAppServiceImpl` | Service:EntityAppServiceImpl(createWithoutAuthentication) |
| `createIntegrationApplication` | `ApplicationManagerAppService` | `IntegrationApplicationDto` | `ApplicationManagerAppServiceImpl` | Service:ApplicationService(create) |
| `createLayoutApplication` | `ApplicationManagerAppService` | `LayoutApplicationDto` | `ApplicationManagerAppServiceImpl` | Service:ApplicationService(create) |
| `createMember` | `ApplicationManagerAppService` | `MemberAddDto` | `ApplicationManagerAppServiceImpl` | Service:AppCollaborationAppServiceImpl(createMember) |
| `createNewLayoutAfterCall` | `ApplicationManagerAppService` | `NewLayoutCreateAfterCallDto` | `ApplicationManagerAppServiceImpl` | Service:PageInfoAppService(replaceNewLayoutSchema) |
| `createOnlyPageApplication` | `ApplicationManagerAppService` | `CreateOnlyPageApplicationDto` | `ApplicationManagerAppServiceImpl` | Service:CustomPageInfoService(create4CustomPage) |
| `createReturnDto` | `ApplicationManagerAppService` | `ApplicationDto` | `ApplicationManagerAppServiceImpl` | Service:ApplicationService(create) |
| `createApplicationByMap` | `ApprovalInvokeAppService` | — | `ApprovalInvokeAppServiceImpl` | Service:ApplicationService(create) |
| `createOrUpdateTemporaryData` | `ApprovalInvokeAppService` | — | `ApprovalInvokeAppServiceImpl` | Service:AppDraftAppService(createOrUpdate) |
| `createLayoutApplicationAsync` | `AsyncAppService` | `LayoutApplicationDto` | `AsyncAppServiceImpl` | Util:Ids(uuidAbsLong) |
| `createOnlyPageApplicationAsync` | `AsyncAppService` | `CreateOnlyPageApplicationDto` | `AsyncAppServiceImpl` | Util:Ids(uuidAbsLong) |
| `create` | `AttributeAppService` | `AttributeDto` | `AttributeAppServiceImpl` | Service:AttributeSetService(selectById) |
| `createBatch` | `AttributeAppService` | — | `AttributeAppServiceImpl` | Service:AttributeService(createBatch) |
| `createBatch4System` | `AttributeAppService` | — | `AttributeAppServiceImpl` | Service:AttributeService(createBatch4System) |
| `create` | `AttributeGroupAppService` | `AttributeGroupDto` | `AttributeGroupAppServiceImpl` | Service:AttributeGroupService(create) |
| `create` | `AttributeSetAppService` | `AttributeSetDto` | `AttributeSetAppServiceImpl` | Service:AttributeSetService(create) |
| `createBatch` | `AttributeSetAppService` | — | `AttributeSetAppServiceImpl` | Service:AttributeSetService(createBatch) |
| `createDatabase` | `BaseConfigAppService` | `DatabaseInfoDto` | `BaseConfigAppServiceImpl` | Service:DatabaseInfoService(create) |
| `create` | `BpmActivityAppService` | `BpmActivityRunDto` | `BpmActivityAppServiceImpl` | Service:BpmActivityRunService(create) |
| `createBatch` | `BpmActivityAppService` | — | `BpmActivityAppServiceImpl` | Service:BpmActivityRunService(createBatch) |
| `create` | `BpmApiFormPermissionAppService` | `BpmFormPermissionDto` | `BpmApiFormPermissionAppServiceImpl` | Service:TemplatePublishLockService(checkLockAndAuth) |
| `createBatchOrUpdateContent` | `BpmApiFormPermissionAppService` | — | `BpmApiFormPermissionAppServiceImpl` | Service:BpmFormPermissionContentService(selectByIds) |
| `createOrUpdateBatch` | `BpmApiFormPermissionAppService` | — | `BpmApiFormPermissionAppServiceImpl` | Service:BpmFormPermissionService(selectPermissionByIds) |
| `createOrUpdateNodePermissionBatch` | `BpmApiNodePermissionAppService` | — | `BpmNodePermissionAppServiceImpl` | Service:BpmNodePermissionService(createOrUpdateBatch) |
| `savePermission` | `BpmApiNodePermissionAppService` | `BpmNodePermissionAddDto` | `BpmNodePermissionAppServiceImpl` | Service:BpmNodePermissionAppService(savePermission) |
| `savePermissionList` | `BpmApiNodePermissionAppService` | — | `BpmNodePermissionAppServiceImpl` | Service:BpmNodePermissionAppService(savePermissionList) |
| `saveParamData` | `BpmApiParamAppService` | `BpmParameterDataDto` | `BpmApiParamAppServiceImpl` | Service:BpmParameterService(saveParamData) |
| `saveParamSchema` | `BpmApiParamAppService` | `BpmParameterDefineDto` | `BpmApiParamAppServiceImpl` | Service:BpmParameterService(saveBatch) |
| `saveAs` | `BpmApiTransportAppService` | `BpmSaveAsDto` | `BpmApiTransportAppServiceImpl` | Other:SingleResponse(ok) |
| `addExecuteMember` | `BpmAppService` | `BpmAddExecuteUserDto` | `BpmApiAppServiceImpl` | Service:OrgServiceInterface(selectUserById) |
| `addNode` | `BpmAppService` | `SimpleChangeProcessRequestDto` | `BpmApiAppServiceImpl` | Service:BpmService(countersignNode) |
| `saveDraft` | `BpmAppService` | `BpmSaveDraftDto` | `BpmApiAppServiceImpl` | Service:BpmUserTemplateService(selectCanSendTemplateByCode) |
| `create` | `BpmCaseAppService` | `BpmCaseDto` | `BpmCaseAppServiceImpl` | Service:BpmCaseService(create) |
| `createBatch` | `BpmCaseAppService` | — | `BpmCaseAppServiceImpl` | Service:BpmCaseService(createBatch) |
| `create` | `BpmOpinionAppService` | `BpmOpinionDataDto` | `BpmOpinionAppServiceImpl` | Service:OpinionService(create) |
| `createBatch` | `BpmOpinionAppService` | — | `BpmOpinionAppServiceImpl` | Service:BpmOpinionService(createBatch) |
| `createBatchOpinion` | `BpmOpinionAppService` | — | `BpmOpinionAppServiceImpl` | Service:OpinionService(createBatchIgnoreTime) |
| `create` | `BpmProcessLogAppService` | `BpmProcessLogDto` | `BpmProcessLogAppServiceImpl` | Service:BpmProcessLogInnerAppService(create) |
| `createBatch` | `BpmProcessLogAppService` | — | `BpmProcessLogAppServiceImpl` | Service:BpmProcessLogInnerAppService(createBatchBusinessLog) |
| `createBatchProcessLog` | `BpmProcessLogAppService` | — | `BpmProcessLogAppServiceImpl` | Service:BpmProcessLogInnerAppService(createBatch) |
| `createOrUpdate` | `BpmTemplateAppService` | `BpmTemplateDto` | `BpmTemplateAppServiceImpl` | Service:BpmTemplateInnerAppService(createOrUpdateWithoutAuth) |
| `createActivityResponsibilities` | `BpmThirdTemplateSyncAppService` | — | `BpmThirdTemplateSyncAppServiceImpl` | Service:BpmDiagramDetailService(createBatch) |
| `createBatch` | `BpmThirdTemplateSyncAppService` | — | `BpmThirdTemplateSyncAppServiceImpl` | Service:BpmThirdTemplateService(creteBatch) |
| `createTemplateRecent` | `BpmThirdTemplateSyncAppService` | `BpmTemplateRecentDto` | `BpmThirdTemplateSyncAppServiceImpl` | Service:BpmTemplateRecentService(updateOrCreateAsync) |
| `create` | `BpmWorkItemAppService` | `BpmWorkItemDto` | `BpmWorkItemAppServiceImpl` | Service:BpmWorkItemService(create) |
| `createBatch` | `BpmWorkItemAppService` | — | `BpmWorkItemAppServiceImpl` | Service:BpmWorkItemService(createBatchWorkItemRun) |
| `addressGetBook` | `BusinessTripAppService` | `TripAddressGetBookRequestDto` | `BusinessTripAppServiceImpl` | Service:TripManageMsgSend(addressGetBook) |
| `addressGetH5` | `BusinessTripAppService` | `TripAddressGetH5RequestDto` | `BusinessTripAppServiceImpl` | Service:TripManageMsgSend(addressGetH5) |
| `addressGetManager` | `BusinessTripAppService` | `TripAddressGetManagerRequestDto` | `BusinessTripAppServiceImpl` | Service:TripManageMsgSend(addressGetManager) |
| `addressGetOrder` | `BusinessTripAppService` | `TripAddressGetOrderRequestDto` | `BusinessTripAppServiceImpl` | Service:TripManageMsgSend(addressGetOrder) |
| `create` | `CapabilityEnumAppService` | `CapabilityEnumDto` | `CapabilityEnumAppServiceImpl` | Service:CapabilityEnumService(create) |
| `createItem` | `CapabilityEnumAppService` | `CapabilityEnumItemDto` | `CapabilityEnumAppServiceImpl` | Service:CapabilityEnumItemService(create) |
| `createApp` | `CapabilityManageAppService` | `CipAppCreateDto` | `CapabilityManageAppServiceImpl` | Service:CipAppService(create) |
| `createAppConfig` | `CapabilityManageAppService` | `CipAppFeatureProviderCreateInDto` | `CapabilityManageAppServiceImpl` | Service:CipAppFeatureProviderService(createAppConfig) |
| `createParamBatch` | `CapabilityManageAppService` | `ProviderParameterRequestDto` | `CapabilityManageAppServiceImpl` | Service:ProviderSelectorService(selectProviderById) |
| `saveLinkProperties` | `CapabilityManageAppService` | `CloudConnectPropertiesDto` | `CapabilityManageAppServiceImpl` | Service:OpenApiPropertiesService(saveCloudConnectProperties) |
| `create` | `CategoryCommonAppService` | `CategoryDto` | `CategoryCommonAppServiceImpl` | Service:CategoryService(create) |
| `createBatch` | `CategoryCommonAppService` | `CategorySyncBatchDto` | `CategoryCommonAppServiceImpl` | Service:CategoryService(createBatch) |
| `create` | `CtpDataAuditCoreAppService` | `CtpDataAuditDto` | `CtpDataAuditCoreAppServiceImpl` | Service:CtpPermissionApprovalAppService(createDataAudit) |
| `createOrUpdate` | `CtpLoginPreConfigAppService` | `CtpLoginPreConfigDto` | `CtpLoginPreConfigAppServiceImpl` | Service:CtpLoginPreConfigService(createOrUpdate) |
| `createSource` | `CtpMessageSourceTypeAppService` | `CtpMessageSourceBaseDto` | `CtpMessageSourceTypeAppServiceImpl` | Service:CtpMessageSourceService(create) |
| `createType` | `CtpMessageSourceTypeAppService` | `CtpMessageTypeDto` | `CtpMessageSourceTypeAppServiceImpl` | Service:CtpMessageTypeService(create) |
| `create` | `CtpMessageTypeAppService` | — | `CtpMessageTypeAppServiceImpl` | Service:CtpMessageTypeService(create) |
| `createOrUpdateBatch` | `CtpPersonalPlanCoreAppService` | `CtpPersonalPlanPermissionDto` | `CtpPersonalPlanCoreAppServiceImpl` | Service:UserOrgHandler(registerResourceAndPermission) |
| `createRedirectBatch` | `CtpPersonalPlanCoreAppService` | — | `CtpPersonalPlanCoreAppServiceImpl` | Service:CtpPersonalPlanService(createRedirectBatch) |
| `create` | `CtpSecretApprovalOrgAppService` | — | `CtpSecretApprovalOrgAppServiceImpl` | Service:CtpPermissionApprovalService(selectByConditions) |
| `saveUpdate` | `CtpUserBindMappingAppService` | `CtpUserMappingSyncRequestDto` | `CtpUserBindMappingAppServiceImpl` | Other:SingleResponse(setMessage) |
| `create` | `DataTransferObjectAppService` | `DataTransferObjectDto` | `DataTransferObjectAppServiceImpl` | Service:DataTransferObjectService(create) |
| `createDtoWithAttrs` | `DataTransferObjectAppService` | `DataTransferObjectDto` | `DataTransferObjectAppServiceImpl` | Service:DataTransferObjectService(create) |
| `createDtoWithAttrs4EntityEvent` | `DataTransferObjectAppService` | `EventAndDataDto` | `DataTransferObjectAppServiceImpl` | Service:EntityService(selectEntityByIdsLoadAttribute) |
| `createDtoWithAttrsAndRefDtos` | `DataTransferObjectAppService` | — | `DataTransferObjectAppServiceImpl` | Service:DataTransferObjectService(createBatch) |
| `create` | `DtoAttributeAppService` | `DtoAttributeDto` | `DtoAttributeAppServiceImpl` | Service:DtoAttributeService(create) |
| `createBatch` | `DtoAttributeAppService` | — | `DtoAttributeAppServiceImpl` | Service:DtoAttributeService(createBatch) |
| `addEmailTemplate` | `EmailPrivateAppService` | `CipEmailTemplateDto` | `EmailPrivateAppServiceImpl` | Service:EmailService(addEmailTemplate) |
| `insertOrUpdateEmailConfig` | `EmailPrivateAppService` | `CipEmailConfigDto` | `EmailPrivateAppServiceImpl` | Service:EmailService(insertOrUpdateEmailConfig) |
| `insertOrUpdateEmailLimitConfig` | `EmailPrivateAppService` | `CipEmailLimitConfigDto` | `EmailPrivateAppServiceImpl` | Service:EmailService(insertOrUpdateEmailLimitConfig) |
| `create` | `EntityAppService` | `EntityDto` | `EntityAppServiceImpl` | Service:EntityService(create) |
| `create` | `EntityGroupAppService` | `EntityGroupDto` | `EntityGroupAppServiceImpl` | Service:EntityGroupService(create) |
| `create` | `EntityPresetAppService` | `EntityPresetDto` | `EntityPresetAppServiceImpl` | Service:EntityPresetService(create) |
| `createDefaultExcelTemplate` | `EntityPresetAppService` | `Long` | `EntityPresetAppServiceImpl` | Service:EntityPresetService(createDefaultExcelTemplate) |
| `create` | `EventAppService` | `EventDto` | `EventAppServiceImpl` | Service:EventService(create) |
| `createWithEventData` | `EventWithDataAppService` | `EventAndDataDto` | `EventWithDataAppServiceImpl` | Service:DataTransferObjectAppService(createDtoWithAttrs4EntityEvent) |
| `addFace` | `FaceIdAppService` | `FaceAddReqDto` | `FaceIdAppServiceImpl` | Service:FaceIdService(addFace) |
| `create` | `ImageAppService` | — | `ImageAppServiceImpl` | Service:ImageService(createBatch) |
| `save` | `ImageCategoryAppService` | `ImageCategoryDto` | `ImageCategoryAppServiceImpl` | Service:ImageCategoryService(save) |
| `save` | `ImageStoreAppService` | `ImageStoreDto` | `ImageStoreAppServiceImpl` | Service:ImageStoreService(save) |
| `create` | `IndexAppService` | `IndexDto` | `IndexAppServiceImpl` | Service:EntityService(selectById) |
| `save` | `IndexStoreAppService` | `IndexStoreDto` | `IndexStoreAppServiceImpl` | Service:IndexStoreService(save) |
| `saveIndexBpmData` | `IndexStoreAppService` | `IndexBpmDataDto` | `IndexStoreAppServiceImpl` | Service:IndexStoreService(saveIndexBpmData) |
| `create` | `IntegralLedgerOprateAppService` | `IntegralLedgerDto` | `IntegralLedgerOprateAppServiceImpl` | Service:IntegralLedgerService(create) |
| `createBatch` | `IntegralLedgerOprateAppService` | — | `IntegralLedgerOprateAppServiceImpl` | Service:IntegralLedgerService(createBatch) |
| `createDocDiffTask` | `IntelligentMissiveAppService` | `DiffTaskReqDto` | `IntelligentMissiveAppServiceImpl` | Service:IntelligentMissiveService(createDocDiffTask) |
| `createExtractingTask` | `IntelligentMissiveAppService` | `ExtractingTaskReqDto` | `IntelligentMissiveAppServiceImpl` | Service:IntelligentMissiveService(createExtractingTask) |
| `createOnlineProofread` | `IntelligentMissiveAppService` | `ProofreadTaskReqDto` | `IntelligentMissiveAppServiceImpl` | Service:IntelligentMissiveService(createOnlineProofread) |
| `createRecommend` | `IntelligentMissiveAppService` | `RecommendReqDto` | `IntelligentMissiveAppServiceImpl` | Service:IntelligentMissiveService(createRecommend) |
| `createReviewTask` | `IntelligentMissiveAppService` | `ReviewTaskReqDto` | `IntelligentMissiveAppServiceImpl` | Service:IntelligentMissiveService(createReviewTask) |
| `createSettingByTemplate` | `IntelligentMissiveAppService` | `SettingTaskReqDto` | `IntelligentMissiveAppServiceImpl` | Service:IntelligentMissiveService(createSettingByTemplate) |
| `createTableTask` | `IntelligentMissiveAppService` | `TableTaskReqDto` | `IntelligentMissiveAppServiceImpl` | Service:IntelligentMissiveService(createTableTask) |
| `createWrite` | `IntelligentMissiveAppService` | `IntelligentWriteReqDto` | `IntelligentMissiveAppServiceImpl` | Service:IntelligentMissiveService(createWrite) |
| `createImageTask` | `InvoiceImageAppService` | `InvoiceImageReqDto` | `InvoiceImageAppServiceImpl` | Service:InvoiceService(createImageTask) |
| `initDataJsonByNames` | `LinkerMigrationAppService` | — | `LinkerMigrationAppServiceImpl` | Other:SingleRequest(getData) |
| `addOrgMappingDetail` | `MappingDetailAppService` | `OrgMappingDetailAddReqDto` | `MappingDetailAppServiceImpl` | Service:OrgMappingDetailService(addOrgMappingDetail) |
| `addUserMappingDetail` | `MappingDetailAppService` | `UserMappingDetailAddReqDto` | `MappingDetailAppServiceImpl` | Service:UserMappingDetailService(addUserMappingDetail) |
| `createMerchant` | `MerchantAppService` | `MerchantDto` | `MerchantAppServiceImpl` | Service:MerchantService(createMerchant) |
| `create` | `MgnAggDataInitAppService` | `CtpMgnAggDataDto` | `MgnAggDataInitAppServiceImpl` | Dao:CtpMgnAggDataDao(create) |
| `saveDuty` | `MiddleTableAppService` | `DutyInfoReqDto` | `MiddleTableAppServiceImpl` | Service:MiddleTableService(saveDuty) |
| `saveLevel` | `MiddleTableAppService` | `LevelInfoReqDto` | `MiddleTableAppServiceImpl` | Service:MiddleTableService(saveLevel) |
| `saveMember` | `MiddleTableAppService` | `MemberInfoReqDto` | `MiddleTableAppServiceImpl` | Service:MiddleTableService(saveMember) |
| `savePost` | `MiddleTableAppService` | `PostInfoReqDto` | `MiddleTableAppServiceImpl` | Service:MiddleTableService(savePost) |
| `saveUnit` | `MiddleTableAppService` | `UnitInfoReqDto` | `MiddleTableAppServiceImpl` | Service:MiddleTableService(saveUnit) |
| `saveDuty` | `MiddleTableOperationAppService` | `DutyInfoReqDto` | `MiddleTableOperationAppServiceImpl` | Service:MiddleTableAppService(saveDuty) |
| `saveLevel` | `MiddleTableOperationAppService` | `LevelInfoReqDto` | `MiddleTableOperationAppServiceImpl` | Service:MiddleTableAppService(saveLevel) |
| `saveMember` | `MiddleTableOperationAppService` | `MemberInfoReqDto` | `MiddleTableOperationAppServiceImpl` | Service:MiddleTableAppService(saveMember) |
| `savePost` | `MiddleTableOperationAppService` | `PostInfoReqDto` | `MiddleTableOperationAppServiceImpl` | Service:MiddleTableAppService(savePost) |
| `saveUnit` | `MiddleTableOperationAppService` | `UnitInfoReqDto` | `MiddleTableOperationAppServiceImpl` | Service:MiddleTableAppService(saveUnit) |
| `create` | `MobilePluginConfigAppService` | `MobilePluginPlatformConfigDto` | `MobilePluginConfigAppServiceImpl` | Service:CipCapabilityMobileConfigGeneralizationInvoker(create) |
| `create` | `OrgJobBaseAppService` | `OrgJobRequestDto` | `OrgJobBaseAppServiceImpl` | Service:OrgJobService(create) |
| `createBatch` | `OrgJobSyncAppService` | `OrgBatchJobDto` | `OrgJobSyncAppServiceImpl` | Service:OrgUnitService(selectListByWrapper) |
| `create` | `OrgLevelBaseAppService` | `OrgLevelRequestDto` | `OrgLevelBaseAppServiceImpl` | Service:OrgLevelService(create) |
| `createBatch` | `OrgLevelSyncAppService` | `OrgBatchLevelDto` | `OrgLevelSyncAppServiceImpl` | Service:OrgBusinessService(selectAdministrativeId) |
| `create` | `OrgMemberBaseAppService` | `OrgCreateMemberBaseDto` | `OrgMemberBaseAppServiceImpl` | Service:OrgMemberService(create) |
| `create` | `OrgMemberPostBaseAppService` | `OrgMemberPostDto` | `OrgMemberPostAppServiceImpl` | Other:SingleRequest(getData) |
| `createOrUpdateBatch` | `OrgMemberRoleBaseAppService` | — | `OrgMemberRoleBaseAppServiceImpl` | Service:OrgMemberRoleAppService(createOrUpdateBatch) |
| `createBatch` | `OrgMemberSyncAppService` | `OrgBatchMemberDto` | `OrgMemberSyncAppServiceImpl` | Service:MemberSyncService(createBatch) |
| `createBatchMemberMetadata` | `OrgMemberSyncAppService` | `OrgBatchMetadataDto` | `OrgMemberSyncAppServiceImpl` | Service:MemberSyncService(createBatchMemberMetadata) |
| `createBatchMemberPost` | `OrgMemberSyncAppService` | `OrgBatchMemberPostDto` | `OrgMemberSyncAppServiceImpl` | Service:OrgMemberPostSyncAppService(createBatch) |
| `createBatchNaturalMember` | `OrgMemberSyncAppService` | `OrgBatchNaturalMemberDto` | `OrgMemberSyncAppServiceImpl` | Service:NaturalMemberSyncService(createBatchNaturalMember) |
| `create` | `OrgPostBaseAppService` | `OrgPostRequestDto` | `OrgPostBaseAppServiceImpl` | Service:OrgPostService(create) |
| `createBatch` | `OrgPostSyncAppService` | `OrgBatchPostDto` | `OrgPostSyncAppServiceImpl` | Service:PostSyncService(createBatch) |
| `createOrUpdateBatch` | `OrgRoleBaseAppService` | — | `OrgRoleBaseAppServiceImpl` | Service:OrgRoleAppService(createOrUpdateBatch) |
| `create` | `OrgTeamSyncAppService` | `OrgTeamDataDto` | `OrgTeamSyncAppServiceImpl` | Service:OrgHelperService(syncValidateName) |
| `createBatch` | `OrgTeamSyncAppService` | `OrgBatchTeamDto` | `OrgTeamSyncAppServiceImpl` | Other:SingleRequest(getData) |
| `create` | `OrgUnitBaseAppService` | `OrgCreateUnitBaseDto` | `OrgUnitBaseAppServiceImpl` | Service:OrgBusinessService(selectAdministrativeId) |
| `createBatch` | `OrgUnitSyncAppService` | `OrgBatchUnitDto` | `OrgUnitSyncAppServiceImpl` | Service:OrgBusinessService(selectAdministrativeId) |
| `createBatchUnitMetadata` | `OrgUnitSyncAppService` | `OrgBatchMetadataDto` | `OrgUnitSyncAppServiceImpl` | Service:OrgBusinessService(selectAdministrativeId) |
| `create` | `OrgUnitTeamCoreAppService` | `OrgUnitTeamDto` | `OrgUnitTeamCoreAppServiceImpl` | Service:OrgUnitTeamService(selectSortId) |
| `create` | `ParameterAppService` | `UdcParameterDto` | `ParameterAppServiceImpl` | Service:ParameterService(create) |
| `addModifyPluginAffair` | `PluginAffairAppService` | `PluginAffairBatchDto` | `PluginAffairAppServiceImpl` | Service:ApplicationAffairAppService(addModifyPluginAffair) |
| `createBatch` | `PluginAttributeAppService` | — | `PluginAttributeAppServiceImpl` | Service:AttributeService(createBatch) |
| `create` | `PluginEntityAppService` | `EntityDto` | `PluginEntityAppServiceImpl` | Service:EntityService(create) |
| `createDefaultFilterPlanContentByEntity` | `PluginPageInfoAppService` | `EntityDto` | `PluginPageInfoAppServiceImpl` | Util:PageUtils(generateFilterPlanContent4EntityDto) |
| `createDefaultRefer` | `PluginReferConfigGroupAppService` | `Long` | `PluginReferConfigGroupAppServiceImpl` | Service:EntityService(selectById) |
| `create` | `ReferConfigAppService` | `ReferConfigDto` | `ReferConfigAppServiceImpl` | Service:ReferConfigService(create) |
| `createOrUpdate` | `ReferConfigAppService` | `ReferConfigDto` | `ReferConfigAppServiceImpl` | Service:ReferConfigService(createOrUpdate) |
| `createConfigInfo` | `ReferConfigGroupAppService` | `ReferConfigInfoDto` | `ReferConfigGroupAppServiceImpl` | Service:ReferConfigGroupService(createConfigInfo) |
| `create` | `ScalabilityAppService` | `ScalabilityDto` | `ScalabilityAppServiceImpl` | Service:ScalabilityOptionService(selectById) |
| `create` | `ScalabilityOptionAppService` | `ScalabilityOptionDto` | `ScalabilityOptionAppServiceImpl` | Service:ScalabilityOptionService(create) |
| `addSchedule` | `ScheduleAppService` | `AddScheduleDto` | `ScheduleAppServiceImpl` | Service:ScheduleService(addSchedule) |
| `createShortMessageTemplateContent` | `ShortMessageProviderTemplateAppService` | `ShortMessageProviderTemplateDto` | `ShortMessageProviderTemplateAppServiceImpl` | Service:ShortMessageProviderTemplateService(createTemplateContent) |
| `createShortMessageSign` | `ShortMessageSignAppService` | `ShortMessageSignDto` | `ShortMessageSignAppServiceImpl` | Service:ShortMessageSignService(createSign) |
| `createSmsSign` | `ShortMessageSignAppService` | `SmsSignCloudDto` | `ShortMessageSignAppServiceImpl` | Service:ShortMessageSignService(createSmsSign) |
| `createSMSTemplate` | `ShortMessageTemplateAppService` | `ShortMessageTemplateDto` | `ShortMessageTemplateAppServiceImpl` | Service:ShortMessageTemplateService(createSMSTemplate) |
| `createShortMessageTemplate` | `ShortMessageTemplateAppService` | `ShortMessageTemplateDto` | `ShortMessageTemplateAppServiceImpl` | Service:ShortMessageTemplateService(createTemplate) |
| `createOrg` | `SignatureAppService` | `OrganizationDto` | `SignatureAppServiceImpl` | Service:SignatureService(createOrg) |
| `createOuterOrg` | `SignatureAppService` | `OuterOrganizationDto` | `SignatureAppServiceImpl` | Service:SignatureService(createOuterOrg) |
| `initPreSign` | `SignatureAppService` | `InitPreSignDto` | `SignatureAppServiceImpl` | Service:SignatureService(initPreSign) |
| `initiateSign` | `SignatureAppService` | `InitiateSignDto` | `SignatureAppServiceImpl` | Service:SignatureService(initiateSign) |
| `initiateSignFree` | `SignatureAppService` | `InitiateSignFreeDto` | `SignatureAppServiceImpl` | Service:SignatureService(initiateSignFree) |
| `create` | `ThemeAppService` | `ThemeDto` | `ThemeAppServiceImpl` | Service:ThemeService(create) |
| `create` | `UdcEnumAppService` | `UdcEnumDto` | `UdcEnumAppServiceImpl` | Service:UdcEnumService(create) |
| `create` | `UdcEnumCategoryAppService` | `UdcEnumCategoryDto` | `UdcEnumCategoryAppServiceImpl` | Service:UdcEnumCategoryService(create) |
| `create` | `UdcEnumItemAppService` | `UdcEnumItemDto` | `UdcEnumItemAppServiceImpl` | Service:UdcEnumItemService(create) |
| `createFunctionRefer` | `UdcFunctionAppService` | — | `UdcFunctionAppServiceImpl` | Service:FunctionNodeService(createSpaceFunctionRefer) |
| `addMeetingRoomResource` | `VideoMeetingAppService` | `VideoMeetingRoomResourceDto` | `VideoMeetingAppServiceImpl` | Service:VideoMeetingRoomService(addMeetingRoomResource) |
| `addMeetingUser` | `VideoMeetingAppService` | `VideoMeetingUserDto` | `VideoMeetingAppServiceImpl` | Service:VideoMeetingRoomService(addMeetingUser) |
| `createPersonalVideoMeeting` | `VideoMeetingAppService` | `VideoMeetingPersonalCreateDto` | `VideoMeetingAppServiceImpl` | Service:VideoMeetingManagerService(createPersonalVideoMeeting) |
| `createVideoMeeting` | `VideoMeetingAppService` | `VideoMeetingCreateDto` | `VideoMeetingAppServiceImpl` | Service:VideoMeetingManagerService(createVideoMeeting) |
| `createFileConvertWords` | `VoiceAppService` | `CreateWordsDto` | `VoiceAppServiceImpl` | Service:VoiceService(createFileConvertWords) |
| `createIntelligentDigest` | `VoiceAppService` | `CreateIntelligentDigestDto` | `VoiceAppServiceImpl` | Service:VoiceService(createIntelligentDigest) |
| `createRealTime` | `VoiceAppService` | `RealtimeDto` | `VoiceAppServiceImpl` | Service:VoiceService(createRealTime) |
| `createVoiceFile` | `VoiceAppService` | `CreateVoiceFileDto` | `VoiceAppServiceImpl` | Service:VoiceService(createVoiceFile) |
| `create` | `AgentCoreAppService` | `AgentDto` | `AgentAppService` | 见 flow 文件 |
| `createOrUpdate` | `AppDraftAppService` | `AppDraftDto` | `AppDraftAppServiceImpl` | 见 flow 文件 |
| `saveApplicationOperateLog` | `BpmApplicationOperateLogAppService` | `BpmApplicationOperateLogInfoDto` | 平台服务端 | — |
| `createOrUpdate` | `CompanyAccountServiceAppService` | `CommonCompanyAccountDto` | 平台服务端 | — |
| `create` | `CtpApplicationBaseAppService` | `CtpApplicationAdminCreateDto` | `CtpUserApplicationAppService` | 见 flow 文件 |
| `create` | `CtpAuthorizationRuleOrgAppService` | `CtpAuthorizationRuleAllDto` | `CtpAuthorizationRuleOrgAppServiceMock` | 见 flow 文件 |
| `create` | `CtpManagerTenantAppService` | `CtpManagerTenantDto` | `CtpManagerTenantAppServiceMock` | 见 flow 文件 |
| `createAdmin` | `CtpOrgAdminOrgAppService` | `CtpOrgAdminConfigDto` | `CtpOrgAdminAppServiceMock` | 见 flow 文件 |
| `create` | `CtpRoleCoreAppService` | `CtpRoleDto` | `CtpRoleCoreAppServiceForMock` | 见 flow 文件 |
| `saveBatch` | `CtpRoleCoreAppService` | `CtpRoleSyncDto` | `CtpRoleCoreAppServiceForMock` | 见 flow 文件 |
| `create` | `CtpThirdPlatformConfigCoreAppService` | `CtpThirdPlatformConfigDto` | 平台服务端 | — |
| `create` | `CtpUserCoreAppService` | `CtpUserDto` | `CtpUserCoreAppServiceMock` | 见 flow 文件 |
| `createBatch` | `CtpUserCoreAppService` | — | `CtpUserCoreAppServiceMock` | 见 flow 文件 |
| `createBatch` | `CtpUserResourceCoreAppService` | — | `CtpUserResourceCoreAppServiceMock` | 见 flow 文件 |
| `createAuthorizationRule` | `CtpUserRoleCoreAppService` | `CtpAuthorizationDto` | `CtpUserRoleCoreAppServiceMock` | 见 flow 文件 |
| `createBatch` | `CtpUserRoleCoreAppService` | — | `CtpUserRoleCoreAppServiceMock` | 见 flow 文件 |
| `createBatchAuthorizationRule` | `CtpUserRoleCoreAppService` | `CtpUserRoleSyncDto` | `CtpUserRoleCoreAppServiceMock` | 见 flow 文件 |
| `createUserRule` | `CtpUserRoleCoreAppService` | `CtpRuleRoleDto` | `CtpUserRoleCoreAppServiceMock` | 见 flow 文件 |
| `initData` | `DeductionRtRuleAppService` | `DeductionRtRuleVersionQueryDto` | `DeductionRtRuleAppServiceImpl` | 见 flow 文件 |
| `saveRuleNewVersion` | `DeductionRtRuleAppService` | `DeductionRtRuleDto` | `DeductionRtRuleAppServiceImpl` | 见 flow 文件 |
| `insertOrUpdate` | `EmailAppService` | `CipEmailUserAccountDto` | `EmailAppServiceMock` | 见 flow 文件 |
| `create` | `MyAttentionCommonAppService` | `MyAttentionDto` | `MyAttentionAppService` | 见 flow 文件 |
| `createOrUpdateBatch` | `MyAttentionCommonAppService` | — | `MyAttentionAppService` | 见 flow 文件 |
| `createApp` | `OpenCapabilityAppService` | `AppCreateDto` | `OpenCapabilityAppServiceImp` | 见 flow 文件 |
| `createTenantApp` | `OpenCapabilityAppService` | `TenantAppCreateDto` | `OpenCapabilityAppServiceImp` | 见 flow 文件 |
| `createRedirectBatch` | `PersonalPlanAppService` | — | `PersonalPlanAppServiceImpl` | 见 flow 文件 |
| `createDefaultFilterPlanContentByEntityId` | `PluginPageInfoAppService` | `Long` | `PluginPageInfoAppServiceImpl` | 见 flow 文件 |
| `createBatchCategory` | `PortalPortletAppService` | `UdcPortletCategoryListDto` | `PortalPortletDefinitionAppServiceImpl` | 见 flow 文件 |
| `createBatchPortlet` | `PortalPortletAppService` | `UdcPortletDefinitionListDto` | `PortalPortletDefinitionAppServiceImpl` | 见 flow 文件 |
| `createCategory` | `PortalPortletAppService` | `PortletCategoryDesignerDto` | `PortalPortletDefinitionAppServiceImpl` | 见 flow 文件 |
| `createPortlet` | `PortalPortletAppService` | `PortletDefinitionDesignerDto` | `PortalPortletDefinitionAppServiceImpl` | 见 flow 文件 |
| `createPcTemplateData` | `PortalSetAppService` | `PortalSetDesignerDto` | `PortalSetAppServiceImpl` | 见 flow 文件 |
| `createPortal` | `PortalSetAppService` | `PortalSetDesignerDto` | `PortalSetAppServiceImpl` | 见 flow 文件 |
| `create` | `PortalShortcutAppService` | `PortalShortcutDto` | 平台服务端 | — |
| `createSpace` | `PortalSpaceAppService` | `PortalSpaceDesignerDto` | `PortalSpaceAppServiceImpl` | 见 flow 文件 |
| `saveAsPortalSpaceCopy` | `PortalSpaceAppService` | `UdcPortalSpaceAndInstanceDto` | `PortalSpaceAppServiceImpl` | 见 flow 文件 |
| `create` | `QrCodeCommonAppService` | `QrCodeCreateDto` | `QrCodeCommonAppServiceMock` | 见 flow 文件 |
| `saveSystemConfig` | `SystemConfigCommonAppService` | — | `SystemConfigCommonAppServiceMock` | 见 flow 文件 |
| `createNotification` | `TeamworkMessageAppService` | `TeamworkNotificationMessageDto` | `TeamworkMessageAppServiceImpl` | 见 flow 文件 |
| `createTab` | `TeamworkTabAppService` | `TeamworkGroupTabCreateDto` | `TeamworkTabAppServiceImpl` | 见 flow 文件 |
| `createTabs` | `TeamworkTabAppService` | — | `TeamworkTabAppServiceImpl` | 见 flow 文件 |
| `saveTokenExpireTime` | `TokenAppService` | `String` | 平台服务端 | — |
| `createCategory` | `UdcPortalPortletAppService` | `UdcPortalPortletCategoryDto` | 平台服务端 | — |
| `createOrUpdatePortlet` | `UdcPortalPortletAppService` | `UdcPortalPortletDefinitionDto` | 平台服务端 | — |
| `createPcTemplateData` | `UdcPortalSetAppService` | `UdcPortalSetDesignerDto` | 平台服务端 | — |
| `createEasyScheme` | `UdcSerialSchemeAppService` | `UdcSerialSchemeCreateDto` | `UdcSerialSchemeAppServiceImpl` | 见 flow 文件 |
| `addWarningInfo` | `WarningManageAppService` | `CipWarningInfoDto` | `CipWarningOuterAppService` | 见 flow 文件 |
| `addWarningInfo` | `WarningManageAppService` | `CipWarningInfoDto` | 平台服务端 | — |

## 修改（161）

| 动作方法 | 接口 | 入参 DTO | 实现 | 流转（第一步） |
|---|---|---|---|---|
| `updateAffair` | `AffairCommonAppService` | `AffairUpdateMessageDto` | `AffairCommonAppServiceImpl` | Service:AffairInvokeAppService(affairUpdate) |
| `updateAffairById` | `AffairCommonAppService` | `AffairInfoDto` | `AffairCommonAppServiceImpl` | Service:AffairService(updateAffairById) |
| `updateAffairCategory` | `AffairCommonAppService` | `AffairFullCategoryDto` | `AffairCommonAppServiceImpl` | Service:AffairCategoryService(updateCategory) |
| `updateAffairDone` | `AffairCommonAppService` | `Long` | `AffairCommonAppServiceImpl` | Service:AffairEntityService(updateAffairDone) |
| `updateAffairDoneIdempotent` | `AffairCommonAppService` | `UpdateAffairDoneDto` | `AffairCommonAppServiceImpl` | Other:SingleRequest(getData) |
| `updateAffairIdempotent` | `AffairCommonAppService` | `AffairUpdateMessageIdempotentDto` | `AffairCommonAppServiceImpl` | Other:SingleRequest(getData) |
| `updateAffairRead` | `AffairCommonAppService` | `Long` | `AffairCommonAppServiceImpl` | Service:AffairEntityService(updateAffairRead) |
| `updateAffairReadIdempotent` | `AffairCommonAppService` | `UpdateAffairReadDto` | `AffairCommonAppServiceImpl` | Other:SingleRequest(getData) |
| `updateAffairTrack` | `AffairCommonAppService` | `AffairTrackUpdateDto` | `AffairCommonAppServiceImpl` | Service:AffairEntityService(updateAffairTrack) |
| `updateBatchAffairByCondition` | `AffairCommonAppService` | `AffairUpdateBatchDto` | `AffairCommonAppServiceImpl` | Service:AffairInvokeAppService(updateBatchAffairByCondition) |
| `updateBatchAffairByConditionIdempotent` | `AffairCommonAppService` | `AffairUpdateBatchIdempotentDto` | `AffairCommonAppServiceImpl` | Other:SingleRequest(getData) |
| `updateBpmCaseTrackToAffairTrack` | `AffairCommonAppService` | `AffairTrackUpgradeDto` | `AffairCommonAppServiceImpl` | Service:AffairEntityService(updateBpmCaseTrackToAffairTrack) |
| `updateAffairDoneByMicroflow` | `AffairMicroflowAppService` | `AffairMicroUpdateConditionDto` | `AffairMicroflowAppServiceImpl` | Service:AffairEntityService(updateMicroflowAffairDone) |
| `updateAffairReadByMicroflow` | `AffairMicroflowAppService` | `AffairMicroUpdateConditionDto` | `AffairMicroflowAppServiceImpl` | Service:AffairEntityService(updateMicroflowAffairRead) |
| `updateTemplateAccountId2Affairs` | `AffairSuperviseAppService` | — | `AffairSuperviseAppServiceImpl` | Service:AffairEntityService(updateTemplateAccountId2Affairs) |
| `update` | `AgentCommonAppService` | `AgentDto` | `AgentCommonAppServiceImpl` | Service:AgentService(update) |
| `update` | `ApplicationAppService` | `ApplicationDto` | `ApplicationAppServiceImpl` | Service:ApplicationService(update) |
| `updateBatchDepAppVersion` | `ApplicationAppService` | — | `ApplicationAppServiceImpl` | Service:DependentApplicationService(updateBatchVersion) |
| `updateCaptionForAllVersion` | `ApplicationAppService` | `ApplicationDto` | `ApplicationAppServiceImpl` | Service:ApplicationService(updateCaptionForAllVersion) |
| `updateDepApp` | `ApplicationAppService` | `DependentApplicationDto` | `ApplicationAppServiceImpl` | Service:DependentApplicationService(update) |
| `updateDepAppBatch` | `ApplicationAppService` | — | `ApplicationAppServiceImpl` | Service:DependentApplicationService(updateBatch) |
| `updateNoEvents` | `ApplicationAppService` | `ApplicationDto` | `ApplicationAppServiceImpl` | Service:ApplicationService(updateNoEvents) |
| `update` | `ApplicationManagerAppService` | `ApplicationDto` | `ApplicationManagerAppServiceImpl` | Service:ApplicationService(update) |
| `updateAppCategoryBatch` | `ApplicationManagerAppService` | `AppCategoryDto` | `ApplicationManagerAppServiceImpl` | Service:ApplicationService(updateAppCategoryBatch) |
| `updateWithMember` | `ApplicationManagerAppService` | `ApplicationWithMemberDto` | `ApplicationManagerAppServiceImpl` | Service:ApplicationService(updateWithMember) |
| `updateApplicationOrgInfoByMap` | `ApprovalInvokeAppService` | — | `ApprovalInvokeAppServiceImpl` | Service:ApplicationService(selectById) |
| `update` | `AttributeAppService` | `AttributeDto` | `AttributeAppServiceImpl` | Service:AttributeSetService(selectById) |
| `updateBatch` | `AttributeAppService` | — | `AttributeAppServiceImpl` | Service:AttributeService(updateBatch) |
| `update` | `AttributeGroupAppService` | `AttributeGroupDto` | `AttributeGroupAppServiceImpl` | Service:AttributeGroupService(update) |
| `update` | `AttributeSetAppService` | `AttributeSetDto` | `AttributeSetAppServiceImpl` | Service:AttributeSetService(update) |
| `updateDatabase` | `BaseConfigAppService` | `DatabaseInfoDto` | `BaseConfigAppServiceImpl` | Service:DatabaseInfoService(update) |
| `update` | `BpmApiFormPermissionAppService` | `BpmFormPermissionDto` | `BpmApiFormPermissionAppServiceImpl` | Service:TemplatePublishLockService(checkLockAndAuth) |
| `updateCase` | `BpmCaseAppService` | `BpmCaseDto` | `BpmCaseAppServiceImpl` | Service:BpmCaseService(selectBpmCaseById) |
| `updateNormalApplicationToSpecifiedInstitution` | `BpmNormalAppMultiVersionAppService` | `BpmUpdateApplicationToSpecifiedInstitutionDto` | `BpmNormalAppMultiVersionAppServiceImpl` | Other:SingleRequest(getData) |
| `updateOpinion` | `BpmOpinionAppService` | `BpmOpinionUpdateDto` | `BpmOpinionAppServiceImpl` | Service:BpmOpinionService(updateOpinion) |
| `updateAuthorized` | `BpmTemplateAppService` | — | `BpmTemplateAppServiceImpl` | Service:BpmTemplateService(updateAuthorized) |
| `updateByAppName` | `BpmTemplateAppService` | `BpmTemplateDto` | `BpmTemplateAppServiceImpl` | Service:BpmTemplateService(updateByAppName) |
| `updateCategoryByApplicationId` | `BpmTemplateAppService` | `BpmUpdateCategoryDto` | `BpmTemplateAppServiceImpl` | Service:BpmTemplateService(updateCategoryByApplicationId) |
| `updateEffectTime` | `BpmTemplateAppService` | `String` | `BpmTemplateAppServiceImpl` | Other:SingleResponse(ok) |
| `updateEffectTimeByTemplateId` | `BpmTemplateAppService` | `BpmStartTemplateDto` | `BpmTemplateAppServiceImpl` | Service:BpmTemplateService(updateAndSaveEffectTimeByTemplateId) |
| `updateTemplateExtend` | `BpmTemplateAppService` | `BpmTemplateExtendUpdateDto` | `BpmTemplateAppServiceImpl` | Service:BpmTemplateService(selectEntityById) |
| `updateAuth` | `BpmTemplateManageAppService` | `BpmBatchAuthDto` | `BpmTemplateManageAppServiceImpl` | Service:BpmTemplateService(selectById) |
| `updateBatch` | `BpmThirdTemplateSyncAppService` | — | `BpmThirdTemplateSyncAppServiceImpl` | Service:BpmThirdTemplateService(updateBatch) |
| `update` | `CapabilityEnumAppService` | `CapabilityEnumDto` | `CapabilityEnumAppServiceImpl` | Service:CapabilityEnumService(update) |
| `updateItem` | `CapabilityEnumAppService` | `CapabilityEnumItemDto` | `CapabilityEnumAppServiceImpl` | Service:CapabilityEnumItemService(update) |
| `editProviderParams` | `CapabilityManageAppService` | `Long` | `CapabilityManageAppServiceImpl` | Service:ProviderSelectorService(selectProviderById) |
| `modifyEventToken` | `CapabilityManageAppService` | `EventCallbackConfigQueryDto` | `CapabilityManageAppServiceImpl` | Other:SingleResponse(ok) |
| `setAllCapabilityCycleCount` | `CapabilityManageAppService` | `AllCapabilityCycleCountDto` | `CapabilityManageAppServiceImpl` | Service:ProviderManageService(setAllCapabilityCycleCount) |
| `setCapabilityCycleCount` | `CapabilityManageAppService` | `CapabilityCycleCountDto` | `CapabilityManageAppServiceImpl` | Service:ProviderManageService(setCapabilityCycleCount) |
| `updateApp` | `CapabilityManageAppService` | `CipAppUpdateDto` | `CapabilityManageAppServiceImpl` | Service:CipAppService(update) |
| `updateAppConfig` | `CapabilityManageAppService` | `CipAppFeatureProviderCreateInDto` | `CapabilityManageAppServiceImpl` | Service:CipAppFeatureProviderService(updateAppConfig) |
| `updateDefaultProvider` | `CapabilityManageAppService` | `SelectProvicerEnableDto` | `CapabilityManageAppServiceImpl` | Service:ProviderSelectorService(updateDefaultProvider) |
| `update` | `CategoryCommonAppService` | `CategoryDto` | `CategoryCommonAppServiceImpl` | Service:CategoryService(update) |
| `updateDetection` | `ConsistenceDetectionAppService` | `Class` | `ConsistenceDetectionAppServiceImpl` | Service:ConsistenceDetectionService(updateDetection) |
| `updateDetection4Dto` | `ConsistenceDetectionAppService` | `Class` | `ConsistenceDetectionAppServiceImpl` | Service:ConsistenceDetectionService(updateDetection4Dto) |
| `updateCtpMessageClientType` | `CtpMessageClientAppService` | — | `CtpMessageClientAppServiceImpl` | Service:CtpMessageClientService(updateCtpMessageClientType) |
| `set` | `CtpMessageManageAppService` | `CtpMessageManageDto` | `CtpMessageManageAppServiceImpl` | Service:CtpMessageManageService(set) |
| `updateBatchUserCode` | `CtpOrgUpgradeAppService` | — | `CtpOrgUpgradeAppServiceImpl` | Dao:Wrapper(and) |
| `update` | `CtpPermissionApprovalOrgAppService` | `CtpPermissionApprovalDto` | `CtpPermissionApprovalOrgAppServiceImpl` | Service:CtpPermissionApprovalAppService(audit) |
| `update` | `DataTransferObjectAppService` | `DataTransferObjectDto` | `DataTransferObjectAppServiceImpl` | Service:DataTransferObjectService(update) |
| `updateDtoWithAttrs` | `DataTransferObjectAppService` | `DataTransferObjectDto` | `DataTransferObjectAppServiceImpl` | Service:DtoAttributeService(selectByDtoId) |
| `updateDtoWithAttrs4EntityEvent` | `DataTransferObjectAppService` | `EventAndDataDto` | `DataTransferObjectAppServiceImpl` | Service:EntityService(selectEntityByIdsLoadAttribute) |
| `updateDtoWithAttrsAndRefDtos` | `DataTransferObjectAppService` | — | `DataTransferObjectAppServiceImpl` | Service:DtoAttributeService(deleteByIds) |
| `editFileHistory` | `DocCallBackAppService` | `DocFileInfoDto` | `DocCallBackAppServiceImpl` | Service:DocCallBackService(editFileHistory) |
| `editFileNotify` | `DocCallBackAppService` | `DocFileInfoDto` | `DocCallBackAppServiceImpl` | Other:SingleResponse(from) |
| `editFileOnline` | `DocCallBackAppService` | `DocFileInfoDto` | `DocCallBackAppServiceImpl` | Other:SingleResponse(from) |
| `editFileRename` | `DocCallBackAppService` | `DocFileInfoDto` | `DocCallBackAppServiceImpl` | Service:DocCallBackService(editFileRename) |
| `editFileSave` | `DocCallBackAppService` | `DocFileInfoDto` | `DocCallBackAppServiceImpl` | Service:DocCallBackService(editFileSave) |
| `editFileVersion` | `DocCallBackAppService` | `DocFileInfoDto` | `DocCallBackAppServiceImpl` | Other:SingleResponse(from) |
| `editInfo` | `DocCallBackAppService` | `DocFileInfoDto` | `DocCallBackAppServiceImpl` | Other:SingleResponse(from) |
| `editOnNotify` | `DocCallBackAppService` | `DocFileInfoDto` | `DocCallBackAppServiceImpl` | Other:SingleResponse(from) |
| `editUserAuth` | `DocCallBackAppService` | `DocFileInfoDto` | `DocCallBackAppServiceImpl` | Other:SingleResponse(from) |
| `setBookmarkPermissions` | `DocOnlineAppService` | `DocSetBookmarkPermissionsDto` | `DocOnlineAppServiceImpl` | Service:DocOnlineService(setBookmarkPermissions) |
| `update` | `DtoAttributeAppService` | `DtoAttributeDto` | `DtoAttributeAppServiceImpl` | Service:DtoAttributeService(update) |
| `modifyEmailTemplate` | `EmailPrivateAppService` | `CipEmailTemplateDto` | `EmailPrivateAppServiceImpl` | Service:EmailService(modifyEmailTemplate) |
| `update` | `EntityAppService` | `EntityDto` | `EntityAppServiceImpl` | Service:EntityService(update) |
| `update` | `EntityGroupAppService` | `EntityGroupDto` | `EntityGroupAppServiceImpl` | Service:EntityGroupService(update) |
| `updateBatch` | `EntityGroupAppService` | — | `EntityGroupAppServiceImpl` | Service:EntityGroupService(updateBatch) |
| `update` | `EntityPresetAppService` | `EntityPresetDto` | `EntityPresetAppServiceImpl` | Service:EntityPresetService(update) |
| `update` | `EventAppService` | `EventDto` | `EventAppServiceImpl` | Service:EventService(update) |
| `updateWithEventData` | `EventWithDataAppService` | `EventAndDataDto` | `EventWithDataAppServiceImpl` | Service:EventService(selectWithEventData) |
| `updateFace` | `FaceIdAppService` | `FaceUpdateReqDto` | `FaceIdAppServiceImpl` | Service:FaceIdService(updateFace) |
| `update` | `ImageAppService` | — | `ImageAppServiceImpl` | Service:ImageService(updateBatch) |
| `update` | `IndexAppService` | `IndexDto` | `IndexAppServiceImpl` | Service:EntityService(selectById) |
| `updateIndexAuth` | `IndexStoreAppService` | `IndexUpdateAuthDto` | `IndexStoreAppServiceImpl` | Service:IndexStoreService(updateIndexAuth) |
| `updateReferenceCount` | `LabelAppService` | `LabelDepartmentDto` | `LabelCommonAppServiceImpl` | Service:LabelService(updateReferenceCount) |
| `modifyOrgMappingDetail` | `MappingDetailAppService` | `OrgMappingDetailUpdateReqDto` | `MappingDetailAppServiceImpl` | Service:OrgMappingDetailService(modifyOrgMappingDetail) |
| `modifyUserMappingDetail` | `MappingDetailAppService` | `UserMappingDetailUpdateReqDto` | `MappingDetailAppServiceImpl` | Service:UserMappingDetailService(modifyUserMappingDetail) |
| `updateMerchant` | `MerchantAppService` | `MerchantDto` | `MerchantAppServiceImpl` | Service:MerchantService(updateMerchant) |
| `update` | `MgnAggDataInitAppService` | `CtpMgnAggDataDto` | `MgnAggDataInitAppServiceImpl` | Dao:CtpMgnAggDataDao(update) |
| `update` | `MobilePluginConfigAppService` | `MobilePluginPlatformConfigDto` | `MobilePluginConfigAppServiceImpl` | Service:CipCapabilityMobileConfigGeneralizationInvoker(update) |
| `updateStatus` | `MobilePluginConfigAppService` | `MobilePluginPlatformConfigDto` | `MobilePluginConfigAppServiceImpl` | Service:CipCapabilityMobileConfigGeneralizationInvoker(updateStatus) |
| `updateCardInfo` | `OrgIntegrationAppService` | `UpdateReqDto` | `OrgIntegrationAppServiceImpl` | Service:OrgIntegrationService(updateCardInfo) |
| `update` | `OrgJobBaseAppService` | `OrgJobRequestDto` | `OrgJobBaseAppServiceImpl` | Service:OrgJobService(update) |
| `update` | `OrgLevelBaseAppService` | `OrgLevelRequestDto` | `OrgLevelBaseAppServiceImpl` | Service:OrgLevelService(update) |
| `update` | `OrgMemberBaseAppService` | `OrgUpdateMemberBaseDto` | `OrgMemberBaseAppServiceImpl` | Service:OrgMemberService(selectById) |
| `update` | `OrgMemberPostBaseAppService` | `OrgMemberPostDto` | `OrgMemberPostAppServiceImpl` | Other:SingleRequest(getData) |
| `update` | `OrgPostBaseAppService` | `OrgPostRequestDto` | `OrgPostBaseAppServiceImpl` | Service:OrgPostService(update) |
| `update` | `OrgUnitBaseAppService` | `OrgUpdateUnitBaseDto` | `OrgUnitBaseAppServiceImpl` | Service:OrgBusinessService(selectAdministrativeId) |
| `update` | `OrgUnitTeamCoreAppService` | `OrgUnitTeamDto` | `OrgUnitTeamCoreAppServiceImpl` | Service:OrgUnitTeamService(update) |
| `update` | `ParameterAppService` | `UdcParameterDto` | `ParameterAppServiceImpl` | Service:ParameterService(update) |
| `update` | `PluginEntityAppService` | `EntityDto` | `PluginEntityAppServiceImpl` | Service:EntityService(update) |
| `updateDefaultRefer` | `PluginReferConfigGroupAppService` | `Long` | `PluginReferConfigGroupAppServiceImpl` | Service:EntityService(selectById) |
| `updateState` | `PublishStateAppService` | `PublishStateUpdateDto` | `PublishStateAppServiceImpl` | Service:PublishStateService(updateState) |
| `updateApplication` | `QueryAppService` | — | `QueryAppServiceImpl` | Dao:UdcApplicationDao(updateColumns) |
| `update` | `ReferConfigAppService` | `ReferConfigDto` | `ReferConfigAppServiceImpl` | Service:ReferConfigService(update) |
| `updateConfigInfo` | `ReferConfigGroupAppService` | `ReferConfigInfoDto` | `ReferConfigGroupAppServiceImpl` | Service:ReferConfigGroupService(updateConfigInfo) |
| `update` | `ScalabilityAppService` | `ScalabilityDto` | `ScalabilityAppServiceImpl` | Service:ScalabilityOptionService(selectById) |
| `update` | `ScalabilityOptionAppService` | `ScalabilityOptionDto` | `ScalabilityOptionAppServiceImpl` | Service:ScalabilityOptionService(update) |
| `updateSchedule` | `ScheduleAppService` | `UpdateScheduleDto` | `ScheduleAppServiceImpl` | Service:ScheduleService(updateSchedule) |
| `updateTemplateContent` | `ShortMessageProviderTemplateAppService` | `ShortMessageProviderTemplateDto` | `ShortMessageProviderTemplateAppServiceImpl` | Service:ShortMessageProviderTemplateService(updateTemplateContent) |
| `updateShortMessageSign` | `ShortMessageSignAppService` | `ShortMessageSignDto` | `ShortMessageSignAppServiceImpl` | Service:ShortMessageSignService(updateSign) |
| `updateSmsSign` | `ShortMessageSignAppService` | `SmsSignCloudDto` | `ShortMessageSignAppServiceImpl` | Service:ShortMessageSignService(updateSmsSign) |
| `updateTemplateSign` | `ShortMessageSignAppService` | `ShortMessageSignDto` | `ShortMessageSignAppServiceImpl` | Service:ShortMessageSignService(updateSign) |
| `setTemplateSign` | `ShortMessageTemplateAppService` | `SmsSetSignDto` | `ShortMessageTemplateAppServiceImpl` | Service:ShortMessageTemplateService(setTemplateSign) |
| `updateShortMessageTemplate` | `ShortMessageTemplateAppService` | `ShortMessageTemplateDto` | `ShortMessageTemplateAppServiceImpl` | Service:ShortMessageTemplateService(update) |
| `updateTemplate` | `ShortMessageTemplateAppService` | `ShortMessageTemplateDto` | `ShortMessageTemplateAppServiceImpl` | Service:ShortMessageTemplateService(update) |
| `updateOrg` | `SignatureAppService` | `OrganizationUpdateDto` | `SignatureAppServiceImpl` | Service:SignatureService(updateOrg) |
| `updateOuterOrg` | `SignatureAppService` | `OuterOrganizationUpdateDto` | `SignatureAppServiceImpl` | Service:SignatureService(updateOuterOrg) |
| `update` | `UdcEnumAppService` | `UdcEnumDto` | `UdcEnumAppServiceImpl` | Service:UdcEnumService(update) |
| `update` | `UdcEnumCategoryAppService` | `UdcEnumCategoryDto` | `UdcEnumCategoryAppServiceImpl` | Service:UdcEnumCategoryService(update) |
| `update` | `UdcEnumItemAppService` | `UdcEnumItemDto` | `UdcEnumItemAppServiceImpl` | Service:UdcEnumItemService(update) |
| `updateFunctionRefer` | `UdcFunctionAppService` | — | `UdcFunctionAppServiceImpl` | Service:FunctionNodeService(updatePortalFunctionRefer) |
| `updateMeetingRoomResource` | `VideoMeetingAppService` | `VideoMeetingRoomResourceDto` | `VideoMeetingAppServiceImpl` | Service:VideoMeetingRoomService(updateMeetingRoomResource) |
| `updateVideoMeeting` | `VideoMeetingAppService` | `VideoMeetingUpdateDto` | `VideoMeetingAppServiceImpl` | Service:VideoMeetingManagerService(updateVideoMeeting) |
| `updateVideoMeetingRoom` | `VideoMeetingAppService` | `VideoMeetingRoomUpdateDto` | `VideoMeetingAppServiceImpl` | Service:VideoMeetingRoomService(updateVideoMeetingRoom) |
| `update` | `AgentCoreAppService` | `AgentDto` | `AgentAppService` | 见 flow 文件 |
| `updateAppLogs` | `BpmApplicationOperateLogAppService` | — | 平台服务端 | — |
| `update` | `CtpApplicationBaseAppService` | `CtpApplicationAdminCreateDto` | `CtpUserApplicationAppService` | 见 flow 文件 |
| `updateOnlineStatus` | `CtpApplicationBaseAppService` | `String` | `CtpUserApplicationAppService` | 见 flow 文件 |
| `updateStatus` | `CtpApplicationBaseAppService` | `Long` | `CtpUserApplicationAppService` | 见 flow 文件 |
| `update` | `CtpAuthorizationRuleOrgAppService` | `CtpAuthorizationRuleAllDto` | `CtpAuthorizationRuleOrgAppServiceMock` | 见 flow 文件 |
| `updateByUseTenantId` | `CtpManagerTenantAppService` | `CtpManagerTenantDto` | `CtpManagerTenantAppServiceMock` | 见 flow 文件 |
| `updateStatusByUseTenantId` | `CtpManagerTenantAppService` | `CtpManagerTenantStatusDto` | `CtpManagerTenantAppServiceMock` | 见 flow 文件 |
| `updateTenantAdmin` | `CtpManagerTenantAppService` | `CtpManagerTenantAdminUpdateDto` | `CtpManagerTenantAppServiceMock` | 见 flow 文件 |
| `updateAdmin` | `CtpOrgAdminOrgAppService` | `CtpOrgAdminConfigDto` | `CtpOrgAdminAppServiceMock` | 见 flow 文件 |
| `updateByCode` | `CtpResourceCoreAppService` | `CtpResourceDto` | `CtpResourceCoreAppServiceMock` | 见 flow 文件 |
| `update` | `CtpRoleCoreAppService` | `CtpRoleDto` | `CtpRoleCoreAppServiceForMock` | 见 flow 文件 |
| `update` | `CtpThirdPlatformConfigCoreAppService` | `CtpThirdPlatformConfigDto` | 平台服务端 | — |
| `update` | `CtpUserCoreAppService` | `CtpUserDto` | `CtpUserCoreAppServiceMock` | 见 flow 文件 |
| `updateBatch` | `CtpUserCoreAppService` | — | `CtpUserCoreAppServiceMock` | 见 flow 文件 |
| `update` | `DataFlowMappingAppService` | `DataFlowRtMappingSaveDto` | `DataFlowMappingAppServiceImpl` | 见 flow 文件 |
| `updateMappingState` | `DataFlowMappingAppService` | `DataFlowMappingStateUpdateDto` | `DataFlowMappingAppServiceImpl` | 见 flow 文件 |
| `update` | `MyAttentionCommonAppService` | `MyAttentionDto` | `MyAttentionAppService` | 见 flow 文件 |
| `updateAppCharges` | `OpenCapabilityAppService` | `CapabilityRechargeDto` | `OpenCapabilityAppServiceImp` | 见 flow 文件 |
| `modifyMemberInfoBySelf` | `OrgMemberCoreAppService` | `OrgModifyMemberInfoSelfDto` | `OrgMemberCoreAppServiceMock` | 见 flow 文件 |
| `updateCategory` | `PortalPortletAppService` | `PortletCategoryDesignerDto` | `PortalPortletDefinitionAppServiceImpl` | 见 flow 文件 |
| `updatePortletName` | `PortalPortletAppService` | `PortletDefinitionDesignerDto` | `PortalPortletDefinitionAppServiceImpl` | 见 flow 文件 |
| `updatePortletSortNos` | `PortalPortletAppService` | `PortalPortletSortNoParamDto` | `PortalPortletDefinitionAppServiceImpl` | 见 flow 文件 |
| `updatePortal` | `PortalSetAppService` | `PortalSetDesignerDto` | `PortalSetAppServiceImpl` | 见 flow 文件 |
| `update` | `PortalShortcutAppService` | `PortalShortcutDto` | 平台服务端 | — |
| `updateSpace` | `PortalSpaceAppService` | `PortalSpaceDesignerDto` | `PortalSpaceAppServiceImpl` | 见 flow 文件 |
| `updateBatch` | `ScalabilityFieldAppService` | — | `ScalabilityFieldAppServiceImpl` | 见 flow 文件 |
| `updateTab` | `TeamworkTabAppService` | `TeamworkGroupTabUpdateDto` | `TeamworkTabAppServiceImpl` | 见 flow 文件 |
| `updateTabs` | `TeamworkTabAppService` | — | `TeamworkTabAppServiceImpl` | 见 flow 文件 |
| `updateCategory` | `UdcPortalPortletAppService` | `UdcPortalPortletCategoryDto` | 平台服务端 | — |
| `updatePortletName` | `UdcPortalPortletAppService` | `UdcPortalPortletDefinitionDto` | 平台服务端 | — |
| `updatePortletSortNos` | `UdcPortalPortletAppService` | `UdcPortalPortletSortNoParamDto` | 平台服务端 | — |
| `update` | `UdcSerialConfigAppService` | `UdcSerialConfigDto` | `UdcSerialConfigAppServiceImpl` | 见 flow 文件 |
| `modifyWarningInfo` | `WarningManageAppService` | `CipWarningInfoDto` | `CipWarningOuterAppService` | 见 flow 文件 |
| `modifyWarningInfo` | `WarningManageAppService` | `CipWarningInfoDto` | 平台服务端 | — |

## 删除（141）

| 动作方法 | 接口 | 入参 DTO | 实现 | 流转（第一步） |
|---|---|---|---|---|
| `deleteAffairByIds` | `AffairCommonAppService` | `AffairCommonIdsDto` | `AffairCommonAppServiceImpl` | Service:AffairEntityService(deleteAffairByIds) |
| `deleteAffairByObjectIds` | `AffairCommonAppService` | `AffairCommonIdsDto` | `AffairCommonAppServiceImpl` | Service:AffairEntityService(deleteAffairByObjectIds) |
| `deleteAffairCategoryByCondition` | `AffairCommonAppService` | `AffairDeleteCategoryConditionDto` | `AffairCommonAppServiceImpl` | Service:AffairCategoryService(deleteCategoryByAppNameAndSubAppName) |
| `deleteAffairCategoryById` | `AffairCommonAppService` | `Long` | `AffairCommonAppServiceImpl` | Service:AffairCategoryService(deleteCategoryById) |
| `deleteByIds` | `AffairNodePermissionAppService` | — | `AffairNodePermissionAppServiceImpl` | Service:AffairNodePermissionService(deleteByIds) |
| `deleteCategory` | `AffairOpenAppService` | `AffairDeleteCategoryConditionDto` | `AffairOpenApiAppServiceImpl` | Service:AffairCategoryService(deleteCategoryByAppNameAndSubAppName) |
| `deleteCategoryHierarchy` | `AffairOpenAppService` | `AffairCategoryHierarchyDeleteDto` | `AffairOpenApiAppServiceImpl` | Service:AffairCategoryHierarchyService(deleteCategoryHierarchy) |
| `deleteAgent` | `AgentCommonAppService` | — | `AgentCommonAppServiceImpl` | Service:AgentService(deleteAgent) |
| `deleteByGuid` | `ApplicationAppService` | `Long` | `ApplicationAppServiceImpl` | Service:ApplicationService(deleteByGuid) |
| `deleteById` | `ApplicationAppService` | `Long` | `ApplicationAppServiceImpl` | Service:ApplicationService(deleteById) |
| `deleteDepAppById` | `ApplicationAppService` | `Long` | `ApplicationAppServiceImpl` | Service:DependentApplicationService(deleteById) |
| `deleteDepAppsByAppId` | `ApplicationAppService` | `Long` | `ApplicationAppServiceImpl` | Service:DependentApplicationService(deleteByAppId) |
| `deleteDepAppsByIds` | `ApplicationAppService` | — | `ApplicationAppServiceImpl` | Service:DependentApplicationService(deleteByIds) |
| `deleteFormAppByGuid` | `ApplicationAppService` | `Long` | `ApplicationAppServiceImpl` | Service:ApplicationService(deleteFormAppByGuid) |
| `deleteById` | `ApplicationManagerAppService` | `Long` | `ApplicationManagerAppServiceImpl` | Service:ApplicationService(deleteById) |
| `deleteFormAppByGuid` | `ApplicationManagerAppService` | `Long` | `ApplicationManagerAppServiceImpl` | Service:ApplicationService(deleteFormAppByGuid) |
| `deleteFormAppByName` | `ApplicationManagerAppService` | `String` | `ApplicationManagerAppServiceImpl` | Service:ApplicationService(selectByAppName) |
| `deleteMemberById` | `ApplicationManagerAppService` | `Long` | `ApplicationManagerAppServiceImpl` | Service:AppCollaborationAppServiceImpl(deleteMemberById) |
| `deleteAllTemporaryData` | `ApprovalInvokeAppService` | — | `ApprovalInvokeAppServiceImpl` | Service:AppDraftAppService(deleteAll) |
| `deleteById` | `AttributeAppService` | `Long` | `AttributeAppServiceImpl` | Service:AttributeService(selectById) |
| `deleteByIds` | `AttributeAppService` | — | `AttributeAppServiceImpl` | Service:AttributeService(selectById) |
| `cancel` | `AttributeGroupAppService` | `AttributeGroupDto` | `AttributeGroupAppServiceImpl` | Service:AttributeGroupService(cancel) |
| `remove` | `AttributeGroupAppService` | `AttributeGroupDto` | `AttributeGroupAppServiceImpl` | Service:AttributeGroupService(remove) |
| `deleteById` | `AttributeSetAppService` | `Long` | `AttributeSetAppServiceImpl` | Service:AttributeSetService(selectById) |
| `deleteByIds` | `AttributeSetAppService` | — | `AttributeSetAppServiceImpl` | Service:AttributeSetService(selectById) |
| `deleteDatabaseById` | `BaseConfigAppService` | `Long` | `BaseConfigAppServiceImpl` | Service:DatabaseInfoService(deleteById) |
| `deleteById` | `BpmApiFormPermissionAppService` | `Long` | `BpmApiFormPermissionAppServiceImpl` | Service:BpmFormPermissionService(selectPermissionById) |
| `deleteFormPermisionForceEntityDraft` | `BpmApiFormPermissionAppService` | `BpmFormPermissionDeleteRequestDto` | `BpmApiFormPermissionAppServiceImpl` | Service:BpmFormPermissionService(deleteFormPermisionForceEntityDraft) |
| `deleteSettingByIds` | `BpmApiParamAppService` | — | `BpmApiParamAppServiceImpl` | Service:BpmParameterService(deleteSettingByIds) |
| `cancelItems` | `BpmAppService` | `BpmCancelItemDto` | `BpmApiAppServiceImpl` | Service:BpmOperationService(cancelItems) |
| `cancelPause` | `BpmAppService` | `BpmPauseDto` | `BpmApiAppServiceImpl` | Service:BpmProcessSuperviseService(cancelPause) |
| `deleteDraft` | `BpmAppService` | `Long` | `BpmApiAppServiceImpl` | Service:BpmOperationService(deleteDraft) |
| `deleteDraftAffair` | `BpmAppService` | `DeleteDraftReqDto` | `BpmApiAppServiceImpl` | Service:BpmOperationService(deleteDraft) |
| `deleteCaseByIds` | `BpmCaseAppService` | `BpmDeleteCaseDto` | `BpmCaseAppServiceImpl` | Service:BpmCaseService(deleteByFormDataCaseIds) |
| `deleteOpinion` | `BpmOpinionAppService` | `BpmDeleteOpinionDto` | `BpmOpinionAppServiceImpl` | Service:OpinionService(deleteByAffairId) |
| `cancelFocus` | `BpmSuperviseAppService` | `SuperviseCancelFocusDto` | `BpmSuperviseAppServiceImpl` | Service:BpmVipSuperviseService(cancelFocus) |
| `deleteByApps` | `BpmTemplateAppService` | — | `BpmTemplateAppServiceImpl` | Service:DeployLifeCycleManage(postDeleteApps) |
| `deleteById` | `BpmTemplateAppService` | `Long` | `BpmTemplateAppServiceImpl` | Service:BpmTemplateService(selectById) |
| `clearDefaultFrameCache` | `BpmTemplateManageAppService` | `String` | `BpmTemplateManageAppServiceImpl` | Event:BpmLocalCacheEventDispatcher(onDefaultFrameUpdate) |
| `delete` | `CapabilityEnumAppService` | `Long` | `CapabilityEnumAppServiceImpl` | Service:CapabilityEnumService(delete) |
| `deleteItem` | `CapabilityEnumAppService` | `Long` | `CapabilityEnumAppServiceImpl` | Service:CapabilityEnumItemService(delete) |
| `deleteItemByIds` | `CapabilityEnumAppService` | — | `CapabilityEnumAppServiceImpl` | Service:CapabilityEnumItemService(deleteByIds) |
| `deleteApp` | `CapabilityManageAppService` | `Long` | `CapabilityManageAppServiceImpl` | Service:CipAppService(delete) |
| `deleteParam` | `CapabilityManageAppService` | `Long` | `CapabilityManageAppServiceImpl` | Service:ProviderSelectorService(selectProviderById) |
| `deleteById` | `CategoryCommonAppService` | `Long` | `CategoryCommonAppServiceImpl` | Service:CategoryService(deleteById) |
| `deleteApp` | `CdpBiz4UdcAppService` | `DeleteAppParamsDto` | `CdpBiz4UdcAppServiceImpl` | Service:AppDeleteService(deleteAppData) |
| `deleteByStorageKeys` | `CipFileAppService` | `FileDeleteDto` | `CipFileAppServiceImpl` | Service:FileService(deleteByStorageKeys) |
| `deliveryMqMessage` | `CipMessageAppService` | `CipMessageDeliveryDto` | `CipMessageDeliveryAppServiceImpl` | Service:AppServiceInvokeDto(setCommandId) |
| `deleteDetection` | `ConsistenceDetectionAppService` | `Class` | `ConsistenceDetectionAppServiceImpl` | Service:ConsistenceDetectionService(deleteDetection4Dto) |
| `deleteMessageByCode` | `CtpMessageAppService` | — | `CtpMessageAppServiceImpl` | Service:CtpMessageService(deleteMessageByCode) |
| `deleteMessageByCode` | `CtpMessageClientAppService` | — | `CtpMessageClientAppServiceImpl` | Service:CtpMessageService(deleteMessageByCode) |
| `deleteMessageByMessageId` | `CtpMessageClientAppService` | — | `CtpMessageClientAppServiceImpl` | Service:CtpMessageService(deleteMessageByMessageId) |
| `deleteMessageRegister` | `CtpMessageManageAppService` | `String` | `CtpMessageManageAppServiceImpl` | Service:CtpMessageManageService(deleteMessageRegister) |
| `deleteMessageByIdentification` | `CtpMessageOperateAppService` | `String` | `CtpMessageOperateAppServiceImpl` | Service:CtpMessageService(deleteMessageByIdentification) |
| `deleteByIds` | `CtpPersonalPlanCoreAppService` | — | `CtpPersonalPlanCoreAppServiceImpl` | Service:CtpResourcePermissionCoreAppServiceImpl(deleteByResourceCodeNew) |
| `deleteDesignResources` | `CtpResourceCommonAppService` | `String` | `CtpResourceCommonAppServiceImpl` | Other:SingleResponse(from) |
| `deleteById` | `DataTransferObjectAppService` | `Long` | `DataTransferObjectAppServiceImpl` | Service:DataTransferObjectService(selectById) |
| `deleteDtoWithAttrsAndRefDtos` | `DataTransferObjectAppService` | `Long` | `DataTransferObjectAppServiceImpl` | Service:DataTransferObjectService(selectById) |
| `deleteById` | `DtoAttributeAppService` | `Long` | `DtoAttributeAppServiceImpl` | Service:DtoAttributeService(deleteById) |
| `deleteByIds` | `DtoAttributeAppService` | — | `DtoAttributeAppServiceImpl` | Service:DtoAttributeService(deleteByIds) |
| `deleteEmailConfig` | `EmailPrivateAppService` | — | `EmailPrivateAppServiceImpl` | Service:EmailService(deleteEmailConfig) |
| `deleteEmailTemplate` | `EmailPrivateAppService` | `String` | `EmailPrivateAppServiceImpl` | Service:EmailService(deleteEmailTemplate) |
| `deleteEmailTemplates` | `EmailPrivateAppService` | — | `EmailPrivateAppServiceImpl` | Service:CipEmailTemplateService(deleteEmailTemplateBatch) |
| `deleteById` | `EntityAppService` | `Long` | `EntityAppServiceImpl` | Service:EntityService(selectById) |
| `deleteByIds` | `EntityAppService` | — | `EntityAppServiceImpl` | Service:EntityService(selectById) |
| `deleteById` | `EntityGroupAppService` | `Long` | `EntityGroupAppServiceImpl` | Service:EntityGroupService(selectById) |
| `deleteByIds` | `EntityGroupAppService` | — | `EntityGroupAppServiceImpl` | Service:EntityGroupService(selectById) |
| `deleteById` | `EventAppService` | `Long` | `EventAppServiceImpl` | Service:EventService(selectById) |
| `deleteByIds` | `EventAppService` | — | `EventAppServiceImpl` | Service:EventService(selectByIds) |
| `deleteImage` | `ImageAppService` | — | `ImageAppServiceImpl` | Service:ImageService(deleteBatch) |
| `deleteCategory` | `ImageCategoryAppService` | `Long` | `ImageCategoryAppServiceImpl` | Service:ImageCategoryService(delete) |
| `deleteStore` | `ImageStoreAppService` | `Long` | `ImageStoreAppServiceImpl` | Service:ImageStoreService(delete) |
| `deleteById` | `IndexAppService` | `Long` | `IndexAppServiceImpl` | Service:IndexService(selectById) |
| `deleteByIds` | `IndexAppService` | — | `IndexAppServiceImpl` | Service:IndexService(selectById) |
| `delete` | `IndexStoreAppService` | `IndexDeleteDto` | `IndexStoreAppServiceImpl` | Service:IndexStoreService(delete) |
| `deleteOrgMappingDetail` | `MappingDetailAppService` | `OrgMappingDetailDeleteReqDto` | `MappingDetailAppServiceImpl` | Service:OrgMappingDetailService(deleteMappingDetail) |
| `deleteUserMappingDetail` | `MappingDetailAppService` | `UserMappingDetailDeleteReqDto` | `MappingDetailAppServiceImpl` | Service:UserMappingDetailService(deleteMappingDetail) |
| `deleteMerchant` | `MerchantAppService` | `Long` | `MerchantAppServiceImpl` | Service:MerchantService(deleteMerchant) |
| `delete` | `MiddleTableAppService` | `MiddleTableDeleteReqDto` | `MiddleTableAppServiceImpl` | Service:MiddleTableService(delete) |
| `delete` | `MiddleTableOperationAppService` | `MiddleTableDeleteReqDto` | `MiddleTableOperationAppServiceImpl` | Service:MiddleTableAppService(delete) |
| `deleteByIds` | `MobilePluginConfigAppService` | — | `MobilePluginConfigAppServiceImpl` | Service:CipCapabilityMobileConfigGeneralizationInvoker(deleteByIds) |
| `delete` | `OrgUnitTeamCoreAppService` | `Long` | `OrgUnitTeamCoreAppServiceImpl` | Service:OrgUnitTeamService(delete) |
| `deleteReturnFileByKey` | `OrgWorkFlowAppService` | `WorkFlowSelectStorageKeyRequestDto` | `OrgWorkFlowAppServiceImpl` | Service:FileService(deleteByStorageKeys) |
| `deleteById` | `ParameterAppService` | `Long` | `ParameterAppServiceImpl` | Service:ParameterService(deleteById) |
| `deleteByIds` | `ParameterAppService` | — | `ParameterAppServiceImpl` | Service:ParameterService(deleteByIds) |
| `cancelApply` | `PhysicalSealAppService` | `PhysicalSealApplyIdDto` | `PhysicalSealAppServiceImpl` | Service:PhysicalSealService(cancelApply) |
| `deleteDefaultRefer` | `PluginReferConfigGroupAppService` | — | `PluginReferConfigGroupAppServiceImpl` | Service:ReferConfigGroupService(deleteByEntityIds) |
| `deleteById` | `ReferConfigAppService` | `Long` | `ReferConfigAppServiceImpl` | Service:ReferConfigService(selectById) |
| `deleteById` | `ReferConfigGroupAppService` | `Long` | `ReferConfigGroupAppServiceImpl` | Service:ReferConfigGroupService(selectById) |
| `deleteById` | `ScalabilityAppService` | `Long` | `ScalabilityAppServiceImpl` | Service:ScalabilityService(selectById) |
| `deleteByIds` | `ScalabilityAppService` | — | `ScalabilityAppServiceImpl` | Service:ScalabilityService(selectById) |
| `deleteById` | `ScalabilityOptionAppService` | `Long` | `ScalabilityOptionAppServiceImpl` | Service:ScalabilityOptionService(selectById) |
| `cancelSchedule` | `ScheduleAppService` | `ScheduleInfoDto` | `ScheduleAppServiceImpl` | Service:ScheduleService(cancelSchedule) |
| `deleteTemplateContent` | `ShortMessageProviderTemplateAppService` | `Long` | `ShortMessageProviderTemplateAppServiceImpl` | Service:ShortMessageProviderTemplateService(deleteTemplateContent) |
| `deleteShortMessageSign` | `ShortMessageSignAppService` | `Long` | `ShortMessageSignAppServiceImpl` | Service:ShortMessageSignService(deleteSign) |
| `deleteTemplateById` | `ShortMessageTemplateAppService` | `Long` | `ShortMessageTemplateAppServiceImpl` | Service:ShortMessageTemplateService(deleteById) |
| `deleteTemplateByIds` | `ShortMessageTemplateAppService` | — | `ShortMessageTemplateAppServiceImpl` | Service:ShortMessageTemplateService(deleteByIds) |
| `deleteInnerUsers` | `SignatureAppService` | `DeleteInnerUsersReqDto` | `SignatureAppServiceImpl` | Service:SignatureService(deleteInnerUsers) |
| `deleteById` | `UdcEnumAppService` | `Long` | `UdcEnumAppServiceImpl` | Service:UdcEnumService(selectById) |
| `deleteByIds` | `UdcEnumAppService` | — | `UdcEnumAppServiceImpl` | Service:UdcEnumService(selectById) |
| `deleteById` | `UdcEnumCategoryAppService` | `Long` | `UdcEnumCategoryAppServiceImpl` | Service:UdcEnumCategoryService(selectById) |
| `deleteByIds` | `UdcEnumCategoryAppService` | — | `UdcEnumCategoryAppServiceImpl` | Service:UdcEnumCategoryService(selectById) |
| `deleteById` | `UdcEnumItemAppService` | `Long` | `UdcEnumItemAppServiceImpl` | Service:UdcEnumItemService(deleteById) |
| `deleteByIds` | `UdcEnumItemAppService` | — | `UdcEnumItemAppServiceImpl` | Service:UdcEnumItemService(deleteByIds) |
| `deletePortalFunctionRefer` | `UdcFunctionAppService` | — | `UdcFunctionAppServiceImpl` | Service:FunctionNodeService(deleteSpaceFunctionRefer) |
| `cancelVideoMeeting` | `VideoMeetingAppService` | `VideoMeetingOperateDto` | `VideoMeetingAppServiceImpl` | Service:VideoMeetingManagerService(cancelVideoMeeting) |
| `deleteVideoMeetingRoom` | `VideoMeetingAppService` | `VideoMeetingRoomOperateDto` | `VideoMeetingAppServiceImpl` | Service:VideoMeetingRoomService(deleteVideoMeetingRoom) |
| `cancelAgent` | `AgentCoreAppService` | — | `AgentAppService` | 见 flow 文件 |
| `delete` | `AppDraftAppService` | `String` | `AppDraftAppServiceImpl` | 见 flow 文件 |
| `deleteAll` | `AppDraftAppService` | `String` | `AppDraftAppServiceImpl` | 见 flow 文件 |
| `deleteByAppIdList` | `ApprovalAppService` | — | `ApprovalAppServiceImpl` | 见 flow 文件 |
| `delete` | `CtpAuthorizationRuleOrgAppService` | `CtpAuthorizationRuleDeleteDto` | `CtpAuthorizationRuleOrgAppServiceMock` | 见 flow 文件 |
| `deleteByUseTenantId` | `CtpManagerTenantAppService` | `Long` | `CtpManagerTenantAppServiceMock` | 见 flow 文件 |
| `deleteOrgAdminByOrgId` | `CtpOrgAdminOrgAppService` | `Long` | `CtpOrgAdminAppServiceMock` | 见 flow 文件 |
| `deleteByConditions` | `CtpResourceCoreAppService` | — | `CtpResourceCoreAppServiceMock` | 见 flow 文件 |
| `deleteByResourceCode` | `CtpResourcePermissionCoreAppService` | `String` | `CtpResourcePermissionCoreAppServiceMock` | 见 flow 文件 |
| `deleteByConditions` | `CtpRoleCoreAppService` | — | `CtpRoleCoreAppServiceForMock` | 见 flow 文件 |
| `deleteByIds` | `CtpThirdPlatformConfigCoreAppService` | — | 平台服务端 | — |
| `deleteByConditions` | `CtpUserResourceCoreAppService` | — | `CtpUserResourceCoreAppServiceMock` | 见 flow 文件 |
| `deleteAuthorizationRuleById` | `CtpUserRoleCoreAppService` | `Long` | `CtpUserRoleCoreAppServiceMock` | 见 flow 文件 |
| `deleteByConditions` | `CtpUserRoleCoreAppService` | — | `CtpUserRoleCoreAppServiceMock` | 见 flow 文件 |
| `deleteByIds` | `CtpUserRoleCoreAppService` | — | `CtpUserRoleCoreAppServiceMock` | 见 flow 文件 |
| `deleteBatchByObjectIds` | `MyAttentionCommonAppService` | `MyAttentionBatchDeleteDto` | `MyAttentionAppService` | 见 flow 文件 |
| `deleteByObjectIdOrPageUrl` | `MyAttentionCommonAppService` | — | `MyAttentionAppService` | 见 flow 文件 |
| `deleteByIds` | `PersonalPlanAppService` | — | `PersonalPlanAppServiceImpl` | 见 flow 文件 |
| `deleteCategoryByCodes` | `PortalPortletAppService` | — | `PortalPortletDefinitionAppServiceImpl` | 见 flow 文件 |
| `deletePortletByIds` | `PortalPortletAppService` | — | `PortalPortletDefinitionAppServiceImpl` | 见 flow 文件 |
| `deletePortlets` | `PortalPortletAppService` | `PortletBatchOperateDto` | `PortalPortletDefinitionAppServiceImpl` | 见 flow 文件 |
| `deletePortalDesignInfo` | `PortalSetAppService` | — | `PortalSetAppServiceImpl` | 见 flow 文件 |
| `deleteById` | `PortalShortcutAppService` | `Long` | 平台服务端 | — |
| `deleteSpaceById` | `PortalSpaceAppService` | `Long` | `PortalSpaceAppServiceImpl` | 见 flow 文件 |
| `deleteByApp` | `ResourceAppService` | `Long` | 平台服务端 | — |
| `deleteByPage` | `ResourceAppService` | `UdcResourceDeleteDto` | 平台服务端 | — |
| `deleteByRef` | `ResourceAppService` | `UdcResourceDeleteDto` | 平台服务端 | — |
| `cancelAuthSeal` | `SealAppService` | `SealRequestDto` | 平台服务端 | — |
| `deleteAuthSeal` | `SealAppService` | `SealRequestDto` | 平台服务端 | — |
| `deleteTab` | `TeamworkTabAppService` | `TeamworkGroupTabDeleteDto` | `TeamworkTabAppServiceImpl` | 见 flow 文件 |
| `deleteTabs` | `TeamworkTabGeneralizeAppService` | `TeamworkGroupTabListDto` | 平台服务端 | — |
| `deleteCtpEnumByAppApprovalOrUdc` | `UdcCtpEnumAppService` | `UdcCtpEnumItemSearchDto` | `UdcCtpEnumAppServiceImpl` | 见 flow 文件 |
| `deleteCategoryByIds` | `UdcPortalPortletAppService` | — | 平台服务端 | — |
| `deletePortletByIds` | `UdcPortalPortletAppService` | `UdcPortletBatchOperateDto` | 平台服务端 | — |

## 流程（23）

| 动作方法 | 接口 | 入参 DTO | 实现 | 流转（第一步） |
|---|---|---|---|---|
| `stopCase` | `Affair4WorkflowAppService` | `WorkflowStopDto` | `Affair4WorkflowAppServiceImpl` | Service:AffairInvokeAppService(stopCase) |
| `repeal` | `BpmAppService` | `BpmRepealDto` | `BpmApiAppServiceImpl` | Service:UserAppServiceProxy(getOrgMemberPostCoreDto) |
| `send` | `BpmAppService` | `BpmSendDto` | `BpmApiAppServiceImpl` | Service:BpmUserTemplateService(selectCanSendTemplateByCode) |
| `stop` | `BpmAppService` | `BpmStopDto` | `BpmApiAppServiceImpl` | Service:UserAppServiceProxy(getOrgMemberPostCoreDto) |
| `submit` | `BpmAppService` | `BpmSubmitDto` | `BpmApiAppServiceImpl` | Service:UserAppServiceProxy(getOrgMemberPostCoreDto) |
| `stop` | `BpmTemplateAppService` | `String` | `BpmTemplateAppServiceImpl` | Service:BpmTemplateService(stop) |
| `stopByTemplateId` | `BpmTemplateAppService` | `Long` | `BpmTemplateAppServiceImpl` | Service:BpmTemplateService(stopByTemplateIds) |
| `sendOpenApiRequest` | `CapabilityManageAppService` | `OpenApiSendDto` | `CapabilityManageAppServiceImpl` | Service:OpenApiPropertiesService(sendOpenApiRequest) |
| `sendOpenApiRequestPage` | `CapabilityManageAppService` | `OpenApiSendDto` | `CapabilityManageAppServiceImpl` | Service:OpenApiPropertiesService(sendOpenApiRequestPage) |
| `sendMessage` | `CtpMessageAppService` | — | `CtpMessageAppServiceImpl` | Util:BeanCopier(copy) |
| `submitAudit` | `MobilePluginAppletAppService` | `MobilePluginAppletOpenQueryDto` | `MobilePluginAppletAppServiceImpl` | Service:MobilePluginAppletCapabilityService(submitAudit) |
| `finish` | `SignatureAppService` | `ContractLockRequestDto` | `SignatureAppServiceImpl` | Service:SignatureService(finish) |
| `finishVideoMeeting` | `VideoMeetingAppService` | `VideoMeetingOperateDto` | `VideoMeetingAppServiceImpl` | Service:VideoMeetingManagerService(finishVideoMeeting) |
| `sendMessageByChooseJson` | `CtpUdcMessageSendAppService` | `UdcMessageSendChooseDto` | `CtpUdcMessageSendServiceImpl` | 见 flow 文件 |
| `sendMessageByUser` | `CtpUdcMessageSendAppService` | `UdcMessageSendUserDto` | `CtpUdcMessageSendServiceImpl` | 见 flow 文件 |
| `sendNormalEmail` | `EmailAppService` | `EmailDetailsDto` | `EmailAppServiceMock` | 见 flow 文件 |
| `sendNormalEmailByAccount` | `EmailAppService` | `EmailAppointAccountDto` | `EmailAppServiceMock` | 见 flow 文件 |
| `sendPersonalEmail` | `EmailAppService` | `EmailDetailsDto` | `EmailAppServiceMock` | 见 flow 文件 |
| `sendTemplateEmail` | `EmailAppService` | `EmailTemplateSendDto` | `EmailAppServiceMock` | 见 flow 文件 |
| `sendShortMessage` | `ShortMessageAppService` | `SmsSendDto` | `ShortMessageAppServiceMock` | 见 flow 文件 |
| `sendShortMessageAsync` | `ShortMessageAppService` | — | `ShortMessageAppServiceMock` | 见 flow 文件 |
| `sendSycShortMessage` | `ShortMessageAppService` | `SmsSendDto` | `ShortMessageAppServiceMock` | 见 flow 文件 |
| `sendCard` | `TeamworkMessageAppService` | `TeamworkCardMessageDto` | `TeamworkMessageAppServiceImpl` | 见 flow 文件 |

## 发布（29）

| 动作方法 | 接口 | 入参 DTO | 实现 | 流转（第一步） |
|---|---|---|---|---|
| `publish` | `AffairNodePermissionAppService` | `String` | `AffairNodePermissionAppServiceImpl` | Other:SingleResponse(from) |
| `deployForm` | `ApplicationAppService` | `DeployFormDto` | `ApplicationAppServiceImpl` | Service:ApplicationService(deploy) |
| `deployNormal` | `ApplicationAppService` | `DeployNormalDto` | `ApplicationAppServiceImpl` | Service:ApplicationService(deploy) |
| `deployForm` | `ApplicationManagerAppService` | `DeployFormDto` | `ApplicationManagerAppServiceImpl` | Service:ApplicationService(deploy) |
| `deployNormal` | `ApplicationManagerAppService` | `DeployNormalDto` | `ApplicationManagerAppServiceImpl` | Service:ApplicationService(deploy) |
| `shelfCompatibilityLock` | `ApplicationManagerAppService` | `ShelfCompatibilityLockRequestDto` | `ApplicationManagerAppServiceImpl` | Service:ApplicationService(lockCompatibility) |
| `upgradeOnlyPageApplication` | `ApplicationManagerAppService` | `OnlyPageApplicationUpgradeDto` | `ApplicationManagerAppServiceImpl` | Service:CustomPageInfoService(upgradeSchema) |
| `upgradeOnlyPageApplicationAsync` | `AsyncAppService` | `OnlyPageApplicationUpgradeDto` | `AsyncAppServiceImpl` | Util:Ids(uuidAbsLong) |
| `deployBpmTemplatesIndependent` | `BpmDeployAppService` | `String` | `BpmDeployAppServiceImpl` | Service:BpmIndependentDeployService(deployBpmTemplatesIndependent) |
| `upgradeBpmTemplateVersion` | `BpmDeployAppService` | `String` | `BpmDeployAppServiceImpl` | Other:SingleResponse(from) |
| `upgradeCommon` | `BpmDeployAppService` | `UpgradeInfoDto` | `BpmDeployAppServiceImpl` | Service:UpgradeManage(getHandler) |
| `publishCheck` | `BpmTemplateAppService` | `String` | `BpmTemplateAppServiceImpl` | Service:BpmTemplateService(selectListByApplicationName) |
| `publishCheckByAppInfo` | `BpmTemplateAppService` | `BpmAppInfoDto` | `BpmTemplateAppServiceImpl` | Service:BpmTemplateService(selectDesignTemplatesByAppId) |
| `publishFinish` | `BpmTemplateAppService` | `BpmPublishResult` | `BpmTemplateAppServiceImpl` | Service:BpmTemplateService(publishFinished) |
| `publishLock` | `BpmTemplateAppService` | `String` | `BpmTemplateAppServiceImpl` | Service:BpmTemplateService(publishLock) |
| `publishLockByAppInfo` | `BpmTemplateAppService` | `BpmAppInfoDto` | `BpmTemplateAppServiceImpl` | Service:BpmTemplateService(publishLock) |
| `upgradeExtensionPlan` | `BpmUpgrade51To52AppService` | — | `BpmUpgradeV51To52AppServiceImpl` | Service:BpmTemplateService(selectTemplateByRootEntityName) |
| `deploy` | `CdpBiz4UdcAppService` | `PublishParamsDto` | `CdpBiz4UdcAppServiceImpl` | Other:SingleRequest(getData) |
| `upgradeApps` | `CdpBiz4UdcAppService` | — | `CdpBiz4UdcAppServiceImpl` | Other:SingleRequest(getData) |
| `upgradeCallExtendAppService` | `MicroFlowUpgradeAppService` | `Long` | `MicroFlowUpgradeAppServiceImpl` | Service:MicroFlowService(selectListByConditions) |
| `upgradeEntityEventFullName` | `MicroFlowUpgradeAppService` | `Long` | `MicroFlowUpgradeAppServiceImpl` | Service:MicroFlowService(selectByAppId) |
| `upgradeExtendFullNameByAppId` | `MicroFlowUpgradeAppService` | `String` | `MicroFlowUpgradeAppServiceImpl` | Service:ApplicationService(selectById) |
| `upgradeThirdEntity` | `MicroFlowUpgradeAppService` | `String` | `MicroFlowUpgradeAppServiceImpl` | Service:ApplicationService(selectById) |
| `upgradeThirdServiceByNames` | `MicroFlowUpgradeAppService` | `ThirdServiceQueryDto` | `MicroFlowUpgradeAppServiceImpl` | Service:ThirdServiceQueryDto(getAppId) |
| `releaseAudited` | `MobilePluginAppletAppService` | `MobilePluginAppletOpenCommonDto` | `MobilePluginAppletAppServiceImpl` | Service:MobilePluginAppletCapabilityService(releaseAudited) |
| `publishById` | `ThemeAppService` | `Long` | `ThemeAppServiceImpl` | Service:ThemeService(publishById) |
| `upgrade` | `FeatureAppService` | `String` | `FeatureAppServiceImpl` | 见 flow 文件 |
| `publishPortalDesignInfo` | `PortalSetAppService` | `Long` | `PortalSetAppServiceImpl` | 见 flow 文件 |
| `upgrade` | `StereotypeAppService` | `String` | `StereotypeAppServiceImpl` | 见 flow 文件 |

## 导入导出（35）

| 动作方法 | 接口 | 入参 DTO | 实现 | 流转（第一步） |
|---|---|---|---|---|
| `copyApp` | `ApplicationAppService` | `ApplicationCopyDto` | `ApplicationAppServiceImpl` | Util:RequestUtils(requestAsync) |
| `importAppOnlineIntoCurrentApp` | `ApplicationAppService` | — | `ApplicationAppServiceImpl` | Other:AutoCodeManager(importAppSchemaOnLine) |
| `importAppZipIntoCurrentApp` | `ApplicationAppService` | — | `ApplicationAppServiceImpl` | Other:AutoCodeManager(importAppSchemaZip) |
| `copyApp` | `ApplicationManagerAppService` | `ApplicationCopyDto` | `ApplicationManagerAppServiceImpl` | Other:SingleRequest(getData) |
| `copyAppAsync` | `ApplicationManagerAppService` | `ApplicationCopyDto` | `ApplicationManagerAppServiceImpl` | Util:RequestUtils(requestAsync) |
| `copyLayoutApp` | `ApplicationManagerAppService` | `ApplicationCopyDto` | `ApplicationManagerAppServiceImpl` | Service:CustomPageInfoService(getLayoutByAppId) |
| `copyOnlyPageApp` | `ApplicationManagerAppService` | `ApplicationCopyDto` | `ApplicationManagerAppServiceImpl` | Service:CustomPageInfoService(getOriginNewPagePairListByAppId) |
| `exportAppInfos` | `ApplicationManagerAppService` | `AppInfoExportDto` | `ApplicationManagerAppServiceImpl` | Service:AppVersionService(exportAppInfos) |
| `importApp` | `ApplicationManagerAppService` | `String` | `ApplicationManagerAppServiceImpl` | Other:SingleRequest(getData) |
| `importAppWithDto` | `ApplicationManagerAppService` | `ApplicationImportDto` | `ApplicationManagerAppServiceImpl` | Other:SingleRequest(getData) |
| `importFormApp` | `ApplicationManagerAppService` | — | `ApplicationManagerAppServiceImpl` | Util:RequestUtils(requestAsync) |
| `importFormValidate` | `ApplicationManagerAppService` | — | `ApplicationManagerAppServiceImpl` | Other:SchemaManager(importValidate) |
| `transfer` | `ApplicationManagerAppService` | `String` | `ApplicationManagerAppServiceImpl` | Other:SingleRequest(getData) |
| `transfer` | `ApplicationManagerAppService` | `String` | `ApplicationManagerAppServiceImpl` | Other:SingleRequest(getData) |
| `exportApprovalFrameInfo` | `ApprovalFrameApiTransportAppService` | `ApprovalFrameParamDto` | `ApprovalFrameApiTransportAppServiceImpl` | Service:ApprovalFrameService(getByPram) |
| `copyLayoutAppAsync` | `AsyncAppService` | `ApplicationCopyDto` | `AsyncAppServiceImpl` | Util:Ids(uuidAbsLong) |
| `copyOnlyPageAppAsync` | `AsyncAppService` | `ApplicationCopyDto` | `AsyncAppServiceImpl` | Util:Ids(uuidAbsLong) |
| `transferAsync` | `AsyncAppService` | — | `AsyncAppServiceImpl` | Util:Asserts(notNull) |
| `exportTemplateInfo` | `BpmApiTransportAppService` | `BpmInitDataDto` | `BpmApiTransportAppServiceImpl` | Service:DeployUtil(asyncExecuteWithRedisKey) |
| `importTemplateInfo` | `BpmApiTransportAppService` | `BpmImportDto` | `BpmApiTransportAppServiceImpl` | Other:SingleResponse(ok) |
| `transportIn` | `CdpBiz4UdcAppService` | `String` | `CdpBiz4UdcAppServiceImpl` | Other:SingleRequest(getData) |
| `transportInV2` | `CdpBiz4UdcAppService` | `String` | `CdpBiz4UdcAppServiceImpl` | Other:SingleRequest(getData) |
| `transportOut` | `CdpBiz4UdcAppService` | `TransportOutRequestDto` | `CdpBiz4UdcAppServiceImpl` | Other:SingleRequest(getData) |
| `transportOutV2` | `CdpBiz4UdcAppService` | `TransportOutRequestDto` | `CdpBiz4UdcAppServiceImpl` | Other:SingleRequest(getData) |
| `exportExcel` | `ExcelSmsImportAndExportAppService` | `ExcelSheetEnum` | `ExcelSmsImportAndExportAppServiceImpl` | Service:ExcelSmsExportService(exportExcel) |
| `exportExcelTemplate` | `ExcelSmsImportAndExportAppService` | `ExcelSheetEnum` | `ExcelSmsImportAndExportAppServiceImpl` | Service:ExcelSmsExportService(exportExcelTemplate) |
| `importExcel` | `ExcelSmsImportAndExportAppService` | `ExcelSmsImportDto` | `ExcelSmsImportAndExportAppServiceImpl` | Service:ExcelSmsImportService(importExcel) |
| `copyEntity` | `InnerEntityAppService` | `EntityCopyDto` | `EntityAppServiceImpl` | Other:SingleRequest(getData) |
| `exportEntityTask` | `LinkerMigrationAppService` | `LinkMigrationRequestDto` | `LinkerMigrationAppServiceImpl` | Service:MigrationAppService(exportEntityTask) |
| `importConnectorData` | `LinkerMigrationAppService` | `ConnectorMigrateImportResponseDto` | `LinkerMigrationAppServiceImpl` | Service:ConnectorMigrateHandler(importConnectorDataByLinker) |
| `exportSignByConditions` | `ShortMessageSignAppService` | — | `ShortMessageSignAppServiceImpl` | Service:ShortMessageSignService(exportByConditions) |
| `importExcel` | `UdcEnumItemAppService` | `ExcelImportTransDto` | `UdcEnumItemAppServiceImpl` | Service:UdcEnumItemService(importEntityInitData) |
| `exportPortalDesignInfo` | `PortalSetAppService` | `Long` | `PortalSetAppServiceImpl` | 见 flow 文件 |
| `importPortalDesignInfo` | `PortalSetAppService` | `PortalImportParamDto` | `PortalSetAppServiceImpl` | 见 flow 文件 |
| `transportIn` | `ScalabilityFieldAppService` | — | `ScalabilityFieldAppServiceImpl` | 见 flow 文件 |

## 校验（42）

| 动作方法 | 接口 | 入参 DTO | 实现 | 流转（第一步） |
|---|---|---|---|---|
| `hasAgent` | `AgentCommonAppService` | `AgentParamDto` | `AgentCommonAppServiceImpl` | Service:AgentService(hasAgent) |
| `checkDesignModifiedAfterLastRelease` | `ApplicationAppService` | — | `ApplicationAppServiceImpl` | Service:ApplicationService(checkDesignModifiedAfterLastRelease) |
| `detectionByAppId` | `ApplicationAppService` | `Long` | `ApplicationAppServiceImpl` | Other:SingleRequest(getData) |
| `hasSuperFormAuth` | `ApprovalInvokeAppService` | — | `ApprovalInvokeAppServiceImpl` | Service:ApprovalAuthService(getUserBpmEditSuperEdit) |
| `checkFormPermissionBatch` | `BpmApiFormPermissionAppService` | — | `BpmApiFormPermissionAppServiceImpl` | Service:BpmTemplateService(selectByIds) |
| `checkApplicationPermission` | `BpmApiPermissionAppService` | — | `BpmApiPermissionAppServiceImpl` | Service:BpmHierarchicalControlAppService(hasAppControlledOrgPermission) |
| `check` | `BpmAppService` | `SecurityCheckDto` | `BpmApiAppServiceImpl` | Service:BpmSummaryAppService(authorization) |
| `hasten` | `BpmAppService` | `BpmHastenDto` | `BpmApiAppServiceImpl` | Service:UserAppServiceProxy(getOrgMemberPostCoreDto) |
| `hasDesignTemplateByEntityName` | `BpmTemplateAppService` | `String` | `BpmTemplateAppServiceImpl` | Service:BpmTemplateService(selectTemplateByRootEntityName) |
| `checkFeatureByEnum` | `CapabilityManageAppService` | `CapabilityEnum` | `CapabilityManageAppServiceImpl` | Service:ProviderSelectorService(checkFeatureByEnum) |
| `checkCategoryBatch` | `CategoryCommonAppService` | — | `CategoryCommonAppServiceImpl` | Service:CategoryService(dataInitAndCheckCategoryBatch) |
| `detectionPartEntityForDataset` | `CdpBiz4UdcAppService` | `CdpDetectionEntityDto` | `CdpBiz4UdcAppServiceImpl` | Other:SingleRequest(getData) |
| `detectionPartEntityForStream` | `CdpBiz4UdcAppService` | `CdpDetectionEntityDto` | `CdpBiz4UdcAppServiceImpl` | Other:ListResponse(from) |
| `detectionPartIndicatorForTable` | `CdpBiz4UdcAppService` | `CdpDetectionIndicatorRequestDto` | `CdpBiz4UdcAppServiceImpl` | Other:ListResponse(from) |
| `detectionPartModelForIndicator` | `CdpBiz4UdcAppService` | `CdpDetectionModelRequestDto` | `CdpBiz4UdcAppServiceImpl` | Other:ListResponse(from) |
| `detectionPartModelForReport` | `CdpBiz4UdcAppService` | `CdpDetectionModelRequestDto` | `CdpBiz4UdcAppServiceImpl` | Other:ListResponse(from) |
| `detectionPartModelForStream` | `CdpBiz4UdcAppService` | `CdpDetectionModelRequestDto` | `CdpBiz4UdcAppServiceImpl` | Other:ListResponse(from) |
| `detectionV2` | `CdpBiz4UdcAppService` | `ValidationParamsDto` | `CdpBiz4UdcAppServiceImpl` | Other:SingleRequest(getData) |
| `hasRepeatName` | `CtpLoginPreConfigAppService` | `CtpLoginPreConfigDto` | `CtpLoginPreConfigAppServiceImpl` | Service:CtpLoginPreConfigService(hasRepeatName) |
| `checkExists` | `DataTransferObjectAppService` | — | `DataTransferObjectAppServiceImpl` | Service:DataTransferObjectService(selectByIds) |
| `checkAndEncrypt` | `DocOnlineAppService` | `DocEncryptFileRequestDto` | `DocOnlineAppServiceImpl` | Service:DocOnlineService(checkAndEncrypt) |
| `checkContent` | `DocOnlineAppService` | `DocCheckContentRequestDto` | `DocOnlineAppServiceImpl` | Service:DocOnlineService(checkContent) |
| `checkSensitiveWord` | `IntelligentMissiveAppService` | `SensitiveWordReqDto` | `IntelligentMissiveAppServiceImpl` | Service:IntelligentMissiveService(checkSensitiveWord) |
| `checkUserExecutiveHide` | `OrgInstitutionExecutiveAppService` | — | `OrgInstitutionExecutiveAppServiceImpl` | Service:OrgInstitutionVisitPermissionService(checkUserExecutiveHide) |
| `checkSelectPeopleData` | `OrgWorkFlowAppService` | — | `OrgWorkFlowAppServiceImpl` | Service:OrgHelperService(isLong) |
| `checkRepeatSignName` | `ShortMessageSignAppService` | `RepeatSignRequestDto` | `ShortMessageSignAppServiceImpl` | Service:ShortMessageSignService(checkRepeatSignName) |
| `checkTemplateCode` | `ShortMessageTemplateAppService` | `RepeatTemplateCodeRequestDto` | `ShortMessageTemplateAppServiceImpl` | Service:ShortMessageTemplateService(checkTemplateCode) |
| `verifySeal` | `SignatureAppService` | `VerifySealDto` | `SignatureAppServiceImpl` | Service:SignatureService(verifySeal) |
| `verifySignature` | `SignatureAppService` | `VerifySignatureDto` | `SignatureAppServiceImpl` | Service:SignatureService(verifySignature) |
| `check` | `UdcLateralAuthCheckAppService` | `UdcLateralCheckDto` | `UdcLateralAuthCheckAppServiceImpl` | Service:ApplicationService(selectByAppName) |
| `exist` | `AppDraftAppService` | `String` | `AppDraftAppServiceImpl` | 见 flow 文件 |
| `check` | `AppManageCoreAppService` | `AppCheckRequestDto` | `AppsAppServiceImpl` | 见 flow 文件 |
| `checkOrgAdminPermission` | `CtpUserPermissionCommonAppService` | `CheckOrgAdminPermissionDto` | `UserAppServiceMock` | 见 flow 文件 |
| `checkUserAppPermission` | `CtpUserPermissionCommonAppService` | `CtpUserAppPermissionDto` | `UserAppServiceMock` | 见 flow 文件 |
| `checkUserResource` | `CtpUserPermissionCommonAppService` | — | `UserAppServiceMock` | 见 flow 文件 |
| `checkUserResourceCode` | `CtpUserPermissionCommonAppService` | `CtpUserResourceSearchDto` | `UserAppServiceMock` | 见 flow 文件 |
| `hasAdminRole` | `CtpUserPermissionCommonAppService` | `Long` | `UserAppServiceMock` | 见 flow 文件 |
| `hasRoleByOrgCode` | `CtpUserRoleCommonAppService` | `HasRoleByOrgCodeSearchDto` | `CtpUserRoleCommonAppServiceMock` | 见 flow 文件 |
| `check` | `DataTransferObjectAppService` | — | `DataTransferObjectAppServiceImpl` | 见 flow 文件 |
| `detection` | `PortalSetAppService` | `PortalDetectionRequestDto` | `PortalSetAppServiceImpl` | 见 flow 文件 |
| `checkSealPassword` | `SealCommonAppService` | `SealPasswordCheckDto` | `SealAppService` | 见 flow 文件 |
| `checkPermissionByUser` | `ThirdPermissionAppService` | `ThirdCheckResourcePermissionDto` | `AffairHandoverAppService` | 见 flow 文件 |

## 启用禁用（11）

| 动作方法 | 接口 | 入参 DTO | 实现 | 流转（第一步） |
|---|---|---|---|---|
| `startArchiving` | `ArchivesAppService` | `ArchivingInfoWrapperDto` | `ArchivesAppServiceImpl` | Service:ArchivesService(startArchiving) |
| `pause` | `BpmAppService` | `BpmPauseDto` | `BpmApiAppServiceImpl` | Service:BpmProcessSuperviseService(pause) |
| `startByTemplateId` | `BpmTemplateAppService` | `BpmStartTemplateDto` | `BpmTemplateAppServiceImpl` | Service:BpmTemplateService(startByTemplateId) |
| `startByTemplateIdWithoutAuth` | `BpmTemplateAppService` | `BpmStartTemplateDto` | `BpmTemplateAppServiceImpl` | Service:BpmTemplateService(startByTemplateId) |
| `startCheck` | `BpmTemplateAppService` | `BpmStartTemplateDto` | `BpmTemplateAppServiceImpl` | Service:BpmTemplateService(startCheck) |
| `startByAppName` | `BpmTemplateManageAppService` | `BpmAppInfoDto` | `BpmTemplateManageAppServiceImpl` | Service:BpmTemplateService(startTemplates) |
| `disableMember` | `OrgMemberSyncAppService` | `String` | `OrgMemberSyncAppServiceImpl` | Service:OrgMemberService(selectListByConditions) |
| `disableMemberByThirdIds` | `OrgMemberSyncAppService` | `String` | `OrgMemberSyncAppServiceImpl` | Service:OrgMemberService(selectListByConditions) |
| `disableOrganization` | `OrgUnitSyncAppService` | `OrgDisableUnitDto` | `OrgUnitSyncAppServiceImpl` | Service:OrgUnitService(selectOneByCondition) |
| `start` | `BpmTemplateAppService` | `String` | `BpmTemplateAppServiceImpl` | 见 flow 文件 |
| `enableRule` | `DeductionRtRuleAppService` | `Long` | `DeductionRtRuleAppServiceImpl` | 见 flow 文件 |

## 查询（1218）

查询类 1197 个方法太碎，按接口聚合（完整签名去 `packages/` 查）：

| 接口 | 方法数 | 方法 |
|---|---|---|
| `DesignMetadataQueryAppService` | 49 | `selectServiceMetadata`, `selectEntityMetadata`, `selectEntityMetadataExcludeBoot`, `selectEntityMetadataByFullName`, `selectEntityMetadataByFullNames`, `selectAggMetadata` … 另 43 |
| `OrgCommonAppService` | 40 | `selectMemberInfoById`, `selectMemberDepartmentInfoById`, `selectMemberMultiDimOrgInfo`, `selectMemberInstitutionInfoById`, `selectMemberBySelectPeopleData`, `selectPageMemberBySelectPeopleData` … 另 34 |
| `UdcMetaDataAppService` | 32 | `selectAppMetaData4PageCode`, `selectAvailableUpgradeAppMetadataById`, `selectPageAvailableAppMetaDataByCondition`, `selectPageAvailableAppMultiVersionMetaDataByCondition`, `selectReferMetaDataByEntity`, `selectCustomReferMetaDataByPageId` … 另 26 |
| `BpmTemplateAppService` | 30 | `selectByApplicationName`, `selectById`, `selectTemplateListByCondition`, `selectByTemplateUrlId`, `selectEffectedDiagramListByAppName`, `selectTemplateUserGuidInfo` … 另 24 |
| `OrgWorkFlowAppService` | 29 | `selectMemberPostBySelectPeople`, `selectMemberPostBySelectPeoples`, `selectMemberPostBySelectPeoplesReturnFile`, `selectReturnFileByKey`, `selectListByCondition`, `selectListByMetaCondition` … 另 23 |
| `CapabilityManageAppService` | 28 | `selectPageByConditions`, `selectProvidersByEnum`, `selectEnableProvidersByEnum`, `selectProvidersListByEnum`, `selectOptionalProvider`, `selectActiveXFunctionByEnum` … 另 22 |
| `EnterpriseCreditAppService` | 25 | `pageEnterpriseInfo`, `getBasicBusinessInfo`, `pageEnterpriseInfo`, `getBasicInfo`, `getPartners`, `getCourtNotice` … 另 19 |
| `AffairCommonAppService` | 24 | `selectAffairById`, `selectListByCondition`, `countAffairByConditions`, `selectAffairSimpleById`, `selectAffairSimpleByIds`, `selectAffairSimpleListByCondition` … 另 18 |
| `ApplicationAppService` | 21 | `selectPageByConditions`, `selectAppPageByConditions`, `selectAppPageByConditionsWithVersion`, `selectAppPageByGuid`, `selectTemplateAppPageByConditions`, `selectById` … 另 15 |
| `OcrAppService` | 18 | `getIdCardFrontData`, `getIdCardBackData`, `getBankCardData`, `getBusinessCardData`, `getBusinessLicenseData`, `getTaxInvoiceData` … 另 12 |
| `BpmCaseAppService` | 16 | `selectCaseById`, `selectMainCaseBySubCaseId`, `selectById`, `selectByIds`, `selectBpmCaseByFormRecordId`, `selectByPageCondition` … 另 10 |
| `OrgMetadataCoreAppService` | 16 | `selectOrgMetadataColumnListByCondition`, `selectMetadataColumnList`, `selectPageMetadataColumnList`, `selectOrgByUnitMemberMetadata`, `selectMemberByUnitMetadata`, `selectMemberByUnitMemberMetadata` … 另 10 |
| `OrgUnitBaseAppService` | 16 | `selectById`, `selectByIds`, `selectOrgById`, `selectOrgByIds`, `selectCascadeById`, `selectCascadeByIds` … 另 10 |
| `ApplicationManagerAppService` | 15 | `selectById`, `selectCollaborationRecordsByAppId`, `selectLatestDesignAppByGuid`, `selectLatestDesignAppWithMemberByGuid`, `selectAppNameAndIdMapByAppNames`, `selectDesignAppByGuid` … 另 9 |
| `UdcCtpEnumAppService` | 15 | `selectCategoryByAppGuid`, `selectCategoryAndEnum`, `selectCtpEnum`, `selectCtpEnumByIds`, `selectParentByCode`, `selectListByConditionsNoLevel` … 另 9 |
| `CtpUserPermissionCommonAppService` | 14 | `selectUserResourceCode`, `selectUserResourceCodesMap`, `selectUserResource`, `selectUserResourceProperties`, `selectUserResource`, `selectControlMenus` … 另 8 |
| `EntityAppService` | 14 | `selectById`, `selectByIds`, `selectByName`, `selectPageByCondition`, `selectListByConditions`, `selectListByTerm` … 另 8 |
| `CtpSecretCommonAppService` | 13 | `selectSecretEnable`, `selectSecretLevelEnumItem`, `selectOrgSecretLevelEnumItem`, `selectSecretLevelEnumItemList`, `selectSecretLevelEnumItemByValue`, `selectSecretLevelEnumItemByOrderNo` … 另 7 |
| `OrgMemberBaseAppService` | 13 | `selectById`, `selectByIds`, `selectCascadeById`, `selectCascadeByIds`, `selectListByConditions`, `selectMemberListByCondition` … 另 7 |
| `OrgUnitCoreAppService` | 13 | `selectOrgById`, `selectOrgInfoById`, `selectOrgByIds`, `selectOrgByIdsIgnoreTenantId`, `selectOrgInfoByIds`, `selectOrgListByCondition` … 另 7 |
| `IntelligentMissiveAppService` | 12 | `queryExtractingDetail`, `queryDiffRule`, `queryDocDiffPage`, `queryDocDiffDetail`, `queryDocDiffView`, `queryCardRule` … 另 6 |
| `OrgMemberCoreAppService` | 12 | `selectMemberById`, `selectMemberInfoById`, `selectMemberByIds`, `selectMemberByIdsIgnoreTenantId`, `selectMemberInfoByIds`, `selectMemberListByCondition` … 另 6 |
| `ApprovalInvokeAppService` | 12 | `selectCurrentTenantFormApps`, `selectByGuidAndVersion`, `selectApplicationByGuid`, `selectApplicationByParams`, `selectApplicationByNames`, `selectApplicationDmlFileById` … 另 6 |
| `WorktimeAppService` | 11 | `selectWorktimeByOrgIdAndYear`, `selectByOrgIdAndYear`, `getByParentOrgIdAndYear`, `getWorkTimeByYear`, `getWorkTimeBetweenYear`, `getWorkTimeBetweenDate` … 另 5 |
| `BpmApiFormPermissionAppService` | 11 | `selectByTemplateId`, `selectById`, `selectPermissionIncludeContentById`, `selectByApplicationName`, `selectThirdPermissionByTemplateId`, `selectByIds` … 另 5 |
| `OrgJobBaseAppService` | 10 | `selectById`, `selectByIds`, `selectCascadeById`, `selectCascadeByIds`, `selectListByConditions`, `selectPageByConditions` … 另 4 |
| `OrgLevelBaseAppService` | 10 | `selectById`, `selectByIds`, `selectCascadeById`, `selectCascadeByIds`, `selectListByConditions`, `selectPageByConditions` … 另 4 |
| `OrgMemberRoleBaseAppService` | 10 | `selectById`, `selectByIds`, `selectCascadeById`, `selectCascadeByIds`, `selectListByConditions`, `selectListByCondition` … 另 4 |
| `OrgRoleBaseAppService` | 10 | `selectById`, `selectByIds`, `selectCascadeById`, `selectCascadeByIds`, `selectListByConditions`, `selectListByCondition` … 另 4 |
| `OrgPostBaseAppService` | 10 | `selectById`, `selectByIds`, `selectCascadeById`, `selectCascadeByIds`, `selectListByConditions`, `selectPageByConditions` … 另 4 |
| `DataTransferObjectAppService` | 10 | `selectById`, `selectDtoWithAttrsById`, `selectPageByConditions`, `selectListByConditions`, `selectDtoWithAttrsAndRefDtos`, `selectListBySourceId` … 另 4 |
| `LinkerAppService` | 9 | `selectPageByCondition`, `selectAll`, `selectDetailsByInfoId`, `selectLinkerDetailParameterDisplay`, `selectEventDetailsByInfoId`, `selectEventDetailById` … 另 3 |
| `OrgIntegrationAppService` | 9 | `queryCardInfo`, `queryServiceTypeInfo`, `queryJsApiAddressByCode`, `queryCardRunInfo`, `queryCardShowInfo`, `queryCardShowIsCustomAvatar` … 另 3 |
| `OrgPortalAppService` | 9 | `selectSwitchInstitution`, `selectSwitchInstitutions`, `selectSwitchInstitutionByMemberId`, `selectLoginUserInfo`, `selectCurrentLoginUserInfo`, `selectMainMemberPostByMemberId` … 另 3 |
| `DocOnlineAppService` | 8 | `getOfficeViewUrl`, `getCompositeViewUrl`, `getLatestPicViewUrl`, `getOfficeEditUrl`, `getLatestDocFileInfoByStorageKey`, `selectDocFileVersionPage` … 另 2 |
| `CtpApplicationCommonAppService` | 8 | `selectCategoryApplications`, `selectCategorySetting`, `selectApplicationsByCategoryAndClientScope`, `selectAdminAppIdsByUserIdAndOrgId`, `selectEnabledApplications`, `selectUserMenuAndPortal` … 另 2 |
| `CtpUserCoreAppService` | 8 | `selectById`, `selectByIds`, `selectSimpleByIds`, `selectOneByCondition`, `selectListByConditions`, `selectPageByConditions` … 另 2 |
| `CtpOrgAdminOrgAppService` | 8 | `selectByOrgId`, `selectByOrgIds`, `selectByUserId`, `selectPageByConditions`, `selectListByConditions`, `selectManageScopeByOrgAndUser` … 另 2 |
| `OrgBusinessBaseAppService` | 8 | `selectById`, `selectByIds`, `selectCascadeById`, `selectCascadeByIds`, `selectListByConditions`, `selectPageByConditions` … 另 2 |
| `OrgMemberPostBaseAppService` | 8 | `selectById`, `selectByIds`, `selectCascadeById`, `selectCascadeByIds`, `selectListByConditions`, `selectPageByConditions` … 另 2 |
| `OrgUnitVerticalBaseAppService` | 8 | `selectById`, `selectByIds`, `selectCascadeById`, `selectCascadeByIds`, `selectListByConditions`, `selectPageByConditions` … 另 2 |
| `AttributeSetAppService` | 8 | `selectById`, `selectByIds`, `selectByName`, `selectListByConditions`, `selectListByAppId`, `selectListByNames` … 另 2 |
| `AttributeAppService` | 8 | `selectById`, `selectPageByCondition`, `selectListByCondition`, `selectListByTerm`, `selectAllAttributeByEntityId`, `selectEntityAttributeList` … 另 2 |
| `CategoryCommonAppService` | 7 | `selectById`, `selectListByConditions`, `selectTreeByIds`, `selectChildrenById`, `selectChildrenByCode`, `getCategoryDataInitResult` … 另 1 |
| `BaseConfigAppService` | 7 | `selectDatabaseById`, `selectDatabaseByIds`, `selectPageDatabaseByCondition`, `selectAllDatabaseType`, `selectAllTableInfo`, `selectAllTableNameById` … 另 1 |
| `AffairOpenAppService` | 7 | `selectPageByCondition`, `selectByConditionIgnoreTenant`, `selectActivityUnprocessedMember`, `selectSpecifyActivityUnprocessedMember`, `selectNodePermissionPageByCondition`, `selectCategoryByCondition` … 另 1 |
| `CtpAuthCoreAppService` | 7 | `getLoginUserInfo`, `getPcUserInfo`, `selectTenantList`, `getAccessToken`, `selectTenantListByUserId`, `selectTicketByToken` … 另 1 |
| `CtpRoleCoreAppService` | 7 | `selectById`, `selectByCode`, `selectByIds`, `selectListByConditions`, `selectPageByConditions`, `selectCascadeById` … 另 1 |
| `OrgMemberSyncAppService` | 7 | `selectByCodes`, `selectByThirdIds`, `selectByCondition`, `selectNaturalMemberByPhoneNumber`, `selectNaturalMemberByCodes`, `selectNaturalMemberInfoPageListByCondition` … 另 1 |
| `DataTypeAppService` | 7 | `getAll`, `selectBaseDataTypes`, `selectParameterDataTypes`, `selectDataTypeByName`, `selectDataTypeByAppId`, `selectDataTypeByParams` … 另 1 |
| `AgentCoreAppService` | 6 | `selectListByCondition`, `selectById`, `selectByIds`, `selectPageByCondition`, `selectBizAgentPageByCondition`, `getAgentProperties` |
| `BpmApiNodePermissionAppService` | 6 | `selectNodePermissionById`, `selectNodePermissionListByIds`, `queryPermissionList`, `selectNodePermissionDetailListByIds`, `selectNodePermissionListByConditions`, `getMaxOrderNumber` |
| `ShortMessageTemplateAppService` | 6 | `selectTemplateById`, `selectTemplateByCode`, `selectPageStoreLibrary`, `selectPageByConditions`, `selectTemplateTypeListByConditions`, `getLanguage` |
| `MappingDetailAppService` | 6 | `queryUserMappingDetail`, `queryOrgMappingDetail`, `getOrgInnerIdByOuterId`, `getOrgOuterIdByInnerId`, `getUserInnerIdByOuterId`, `getUserOuterIdByInnerId` |
| `CtpApplicationAuthCoreAppService` | 6 | `selectApplicationAuthByAppId`, `selectAuthAppIdsByOrgId`, `selectAuthAppIds`, `selectWithOutAuthAllAppIdsByOrgId`, `selectApplicationByAuthedOrg`, `selectPageApplicationByAuthedOrg` |
| `CtpUserBindMappingAppService` | 6 | `selectOneByCondition`, `selectListByConditions`, `pageUserMappingByUserIds`, `listUserMappingByUserIds`, `listUserMappingForPending`, `selectPageByConditions` |
| `CtpAuthorizationRuleOrgAppService` | 6 | `selectPageByConditions`, `selectAuthorizationObject`, `selectAuthorizationEntity`, `selectAuthorizationFuncList`, `selectAuthorizationFuncListByRole`, `selectDuplicateRolesRule` |
| `OrgJobCoreAppService` | 6 | `selectJobById`, `selectJobByIds`, `selectJobListByCondition`, `selectJobPageListByCondition`, `selectJobListPropertiesByJobIds`, `selectJobPageListPropertiesByCondition` |
| `OrgLevelCoreAppService` | 6 | `selectLevelById`, `selectLevelByIds`, `selectLevelListByCondition`, `selectLevelPageListByCondition`, `selectLevelListPropertiesByLevelIds`, `selectLevelPageListPropertiesByCondition` |
| `OrgPostCoreAppService` | 6 | `selectPostById`, `selectPostByIds`, `selectPostListByCondition`, `selectPostPageListByCondition`, `selectPostListPropertiesByPostIds`, `selectPostPageListPropertiesByCondition` |
| `UdcCtpEnumProxyAppService` | 6 | `selectOneByIdAndApp`, `selectByEnumCodeAndAppGuid`, `selectByEnumCodesAndAppGuid`, `selectCascadeTreeByEnumCode`, `selectByEnumItemByDependentApp`, `selectByEnumItemByDependentApp` |
| `AgentCommonAppService` | 5 | `selectByAgentUserId`, `selectByUserIdAndTemplate`, `selectById`, `selectListByConditions`, `selectEffectiveAgentList` |
| `BpmApiParamAppService` | 5 | `loadParamSchema`, `loadParamTypes`, `loadParamSchemaByOrigin`, `selectParameterUsedByTemplateId`, `selectUsedParameterPathName` |
| `IndexAppService` | 5 | `search`, `searchHistory`, `selectById`, `selectByEntityId`, `selectMatchesAttributeByEntityId` |
| `InvoiceAppService` | 5 | `getOcrInvoiceData`, `getOcrAsyncResult`, `getOcrInvoiceSingle`, `queryOcrPage`, `queryCheckPage` |
| `MobilePluginConfigAppService` | 5 | `selectOneByConditions`, `selectById`, `getWorkWxAccessMode`, `getPlatformTypeList`, `selectOneByConditionsIgnoreTenant` |
| `SignatureAppService` | 5 | `getSignatureViewUrl`, `getSealInfo`, `selectPageByConditions`, `getTemplateContents`, `querySsoUrl` |
| `VideoMeetingAppService` | 5 | `getMeetingDetail`, `selectVideoMeetingRoom`, `selectMemberMeetingRoom`, `getEndedMeetingDetail`, `getMeetingRecord` |
| `OrgUnitSyncAppService` | 5 | `selectByCodes`, `selectByThirdIds`, `selectChildrenByCondition`, `selectPageChildrenByCondition`, `selectPageByConditions` |
| `OrgMemberPostCoreAppService` | 5 | `selectMemberPostListByCondition`, `selectMemberPostListByMemberIds`, `selectMemberPostPageListByCondition`, `selectMemberPostListPropertiesByMemberIds`, `selectMemberPostPageListPropertiesByCondition` |
| `OrgSystemTeamCoreAppService` | 5 | `selectTeamMemberByTeamId`, `selectTeamMemberByTeamIds`, `selectTeamById`, `selectTeamByIds`, `selectTeamByCondition` |
| `OrgUnitTeamCoreAppService` | 5 | `selectUnitTeamById`, `selectUnitTeamByIds`, `selectUnitTeamListByCondition`, `selectUnitTeamPageListByCondition`, `selectSortId` |
| `EventAppService` | 5 | `selectPageByConditions`, `selectListByConditions`, `selectById`, `selectBusinessEvent`, `selectEvents` |
| `UdcEnumItemAppService` | 5 | `selectPageByConditions`, `selectListByConditions`, `selectById`, `selectByEnumId`, `selectListByTerm` |
| `UdcSandBoxAppService` | 5 | `search`, `searchDetails`, `searchDetails4FlowLog`, `searchPageLog`, `searchPageLogNonMetadata` |
| `I18nLocaleAppService` | 4 | `getEnableLocalesMap`, `getTenantDefaultLocale`, `getSystemDataI18nLocaleList`, `getTenantDataI18nLocaleList` |
| `BpmNodeAppService` | 4 | `selectPageByConditions`, `selectByTemplateAndActivityType`, `selectRunningProcessPreNode`, `selectNodePolicy` |
| `BpmProcessLogAppService` | 4 | `selectLogList`, `selectOriginalI18nLogList`, `selectLogOriginalListByCaseIds`, `selectPageByConditions` |
| `OfdAppService` | 4 | `getOfdViewUrl`, `getSealInfo`, `getSealList`, `getOfdMetaData` |
| `PhysicalSealAppService` | 4 | `queryApplyRecord`, `querySeals`, `getImageByApplyId`, `getImage` |
| `ShortMessageSignAppService` | 4 | `selectRecentTimeSign`, `selectValidSign`, `selectPageSignByConditions`, `selectSignById` |
| `ApplicationAffairAppService` | 4 | `queryExternalIdByAffair`, `listExternalIdsByAffairIds`, `queryAffairByExternalId`, `queryAffairListByExternalIdList` |
| `MiddleTableAppService` | 4 | `queryUnit`, `queryLevel`, `queryPost`, `queryMember` |
| `MiddleTableOperationAppService` | 4 | `queryUnit`, `queryLevel`, `queryPost`, `queryMember` |
| `CtpManagerTenantAppService` | 4 | `selectByUseTenantId`, `selectByUseTenantCode`, `selectStatusByUseTenantId`, `selectInitStatus` |
| `CtpUserCommonAppService` | 4 | `getUserInfo`, `selectUserByLoginName`, `getLoginPageSetParameter`, `getRecentUserId` |
| `CtpUserRoleCommonAppService` | 4 | `selectUserByRoleCode`, `selectPageUserByRoleCode`, `selectUserByRoleCodeSearch`, `selectUserIdByRoleCode` |
| `CtpThirdPlatformConfigCoreAppService` | 4 | `selectById`, `selectOneByConditions`, `selectListByConditions`, `selectPageByConditions` |
| `CtpUserRoleCoreAppService` | 4 | `selectListByConditions`, `selectEntityRoleListByConditions`, `selectPageByConditions`, `selectCtpEntityRolePageByConditions` |
| `OrgMemberRoleCoreAppService` | 4 | `selectById`, `selectByIds`, `selectListByConditions`, `selectPageByConditions` |
| `OrgRoleCoreAppService` | 4 | `selectById`, `selectByIds`, `selectListByConditions`, `selectPageByConditions` |
| `ScalabilityOptionAppService` | 4 | `selectById`, `selectByAppId`, `selectByAppIdWithDetail`, `selectAllOptionName` |
| `UdcEnumAppService` | 4 | `selectPageByConditions`, `selectListByConditions`, `selectById`, `selectListByTerm` |
| `UdcEnumCategoryAppService` | 4 | `selectPageByConditions`, `selectListByConditions`, `selectById`, `selectCategoryAndEnum` |
| `UdcSerialSchemeAppService` | 4 | `selectSerialScheme`, `selectSerialSchemeById`, `selectSerialRange`, `selectDepAppSerialScheme` |
| `ScalabilityFieldAppService` | 4 | `selectMetadataExtEntityTree`, `listExtFileds`, `selectAvailableDatatype`, `selectAttribute` |
| `DataFlowMappingAppService` | 4 | `selectOriginalMappingList`, `selectById`, `selectMappingInitData`, `selectDetailByCondition` |
| `AttributeSnapshotAppService` | 4 | `selectByDataId`, `selectByDataIds`, `selectByMasterDataId`, `selectByMasterDataIds` |
| `CtpMessageClientAppService` | 4 | `selectSourceAndClassificationList`, `selectOtherList`, `selectMessageListByCode`, `getReadStatus` |
| `AssociateCommonAppService` | 3 | `selectEntityConfigByConditions`, `selectAssociateCompleteByAppName`, `selectAssociateCompleteByControlCodes` |
| `MyAttentionCommonAppService` | 3 | `getAttentionByObjectIds`, `getAttentionUserIdsByObjectIds`, `selectPageByConditions` |
| `SystemConfigCommonAppService` | 3 | `getI18nConfig`, `getSystemConfig`, `getLocaleParameterByUserIds` |
| `CtpQrCodeRuleUdcAppService` | 3 | `getRuleListByAppIdAndFullNames`, `getRuleListByAppIdAndFieldCodes`, `getRuleListByAppId` |
| `BpmTemplateManageAppService` | 3 | `selectFormalAuthTemplateList`, `selectFormalAuthTemplateListByQueryDto`, `selectGrayAuthTemplateList` |
| `BpmApiTransportAppService` | 3 | `getApplicationInitData`, `getApplicationInitDataAsync`, `selectUsedConnectorByAppName` |
| `EmailPrivateAppService` | 3 | `getCompanySystemEmail`, `selectEmailTemplate`, `getEmailLimit` |
| `LocationAppService` | 3 | `getLocation`, `getDistance`, `getJsApiInfo` |
| `PayAppService` | 3 | `queryTransactionByOutTradeNo`, `queryRefund`, `getCert` |
| `VoiceAppService` | 3 | `queryVoiceFileResult`, `queryConvertWordsResult`, `queryIntelligentDigestResult` |
| `CapabilityAccessLogDbAppService` | 3 | `selectById`, `selectPageByConditions`, `countByConditions` |
| `OpenCapabilityAppService` | 3 | `queryUseCount`, `getTicket`, `getAppUrl` |
| `CtpMessageManageAppService` | 3 | `selectBySetType`, `selectListByUserId`, `getMessageNumber` |
| `CtpApplicationCoreAppService` | 3 | `selectListByConditions`, `selectPageByConditions`, `selectAppStatusListIgnoreTenantId` |
| `CtpUserDefaultIdentityCommonAppService` | 3 | `selectDefaultSwitchAdminOrg`, `selectUDefaultseIdentityInfo`, `selectFrontUserDefaultTenant` |
| `CtpResourceCoreAppService` | 3 | `selectByCode`, `selectListByConditions`, `selectPageByConditions` |
| `OrgJobSyncAppService` | 3 | `selectByCodes`, `selectPageByConditions`, `selectByThirds` |
| `OrgLevelSyncAppService` | 3 | `selectByCodes`, `selectPageByConditions`, `selectByThirdIds` |
| `OrgPostSyncAppService` | 3 | `selectByCodes`, `selectPageByConditions`, `selectByThirdIds` |
| `PortalShortcutAppService` | 3 | `selectById`, `selectListByConditions`, `selectByIds` |
| `DtoAttributeAppService` | 3 | `selectById`, `selectPageByConditions`, `selectListByConditions` |
| `EventWithDataAppService` | 3 | `selectWithEventData`, `selectListWithDataByConditions`, `selectListWithDataByTerm` |
| `ParameterAppService` | 3 | `selectById`, `selectByIds`, `selectPageByCondition` |
| `ReferConfigAppService` | 3 | `selectById`, `selectPageByCondition`, `selectListByCondition` |
| `QueryAppService` | 3 | `selectByIds`, `selectById`, `selectByAppIdAndDeployType` |
| `AppCollaborationAppService` | 3 | `selectCollaborativeAppNames`, `selectCollaborativeGuid`, `selectAppMemberInfoListByAppIdList` |
| `PersonalPlanAppService` | 3 | `selectByCondition`, `selectListByCondition`, `selectPageByCondition` |
| `UdcSerialConfigAppService` | 3 | `selectListByConditions`, `selectEntityList`, `selectEntityBySerialId` |
| `ApprovalAppService` | 2 | `getApprovalPageSchemaAndPermissionByAffairId`, `getFormDataByGraphql` |
| `ImageCategoryAppService` | 2 | `selectImageCategory`, `selectCountByCategoryId` |
| `ImageStoreAppService` | 2 | `selectImageStore`, `selectStoreAndCategory` |
| `IntegralLedgerOprateAppService` | 2 | `selectPageByConditions`, `selectRankById` |
| `MgnAggDataInitAppService` | 2 | `selectListByConditions`, `selectListByMap` |
| `SealCommonAppService` | 2 | `selectUsableList`, `selectListByCondition` |
| `ThemeAppService` | 2 | `selectById`, `selectPagePropertiesByConditions` |
| `VideoMeetingRoomCommonAppService` | 2 | `selectById`, `selectAuthedVideoMeetingRoomList` |
| `InitMonitorAppService` | 2 | `selectAppStarterInitVersions`, `selectAppInitSingleDetails` |
| `LoadJarResourceAppService` | 2 | `getJsonMetadataData`, `getRuntimeJsonData` |
| `BpmActivityAppService` | 2 | `selectAllByCaseId`, `selectBpmCaseActivityByCaseId` |
| `BpmAppService` | 2 | `selectFullCaseInfo`, `counterSignNode` |
| `BpmCaseLogAppService` | 2 | `selectByCaseId`, `selectByDto` |
| `BpmNodePermissionOperationAppService` | 2 | `getNodePermissionOperation`, `selectOperationSimpleByPermissionIds` |
| `BpmProcessTrackAppService` | 2 | `selectProcessTrackList`, `countAttentionForBadge` |
| `BpmWorkItemAppService` | 2 | `selectById`, `selectByCaseId` |
| `BpmApiSimulationAppService` | 2 | `selectProcessPredictionResult`, `selectSimulationLinkByGuid` |
| `ReportOpenApiAppService` | 2 | `getReportDetail`, `getReportResult` |
| `CdpBiz4UdcAppService` | 2 | `getReportList`, `getCdpDataIdList` |
| `DatasetOpenApiAppService` | 2 | `getDatasetModel`, `getDatasetResult` |
| `CdpEtlSourceAppService` | 2 | `getSource`, `getDatasetPublishMetadata` |
| `IndicatorOpenApiAppService` | 2 | `getIndicatorModel`, `getIndicatorResult` |
| `StreamOpenApiAppService` | 2 | `getStreamModel`, `getStreamResult` |
| `ArchivesAppService` | 2 | `queryArchiveSystemCategory`, `selectAttributesByTypeIds` |
| `SealAppService` | 2 | `listSeal`, `getSealDetails` |
| `EmailAppService` | 2 | `findCipEmailUserAccount`, `selectPageEmailTemplate` |
| `MobilePluginAppletAppService` | 2 | `getAuditStatus`, `queryBindAuth` |
| `WeatherAppService` | 2 | `getLocation`, `getWeather` |
| `CapabilityEnumAppService` | 2 | `selectList`, `selectItemList` |
| `ShortMessageProviderTemplateAppService` | 2 | `selectTemplateContentById`, `selectTemplateContentByConditions` |
| `ApplicationPluginStatusAppService` | 2 | `selectStatusByPlugIds`, `selectStatusByLinkerIds` |
| `PluginStatusAppService` | 2 | `selectStatusByPlugIds`, `selectStatusByLinkerIds` |
| `AffairCategoryAppService` | 2 | `getAllAppAndSubAppInfoRegisterAffair`, `searchAffairCategory` |
| `AffairSuperviseAppService` | 2 | `selectPageByFixedTemplate`, `selectTemplateAffairPageData` |
| `CtpCategoryCoreAppService` | 2 | `selectListByConditions`, `selectQuickListByConditions` |
| `CtpMenuCommonAppService` | 2 | `selectChildrenByCode`, `selectListByConditions` |
| `CtpLoginPreConfigAppService` | 2 | `selectByOrgId`, `selectByUri` |
| `CtpResourcePermissionCoreAppService` | 2 | `selectByResourceCode`, `selectListByConditions` |
| `CtpUserResourceCoreAppService` | 2 | `selectListByConditions`, `selectPageListByConditions` |
| `CtpUserRoleAppService` | 2 | `selectCascadeById`, `selectCascadeByIds` |
| `CtpPermissionApprovalOrgAppService` | 2 | `selectById`, `selectPageByConditions` |
| `AppManageCoreAppService` | 2 | `getLatestDownloadUrl`, `getLatestApp` |
| `OrgAppCommonAppService` | 2 | `selectAccessViewMember`, `selectAccessViewOrg` |
| `OrgMobileAppService` | 2 | `selectPagePhoneNumber`, `selectOfflineStorageKey` |
| `OrgTeamSyncAppService` | 2 | `selectByCode`, `selectPageByConditions` |
| `OrgSelectPeopleForInstAppService` | 2 | `selectFirstChildrenUnits`, `searchInstitution` |
| `OrgSelectPeopleForMemberAppService` | 2 | `searchMemberByGroup`, `selectMembersByOrg` |
| `PortalSetAppService` | 2 | `selectRootOrgPortalSet`, `selectByIds` |
| `PortalSpaceAppService` | 2 | `selectDesignSpaceList`, `selectAllSectionsByUserIds` |
| `EntityGroupAppService` | 2 | `selectById`, `selectByAppId` |
| `EntityPresetAppService` | 2 | `selectPresetByEntityId`, `selectListByAppId` |
| `FeatureAppService` | 2 | `list`, `listSystemAttributeNames` |
| `InnerEntityAppService` | 2 | `selectEntitiesByEntityId4Tree`, `selectMasterEntityCount` |
| `PreSetAttributeCapacityAppService` | 2 | `getAllPreSetAttributeCapacity`, `getPreSetAttributeCapacity` |
| `ScalabilityAppService` | 2 | `selectById`, `selectByOptionId` |
| `StereotypeAllAppService` | 2 | `getAll`, `get` |
| `MicroFlowInfoAppService` | 2 | `findCallConnectorAppService`, `findCallIntegrationAppService` |
| `PluginPageInfoAppService` | 2 | `getResourceByCondition`, `getResource4UserCenter` |
| `CustomPlanAppService` | 2 | `selectBySourceIds`, `selectByComplexCondition` |
| `DataFlowMapAppService` | 2 | `selectByCondition`, `selectById` |
| `DeductionRtMapAppService` | 2 | `selectSimpleDeductionMap`, `selectById` |
| `DeductionRtRuleAppService` | 2 | `selectRtRuleVersion`, `selectById` |
| `FormAppService` | 2 | `loadForm`, `getHostAppDepends` |
| `CtpMessageAppService` | 2 | `selectPageByCondition`, `getPushMessage` |
| `CtpMessageTypeAppService` | 2 | `selectById`, `selectPageByCondition` |
| `ImageAppService` | 1 | `selectImage` |
| `QrCodeCommonAppService` | 1 | `selectByJson` |
| `StyleFileAppService` | 1 | `getCurrentTenantPortalFile` |
| `WaterMarkCommonAppService` | 1 | `getWaterMarkConfig` |
| `I18nResourceAppService` | 1 | `getTenantResourceDtoMap` |
| `BpmApiPermissionAppService` | 1 | `getCurrentOrgHierarchicalAppGuid` |
| `BpmApiProcessAppService` | 1 | `selectDiagramDetailByTemplateCodeAndVersion` |
| `BpmApplicationOperateLogAppService` | 1 | `selectNewestLogInfo` |
| `BpmCoMiAppService` | 1 | `getDetailInfo` |
| `BpmDetailAppService` | 1 | `selectDetail` |
| `BpmNormalAppMultiVersionAppService` | 1 | `selectCurrentHighestVersionBatch` |
| `BpmOpinionAppService` | 1 | `selectOpinionGroupByActivityNodeWithObjectId` |
| `BpmSuperviseAppService` | 1 | `search` |
| `BpmApiSplitImportAppService` | 1 | `selectTemplateByAppName` |
| `DocGeneralizeAppService` | 1 | `getAuthorityInfoProxy` |
| `CompanyAccountServiceAppService` | 1 | `queryCompanyAccountInfo` |
| `FaceIdAppService` | 1 | `getAccessToken` |
| `GisAppService` | 1 | `getToken` |
| `MerchantAppService` | 1 | `selectPageMerchantByConditions` |
| `SearchAppService` | 1 | `querySearchUrl` |
| `TranslationAppService` | 1 | `getLanguages` |
| `AiAppService` | 1 | `queryUsageAmount` |
| `TokenAppService` | 1 | `selectTokenExpireTime` |
| `ApplicationMobileAppService` | 1 | `getAppUrl` |
| `LinkerEnumAppService` | 1 | `selectItemList` |
| `LinkerMigrationAppService` | 1 | `listConnectorData` |
| `CipPlugCapabilityAppService` | 1 | `getAndCheckCapability` |
| `PluginAffairAppService` | 1 | `getExternalIdByAffairId` |
| `AffairDataScopeAppService` | 1 | `getDataScope` |
| `AffairNodePermissionAppService` | 1 | `selectPageByCondition` |
| `AffairUdcAppService` | 1 | `selectSpecifiedFieldValues` |
| `CtpCapabilityCoreAppService` | 1 | `selectListByConditions` |
| `CtpPersonalPlanCoreAppService` | 1 | `selectPageByConditions` |
| `CtpUserBpmAppService` | 1 | `selectUserResourceIgnoreTenant` |
| `CtpDeviceBindCommonAppService` | 1 | `selectByConditions` |
| `CtpResourceCommonAppService` | 1 | `selectDesignResources` |
| `CtpLoginLogCoreAppService` | 1 | `selectPageByConditions` |
| `CtpResourceTypeCoreAppService` | 1 | `selectListByConditions` |
| `CtpRoleResourceCoreAppService` | 1 | `selectResourceActionByRoleCodes` |
| `CtpOrgSelectPeopleAppService` | 1 | `selectPageByConditions` |
| `CtpSecretApprovalOrgAppService` | 1 | `selectPendingInfo` |
| `CtpAuthorizationUdcAppService` | 1 | `selectAppFirstLinks` |
| `OrgAffairAppService` | 1 | `selectByIdOrCode` |
| `OrgEdocAppService` | 1 | `selectSortByIds` |
| `OrgPlatformAppService` | 1 | `selectWatermarkInfoByMemberId` |
| `OrgBusinessCoreAppService` | 1 | `selectBusinessListByCondition` |
| `OrgUnitVerticalCoreAppService` | 1 | `selectUnitVerticalListByCondition` |
| `OrgParameterCoreAppService` | 1 | `selectValueByParamsKey` |
| `OrgSelectPeopleForDeptAppService` | 1 | `selectOrgPath` |
| `TenantManageAppService` | 1 | `selectEnableUnitNumIgnoreTenant` |
| `PortalPortletAppService` | 1 | `getPortalPortlet` |
| `AttributeGroupAppService` | 1 | `selectListByEntityId` |
| `EntityOpenApiAppService` | 1 | `selectOpenApiData` |
| `ReferConfigGroupAppService` | 1 | `selectListByConditions` |
| `StereotypeAppService` | 1 | `list` |
| `AsyncAppService` | 1 | `getRequestStatus` |
| `PageMetadataQuery4SfAppService` | 1 | `selectAppMetaDataByAppName` |
| `PageProcessEventAppService` | 1 | `selectListByCondition` |
| `ConsistenceDetectionAppService` | 1 | `selectDetectionListByAppId` |
| `UdcBpmAppService` | 1 | `selectDefaultLayoutAppName` |
| `UdcFunctionAppService` | 1 | `findMenuDefaultPage` |
| `UdcPortalSpaceAppService` | 1 | `selectDesignSpaceList` |
| `UdcRuleAppService` | 1 | `selectRuleByEntity` |
| `AppDraftAppService` | 1 | `select` |
| `CtpMessageUserSubscribeAppService` | 1 | `selectListByUserId` |

## 怎么用

```
① 我要做某件事 → 在本文件找对应动作分组
② 找到入口方法 → 记下接口名和入参 DTO
③ DTO 有什么字段 → dto-fields/<域>.md
④ 背后发生什么 → service-flow-20261103/<构件>.md 搜那个实现类
⑤ 完整签名 → packages/<构件>.md 或 domains/<域>.md
```

## 缺口

- 254 个 AppService 无实现类 → 流转 UNVERIFIED（实现在平台服务端）
- 「其他」类动作（392 个）多为 `batch*` / `dynamic*` / `process*` 前缀，未归类
- 流转只给第一步调用，完整链路见 flow 文件
