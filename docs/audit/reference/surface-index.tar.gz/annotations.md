# 平台注解速查（109 个 @interface）

> 自动生成，勿手改。`tools/core/platform/scan_annotation_meta.py` 重跑即可。
> 来源：`javap -v` 的 RuntimeVisibleAnnotations 块（解常量池）。
> 共 **109 个**注解（另有 0 个未能解析）。

## 怎么用

- **@Target** 决定能贴哪：`TYPE`=类/接口、`METHOD`=方法、`FIELD`=字段、
  `PARAMETER`=参数、`ANNOTATION_TYPE`=元注解、`CONSTRUCTOR`=构造器
- **@Retention** 决定何时有效：`RUNTIME`=运行期可反射读到（扩展点都是这个）、
  `CLASS`=编译进字节码但反射读不到、`SOURCE`=编译完就丢（只给编译器/APT 用）
- **元注解里的 @Service / @Component** = 贴了这个注解就等于贴了 Spring 组件注解，
  会自动被扫描注册——这是「写了代码怎么被平台发现」的一条暗线。

## @Retention(RUNTIME) —— 108 个

| 注解 | 元素数 | @Target | 元注解（Spring 等） | 构件 |
|---|---|---|---|---|
| `EntityAttribute` | 19 | FIELD | — | `boot-core` |
| `ExcelContentStyle` | 17 | FIELD, TYPE | — | `boot-core` |
| `ExcelHeadStyle` | 17 | TYPE | — | `boot-core` |
| `DtoAttribute` | 13 | FIELD, METHOD | — | `boot-core` |
| `CtpSchedule` | 13 | TYPE | — | `boot-starter-schedule` |
| `EntityInfo` | 12 | TYPE | — | `boot-core` |
| `AppServiceOperation` | 9 | METHOD | — | `boot-core` |
| `BootApp` | 8 | TYPE | SpringBootApplication, EntityScan, ComponentScan, EnableScheduling, EnableAsync, EnableAspectJAutoProxy, EnableTransactionManagement, Import | `boot-core` |
| `Function` | 7 | METHOD | — | `boot-formula-engine` |
| `ExcelContentFontStyle` | 7 | FIELD, TYPE | — | `boot-core` |
| `ExcelHeadFontStyle` | 7 | TYPE | — | `boot-core` |
| `OperationLog` | 7 | METHOD | — | `udc-plugin-api` |
| `EnumAttribute` | 6 | FIELD | — | `boot-core` |
| `EnumInfo` | 6 | TYPE | — | `boot-core` |
| `MessageInfo` | 6 | TYPE | — | `boot-core` |
| `RestApiOperation` | 6 | METHOD | — | `boot-core` |
| `DtoInfo` | 5 | TYPE | — | `boot-core` |
| `OpenApi` | 5 | — | — | `boot-core` |
| `Safety` | 5 | — | — | `boot-core` |
| `IsolatorExecutor` | 5 | METHOD | — | `boot-starter-threadpool` |
| `DateValidation` | 5 | METHOD, FIELD, ANNOTATION_TYPE, CONSTRUCTOR, PARAMETER, TYPE_USE | Repeatable, Constraint | `udc-biz` |
| `TimeValidation` | 5 | METHOD, FIELD, ANNOTATION_TYPE, CONSTRUCTOR, PARAMETER, TYPE_USE | Repeatable, Constraint | `udc-biz` |
| `LogDefault` | 5 | — | — | `udc-plugin-api` |
| `AppService` | 4 | TYPE | Service, Primary | `boot-core` |
| `EntityIndex` | 4 | — | — | `boot-core` |
| `Maskable` | 4 | FIELD, METHOD | — | `boot-core` |
| `RestApi` | 4 | TYPE | — | `boot-core` |
| `ReturnValue` | 4 | METHOD | — | `boot-formula-engine` |
| `AttrTypeMatch` | 4 | METHOD, FIELD, ANNOTATION_TYPE, PARAMETER | Repeatable, Constraint | `udc-biz` |
| `DelDetection` | 4 | METHOD | — | `udc-biz` |
| `UpdateDetection` | 4 | METHOD | — | `udc-biz` |
| `ParameterInfo` | 3 | PARAMETER | — | `boot-core` |
| `Parameter` | 3 | — | — | `boot-formula-engine` |
| `PriorityCache` | 3 | TYPE, METHOD | — | `udc-starter-lowcode` |
| `UseUdcAppLog` | 3 | TYPE, METHOD | — | `udc-starter-lowcode` |
| `CipDaoCondition` | 3 | FIELD | — | `cip-capability-common` |
| `TypeMapping` | 3 | TYPE | Component, Order | `udc-common` |
| `UpgradeMethod` | 3 | METHOD | — | `udc-plugin-api` |
| `AttributeExist` | 3 | METHOD, FIELD, ANNOTATION_TYPE, PARAMETER | Repeatable, Constraint | `udc-biz` |
| `EntityExist` | 3 | METHOD, FIELD, ANNOTATION_TYPE, PARAMETER | Repeatable, Constraint | `udc-biz` |
| `LogDefaultUpdate` | 3 | — | — | `udc-plugin-api` |
| `Custom` | 2 | — | — | `boot-core` |
| `CustomAttribute` | 2 | — | — | `boot-core` |
| `HasRole` | 2 | METHOD, TYPE | — | `boot-core` |
| `MigrationStorageField` | 2 | FIELD | — | `boot-core` |
| `MultiRequestBody` | 2 | PARAMETER | — | `boot-core` |
| `ResourcePermission` | 2 | METHOD, TYPE | — | `boot-core` |
| `EventSubscribe` | 2 | METHOD | — | `boot-starter-eventbus` |
| `ParamLoadService` | 2 | TYPE | Service | `boot-starter-formula` |
| `ParamLinkage` | 2 | PARAMETER | — | `boot-formula-engine` |
| `MessageListener` | 2 | METHOD | — | `boot-starter-mq` |
| `MetricMethodCounter` | 2 | METHOD | — | `boot-starter-prometheus` |
| `MetricMethodGauge` | 2 | METHOD | — | `boot-starter-prometheus` |
| `MetricMethodHistogram` | 2 | METHOD | — | `boot-starter-prometheus` |
| `MetricMethodSummary` | 2 | METHOD | — | `boot-starter-prometheus` |
| `AntiReCommit` | 2 | METHOD | — | `boot-starter-web` |
| `TraceTag` | 2 | METHOD | Repeatable | `boot-core` |
| `ExcelColumn` | 2 | FIELD | — | `boot-core` |
| `CipConnectorComment` | 2 | TYPE, METHOD, FIELD | Indexed | `cip-connector-api` |
| `ConnectorChannelRouter` | 2 | TYPE | Indexed | `cip-connector-api` |
| `MiddleTableChannelRouter` | 2 | TYPE | Indexed | `cip-connector-api` |
| `EncryptFilter` | 2 | TYPE, METHOD, FIELD | — | `organization-facade` |
| `AppOpsAuth` | 2 | METHOD | — | `udc-plugin-api` |
| `Importer` | 2 | TYPE | Component | `udc-plugin-api` |
| `ExclusivePermit` | 2 | METHOD | — | `udc-biz` |
| `AppIdRef` | 2 | — | — | `udc-cicd` |
| `LimitCountOperation` | 2 | METHOD | — | `udc-biz` |
| `FileFieldAttribute` | 1 | FIELD | — | `boot-core` |
| `MigrationIgnoreField` | 1 | FIELD | — | `boot-core` |
| `ExpressionFilter` | 1 | TYPE | Component | `boot-starter-formula` |
| `Parameters` | 1 | METHOD | — | `boot-formula-engine` |
| `FunctionSupporter` | 1 | TYPE | — | `boot-starter-formula` |
| `ECachePut` | 1 | TYPE, METHOD | CachePut | `udc-starter-lowcode` |
| `ECacheable` | 1 | TYPE, METHOD | Cacheable | `udc-starter-lowcode` |
| `ENoCache` | 1 | TYPE | — | `udc-starter-lowcode` |
| `RCacheable` | 1 | TYPE, METHOD | Cacheable | `udc-starter-lowcode` |
| `CountSql` | 1 | METHOD | — | `boot-starter-mybatis` |
| `ConfigAutoRefresh` | 1 | TYPE | — | `boot-core` |
| `CtpSentinel` | 1 | METHOD | — | `boot-core` |
| `Upgrade` | 1 | TYPE | Deprecated | `boot-starter-web` |
| `Trace` | 1 | METHOD | — | `boot-core` |
| `TraceTags` | 1 | METHOD | — | `boot-core` |
| `ExcelColumnWidth` | 1 | TYPE | — | `boot-core` |
| `CipChannelRouter` | 1 | TYPE | Indexed | `cip-capability-common` |
| `AuthModel` | 1 | TYPE | — | `udc-plugin-api` |
| `AuthOperation` | 1 | METHOD | — | `udc-plugin-api` |
| `ComparedSchema` | 1 | METHOD | — | `udc-plugin-api` |
| `DataChangeAware` | 1 | METHOD | — | `udc-cicd` |
| `ConsistencyDetection` | 1 | TYPE | Component, Order | `udc-plugin-api` |
| `ExprConsistency` | 1 | TYPE | — | `udc-biz` |
| `Idempotent` | 0 | METHOD | — | `boot-starter-appservice` |
| `DubboComponent` | 0 | TYPE | — | `boot-starter-dubbo` |
| `EventHandler` | 0 | TYPE | Component | `boot-starter-eventbus` |
| `FunctionClass` | 0 | TYPE | — | `boot-formula-engine` |
| `ECacheEvict` | 0 | TYPE, METHOD | — | `udc-starter-lowcode` |
| `MethodBizProxy` | 0 | METHOD | — | `udc-starter-lowcode` |
| `RecycleSerialNumber` | 0 | TYPE, METHOD | — | `udc-starter-lowcode` |
| `ModuleEnhance` | 0 | TYPE | — | `boot-starter-module` |
| `AsyncTrace` | 0 | TYPE | — | `boot-core` |
| `IgnoredException` | 0 | TYPE | — | `boot-core` |
| `ValidationGroup` | 0 | TYPE | — | `cip-capability-common` |
| `ImportUpgradeHandler` | 0 | TYPE | Component | `udc-plugin-api` |
| `Internal` | 0 | CONSTRUCTOR, METHOD, TYPE, FIELD | — | `boot-starter-graphql` |
| `PublicApi` | 0 | CONSTRUCTOR, METHOD, TYPE, FIELD | — | `boot-starter-graphql` |
| `PublicSpi` | 0 | CONSTRUCTOR, METHOD, TYPE | — | `boot-starter-graphql` |
| `ThreadSafe` | 0 | CONSTRUCTOR, METHOD, TYPE | — | `boot-starter-graphql` |
| `VisibleForTesting` | 0 | CONSTRUCTOR, METHOD, FIELD | Internal | `boot-starter-graphql` |
| `Batched` | 0 | METHOD | Deprecated | `boot-starter-graphql` |

## @Retention(CLASS) —— 1 个

| 注解 | 元素数 | @Target | 元注解（Spring 等） | 构件 |
|---|---|---|---|---|
| `NotNull` | 0 | FIELD, METHOD, PARAMETER, LOCAL_VARIABLE | — | `boot-starter-graphql` |

## 元素最多的 15 个（贴之前先看要填什么）

- **`EntityAttribute`**（19 元素，@Target(FIELD)）：value, description, hidden, changeId, dataI18n, dataType, relationApp, relationHostAppName, relationAppName, relationEntity, relationType, excludeFullTextSearch, multiSelect, unique …
- **`ExcelContentStyle`**（17 元素，@Target(FIELD, TYPE)）：dataFormat, hidden, locked, wrapped, verticalAlignment, horizontalAlignment, borderLeft, borderRight, borderTop, borderBottom, leftBorderColor, rightBorderColor, topBorderColor, bottomBorderColor …
- **`ExcelHeadStyle`**（17 元素，@Target(TYPE)）：dataFormat, hidden, locked, wrapped, verticalAlignment, horizontalAlignment, borderLeft, borderRight, borderTop, borderBottom, leftBorderColor, rightBorderColor, topBorderColor, bottomBorderColor …
- **`DtoAttribute`**（13 元素，@Target(FIELD, METHOD)）：value, description, hidden, xssProcess, dataI18n, relationApp, relationHostAppName, relationAppName, relationDto, subRelation, example, sort, customs
- **`CtpSchedule`**（13 元素，@Target(TYPE)）：systemTenant, isSingle, jobName, cron, description, fixedDelay, fixedDelayString, fixedRate, fixedRateString, initialDelay, initialDelayString, timeUnit, zone
- **`EntityInfo`**（12 元素，@Target(TYPE)）：value, description, entityType, historyEntity, plugins, fullTextSearch, permission, isPublic, export, isLogicDelete, sort, customs
- **`AppServiceOperation`**（9 元素，@Target(METHOD)）：value, description, returnValue, openApi, sort, requestMaxSize, plugins, ignoreVersion, customs
- **`BootApp`**（8 元素，@Target(TYPE)）：name, names, caption, version, description, owner, httpPort, udcApp
- **`Function`**（7 元素，@Target(METHOD)）：category, displayName, description, sort, hidden, terminalSupport, customAggFunction
- **`ExcelContentFontStyle`**（7 元素，@Target(FIELD, TYPE)）：fontName, fontHeightInPoints, italic, strikeout, color, underline, bold
- **`ExcelHeadFontStyle`**（7 元素，@Target(TYPE)）：fontName, fontHeightInPoints, italic, strikeout, color, underline, bold
- **`OperationLog`**（7 元素，@Target(METHOD)）：operationType, module, subModule, requestDto, recordServiceClass, defaultImpl, pathExpression
- **`EnumAttribute`**（6 元素，@Target(FIELD)）：value, description, icon, color, sort, customs
- **`EnumInfo`**（6 元素，@Target(TYPE)）：value, type, description, excludes, sort, customs
- **`MessageInfo`**（6 元素，@Target(TYPE)）：value, description, topic, sort, openApi, customs

## 全部逐个（含全名与 jar）

| 注解 | 全名 | Retention | Target | 构件 / jar |
|---|---|---|---|---|
| `EntityAttribute` | `com.seeyon.boot.annotation.EntityAttribute` | RUNTIME | FIELD | `boot-core` / boot-core-5.3.600.jar |
| `ExcelContentStyle` | `com.seeyon.boot.util.excel.annotation.ExcelContentStyle` | RUNTIME | FIELD, TYPE | `boot-core` / boot-core-5.3.600.jar |
| `ExcelHeadStyle` | `com.seeyon.boot.util.excel.annotation.ExcelHeadStyle` | RUNTIME | TYPE | `boot-core` / boot-core-5.3.600.jar |
| `DtoAttribute` | `com.seeyon.boot.annotation.DtoAttribute` | RUNTIME | FIELD, METHOD | `boot-core` / boot-core-5.3.600.jar |
| `CtpSchedule` | `com.seeyon.boot.starter.schedule.annotation.CtpSchedule` | RUNTIME | TYPE | `boot-starter-schedule` / boot-starter-schedule-5.3.600.jar |
| `EntityInfo` | `com.seeyon.boot.annotation.EntityInfo` | RUNTIME | TYPE | `boot-core` / boot-core-5.3.600.jar |
| `AppServiceOperation` | `com.seeyon.boot.annotation.AppServiceOperation` | RUNTIME | METHOD | `boot-core` / boot-core-5.3.600.jar |
| `BootApp` | `com.seeyon.boot.annotation.BootApp` | RUNTIME | TYPE | `boot-core` / boot-core-5.3.600.jar |
| `Function` | `com.seeyon.boot.starter.formula.engine.annotation.Function` | RUNTIME | METHOD | `boot-formula-engine` / boot-formula-engine-5.3.603.jar |
| `ExcelContentFontStyle` | `com.seeyon.boot.util.excel.annotation.ExcelContentFontStyle` | RUNTIME | FIELD, TYPE | `boot-core` / boot-core-5.3.600.jar |
| `ExcelHeadFontStyle` | `com.seeyon.boot.util.excel.annotation.ExcelHeadFontStyle` | RUNTIME | TYPE | `boot-core` / boot-core-5.3.600.jar |
| `OperationLog` | `com.seeyon.udc.operationlog.annotations.OperationLog` | RUNTIME | METHOD | `udc-plugin-api` / udc-plugin-api-5.3.517.jar |
| `EnumAttribute` | `com.seeyon.boot.annotation.EnumAttribute` | RUNTIME | FIELD | `boot-core` / boot-core-5.3.600.jar |
| `EnumInfo` | `com.seeyon.boot.annotation.EnumInfo` | RUNTIME | TYPE | `boot-core` / boot-core-5.3.600.jar |
| `MessageInfo` | `com.seeyon.boot.annotation.MessageInfo` | RUNTIME | TYPE | `boot-core` / boot-core-5.3.600.jar |
| `RestApiOperation` | `com.seeyon.boot.annotation.RestApiOperation` | RUNTIME | METHOD | `boot-core` / boot-core-5.3.600.jar |
| `DtoInfo` | `com.seeyon.boot.annotation.DtoInfo` | RUNTIME | TYPE | `boot-core` / boot-core-5.3.600.jar |
| `OpenApi` | `com.seeyon.boot.annotation.OpenApi` | RUNTIME | — | `boot-core` / boot-core-5.3.600.jar |
| `Safety` | `com.seeyon.boot.annotation.Safety` | RUNTIME | — | `boot-core` / boot-core-5.3.600.jar |
| `IsolatorExecutor` | `com.seeyon.boot.starter.threadpool.isolator.annotation.IsolatorExecutor` | RUNTIME | METHOD | `boot-starter-threadpool` / boot-starter-threadpool-5.3.600.jar |
| `DateValidation` | `com.seeyon.udc.common.validation.annotation.DateValidation` | RUNTIME | METHOD, FIELD, ANNOTATION_TYPE, CONSTRUCTOR, PARAMETER, TYPE_USE | `udc-biz` / udc-biz-5.3.517.jar |
| `TimeValidation` | `com.seeyon.udc.common.validation.annotation.TimeValidation` | RUNTIME | METHOD, FIELD, ANNOTATION_TYPE, CONSTRUCTOR, PARAMETER, TYPE_USE | `udc-biz` / udc-biz-5.3.517.jar |
| `LogDefault` | `com.seeyon.udc.operationlog.annotations.LogDefault` | RUNTIME | — | `udc-plugin-api` / udc-plugin-api-5.3.517.jar |
| `AppService` | `com.seeyon.boot.annotation.AppService` | RUNTIME | TYPE | `boot-core` / boot-core-5.3.600.jar |
| `EntityIndex` | `com.seeyon.boot.annotation.EntityIndex` | RUNTIME | — | `boot-core` / boot-core-5.3.600.jar |
| `Maskable` | `com.seeyon.boot.annotation.Maskable` | RUNTIME | FIELD, METHOD | `boot-core` / boot-core-5.3.600.jar |
| `RestApi` | `com.seeyon.boot.annotation.RestApi` | RUNTIME | TYPE | `boot-core` / boot-core-5.3.600.jar |
| `ReturnValue` | `com.seeyon.boot.starter.formula.engine.annotation.ReturnValue` | RUNTIME | METHOD | `boot-formula-engine` / boot-formula-engine-5.3.603.jar |
| `AttrTypeMatch` | `com.seeyon.udc.common.validation.constraints.AttrTypeMatch` | RUNTIME | METHOD, FIELD, ANNOTATION_TYPE, PARAMETER | `udc-biz` / udc-biz-5.3.517.jar |
| `DelDetection` | `com.seeyon.udc.detection.annotation.DelDetection` | RUNTIME | METHOD | `udc-biz` / udc-biz-5.3.517.jar |
| `UpdateDetection` | `com.seeyon.udc.detection.annotation.UpdateDetection` | RUNTIME | METHOD | `udc-biz` / udc-biz-5.3.517.jar |
| `ParameterInfo` | `com.seeyon.boot.annotation.ParameterInfo` | RUNTIME | PARAMETER | `boot-core` / boot-core-5.3.600.jar |
| `Parameter` | `com.seeyon.boot.starter.formula.engine.annotation.Parameter` | RUNTIME | — | `boot-formula-engine` / boot-formula-engine-5.3.603.jar |
| `PriorityCache` | `com.seeyon.boot.starter.lowcode.annotation.PriorityCache` | RUNTIME | TYPE, METHOD | `udc-starter-lowcode` / udc-starter-lowcode-5.3.605.jar |
| `UseUdcAppLog` | `com.seeyon.boot.starter.udcrt.aspect.UseUdcAppLog` | RUNTIME | TYPE, METHOD | `udc-starter-lowcode` / udc-starter-lowcode-5.3.605.jar |
| `CipDaoCondition` | `com.seeyon.cip.capability.common.ann.CipDaoCondition` | RUNTIME | FIELD | `cip-capability-common` / cip-capability-common-5.3.276.jar |
| `TypeMapping` | `com.seeyon.udc.common.annotation.TypeMapping` | RUNTIME | TYPE | `udc-common` / udc-common-5.3.605.jar |
| `UpgradeMethod` | `com.seeyon.udc.common.transport.upgrade.UpgradeMethod` | RUNTIME | METHOD | `udc-plugin-api` / udc-plugin-api-5.3.517.jar |
| `AttributeExist` | `com.seeyon.udc.common.validation.constraints.AttributeExist` | RUNTIME | METHOD, FIELD, ANNOTATION_TYPE, PARAMETER | `udc-biz` / udc-biz-5.3.517.jar |
| `EntityExist` | `com.seeyon.udc.common.validation.constraints.EntityExist` | RUNTIME | METHOD, FIELD, ANNOTATION_TYPE, PARAMETER | `udc-biz` / udc-biz-5.3.517.jar |
| `LogDefaultUpdate` | `com.seeyon.udc.operationlog.annotations.LogDefaultUpdate` | RUNTIME | — | `udc-plugin-api` / udc-plugin-api-5.3.517.jar |
| `Custom` | `com.seeyon.boot.annotation.Custom` | RUNTIME | — | `boot-core` / boot-core-5.3.600.jar |
| `CustomAttribute` | `com.seeyon.boot.annotation.CustomAttribute` | RUNTIME | — | `boot-core` / boot-core-5.3.600.jar |
| `HasRole` | `com.seeyon.boot.annotation.HasRole` | RUNTIME | METHOD, TYPE | `boot-core` / boot-core-5.3.600.jar |
| `MigrationStorageField` | `com.seeyon.boot.annotation.MigrationStorageField` | RUNTIME | FIELD | `boot-core` / boot-core-5.3.600.jar |
| `MultiRequestBody` | `com.seeyon.boot.annotation.MultiRequestBody` | RUNTIME | PARAMETER | `boot-core` / boot-core-5.3.600.jar |
| `ResourcePermission` | `com.seeyon.boot.annotation.ResourcePermission` | RUNTIME | METHOD, TYPE | `boot-core` / boot-core-5.3.600.jar |
| `EventSubscribe` | `com.seeyon.boot.starter.eventbus.annotation.EventSubscribe` | RUNTIME | METHOD | `boot-starter-eventbus` / boot-starter-eventbus-5.3.600.jar |
| `ParamLoadService` | `com.seeyon.boot.starter.formula.common.annotation.ParamLoadService` | RUNTIME | TYPE | `boot-starter-formula` / boot-starter-formula-5.3.603.jar |
| `ParamLinkage` | `com.seeyon.boot.starter.formula.engine.annotation.ParamLinkage` | RUNTIME | PARAMETER | `boot-formula-engine` / boot-formula-engine-5.3.603.jar |
| `MessageListener` | `com.seeyon.boot.starter.mq.consumer.anotations.MessageListener` | RUNTIME | METHOD | `boot-starter-mq` / boot-starter-mq-5.3.600.jar |
| `MetricMethodCounter` | `com.seeyon.boot.starter.prometheus.annotation.MetricMethodCounter` | RUNTIME | METHOD | `boot-starter-prometheus` / boot-starter-prometheus-5.3.600.jar |
| `MetricMethodGauge` | `com.seeyon.boot.starter.prometheus.annotation.MetricMethodGauge` | RUNTIME | METHOD | `boot-starter-prometheus` / boot-starter-prometheus-5.3.600.jar |
| `MetricMethodHistogram` | `com.seeyon.boot.starter.prometheus.annotation.MetricMethodHistogram` | RUNTIME | METHOD | `boot-starter-prometheus` / boot-starter-prometheus-5.3.600.jar |
| `MetricMethodSummary` | `com.seeyon.boot.starter.prometheus.annotation.MetricMethodSummary` | RUNTIME | METHOD | `boot-starter-prometheus` / boot-starter-prometheus-5.3.600.jar |
| `AntiReCommit` | `com.seeyon.boot.starter.web.annotation.AntiReCommit` | RUNTIME | METHOD | `boot-starter-web` / boot-starter-web-5.3.600.jar |
| `TraceTag` | `com.seeyon.boot.trace.TraceTag` | RUNTIME | METHOD | `boot-core` / boot-core-5.3.600.jar |
| `ExcelColumn` | `com.seeyon.boot.util.excel.annotation.ExcelColumn` | RUNTIME | FIELD | `boot-core` / boot-core-5.3.600.jar |
| `CipConnectorComment` | `com.seeyon.cip.connector.annotation.CipConnectorComment` | RUNTIME | TYPE, METHOD, FIELD | `cip-connector-api` / cip-connector-api-5.3.286.jar |
| `ConnectorChannelRouter` | `com.seeyon.cip.connector.annotation.ConnectorChannelRouter` | RUNTIME | TYPE | `cip-connector-api` / cip-connector-api-5.3.286.jar |
| `MiddleTableChannelRouter` | `com.seeyon.cip.connector.annotation.MiddleTableChannelRouter` | RUNTIME | TYPE | `cip-connector-api` / cip-connector-api-5.3.286.jar |
| `EncryptFilter` | `com.seeyon.organization.annotation.EncryptFilter` | RUNTIME | TYPE, METHOD, FIELD | `organization-facade` / organization-facade-5.3.601.jar |
| `AppOpsAuth` | `com.seeyon.udc.collaboration.annotations.AppOpsAuth` | RUNTIME | METHOD | `udc-plugin-api` / udc-plugin-api-5.3.517.jar |
| `Importer` | `com.seeyon.udc.common.autocode.transport.upgrade.Importer` | RUNTIME | TYPE | `udc-plugin-api` / udc-plugin-api-5.3.517.jar |
| `ExclusivePermit` | `com.seeyon.udc.common.concurrent.ExclusivePermit` | RUNTIME | METHOD | `udc-biz` / udc-biz-5.3.517.jar |
| `AppIdRef` | `com.seeyon.udc.dataaware.annotation.AppIdRef` | RUNTIME | — | `udc-cicd` / udc-cicd-5.3.517.jar |
| `LimitCountOperation` | `com.seeyon.udc.limit.LimitCountOperation` | RUNTIME | METHOD | `udc-biz` / udc-biz-5.3.517.jar |
| `FileFieldAttribute` | `com.seeyon.boot.annotation.FileFieldAttribute` | RUNTIME | FIELD | `boot-core` / boot-core-5.3.600.jar |
| `MigrationIgnoreField` | `com.seeyon.boot.annotation.MigrationIgnoreField` | RUNTIME | FIELD | `boot-core` / boot-core-5.3.600.jar |
| `ExpressionFilter` | `com.seeyon.boot.starter.formula.common.annotation.ExpressionFilter` | RUNTIME | TYPE | `boot-starter-formula` / boot-starter-formula-5.3.603.jar |
| `Parameters` | `com.seeyon.boot.starter.formula.engine.annotation.Parameters` | RUNTIME | METHOD | `boot-formula-engine` / boot-formula-engine-5.3.603.jar |
| `FunctionSupporter` | `com.seeyon.boot.starter.formula.init.FunctionSupporter` | RUNTIME | TYPE | `boot-starter-formula` / boot-starter-formula-5.3.603.jar |
| `ECachePut` | `com.seeyon.boot.starter.lowcode.annotation.ECachePut` | RUNTIME | TYPE, METHOD | `udc-starter-lowcode` / udc-starter-lowcode-5.3.605.jar |
| `ECacheable` | `com.seeyon.boot.starter.lowcode.annotation.ECacheable` | RUNTIME | TYPE, METHOD | `udc-starter-lowcode` / udc-starter-lowcode-5.3.605.jar |
| `ENoCache` | `com.seeyon.boot.starter.lowcode.annotation.ENoCache` | RUNTIME | TYPE | `udc-starter-lowcode` / udc-starter-lowcode-5.3.605.jar |
| `RCacheable` | `com.seeyon.boot.starter.lowcode.annotation.RCacheable` | RUNTIME | TYPE, METHOD | `udc-starter-lowcode` / udc-starter-lowcode-5.3.605.jar |
| `CountSql` | `com.seeyon.boot.starter.mybatis.annotation.CountSql` | RUNTIME | METHOD | `boot-starter-mybatis` / boot-starter-mybatis-5.3.600.jar |
| `ConfigAutoRefresh` | `com.seeyon.boot.starter.nacos.annotation.ConfigAutoRefresh` | RUNTIME | TYPE | `boot-core` / boot-core-5.3.600.jar |
| `CtpSentinel` | `com.seeyon.boot.starter.sentinel.CtpSentinel` | RUNTIME | METHOD | `boot-core` / boot-core-5.3.600.jar |
| `Upgrade` | `com.seeyon.boot.starter.upgrade.annotation.Upgrade` | RUNTIME | TYPE | `boot-starter-web` / boot-starter-web-5.3.600.jar |
| `Trace` | `com.seeyon.boot.trace.Trace` | RUNTIME | METHOD | `boot-core` / boot-core-5.3.600.jar |
| `TraceTags` | `com.seeyon.boot.trace.TraceTags` | RUNTIME | METHOD | `boot-core` / boot-core-5.3.600.jar |
| `ExcelColumnWidth` | `com.seeyon.boot.util.excel.annotation.ExcelColumnWidth` | RUNTIME | TYPE | `boot-core` / boot-core-5.3.600.jar |
| `CipChannelRouter` | `com.seeyon.cip.provider.annotation.CipChannelRouter` | RUNTIME | TYPE | `cip-capability-common` / cip-capability-common-5.3.276.jar |
| `AuthModel` | `com.seeyon.udc.auth.AuthModel` | RUNTIME | TYPE | `udc-plugin-api` / udc-plugin-api-5.3.517.jar |
| `AuthOperation` | `com.seeyon.udc.auth.AuthOperation` | RUNTIME | METHOD | `udc-plugin-api` / udc-plugin-api-5.3.517.jar |
| `ComparedSchema` | `com.seeyon.udc.common.autocode.transport.compare.ComparedSchema` | RUNTIME | METHOD | `udc-plugin-api` / udc-plugin-api-5.3.517.jar |
| `DataChangeAware` | `com.seeyon.udc.dataaware.annotation.DataChangeAware` | RUNTIME | METHOD | `udc-cicd` / udc-cicd-5.3.517.jar |
| `ConsistencyDetection` | `com.seeyon.udc.detection.ConsistencyDetection` | RUNTIME | TYPE | `udc-plugin-api` / udc-plugin-api-5.3.517.jar |
| `ExprConsistency` | `com.seeyon.udc.expression.domain.service.detection.filter.ExprConsistency` | RUNTIME | TYPE | `udc-biz` / udc-biz-5.3.517.jar |
| `Idempotent` | `com.seeyon.boot.starter.appservice.annotation.Idempotent` | RUNTIME | METHOD | `boot-starter-appservice` / boot-starter-appservice-5.3.600.jar |
| `DubboComponent` | `com.seeyon.boot.starter.dubbo.annotation.DubboComponent` | RUNTIME | TYPE | `boot-starter-dubbo` / boot-starter-dubbo-5.3.600.jar |
| `EventHandler` | `com.seeyon.boot.starter.eventbus.annotation.EventHandler` | RUNTIME | TYPE | `boot-starter-eventbus` / boot-starter-eventbus-5.3.600.jar |
| `FunctionClass` | `com.seeyon.boot.starter.formula.engine.annotation.FunctionClass` | RUNTIME | TYPE | `boot-formula-engine` / boot-formula-engine-5.3.603.jar |
| `ECacheEvict` | `com.seeyon.boot.starter.lowcode.annotation.ECacheEvict` | RUNTIME | TYPE, METHOD | `udc-starter-lowcode` / udc-starter-lowcode-5.3.605.jar |
| `MethodBizProxy` | `com.seeyon.boot.starter.lowcode.annotation.MethodBizProxy` | RUNTIME | METHOD | `udc-starter-lowcode` / udc-starter-lowcode-5.3.605.jar |
| `RecycleSerialNumber` | `com.seeyon.boot.starter.lowcode.aspect.RecycleSerialNumber` | RUNTIME | TYPE, METHOD | `udc-starter-lowcode` / udc-starter-lowcode-5.3.605.jar |
| `ModuleEnhance` | `com.seeyon.boot.starter.module.anotations.ModuleEnhance` | RUNTIME | TYPE | `boot-starter-module` / boot-starter-module-5.3.600.jar |
| `AsyncTrace` | `com.seeyon.boot.trace.AsyncTrace` | RUNTIME | TYPE | `boot-core` / boot-core-5.3.600.jar |
| `IgnoredException` | `com.seeyon.boot.trace.IgnoredException` | RUNTIME | TYPE | `boot-core` / boot-core-5.3.600.jar |
| `ValidationGroup` | `com.seeyon.cip.provider.annotation.ValidationGroup` | RUNTIME | TYPE | `cip-capability-common` / cip-capability-common-5.3.276.jar |
| `ImportUpgradeHandler` | `com.seeyon.udc.common.transport.upgrade.ImportUpgradeHandler` | RUNTIME | TYPE | `udc-plugin-api` / udc-plugin-api-5.3.517.jar |
| `Internal` | `graphql.Internal` | RUNTIME | CONSTRUCTOR, METHOD, TYPE, FIELD | `boot-starter-graphql` / boot-starter-graphql-5.3.600.jar |
| `PublicApi` | `graphql.PublicApi` | RUNTIME | CONSTRUCTOR, METHOD, TYPE, FIELD | `boot-starter-graphql` / boot-starter-graphql-5.3.600.jar |
| `PublicSpi` | `graphql.PublicSpi` | RUNTIME | CONSTRUCTOR, METHOD, TYPE | `boot-starter-graphql` / boot-starter-graphql-5.3.600.jar |
| `ThreadSafe` | `graphql.ThreadSafe` | RUNTIME | CONSTRUCTOR, METHOD, TYPE | `boot-starter-graphql` / boot-starter-graphql-5.3.600.jar |
| `VisibleForTesting` | `graphql.VisibleForTesting` | RUNTIME | CONSTRUCTOR, METHOD, FIELD | `boot-starter-graphql` / boot-starter-graphql-5.3.600.jar |
| `Batched` | `graphql.execution.batched.Batched` | RUNTIME | METHOD | `boot-starter-graphql` / boot-starter-graphql-5.3.600.jar |
| `NotNull` | `antlr.v4.runtime.misc.NotNull` | CLASS | FIELD, METHOD, PARAMETER, LOCAL_VARIABLE | `boot-starter-graphql` / boot-starter-graphql-5.3.600.jar |
