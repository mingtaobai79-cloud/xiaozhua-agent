# 业务动作索引：要做什么 → 调哪个方法 → 传什么 → 背后发生什么

> 自动生成，勿手改。`tools/core/platform/emit_action_index.py` 重跑即可。
> 数据源：`interfaces.json`（322 个 AppService / 2259 个方法）+ `service-flow-20261103/`（方法体调用链）。

## 覆盖现实（先看这段，别指望全部能追）

| 项 | 数量 | 说明 |
|---|---|---|
| AppService 方法总数 | **2259** | 322 个接口 |
| 仓库里有实现类 | **2130** | 68 个接口（46 个在 udc-biz） |
| 能追到方法体流转 | **388** | 其余实现在平台服务端，jar 里只有接口 |

⇒ **BPM / 组织架构 / 事项 / 连接器 的实现在平台服务端**，仓库里只有接口 jar，
流转追不到。这些域只能给「接口 + 入参 DTO」，具体动作要实测或看平台日志。
**UDC 域（46 个 AppService）能追全链**。

## 动作分布

| 动作 | 方法数 | 有实现 | 有流转 |
|---|---|---|---|
| 创建 | 237 | 222 | 50 |
| 修改 | 159 | 147 | 40 |
| 删除 | 137 | 125 | 44 |
| 流程 | 22 | 22 | 0 |
| 发布 | 29 | 29 | 12 |
| 导入导出 | 35 | 35 | 19 |
| 校验 | 41 | 39 | 4 |
| 启用禁用 | 11 | 11 | 0 |
| 查询 | 1198 | 1146 | 194 |
| 其他 | 390 | 354 | 25 |

## 创建（237）

| 动作方法 | 接口 | 入参 DTO | 实现 | 流转（第一步） |
|---|---|---|---|---|
| `create` | `ApplicationAppService` | `ApplicationDto` | `ApplicationAppServiceImpl` | Service:ApplicationService(create) |
| `createDepApp` | `ApplicationAppService` | `DependentApplicationDto` | `ApplicationAppServiceImpl` | Service:DependentApplicationService(create) |
| `createDepAppBatch` | `ApplicationAppService` | — | `ApplicationAppServiceImpl` | Service:DependentApplicationService(createBatch) |
| `createFromTemplate` | `ApplicationAppService` | `TemplateApplicationDto` | `ApplicationAppServiceImpl` | Service:ApplicationService(selectTemplateAppListByConditions) |
| `saveAsNewDesign` | `ApplicationAppService` | — | `ApplicationAppServiceImpl` | Service:ApplicationService(saveAsNewDesign) |
| `saveAsNormalNewDesign` | `ApplicationAppService` | — | `ApplicationAppServiceImpl` | Service:ApplicationService(saveAsNormalNewDesign) |
| `saveAsTemplate` | `ApplicationAppService` | `ApplicationCopyDto` | `ApplicationAppServiceImpl` | Other:SingleRequest(getData) |
| `create` | `ApplicationManagerAppService` | `ApplicationDto` | `ApplicationManagerAppServiceImpl` | Service:ApplicationService(create) |
| `createEntity` | `ApplicationManagerAppService` | `EntityDto` | `ApplicationManagerAppServiceImpl` | Service:EntityAppServiceImpl(createWithoutAuthentication) |
| `createIntegrationApplication` | `ApplicationManagerAppService` | `IntegrationApplicationDto` | `ApplicationManagerAppServiceImpl` | Service:ApplicationService(create) |
| `createLayoutApplication` | `ApplicationManagerAppService` | `LayoutApplicationDto` | `ApplicationManagerAppServiceImpl` | Service:ApplicationService(create) |
| `createMember` | `ApplicationManagerAppService` | `MemberAddDto` | `ApplicationManagerAppServiceImpl` | Service:AppCollaborationAppServiceImpl(createMember) |
| `createNewLayoutAfterCall` | `ApplicationManagerAppService` | `NewLayoutCreateAfterCallDto` | `ApplicationManagerAppServiceImpl` | Service:PageInfoAppService(replaceNewLayoutSchema) |
| `createOnlyPageApplication` | `ApplicationManagerAppService` | `CreateOnlyPageApplicationDto` | `ApplicationManagerAppServiceImpl` | Service:CustomPageInfoService(create4CustomPage) |
| `createReturnDto` | `ApplicationManagerAppService` | `ApplicationDto` | `ApplicationManagerAppServiceImpl` | Service:ApplicationService(create) |
| `createLayoutApplicationAsync` | `AsyncAppService` | `LayoutApplicationDto` | `AsyncAppServiceImpl` | Util:Ids(uuidAbsLong) |
| `createOnlyPageApplicationAsync` | `AsyncAppService` | `CreateOnlyPageApplicationDto` | `AsyncAppServiceImpl` | Util:Ids(uuidAbsLong) |
| `create` | `AttributeAppService` | `AttributeDto` | `AttributeAppServiceImpl` | Service:AttributeSetService(selectById) |
| `createBatch` | `AttributeAppService` | — | `AttributeAppServiceImpl` | Service:AttributeService(createBatch) |
| `createBatch4System` | `AttributeAppService` | — | `AttributeAppServiceImpl` | Service:AttributeService(createBatch4System) |
| `create` | `AttributeGroupAppService` | `AttributeGroupDto` | `AttributeGroupAppServiceImpl` | Service:AttributeGroupService(create) |
| `create` | `AttributeSetAppService` | `AttributeSetDto` | `AttributeSetAppServiceImpl` | Service:AttributeSetService(create) |
| `createBatch` | `AttributeSetAppService` | — | `AttributeSetAppServiceImpl` | Service:AttributeSetService(createBatch) |
| `create` | `DataTransferObjectAppService` | `DataTransferObjectDto` | `DataTransferObjectAppServiceImpl` | Service:DataTransferObjectService(create) |
| `createDtoWithAttrs` | `DataTransferObjectAppService` | `DataTransferObjectDto` | `DataTransferObjectAppServiceImpl` | Service:DataTransferObjectService(create) |
| `createDtoWithAttrs4EntityEvent` | `DataTransferObjectAppService` | `EventAndDataDto` | `DataTransferObjectAppServiceImpl` | Service:EntityService(selectEntityByIdsLoadAttribute) |
| `createDtoWithAttrsAndRefDtos` | `DataTransferObjectAppService` | — | `DataTransferObjectAppServiceImpl` | Service:DataTransferObjectService(createBatch) |
| `create` | `DtoAttributeAppService` | `DtoAttributeDto` | `DtoAttributeAppServiceImpl` | Service:DtoAttributeService(create) |
| `createBatch` | `DtoAttributeAppService` | — | `DtoAttributeAppServiceImpl` | Service:DtoAttributeService(createBatch) |
| `create` | `EntityAppService` | `EntityDto` | `EntityAppServiceImpl` | Service:EntityService(create) |
| `create` | `EntityGroupAppService` | `EntityGroupDto` | `EntityGroupAppServiceImpl` | Service:EntityGroupService(create) |
| `create` | `EntityPresetAppService` | `EntityPresetDto` | `EntityPresetAppServiceImpl` | Service:EntityPresetService(create) |
| `createDefaultExcelTemplate` | `EntityPresetAppService` | `Long` | `EntityPresetAppServiceImpl` | Service:EntityPresetService(createDefaultExcelTemplate) |
| `create` | `EventAppService` | `EventDto` | `EventAppServiceImpl` | Service:EventService(create) |
| `createWithEventData` | `EventWithDataAppService` | `EventAndDataDto` | `EventWithDataAppServiceImpl` | Service:DataTransferObjectAppService(createDtoWithAttrs4EntityEvent) |
| `create` | `IndexAppService` | `IndexDto` | `IndexAppServiceImpl` | Service:EntityService(selectById) |
| `create` | `ParameterAppService` | `UdcParameterDto` | `ParameterAppServiceImpl` | Service:ParameterService(create) |
| `createBatch` | `PluginAttributeAppService` | — | `PluginAttributeAppServiceImpl` | Service:AttributeService(createBatch) |
| `create` | `PluginEntityAppService` | `EntityDto` | `PluginEntityAppServiceImpl` | Service:EntityService(create) |
| `createDefaultFilterPlanContentByEntity` | `PluginPageInfoAppService` | `EntityDto` | `PluginPageInfoAppServiceImpl` | Util:PageUtils(generateFilterPlanContent4EntityDto) |
| `createDefaultRefer` | `PluginReferConfigGroupAppService` | `Long` | `PluginReferConfigGroupAppServiceImpl` | Service:EntityService(selectById) |
| `create` | `ReferConfigAppService` | `ReferConfigDto` | `ReferConfigAppServiceImpl` | Service:ReferConfigService(create) |
| `createOrUpdate` | `ReferConfigAppService` | `ReferConfigDto` | `ReferConfigAppServiceImpl` | Service:ReferConfigService(createOrUpdate) |
| `createConfigInfo` | `ReferConfigGroupAppService` | `ReferConfigInfoDto` | `ReferConfigGroupAppServiceImpl` | Service:ReferConfigGroupService(createConfigInfo) |
| `create` | `ScalabilityAppService` | `ScalabilityDto` | `ScalabilityAppServiceImpl` | Service:ScalabilityOptionService(selectById) |
| `create` | `ScalabilityOptionAppService` | `ScalabilityOptionDto` | `ScalabilityOptionAppServiceImpl` | Service:ScalabilityOptionService(create) |
| `create` | `UdcEnumAppService` | `UdcEnumDto` | `UdcEnumAppServiceImpl` | Service:UdcEnumService(create) |
| `create` | `UdcEnumCategoryAppService` | `UdcEnumCategoryDto` | `UdcEnumCategoryAppServiceImpl` | Service:UdcEnumCategoryService(create) |
| `create` | `UdcEnumItemAppService` | `UdcEnumItemDto` | `UdcEnumItemAppServiceImpl` | Service:UdcEnumItemService(create) |
| `createFunctionRefer` | `UdcFunctionAppService` | — | `UdcFunctionAppServiceImpl` | Service:FunctionNodeService(createSpaceFunctionRefer) |
| `createAffair` | `AffairCommonAppService` | `AffairCreateMessageDto` | `AffairCommonAppServiceImpl` | 见 flow 文件 |
| `createAffairCategory` | `AffairCommonAppService` | `AffairFullCategoryDto` | `AffairCommonAppServiceImpl` | 见 flow 文件 |
| `createAffairIdempotent` | `AffairCommonAppService` | `AffairCreateMessageIdempotentDto` | `AffairCommonAppServiceImpl` | 见 flow 文件 |
| `createAffairCustomOperation` | `AffairCustomOperationAppService` | `AffairCustomOperationDto` | `AffairCustomOperationAppServiceImpl` | 见 flow 文件 |
| `createAffairByMicroflow` | `AffairMicroflowAppService` | `AffairMicroflowInfoDto` | `AffairMicroflowAppServiceImpl` | 见 flow 文件 |
| `createAffairByMicroflowReturnIds` | `AffairMicroflowAppService` | `AffairMicroflowInfoDto` | `AffairMicroflowAppServiceImpl` | 见 flow 文件 |
| `createOrUpdate` | `AffairNodePermissionAppService` | — | `AffairNodePermissionAppServiceImpl` | 见 flow 文件 |
| `createOrUpdate` | `AffairOpenAppService` | — | `AffairOpenApiAppServiceImpl` | 见 flow 文件 |
| `createOrUpdateCategory` | `AffairOpenAppService` | `AffairFullCategoryDto` | `AffairOpenApiAppServiceImpl` | 见 flow 文件 |
| `createOrUpdateCategoryHierarchy` | `AffairOpenAppService` | — | `AffairOpenApiAppServiceImpl` | 见 flow 文件 |
| `create` | `AgentCommonAppService` | `AgentDto` | `AgentCommonAppServiceImpl` | 见 flow 文件 |
| `create` | `AgentCoreAppService` | `AgentDto` | 平台服务端 | — |
| `createThirdApp` | `AiAppService` | `AiAppInfoDto` | `AiAppServiceImpl` | 见 flow 文件 |
| `createOrUpdate` | `AppDraftAppService` | `AppDraftDto` | `AppDraftAppServiceImpl` | 见 flow 文件 |
| `addModifyPluginAffair` | `ApplicationAffairAppService` | `PluginAffairBatchDto` | `ApplicationAffairAppServiceImpl` | 见 flow 文件 |
| `createDatabase` | `BaseConfigAppService` | `DatabaseInfoDto` | 平台服务端 | — |
| `create` | `BpmActivityAppService` | `BpmActivityRunDto` | `BpmActivityAppServiceImpl` | 见 flow 文件 |
| `createBatch` | `BpmActivityAppService` | — | `BpmActivityAppServiceImpl` | 见 flow 文件 |
| `create` | `BpmApiFormPermissionAppService` | `BpmFormPermissionDto` | `BpmApiFormPermissionAppServiceImpl` | 见 flow 文件 |
| `createBatchOrUpdateContent` | `BpmApiFormPermissionAppService` | — | `BpmApiFormPermissionAppServiceImpl` | 见 flow 文件 |
| `createOrUpdateBatch` | `BpmApiFormPermissionAppService` | — | `BpmApiFormPermissionAppServiceImpl` | 见 flow 文件 |
| `createOrUpdateNodePermissionBatch` | `BpmApiNodePermissionAppService` | — | `BpmNodePermissionAppServiceImpl` | 见 flow 文件 |
| `savePermission` | `BpmApiNodePermissionAppService` | `BpmNodePermissionAddDto` | `BpmNodePermissionAppServiceImpl` | 见 flow 文件 |
| `savePermissionList` | `BpmApiNodePermissionAppService` | — | `BpmNodePermissionAppServiceImpl` | 见 flow 文件 |
| `saveParamData` | `BpmApiParamAppService` | `BpmParameterDataDto` | `BpmApiParamAppServiceImpl` | 见 flow 文件 |
| `saveParamSchema` | `BpmApiParamAppService` | `BpmParameterDefineDto` | `BpmApiParamAppServiceImpl` | 见 flow 文件 |
| `saveAs` | `BpmApiTransportAppService` | `BpmSaveAsDto` | `BpmApiTransportAppServiceImpl` | 见 flow 文件 |
| `addExecuteMember` | `BpmAppService` | `BpmAddExecuteUserDto` | `BpmApiAppServiceImpl` | 见 flow 文件 |
| `addNode` | `BpmAppService` | `SimpleChangeProcessRequestDto` | `BpmApiAppServiceImpl` | 见 flow 文件 |
| `saveDraft` | `BpmAppService` | `BpmSaveDraftDto` | `BpmApiAppServiceImpl` | 见 flow 文件 |
| `saveApplicationOperateLog` | `BpmApplicationOperateLogAppService` | `BpmApplicationOperateLogInfoDto` | 平台服务端 | — |
| `create` | `BpmCaseAppService` | `BpmCaseDto` | `BpmCaseAppServiceImpl` | 见 flow 文件 |
| `createBatch` | `BpmCaseAppService` | — | `BpmCaseAppServiceImpl` | 见 flow 文件 |
| `create` | `BpmOpinionAppService` | `BpmOpinionDataDto` | `BpmOpinionAppServiceImpl` | 见 flow 文件 |
| `createBatch` | `BpmOpinionAppService` | — | `BpmOpinionAppServiceImpl` | 见 flow 文件 |
| `createBatchOpinion` | `BpmOpinionAppService` | — | `BpmOpinionAppServiceImpl` | 见 flow 文件 |
| `create` | `BpmProcessLogAppService` | `BpmProcessLogDto` | `BpmProcessLogAppServiceImpl` | 见 flow 文件 |
| `createBatch` | `BpmProcessLogAppService` | — | `BpmProcessLogAppServiceImpl` | 见 flow 文件 |
| `createBatchProcessLog` | `BpmProcessLogAppService` | — | `BpmProcessLogAppServiceImpl` | 见 flow 文件 |
| `createOrUpdate` | `BpmTemplateAppService` | `BpmTemplateDto` | `BpmTemplateAppServiceImpl` | 见 flow 文件 |
| `createActivityResponsibilities` | `BpmThirdTemplateSyncAppService` | — | `BpmThirdTemplateSyncAppServiceImpl` | 见 flow 文件 |
| `createBatch` | `BpmThirdTemplateSyncAppService` | — | `BpmThirdTemplateSyncAppServiceImpl` | 见 flow 文件 |
| `createTemplateRecent` | `BpmThirdTemplateSyncAppService` | `BpmTemplateRecentDto` | `BpmThirdTemplateSyncAppServiceImpl` | 见 flow 文件 |
| `create` | `BpmWorkItemAppService` | `BpmWorkItemDto` | `BpmWorkItemAppServiceImpl` | 见 flow 文件 |
| `createBatch` | `BpmWorkItemAppService` | — | `BpmWorkItemAppServiceImpl` | 见 flow 文件 |
| `addressGetBook` | `BusinessTripAppService` | `TripAddressGetBookRequestDto` | `BusinessTripAppServiceImpl` | 见 flow 文件 |
| `addressGetH5` | `BusinessTripAppService` | `TripAddressGetH5RequestDto` | `BusinessTripAppServiceImpl` | 见 flow 文件 |
| `addressGetManager` | `BusinessTripAppService` | `TripAddressGetManagerRequestDto` | `BusinessTripAppServiceImpl` | 见 flow 文件 |
| `addressGetOrder` | `BusinessTripAppService` | `TripAddressGetOrderRequestDto` | `BusinessTripAppServiceImpl` | 见 flow 文件 |
| `create` | `CapabilityEnumAppService` | `CapabilityEnumDto` | `CapabilityEnumAppServiceImpl` | 见 flow 文件 |
| `createItem` | `CapabilityEnumAppService` | `CapabilityEnumItemDto` | `CapabilityEnumAppServiceImpl` | 见 flow 文件 |
| `createApp` | `CapabilityManageAppService` | `CipAppCreateDto` | `CapabilityManageAppServiceImpl` | 见 flow 文件 |
| `createAppConfig` | `CapabilityManageAppService` | `CipAppFeatureProviderCreateInDto` | `CapabilityManageAppServiceImpl` | 见 flow 文件 |
| `createParamBatch` | `CapabilityManageAppService` | `ProviderParameterRequestDto` | `CapabilityManageAppServiceImpl` | 见 flow 文件 |
| `saveLinkProperties` | `CapabilityManageAppService` | `CloudConnectPropertiesDto` | `CapabilityManageAppServiceImpl` | 见 flow 文件 |
| `create` | `CategoryCommonAppService` | `CategoryDto` | `CategoryCommonAppServiceImpl` | 见 flow 文件 |
| `createBatch` | `CategoryCommonAppService` | `CategorySyncBatchDto` | `CategoryCommonAppServiceImpl` | 见 flow 文件 |
| `createOrUpdate` | `CompanyAccountServiceAppService` | `CommonCompanyAccountDto` | 平台服务端 | — |
| `create` | `CtpApplicationBaseAppService` | `CtpApplicationAdminCreateDto` | 平台服务端 | — |
| `create` | `CtpAuthorizationRuleOrgAppService` | `CtpAuthorizationRuleAllDto` | `CtpAuthorizationRuleOrgAppServiceImpl` | 见 flow 文件 |
| `create` | `CtpDataAuditCoreAppService` | `CtpDataAuditDto` | `CtpDataAuditCoreAppServiceImpl` | 见 flow 文件 |
| `createOrUpdate` | `CtpLoginPreConfigAppService` | `CtpLoginPreConfigDto` | `CtpLoginPreConfigAppServiceImpl` | 见 flow 文件 |
| `create` | `CtpManagerTenantAppService` | `CtpManagerTenantDto` | `CtpManagerTenantAppServiceImpl` | 见 flow 文件 |
| `createSource` | `CtpMessageSourceTypeAppService` | `CtpMessageSourceBaseDto` | `CtpMessageSourceTypeAppServiceImpl` | 见 flow 文件 |
| `createType` | `CtpMessageSourceTypeAppService` | `CtpMessageTypeDto` | `CtpMessageSourceTypeAppServiceImpl` | 见 flow 文件 |
| `createAdmin` | `CtpOrgAdminOrgAppService` | `CtpOrgAdminConfigDto` | `CtpOrgAdminOrgAppServiceImpl` | 见 flow 文件 |
| `createOrUpdateBatch` | `CtpPersonalPlanCoreAppService` | `CtpPersonalPlanPermissionDto` | `CtpPersonalPlanCoreAppServiceImpl` | 见 flow 文件 |
| `createRedirectBatch` | `CtpPersonalPlanCoreAppService` | — | `CtpPersonalPlanCoreAppServiceImpl` | 见 flow 文件 |
| `create` | `CtpRoleCoreAppService` | `CtpRoleDto` | `CtpRoleCoreAppServiceImpl` | 见 flow 文件 |
| `saveBatch` | `CtpRoleCoreAppService` | `CtpRoleSyncDto` | `CtpRoleCoreAppServiceImpl` | 见 flow 文件 |
| `create` | `CtpSecretApprovalOrgAppService` | — | `CtpSecretApprovalOrgAppServiceImpl` | 见 flow 文件 |
| `create` | `CtpThirdPlatformConfigCoreAppService` | `CtpThirdPlatformConfigDto` | 平台服务端 | — |
| `saveUpdate` | `CtpUserBindMappingAppService` | `CtpUserMappingSyncRequestDto` | `CtpUserBindMappingAppServiceImpl` | 见 flow 文件 |
| `create` | `CtpUserCoreAppService` | `CtpUserDto` | `CtpUserCoreAppServiceImpl` | 见 flow 文件 |
| `createBatch` | `CtpUserCoreAppService` | — | `CtpUserCoreAppServiceImpl` | 见 flow 文件 |
| `createBatch` | `CtpUserResourceCoreAppService` | — | `CtpUserResourceCoreAppServiceImpl` | 见 flow 文件 |
| `createAuthorizationRule` | `CtpUserRoleCoreAppService` | `CtpAuthorizationDto` | `CtpUserRoleCoreAppServiceImpl` | 见 flow 文件 |
| `createBatch` | `CtpUserRoleCoreAppService` | — | `CtpUserRoleCoreAppServiceImpl` | 见 flow 文件 |
| `createBatchAuthorizationRule` | `CtpUserRoleCoreAppService` | `CtpUserRoleSyncDto` | `CtpUserRoleCoreAppServiceImpl` | 见 flow 文件 |
| `createUserRule` | `CtpUserRoleCoreAppService` | `CtpRuleRoleDto` | `CtpUserRoleCoreAppServiceImpl` | 见 flow 文件 |
| `initData` | `DeductionRtRuleAppService` | `DeductionRtRuleVersionQueryDto` | `DeductionRtRuleAppServiceImpl` | 见 flow 文件 |
| `saveRuleNewVersion` | `DeductionRtRuleAppService` | `DeductionRtRuleDto` | `DeductionRtRuleAppServiceImpl` | 见 flow 文件 |
| `insertOrUpdate` | `EmailAppService` | `CipEmailUserAccountDto` | `EmailAppServiceImpl` | 见 flow 文件 |
| `addEmailTemplate` | `EmailPrivateAppService` | `CipEmailTemplateDto` | `EmailPrivateAppServiceImpl` | 见 flow 文件 |
| `insertOrUpdateEmailConfig` | `EmailPrivateAppService` | `CipEmailConfigDto` | `EmailPrivateAppServiceImpl` | 见 flow 文件 |
| `insertOrUpdateEmailLimitConfig` | `EmailPrivateAppService` | `CipEmailLimitConfigDto` | `EmailPrivateAppServiceImpl` | 见 flow 文件 |
| `addFace` | `FaceIdAppService` | `FaceAddReqDto` | `FaceIdAppServiceImpl` | 见 flow 文件 |
| `create` | `ImageAppService` | — | `ImageAppServiceImpl` | 见 flow 文件 |
| `save` | `ImageCategoryAppService` | `ImageCategoryDto` | `ImageCategoryAppServiceImpl` | 见 flow 文件 |
| `save` | `ImageStoreAppService` | `ImageStoreDto` | `ImageStoreAppServiceImpl` | 见 flow 文件 |
| `save` | `IndexStoreAppService` | `IndexStoreDto` | `IndexStoreAppServiceImpl` | 见 flow 文件 |
| `saveIndexBpmData` | `IndexStoreAppService` | `IndexBpmDataDto` | `IndexStoreAppServiceImpl` | 见 flow 文件 |
| `create` | `IntegralLedgerOprateAppService` | `IntegralLedgerDto` | `IntegralLedgerOprateAppServiceImpl` | 见 flow 文件 |
| `createBatch` | `IntegralLedgerOprateAppService` | — | `IntegralLedgerOprateAppServiceImpl` | 见 flow 文件 |
| `createDocDiffTask` | `IntelligentMissiveAppService` | `DiffTaskReqDto` | `IntelligentMissiveAppServiceImpl` | 见 flow 文件 |
| `createExtractingTask` | `IntelligentMissiveAppService` | `ExtractingTaskReqDto` | `IntelligentMissiveAppServiceImpl` | 见 flow 文件 |
| `createOnlineProofread` | `IntelligentMissiveAppService` | `ProofreadTaskReqDto` | `IntelligentMissiveAppServiceImpl` | 见 flow 文件 |
| `createRecommend` | `IntelligentMissiveAppService` | `RecommendReqDto` | `IntelligentMissiveAppServiceImpl` | 见 flow 文件 |
| `createReviewTask` | `IntelligentMissiveAppService` | `ReviewTaskReqDto` | `IntelligentMissiveAppServiceImpl` | 见 flow 文件 |
| `createSettingByTemplate` | `IntelligentMissiveAppService` | `SettingTaskReqDto` | `IntelligentMissiveAppServiceImpl` | 见 flow 文件 |
| `createTableTask` | `IntelligentMissiveAppService` | `TableTaskReqDto` | `IntelligentMissiveAppServiceImpl` | 见 flow 文件 |
| `createWrite` | `IntelligentMissiveAppService` | `IntelligentWriteReqDto` | `IntelligentMissiveAppServiceImpl` | 见 flow 文件 |
| `createImageTask` | `InvoiceImageAppService` | `InvoiceImageReqDto` | `InvoiceImageAppServiceImpl` | 见 flow 文件 |
| `initDataJsonByNames` | `LinkerMigrationAppService` | — | `LinkerMigrationAppServiceImpl` | 见 flow 文件 |
| `addOrgMappingDetail` | `MappingDetailAppService` | `OrgMappingDetailAddReqDto` | `MappingDetailAppServiceImpl` | 见 flow 文件 |
| `addUserMappingDetail` | `MappingDetailAppService` | `UserMappingDetailAddReqDto` | `MappingDetailAppServiceImpl` | 见 flow 文件 |
| `createMerchant` | `MerchantAppService` | `MerchantDto` | `MerchantAppServiceImpl` | 见 flow 文件 |
| `create` | `MgnAggDataInitAppService` | `CtpMgnAggDataDto` | `MgnAggDataInitAppServiceImpl` | 见 flow 文件 |
| `saveDuty` | `MiddleTableAppService` | `DutyInfoReqDto` | `MiddleTableAppServiceImpl` | 见 flow 文件 |
| `saveLevel` | `MiddleTableAppService` | `LevelInfoReqDto` | `MiddleTableAppServiceImpl` | 见 flow 文件 |
| `saveMember` | `MiddleTableAppService` | `MemberInfoReqDto` | `MiddleTableAppServiceImpl` | 见 flow 文件 |
| `savePost` | `MiddleTableAppService` | `PostInfoReqDto` | `MiddleTableAppServiceImpl` | 见 flow 文件 |
| `saveUnit` | `MiddleTableAppService` | `UnitInfoReqDto` | `MiddleTableAppServiceImpl` | 见 flow 文件 |
| `saveDuty` | `MiddleTableOperationAppService` | `DutyInfoReqDto` | `MiddleTableOperationAppServiceImpl` | 见 flow 文件 |
| `saveLevel` | `MiddleTableOperationAppService` | `LevelInfoReqDto` | `MiddleTableOperationAppServiceImpl` | 见 flow 文件 |
| `saveMember` | `MiddleTableOperationAppService` | `MemberInfoReqDto` | `MiddleTableOperationAppServiceImpl` | 见 flow 文件 |
| `savePost` | `MiddleTableOperationAppService` | `PostInfoReqDto` | `MiddleTableOperationAppServiceImpl` | 见 flow 文件 |
| `saveUnit` | `MiddleTableOperationAppService` | `UnitInfoReqDto` | `MiddleTableOperationAppServiceImpl` | 见 flow 文件 |
| `create` | `MobilePluginConfigAppService` | `MobilePluginPlatformConfigDto` | `MobilePluginConfigAppServiceImpl` | 见 flow 文件 |
| `create` | `MyAttentionCommonAppService` | `MyAttentionDto` | 平台服务端 | — |
| `createOrUpdateBatch` | `MyAttentionCommonAppService` | — | 平台服务端 | — |
| `createApp` | `OpenCapabilityAppService` | `AppCreateDto` | 平台服务端 | — |
| `createTenantApp` | `OpenCapabilityAppService` | `TenantAppCreateDto` | 平台服务端 | — |
| `create` | `OrgJobBaseAppService` | `OrgJobRequestDto` | `OrgJobBaseAppServiceImpl` | 见 flow 文件 |
| `createBatch` | `OrgJobSyncAppService` | `OrgBatchJobDto` | `OrgJobSyncAppServiceImpl` | 见 flow 文件 |
| `create` | `OrgLevelBaseAppService` | `OrgLevelRequestDto` | `OrgLevelBaseAppServiceImpl` | 见 flow 文件 |
| `createBatch` | `OrgLevelSyncAppService` | `OrgBatchLevelDto` | `OrgLevelSyncAppServiceImpl` | 见 flow 文件 |
| `create` | `OrgMemberBaseAppService` | `OrgCreateMemberBaseDto` | `OrgMemberBaseAppServiceImpl` | 见 flow 文件 |
| `create` | `OrgMemberPostBaseAppService` | `OrgMemberPostDto` | `OrgMemberPostAppServiceImpl` | 见 flow 文件 |
| `createOrUpdateBatch` | `OrgMemberRoleBaseAppService` | — | `OrgMemberRoleBaseAppServiceImpl` | 见 flow 文件 |
| `createBatch` | `OrgMemberSyncAppService` | `OrgBatchMemberDto` | `OrgMemberSyncAppServiceImpl` | 见 flow 文件 |
| `createBatchMemberMetadata` | `OrgMemberSyncAppService` | `OrgBatchMetadataDto` | `OrgMemberSyncAppServiceImpl` | 见 flow 文件 |
| `createBatchMemberPost` | `OrgMemberSyncAppService` | `OrgBatchMemberPostDto` | `OrgMemberSyncAppServiceImpl` | 见 flow 文件 |
| `createBatchNaturalMember` | `OrgMemberSyncAppService` | `OrgBatchNaturalMemberDto` | `OrgMemberSyncAppServiceImpl` | 见 flow 文件 |
| `create` | `OrgPostBaseAppService` | `OrgPostRequestDto` | `OrgPostBaseAppServiceImpl` | 见 flow 文件 |
| `createBatch` | `OrgPostSyncAppService` | `OrgBatchPostDto` | `OrgPostSyncAppServiceImpl` | 见 flow 文件 |
| `createOrUpdateBatch` | `OrgRoleBaseAppService` | — | `OrgRoleBaseAppServiceImpl` | 见 flow 文件 |
| `create` | `OrgTeamSyncAppService` | `OrgTeamDataDto` | `OrgTeamSyncAppServiceImpl` | 见 flow 文件 |
| `createBatch` | `OrgTeamSyncAppService` | `OrgBatchTeamDto` | `OrgTeamSyncAppServiceImpl` | 见 flow 文件 |
| `create` | `OrgUnitBaseAppService` | `OrgCreateUnitBaseDto` | `OrgUnitBaseAppServiceImpl` | 见 flow 文件 |
| `createBatch` | `OrgUnitSyncAppService` | `OrgBatchUnitDto` | `OrgUnitSyncAppServiceImpl` | 见 flow 文件 |
| `createBatchUnitMetadata` | `OrgUnitSyncAppService` | `OrgBatchMetadataDto` | `OrgUnitSyncAppServiceImpl` | 见 flow 文件 |
| `create` | `OrgUnitTeamCoreAppService` | `OrgUnitTeamDto` | `OrgUnitTeamCoreAppServiceImpl` | 见 flow 文件 |
| `createRedirectBatch` | `PersonalPlanAppService` | — | `PersonalPlanAppServiceImpl` | 见 flow 文件 |
| `addModifyPluginAffair` | `PluginAffairAppService` | `PluginAffairBatchDto` | `PluginAffairAppServiceImpl` | 见 flow 文件 |
| `createDefaultFilterPlanContentByEntityId` | `PluginPageInfoAppService` | `Long` | `PluginPageInfoAppServiceImpl` | 见 flow 文件 |
| `createBatchCategory` | `PortalPortletAppService` | `UdcPortletCategoryListDto` | `PortalPortletDefinitionAppServiceImpl` | 见 flow 文件 |
| `createBatchPortlet` | `PortalPortletAppService` | `UdcPortletDefinitionListDto` | `PortalPortletDefinitionAppServiceImpl` | 见 flow 文件 |
| `createCategory` | `PortalPortletAppService` | `PortletCategoryDesignerDto` | `PortalPortletDefinitionAppServiceImpl` | 见 flow 文件 |
| `createPortlet` | `PortalPortletAppService` | `PortletDefinitionDesignerDto` | `PortalPortletDefinitionAppServiceImpl` | 见 flow 文件 |
| `createPcTemplateData` | `PortalSetAppService` | `PortalSetDesignerDto` | `PortalSetAppServiceImpl` | 见 flow 文件 |
| `createPortal` | `PortalSetAppService` | `PortalSetDesignerDto` | `PortalSetAppServiceImpl` | 见 flow 文件 |
| `create` | `PortalShortcutAppService` | `PortalShortcutDto` | 平台服务端 | — |
| `createSpace` | `PortalSpaceAppService` | `PortalSpaceDesignerDto` | `PortalSpaceAppServiceImpl` | 见 flow 文件 |
| `saveAsPortalSpaceCopy` | `PortalSpaceAppService` | `UdcPortalSpaceAndInstanceDto` | `PortalSpaceAppServiceImpl` | 见 flow 文件 |
| `create` | `QrCodeCommonAppService` | `QrCodeCreateDto` | 平台服务端 | — |
| `addSchedule` | `ScheduleAppService` | `AddScheduleDto` | `ScheduleAppServiceImpl` | 见 flow 文件 |
| `createShortMessageTemplateContent` | `ShortMessageProviderTemplateAppService` | `ShortMessageProviderTemplateDto` | `ShortMessageProviderTemplateAppServiceImpl` | 见 flow 文件 |
| `createShortMessageSign` | `ShortMessageSignAppService` | `ShortMessageSignDto` | `ShortMessageSignAppServiceImpl` | 见 flow 文件 |
| `createSmsSign` | `ShortMessageSignAppService` | `SmsSignCloudDto` | `ShortMessageSignAppServiceImpl` | 见 flow 文件 |
| `createSMSTemplate` | `ShortMessageTemplateAppService` | `ShortMessageTemplateDto` | `ShortMessageTemplateAppServiceImpl` | 见 flow 文件 |
| `createShortMessageTemplate` | `ShortMessageTemplateAppService` | `ShortMessageTemplateDto` | `ShortMessageTemplateAppServiceImpl` | 见 flow 文件 |
| `createOrg` | `SignatureAppService` | `OrganizationDto` | `SignatureAppServiceImpl` | 见 flow 文件 |
| `createOuterOrg` | `SignatureAppService` | `OuterOrganizationDto` | `SignatureAppServiceImpl` | 见 flow 文件 |
| `initPreSign` | `SignatureAppService` | `InitPreSignDto` | `SignatureAppServiceImpl` | 见 flow 文件 |
| `initiateSign` | `SignatureAppService` | `InitiateSignDto` | `SignatureAppServiceImpl` | 见 flow 文件 |
| `initiateSignFree` | `SignatureAppService` | `InitiateSignFreeDto` | `SignatureAppServiceImpl` | 见 flow 文件 |
| `saveSystemConfig` | `SystemConfigCommonAppService` | — | `SystemConfigCommonAppServiceImpl` | 见 flow 文件 |
| `createNotification` | `TeamworkMessageAppService` | `TeamworkNotificationMessageDto` | `TeamworkMessageAppServiceImpl` | 见 flow 文件 |
| `createTab` | `TeamworkTabAppService` | `TeamworkGroupTabCreateDto` | `TeamworkTabAppServiceImpl` | 见 flow 文件 |
| `createTabs` | `TeamworkTabAppService` | — | `TeamworkTabAppServiceImpl` | 见 flow 文件 |
| `create` | `ThemeAppService` | `ThemeDto` | `ThemeAppServiceImpl` | 见 flow 文件 |
| `saveTokenExpireTime` | `TokenAppService` | `String` | 平台服务端 | — |
| `createCategory` | `UdcPortalPortletAppService` | `UdcPortalPortletCategoryDto` | `UdcPortalPortletAppServiceImpl` | 见 flow 文件 |
| `createOrUpdatePortlet` | `UdcPortalPortletAppService` | `UdcPortalPortletDefinitionDto` | `UdcPortalPortletAppServiceImpl` | 见 flow 文件 |
| `createPcTemplateData` | `UdcPortalSetAppService` | `UdcPortalSetDesignerDto` | `UdcPortalSetAppServiceImpl` | 见 flow 文件 |
| `createEasyScheme` | `UdcSerialSchemeAppService` | `UdcSerialSchemeCreateDto` | `UdcSerialSchemeAppServiceImpl` | 见 flow 文件 |
| `addMeetingRoomResource` | `VideoMeetingAppService` | `VideoMeetingRoomResourceDto` | `VideoMeetingAppServiceImpl` | 见 flow 文件 |
| `addMeetingUser` | `VideoMeetingAppService` | `VideoMeetingUserDto` | `VideoMeetingAppServiceImpl` | 见 flow 文件 |
| `createPersonalVideoMeeting` | `VideoMeetingAppService` | `VideoMeetingPersonalCreateDto` | `VideoMeetingAppServiceImpl` | 见 flow 文件 |
| `createVideoMeeting` | `VideoMeetingAppService` | `VideoMeetingCreateDto` | `VideoMeetingAppServiceImpl` | 见 flow 文件 |
| `createFileConvertWords` | `VoiceAppService` | `CreateWordsDto` | `VoiceAppServiceImpl` | 见 flow 文件 |
| `createIntelligentDigest` | `VoiceAppService` | `CreateIntelligentDigestDto` | `VoiceAppServiceImpl` | 见 flow 文件 |
| `createRealTime` | `VoiceAppService` | `RealtimeDto` | `VoiceAppServiceImpl` | 见 flow 文件 |
| `createVoiceFile` | `VoiceAppService` | `CreateVoiceFileDto` | `VoiceAppServiceImpl` | 见 flow 文件 |
| `addWarningInfo` | `WarningManageAppService` | `CipWarningInfoDto` | 平台服务端 | — |
| `addWarningInfo` | `WarningManageAppService` | `CipWarningInfoDto` | 平台服务端 | — |

## 修改（159）

| 动作方法 | 接口 | 入参 DTO | 实现 | 流转（第一步） |
|---|---|---|---|---|
| `update` | `ApplicationAppService` | `ApplicationDto` | `ApplicationAppServiceImpl` | Service:ApplicationService(update) |
| `updateBatchDepAppVersion` | `ApplicationAppService` | — | `ApplicationAppServiceImpl` | Service:DependentApplicationService(updateBatchVersion) |
| `updateCaptionForAllVersion` | `ApplicationAppService` | `ApplicationDto` | `ApplicationAppServiceImpl` | Service:ApplicationService(updateCaptionForAllVersion) |
| `updateDepApp` | `ApplicationAppService` | `DependentApplicationDto` | `ApplicationAppServiceImpl` | Service:DependentApplicationService(update) |
| `updateDepAppBatch` | `ApplicationAppService` | — | `ApplicationAppServiceImpl` | Service:DependentApplicationService(updateBatch) |
| `updateNoEvents` | `ApplicationAppService` | `ApplicationDto` | `ApplicationAppServiceImpl` | Service:ApplicationService(updateNoEvents) |
| `update` | `ApplicationManagerAppService` | `ApplicationDto` | `ApplicationManagerAppServiceImpl` | Service:ApplicationService(update) |
| `updateAppCategoryBatch` | `ApplicationManagerAppService` | `AppCategoryDto` | `ApplicationManagerAppServiceImpl` | Service:ApplicationService(updateAppCategoryBatch) |
| `updateWithMember` | `ApplicationManagerAppService` | `ApplicationWithMemberDto` | `ApplicationManagerAppServiceImpl` | Service:ApplicationService(updateWithMember) |
| `update` | `AttributeAppService` | `AttributeDto` | `AttributeAppServiceImpl` | Service:AttributeSetService(selectById) |
| `updateBatch` | `AttributeAppService` | — | `AttributeAppServiceImpl` | Service:AttributeService(updateBatch) |
| `update` | `AttributeGroupAppService` | `AttributeGroupDto` | `AttributeGroupAppServiceImpl` | Service:AttributeGroupService(update) |
| `update` | `AttributeSetAppService` | `AttributeSetDto` | `AttributeSetAppServiceImpl` | Service:AttributeSetService(update) |
| `updateDetection` | `ConsistenceDetectionAppService` | `Class` | `ConsistenceDetectionAppServiceImpl` | Service:ConsistenceDetectionService(updateDetection) |
| `updateDetection4Dto` | `ConsistenceDetectionAppService` | `Class` | `ConsistenceDetectionAppServiceImpl` | Service:ConsistenceDetectionService(updateDetection4Dto) |
| `update` | `DataTransferObjectAppService` | `DataTransferObjectDto` | `DataTransferObjectAppServiceImpl` | Service:DataTransferObjectService(update) |
| `updateDtoWithAttrs` | `DataTransferObjectAppService` | `DataTransferObjectDto` | `DataTransferObjectAppServiceImpl` | Service:DtoAttributeService(selectByDtoId) |
| `updateDtoWithAttrs4EntityEvent` | `DataTransferObjectAppService` | `EventAndDataDto` | `DataTransferObjectAppServiceImpl` | Service:EntityService(selectEntityByIdsLoadAttribute) |
| `updateDtoWithAttrsAndRefDtos` | `DataTransferObjectAppService` | — | `DataTransferObjectAppServiceImpl` | Service:DtoAttributeService(deleteByIds) |
| `update` | `DtoAttributeAppService` | `DtoAttributeDto` | `DtoAttributeAppServiceImpl` | Service:DtoAttributeService(update) |
| `update` | `EntityAppService` | `EntityDto` | `EntityAppServiceImpl` | Service:EntityService(update) |
| `update` | `EntityGroupAppService` | `EntityGroupDto` | `EntityGroupAppServiceImpl` | Service:EntityGroupService(update) |
| `updateBatch` | `EntityGroupAppService` | — | `EntityGroupAppServiceImpl` | Service:EntityGroupService(updateBatch) |
| `update` | `EntityPresetAppService` | `EntityPresetDto` | `EntityPresetAppServiceImpl` | Service:EntityPresetService(update) |
| `update` | `EventAppService` | `EventDto` | `EventAppServiceImpl` | Service:EventService(update) |
| `updateWithEventData` | `EventWithDataAppService` | `EventAndDataDto` | `EventWithDataAppServiceImpl` | Service:EventService(selectWithEventData) |
| `update` | `IndexAppService` | `IndexDto` | `IndexAppServiceImpl` | Service:EntityService(selectById) |
| `update` | `ParameterAppService` | `UdcParameterDto` | `ParameterAppServiceImpl` | Service:ParameterService(update) |
| `update` | `PluginEntityAppService` | `EntityDto` | `PluginEntityAppServiceImpl` | Service:EntityService(update) |
| `updateDefaultRefer` | `PluginReferConfigGroupAppService` | `Long` | `PluginReferConfigGroupAppServiceImpl` | Service:EntityService(selectById) |
| `updateState` | `PublishStateAppService` | `PublishStateUpdateDto` | `PublishStateAppServiceImpl` | Service:PublishStateService(updateState) |
| `updateApplication` | `QueryAppService` | — | `QueryAppServiceImpl` | Dao:UdcApplicationDao(updateColumns) |
| `update` | `ReferConfigAppService` | `ReferConfigDto` | `ReferConfigAppServiceImpl` | Service:ReferConfigService(update) |
| `updateConfigInfo` | `ReferConfigGroupAppService` | `ReferConfigInfoDto` | `ReferConfigGroupAppServiceImpl` | Service:ReferConfigGroupService(updateConfigInfo) |
| `update` | `ScalabilityAppService` | `ScalabilityDto` | `ScalabilityAppServiceImpl` | Service:ScalabilityOptionService(selectById) |
| `update` | `ScalabilityOptionAppService` | `ScalabilityOptionDto` | `ScalabilityOptionAppServiceImpl` | Service:ScalabilityOptionService(update) |
| `update` | `UdcEnumAppService` | `UdcEnumDto` | `UdcEnumAppServiceImpl` | Service:UdcEnumService(update) |
| `update` | `UdcEnumCategoryAppService` | `UdcEnumCategoryDto` | `UdcEnumCategoryAppServiceImpl` | Service:UdcEnumCategoryService(update) |
| `update` | `UdcEnumItemAppService` | `UdcEnumItemDto` | `UdcEnumItemAppServiceImpl` | Service:UdcEnumItemService(update) |
| `updateFunctionRefer` | `UdcFunctionAppService` | — | `UdcFunctionAppServiceImpl` | Service:FunctionNodeService(updatePortalFunctionRefer) |
| `updateAffair` | `AffairCommonAppService` | `AffairUpdateMessageDto` | `AffairCommonAppServiceImpl` | 见 flow 文件 |
| `updateAffairById` | `AffairCommonAppService` | `AffairInfoDto` | `AffairCommonAppServiceImpl` | 见 flow 文件 |
| `updateAffairCategory` | `AffairCommonAppService` | `AffairFullCategoryDto` | `AffairCommonAppServiceImpl` | 见 flow 文件 |
| `updateAffairDone` | `AffairCommonAppService` | `Long` | `AffairCommonAppServiceImpl` | 见 flow 文件 |
| `updateAffairDoneIdempotent` | `AffairCommonAppService` | `UpdateAffairDoneDto` | `AffairCommonAppServiceImpl` | 见 flow 文件 |
| `updateAffairIdempotent` | `AffairCommonAppService` | `AffairUpdateMessageIdempotentDto` | `AffairCommonAppServiceImpl` | 见 flow 文件 |
| `updateAffairRead` | `AffairCommonAppService` | `Long` | `AffairCommonAppServiceImpl` | 见 flow 文件 |
| `updateAffairReadIdempotent` | `AffairCommonAppService` | `UpdateAffairReadDto` | `AffairCommonAppServiceImpl` | 见 flow 文件 |
| `updateAffairTrack` | `AffairCommonAppService` | `AffairTrackUpdateDto` | `AffairCommonAppServiceImpl` | 见 flow 文件 |
| `updateBatchAffairByCondition` | `AffairCommonAppService` | `AffairUpdateBatchDto` | `AffairCommonAppServiceImpl` | 见 flow 文件 |
| `updateBatchAffairByConditionIdempotent` | `AffairCommonAppService` | `AffairUpdateBatchIdempotentDto` | `AffairCommonAppServiceImpl` | 见 flow 文件 |
| `updateBpmCaseTrackToAffairTrack` | `AffairCommonAppService` | `AffairTrackUpgradeDto` | `AffairCommonAppServiceImpl` | 见 flow 文件 |
| `updateAffairDoneByMicroflow` | `AffairMicroflowAppService` | `AffairMicroUpdateConditionDto` | `AffairMicroflowAppServiceImpl` | 见 flow 文件 |
| `updateAffairReadByMicroflow` | `AffairMicroflowAppService` | `AffairMicroUpdateConditionDto` | `AffairMicroflowAppServiceImpl` | 见 flow 文件 |
| `updateTemplateAccountId2Affairs` | `AffairSuperviseAppService` | — | `AffairSuperviseAppServiceImpl` | 见 flow 文件 |
| `update` | `AgentCommonAppService` | `AgentDto` | `AgentCommonAppServiceImpl` | 见 flow 文件 |
| `update` | `AgentCoreAppService` | `AgentDto` | 平台服务端 | — |
| `updateDatabase` | `BaseConfigAppService` | `DatabaseInfoDto` | 平台服务端 | — |
| `update` | `BpmApiFormPermissionAppService` | `BpmFormPermissionDto` | `BpmApiFormPermissionAppServiceImpl` | 见 flow 文件 |
| `updateAppLogs` | `BpmApplicationOperateLogAppService` | — | 平台服务端 | — |
| `updateCase` | `BpmCaseAppService` | `BpmCaseDto` | `BpmCaseAppServiceImpl` | 见 flow 文件 |
| `updateNormalApplicationToSpecifiedInstitution` | `BpmNormalAppMultiVersionAppService` | `BpmUpdateApplicationToSpecifiedInstitutionDto` | `BpmNormalAppMultiVersionAppServiceImpl` | 见 flow 文件 |
| `updateOpinion` | `BpmOpinionAppService` | `BpmOpinionUpdateDto` | `BpmOpinionAppServiceImpl` | 见 flow 文件 |
| `updateAuthorized` | `BpmTemplateAppService` | — | `BpmTemplateAppServiceImpl` | 见 flow 文件 |
| `updateByAppName` | `BpmTemplateAppService` | `BpmTemplateDto` | `BpmTemplateAppServiceImpl` | 见 flow 文件 |
| `updateCategoryByApplicationId` | `BpmTemplateAppService` | `BpmUpdateCategoryDto` | `BpmTemplateAppServiceImpl` | 见 flow 文件 |
| `updateEffectTime` | `BpmTemplateAppService` | `String` | `BpmTemplateAppServiceImpl` | 见 flow 文件 |
| `updateEffectTimeByTemplateId` | `BpmTemplateAppService` | `BpmStartTemplateDto` | `BpmTemplateAppServiceImpl` | 见 flow 文件 |
| `updateTemplateExtend` | `BpmTemplateAppService` | `BpmTemplateExtendUpdateDto` | `BpmTemplateAppServiceImpl` | 见 flow 文件 |
| `updateAuth` | `BpmTemplateManageAppService` | `BpmBatchAuthDto` | `BpmTemplateManageAppServiceImpl` | 见 flow 文件 |
| `updateBatch` | `BpmThirdTemplateSyncAppService` | — | `BpmThirdTemplateSyncAppServiceImpl` | 见 flow 文件 |
| `update` | `CapabilityEnumAppService` | `CapabilityEnumDto` | `CapabilityEnumAppServiceImpl` | 见 flow 文件 |
| `updateItem` | `CapabilityEnumAppService` | `CapabilityEnumItemDto` | `CapabilityEnumAppServiceImpl` | 见 flow 文件 |
| `editProviderParams` | `CapabilityManageAppService` | `Long` | `CapabilityManageAppServiceImpl` | 见 flow 文件 |
| `modifyEventToken` | `CapabilityManageAppService` | `EventCallbackConfigQueryDto` | `CapabilityManageAppServiceImpl` | 见 flow 文件 |
| `setAllCapabilityCycleCount` | `CapabilityManageAppService` | `AllCapabilityCycleCountDto` | `CapabilityManageAppServiceImpl` | 见 flow 文件 |
| `setCapabilityCycleCount` | `CapabilityManageAppService` | `CapabilityCycleCountDto` | `CapabilityManageAppServiceImpl` | 见 flow 文件 |
| `updateApp` | `CapabilityManageAppService` | `CipAppUpdateDto` | `CapabilityManageAppServiceImpl` | 见 flow 文件 |
| `updateAppConfig` | `CapabilityManageAppService` | `CipAppFeatureProviderCreateInDto` | `CapabilityManageAppServiceImpl` | 见 flow 文件 |
| `updateDefaultProvider` | `CapabilityManageAppService` | `SelectProvicerEnableDto` | `CapabilityManageAppServiceImpl` | 见 flow 文件 |
| `update` | `CategoryCommonAppService` | `CategoryDto` | `CategoryCommonAppServiceImpl` | 见 flow 文件 |
| `update` | `CtpApplicationBaseAppService` | `CtpApplicationAdminCreateDto` | 平台服务端 | — |
| `updateOnlineStatus` | `CtpApplicationBaseAppService` | `String` | 平台服务端 | — |
| `updateStatus` | `CtpApplicationBaseAppService` | `Long` | 平台服务端 | — |
| `update` | `CtpAuthorizationRuleOrgAppService` | `CtpAuthorizationRuleAllDto` | `CtpAuthorizationRuleOrgAppServiceImpl` | 见 flow 文件 |
| `updateByUseTenantId` | `CtpManagerTenantAppService` | `CtpManagerTenantDto` | `CtpManagerTenantAppServiceImpl` | 见 flow 文件 |
| `updateStatusByUseTenantId` | `CtpManagerTenantAppService` | `CtpManagerTenantStatusDto` | `CtpManagerTenantAppServiceImpl` | 见 flow 文件 |
| `updateTenantAdmin` | `CtpManagerTenantAppService` | `CtpManagerTenantAdminUpdateDto` | `CtpManagerTenantAppServiceImpl` | 见 flow 文件 |
| `set` | `CtpMessageManageAppService` | `CtpMessageManageDto` | `CtpMessageManageAppServiceImpl` | 见 flow 文件 |
| `updateAdmin` | `CtpOrgAdminOrgAppService` | `CtpOrgAdminConfigDto` | `CtpOrgAdminOrgAppServiceImpl` | 见 flow 文件 |
| `updateBatchUserCode` | `CtpOrgUpgradeAppService` | — | `CtpOrgUpgradeAppServiceImpl` | 见 flow 文件 |
| `update` | `CtpPermissionApprovalOrgAppService` | `CtpPermissionApprovalDto` | `CtpPermissionApprovalOrgAppServiceImpl` | 见 flow 文件 |
| `updateByCode` | `CtpResourceCoreAppService` | `CtpResourceDto` | `CtpResourceCoreAppServiceImpl` | 见 flow 文件 |
| `update` | `CtpRoleCoreAppService` | `CtpRoleDto` | `CtpRoleCoreAppServiceImpl` | 见 flow 文件 |
| `update` | `CtpThirdPlatformConfigCoreAppService` | `CtpThirdPlatformConfigDto` | 平台服务端 | — |
| `update` | `CtpUserCoreAppService` | `CtpUserDto` | `CtpUserCoreAppServiceImpl` | 见 flow 文件 |
| `updateBatch` | `CtpUserCoreAppService` | — | `CtpUserCoreAppServiceImpl` | 见 flow 文件 |
| `update` | `DataFlowMappingAppService` | `DataFlowRtMappingSaveDto` | `DataFlowMappingAppServiceImpl` | 见 flow 文件 |
| `updateMappingState` | `DataFlowMappingAppService` | `DataFlowMappingStateUpdateDto` | `DataFlowMappingAppServiceImpl` | 见 flow 文件 |
| `editFileHistory` | `DocCallBackAppService` | `DocFileInfoDto` | `DocCallBackAppServiceImpl` | 见 flow 文件 |
| `editFileNotify` | `DocCallBackAppService` | `DocFileInfoDto` | `DocCallBackAppServiceImpl` | 见 flow 文件 |
| `editFileOnline` | `DocCallBackAppService` | `DocFileInfoDto` | `DocCallBackAppServiceImpl` | 见 flow 文件 |
| `editFileRename` | `DocCallBackAppService` | `DocFileInfoDto` | `DocCallBackAppServiceImpl` | 见 flow 文件 |
| `editFileSave` | `DocCallBackAppService` | `DocFileInfoDto` | `DocCallBackAppServiceImpl` | 见 flow 文件 |
| `editFileVersion` | `DocCallBackAppService` | `DocFileInfoDto` | `DocCallBackAppServiceImpl` | 见 flow 文件 |
| `editInfo` | `DocCallBackAppService` | `DocFileInfoDto` | `DocCallBackAppServiceImpl` | 见 flow 文件 |
| `editOnNotify` | `DocCallBackAppService` | `DocFileInfoDto` | `DocCallBackAppServiceImpl` | 见 flow 文件 |
| `editUserAuth` | `DocCallBackAppService` | `DocFileInfoDto` | `DocCallBackAppServiceImpl` | 见 flow 文件 |
| `setBookmarkPermissions` | `DocOnlineAppService` | `DocSetBookmarkPermissionsDto` | `DocOnlineAppServiceImpl` | 见 flow 文件 |
| `modifyEmailTemplate` | `EmailPrivateAppService` | `CipEmailTemplateDto` | `EmailPrivateAppServiceImpl` | 见 flow 文件 |
| `updateFace` | `FaceIdAppService` | `FaceUpdateReqDto` | `FaceIdAppServiceImpl` | 见 flow 文件 |
| `update` | `ImageAppService` | — | `ImageAppServiceImpl` | 见 flow 文件 |
| `updateIndexAuth` | `IndexStoreAppService` | `IndexUpdateAuthDto` | `IndexStoreAppServiceImpl` | 见 flow 文件 |
| `updateReferenceCount` | `LabelAppService` | `LabelDepartmentDto` | `LabelCommonAppServiceImpl` | 见 flow 文件 |
| `modifyOrgMappingDetail` | `MappingDetailAppService` | `OrgMappingDetailUpdateReqDto` | `MappingDetailAppServiceImpl` | 见 flow 文件 |
| `modifyUserMappingDetail` | `MappingDetailAppService` | `UserMappingDetailUpdateReqDto` | `MappingDetailAppServiceImpl` | 见 flow 文件 |
| `updateMerchant` | `MerchantAppService` | `MerchantDto` | `MerchantAppServiceImpl` | 见 flow 文件 |
| `update` | `MgnAggDataInitAppService` | `CtpMgnAggDataDto` | `MgnAggDataInitAppServiceImpl` | 见 flow 文件 |
| `update` | `MobilePluginConfigAppService` | `MobilePluginPlatformConfigDto` | `MobilePluginConfigAppServiceImpl` | 见 flow 文件 |
| `updateStatus` | `MobilePluginConfigAppService` | `MobilePluginPlatformConfigDto` | `MobilePluginConfigAppServiceImpl` | 见 flow 文件 |
| `update` | `MyAttentionCommonAppService` | `MyAttentionDto` | 平台服务端 | — |
| `updateAppCharges` | `OpenCapabilityAppService` | `CapabilityRechargeDto` | 平台服务端 | — |
| `updateCardInfo` | `OrgIntegrationAppService` | `UpdateReqDto` | `OrgIntegrationAppServiceImpl` | 见 flow 文件 |
| `update` | `OrgJobBaseAppService` | `OrgJobRequestDto` | `OrgJobBaseAppServiceImpl` | 见 flow 文件 |
| `update` | `OrgLevelBaseAppService` | `OrgLevelRequestDto` | `OrgLevelBaseAppServiceImpl` | 见 flow 文件 |
| `update` | `OrgMemberBaseAppService` | `OrgUpdateMemberBaseDto` | `OrgMemberBaseAppServiceImpl` | 见 flow 文件 |
| `modifyMemberInfoBySelf` | `OrgMemberCoreAppService` | `OrgModifyMemberInfoSelfDto` | `OrgMemberCoreAppServiceImpl` | 见 flow 文件 |
| `update` | `OrgMemberPostBaseAppService` | `OrgMemberPostDto` | `OrgMemberPostAppServiceImpl` | 见 flow 文件 |
| `update` | `OrgPostBaseAppService` | `OrgPostRequestDto` | `OrgPostBaseAppServiceImpl` | 见 flow 文件 |
| `update` | `OrgUnitBaseAppService` | `OrgUpdateUnitBaseDto` | `OrgUnitBaseAppServiceImpl` | 见 flow 文件 |
| `update` | `OrgUnitTeamCoreAppService` | `OrgUnitTeamDto` | `OrgUnitTeamCoreAppServiceImpl` | 见 flow 文件 |
| `updateCategory` | `PortalPortletAppService` | `PortletCategoryDesignerDto` | `PortalPortletDefinitionAppServiceImpl` | 见 flow 文件 |
| `updatePortletName` | `PortalPortletAppService` | `PortletDefinitionDesignerDto` | `PortalPortletDefinitionAppServiceImpl` | 见 flow 文件 |
| `updatePortletSortNos` | `PortalPortletAppService` | `PortalPortletSortNoParamDto` | `PortalPortletDefinitionAppServiceImpl` | 见 flow 文件 |
| `updatePortal` | `PortalSetAppService` | `PortalSetDesignerDto` | `PortalSetAppServiceImpl` | 见 flow 文件 |
| `update` | `PortalShortcutAppService` | `PortalShortcutDto` | 平台服务端 | — |
| `updateSpace` | `PortalSpaceAppService` | `PortalSpaceDesignerDto` | `PortalSpaceAppServiceImpl` | 见 flow 文件 |
| `updateBatch` | `ScalabilityFieldAppService` | — | `ScalabilityFieldAppServiceImpl` | 见 flow 文件 |
| `updateSchedule` | `ScheduleAppService` | `UpdateScheduleDto` | `ScheduleAppServiceImpl` | 见 flow 文件 |
| `updateTemplateContent` | `ShortMessageProviderTemplateAppService` | `ShortMessageProviderTemplateDto` | `ShortMessageProviderTemplateAppServiceImpl` | 见 flow 文件 |
| `updateShortMessageSign` | `ShortMessageSignAppService` | `ShortMessageSignDto` | `ShortMessageSignAppServiceImpl` | 见 flow 文件 |
| `updateSmsSign` | `ShortMessageSignAppService` | `SmsSignCloudDto` | `ShortMessageSignAppServiceImpl` | 见 flow 文件 |
| `updateTemplateSign` | `ShortMessageSignAppService` | `ShortMessageSignDto` | `ShortMessageSignAppServiceImpl` | 见 flow 文件 |
| `setTemplateSign` | `ShortMessageTemplateAppService` | `SmsSetSignDto` | `ShortMessageTemplateAppServiceImpl` | 见 flow 文件 |
| `updateShortMessageTemplate` | `ShortMessageTemplateAppService` | `ShortMessageTemplateDto` | `ShortMessageTemplateAppServiceImpl` | 见 flow 文件 |
| `updateTemplate` | `ShortMessageTemplateAppService` | `ShortMessageTemplateDto` | `ShortMessageTemplateAppServiceImpl` | 见 flow 文件 |
| `updateOrg` | `SignatureAppService` | `OrganizationUpdateDto` | `SignatureAppServiceImpl` | 见 flow 文件 |
| `updateOuterOrg` | `SignatureAppService` | `OuterOrganizationUpdateDto` | `SignatureAppServiceImpl` | 见 flow 文件 |
| `updateTab` | `TeamworkTabAppService` | `TeamworkGroupTabUpdateDto` | `TeamworkTabAppServiceImpl` | 见 flow 文件 |
| `updateTabs` | `TeamworkTabAppService` | — | `TeamworkTabAppServiceImpl` | 见 flow 文件 |
| `updateCategory` | `UdcPortalPortletAppService` | `UdcPortalPortletCategoryDto` | `UdcPortalPortletAppServiceImpl` | 见 flow 文件 |
| `updatePortletName` | `UdcPortalPortletAppService` | `UdcPortalPortletDefinitionDto` | `UdcPortalPortletAppServiceImpl` | 见 flow 文件 |
| `updatePortletSortNos` | `UdcPortalPortletAppService` | `UdcPortalPortletSortNoParamDto` | `UdcPortalPortletAppServiceImpl` | 见 flow 文件 |
| `update` | `UdcSerialConfigAppService` | `UdcSerialConfigDto` | `UdcSerialConfigAppServiceImpl` | 见 flow 文件 |
| `updateMeetingRoomResource` | `VideoMeetingAppService` | `VideoMeetingRoomResourceDto` | `VideoMeetingAppServiceImpl` | 见 flow 文件 |
| `updateVideoMeeting` | `VideoMeetingAppService` | `VideoMeetingUpdateDto` | `VideoMeetingAppServiceImpl` | 见 flow 文件 |
| `updateVideoMeetingRoom` | `VideoMeetingAppService` | `VideoMeetingRoomUpdateDto` | `VideoMeetingAppServiceImpl` | 见 flow 文件 |
| `modifyWarningInfo` | `WarningManageAppService` | `CipWarningInfoDto` | 平台服务端 | — |
| `modifyWarningInfo` | `WarningManageAppService` | `CipWarningInfoDto` | 平台服务端 | — |

## 删除（137）

| 动作方法 | 接口 | 入参 DTO | 实现 | 流转（第一步） |
|---|---|---|---|---|
| `deleteByGuid` | `ApplicationAppService` | `Long` | `ApplicationAppServiceImpl` | Service:ApplicationService(deleteByGuid) |
| `deleteById` | `ApplicationAppService` | `Long` | `ApplicationAppServiceImpl` | Service:ApplicationService(deleteById) |
| `deleteDepAppById` | `ApplicationAppService` | `Long` | `ApplicationAppServiceImpl` | Service:DependentApplicationService(deleteById) |
| `deleteDepAppsByAppId` | `ApplicationAppService` | `Long` | `ApplicationAppServiceImpl` | Service:DependentApplicationService(deleteByAppId) |
| `deleteDepAppsByIds` | `ApplicationAppService` | — | `ApplicationAppServiceImpl` | Service:DependentApplicationService(deleteByIds) |
| `deleteFormAppByGuid` | `ApplicationAppService` | `Long` | `ApplicationAppServiceImpl` | Service:ApplicationService(deleteFormAppByGuid) |
| `deleteById` | `ApplicationManagerAppService` | `Long` | `ApplicationManagerAppServiceImpl` | Service:ApplicationService(deleteById) |
| `deleteFormAppByGuid` | `ApplicationManagerAppService` | `Long` | `ApplicationManagerAppServiceImpl` | Service:ApplicationService(deleteFormAppByGuid) |
| `deleteFormAppByName` | `ApplicationManagerAppService` | `String` | `ApplicationManagerAppServiceImpl` | Service:ApplicationService(selectByAppName) |
| `deleteMemberById` | `ApplicationManagerAppService` | `Long` | `ApplicationManagerAppServiceImpl` | Service:AppCollaborationAppServiceImpl(deleteMemberById) |
| `deleteById` | `AttributeAppService` | `Long` | `AttributeAppServiceImpl` | Service:AttributeService(selectById) |
| `deleteByIds` | `AttributeAppService` | — | `AttributeAppServiceImpl` | Service:AttributeService(selectById) |
| `cancel` | `AttributeGroupAppService` | `AttributeGroupDto` | `AttributeGroupAppServiceImpl` | Service:AttributeGroupService(cancel) |
| `remove` | `AttributeGroupAppService` | `AttributeGroupDto` | `AttributeGroupAppServiceImpl` | Service:AttributeGroupService(remove) |
| `deleteById` | `AttributeSetAppService` | `Long` | `AttributeSetAppServiceImpl` | Service:AttributeSetService(selectById) |
| `deleteByIds` | `AttributeSetAppService` | — | `AttributeSetAppServiceImpl` | Service:AttributeSetService(selectById) |
| `deleteDetection` | `ConsistenceDetectionAppService` | `Class` | `ConsistenceDetectionAppServiceImpl` | Service:ConsistenceDetectionService(deleteDetection4Dto) |
| `deleteById` | `DataTransferObjectAppService` | `Long` | `DataTransferObjectAppServiceImpl` | Service:DataTransferObjectService(selectById) |
| `deleteDtoWithAttrsAndRefDtos` | `DataTransferObjectAppService` | `Long` | `DataTransferObjectAppServiceImpl` | Service:DataTransferObjectService(selectById) |
| `deleteById` | `DtoAttributeAppService` | `Long` | `DtoAttributeAppServiceImpl` | Service:DtoAttributeService(deleteById) |
| `deleteByIds` | `DtoAttributeAppService` | — | `DtoAttributeAppServiceImpl` | Service:DtoAttributeService(deleteByIds) |
| `deleteById` | `EntityAppService` | `Long` | `EntityAppServiceImpl` | Service:EntityService(selectById) |
| `deleteByIds` | `EntityAppService` | — | `EntityAppServiceImpl` | Service:EntityService(selectById) |
| `deleteById` | `EntityGroupAppService` | `Long` | `EntityGroupAppServiceImpl` | Service:EntityGroupService(selectById) |
| `deleteByIds` | `EntityGroupAppService` | — | `EntityGroupAppServiceImpl` | Service:EntityGroupService(selectById) |
| `deleteById` | `EventAppService` | `Long` | `EventAppServiceImpl` | Service:EventService(selectById) |
| `deleteByIds` | `EventAppService` | — | `EventAppServiceImpl` | Service:EventService(selectByIds) |
| `deleteById` | `IndexAppService` | `Long` | `IndexAppServiceImpl` | Service:IndexService(selectById) |
| `deleteByIds` | `IndexAppService` | — | `IndexAppServiceImpl` | Service:IndexService(selectById) |
| `deleteById` | `ParameterAppService` | `Long` | `ParameterAppServiceImpl` | Service:ParameterService(deleteById) |
| `deleteByIds` | `ParameterAppService` | — | `ParameterAppServiceImpl` | Service:ParameterService(deleteByIds) |
| `deleteDefaultRefer` | `PluginReferConfigGroupAppService` | — | `PluginReferConfigGroupAppServiceImpl` | Service:ReferConfigGroupService(deleteByEntityIds) |
| `deleteById` | `ReferConfigAppService` | `Long` | `ReferConfigAppServiceImpl` | Service:ReferConfigService(selectById) |
| `deleteById` | `ReferConfigGroupAppService` | `Long` | `ReferConfigGroupAppServiceImpl` | Service:ReferConfigGroupService(selectById) |
| `deleteById` | `ScalabilityAppService` | `Long` | `ScalabilityAppServiceImpl` | Service:ScalabilityService(selectById) |
| `deleteByIds` | `ScalabilityAppService` | — | `ScalabilityAppServiceImpl` | Service:ScalabilityService(selectById) |
| `deleteById` | `ScalabilityOptionAppService` | `Long` | `ScalabilityOptionAppServiceImpl` | Service:ScalabilityOptionService(selectById) |
| `deleteById` | `UdcEnumAppService` | `Long` | `UdcEnumAppServiceImpl` | Service:UdcEnumService(selectById) |
| `deleteByIds` | `UdcEnumAppService` | — | `UdcEnumAppServiceImpl` | Service:UdcEnumService(selectById) |
| `deleteById` | `UdcEnumCategoryAppService` | `Long` | `UdcEnumCategoryAppServiceImpl` | Service:UdcEnumCategoryService(selectById) |
| `deleteByIds` | `UdcEnumCategoryAppService` | — | `UdcEnumCategoryAppServiceImpl` | Service:UdcEnumCategoryService(selectById) |
| `deleteById` | `UdcEnumItemAppService` | `Long` | `UdcEnumItemAppServiceImpl` | Service:UdcEnumItemService(deleteById) |
| `deleteByIds` | `UdcEnumItemAppService` | — | `UdcEnumItemAppServiceImpl` | Service:UdcEnumItemService(deleteByIds) |
| `deletePortalFunctionRefer` | `UdcFunctionAppService` | — | `UdcFunctionAppServiceImpl` | Service:FunctionNodeService(deleteSpaceFunctionRefer) |
| `deleteAffairByIds` | `AffairCommonAppService` | `AffairCommonIdsDto` | `AffairCommonAppServiceImpl` | 见 flow 文件 |
| `deleteAffairByObjectIds` | `AffairCommonAppService` | `AffairCommonIdsDto` | `AffairCommonAppServiceImpl` | 见 flow 文件 |
| `deleteAffairCategoryByCondition` | `AffairCommonAppService` | `AffairDeleteCategoryConditionDto` | `AffairCommonAppServiceImpl` | 见 flow 文件 |
| `deleteAffairCategoryById` | `AffairCommonAppService` | `Long` | `AffairCommonAppServiceImpl` | 见 flow 文件 |
| `deleteByIds` | `AffairNodePermissionAppService` | — | `AffairNodePermissionAppServiceImpl` | 见 flow 文件 |
| `deleteCategory` | `AffairOpenAppService` | `AffairDeleteCategoryConditionDto` | `AffairOpenApiAppServiceImpl` | 见 flow 文件 |
| `deleteCategoryHierarchy` | `AffairOpenAppService` | `AffairCategoryHierarchyDeleteDto` | `AffairOpenApiAppServiceImpl` | 见 flow 文件 |
| `deleteAgent` | `AgentCommonAppService` | — | `AgentCommonAppServiceImpl` | 见 flow 文件 |
| `cancelAgent` | `AgentCoreAppService` | — | 平台服务端 | — |
| `delete` | `AppDraftAppService` | `String` | `AppDraftAppServiceImpl` | 见 flow 文件 |
| `deleteAll` | `AppDraftAppService` | `String` | `AppDraftAppServiceImpl` | 见 flow 文件 |
| `deleteByAppIdList` | `ApprovalAppService` | — | `ApprovalAppServiceImpl` | 见 flow 文件 |
| `deleteDatabaseById` | `BaseConfigAppService` | `Long` | 平台服务端 | — |
| `deleteById` | `BpmApiFormPermissionAppService` | `Long` | `BpmApiFormPermissionAppServiceImpl` | 见 flow 文件 |
| `deleteFormPermisionForceEntityDraft` | `BpmApiFormPermissionAppService` | `BpmFormPermissionDeleteRequestDto` | `BpmApiFormPermissionAppServiceImpl` | 见 flow 文件 |
| `deleteSettingByIds` | `BpmApiParamAppService` | — | `BpmApiParamAppServiceImpl` | 见 flow 文件 |
| `cancelItems` | `BpmAppService` | `BpmCancelItemDto` | `BpmApiAppServiceImpl` | 见 flow 文件 |
| `cancelPause` | `BpmAppService` | `BpmPauseDto` | `BpmApiAppServiceImpl` | 见 flow 文件 |
| `deleteDraft` | `BpmAppService` | `Long` | `BpmApiAppServiceImpl` | 见 flow 文件 |
| `deleteDraftAffair` | `BpmAppService` | `DeleteDraftReqDto` | `BpmApiAppServiceImpl` | 见 flow 文件 |
| `deleteCaseByIds` | `BpmCaseAppService` | `BpmDeleteCaseDto` | `BpmCaseAppServiceImpl` | 见 flow 文件 |
| `deleteOpinion` | `BpmOpinionAppService` | `BpmDeleteOpinionDto` | `BpmOpinionAppServiceImpl` | 见 flow 文件 |
| `cancelFocus` | `BpmSuperviseAppService` | `SuperviseCancelFocusDto` | `BpmSuperviseAppServiceImpl` | 见 flow 文件 |
| `deleteByApps` | `BpmTemplateAppService` | — | `BpmTemplateAppServiceImpl` | 见 flow 文件 |
| `deleteById` | `BpmTemplateAppService` | `Long` | `BpmTemplateAppServiceImpl` | 见 flow 文件 |
| `clearDefaultFrameCache` | `BpmTemplateManageAppService` | `String` | `BpmTemplateManageAppServiceImpl` | 见 flow 文件 |
| `delete` | `CapabilityEnumAppService` | `Long` | `CapabilityEnumAppServiceImpl` | 见 flow 文件 |
| `deleteItem` | `CapabilityEnumAppService` | `Long` | `CapabilityEnumAppServiceImpl` | 见 flow 文件 |
| `deleteItemByIds` | `CapabilityEnumAppService` | — | `CapabilityEnumAppServiceImpl` | 见 flow 文件 |
| `deleteApp` | `CapabilityManageAppService` | `Long` | `CapabilityManageAppServiceImpl` | 见 flow 文件 |
| `deleteParam` | `CapabilityManageAppService` | `Long` | `CapabilityManageAppServiceImpl` | 见 flow 文件 |
| `deleteById` | `CategoryCommonAppService` | `Long` | `CategoryCommonAppServiceImpl` | 见 flow 文件 |
| `deleteApp` | `CdpBiz4UdcAppService` | `DeleteAppParamsDto` | `CdpBiz4UdcAppServiceImpl` | 见 flow 文件 |
| `deleteByStorageKeys` | `CipFileAppService` | `FileDeleteDto` | `CipFileAppServiceImpl` | 见 flow 文件 |
| `deliveryMqMessage` | `CipMessageAppService` | `CipMessageDeliveryDto` | `CipMessageDeliveryAppServiceImpl` | 见 flow 文件 |
| `delete` | `CtpAuthorizationRuleOrgAppService` | `CtpAuthorizationRuleDeleteDto` | `CtpAuthorizationRuleOrgAppServiceImpl` | 见 flow 文件 |
| `deleteByUseTenantId` | `CtpManagerTenantAppService` | `Long` | `CtpManagerTenantAppServiceImpl` | 见 flow 文件 |
| `deleteMessageRegister` | `CtpMessageManageAppService` | `String` | `CtpMessageManageAppServiceImpl` | 见 flow 文件 |
| `deleteMessageByIdentification` | `CtpMessageOperateAppService` | `String` | `CtpMessageOperateAppServiceImpl` | 见 flow 文件 |
| `deleteOrgAdminByOrgId` | `CtpOrgAdminOrgAppService` | `Long` | `CtpOrgAdminOrgAppServiceImpl` | 见 flow 文件 |
| `deleteByIds` | `CtpPersonalPlanCoreAppService` | — | `CtpPersonalPlanCoreAppServiceImpl` | 见 flow 文件 |
| `deleteDesignResources` | `CtpResourceCommonAppService` | `String` | `CtpResourceCommonAppServiceImpl` | 见 flow 文件 |
| `deleteByConditions` | `CtpResourceCoreAppService` | — | `CtpResourceCoreAppServiceImpl` | 见 flow 文件 |
| `deleteByResourceCode` | `CtpResourcePermissionCoreAppService` | `String` | `CtpResourcePermissionCoreAppServiceImpl` | 见 flow 文件 |
| `deleteByConditions` | `CtpRoleCoreAppService` | — | `CtpRoleCoreAppServiceImpl` | 见 flow 文件 |
| `deleteByIds` | `CtpThirdPlatformConfigCoreAppService` | — | 平台服务端 | — |
| `deleteByConditions` | `CtpUserResourceCoreAppService` | — | `CtpUserResourceCoreAppServiceImpl` | 见 flow 文件 |
| `deleteAuthorizationRuleById` | `CtpUserRoleCoreAppService` | `Long` | `CtpUserRoleCoreAppServiceImpl` | 见 flow 文件 |
| `deleteByConditions` | `CtpUserRoleCoreAppService` | — | `CtpUserRoleCoreAppServiceImpl` | 见 flow 文件 |
| `deleteByIds` | `CtpUserRoleCoreAppService` | — | `CtpUserRoleCoreAppServiceImpl` | 见 flow 文件 |
| `deleteEmailConfig` | `EmailPrivateAppService` | — | `EmailPrivateAppServiceImpl` | 见 flow 文件 |
| `deleteEmailTemplate` | `EmailPrivateAppService` | `String` | `EmailPrivateAppServiceImpl` | 见 flow 文件 |
| `deleteEmailTemplates` | `EmailPrivateAppService` | — | `EmailPrivateAppServiceImpl` | 见 flow 文件 |
| `deleteImage` | `ImageAppService` | — | `ImageAppServiceImpl` | 见 flow 文件 |
| `deleteCategory` | `ImageCategoryAppService` | `Long` | `ImageCategoryAppServiceImpl` | 见 flow 文件 |
| `deleteStore` | `ImageStoreAppService` | `Long` | `ImageStoreAppServiceImpl` | 见 flow 文件 |
| `delete` | `IndexStoreAppService` | `IndexDeleteDto` | `IndexStoreAppServiceImpl` | 见 flow 文件 |
| `deleteOrgMappingDetail` | `MappingDetailAppService` | `OrgMappingDetailDeleteReqDto` | `MappingDetailAppServiceImpl` | 见 flow 文件 |
| `deleteUserMappingDetail` | `MappingDetailAppService` | `UserMappingDetailDeleteReqDto` | `MappingDetailAppServiceImpl` | 见 flow 文件 |
| `deleteMerchant` | `MerchantAppService` | `Long` | `MerchantAppServiceImpl` | 见 flow 文件 |
| `delete` | `MiddleTableAppService` | `MiddleTableDeleteReqDto` | `MiddleTableAppServiceImpl` | 见 flow 文件 |
| `delete` | `MiddleTableOperationAppService` | `MiddleTableDeleteReqDto` | `MiddleTableOperationAppServiceImpl` | 见 flow 文件 |
| `deleteByIds` | `MobilePluginConfigAppService` | — | `MobilePluginConfigAppServiceImpl` | 见 flow 文件 |
| `deleteBatchByObjectIds` | `MyAttentionCommonAppService` | `MyAttentionBatchDeleteDto` | 平台服务端 | — |
| `deleteByObjectIdOrPageUrl` | `MyAttentionCommonAppService` | — | 平台服务端 | — |
| `delete` | `OrgUnitTeamCoreAppService` | `Long` | `OrgUnitTeamCoreAppServiceImpl` | 见 flow 文件 |
| `deleteReturnFileByKey` | `OrgWorkFlowAppService` | `WorkFlowSelectStorageKeyRequestDto` | `OrgWorkFlowAppServiceImpl` | 见 flow 文件 |
| `deleteByIds` | `PersonalPlanAppService` | — | `PersonalPlanAppServiceImpl` | 见 flow 文件 |
| `cancelApply` | `PhysicalSealAppService` | `PhysicalSealApplyIdDto` | `PhysicalSealAppServiceImpl` | 见 flow 文件 |
| `deleteCategoryByCodes` | `PortalPortletAppService` | — | `PortalPortletDefinitionAppServiceImpl` | 见 flow 文件 |
| `deletePortletByIds` | `PortalPortletAppService` | — | `PortalPortletDefinitionAppServiceImpl` | 见 flow 文件 |
| `deletePortlets` | `PortalPortletAppService` | `PortletBatchOperateDto` | `PortalPortletDefinitionAppServiceImpl` | 见 flow 文件 |
| `deletePortalDesignInfo` | `PortalSetAppService` | — | `PortalSetAppServiceImpl` | 见 flow 文件 |
| `deleteById` | `PortalShortcutAppService` | `Long` | 平台服务端 | — |
| `deleteSpaceById` | `PortalSpaceAppService` | `Long` | `PortalSpaceAppServiceImpl` | 见 flow 文件 |
| `deleteByApp` | `ResourceAppService` | `Long` | 平台服务端 | — |
| `deleteByPage` | `ResourceAppService` | `UdcResourceDeleteDto` | 平台服务端 | — |
| `deleteByRef` | `ResourceAppService` | `UdcResourceDeleteDto` | 平台服务端 | — |
| `cancelSchedule` | `ScheduleAppService` | `ScheduleInfoDto` | `ScheduleAppServiceImpl` | 见 flow 文件 |
| `cancelAuthSeal` | `SealAppService` | `SealRequestDto` | 平台服务端 | — |
| `deleteAuthSeal` | `SealAppService` | `SealRequestDto` | 平台服务端 | — |
| `deleteTemplateContent` | `ShortMessageProviderTemplateAppService` | `Long` | `ShortMessageProviderTemplateAppServiceImpl` | 见 flow 文件 |
| `deleteShortMessageSign` | `ShortMessageSignAppService` | `Long` | `ShortMessageSignAppServiceImpl` | 见 flow 文件 |
| `deleteTemplateById` | `ShortMessageTemplateAppService` | `Long` | `ShortMessageTemplateAppServiceImpl` | 见 flow 文件 |
| `deleteTemplateByIds` | `ShortMessageTemplateAppService` | — | `ShortMessageTemplateAppServiceImpl` | 见 flow 文件 |
| `deleteInnerUsers` | `SignatureAppService` | `DeleteInnerUsersReqDto` | `SignatureAppServiceImpl` | 见 flow 文件 |
| `deleteTab` | `TeamworkTabAppService` | `TeamworkGroupTabDeleteDto` | `TeamworkTabAppServiceImpl` | 见 flow 文件 |
| `deleteTabs` | `TeamworkTabGeneralizeAppService` | `TeamworkGroupTabListDto` | 平台服务端 | — |
| `deleteCtpEnumByAppApprovalOrUdc` | `UdcCtpEnumAppService` | `UdcCtpEnumItemSearchDto` | `UdcCtpEnumAppServiceImpl` | 见 flow 文件 |
| `deleteCategoryByIds` | `UdcPortalPortletAppService` | — | `UdcPortalPortletAppServiceImpl` | 见 flow 文件 |
| `deletePortletByIds` | `UdcPortalPortletAppService` | `UdcPortletBatchOperateDto` | `UdcPortalPortletAppServiceImpl` | 见 flow 文件 |
| `cancelVideoMeeting` | `VideoMeetingAppService` | `VideoMeetingOperateDto` | `VideoMeetingAppServiceImpl` | 见 flow 文件 |
| `deleteVideoMeetingRoom` | `VideoMeetingAppService` | `VideoMeetingRoomOperateDto` | `VideoMeetingAppServiceImpl` | 见 flow 文件 |

## 流程（22）

| 动作方法 | 接口 | 入参 DTO | 实现 | 流转（第一步） |
|---|---|---|---|---|
| `stopCase` | `Affair4WorkflowAppService` | `WorkflowStopDto` | `Affair4WorkflowAppServiceImpl` | 见 flow 文件 |
| `repeal` | `BpmAppService` | `BpmRepealDto` | `BpmApiAppServiceImpl` | 见 flow 文件 |
| `send` | `BpmAppService` | `BpmSendDto` | `BpmApiAppServiceImpl` | 见 flow 文件 |
| `stop` | `BpmAppService` | `BpmStopDto` | `BpmApiAppServiceImpl` | 见 flow 文件 |
| `submit` | `BpmAppService` | `BpmSubmitDto` | `BpmApiAppServiceImpl` | 见 flow 文件 |
| `stop` | `BpmTemplateAppService` | `String` | `BpmTemplateAppServiceImpl` | 见 flow 文件 |
| `stopByTemplateId` | `BpmTemplateAppService` | `Long` | `BpmTemplateAppServiceImpl` | 见 flow 文件 |
| `sendOpenApiRequest` | `CapabilityManageAppService` | `OpenApiSendDto` | `CapabilityManageAppServiceImpl` | 见 flow 文件 |
| `sendOpenApiRequestPage` | `CapabilityManageAppService` | `OpenApiSendDto` | `CapabilityManageAppServiceImpl` | 见 flow 文件 |
| `sendMessageByChooseJson` | `CtpUdcMessageSendAppService` | `UdcMessageSendChooseDto` | `CtpUdcMessageSendServiceImpl` | 见 flow 文件 |
| `sendMessageByUser` | `CtpUdcMessageSendAppService` | `UdcMessageSendUserDto` | `CtpUdcMessageSendServiceImpl` | 见 flow 文件 |
| `sendNormalEmail` | `EmailAppService` | `EmailDetailsDto` | `EmailAppServiceImpl` | 见 flow 文件 |
| `sendNormalEmailByAccount` | `EmailAppService` | `EmailAppointAccountDto` | `EmailAppServiceImpl` | 见 flow 文件 |
| `sendPersonalEmail` | `EmailAppService` | `EmailDetailsDto` | `EmailAppServiceImpl` | 见 flow 文件 |
| `sendTemplateEmail` | `EmailAppService` | `EmailTemplateSendDto` | `EmailAppServiceImpl` | 见 flow 文件 |
| `submitAudit` | `MobilePluginAppletAppService` | `MobilePluginAppletOpenQueryDto` | `MobilePluginAppletAppServiceImpl` | 见 flow 文件 |
| `sendShortMessage` | `ShortMessageAppService` | `SmsSendDto` | `ShortMessageAppServiceImpl` | 见 flow 文件 |
| `sendShortMessageAsync` | `ShortMessageAppService` | — | `ShortMessageAppServiceImpl` | 见 flow 文件 |
| `sendSycShortMessage` | `ShortMessageAppService` | `SmsSendDto` | `ShortMessageAppServiceImpl` | 见 flow 文件 |
| `finish` | `SignatureAppService` | `ContractLockRequestDto` | `SignatureAppServiceImpl` | 见 flow 文件 |
| `sendCard` | `TeamworkMessageAppService` | `TeamworkCardMessageDto` | `TeamworkMessageAppServiceImpl` | 见 flow 文件 |
| `finishVideoMeeting` | `VideoMeetingAppService` | `VideoMeetingOperateDto` | `VideoMeetingAppServiceImpl` | 见 flow 文件 |

## 发布（29）

| 动作方法 | 接口 | 入参 DTO | 实现 | 流转（第一步） |
|---|---|---|---|---|
| `deployForm` | `ApplicationAppService` | `DeployFormDto` | `ApplicationAppServiceImpl` | Service:ApplicationService(deploy) |
| `deployNormal` | `ApplicationAppService` | `DeployNormalDto` | `ApplicationAppServiceImpl` | Service:ApplicationService(deploy) |
| `deployForm` | `ApplicationManagerAppService` | `DeployFormDto` | `ApplicationManagerAppServiceImpl` | Service:ApplicationService(deploy) |
| `deployNormal` | `ApplicationManagerAppService` | `DeployNormalDto` | `ApplicationManagerAppServiceImpl` | Service:ApplicationService(deploy) |
| `shelfCompatibilityLock` | `ApplicationManagerAppService` | `ShelfCompatibilityLockRequestDto` | `ApplicationManagerAppServiceImpl` | Service:ApplicationService(lockCompatibility) |
| `upgradeOnlyPageApplication` | `ApplicationManagerAppService` | `OnlyPageApplicationUpgradeDto` | `ApplicationManagerAppServiceImpl` | Service:CustomPageInfoService(upgradeSchema) |
| `upgradeOnlyPageApplicationAsync` | `AsyncAppService` | `OnlyPageApplicationUpgradeDto` | `AsyncAppServiceImpl` | Util:Ids(uuidAbsLong) |
| `upgradeCallExtendAppService` | `MicroFlowUpgradeAppService` | `Long` | `MicroFlowUpgradeAppServiceImpl` | Service:MicroFlowService(selectListByConditions) |
| `upgradeEntityEventFullName` | `MicroFlowUpgradeAppService` | `Long` | `MicroFlowUpgradeAppServiceImpl` | Service:MicroFlowService(selectByAppId) |
| `upgradeExtendFullNameByAppId` | `MicroFlowUpgradeAppService` | `String` | `MicroFlowUpgradeAppServiceImpl` | Service:ApplicationService(selectById) |
| `upgradeThirdEntity` | `MicroFlowUpgradeAppService` | `String` | `MicroFlowUpgradeAppServiceImpl` | Service:ApplicationService(selectById) |
| `upgradeThirdServiceByNames` | `MicroFlowUpgradeAppService` | `ThirdServiceQueryDto` | `MicroFlowUpgradeAppServiceImpl` | Service:ThirdServiceQueryDto(getAppId) |
| `publish` | `AffairNodePermissionAppService` | `String` | `AffairNodePermissionAppServiceImpl` | 见 flow 文件 |
| `deployBpmTemplatesIndependent` | `BpmDeployAppService` | `String` | `BpmDeployAppServiceImpl` | 见 flow 文件 |
| `upgradeBpmTemplateVersion` | `BpmDeployAppService` | `String` | `BpmDeployAppServiceImpl` | 见 flow 文件 |
| `upgradeCommon` | `BpmDeployAppService` | `UpgradeInfoDto` | `BpmDeployAppServiceImpl` | 见 flow 文件 |
| `publishCheck` | `BpmTemplateAppService` | `String` | `BpmTemplateAppServiceImpl` | 见 flow 文件 |
| `publishCheckByAppInfo` | `BpmTemplateAppService` | `BpmAppInfoDto` | `BpmTemplateAppServiceImpl` | 见 flow 文件 |
| `publishFinish` | `BpmTemplateAppService` | `BpmPublishResult` | `BpmTemplateAppServiceImpl` | 见 flow 文件 |
| `publishLock` | `BpmTemplateAppService` | `String` | `BpmTemplateAppServiceImpl` | 见 flow 文件 |
| `publishLockByAppInfo` | `BpmTemplateAppService` | `BpmAppInfoDto` | `BpmTemplateAppServiceImpl` | 见 flow 文件 |
| `upgradeExtensionPlan` | `BpmUpgrade51To52AppService` | — | `BpmUpgradeV51To52AppServiceImpl` | 见 flow 文件 |
| `deploy` | `CdpBiz4UdcAppService` | `PublishParamsDto` | `CdpBiz4UdcAppServiceImpl` | 见 flow 文件 |
| `upgradeApps` | `CdpBiz4UdcAppService` | — | `CdpBiz4UdcAppServiceImpl` | 见 flow 文件 |
| `upgrade` | `FeatureAppService` | `String` | `FeatureAppServiceImpl` | 见 flow 文件 |
| `releaseAudited` | `MobilePluginAppletAppService` | `MobilePluginAppletOpenCommonDto` | `MobilePluginAppletAppServiceImpl` | 见 flow 文件 |
| `publishPortalDesignInfo` | `PortalSetAppService` | `Long` | `PortalSetAppServiceImpl` | 见 flow 文件 |
| `upgrade` | `StereotypeAppService` | `String` | `StereotypeAppServiceImpl` | 见 flow 文件 |
| `publishById` | `ThemeAppService` | `Long` | `ThemeAppServiceImpl` | 见 flow 文件 |

## 导入导出（35）

| 动作方法 | 接口 | 入参 DTO | 实现 | 流转（第一步） |
|---|---|---|---|---|
| `copyApp` | `ApplicationAppService` | `ApplicationCopyDto` | `ApplicationAppServiceImpl` | Util:RequestUtils(requestAsync) |
| `importAppOnlineIntoCurrentApp` | `ApplicationAppService` | — | `ApplicationAppServiceImpl` | Other:AutoCodeManager(importAppSchemaOnLine) |
| `importAppZipIntoCurrentApp` | `ApplicationAppService` | — | `ApplicationAppServiceImpl` | Other:AutoCodeManager(importAppSchemaZip) |
| `copyApp` | `ApplicationManagerAppService` | `ApplicationCopyDto` | `ApplicationManagerAppServiceImpl` | Other:SingleRequest(getData) |
| `copyAppAsync` | `ApplicationManagerAppService` | `ApplicationCopyDto` | `ApplicationManagerAppServiceImpl` | Util:RequestUtils(requestAsync) |
| `copyLayoutApp` | `ApplicationManagerAppService` | `ApplicationCopyDto` | `ApplicationManagerAppServiceImpl` | Service:CustomPageInfoService(getLayoutByAppId) |
| `copyOnlyPageApp` | `ApplicationManagerAppService` | `ApplicationCopyDto` | `ApplicationManagerAppServiceImpl` | Service:CustomPageInfoService(getOriginNewPagePairListByAppId) |
| `exportAppInfos` | `ApplicationManagerAppService` | `AppInfoExportDto` | `ApplicationManagerAppServiceImpl` | Service:AppVersionService(exportAppInfos) |
| `importApp` | `ApplicationManagerAppService` | `String` | `ApplicationManagerAppServiceImpl` | Other:SingleRequest(getData) |
| `importAppWithDto` | `ApplicationManagerAppService` | `ApplicationImportDto` | `ApplicationManagerAppServiceImpl` | Other:SingleRequest(getData) |
| `importFormApp` | `ApplicationManagerAppService` | — | `ApplicationManagerAppServiceImpl` | Util:RequestUtils(requestAsync) |
| `importFormValidate` | `ApplicationManagerAppService` | — | `ApplicationManagerAppServiceImpl` | Other:SchemaManager(importValidate) |
| `transfer` | `ApplicationManagerAppService` | `String` | `ApplicationManagerAppServiceImpl` | Other:SingleRequest(getData) |
| `transfer` | `ApplicationManagerAppService` | `String` | `ApplicationManagerAppServiceImpl` | Other:SingleRequest(getData) |
| `copyLayoutAppAsync` | `AsyncAppService` | `ApplicationCopyDto` | `AsyncAppServiceImpl` | Util:Ids(uuidAbsLong) |
| `copyOnlyPageAppAsync` | `AsyncAppService` | `ApplicationCopyDto` | `AsyncAppServiceImpl` | Util:Ids(uuidAbsLong) |
| `transferAsync` | `AsyncAppService` | — | `AsyncAppServiceImpl` | Util:Asserts(notNull) |
| `copyEntity` | `InnerEntityAppService` | `EntityCopyDto` | `EntityAppServiceImpl` | Other:SingleRequest(getData) |
| `importExcel` | `UdcEnumItemAppService` | `ExcelImportTransDto` | `UdcEnumItemAppServiceImpl` | Service:UdcEnumItemService(importEntityInitData) |
| `exportApprovalFrameInfo` | `ApprovalFrameApiTransportAppService` | `ApprovalFrameParamDto` | `ApprovalFrameApiTransportAppServiceImpl` | 见 flow 文件 |
| `exportTemplateInfo` | `BpmApiTransportAppService` | `BpmInitDataDto` | `BpmApiTransportAppServiceImpl` | 见 flow 文件 |
| `importTemplateInfo` | `BpmApiTransportAppService` | `BpmImportDto` | `BpmApiTransportAppServiceImpl` | 见 flow 文件 |
| `transportIn` | `CdpBiz4UdcAppService` | `String` | `CdpBiz4UdcAppServiceImpl` | 见 flow 文件 |
| `transportInV2` | `CdpBiz4UdcAppService` | `String` | `CdpBiz4UdcAppServiceImpl` | 见 flow 文件 |
| `transportOut` | `CdpBiz4UdcAppService` | `TransportOutRequestDto` | `CdpBiz4UdcAppServiceImpl` | 见 flow 文件 |
| `transportOutV2` | `CdpBiz4UdcAppService` | `TransportOutRequestDto` | `CdpBiz4UdcAppServiceImpl` | 见 flow 文件 |
| `exportExcel` | `ExcelSmsImportAndExportAppService` | `ExcelSheetEnum` | `ExcelSmsImportAndExportAppServiceImpl` | 见 flow 文件 |
| `exportExcelTemplate` | `ExcelSmsImportAndExportAppService` | `ExcelSheetEnum` | `ExcelSmsImportAndExportAppServiceImpl` | 见 flow 文件 |
| `importExcel` | `ExcelSmsImportAndExportAppService` | `ExcelSmsImportDto` | `ExcelSmsImportAndExportAppServiceImpl` | 见 flow 文件 |
| `exportEntityTask` | `LinkerMigrationAppService` | `LinkMigrationRequestDto` | `LinkerMigrationAppServiceImpl` | 见 flow 文件 |
| `importConnectorData` | `LinkerMigrationAppService` | `ConnectorMigrateImportResponseDto` | `LinkerMigrationAppServiceImpl` | 见 flow 文件 |
| `exportPortalDesignInfo` | `PortalSetAppService` | `Long` | `PortalSetAppServiceImpl` | 见 flow 文件 |
| `importPortalDesignInfo` | `PortalSetAppService` | `PortalImportParamDto` | `PortalSetAppServiceImpl` | 见 flow 文件 |
| `transportIn` | `ScalabilityFieldAppService` | — | `ScalabilityFieldAppServiceImpl` | 见 flow 文件 |
| `exportSignByConditions` | `ShortMessageSignAppService` | — | `ShortMessageSignAppServiceImpl` | 见 flow 文件 |

## 校验（41）

| 动作方法 | 接口 | 入参 DTO | 实现 | 流转（第一步） |
|---|---|---|---|---|
| `checkDesignModifiedAfterLastRelease` | `ApplicationAppService` | — | `ApplicationAppServiceImpl` | Service:ApplicationService(checkDesignModifiedAfterLastRelease) |
| `detectionByAppId` | `ApplicationAppService` | `Long` | `ApplicationAppServiceImpl` | Other:SingleRequest(getData) |
| `checkExists` | `DataTransferObjectAppService` | — | `DataTransferObjectAppServiceImpl` | Service:DataTransferObjectService(selectByIds) |
| `check` | `UdcLateralAuthCheckAppService` | `UdcLateralCheckDto` | `UdcLateralAuthCheckAppServiceImpl` | Service:ApplicationService(selectByAppName) |
| `hasAgent` | `AgentCommonAppService` | `AgentParamDto` | `AgentCommonAppServiceImpl` | 见 flow 文件 |
| `exist` | `AppDraftAppService` | `String` | `AppDraftAppServiceImpl` | 见 flow 文件 |
| `check` | `AppManageCoreAppService` | `AppCheckRequestDto` | `AppsAppServiceImpl` | 见 flow 文件 |
| `checkFormPermissionBatch` | `BpmApiFormPermissionAppService` | — | `BpmApiFormPermissionAppServiceImpl` | 见 flow 文件 |
| `checkApplicationPermission` | `BpmApiPermissionAppService` | — | `BpmApiPermissionAppServiceImpl` | 见 flow 文件 |
| `check` | `BpmAppService` | `SecurityCheckDto` | `BpmApiAppServiceImpl` | 见 flow 文件 |
| `hasten` | `BpmAppService` | `BpmHastenDto` | `BpmApiAppServiceImpl` | 见 flow 文件 |
| `hasDesignTemplateByEntityName` | `BpmTemplateAppService` | `String` | `BpmTemplateAppServiceImpl` | 见 flow 文件 |
| `checkFeatureByEnum` | `CapabilityManageAppService` | `CapabilityEnum` | `CapabilityManageAppServiceImpl` | 见 flow 文件 |
| `checkCategoryBatch` | `CategoryCommonAppService` | — | `CategoryCommonAppServiceImpl` | 见 flow 文件 |
| `detectionPartEntityForDataset` | `CdpBiz4UdcAppService` | `CdpDetectionEntityDto` | `CdpBiz4UdcAppServiceImpl` | 见 flow 文件 |
| `detectionPartEntityForStream` | `CdpBiz4UdcAppService` | `CdpDetectionEntityDto` | `CdpBiz4UdcAppServiceImpl` | 见 flow 文件 |
| `detectionPartIndicatorForTable` | `CdpBiz4UdcAppService` | `CdpDetectionIndicatorRequestDto` | `CdpBiz4UdcAppServiceImpl` | 见 flow 文件 |
| `detectionPartModelForIndicator` | `CdpBiz4UdcAppService` | `CdpDetectionModelRequestDto` | `CdpBiz4UdcAppServiceImpl` | 见 flow 文件 |
| `detectionPartModelForReport` | `CdpBiz4UdcAppService` | `CdpDetectionModelRequestDto` | `CdpBiz4UdcAppServiceImpl` | 见 flow 文件 |
| `detectionPartModelForStream` | `CdpBiz4UdcAppService` | `CdpDetectionModelRequestDto` | `CdpBiz4UdcAppServiceImpl` | 见 flow 文件 |
| `detectionV2` | `CdpBiz4UdcAppService` | `ValidationParamsDto` | `CdpBiz4UdcAppServiceImpl` | 见 flow 文件 |
| `hasRepeatName` | `CtpLoginPreConfigAppService` | `CtpLoginPreConfigDto` | `CtpLoginPreConfigAppServiceImpl` | 见 flow 文件 |
| `checkOrgAdminPermission` | `CtpUserPermissionCommonAppService` | `CheckOrgAdminPermissionDto` | `CtpUserPermissionCommonAppServiceImpl` | 见 flow 文件 |
| `checkUserAppPermission` | `CtpUserPermissionCommonAppService` | `CtpUserAppPermissionDto` | `CtpUserPermissionCommonAppServiceImpl` | 见 flow 文件 |
| `checkUserResource` | `CtpUserPermissionCommonAppService` | — | `CtpUserPermissionCommonAppServiceImpl` | 见 flow 文件 |
| `checkUserResourceCode` | `CtpUserPermissionCommonAppService` | `CtpUserResourceSearchDto` | `CtpUserPermissionCommonAppServiceImpl` | 见 flow 文件 |
| `hasAdminRole` | `CtpUserPermissionCommonAppService` | `Long` | `CtpUserPermissionCommonAppServiceImpl` | 见 flow 文件 |
| `hasRoleByOrgCode` | `CtpUserRoleCommonAppService` | `HasRoleByOrgCodeSearchDto` | `CtpUserRoleCommonAppServiceImpl` | 见 flow 文件 |
| `check` | `DataTransferObjectAppService` | — | `DataTransferObjectAppServiceImpl` | 见 flow 文件 |
| `checkAndEncrypt` | `DocOnlineAppService` | `DocEncryptFileRequestDto` | `DocOnlineAppServiceImpl` | 见 flow 文件 |
| `checkContent` | `DocOnlineAppService` | `DocCheckContentRequestDto` | `DocOnlineAppServiceImpl` | 见 flow 文件 |
| `checkSensitiveWord` | `IntelligentMissiveAppService` | `SensitiveWordReqDto` | `IntelligentMissiveAppServiceImpl` | 见 flow 文件 |
| `checkUserExecutiveHide` | `OrgInstitutionExecutiveAppService` | — | `OrgInstitutionExecutiveAppServiceImpl` | 见 flow 文件 |
| `checkSelectPeopleData` | `OrgWorkFlowAppService` | — | `OrgWorkFlowAppServiceImpl` | 见 flow 文件 |
| `detection` | `PortalSetAppService` | `PortalDetectionRequestDto` | `PortalSetAppServiceImpl` | 见 flow 文件 |
| `checkSealPassword` | `SealCommonAppService` | `SealPasswordCheckDto` | 平台服务端 | — |
| `checkRepeatSignName` | `ShortMessageSignAppService` | `RepeatSignRequestDto` | `ShortMessageSignAppServiceImpl` | 见 flow 文件 |
| `checkTemplateCode` | `ShortMessageTemplateAppService` | `RepeatTemplateCodeRequestDto` | `ShortMessageTemplateAppServiceImpl` | 见 flow 文件 |
| `verifySeal` | `SignatureAppService` | `VerifySealDto` | `SignatureAppServiceImpl` | 见 flow 文件 |
| `verifySignature` | `SignatureAppService` | `VerifySignatureDto` | `SignatureAppServiceImpl` | 见 flow 文件 |
| `checkPermissionByUser` | `ThirdPermissionAppService` | `ThirdCheckResourcePermissionDto` | 平台服务端 | — |

## 启用禁用（11）

| 动作方法 | 接口 | 入参 DTO | 实现 | 流转（第一步） |
|---|---|---|---|---|
| `startArchiving` | `ArchivesAppService` | `ArchivingInfoWrapperDto` | `ArchivesAppServiceImpl` | 见 flow 文件 |
| `pause` | `BpmAppService` | `BpmPauseDto` | `BpmApiAppServiceImpl` | 见 flow 文件 |
| `start` | `BpmTemplateAppService` | `String` | `BpmTemplateAppServiceImpl` | 见 flow 文件 |
| `startByTemplateId` | `BpmTemplateAppService` | `BpmStartTemplateDto` | `BpmTemplateAppServiceImpl` | 见 flow 文件 |
| `startByTemplateIdWithoutAuth` | `BpmTemplateAppService` | `BpmStartTemplateDto` | `BpmTemplateAppServiceImpl` | 见 flow 文件 |
| `startCheck` | `BpmTemplateAppService` | `BpmStartTemplateDto` | `BpmTemplateAppServiceImpl` | 见 flow 文件 |
| `startByAppName` | `BpmTemplateManageAppService` | `BpmAppInfoDto` | `BpmTemplateManageAppServiceImpl` | 见 flow 文件 |
| `enableRule` | `DeductionRtRuleAppService` | `Long` | `DeductionRtRuleAppServiceImpl` | 见 flow 文件 |
| `disableMember` | `OrgMemberSyncAppService` | `String` | `OrgMemberSyncAppServiceImpl` | 见 flow 文件 |
| `disableMemberByThirdIds` | `OrgMemberSyncAppService` | `String` | `OrgMemberSyncAppServiceImpl` | 见 flow 文件 |
| `disableOrganization` | `OrgUnitSyncAppService` | `OrgDisableUnitDto` | `OrgUnitSyncAppServiceImpl` | 见 flow 文件 |

## 查询（1198）

查询类 1197 个方法太碎，按接口聚合（完整签名去 `packages/` 查）：

| 接口 | 方法数 | 方法 |
|---|---|---|
| `DesignMetadataQueryAppService` | 49 | `selectServiceMetadata`, `selectEntityMetadata`, `selectEntityMetadataExcludeBoot`, `selectEntityMetadataByFullName`, `selectEntityMetadataByFullNames`, `selectAggMetadata` … 另 43 |
| `OrgCommonAppService` | 40 | `selectMemberInfoById`, `selectMemberDepartmentInfoById`, `selectMemberMultiDimOrgInfo`, `selectMemberInstitutionInfoById`, `selectMemberBySelectPeopleData`, `selectPageMemberBySelectPeopleData` … 另 34 |
| `UdcMetaDataAppService` | 32 | `selectAppMetaData4PageCode`, `selectAvailableUpgradeAppMetadataById`, `selectPageAvailableAppMetaDataByCondition`, `selectPageAvailableAppMultiVersionMetaDataByCondition`, `selectReferMetaDataByEntity`, `selectCustomReferMetaDataByPageId` … 另 26 |
| `BpmTemplateAppService` | 30 | `selectByApplicationName`, `selectById`, `selectTemplateListByCondition`, `selectByTemplateUrlId`, `selectEffectedDiagramListByAppName`, `selectTemplateUserGuidInfo` … 另 24 |
| `OrgWorkFlowAppService` | 29 | `selectMemberPostBySelectPeople`, `selectMemberPostBySelectPeoples`, `selectMemberPostBySelectPeoplesReturnFile`, `selectReturnFileByKey`, `selectListByCondition`, `selectListByMetaCondition` … 另 23 |
| `CapabilityManageAppService` | 28 | `selectPageByConditions`, `selectProvidersByEnum`, `selectEnableProvidersByEnum`, `selectProvidersListByEnum`, `selectOptionalProvider`, `selectActiveXFunctionByEnum` … 另 22 |
| `EnterpriseCreditAppService` | 25 | `pageEnterpriseInfo`, `getBasicBusinessInfo`, `pageEnterpriseInfo`, `getBasicInfo`, `getPartners`, `getCourtNotice` … 另 19 |
| `AffairCommonAppService` | 24 | `selectAffairById`, `selectListByCondition`, `countAffairByConditions`, `selectAffairSimpleById`, `selectAffairSimpleByIds`, `selectAffairSimpleListByCondition` … 另 18 |
| `ApplicationAppService` | 21 | `selectPageByConditions`, `selectAppPageByConditions`, `selectAppPageByConditionsWithVersion`, `selectAppPageByGuid`, `selectTemplateAppPageByConditions`, `selectById` … 另 15 |
| `OcrAppService` | 18 | `getIdCardFrontData`, `getIdCardBackData`, `getBankCardData`, `getBusinessCardData`, `getBusinessLicenseData`, `getTaxInvoiceData` … 另 12 |
| `BpmCaseAppService` | 16 | `selectCaseById`, `selectMainCaseBySubCaseId`, `selectById`, `selectByIds`, `selectBpmCaseByFormRecordId`, `selectByPageCondition` … 另 10 |
| `OrgUnitBaseAppService` | 16 | `selectById`, `selectByIds`, `selectOrgById`, `selectOrgByIds`, `selectCascadeById`, `selectCascadeByIds` … 另 10 |
| `OrgMetadataCoreAppService` | 16 | `selectOrgMetadataColumnListByCondition`, `selectMetadataColumnList`, `selectPageMetadataColumnList`, `selectOrgByUnitMemberMetadata`, `selectMemberByUnitMetadata`, `selectMemberByUnitMemberMetadata` … 另 10 |
| `ApplicationManagerAppService` | 15 | `selectById`, `selectCollaborationRecordsByAppId`, `selectLatestDesignAppByGuid`, `selectLatestDesignAppWithMemberByGuid`, `selectAppNameAndIdMapByAppNames`, `selectDesignAppByGuid` … 另 9 |
| `UdcCtpEnumAppService` | 15 | `selectCategoryByAppGuid`, `selectCategoryAndEnum`, `selectCtpEnum`, `selectCtpEnumByIds`, `selectParentByCode`, `selectListByConditionsNoLevel` … 另 9 |
| `CtpUserPermissionCommonAppService` | 14 | `selectUserResourceCode`, `selectUserResourceCodesMap`, `selectUserResource`, `selectUserResourceProperties`, `selectUserResource`, `selectControlMenus` … 另 8 |
| `EntityAppService` | 14 | `selectById`, `selectByIds`, `selectByName`, `selectPageByCondition`, `selectListByConditions`, `selectListByTerm` … 另 8 |
| `CtpSecretCommonAppService` | 13 | `selectSecretEnable`, `selectSecretLevelEnumItem`, `selectOrgSecretLevelEnumItem`, `selectSecretLevelEnumItemList`, `selectSecretLevelEnumItemByValue`, `selectSecretLevelEnumItemByOrderNo` … 另 7 |
| `OrgMemberBaseAppService` | 13 | `selectById`, `selectByIds`, `selectCascadeById`, `selectCascadeByIds`, `selectListByConditions`, `selectMemberListByCondition` … 另 7 |
| `OrgUnitCoreAppService` | 13 | `selectOrgById`, `selectOrgInfoById`, `selectOrgByIds`, `selectOrgByIdsIgnoreTenantId`, `selectOrgInfoByIds`, `selectOrgListByCondition` … 另 7 |
| `IntelligentMissiveAppService` | 12 | `queryExtractingDetail`, `queryDiffRule`, `queryDocDiffPage`, `queryDocDiffDetail`, `queryDocDiffView`, `queryCardRule` … 另 6 |
| `OrgMemberCoreAppService` | 12 | `selectMemberById`, `selectMemberInfoById`, `selectMemberByIds`, `selectMemberByIdsIgnoreTenantId`, `selectMemberInfoByIds`, `selectMemberListByCondition` … 另 6 |
| `WorktimeAppService` | 11 | `selectWorktimeByOrgIdAndYear`, `selectByOrgIdAndYear`, `getByParentOrgIdAndYear`, `getWorkTimeByYear`, `getWorkTimeBetweenYear`, `getWorkTimeBetweenDate` … 另 5 |
| `BpmApiFormPermissionAppService` | 11 | `selectByTemplateId`, `selectById`, `selectPermissionIncludeContentById`, `selectByApplicationName`, `selectThirdPermissionByTemplateId`, `selectByIds` … 另 5 |
| `OrgMemberRoleBaseAppService` | 10 | `selectById`, `selectByIds`, `selectCascadeById`, `selectCascadeByIds`, `selectListByConditions`, `selectListByCondition` … 另 4 |
| `OrgJobBaseAppService` | 10 | `selectById`, `selectByIds`, `selectCascadeById`, `selectCascadeByIds`, `selectListByConditions`, `selectPageByConditions` … 另 4 |
| `OrgPostBaseAppService` | 10 | `selectById`, `selectByIds`, `selectCascadeById`, `selectCascadeByIds`, `selectListByConditions`, `selectPageByConditions` … 另 4 |
| `OrgRoleBaseAppService` | 10 | `selectById`, `selectByIds`, `selectCascadeById`, `selectCascadeByIds`, `selectListByConditions`, `selectListByCondition` … 另 4 |
| `OrgLevelBaseAppService` | 10 | `selectById`, `selectByIds`, `selectCascadeById`, `selectCascadeByIds`, `selectListByConditions`, `selectPageByConditions` … 另 4 |
| `DataTransferObjectAppService` | 10 | `selectById`, `selectDtoWithAttrsById`, `selectPageByConditions`, `selectListByConditions`, `selectDtoWithAttrsAndRefDtos`, `selectListBySourceId` … 另 4 |
| `LinkerAppService` | 9 | `selectPageByCondition`, `selectAll`, `selectDetailsByInfoId`, `selectLinkerDetailParameterDisplay`, `selectEventDetailsByInfoId`, `selectEventDetailById` … 另 3 |
| `OrgIntegrationAppService` | 9 | `queryCardInfo`, `queryServiceTypeInfo`, `queryJsApiAddressByCode`, `queryCardRunInfo`, `queryCardShowInfo`, `queryCardShowIsCustomAvatar` … 另 3 |
| `OrgPortalAppService` | 9 | `selectSwitchInstitution`, `selectSwitchInstitutions`, `selectSwitchInstitutionByMemberId`, `selectLoginUserInfo`, `selectCurrentLoginUserInfo`, `selectMainMemberPostByMemberId` … 另 3 |
| `DocOnlineAppService` | 8 | `getOfficeViewUrl`, `getCompositeViewUrl`, `getLatestPicViewUrl`, `getOfficeEditUrl`, `getLatestDocFileInfoByStorageKey`, `selectDocFileVersionPage` … 另 2 |
| `CtpApplicationCommonAppService` | 8 | `selectCategoryApplications`, `selectCategorySetting`, `selectApplicationsByCategoryAndClientScope`, `selectAdminAppIdsByUserIdAndOrgId`, `selectEnabledApplications`, `selectUserMenuAndPortal` … 另 2 |
| `CtpUserCoreAppService` | 8 | `selectById`, `selectByIds`, `selectSimpleByIds`, `selectOneByCondition`, `selectListByConditions`, `selectPageByConditions` … 另 2 |
| `CtpOrgAdminOrgAppService` | 8 | `selectByOrgId`, `selectByOrgIds`, `selectByUserId`, `selectPageByConditions`, `selectListByConditions`, `selectManageScopeByOrgAndUser` … 另 2 |
| `OrgUnitVerticalBaseAppService` | 8 | `selectById`, `selectByIds`, `selectCascadeById`, `selectCascadeByIds`, `selectListByConditions`, `selectPageByConditions` … 另 2 |
| `OrgBusinessBaseAppService` | 8 | `selectById`, `selectByIds`, `selectCascadeById`, `selectCascadeByIds`, `selectListByConditions`, `selectPageByConditions` … 另 2 |
| `OrgMemberPostBaseAppService` | 8 | `selectById`, `selectByIds`, `selectCascadeById`, `selectCascadeByIds`, `selectListByConditions`, `selectPageByConditions` … 另 2 |
| `AttributeSetAppService` | 8 | `selectById`, `selectByIds`, `selectByName`, `selectListByConditions`, `selectListByAppId`, `selectListByNames` … 另 2 |
| `AttributeAppService` | 8 | `selectById`, `selectPageByCondition`, `selectListByCondition`, `selectListByTerm`, `selectAllAttributeByEntityId`, `selectEntityAttributeList` … 另 2 |
| `CategoryCommonAppService` | 7 | `selectById`, `selectListByConditions`, `selectTreeByIds`, `selectChildrenById`, `selectChildrenByCode`, `getCategoryDataInitResult` … 另 1 |
| `BaseConfigAppService` | 7 | `selectDatabaseById`, `selectDatabaseByIds`, `selectPageDatabaseByCondition`, `selectAllDatabaseType`, `selectAllTableInfo`, `selectAllTableNameById` … 另 1 |
| `AffairOpenAppService` | 7 | `selectPageByCondition`, `selectByConditionIgnoreTenant`, `selectActivityUnprocessedMember`, `selectSpecifyActivityUnprocessedMember`, `selectNodePermissionPageByCondition`, `selectCategoryByCondition` … 另 1 |
| `CtpRoleCoreAppService` | 7 | `selectById`, `selectByCode`, `selectByIds`, `selectListByConditions`, `selectPageByConditions`, `selectCascadeById` … 另 1 |
| `CtpAuthCoreAppService` | 7 | `getLoginUserInfo`, `getPcUserInfo`, `selectTenantList`, `getAccessToken`, `selectTenantListByUserId`, `selectTicketByToken` … 另 1 |
| `OrgMemberSyncAppService` | 7 | `selectByCodes`, `selectByThirdIds`, `selectByCondition`, `selectNaturalMemberByPhoneNumber`, `selectNaturalMemberByCodes`, `selectNaturalMemberInfoPageListByCondition` … 另 1 |
| `DataTypeAppService` | 7 | `getAll`, `selectBaseDataTypes`, `selectParameterDataTypes`, `selectDataTypeByName`, `selectDataTypeByAppId`, `selectDataTypeByParams` … 另 1 |
| `AgentCoreAppService` | 6 | `selectListByCondition`, `selectById`, `selectByIds`, `selectPageByCondition`, `selectBizAgentPageByCondition`, `getAgentProperties` |
| `BpmApiNodePermissionAppService` | 6 | `selectNodePermissionById`, `selectNodePermissionListByIds`, `queryPermissionList`, `selectNodePermissionDetailListByIds`, `selectNodePermissionListByConditions`, `getMaxOrderNumber` |
| `ShortMessageTemplateAppService` | 6 | `selectTemplateById`, `selectTemplateByCode`, `selectPageStoreLibrary`, `selectPageByConditions`, `selectTemplateTypeListByConditions`, `getLanguage` |
| `MappingDetailAppService` | 6 | `queryUserMappingDetail`, `queryOrgMappingDetail`, `getOrgInnerIdByOuterId`, `getOrgOuterIdByInnerId`, `getUserInnerIdByOuterId`, `getUserOuterIdByInnerId` |
| `CtpApplicationAuthCoreAppService` | 6 | `selectApplicationAuthByAppId`, `selectAuthAppIdsByOrgId`, `selectAuthAppIds`, `selectWithOutAuthAllAppIdsByOrgId`, `selectApplicationByAuthedOrg`, `selectPageApplicationByAuthedOrg` |
| `CtpUserBindMappingAppService` | 6 | `selectOneByCondition`, `selectListByConditions`, `pageUserMappingByUserIds`, `listUserMappingByUserIds`, `listUserMappingForPending`, `selectPageByConditions` |
| `CtpAuthorizationRuleOrgAppService` | 6 | `selectPageByConditions`, `selectAuthorizationObject`, `selectAuthorizationEntity`, `selectAuthorizationFuncList`, `selectAuthorizationFuncListByRole`, `selectDuplicateRolesRule` |
| `OrgJobCoreAppService` | 6 | `selectJobById`, `selectJobByIds`, `selectJobListByCondition`, `selectJobPageListByCondition`, `selectJobListPropertiesByJobIds`, `selectJobPageListPropertiesByCondition` |
| `OrgPostCoreAppService` | 6 | `selectPostById`, `selectPostByIds`, `selectPostListByCondition`, `selectPostPageListByCondition`, `selectPostListPropertiesByPostIds`, `selectPostPageListPropertiesByCondition` |
| `OrgLevelCoreAppService` | 6 | `selectLevelById`, `selectLevelByIds`, `selectLevelListByCondition`, `selectLevelPageListByCondition`, `selectLevelListPropertiesByLevelIds`, `selectLevelPageListPropertiesByCondition` |
| `UdcCtpEnumProxyAppService` | 6 | `selectOneByIdAndApp`, `selectByEnumCodeAndAppGuid`, `selectByEnumCodesAndAppGuid`, `selectCascadeTreeByEnumCode`, `selectByEnumItemByDependentApp`, `selectByEnumItemByDependentApp` |
| `AgentCommonAppService` | 5 | `selectByAgentUserId`, `selectByUserIdAndTemplate`, `selectById`, `selectListByConditions`, `selectEffectiveAgentList` |
| `BpmApiParamAppService` | 5 | `loadParamSchema`, `loadParamTypes`, `loadParamSchemaByOrigin`, `selectParameterUsedByTemplateId`, `selectUsedParameterPathName` |
| `IndexAppService` | 5 | `search`, `searchHistory`, `selectById`, `selectByEntityId`, `selectMatchesAttributeByEntityId` |
| `MobilePluginConfigAppService` | 5 | `selectOneByConditions`, `selectById`, `getWorkWxAccessMode`, `getPlatformTypeList`, `selectOneByConditionsIgnoreTenant` |
| `VideoMeetingAppService` | 5 | `getMeetingDetail`, `selectVideoMeetingRoom`, `selectMemberMeetingRoom`, `getEndedMeetingDetail`, `getMeetingRecord` |
| `InvoiceAppService` | 5 | `getOcrInvoiceData`, `getOcrAsyncResult`, `getOcrInvoiceSingle`, `queryOcrPage`, `queryCheckPage` |
| `SignatureAppService` | 5 | `getSignatureViewUrl`, `getSealInfo`, `selectPageByConditions`, `getTemplateContents`, `querySsoUrl` |
| `OrgUnitSyncAppService` | 5 | `selectByCodes`, `selectByThirdIds`, `selectChildrenByCondition`, `selectPageChildrenByCondition`, `selectPageByConditions` |
| `OrgMemberPostCoreAppService` | 5 | `selectMemberPostListByCondition`, `selectMemberPostListByMemberIds`, `selectMemberPostPageListByCondition`, `selectMemberPostListPropertiesByMemberIds`, `selectMemberPostPageListPropertiesByCondition` |
| `OrgSystemTeamCoreAppService` | 5 | `selectTeamMemberByTeamId`, `selectTeamMemberByTeamIds`, `selectTeamById`, `selectTeamByIds`, `selectTeamByCondition` |
| `OrgUnitTeamCoreAppService` | 5 | `selectUnitTeamById`, `selectUnitTeamByIds`, `selectUnitTeamListByCondition`, `selectUnitTeamPageListByCondition`, `selectSortId` |
| `UdcSandBoxAppService` | 5 | `search`, `searchDetails`, `searchDetails4FlowLog`, `searchPageLog`, `searchPageLogNonMetadata` |
| `UdcEnumItemAppService` | 5 | `selectPageByConditions`, `selectListByConditions`, `selectById`, `selectByEnumId`, `selectListByTerm` |
| `EventAppService` | 5 | `selectPageByConditions`, `selectListByConditions`, `selectById`, `selectBusinessEvent`, `selectEvents` |
| `I18nLocaleAppService` | 4 | `getEnableLocalesMap`, `getTenantDefaultLocale`, `getSystemDataI18nLocaleList`, `getTenantDataI18nLocaleList` |
| `BpmNodeAppService` | 4 | `selectPageByConditions`, `selectByTemplateAndActivityType`, `selectRunningProcessPreNode`, `selectNodePolicy` |
| `BpmProcessLogAppService` | 4 | `selectLogList`, `selectOriginalI18nLogList`, `selectLogOriginalListByCaseIds`, `selectPageByConditions` |
| `OfdAppService` | 4 | `getOfdViewUrl`, `getSealInfo`, `getSealList`, `getOfdMetaData` |
| `PhysicalSealAppService` | 4 | `queryApplyRecord`, `querySeals`, `getImageByApplyId`, `getImage` |
| `ShortMessageSignAppService` | 4 | `selectRecentTimeSign`, `selectValidSign`, `selectPageSignByConditions`, `selectSignById` |
| `ApplicationAffairAppService` | 4 | `queryExternalIdByAffair`, `listExternalIdsByAffairIds`, `queryAffairByExternalId`, `queryAffairListByExternalIdList` |
| `MiddleTableAppService` | 4 | `queryUnit`, `queryLevel`, `queryPost`, `queryMember` |
| `MiddleTableOperationAppService` | 4 | `queryUnit`, `queryLevel`, `queryPost`, `queryMember` |
| `CtpUserRoleCoreAppService` | 4 | `selectListByConditions`, `selectEntityRoleListByConditions`, `selectPageByConditions`, `selectCtpEntityRolePageByConditions` |
| `CtpThirdPlatformConfigCoreAppService` | 4 | `selectById`, `selectOneByConditions`, `selectListByConditions`, `selectPageByConditions` |
| `CtpUserCommonAppService` | 4 | `getUserInfo`, `selectUserByLoginName`, `getLoginPageSetParameter`, `getRecentUserId` |
| `CtpUserRoleCommonAppService` | 4 | `selectUserByRoleCode`, `selectPageUserByRoleCode`, `selectUserByRoleCodeSearch`, `selectUserIdByRoleCode` |
| `CtpManagerTenantAppService` | 4 | `selectByUseTenantId`, `selectByUseTenantCode`, `selectStatusByUseTenantId`, `selectInitStatus` |
| `OrgMemberRoleCoreAppService` | 4 | `selectById`, `selectByIds`, `selectListByConditions`, `selectPageByConditions` |
| `OrgRoleCoreAppService` | 4 | `selectById`, `selectByIds`, `selectListByConditions`, `selectPageByConditions` |
| `UdcEnumCategoryAppService` | 4 | `selectPageByConditions`, `selectListByConditions`, `selectById`, `selectCategoryAndEnum` |
| `UdcEnumAppService` | 4 | `selectPageByConditions`, `selectListByConditions`, `selectById`, `selectListByTerm` |
| `ScalabilityOptionAppService` | 4 | `selectById`, `selectByAppId`, `selectByAppIdWithDetail`, `selectAllOptionName` |
| `UdcSerialSchemeAppService` | 4 | `selectSerialScheme`, `selectSerialSchemeById`, `selectSerialRange`, `selectDepAppSerialScheme` |
| `ScalabilityFieldAppService` | 4 | `selectMetadataExtEntityTree`, `listExtFileds`, `selectAvailableDatatype`, `selectAttribute` |
| `DataFlowMappingAppService` | 4 | `selectOriginalMappingList`, `selectById`, `selectMappingInitData`, `selectDetailByCondition` |
| `AttributeSnapshotAppService` | 4 | `selectByDataId`, `selectByDataIds`, `selectByMasterDataId`, `selectByMasterDataIds` |
| `AssociateCommonAppService` | 3 | `selectEntityConfigByConditions`, `selectAssociateCompleteByAppName`, `selectAssociateCompleteByControlCodes` |
| `MyAttentionCommonAppService` | 3 | `getAttentionByObjectIds`, `getAttentionUserIdsByObjectIds`, `selectPageByConditions` |
| `SystemConfigCommonAppService` | 3 | `getI18nConfig`, `getSystemConfig`, `getLocaleParameterByUserIds` |
| `CtpQrCodeRuleUdcAppService` | 3 | `getRuleListByAppIdAndFullNames`, `getRuleListByAppIdAndFieldCodes`, `getRuleListByAppId` |
| `BpmTemplateManageAppService` | 3 | `selectFormalAuthTemplateList`, `selectFormalAuthTemplateListByQueryDto`, `selectGrayAuthTemplateList` |
| `BpmApiTransportAppService` | 3 | `getApplicationInitData`, `getApplicationInitDataAsync`, `selectUsedConnectorByAppName` |
| `VoiceAppService` | 3 | `queryVoiceFileResult`, `queryConvertWordsResult`, `queryIntelligentDigestResult` |
| `LocationAppService` | 3 | `getLocation`, `getDistance`, `getJsApiInfo` |
| `PayAppService` | 3 | `queryTransactionByOutTradeNo`, `queryRefund`, `getCert` |
| `EmailPrivateAppService` | 3 | `getCompanySystemEmail`, `selectEmailTemplate`, `getEmailLimit` |
| `CapabilityAccessLogDbAppService` | 3 | `selectById`, `selectPageByConditions`, `countByConditions` |
| `OpenCapabilityAppService` | 3 | `queryUseCount`, `getTicket`, `getAppUrl` |
| `AffairCategoryAppService` | 3 | `getAllAppAndSubAppInfoRegisterAffair`, `searchAffairCategory`, `selectAffairCountForBadgeWithMergeTenants` |
| `CtpMessageManageAppService` | 3 | `selectBySetType`, `selectListByUserId`, `getMessageNumber` |
| `CtpApplicationCoreAppService` | 3 | `selectListByConditions`, `selectPageByConditions`, `selectAppStatusListIgnoreTenantId` |
| `CtpResourceCoreAppService` | 3 | `selectByCode`, `selectListByConditions`, `selectPageByConditions` |
| `CtpUserDefaultIdentityCommonAppService` | 3 | `selectDefaultSwitchAdminOrg`, `selectUDefaultseIdentityInfo`, `selectFrontUserDefaultTenant` |
| `OrgLevelSyncAppService` | 3 | `selectByCodes`, `selectPageByConditions`, `selectByThirdIds` |
| `OrgPostSyncAppService` | 3 | `selectByCodes`, `selectPageByConditions`, `selectByThirdIds` |
| `OrgJobSyncAppService` | 3 | `selectByCodes`, `selectPageByConditions`, `selectByThirds` |
| `PortalShortcutAppService` | 3 | `selectById`, `selectListByConditions`, `selectByIds` |
| `ReferConfigAppService` | 3 | `selectById`, `selectPageByCondition`, `selectListByCondition` |
| `ParameterAppService` | 3 | `selectById`, `selectByIds`, `selectPageByCondition` |
| `EventWithDataAppService` | 3 | `selectWithEventData`, `selectListWithDataByConditions`, `selectListWithDataByTerm` |
| `DtoAttributeAppService` | 3 | `selectById`, `selectPageByConditions`, `selectListByConditions` |
| `QueryAppService` | 3 | `selectByIds`, `selectById`, `selectByAppIdAndDeployType` |
| `AppCollaborationAppService` | 3 | `selectCollaborativeAppNames`, `selectCollaborativeGuid`, `selectAppMemberInfoListByAppIdList` |
| `PersonalPlanAppService` | 3 | `selectByCondition`, `selectListByCondition`, `selectPageByCondition` |
| `UdcSerialConfigAppService` | 3 | `selectListByConditions`, `selectEntityList`, `selectEntityBySerialId` |
| `ApprovalAppService` | 2 | `getApprovalPageSchemaAndPermissionByAffairId`, `getFormDataByGraphql` |
| `SealCommonAppService` | 2 | `selectUsableList`, `selectListByCondition` |
| `ImageStoreAppService` | 2 | `selectImageStore`, `selectStoreAndCategory` |
| `ImageCategoryAppService` | 2 | `selectImageCategory`, `selectCountByCategoryId` |
| `IntegralLedgerOprateAppService` | 2 | `selectPageByConditions`, `selectRankById` |
| `ThemeAppService` | 2 | `selectById`, `selectPagePropertiesByConditions` |
| `MgnAggDataInitAppService` | 2 | `selectListByConditions`, `selectListByMap` |
| `VideoMeetingRoomCommonAppService` | 2 | `selectById`, `selectAuthedVideoMeetingRoomList` |
| `InitMonitorAppService` | 2 | `selectAppStarterInitVersions`, `selectAppInitSingleDetails` |
| `LoadJarResourceAppService` | 2 | `getJsonMetadataData`, `getRuntimeJsonData` |
| `BpmAppService` | 2 | `selectFullCaseInfo`, `counterSignNode` |
| `BpmProcessTrackAppService` | 2 | `selectProcessTrackList`, `countAttentionForBadge` |
| `BpmNodePermissionOperationAppService` | 2 | `getNodePermissionOperation`, `selectOperationSimpleByPermissionIds` |
| `BpmWorkItemAppService` | 2 | `selectById`, `selectByCaseId` |
| `BpmActivityAppService` | 2 | `selectAllByCaseId`, `selectBpmCaseActivityByCaseId` |
| `BpmCaseLogAppService` | 2 | `selectByCaseId`, `selectByDto` |
| `BpmApiSimulationAppService` | 2 | `selectProcessPredictionResult`, `selectSimulationLinkByGuid` |
| `CdpBiz4UdcAppService` | 2 | `getReportList`, `getCdpDataIdList` |
| `CdpEtlSourceAppService` | 2 | `getSource`, `getDatasetPublishMetadata` |
| `IndicatorOpenApiAppService` | 2 | `getIndicatorModel`, `getIndicatorResult` |
| `ReportOpenApiAppService` | 2 | `getReportDetail`, `getReportResult` |
| `StreamOpenApiAppService` | 2 | `getStreamModel`, `getStreamResult` |
| `DatasetOpenApiAppService` | 2 | `getDatasetModel`, `getDatasetResult` |
| `MobilePluginAppletAppService` | 2 | `getAuditStatus`, `queryBindAuth` |
| `EmailAppService` | 2 | `findCipEmailUserAccount`, `selectPageEmailTemplate` |
| `WeatherAppService` | 2 | `getLocation`, `getWeather` |
| `SealAppService` | 2 | `listSeal`, `getSealDetails` |
| `ArchivesAppService` | 2 | `queryArchiveSystemCategory`, `selectAttributesByTypeIds` |
| `ShortMessageProviderTemplateAppService` | 2 | `selectTemplateContentById`, `selectTemplateContentByConditions` |
| `CapabilityEnumAppService` | 2 | `selectList`, `selectItemList` |
| `ApplicationPluginStatusAppService` | 2 | `selectStatusByPlugIds`, `selectStatusByLinkerIds` |
| `PluginStatusAppService` | 2 | `selectStatusByPlugIds`, `selectStatusByLinkerIds` |
| `AffairSuperviseAppService` | 2 | `selectPageByFixedTemplate`, `selectTemplateAffairPageData` |
| `CtpCategoryCoreAppService` | 2 | `selectListByConditions`, `selectQuickListByConditions` |
| `CtpLoginPreConfigAppService` | 2 | `selectByOrgId`, `selectByUri` |
| `CtpUserRoleAppService` | 2 | `selectCascadeById`, `selectCascadeByIds` |
| `CtpResourcePermissionCoreAppService` | 2 | `selectByResourceCode`, `selectListByConditions` |
| `CtpUserResourceCoreAppService` | 2 | `selectListByConditions`, `selectPageListByConditions` |
| `CtpPermissionApprovalOrgAppService` | 2 | `selectById`, `selectPageByConditions` |
| `CtpMenuCommonAppService` | 2 | `selectChildrenByCode`, `selectListByConditions` |
| `AppManageCoreAppService` | 2 | `getLatestDownloadUrl`, `getLatestApp` |
| `OrgTeamSyncAppService` | 2 | `selectByCode`, `selectPageByConditions` |
| `OrgMobileAppService` | 2 | `selectPagePhoneNumber`, `selectOfflineStorageKey` |
| `OrgAppCommonAppService` | 2 | `selectAccessViewMember`, `selectAccessViewOrg` |
| `OrgSelectPeopleForMemberAppService` | 2 | `searchMemberByGroup`, `selectMembersByOrg` |
| `OrgSelectPeopleForInstAppService` | 2 | `selectFirstChildrenUnits`, `searchInstitution` |
| `PortalSpaceAppService` | 2 | `selectDesignSpaceList`, `selectAllSectionsByUserIds` |
| `PortalSetAppService` | 2 | `selectRootOrgPortalSet`, `selectByIds` |
| `StereotypeAllAppService` | 2 | `getAll`, `get` |
| `InnerEntityAppService` | 2 | `selectEntitiesByEntityId4Tree`, `selectMasterEntityCount` |
| `ScalabilityAppService` | 2 | `selectById`, `selectByOptionId` |
| `EntityPresetAppService` | 2 | `selectPresetByEntityId`, `selectListByAppId` |
| `EntityGroupAppService` | 2 | `selectById`, `selectByAppId` |
| `FeatureAppService` | 2 | `list`, `listSystemAttributeNames` |
| `PreSetAttributeCapacityAppService` | 2 | `getAllPreSetAttributeCapacity`, `getPreSetAttributeCapacity` |
| `MicroFlowInfoAppService` | 2 | `findCallConnectorAppService`, `findCallIntegrationAppService` |
| `PluginPageInfoAppService` | 2 | `getResourceByCondition`, `getResource4UserCenter` |
| `CustomPlanAppService` | 2 | `selectBySourceIds`, `selectByComplexCondition` |
| `DataFlowMapAppService` | 2 | `selectByCondition`, `selectById` |
| `DeductionRtMapAppService` | 2 | `selectSimpleDeductionMap`, `selectById` |
| `DeductionRtRuleAppService` | 2 | `selectRtRuleVersion`, `selectById` |
| `FormAppService` | 2 | `loadForm`, `getHostAppDepends` |
| `StyleFileAppService` | 1 | `getCurrentTenantPortalFile` |
| `ImageAppService` | 1 | `selectImage` |
| `QrCodeCommonAppService` | 1 | `selectByJson` |
| `WaterMarkCommonAppService` | 1 | `getWaterMarkConfig` |
| `I18nResourceAppService` | 1 | `getTenantResourceDtoMap` |
| `BpmNormalAppMultiVersionAppService` | 1 | `selectCurrentHighestVersionBatch` |
| `BpmApplicationOperateLogAppService` | 1 | `selectNewestLogInfo` |
| `BpmApiPermissionAppService` | 1 | `getCurrentOrgHierarchicalAppGuid` |
| `BpmApiProcessAppService` | 1 | `selectDiagramDetailByTemplateCodeAndVersion` |
| `BpmCoMiAppService` | 1 | `getDetailInfo` |
| `BpmSuperviseAppService` | 1 | `search` |
| `BpmOpinionAppService` | 1 | `selectOpinionGroupByActivityNodeWithObjectId` |
| `BpmDetailAppService` | 1 | `selectDetail` |
| `BpmApiSplitImportAppService` | 1 | `selectTemplateByAppName` |
| `DocGeneralizeAppService` | 1 | `getAuthorityInfoProxy` |
| `MerchantAppService` | 1 | `selectPageMerchantByConditions` |
| `GisAppService` | 1 | `getToken` |
| `CompanyAccountServiceAppService` | 1 | `queryCompanyAccountInfo` |
| `SearchAppService` | 1 | `querySearchUrl` |
| `TranslationAppService` | 1 | `getLanguages` |
| `FaceIdAppService` | 1 | `getAccessToken` |
| `TokenAppService` | 1 | `selectTokenExpireTime` |
| `AiAppService` | 1 | `queryUsageAmount` |
| `ApplicationMobileAppService` | 1 | `getAppUrl` |
| `LinkerEnumAppService` | 1 | `selectItemList` |
| `LinkerMigrationAppService` | 1 | `listConnectorData` |
| `CipPlugCapabilityAppService` | 1 | `getAndCheckCapability` |
| `PluginAffairAppService` | 1 | `getExternalIdByAffairId` |
| `AffairNodePermissionAppService` | 1 | `selectPageByCondition` |
| `AffairDataScopeAppService` | 1 | `getDataScope` |
| `AffairUdcAppService` | 1 | `selectSpecifiedFieldValues` |
| `CtpCapabilityCoreAppService` | 1 | `selectListByConditions` |
| `CtpPersonalPlanCoreAppService` | 1 | `selectPageByConditions` |
| `CtpLoginLogCoreAppService` | 1 | `selectPageByConditions` |
| `CtpResourceTypeCoreAppService` | 1 | `selectListByConditions` |
| `CtpRoleResourceCoreAppService` | 1 | `selectResourceActionByRoleCodes` |
| `CtpSecretApprovalOrgAppService` | 1 | `selectPendingInfo` |
| `CtpOrgSelectPeopleAppService` | 1 | `selectPageByConditions` |
| `CtpAuthorizationUdcAppService` | 1 | `selectAppFirstLinks` |
| `CtpDeviceBindCommonAppService` | 1 | `selectByConditions` |
| `CtpResourceCommonAppService` | 1 | `selectDesignResources` |
| `CtpUserBpmAppService` | 1 | `selectUserResourceIgnoreTenant` |
| `OrgPlatformAppService` | 1 | `selectWatermarkInfoByMemberId` |
| `OrgAffairAppService` | 1 | `selectByIdOrCode` |
| `OrgEdocAppService` | 1 | `selectSortByIds` |
| `OrgUnitVerticalCoreAppService` | 1 | `selectUnitVerticalListByCondition` |
| `OrgBusinessCoreAppService` | 1 | `selectBusinessListByCondition` |
| `OrgSelectPeopleForDeptAppService` | 1 | `selectOrgPath` |
| `OrgParameterCoreAppService` | 1 | `selectValueByParamsKey` |
| `TenantManageAppService` | 1 | `selectEnableUnitNumIgnoreTenant` |
| `PortalPortletAppService` | 1 | `getPortalPortlet` |
| `EntityOpenApiAppService` | 1 | `selectOpenApiData` |
| `ReferConfigGroupAppService` | 1 | `selectListByConditions` |
| `AttributeGroupAppService` | 1 | `selectListByEntityId` |
| `StereotypeAppService` | 1 | `list` |
| `PageMetadataQuery4SfAppService` | 1 | `selectAppMetaDataByAppName` |
| `AsyncAppService` | 1 | `getRequestStatus` |
| `PageProcessEventAppService` | 1 | `selectListByCondition` |
| `UdcBpmAppService` | 1 | `selectDefaultLayoutAppName` |
| `ConsistenceDetectionAppService` | 1 | `selectDetectionListByAppId` |
| `UdcFunctionAppService` | 1 | `findMenuDefaultPage` |
| `UdcPortalSpaceAppService` | 1 | `selectDesignSpaceList` |
| `UdcRuleAppService` | 1 | `selectRuleByEntity` |
| `AppDraftAppService` | 1 | `select` |

## 怎么用

```
① 我要做某件事 → 在本文件找对应动作分组
② 找到入口方法 → 记下接口名和入参 DTO
③ DTO 有什么字段 → dto-fields/<域>.md
④ 背后发生什么 → service-flow-20261103/<构件>.md 搜那个实现类
⑤ 完整签名 → packages/<构件>.md 或 domains/<域>.md
```

## 缺口

- 254 个 AppService 无实现类 → 流转 UNVERIFIED（实现在平台服务端）
- 「其他」类动作（392 个）多为 `batch*` / `dynamic*` / `process*` 前缀，未归类
- 流转只给第一步调用，完整链路见 flow 文件
